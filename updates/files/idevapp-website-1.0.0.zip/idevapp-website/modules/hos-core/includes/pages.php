<?php
/**
 * หน้าเว็บสำหรับธีม iDevApp แบบที่ 1: สร้างด้วยบล็อกมาตรฐานของ WordPress (แก้ไขได้ตรงหน้า)
 * เนื้อหามาจากธีม (hos_page_content_home / hos_page_contents) โดยใช้ชื่อ ที่อยู่ และเบอร์โทรที่ตั้งไว้
 */
defined( 'ABSPATH' ) || exit;

function hos_wys_ready() {
	return function_exists( 'hos_page_content_home' ) && function_exists( 'hos_page_contents' );
}

/** เขียนเนื้อหาให้หน้า: หน้าที่มีอยู่แล้วจะไม่ถูกเขียนทับ เว้นแต่ $replace */
function hos_put_page( $post, $slug, $title, $content, $replace = false ) {
	if ( $post && 'page' === $post->post_type ) {
		if ( ! $replace ) {
			return $post->ID;
		}
		wp_update_post( wp_slash( array( 'ID' => $post->ID, 'post_content' => $content ) ) );
		$id = $post->ID;
	} else {
		$id = wp_insert_post( wp_slash( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug, 'post_content' => $content ) ) );
	}
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, '_wp_page_template', 'default' );
		update_post_meta( $id, '_hos_wysiwyg', 1 );
	}
	return $id;
}

/** สร้างหน้าแรกและหน้าอื่น ๆ ของธีมแบบที่ 1 · คืนรายชื่อหน้าที่สร้าง */
function hos_build_wysiwyg_pages( $replace = false ) {
	if ( ! hos_wys_ready() ) {
		return new WP_Error( 'no_theme', 'กรุณาเปิดใช้ธีม iDevApp แบบที่ 1 ก่อน' );
	}
	$done  = array();
	$front = get_post( (int) get_option( 'page_on_front' ) );
	$id    = hos_put_page( $front, 'home', 'หน้าแรก', hos_page_content_home( '' ), $replace );
	if ( $id && ! is_wp_error( $id ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $id );
	}
	$done[] = 'หน้าแรก';
	foreach ( hos_page_contents() as $slug => $pg ) {
		hos_put_page( get_page_by_path( $slug ), $slug, $pg[0], $pg[1], $replace );
		$done[] = $pg[0];
	}
	return $done;
}

/** หน้าแบบนี้เปิดด้วยตัวแก้ไขบล็อกเสมอ (แม้เปิด Classic Editor อยู่) */
add_filter( 'use_block_editor_for_post', function ( $use, $post ) {
	return ( $post && get_post_meta( $post->ID, '_hos_wysiwyg', true ) ) ? true : $use;
}, 999, 2 );
