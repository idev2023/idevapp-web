<?php
/**
 * Plugin Name:       iDev Store
 * Plugin URI:        https://idevapp.me/plugins/idev-store
 * Description:       Back office for clinics, eye clinics / optical shops and pharmacies: stock with lots and expiry dates, point of sale and dispensing, drug labels and ขย. books, job orders (e.g. glasses) with prescriptions, pick-up appointments, receipts for 80 mm, A4/A5 or continuous-form printers, and PromptPay QR.
 * Version:           1.3.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-store
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// Loaded once: the same plugin may also be inside an iDevApp package (I-Clinic / I-Drug) or a Pro version.
if (defined('IDEV_STORE_VERSION')) return;

define('IDEV_STORE_VERSION', '1.3.0');
define('IDEV_STORE_FILE', __FILE__);
define('IDEV_STORE_DIR', plugin_dir_path(__FILE__));
define('IDEV_STORE_URL', plugin_dir_url(__FILE__));

require_once __DIR__ . '/common/idev-common.php';
require_once __DIR__ . '/includes/core.php';
require_once __DIR__ . '/includes/license.php';
require_once __DIR__ . '/includes/stock.php';
require_once __DIR__ . '/includes/customers.php';
require_once __DIR__ . '/includes/bills.php';
require_once __DIR__ . '/includes/jobs.php';
require_once __DIR__ . '/includes/pharmacy.php';
require_once __DIR__ . '/includes/promptpay.php';
require_once __DIR__ . '/includes/rest.php';
require_once __DIR__ . '/includes/print.php';
require_once __DIR__ . '/includes/codes.php';
require_once __DIR__ . '/includes/front.php';
require_once __DIR__ . '/includes/admin.php';
require_once __DIR__ . '/includes/admin-pos.php';
require_once __DIR__ . '/includes/admin-jobs.php';
require_once __DIR__ . '/includes/admin-stock.php';
require_once __DIR__ . '/includes/admin-customers.php';
require_once __DIR__ . '/includes/admin-reports.php';
require_once __DIR__ . '/includes/settings.php';

register_activation_hook(__FILE__, 'idev_store_install');
