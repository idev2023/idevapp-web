/* iDev Cookie Consent — banner, categories, inert scripts, Consent Mode, consent log.
   API: window.idevConsent.allowed('analytics'|'external'|'marketing'), .state, .open(); event "idev:consent" on document. */
(function () {
  const C = window.IDEV_CC || {};
  const box = document.getElementById('idev-cc');
  if (!box) return;
  const reopen = document.querySelector('.idev-cc-reopen');
  const prefs = box.querySelector('.idev-cc-prefs');
  const btn = (k) => box.querySelector('[data-cc="' + k + '"]');
  let state = window.idevConsentState || null;
  let lastFocus = null;

  const api = window.idevConsent = {
    get state() { return state; },
    allowed(cat) { return cat === 'necessary' || !!(state && state.cats.indexOf(cat) > -1); },
    open() { show(true); },
  };

  function uid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  }
  function save(cats, choice) {
    cats = ['necessary'].concat(cats.filter((c) => c !== 'necessary' && C.cats.indexOf(c) > -1));
    const id = (state && state.id) || uid();
    state = { id, cats, choice };
    const v = [C.version, id, cats.join(',')].join('|');
    document.cookie = C.cookie + '=' + encodeURIComponent(v) + ';max-age=' + (C.days * 86400) + ';path=' + C.path + ';SameSite=Lax' + (C.secure ? ';Secure' : '');
    window.idevConsentPending = false;
    if (C.gcm && typeof window.gtag === 'function') {
      const g = (x) => (cats.indexOf(x) > -1 ? 'granted' : 'denied');
      gtag('consent', 'update', { ad_storage: g('marketing'), ad_user_data: g('marketing'), ad_personalization: g('marketing'), analytics_storage: g('analytics') });
    }
    if (C.log && window.fetch) {
      fetch(C.log, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, choice, cats, page: location.href.split('#')[0] }), keepalive: true, credentials: 'omit' }).catch(() => {});
    }
    activate();
    hide();
    document.dispatchEvent(new CustomEvent('idev:consent', { detail: { state: choice, categories: cats.slice() } }));
  }
  /* Turn inert <script type="text/plain" data-idev-category> and <iframe data-idev-src> on when allowed. */
  function activate() {
    document.querySelectorAll('script[type="text/plain"][data-idev-category]').forEach((old) => {
      if (!api.allowed(old.dataset.idevCategory)) return;
      const s = document.createElement('script');
      for (const a of old.attributes) if (a.name !== 'type' && a.name !== 'data-idev-category') s.setAttribute(a.name, a.value);
      s.text = old.text;
      old.replaceWith(s);
    });
    document.querySelectorAll('iframe[data-idev-src][data-idev-category]').forEach((f) => {
      if (!api.allowed(f.dataset.idevCategory)) return;
      f.src = f.dataset.idevSrc; f.removeAttribute('data-idev-src');
    });
  }
  function syncSwitches() {
    box.querySelectorAll('.idev-cc-switch:not([disabled])').forEach((i) => { i.checked = api.allowed(i.dataset.cat); });
  }
  function show(focus) {
    syncSwitches();
    box.hidden = false;
    if (reopen) reopen.hidden = true;
    document.documentElement.classList.add('idev-cc-open');
    if (focus) { lastFocus = document.activeElement; const b = btn('accept'); if (b) b.focus(); }
  }
  function hide() {
    box.hidden = true;
    document.documentElement.classList.remove('idev-cc-open');
    if (prefs) { prefs.hidden = true; togglePrefsButtons(false); }
    if (reopen) reopen.hidden = false;
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  function togglePrefsButtons(open) {
    const p = btn('prefs'), s = btn('save');
    if (p) p.hidden = open;
    if (s) s.hidden = !open;
  }

  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-cc]');
    if (!el) return;
    const k = el.dataset.cc;
    if (k === 'open') { e.preventDefault(); show(true); return; }
    if (!box.contains(el)) return;
    if (k === 'accept') save(C.cats.slice(), 'accept');
    else if (k === 'reject') save([], 'reject');
    else if (k === 'prefs' && prefs) { prefs.hidden = false; syncSwitches(); togglePrefsButtons(true); }
    else if (k === 'save') save(Array.from(box.querySelectorAll('.idev-cc-switch:checked')).map((i) => i.dataset.cat), 'custom');
  });
  // Keyboard: the modal layout keeps focus inside; Escape never answers for the visitor.
  box.addEventListener('keydown', (e) => {
    if (e.key !== 'Tab' || !box.classList.contains('idev-cc-modal')) return;
    const f = Array.from(box.querySelectorAll('button:not([hidden]),a[href],input:not([disabled])')).filter((x) => x.offsetParent !== null);
    if (!f.length) return;
    if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
    else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
  });

  if (state) { activate(); if (reopen) reopen.hidden = false; }
  else show(false); // no answer yet: asked again on every page until Accept, Reject or Save is pressed
})();
