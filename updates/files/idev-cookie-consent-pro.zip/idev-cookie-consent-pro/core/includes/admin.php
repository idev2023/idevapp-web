<?php
defined('ABSPATH') || exit;

add_action('admin_menu', function () {
    add_submenu_page('idevapp', __('Cookie consent', 'idev-cookie-consent'), __('Cookie consent', 'idev-cookie-consent'), 'manage_options', 'idev-cookie-consent', 'idev_cc_page');
}, 20);

function idev_cc_fields() {
    $pages = ['0' => __('— WordPress privacy policy page —', 'idev-cookie-consent')];
    foreach (get_pages(['post_status' => 'publish']) as $p) $pages[(string) $p->ID] = $p->post_title;
    return [
        'general' => [
            ['enabled', __('Show the cookie banner', 'idev-cookie-consent'), 'checkbox', __('Shown on every page until the visitor presses Accept, Reject or Save. Nothing is remembered before that.', 'idev-cookie-consent')],
            ['layout', __('Layout', 'idev-cookie-consent'), 'select', '', ['bar' => __('Bar across the screen', 'idev-cookie-consent'), 'box' => __('Box in the corner', 'idev-cookie-consent'), 'modal' => __('Centre of the screen (must answer first)', 'idev-cookie-consent')]],
            ['position', __('Position', 'idev-cookie-consent'), 'select', '', ['bottom' => __('Bottom', 'idev-cookie-consent'), 'top' => __('Top', 'idev-cookie-consent')]],
            ['policy_page', __('Privacy policy page', 'idev-cookie-consent'), 'select', '', $pages],
            ['policy_url', __('…or policy link', 'idev-cookie-consent'), 'url'],
            ['show_settings', __('Let visitors choose categories', 'idev-cookie-consent'), 'checkbox'],
            ['reopen', __('Cookie settings button after answering', 'idev-cookie-consent'), 'checkbox', __('Small round button in the corner so visitors can change their mind (required by PDPA/GDPR: withdrawing must be as easy as giving consent). You can also use [idev_cookie_settings].', 'idev-cookie-consent')],
            ['days', __('Remember the answer for (days)', 'idev-cookie-consent'), 'number', '', [1, 395]],
            ['version', __('Policy version', 'idev-cookie-consent'), 'text', __('Change this (e.g. 2) after you change the policy: everyone is asked again.', 'idev-cookie-consent')],
            ['log', __('Keep a consent log', 'idev-cookie-consent'), 'checkbox', __('Proof of consent: random ID, choice, time, page, browser and a one-way hash of the IP address. Kept 36 months.', 'idev-cookie-consent')],
        ],
        'text' => [
            ['title', __('Heading (Thai)', 'idev-cookie-consent'), 'text'], ['title_en', __('Heading (English)', 'idev-cookie-consent'), 'text'],
            ['text', __('Message (Thai)', 'idev-cookie-consent'), 'textarea'], ['text_en', __('Message (English)', 'idev-cookie-consent'), 'textarea'],
        ],
        'categories' => [
            ['cat_analytics', __('Statistics', 'idev-cookie-consent'), 'checkbox'],
            ['cat_external', __('External media (maps, videos)', 'idev-cookie-consent'), 'checkbox'],
            ['cat_marketing', __('Marketing', 'idev-cookie-consent'), 'checkbox'],
            ['gcm', __('Google Consent Mode v2', 'idev-cookie-consent'), 'checkbox', __('For Google Analytics / Tag Manager / Ads: sends "denied" until the visitor agrees.', 'idev-cookie-consent')],
        ],
        'look' => [
            ['bg', __('Background colour', 'idev-cookie-consent'), 'color'], ['text_color', __('Text colour', 'idev-cookie-consent'), 'color'], ['accent', __('Button colour', 'idev-cookie-consent'), 'color'],
            ['reject_style', __('Reject button', 'idev-cookie-consent'), 'select', __('PDPA and GDPR regulators expect Reject to be as easy to see as Accept.', 'idev-cookie-consent'), ['equal' => __('Same as Accept (recommended)', 'idev-cookie-consent'), 'outline' => __('Outline', 'idev-cookie-consent')]],
        ],
    ];
}

function idev_cc_page() {
    $tab = sanitize_key($_GET['tab'] ?? 'general');
    $tabs = ['general' => __('General', 'idev-cookie-consent'), 'text' => __('Text', 'idev-cookie-consent'), 'categories' => __('Categories & scripts', 'idev-cookie-consent'), 'look' => __('Appearance', 'idev-cookie-consent'), 'log' => __('Consent log', 'idev-cookie-consent')];
    if (!isset($tabs[$tab])) $tab = 'general';
    $s = idev_cc_settings();
    $all = idev_cc_fields();
    if ($tab !== 'log' && isset($_POST['idev_cookie_consent']) && check_admin_referer('idev_cc')) {
        $in = (array) wp_unslash($_POST['idev_cookie_consent']); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each field is sanitized by idev_settings_sanitize(); tracking scripts only for users with unfiltered_html
        $s = idev_settings_sanitize($all[$tab], $in, $s);
        if ($tab === 'categories' && current_user_can('unfiltered_html')) foreach (['analytics', 'marketing'] as $c) $s["scripts_{$c}"] = (string) ($in["scripts_{$c}"] ?? '');
        if ($tab === 'general') $s['version'] = preg_replace('/[^A-Za-z0-9._-]/', '', $s['version']) ?: '1';
        update_option('idev_cookie_consent', $s);
        echo '<div class="notice notice-success"><p>' . esc_html__('Saved.', 'idev-cookie-consent') . '</p></div>';
    }
    idev_admin_header(__('Cookie consent', 'idev-cookie-consent'));
    echo '<nav class="nav-tab-wrapper">';
    foreach ($tabs as $k => $l) echo '<a class="nav-tab' . ($k === $tab ? ' nav-tab-active' : '') . '" href="' . esc_url(admin_url('admin.php?page=idev-cookie-consent&tab=' . $k)) . '">' . esc_html($l) . '</a>';
    echo '</nav>';
    if ($tab === 'log') { idev_cc_log_page(); echo '</div>'; return; }
    echo '<form method="post">';
    wp_nonce_field('idev_cc');
    idev_settings_table('idev_cookie_consent', $all[$tab], $s);
    if ($tab === 'categories') {
        echo '<h2 class="idev-section">' . esc_html__('Scripts that wait for consent', 'idev-cookie-consent') . '</h2><p class="description">' . esc_html__('Paste tracking codes here instead of in the theme. They run only after the visitor allows that category.', 'idev-cookie-consent') . '</p><table class="form-table">';
        foreach (['analytics' => __('Statistics scripts (e.g. Google Analytics)', 'idev-cookie-consent'), 'marketing' => __('Marketing scripts (e.g. Facebook Pixel)', 'idev-cookie-consent')] as $c => $l) {
            echo '<tr><th>' . esc_html($l) . '</th><td><textarea class="large-text code" rows="6" name="idev_cookie_consent[scripts_' . esc_attr($c) . ']"' . (current_user_can('unfiltered_html') ? '' : ' readonly') . '>' . esc_textarea($s["scripts_{$c}"]) . '</textarea></td></tr>';
        }
        echo '</table><div class="idev-card"><h3>' . esc_html__('For developers', 'idev-cookie-consent') . '</h3><p><code>&lt;script type="text/plain" data-idev-category="analytics"&gt;…&lt;/script&gt;</code></p><p><code>&lt;iframe data-idev-src="…" data-idev-category="external"&gt;</code></p><p><code>window.idevConsent.allowed(\'external\')</code> · <code>document.addEventListener(\'idev:consent\', …)</code> · PHP <code>idev_consent_allowed(\'analytics\')</code></p></div>';
    }
    submit_button();
    echo '</form></div>';
}

function idev_cc_log_page() {
    global $wpdb;
    $days = 30;
    $since = gmdate('Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS);
    $rows = $wpdb->get_results($wpdb->prepare('SELECT choice, COUNT(*) n FROM %i WHERE created_at >= %s GROUP BY choice', idev_cc_table(), $since), OBJECT_K); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- plugin's own log table
    $total = array_sum(array_map(function ($r) { return (int) $r->n; }, $rows));
    $labels = ['accept' => __('Accepted all', 'idev-cookie-consent'), 'reject' => __('Rejected', 'idev-cookie-consent'), 'custom' => __('Chose categories', 'idev-cookie-consent')];
    /* translators: %d: number of days */
    echo '<h2>' . esc_html(sprintf(__('Last %d days', 'idev-cookie-consent'), $days)) . '</h2><div class="idev-stats">';
    foreach ($labels as $k => $l) { $n = (int) ($rows[$k]->n ?? 0); echo '<div class="idev-stat"><strong>' . esc_html(number_format_i18n($n)) . '</strong><span>' . esc_html($l . ($total ? ' · ' . round($n * 100 / $total) . '%' : '')) . '</span></div>'; }
    echo '</div><p><a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=idev_cc_export'), 'idev_cc_export')) . '">' . esc_html__('Download CSV (all records)', 'idev-cookie-consent') . '</a></p>';
    $search = sanitize_text_field(wp_unslash($_GET['cid'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only search
    echo '<form method="get"><input type="hidden" name="page" value="idev-cookie-consent"><input type="hidden" name="tab" value="log"><p><input name="cid" value="' . esc_attr($search) . '" placeholder="' . esc_attr__('Consent ID', 'idev-cookie-consent') . '" class="regular-text"> <button class="button">' . esc_html__('Find', 'idev-cookie-consent') . '</button></p></form>';
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- plugin's own log table
    $list = $search !== '' ? $wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE consent_id = %s ORDER BY id DESC LIMIT 100', idev_cc_table(), $search)) : $wpdb->get_results($wpdb->prepare('SELECT * FROM %i ORDER BY id DESC LIMIT 50', idev_cc_table()));
    echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Time', 'idev-cookie-consent') . '</th><th>' . esc_html__('Consent ID', 'idev-cookie-consent') . '</th><th>' . esc_html__('Choice', 'idev-cookie-consent') . '</th><th>' . esc_html__('Categories', 'idev-cookie-consent') . '</th><th>' . esc_html__('Policy version', 'idev-cookie-consent') . '</th><th>' . esc_html__('Page', 'idev-cookie-consent') . '</th></tr></thead><tbody>';
    if (!$list) echo '<tr><td colspan="6">' . esc_html__('No records yet.', 'idev-cookie-consent') . '</td></tr>';
    foreach ($list as $r) echo '<tr><td>' . esc_html(get_date_from_gmt($r->created_at, 'Y-m-d H:i')) . '</td><td><code>' . esc_html($r->consent_id) . '</code></td><td>' . esc_html($labels[$r->choice] ?? $r->choice) . '</td><td>' . esc_html($r->categories) . '</td><td>' . esc_html($r->policy_version) . '</td><td>' . esc_html(wp_parse_url($r->page, PHP_URL_PATH) ?: '/') . '</td></tr>';
    echo '</tbody></table><p class="description">' . esc_html__('A visitor can find their consent ID in the "idev_consent" cookie (the part between the | signs) if they ask you to show or delete their record.', 'idev-cookie-consent') . '</p>';
}

add_action('admin_post_idev_cc_export', function () {
    global $wpdb;
    if (!current_user_can('manage_options') || !check_admin_referer('idev_cc_export')) wp_die('Forbidden', 403);
    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="consent-log-' . gmdate('Ymd') . '.csv"');
    $out = fopen('php://output', 'w'); // phpcs:ignore WordPress.WP.AlternativeFunctions -- streaming a CSV download, not a file
    fwrite($out, "\xEF\xBB\xBF"); // phpcs:ignore WordPress.WP.AlternativeFunctions
    fputcsv($out, ['created_at_utc', 'consent_id', 'choice', 'categories', 'policy_version', 'ip_hash', 'user_agent', 'page']);
    $last = 0;
    do {
        $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE id > %d ORDER BY id LIMIT 2000', idev_cc_table(), $last), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- plugin's own log table
        foreach ($rows as $r) {
            $last = (int) $r['id'];
            $line = [$r['created_at'], $r['consent_id'], $r['choice'], $r['categories'], $r['policy_version'], $r['ip_hash'], $r['user_agent'], $r['page']];
            fputcsv($out, array_map(function ($v) { return preg_match('/^[=+\-@\t\r]/', (string) $v) ? "'" . $v : $v; }, $line));
        }
    } while ($rows);
    fclose($out); // phpcs:ignore WordPress.WP.AlternativeFunctions
    exit;
});
