<?php
defined('ABSPATH') || exit;

const IDEV_CC_COOKIE = 'idev_consent';

function idev_cc_defaults() {
    return [
        'enabled' => '1', 'layout' => 'bar', 'position' => 'bottom',
        'title' => 'เว็บไซต์นี้ใช้คุกกี้', 'title_en' => 'We use cookies',
        'text' => 'เราใช้คุกกี้ที่จำเป็นเพื่อให้เว็บไซต์ทำงานได้ และใช้คุกกี้อื่น ๆ (เช่น สถิติการเข้าชม แผนที่ Google และวิดีโอ YouTube) เมื่อคุณยินยอมเท่านั้น ตามพระราชบัญญัติคุ้มครองข้อมูลส่วนบุคคล (PDPA)',
        'text_en' => 'We use necessary cookies to make this website work, and other cookies (such as visit statistics, Google Maps and YouTube) only when you agree, in line with Thailand\'s PDPA and the GDPR.',
        'policy_page' => '0', 'policy_url' => '',
        'show_settings' => '1', 'cat_analytics' => '1', 'cat_external' => '1', 'cat_marketing' => '0',
        'reopen' => '1', 'days' => '365', 'version' => '1', 'log' => '1', 'gcm' => '0',
        'bg' => '#ffffff', 'text_color' => '#1f2937', 'accent' => '#0f766e', 'reject_style' => 'equal',
        'scripts_analytics' => '', 'scripts_marketing' => '',
    ];
}
function idev_cc_settings() { $s = get_option('idev_cookie_consent', []); return array_merge(idev_cc_defaults(), is_array($s) ? $s : []); }

/** True when the banner is on (other iDev plugins check this to hold back maps and videos). */
function idev_cookie_consent_active() { return idev_cc_settings()['enabled'] === '1'; }

function idev_cc_categories() {
    $s = idev_cc_settings();
    $all = [
        'necessary' => [__('Necessary', 'idev-cookie-consent'), __('Needed for the website to work, e.g. language choice and security. Always on.', 'idev-cookie-consent')],
        'analytics' => [__('Statistics', 'idev-cookie-consent'), __('Helps us understand how the website is used, e.g. Google Analytics.', 'idev-cookie-consent')],
        'external' => [__('External media', 'idev-cookie-consent'), __('Content from other services such as Google Maps and YouTube.', 'idev-cookie-consent')],
        'marketing' => [__('Marketing', 'idev-cookie-consent'), __('Used to show relevant advertising, e.g. Facebook Pixel.', 'idev-cookie-consent')],
    ];
    return array_filter($all, function ($k) use ($s) { return $k === 'necessary' || ($s["cat_{$k}"] ?? '0') === '1'; }, ARRAY_FILTER_USE_KEY);
}

/** Server-side: did this visitor allow a category? (Pages may be cached — prefer the JS API in templates.) */
function idev_consent_allowed($cat) {
    if (!idev_cookie_consent_active() || $cat === 'necessary') return true;
    $raw = sanitize_text_field(wp_unslash($_COOKIE[IDEV_CC_COOKIE] ?? ''));
    $parts = explode('|', $raw);
    if (count($parts) < 3 || $parts[0] !== idev_cc_settings()['version']) return false;
    return in_array($cat, explode(',', $parts[2]), true);
}

function idev_cc_policy_url() {
    $s = idev_cc_settings();
    if ((int) $s['policy_page'] && get_post_status((int) $s['policy_page']) === 'publish') return get_permalink((int) $s['policy_page']);
    if ($s['policy_url']) return $s['policy_url'];
    $p = (int) get_option('wp_page_for_privacy_policy');
    return $p && get_post_status($p) === 'publish' ? get_permalink($p) : '';
}

add_action('init', function () {
    load_plugin_textdomain('idev-cookie-consent', false, dirname(plugin_basename(IDEV_CC_FILE)) . '/languages');
    idev_register_plugin('idev-cookie-consent', ['name' => 'iDev Cookie Consent', 'version' => IDEV_CC_VERSION, 'description' => __('PDPA / GDPR cookie banner with consent log.', 'idev-cookie-consent'), 'settings' => admin_url('admin.php?page=idev-cookie-consent'), 'docs' => 'https://idevapp.me/plugins/idev-cookie-consent']);
});
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_CC_FILE, admin_url('admin.php?page=idev-cookie-consent'), 'https://idevapp.me/plugins/idev-cookie-consent'); });

/* Early in <head>: know the answer before any other script runs, so popups and Consent Mode can wait. */
add_action('wp_head', function () {
    if (!idev_cookie_consent_active() || is_admin()) return;
    $s = idev_cc_settings();
    $boot = 'window.idevConsentPending=true;(function(){var m=document.cookie.match(/(?:^|; )' . IDEV_CC_COOKIE . '=([^;]*)/),v=m?decodeURIComponent(m[1]).split("|"):[];if(v.length>2&&v[0]===' . wp_json_encode((string) $s['version']) . '){window.idevConsentPending=false;window.idevConsentState={id:v[1],cats:v[2].split(",")};}})();';
    if ($s['gcm'] === '1') {
        $boot .= 'window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}(function(){var c=(window.idevConsentState||{cats:[]}).cats,g=function(x){return c.indexOf(x)>-1?"granted":"denied";};gtag("consent","default",{ad_storage:g("marketing"),ad_user_data:g("marketing"),ad_personalization:g("marketing"),analytics_storage:g("analytics"),functionality_storage:"granted",security_storage:"granted",wait_for_update:500});})();';
    }
    wp_print_inline_script_tag($boot, ['id' => 'idev-cc-boot']);
}, 1);

/* Scripts the site owner pasted for each category: kept inert until allowed. */
function idev_cc_inert_scripts($html, $cat) {
    if (trim($html) === '') return '';
    return preg_replace_callback('#<script\b([^>]*)>#i', function ($m) use ($cat) {
        $attrs = preg_replace('#\stype\s*=\s*(["\'])[^"\']*\1#i', '', $m[1]);
        return '<script type="text/plain" data-idev-category="' . esc_attr($cat) . '"' . $attrs . '>';
    }, $html);
}
add_action('wp_head', function () {
    if (is_admin()) return;
    $s = idev_cc_settings();
    foreach (['analytics', 'marketing'] as $cat) {
        if (trim($s["scripts_{$cat}"]) === '') continue;
        echo idev_cc_active_or_inert($s["scripts_{$cat}"], $cat); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- tracking code pasted by an administrator who has the unfiltered_html capability; it is made inert until consent
    }
}, 20);
function idev_cc_active_or_inert($html, $cat) { return idev_cookie_consent_active() ? idev_cc_inert_scripts($html, $cat) : $html; }

add_action('wp_enqueue_scripts', function () {
    if (!idev_cookie_consent_active()) return;
    $s = idev_cc_settings();
    wp_enqueue_style('idev-cc', plugins_url('assets/consent.css', IDEV_CC_FILE), [], IDEV_CC_VERSION);
    wp_enqueue_script('idev-cc', plugins_url('assets/consent.js', IDEV_CC_FILE), [], IDEV_CC_VERSION, true);
    wp_localize_script('idev-cc', 'IDEV_CC', [
        'cookie' => IDEV_CC_COOKIE, 'version' => (string) $s['version'], 'days' => (int) $s['days'], 'gcm' => $s['gcm'] === '1',
        'log' => $s['log'] === '1' ? esc_url_raw(rest_url('idev-consent/v1/log')) : '',
        'cats' => array_keys(idev_cc_categories()), 'secure' => is_ssl(), 'path' => COOKIEPATH ?: '/',
    ]);
});

add_action('wp_footer', function () {
    if (!idev_cookie_consent_active() || is_admin()) return;
    $s = idev_cc_settings();
    $policy = idev_cc_policy_url();
    $cats = idev_cc_categories();
    $style = '--idev-cc-bg:' . (sanitize_hex_color($s['bg']) ?: '#ffffff') . ';--idev-cc-fg:' . (sanitize_hex_color($s['text_color']) ?: '#1f2937') . ';--idev-cc-accent:' . (sanitize_hex_color($s['accent']) ?: '#0f766e');
    $layout = in_array($s['layout'], ['bar', 'box', 'modal'], true) ? $s['layout'] : 'bar';
    echo '<div class="' . esc_attr('idev-cc idev-cc-' . $layout . ' idev-cc-' . ($s['position'] === 'top' ? 'top' : 'bottom') . ' idev-cc-reject-' . $s['reject_style']) . '" id="idev-cc" style="' . esc_attr($style) . '" role="dialog" aria-modal="' . ($layout === 'modal' ? 'true' : 'false') . '" aria-labelledby="idev-cc-title" aria-describedby="idev-cc-text" hidden>';
    echo '<div class="idev-cc-panel"><div class="idev-cc-main"><h2 id="idev-cc-title">' . esc_html(idev_pick($s['title'], $s['title_en'])) . '</h2><p id="idev-cc-text">' . esc_html(idev_pick($s['text'], $s['text_en']));
    if ($policy) echo ' <a href="' . esc_url($policy) . '">' . esc_html__('Privacy policy', 'idev-cookie-consent') . '</a>';
    echo '</p></div>';
    if ($s['show_settings'] === '1' && count($cats) > 1) {
        echo '<div class="idev-cc-prefs" hidden>';
        foreach ($cats as $k => $c) {
            $fixed = $k === 'necessary';
            echo '<label class="idev-cc-cat"><span><strong>' . esc_html($c[0]) . '</strong><small>' . esc_html($c[1]) . '</small></span><input type="checkbox" class="idev-cc-switch" data-cat="' . esc_attr($k) . '"' . ($fixed ? ' checked disabled' : '') . '>' . ($fixed ? '<em>' . esc_html__('Always on', 'idev-cookie-consent') . '</em>' : '') . '</label>';
        }
        echo '</div>';
    }
    echo '<div class="idev-cc-actions">';
    if ($s['show_settings'] === '1' && count($cats) > 1) echo '<button type="button" class="idev-cc-btn is-link" data-cc="prefs">' . esc_html__('Choose', 'idev-cookie-consent') . '</button><button type="button" class="idev-cc-btn is-ghost" data-cc="save" hidden>' . esc_html__('Save my choices', 'idev-cookie-consent') . '</button>';
    echo '<button type="button" class="idev-cc-btn is-reject" data-cc="reject">' . esc_html__('Reject', 'idev-cookie-consent') . '</button><button type="button" class="idev-cc-btn is-accept" data-cc="accept">' . esc_html__('Accept all', 'idev-cookie-consent') . '</button></div></div></div>';
    if ($s['reopen'] === '1') echo '<button type="button" class="idev-cc-reopen" style="' . esc_attr($style) . '" data-cc="open" aria-label="' . esc_attr__('Cookie settings', 'idev-cookie-consent') . '" title="' . esc_attr__('Cookie settings', 'idev-cookie-consent') . '" hidden><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 1 0 9 9 4 4 0 0 1-4-4 4 4 0 0 1-5-5Z"/><circle cx="8.5" cy="10.5" r="1"/><circle cx="14.5" cy="15.5" r="1"/><circle cx="9.5" cy="15.5" r="1"/></svg></button>';
}, 5);

/* Link anywhere: [idev_cookie_settings]Cookie settings[/idev_cookie_settings] */
add_shortcode('idev_cookie_settings', function ($a, $content = '') {
    return '<a href="#" class="idev-cc-open" data-cc="open">' . esc_html($content ?: __('Cookie settings', 'idev-cookie-consent')) . '</a>';
});

/* ---------- Consent log (proof of consent for PDPA section 19 / GDPR art. 7) ---------- */

function idev_cc_table() { global $wpdb; return $wpdb->prefix . 'idev_consent_log'; }
function idev_cc_install() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta('CREATE TABLE ' . idev_cc_table() . " (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        consent_id varchar(40) NOT NULL,
        choice varchar(20) NOT NULL,
        categories varchar(120) NOT NULL,
        policy_version varchar(20) NOT NULL,
        ip_hash char(64) NOT NULL,
        user_agent varchar(200) NOT NULL DEFAULT '',
        page varchar(255) NOT NULL DEFAULT '',
        created_at datetime NOT NULL,
        PRIMARY KEY  (id),
        KEY consent_id (consent_id),
        KEY created_at (created_at)
    ) " . $wpdb->get_charset_collate() . ';');
    update_option('idev_cc_db', '1', false);
    if (!wp_next_scheduled('idev_cc_prune')) wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'idev_cc_prune');
}
add_action('plugins_loaded', function () { if (get_option('idev_cc_db') !== '1') idev_cc_install(); });
add_action('idev_cc_prune', function () {
    global $wpdb;
    $months = max(1, (int) apply_filters('idev_cc_log_months', 36));
    $wpdb->query($wpdb->prepare('DELETE FROM %i WHERE created_at < %s', idev_cc_table(), gmdate('Y-m-d H:i:s', strtotime("-{$months} months")))); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- plugin's own log table
});

add_action('rest_api_init', function () {
    register_rest_route('idev-consent/v1', '/log', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => function (WP_REST_Request $r) {
        global $wpdb;
        if (idev_cc_settings()['log'] !== '1') return new WP_REST_Response(['ok' => false], 200);
        $ip = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? ''));
        $ip_hash = hash_hmac('sha256', $ip, wp_salt('auth'));
        $key = 'idev_cc_rl_' . substr($ip_hash, 0, 20);
        $n = (int) get_transient($key);
        if ($n >= 30) return new WP_REST_Response(['ok' => false, 'error' => 'rate'], 429);
        set_transient($key, $n + 1, HOUR_IN_SECONDS);
        $valid = array_keys(idev_cc_categories());
        $cats = array_values(array_intersect($valid, array_map('sanitize_key', (array) $r->get_param('cats'))));
        if (!in_array('necessary', $cats, true)) array_unshift($cats, 'necessary');
        $choice = in_array($r->get_param('choice'), ['accept', 'reject', 'custom'], true) ? $r->get_param('choice') : 'custom';
        $id = preg_replace('/[^a-z0-9-]/', '', strtolower((string) $r->get_param('id')));
        if (strlen($id) < 8) return new WP_REST_Response(['ok' => false], 400);
        $wpdb->insert(idev_cc_table(), [ // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- plugin's own log table
            'consent_id' => substr($id, 0, 40), 'choice' => $choice, 'categories' => implode(',', $cats), 'policy_version' => (string) idev_cc_settings()['version'],
            'ip_hash' => $ip_hash, 'user_agent' => mb_substr(sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? '')), 0, 200),
            'page' => mb_substr(esc_url_raw((string) $r->get_param('page')), 0, 255), 'created_at' => current_time('mysql', true),
        ]);
        return new WP_REST_Response(['ok' => true], 200);
    }]);
});

/* Privacy policy helper text (Settings → Privacy → Policy guide). */
add_action('admin_init', function () {
    if (!function_exists('wp_add_privacy_policy_content')) return;
    wp_add_privacy_policy_content('iDev Cookie Consent', wpautop(__('This website asks for your consent before using cookies other than necessary ones. Your choice is kept in the "idev_consent" cookie for up to 12 months. As proof of consent we record a random consent ID, your choice, the date and time, the page, your browser name and a one-way hash of your IP address (the IP address itself is not stored). You can change your choice at any time with the "Cookie settings" button.', 'idev-cookie-consent')));
});
