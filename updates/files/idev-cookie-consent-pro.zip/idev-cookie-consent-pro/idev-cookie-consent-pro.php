<?php
/**
 * Plugin Name:       iDev Cookie Consent Pro
 * Plugin URI:        https://idevapp.me/plugins/idev-cookie-consent
 * Description:       Add-on for iDev Cookie Consent (PDPA / GDPR): privacy request form and register with 30-day deadlines, consent receipts and evidence reports, policy version archive, cookie and script scanner, log retention.
 * Version:           1.1.1
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-cookie-consent-pro
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// Loaded once: the same plugin may also be inside an iDevApp package (I-Clinic / I-Drug) or a Pro version.
if (defined('IDEV_CCP_VERSION')) return;

define('IDEV_CCP_VERSION', '1.1.1');
define('IDEV_CCP_FILE', __FILE__);
define('IDEV_CCP_DIR', __DIR__);

if (!function_exists('idev_free_plugin_active')) {
    /** Is this plugin active as a separate plugin (this site or network)? */
    function idev_free_plugin_active($slug) {
        $f = $slug . '/' . $slug . '.php';
        if (in_array($f, (array) get_option('active_plugins', []), true)) return true;
        return is_multisite() && isset(((array) get_site_option('active_sitewide_plugins', []))[$f]);
    }
}
/* One plugin to install: the Pro zip contains the free plugin (iDev Cookie Consent) in core/. */
// WordPress loads "idev-cookie-consent-pro" before "idev-cookie-consent": when the separate free plugin is still active, let it load itself
// (it is switched off on the next admin page) instead of loading the copy in core/ — loading both would be a fatal error.
if (!defined('IDEV_CC_VERSION') && is_file(__DIR__ . '/core/idev-cookie-consent.php') && !idev_free_plugin_active('idev-cookie-consent')) require_once __DIR__ . '/core/idev-cookie-consent.php';
require_once __DIR__ . '/common/idev-common.php';
require_once __DIR__ . '/includes/core.php';

/* The add-on needs the free plugin (iDev Cookie Consent). */
add_action('plugins_loaded', function () {
    if (!function_exists('idev_cc_settings')) {
        add_action('admin_notices', function () {
            if (!current_user_can('activate_plugins')) return;
            echo '<div class="notice notice-error"><p>' . esc_html__('iDev Cookie Consent Pro needs the free plugin iDev Cookie Consent. Please install and activate it (Plugins → Add New → search "iDev Cookie Consent").', 'idev-cookie-consent-pro') . '</p></div>';
        });
        return;
    }
    foreach (['license', 'policies', 'requests', 'reports', 'scanner', 'admin'] as $f) require_once __DIR__ . '/includes/' . $f . '.php';
}, 20);

register_activation_hook(__FILE__, function () use (&$idev_ccp_takeover) {
    if (function_exists('idev_cc_install')) idev_cc_install();
    idev_ccp_install();
    $idev_ccp_takeover();
});
/** The free plugin is inside this one: switch the separate free plugin off (settings and data are shared). */
$idev_ccp_takeover = function () {
    if (!is_dir(__DIR__ . '/core')) return;
    if (!function_exists('is_plugin_active')) require_once ABSPATH . 'wp-admin/includes/plugin.php';
    $free = 'idev-cookie-consent/idev-cookie-consent.php';
    if (!is_plugin_active($free)) return;
    deactivate_plugins($free, true);
    set_transient('idev_ccp_took_over', 1, 600);
};
add_action('admin_init', $idev_ccp_takeover);
add_action('admin_notices', function () {
    if (!get_transient('idev_ccp_took_over') || !current_user_can('activate_plugins')) return;
    delete_transient('idev_ccp_took_over');
    echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('The Pro version already contains the free plugin, so the separate free plugin was switched off. Your settings and data are kept. You can delete the free plugin.', 'idev-cookie-consent-pro') . '</p></div>';
});
