<?php
/**
 * Cookie and script scanner: loads pages of this website the way a first-time visitor sees them (no consent yet),
 * finds tracking scripts, pixels and embeds, and tells which ones run before consent.
 */
defined('ABSPATH') || exit;

/** Known services: regex on the URL or code => [name, category]. */
function idev_ccp_services() {
    return apply_filters('idev_ccp_services', [
        '#google-analytics\.com|googletagmanager\.com/gtag|gtag\(\s*[\'"]config[\'"]#i' => ['Google Analytics', 'analytics'],
        '#googletagmanager\.com/gtm\.js|GTM-[A-Z0-9]+#' => ['Google Tag Manager', 'analytics'],
        '#connect\.facebook\.net|fbq\(\s*[\'"]init|facebook\.com/tr\?#i' => ['Facebook / Meta Pixel', 'marketing'],
        '#analytics\.tiktok\.com|ttq\.load#i' => ['TikTok Pixel', 'marketing'],
        '#tr\.line\.me|d\.line-scdn\.net/n/line_tag#i' => ['LINE Tag', 'marketing'],
        '#googleadservices\.com|doubleclick\.net|googlesyndication\.com#i' => ['Google Ads', 'marketing'],
        '#snap\.licdn\.com|linkedin\.com/px#i' => ['LinkedIn Insight', 'marketing'],
        '#static\.hotjar\.com|hotjar\.com#i' => ['Hotjar', 'analytics'],
        '#clarity\.ms#i' => ['Microsoft Clarity', 'analytics'],
        '#mc\.yandex\.ru#i' => ['Yandex Metrica', 'analytics'],
        '#youtube\.com/embed|youtube-nocookie\.com/embed|youtu\.be#i' => ['YouTube', 'external'],
        '#player\.vimeo\.com#i' => ['Vimeo', 'external'],
        '#google\.com/maps|maps\.google\.|maps\.googleapis\.com#i' => ['Google Maps', 'external'],
        '#facebook\.com/plugins|connect\.facebook\.net/[a-z_]+/sdk#i' => ['Facebook embed', 'external'],
        '#platform\.twitter\.com|platform\.x\.com#i' => ['X (Twitter) embed', 'external'],
        '#instagram\.com/embed#i' => ['Instagram embed', 'external'],
        '#google\.com/recaptcha|gstatic\.com/recaptcha#i' => ['Google reCAPTCHA', 'necessary'],
        '#tawk\.to|embed\.tawk#i' => ['Tawk.to chat', 'external'],
    ]);
}

/** Pages to scan: home, a few recent pages and posts, plus the URLs from the settings (same site only). */
function idev_ccp_scan_urls() {
    $urls = [home_url('/')];
    foreach (get_posts(['post_type' => 'page', 'numberposts' => 6, 'post_status' => 'publish', 'orderby' => 'modified']) as $p) $urls[] = get_permalink($p);
    foreach (get_posts(['post_type' => 'post', 'numberposts' => 3, 'post_status' => 'publish']) as $p) $urls[] = get_permalink($p);
    $host = wp_parse_url(home_url('/'), PHP_URL_HOST);
    foreach (preg_split('/\s+/', (string) idev_ccp_settings()['scan_urls']) as $u) {
        $u = esc_url_raw(trim($u));
        if ($u && wp_parse_url($u, PHP_URL_HOST) === $host) $urls[] = $u;
    }
    return array_slice(array_values(array_unique(array_filter($urls))), 0, 15);
}

/** Finds services in one HTML page. Returns [items, cookies, error]. */
function idev_ccp_scan_page($url) {
    $res = wp_remote_get($url, ['timeout' => 20, 'redirection' => 3, 'sslverify' => apply_filters('https_local_ssl_verify', false), 'headers' => ['Cache-Control' => 'no-cache'], 'user-agent' => 'Mozilla/5.0 (iDev Cookie Scanner) ' . home_url('/')]);
    if (is_wp_error($res)) return [[], [], $res->get_error_message()];
    $code = wp_remote_retrieve_response_code($res);
    if ($code >= 400) return [[], [], 'HTTP ' . $code];
    $html = (string) wp_remote_retrieve_body($res);
    $items = [];
    $services = idev_ccp_services();
    $match = function ($text) use ($services) {
        foreach ($services as $re => $sv) if (preg_match($re, $text)) return $sv;
        return null;
    };
    // <script …>…</script>
    if (preg_match_all('#<script\b([^>]*)>(.*?)</script>#is', $html, $m, PREG_SET_ORDER)) {
        foreach ($m as $s) {
            $attrs = $s[1];
            if (preg_match('#\bid=["\']idev-cc-boot["\']#', $attrs)) continue;
            $src = preg_match('#\bsrc=["\']([^"\']+)#i', $attrs, $x) ? $x[1] : '';
            $sv = $match($src . ' ' . substr($s[2], 0, 4000));
            if (!$sv) continue;
            $held = (bool) preg_match('#type=["\']text/plain["\']#i', $attrs) && (bool) preg_match('#data-idev-category=#i', $attrs);
            $items[] = ['service' => $sv[0], 'category' => $sv[1], 'kind' => 'script', 'src' => $src ?: __('(code in the page)', 'idev-cookie-consent-pro'), 'held' => $held || $sv[1] === 'necessary'];
        }
    }
    // <iframe>, <img> pixels, <noscript> pixels
    if (preg_match_all('#<(iframe|img)\b([^>]*)>#is', $html, $m, PREG_SET_ORDER)) {
        foreach ($m as $t) {
            $attrs = $t[2];
            $src = preg_match('#\bsrc=["\']([^"\']+)#i', $attrs, $x) ? $x[1] : '';
            $lazy = preg_match('#\bdata-idev-src=["\']([^"\']+)#i', $attrs, $y) ? $y[1] : '';
            $sv = $match($src . ' ' . $lazy);
            if (!$sv) continue;
            $items[] = ['service' => $sv[0], 'category' => $sv[1], 'kind' => strtolower($t[1]), 'src' => $lazy ?: $src, 'held' => $lazy !== '' || $sv[1] === 'necessary'];
        }
    }
    $cookies = [];
    foreach ((array) wp_remote_retrieve_header($res, 'set-cookie') as $c) if ($c && preg_match('#^([^=;]+)=#', $c, $x)) $cookies[] = trim($x[1]);
    return [$items, array_values(array_unique($cookies)), ''];
}

function idev_ccp_scan_run() {
    $pages = []; $services = []; $cookies = [];
    foreach (idev_ccp_scan_urls() as $url) {
        [$items, $ck, $err] = idev_ccp_scan_page($url);
        $pages[] = ['url' => $url, 'error' => $err, 'count' => count($items)];
        foreach ($items as $it) {
            $k = $it['service'];
            if (!isset($services[$k])) $services[$k] = ['service' => $k, 'category' => $it['category'], 'pages' => [], 'loose' => false, 'kinds' => [], 'src' => $it['src']];
            $services[$k]['pages'][$url] = true;
            $services[$k]['kinds'][$it['kind']] = true;
            if (!$it['held']) $services[$k]['loose'] = true;
        }
        foreach ($ck as $c) $cookies[$c] = ($cookies[$c] ?? 0) + 1;
    }
    foreach ($services as &$s) { $s['pages'] = count($s['pages']); $s['kinds'] = array_keys($s['kinds']); }
    unset($s);
    $loose = count(array_filter($services, function ($s) { return $s['loose']; }));
    $errors = count(array_filter($pages, function ($p) { return $p['error'] !== ''; }));
    $data = ['time' => current_time('mysql', true), 'pages' => $pages, 'services' => array_values($services), 'cookies' => $cookies, 'summary' => ['pages' => count($pages), 'errors' => $errors, 'services' => count($services), 'loose' => $errors === count($pages) ? -1 : $loose]];
    update_option('idev_ccp_scan', $data, false);
    return $data;
}

/** Cookies a site sets itself before consent that are normally necessary. */
function idev_ccp_cookie_note($name) {
    if (preg_match('#^(wordpress_|wp-|wp_|PHPSESSID|woocommerce_|lang$|pll_language|idev_)#', $name)) return __('Usually necessary (site function)', 'idev-cookie-consent-pro');
    if (preg_match('#^(_ga|_gid|_gat|_fbp|_fbc|_hj|_clck|_clsk|_ttp|__utm)#', $name)) return __('Tracking cookie set before consent — check your server or caching setup', 'idev-cookie-consent-pro');
    return __('Unknown — check what sets it', 'idev-cookie-consent-pro');
}

function idev_ccp_tab_scanner() {
    $data = get_option('idev_ccp_scan', []);
    $cats = idev_ccp_cat_labels();
    echo '<p class="description">' . esc_html__('The scanner opens pages of this website like a first-time visitor who has not answered the banner yet, and lists the tracking scripts, pixels and embedded content it finds. Anything marked "Runs before consent" should be moved into Cookie consent → Categories & scripts, or marked to wait for consent.', 'idev-cookie-consent-pro') . '</p>';
    echo '<form method="post"><input type="hidden" name="idev_ccp_action" value="scan">' . wp_nonce_field('idev_ccp_scan', '_wpnonce', true, false) . '<p><button class="button button-primary">' . esc_html__('Scan now', 'idev-cookie-consent-pro') . '</button> <span class="description">' . esc_html(sprintf(/* translators: %d: number of pages */ __('Up to %d pages; it can take a minute.', 'idev-cookie-consent-pro'), 15)) . '</span></p></form>';
    if (!$data) { echo '<p>' . esc_html__('No scan yet.', 'idev-cookie-consent-pro') . '</p>'; return; }
    $sum = $data['summary'];
    echo '<div class="idev-stats"><div class="idev-stat"><strong>' . (int) $sum['pages'] . '</strong><span>' . esc_html__('Pages scanned', 'idev-cookie-consent-pro') . '</span></div><div class="idev-stat"><strong>' . (int) $sum['services'] . '</strong><span>' . esc_html__('Services found', 'idev-cookie-consent-pro') . '</span></div><div class="idev-stat' . ($sum['loose'] > 0 ? ' bad' : '') . '"><strong>' . esc_html($sum['loose'] < 0 ? '—' : (string) $sum['loose']) . '</strong><span>' . esc_html__('Run before consent', 'idev-cookie-consent-pro') . '</span></div></div>';
    echo '<p class="description">' . esc_html(sprintf(/* translators: %s: date and time */ __('Last scan: %s', 'idev-cookie-consent-pro'), idev_ccp_local($data['time']))) . '</p>';
    if ($sum['errors']) {
        echo '<div class="notice notice-warning inline"><p>' . esc_html__('Some pages could not be opened from the server (see the list below). Some hosts block a website from loading its own pages; ask your host to allow "loopback" requests.', 'idev-cookie-consent-pro') . '</p></div>';
    }
    echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Service', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Category', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Found on', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Status', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('What to do', 'idev-cookie-consent-pro') . '</th></tr></thead><tbody>';
    if (!$data['services']) echo '<tr><td colspan="5">' . esc_html__('No known tracking scripts or embeds found.', 'idev-cookie-consent-pro') . '</td></tr>';
    foreach ($data['services'] as $s) {
        $todo = !$s['loose'] ? '—' : (in_array('iframe', $s['kinds'], true) && $s['category'] === 'external'
            ? __('Use the iDev Maps block, or change the embed to <iframe data-idev-src="…" data-idev-category="external">.', 'idev-cookie-consent-pro')
            : __('Remove the code from the theme or other plugin and paste it into Cookie consent → Categories & scripts.', 'idev-cookie-consent-pro'));
        echo '<tr><td><b>' . esc_html($s['service']) . '</b><br><small class="idev-ccp-src">' . esc_html(mb_strimwidth($s['src'], 0, 70, '…')) . '</small></td><td>' . esc_html($cats[$s['category']] ?? $s['category']) . '</td><td>' . esc_html(sprintf(/* translators: %d: number of pages */ _n('%d page', '%d pages', $s['pages'], 'idev-cookie-consent-pro'), $s['pages'])) . '</td><td>' . ($s['loose'] ? '<span class="idev-ccp-bad">' . esc_html__('Runs before consent', 'idev-cookie-consent-pro') . '</span>' : '<span class="idev-ccp-ok">' . esc_html__('Waits for consent', 'idev-cookie-consent-pro') . '</span>') . '</td><td>' . esc_html($todo) . '</td></tr>';
    }
    echo '</tbody></table>';
    if ($data['cookies']) {
        echo '<h3>' . esc_html__('Cookies set by the server before consent', 'idev-cookie-consent-pro') . '</h3><table class="widefat striped"><tbody>';
        foreach ($data['cookies'] as $c => $n) echo '<tr><td><code>' . esc_html($c) . '</code></td><td>' . esc_html(idev_ccp_cookie_note($c)) . '</td></tr>';
        echo '</tbody></table>';
    }
    echo '<details><summary>' . esc_html__('Pages scanned', 'idev-cookie-consent-pro') . '</summary><ul>';
    foreach ($data['pages'] as $p) echo '<li>' . esc_html($p['url']) . ' — ' . ($p['error'] ? '<span class="idev-ccp-bad">' . esc_html($p['error']) . '</span>' : esc_html(sprintf(/* translators: %d: number of items */ __('%d items', 'idev-cookie-consent-pro'), $p['count']))) . '</li>';
    echo '</ul></details><p class="description">' . esc_html__('The scanner sees what the server sends. Scripts added later by other scripts (for example inside Google Tag Manager) are not listed; hold Tag Manager itself until consent.', 'idev-cookie-consent-pro') . '</p>';
}
