<?php
/**
 * Policy version archive: every time the banner text, categories or the privacy policy page change,
 * a snapshot is kept, so a consent record can always be shown with exactly what the visitor saw.
 */
defined('ABSPATH') || exit;

function idev_ccp_policy_snapshot() {
    $s = idev_cc_settings();
    $cats = [];
    foreach (idev_cc_categories() as $k => $c) $cats[$k] = ['label' => $c[0], 'desc' => $c[1]];
    $snap = [
        'version' => (string) $s['version'], 'title' => $s['title'], 'title_en' => $s['title_en'], 'text' => $s['text'], 'text_en' => $s['text_en'],
        'categories' => $cats, 'reject_style' => $s['reject_style'], 'layout' => $s['layout'], 'days' => (int) $s['days'],
        'policy_url' => idev_cc_policy_url(), 'policy_title' => '', 'policy_text' => '', 'policy_modified' => '',
    ];
    $page = (int) $s['policy_page'] ?: (int) get_option('wp_page_for_privacy_policy');
    if ($page && get_post_status($page) === 'publish') {
        $post = get_post($page);
        $snap['policy_title'] = get_the_title($post);
        $snap['policy_text'] = mb_substr(trim(preg_replace('/\n{3,}/', "\n\n", wp_strip_all_tags(strip_shortcodes($post->post_content)))), 0, 30000);
        $snap['policy_modified'] = $post->post_modified_gmt;
    }
    return $snap;
}
function idev_ccp_snapshot_hash($snap) {
    unset($snap['policy_modified']);
    return hash('sha256', wp_json_encode($snap, JSON_UNESCAPED_UNICODE));
}

/** Saves a snapshot when something changed. Returns the row id or 0. */
function idev_ccp_policy_record() {
    global $wpdb;
    $snap = idev_ccp_policy_snapshot();
    $hash = idev_ccp_snapshot_hash($snap);
    $last = $wpdb->get_var($wpdb->prepare('SELECT hash FROM %i ORDER BY id DESC LIMIT 1', idev_ccp_t('policies'))); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    if ($last === $hash) return 0;
    $wpdb->insert(idev_ccp_t('policies'), ['version' => $snap['version'], 'hash' => $hash, 'snapshot' => wp_json_encode($snap, JSON_UNESCAPED_UNICODE), 'user_id' => get_current_user_id(), 'created_at' => current_time('mysql', true)]); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    return (int) $wpdb->insert_id;
}
add_action('update_option_idev_cookie_consent', 'idev_ccp_policy_record', 20, 0);
add_action('add_option_idev_cookie_consent', 'idev_ccp_policy_record', 20, 0);
add_action('admin_init', function () {
    if (!get_option('idev_ccp_policy_init')) { idev_ccp_policy_record(); update_option('idev_ccp_policy_init', '1', false); }
});
add_action('save_post_page', function ($id) {
    $s = idev_cc_settings();
    $page = (int) $s['policy_page'] ?: (int) get_option('wp_page_for_privacy_policy');
    if ($page === (int) $id && !wp_is_post_revision($id)) idev_ccp_policy_record();
}, 30);

function idev_ccp_policies($limit = 100) {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare('SELECT * FROM %i ORDER BY id DESC LIMIT %d', idev_ccp_t('policies'), $limit), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}
/** The snapshot a visitor saw: same version, recorded before (or closest to) the consent time. */
function idev_ccp_policy_at($version, $gmt) {
    global $wpdb;
    $t = idev_ccp_t('policies');
    $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE version = %s AND created_at <= %s ORDER BY id DESC LIMIT 1', $t, $version, $gmt), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    if (!$row) $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE version = %s ORDER BY id ASC LIMIT 1', $t, $version), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    if ($row) $row['snap'] = json_decode($row['snapshot'], true) ?: [];
    return $row;
}

/** True when the text changed but the policy version number was not raised (visitors were not asked again). */
function idev_ccp_policy_warning() {
    $rows = idev_ccp_policies(2);
    return count($rows) === 2 && $rows[0]['version'] === $rows[1]['version'];
}

function idev_ccp_tab_policies() {
    $rows = idev_ccp_policies();
    if (idev_ccp_policy_warning()) echo '<div class="notice notice-warning inline"><p>' . esc_html__('The banner text or the privacy policy changed but the policy version stayed the same, so visitors who already answered were not asked again. If the change matters, raise the version in Cookie consent → General.', 'idev-cookie-consent-pro') . '</p></div>';
    echo '<p class="description">' . esc_html__('A copy is kept automatically whenever the banner text, the categories or the privacy policy page change. Consent receipts show the copy the visitor saw.', 'idev-cookie-consent-pro') . '</p>';
    echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Saved', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Policy version', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Fingerprint', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Content', 'idev-cookie-consent-pro') . '</th></tr></thead><tbody>';
    if (!$rows) echo '<tr><td colspan="4">—</td></tr>';
    foreach ($rows as $r) {
        $s = json_decode($r['snapshot'], true) ?: [];
        $u = get_userdata((int) $r['user_id']);
        echo '<tr><td>' . esc_html(idev_ccp_local($r['created_at'])) . ($u ? '<br><small>' . esc_html($u->display_name) . '</small>' : '') . '</td><td><b>' . esc_html($r['version']) . '</b></td><td><code>' . esc_html(substr($r['hash'], 0, 12)) . '</code></td><td><details><summary>' . esc_html($s['title'] ?? '') . '</summary>' . idev_ccp_snapshot_html($s) . '</details></td></tr>';
    }
    echo '</tbody></table>';
}

/** Readable snapshot (used on the admin page and in receipts). */
function idev_ccp_snapshot_html($s, $full = false) {
    $o = '<div class="idev-ccp-snap"><p><b>' . esc_html($s['title'] ?? '') . '</b><br>' . esc_html($s['text'] ?? '') . '</p>';
    if (!empty($s['title_en']) || !empty($s['text_en'])) $o .= '<p lang="en"><b>' . esc_html($s['title_en'] ?? '') . '</b><br>' . esc_html($s['text_en'] ?? '') . '</p>';
    if (!empty($s['categories'])) {
        $o .= '<ul>';
        foreach ($s['categories'] as $c) $o .= '<li><b>' . esc_html($c['label']) . '</b> — ' . esc_html($c['desc']) . '</li>';
        $o .= '</ul>';
    }
    if (!empty($s['policy_url'])) $o .= '<p>' . esc_html__('Privacy policy:', 'idev-cookie-consent-pro') . ' ' . esc_html($s['policy_url']) . (!empty($s['policy_modified']) ? ' (' . esc_html(sprintf(/* translators: %s: date */ __('updated %s', 'idev-cookie-consent-pro'), idev_ccp_local($s['policy_modified']))) . ')' : '') . '</p>';
    if ($full && !empty($s['policy_text'])) $o .= '<div class="idev-ccp-policytext">' . nl2br(esc_html($s['policy_text'])) . '</div>';
    return $o . '</div>';
}
