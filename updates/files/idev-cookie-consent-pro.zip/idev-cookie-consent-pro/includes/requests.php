<?php
/**
 * Data subject requests (PDPA sections 19, 30–36 / GDPR articles 7, 15–21): a public form,
 * a register with a reference number and a 30-day deadline, e-mails, and tools to act on a request.
 * Names, e-mail addresses, phone numbers and details are stored encrypted.
 */
defined('ABSPATH') || exit;

function idev_ccp_request_types() {
    return [
        'access' => __('See or get a copy of my data', 'idev-cookie-consent-pro'),
        'portability' => __('Send my data to me or another organisation in a common format', 'idev-cookie-consent-pro'),
        'correct' => __('Correct my data', 'idev-cookie-consent-pro'),
        'delete' => __('Delete my data', 'idev-cookie-consent-pro'),
        'object' => __('Object to the use of my data', 'idev-cookie-consent-pro'),
        'restrict' => __('Stop using my data for now', 'idev-cookie-consent-pro'),
        'withdraw' => __('Withdraw my consent', 'idev-cookie-consent-pro'),
        'other' => __('Other / ask a question', 'idev-cookie-consent-pro'),
    ];
}
function idev_ccp_request_types_on() {
    $on = array_filter(explode(',', idev_ccp_settings()['types']));
    return array_intersect_key(idev_ccp_request_types(), array_flip($on)) ?: idev_ccp_request_types();
}
function idev_ccp_statuses() {
    return ['new' => __('New', 'idev-cookie-consent-pro'), 'verifying' => __('Checking identity', 'idev-cookie-consent-pro'), 'progress' => __('In progress', 'idev-cookie-consent-pro'), 'done' => __('Completed', 'idev-cookie-consent-pro'), 'rejected' => __('Refused', 'idev-cookie-consent-pro')];
}
function idev_ccp_open_statuses() { return ['new', 'verifying', 'progress']; }

/* ---------- Data ---------- */

function idev_ccp_next_ref() {
    $key = 'idev_ccp_ref_' . wp_date('ym');
    $n = (int) get_option($key, 0) + 1;
    update_option($key, $n, false);
    return 'PR' . wp_date('ym') . '-' . str_pad((string) $n, 4, '0', STR_PAD_LEFT);
}

/** $in: type, name, email, phone, details, consent_id. Returns id or WP_Error. */
function idev_ccp_request_create($in, $source = 'form') {
    global $wpdb;
    $types = idev_ccp_request_types();
    $type = array_key_exists($in['type'] ?? '', $types) ? $in['type'] : '';
    $name = mb_substr(sanitize_text_field($in['name'] ?? ''), 0, 150);
    $email = sanitize_email($in['email'] ?? '');
    if ($type === '') return new WP_Error('type', __('Please choose what you would like us to do.', 'idev-cookie-consent-pro'));
    if ($name === '') return new WP_Error('name', __('Please enter your name.', 'idev-cookie-consent-pro'));
    if (!is_email($email)) return new WP_Error('email', __('Please enter a valid e-mail address.', 'idev-cookie-consent-pro'));
    $data = ['name' => $name, 'email' => $email, 'phone' => mb_substr(sanitize_text_field($in['phone'] ?? ''), 0, 40), 'details' => mb_substr(sanitize_textarea_field($in['details'] ?? ''), 0, 4000)];
    $ref = idev_ccp_next_ref();
    $now = idev_ccp_now();
    $due = wp_date('Y-m-d', time() + max(1, (int) idev_ccp_settings()['due_days']) * DAY_IN_SECONDS);
    $log = [['t' => current_time('mysql', true), 'u' => get_current_user_id(), 'a' => 'created', 'm' => $source]];
    $ok = $wpdb->insert(idev_ccp_t('requests'), [ // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        'ref' => $ref, 'type' => $type, 'status' => 'new', 'data' => idev_ccp_encrypt($data), 'email_hash' => idev_ccp_hash($email),
        'consent_id' => substr(preg_replace('/[^a-z0-9-]/', '', strtolower((string) ($in['consent_id'] ?? ''))), 0, 40),
        'due_date' => $due, 'ip_hash' => $source === 'form' ? idev_ccp_hash(sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? ''))) : '',
        'log' => idev_ccp_encrypt($log), 'created_at' => $now, 'updated_at' => $now,
    ]);
    if (!$ok) return new WP_Error('db', __('Could not save your request. Please try again or contact us by e-mail.', 'idev-cookie-consent-pro'));
    $id = (int) $wpdb->insert_id;
    idev_ccp_request_mails($id);
    do_action('idev_ccp_request_created', $id);
    return $id;
}

function idev_ccp_request($id) {
    global $wpdb;
    $r = $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id = %d', idev_ccp_t('requests'), $id), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    if (!$r) return null;
    $r['d'] = idev_ccp_decrypt($r['data']);
    $r['log_items'] = idev_ccp_decrypt($r['log']);
    $r['overdue'] = in_array($r['status'], idev_ccp_open_statuses(), true) && $r['due_date'] < wp_date('Y-m-d');
    return $r;
}
function idev_ccp_requests($status = '', $limit = 200) {
    global $wpdb;
    $t = idev_ccp_t('requests');
    if ($status === 'open') $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE status IN ('new','verifying','progress') ORDER BY due_date, id LIMIT %d", $t, $limit), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    elseif ($status !== '') $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE status = %s ORDER BY id DESC LIMIT %d', $t, $status, $limit), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    else $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM %i ORDER BY id DESC LIMIT %d', $t, $limit), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    foreach ($rows as &$r) { $r['d'] = idev_ccp_decrypt($r['data']); $r['overdue'] = in_array($r['status'], idev_ccp_open_statuses(), true) && $r['due_date'] < wp_date('Y-m-d'); }
    return $rows;
}
function idev_ccp_request_counts() {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare('SELECT status, COUNT(*) n, SUM(CASE WHEN due_date < %s THEN 1 ELSE 0 END) late FROM %i GROUP BY status', wp_date('Y-m-d'), idev_ccp_t('requests')), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    $out = ['open' => 0, 'late' => 0];
    foreach ($rows as $r) {
        $out[$r['status']] = (int) $r['n'];
        if (in_array($r['status'], idev_ccp_open_statuses(), true)) { $out['open'] += (int) $r['n']; $out['late'] += (int) $r['late']; }
    }
    return $out;
}
function idev_ccp_request_log($id, $action, $message = '') {
    global $wpdb;
    $r = idev_ccp_request($id);
    if (!$r) return;
    $log = $r['log_items'];
    $log[] = ['t' => current_time('mysql', true), 'u' => get_current_user_id(), 'a' => $action, 'm' => mb_substr((string) $message, 0, 4000)];
    $wpdb->update(idev_ccp_t('requests'), ['log' => idev_ccp_encrypt($log), 'updated_at' => idev_ccp_now()], ['id' => $id]); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}
function idev_ccp_request_status($id, $status, $note = '') {
    global $wpdb;
    if (!isset(idev_ccp_statuses()[$status])) return;
    $wpdb->update(idev_ccp_t('requests'), ['status' => $status, 'updated_at' => idev_ccp_now()], ['id' => $id]); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    idev_ccp_request_log($id, 'status:' . $status, $note);
}

/* ---------- E-mails ---------- */

function idev_ccp_request_mails($id) {
    $r = idev_ccp_request($id);
    if (!$r) return;
    $s = idev_ccp_settings();
    $types = idev_ccp_request_types();
    $site = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
    if (is_email($s['notify_email'])) {
        $body = implode("\n", [
            __('A new privacy request was received.', 'idev-cookie-consent-pro'), '',
            /* translators: %s: request type */
            sprintf(__('Request: %s', 'idev-cookie-consent-pro'), $types[$r['type']] ?? $r['type']),
            /* translators: %s: date */
            sprintf(__('Reply by: %s', 'idev-cookie-consent-pro'), idev_format_day($r['due_date'])), '',
            /* translators: %s: link */
            sprintf(__('Open it here (log in first): %s', 'idev-cookie-consent-pro'), idev_ccp_url('requests', ['id' => $id])),
        ]);
        /* translators: 1: reference number, 2: website name */
        wp_mail($s['notify_email'], sprintf(__('[%2$s] New privacy request %1$s', 'idev-cookie-consent-pro'), $r['ref'], $site), $body);
    }
    $headers = is_email($s['contact_email']) ? ['Reply-To: ' . $s['contact_email']] : [];
    $body = implode("\n", [
        /* translators: %s: name */
        sprintf(__('Dear %s,', 'idev-cookie-consent-pro'), $r['d']['name']), '',
        __('We have received your request.', 'idev-cookie-consent-pro'), '',
        /* translators: %s: reference number */
        sprintf(__('Reference: %s', 'idev-cookie-consent-pro'), $r['ref']),
        /* translators: %s: request type */
        sprintf(__('Request: %s', 'idev-cookie-consent-pro'), $types[$r['type']] ?? $r['type']),
        /* translators: %s: date */
        sprintf(__('We will reply by: %s', 'idev-cookie-consent-pro'), idev_format_day($r['due_date'])), '',
        /* translators: %s: e-mail address */
        sprintf(__('We may contact you to confirm your identity before we act on the request. If you did not send this request, please tell us at %s.', 'idev-cookie-consent-pro'), $s['contact_email']),
        '', $site,
    ]);
    /* translators: 1: reference number, 2: website name */
    wp_mail($r['d']['email'], sprintf(__('We received your request %1$s — %2$s', 'idev-cookie-consent-pro'), $r['ref'], $site), $body, $headers);
}

/* ---------- Public form ---------- */

function idev_ccp_form($atts = []) {
    $s = idev_ccp_settings();
    wp_enqueue_style('idev-ccp-form', plugins_url('assets/form.css', IDEV_CCP_FILE), [], IDEV_CCP_VERSION);
    wp_enqueue_script('idev-ccp-form', plugins_url('assets/form.js', IDEV_CCP_FILE), [], IDEV_CCP_VERSION, true);
    wp_localize_script('idev-ccp-form', 'IDEV_CCP', ['api' => esc_url_raw(rest_url('idev-ccp/v1/request')), 'cookie' => defined('IDEV_CC_COOKIE') ? IDEV_CC_COOKIE : 'idev_consent', 'error' => __('Sorry, something went wrong. Please try again.', 'idev-cookie-consent-pro'), 'sending' => __('Sending…', 'idev-cookie-consent-pro')]);
    $o = '<form class="idev-ccp-form" novalidate>';
    $intro = idev_pick($s['intro'], $s['intro_en']);
    if ($intro !== '') $o .= '<p class="idev-ccp-intro">' . esc_html($intro) . '</p>';
    $o .= '<fieldset><legend>' . esc_html__('What would you like us to do?', 'idev-cookie-consent-pro') . '</legend>';
    foreach (idev_ccp_request_types_on() as $k => $l) $o .= '<label class="idev-ccp-type"><input type="radio" name="type" value="' . esc_attr($k) . '" required> <span>' . esc_html($l) . '</span></label>';
    $o .= '</fieldset>';
    $o .= '<div class="idev-ccp-grid"><label>' . esc_html__('Full name', 'idev-cookie-consent-pro') . ' *<input name="name" autocomplete="name" required maxlength="150"></label>';
    $o .= '<label>' . esc_html__('E-mail', 'idev-cookie-consent-pro') . ' *<input type="email" name="email" autocomplete="email" required maxlength="190"></label>';
    $o .= '<label>' . esc_html__('Phone', 'idev-cookie-consent-pro') . '<input type="tel" name="phone" autocomplete="tel" maxlength="40"></label>';
    $o .= '<label>' . esc_html__('Cookie consent ID (filled in automatically)', 'idev-cookie-consent-pro') . '<input name="consent_id" maxlength="40" readonly></label></div>';
    $o .= '<label>' . esc_html__('Details', 'idev-cookie-consent-pro') . '<textarea name="details" rows="5" maxlength="4000" placeholder="' . esc_attr__('Which data, which service or visit, and anything that helps us find it.', 'idev-cookie-consent-pro') . '"></textarea></label>';
    $o .= '<p class="idev-ccp-hp" aria-hidden="true"><label>Website<input name="website" tabindex="-1" autocomplete="off"></label></p>';
    $notice = idev_pick($s['notice'], $s['notice_en']);
    $o .= '<label class="idev-ccp-agree"><input type="checkbox" name="agree" value="1" required> <span>' . esc_html__('The information above is correct and the request is about my own data (or I am allowed to act for the person).', 'idev-cookie-consent-pro') . '</span></label>';
    if ($notice !== '') $o .= '<p class="idev-ccp-notice">' . esc_html($notice) . '</p>';
    $o .= '<p><button type="submit">' . esc_html__('Send request', 'idev-cookie-consent-pro') . '</button></p><div class="idev-ccp-msg" role="status" aria-live="polite"></div></form>';
    return $o;
}
add_shortcode('idev_privacy_request', 'idev_ccp_form');
add_action('init', function () {
    idev_register_block('idev/privacy-request', __('Privacy request form', 'idev-cookie-consent-pro'), 'shield', __('Form for data subject requests (PDPA / GDPR).', 'idev-cookie-consent-pro'), [], function () { return idev_ccp_form(); });
});

add_action('rest_api_init', function () {
    register_rest_route('idev-ccp/v1', '/request', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => function (WP_REST_Request $r) {
        if (trim((string) $r->get_param('website')) !== '') return new WP_REST_Response(['ok' => true, 'ref' => ''], 200); // honeypot
        $ip = idev_ccp_hash(sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? '')));
        $key = 'idev_ccp_rl_' . substr($ip, 0, 20);
        $n = (int) get_transient($key);
        if ($n >= 5) return new WP_REST_Response(['ok' => false, 'error' => __('Too many requests from your network. Please try again later or e-mail us.', 'idev-cookie-consent-pro')], 429);
        if (!$r->get_param('agree')) return new WP_REST_Response(['ok' => false, 'error' => __('Please confirm that the information is correct.', 'idev-cookie-consent-pro')], 400);
        $id = idev_ccp_request_create(['type' => (string) $r->get_param('type'), 'name' => (string) $r->get_param('name'), 'email' => (string) $r->get_param('email'), 'phone' => (string) $r->get_param('phone'), 'details' => (string) $r->get_param('details'), 'consent_id' => (string) $r->get_param('consent_id')]);
        if (is_wp_error($id)) return new WP_REST_Response(['ok' => false, 'error' => $id->get_error_message()], 400);
        set_transient($key, $n + 1, HOUR_IN_SECONDS);
        $req = idev_ccp_request($id);
        /* translators: 1: reference number, 2: date */
        return new WP_REST_Response(['ok' => true, 'ref' => $req['ref'], 'message' => sprintf(__('Thank you. Your reference number is %1$s. We have sent a confirmation to your e-mail and will reply by %2$s.', 'idev-cookie-consent-pro'), $req['ref'], idev_format_day($req['due_date']))], 200);
    }]);
});
