<?php
/** Consent receipts (one consent ID) and evidence reports (a period), printable or as CSV. */
defined('ABSPATH') || exit;

function idev_ccp_consents_by_id($cid) {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE consent_id = %s ORDER BY id', idev_cc_table(), $cid), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}

function idev_ccp_print_url($what, $args = []) {
    return add_query_arg(array_merge(['action' => 'idev_ccp_print', 'what' => $what, '_wpnonce' => wp_create_nonce('idev_ccp_print')], $args), admin_url('admin-post.php'));
}

add_action('admin_post_idev_ccp_print', function () {
    if (!current_user_can('manage_options') || !wp_verify_nonce(sanitize_key($_GET['_wpnonce'] ?? ''), 'idev_ccp_print')) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-cookie-consent-pro'), 403);
    $what = sanitize_key($_GET['what'] ?? '');
    nocache_headers();
    if ($what === 'receipt') {
        $cid = preg_replace('/[^a-z0-9-]/', '', strtolower(sanitize_text_field(wp_unslash($_GET['cid'] ?? ''))));
        idev_ccp_print_page(__('Consent receipt', 'idev-cookie-consent-pro'), idev_ccp_receipt_html($cid));
    }
    [$from, $to] = idev_ccp_period();
    if ($what === 'report_csv') { idev_ccp_report_csv($from, $to); exit; }
    idev_ccp_print_page(__('Cookie consent report', 'idev-cookie-consent-pro'), idev_ccp_report_html($from, $to));
});

function idev_ccp_period() {
    $from = idev_is_valid_date(sanitize_text_field(wp_unslash($_GET['from'] ?? ''))) ? sanitize_text_field(wp_unslash($_GET['from'])) : wp_date('Y-m-01', strtotime('-2 months')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $to = idev_is_valid_date(sanitize_text_field(wp_unslash($_GET['to'] ?? ''))) ? sanitize_text_field(wp_unslash($_GET['to'])) : wp_date('Y-m-d'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    return [$from, $to];
}

function idev_ccp_print_page($title, $body, $preview = false) {
    if ($preview) ob_start();
    $trial = idev_ccp_licensed() ? '' : '<div class="trial">' . esc_html__('TRIAL — not activated', 'idev-cookie-consent-pro') . '</div>';
    echo '<!doctype html><html lang="' . esc_attr(idev_lang()) . '"><head><meta charset="utf-8"><title>' . esc_html($title) . '</title><style>
@page{size:A4;margin:14mm}*{box-sizing:border-box}
body{margin:0;font:13px/1.55 Tahoma,"Leelawadee UI","Sarabun","Noto Sans Thai",Arial,sans-serif;color:#111;background:#eef0f3}
.bar{position:sticky;top:0;display:flex;justify-content:center;gap:8px;padding:10px;background:#1d2327}
.bar button{font:bold 13px Tahoma,sans-serif;color:#fff;background:#00a32a;border:0;border-radius:6px;padding:8px 16px;cursor:pointer}
.sheet{background:#fff;width:210mm;min-height:297mm;margin:16px auto;padding:16mm;box-shadow:0 2px 12px rgba(0,0,0,.15);position:relative}
h1{font-size:20px;margin:0 0 4px}h2{font-size:15px;margin:22px 0 8px;border-bottom:1px solid #111;padding-bottom:3px}
.sub{color:#444;margin:0 0 14px}
table{width:100%;border-collapse:collapse;margin:6px 0}th,td{border:1px solid #999;padding:5px 6px;text-align:left;vertical-align:top}th{background:#f3f4f6}
.kv td:first-child{width:34%;background:#fafafa;font-weight:bold}
.r{text-align:right}.mono{font-family:Consolas,monospace;font-size:12px;word-break:break-all}
.idev-ccp-snap{border:1px solid #ccc;border-radius:6px;padding:8px 12px;background:#fcfcfc}.idev-ccp-snap ul{margin:6px 0 0 18px;padding:0}
.idev-ccp-policytext{margin-top:8px;font-size:12px;max-height:none;border-top:1px dashed #bbb;padding-top:8px}
.ok{color:#047857;font-weight:bold}.bad{color:#b91c1c;font-weight:bold}
.foot{margin-top:24px;font-size:11.5px;color:#555;border-top:1px solid #ccc;padding-top:8px}
.sign{display:grid;grid-template-columns:1fr 1fr;gap:40px;margin-top:36px;text-align:center}.sign div{border-top:1px dotted #111;padding-top:4px}
.trial{border:2px solid #111;text-align:center;font-weight:bold;letter-spacing:.08em;padding:4px;margin-bottom:10px}
.sheet:has(.trial)::after{content:"TRIAL";position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:bold 120px sans-serif;color:rgba(0,0,0,.07);transform:rotate(-30deg);pointer-events:none}
@media print{body{background:#fff}.bar{display:none}.sheet{margin:0;box-shadow:none;width:auto;min-height:0;padding:0}}
' . (function_exists('idev_doc_css') ? idev_doc_css(idev_ccp_doc_design()) : '') . '
</style></head><body>' . ($preview ? '' : '<div class="bar"><button onclick="window.print()">' . esc_html__('Print / Save as PDF', 'idev-cookie-consent-pro') . '</button></div>') . '<div class="sheet">' . $trial . wp_kses_post($body) . (function_exists('idev_doc_signatures') ? idev_doc_signatures(idev_ccp_doc_design()) . idev_doc_footer(idev_ccp_doc_design()) : '') . '</div></body></html>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static CSS
    if ($preview) return ob_get_clean();
    exit;
}

function idev_ccp_doc_design() { return function_exists('idev_doc_design') ? idev_doc_design('idev_ccp_doc_design') : []; }
function idev_ccp_doc_head($title, $sub) {
    $s = idev_ccp_settings();
    if (function_exists('idev_doc_header')) return idev_doc_header(idev_ccp_doc_design(), ['name' => $s['controller'] ?: get_bloginfo('name'), 'line' => home_url('/'), 'meta' => '<p class="sub">' . esc_html($sub) . '</p>'], $title);
    return '<h1>' . esc_html($title) . '</h1><p class="sub">' . esc_html($s['controller'] ?: get_bloginfo('name')) . ' · ' . esc_html(home_url('/')) . '<br>' . esc_html($sub) . '</p>';
}

function idev_ccp_receipt_html($cid) {
    $rows = $cid !== '' ? idev_ccp_consents_by_id($cid) : [];
    $choices = idev_ccp_choice_labels();
    $o = idev_ccp_doc_head(__('Cookie consent receipt', 'idev-cookie-consent-pro'), sprintf(/* translators: %s: date and time */ __('Made %s from the consent log of this website', 'idev-cookie-consent-pro'), wp_date('Y-m-d H:i')));
    $o .= '<table class="kv"><tr><td>' . esc_html__('Consent ID', 'idev-cookie-consent-pro') . '</td><td class="mono">' . esc_html($cid ?: '—') . '</td></tr>';
    $o .= '<tr><td>' . esc_html__('Records', 'idev-cookie-consent-pro') . '</td><td>' . (int) count($rows) . '</td></tr>';
    if ($rows) {
        $last = end($rows);
        $o .= '<tr><td>' . esc_html__('Current choice', 'idev-cookie-consent-pro') . '</td><td><b>' . esc_html($choices[$last['choice']] ?? $last['choice']) . '</b> — ' . esc_html(idev_ccp_cats_text($last['categories'])) . '</td></tr>';
        $o .= '<tr><td>' . esc_html__('Last answer', 'idev-cookie-consent-pro') . '</td><td>' . esc_html(idev_ccp_local($last['created_at'])) . '</td></tr>';
    }
    $o .= '</table>';
    if (!$rows) return $o . '<p class="bad">' . esc_html__('No consent records were found for this ID. It may be mistyped, the visitor may never have answered, or the records may have been removed after the retention period.', 'idev-cookie-consent-pro') . '</p>';
    $o .= '<h2>' . esc_html__('Answers given', 'idev-cookie-consent-pro') . '</h2><table><thead><tr><th>#</th><th>' . esc_html__('Date and time', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Choice', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Categories allowed', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Policy version', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Page', 'idev-cookie-consent-pro') . '</th></tr></thead><tbody>';
    foreach ($rows as $i => $r) $o .= '<tr><td>' . ($i + 1) . '</td><td>' . esc_html(idev_ccp_local($r['created_at'])) . '</td><td>' . esc_html($choices[$r['choice']] ?? $r['choice']) . '</td><td>' . esc_html(idev_ccp_cats_text($r['categories'])) . '</td><td>' . esc_html($r['policy_version']) . '</td><td class="mono">' . esc_html(wp_parse_url($r['page'], PHP_URL_PATH) ?: '/') . '</td></tr>';
    $o .= '</tbody></table>';
    $o .= '<h2>' . esc_html__('Technical details', 'idev-cookie-consent-pro') . '</h2><table class="kv"><tr><td>' . esc_html__('Browser', 'idev-cookie-consent-pro') . '</td><td class="mono">' . esc_html($last['user_agent']) . '</td></tr><tr><td>' . esc_html__('IP address (one-way hash)', 'idev-cookie-consent-pro') . '</td><td class="mono">' . esc_html($last['ip_hash']) . '</td></tr></table>';
    $seen = [];
    foreach ($rows as $r) {
        if (isset($seen[$r['policy_version']])) continue;
        $seen[$r['policy_version']] = true;
        $p = idev_ccp_policy_at($r['policy_version'], $r['created_at']);
        $o .= '<h2>' . esc_html(sprintf(/* translators: %s: version */ __('What the visitor was shown (policy version %s)', 'idev-cookie-consent-pro'), $r['policy_version'])) . '</h2>';
        $o .= $p ? idev_ccp_snapshot_html($p['snap'], true) . '<p class="mono">' . esc_html__('Fingerprint', 'idev-cookie-consent-pro') . ' SHA-256 ' . esc_html($p['hash']) . '</p>' : '<p>' . esc_html__('No copy of this version was kept (it is older than iDev Cookie Consent Pro on this site).', 'idev-cookie-consent-pro') . '</p>';
    }
    $o .= '<p class="foot">' . esc_html__('The consent ID is a random code kept in the visitor\'s browser (cookie "idev_consent"). The IP address is not stored; only a one-way hash made with this website\'s secret key, which can confirm a match but cannot be turned back into the address. Times are in the website\'s time zone.', 'idev-cookie-consent-pro') . '</p>';
    $o .= '<div class="sign"><div>' . esc_html__('Prepared by', 'idev-cookie-consent-pro') . '</div><div>' . esc_html__('Data protection officer', 'idev-cookie-consent-pro') . '</div></div>';
    return $o;
}

/** Numbers for a period: [by choice, by month, category rates, versions]. */
function idev_ccp_report_data($from, $to) {
    global $wpdb;
    $t = idev_cc_table();
    $a = get_gmt_from_date($from . ' 00:00:00'); $b = get_gmt_from_date($to . ' 23:59:59');
    // phpcs:disable WordPress.DB.DirectDatabaseQuery
    $by = $wpdb->get_results($wpdb->prepare('SELECT choice, COUNT(*) n FROM %i WHERE created_at BETWEEN %s AND %s GROUP BY choice', $t, $a, $b), OBJECT_K);
    $months = $wpdb->get_results($wpdb->prepare("SELECT substr(created_at,1,7) m, SUM(CASE WHEN choice='accept' THEN 1 ELSE 0 END) acc, SUM(CASE WHEN choice='reject' THEN 1 ELSE 0 END) rej, SUM(CASE WHEN choice='custom' THEN 1 ELSE 0 END) cus, COUNT(*) n FROM %i WHERE created_at BETWEEN %s AND %s GROUP BY substr(created_at,1,7) ORDER BY m", $t, $a, $b), ARRAY_A);
    $total = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE created_at BETWEEN %s AND %s', $t, $a, $b));
    $cats = [];
    foreach (['analytics', 'external', 'marketing'] as $c) $cats[$c] = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE created_at BETWEEN %s AND %s AND categories LIKE %s', $t, $a, $b, '%' . $wpdb->esc_like($c) . '%'));
    $versions = $wpdb->get_results($wpdb->prepare('SELECT policy_version v, COUNT(*) n, MIN(created_at) first, MAX(created_at) last FROM %i WHERE created_at BETWEEN %s AND %s GROUP BY policy_version ORDER BY first', $t, $a, $b), ARRAY_A);
    $people = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(DISTINCT consent_id) FROM %i WHERE created_at BETWEEN %s AND %s', $t, $a, $b));
    // phpcs:enable
    return compact('by', 'months', 'total', 'cats', 'versions', 'people');
}

/** Settings that regulators look at, with pass / check. */
function idev_ccp_checklist() {
    $s = idev_cc_settings();
    $scan = get_option('idev_ccp_scan', []);
    $loose = (int) ($scan['summary']['loose'] ?? -1);
    return [
        [__('Banner is on', 'idev-cookie-consent-pro'), $s['enabled'] === '1'],
        [__('Reject is as easy to see as Accept', 'idev-cookie-consent-pro'), $s['reject_style'] === 'equal'],
        [__('Visitors can choose categories', 'idev-cookie-consent-pro'), $s['show_settings'] === '1'],
        [__('Visitors can change their mind later (cookie settings button)', 'idev-cookie-consent-pro'), $s['reopen'] === '1'],
        [__('Consent is logged as evidence', 'idev-cookie-consent-pro'), $s['log'] === '1'],
        [__('A privacy policy is linked', 'idev-cookie-consent-pro'), idev_cc_policy_url() !== ''],
        [$loose < 0 ? __('Cookie scan not run yet', 'idev-cookie-consent-pro') : sprintf(/* translators: %d: number of services */ _n('Last scan: %d service loads before consent', 'Last scan: %d services load before consent', $loose, 'idev-cookie-consent-pro'), $loose), $loose === 0],
    ];
}

function idev_ccp_report_html($from, $to) {
    $d = idev_ccp_report_data($from, $to);
    $choices = idev_ccp_choice_labels();
    $pct = function ($n) use ($d) { return $d['total'] ? round($n * 100 / $d['total'], 1) . '%' : '—'; };
    $o = idev_ccp_doc_head(__('Cookie consent report', 'idev-cookie-consent-pro'), sprintf(/* translators: 1: from date, 2: to date */ __('Period %1$s – %2$s', 'idev-cookie-consent-pro'), idev_format_day($from), idev_format_day($to)));
    $o .= '<h2>' . esc_html__('Summary', 'idev-cookie-consent-pro') . '</h2><table class="kv"><tr><td>' . esc_html__('Answers recorded', 'idev-cookie-consent-pro') . '</td><td>' . esc_html(number_format_i18n($d['total'])) . '</td></tr><tr><td>' . esc_html__('Different visitors (consent IDs)', 'idev-cookie-consent-pro') . '</td><td>' . esc_html(number_format_i18n($d['people'])) . '</td></tr>';
    foreach ($choices as $k => $l) { $n = (int) ($d['by'][$k]->n ?? 0); $o .= '<tr><td>' . esc_html($l) . '</td><td>' . esc_html(number_format_i18n($n) . ' (' . $pct($n) . ')') . '</td></tr>'; }
    $o .= '</table><h2>' . esc_html__('Categories allowed', 'idev-cookie-consent-pro') . '</h2><table><thead><tr><th>' . esc_html__('Category', 'idev-cookie-consent-pro') . '</th><th class="r">' . esc_html__('Answers', 'idev-cookie-consent-pro') . '</th><th class="r">%</th></tr></thead><tbody>';
    $cl = idev_ccp_cat_labels();
    foreach ($d['cats'] as $c => $n) $o .= '<tr><td>' . esc_html($cl[$c]) . '</td><td class="r">' . esc_html(number_format_i18n($n)) . '</td><td class="r">' . esc_html($pct($n)) . '</td></tr>';
    $o .= '</tbody></table><h2>' . esc_html__('By month', 'idev-cookie-consent-pro') . '</h2><table><thead><tr><th>' . esc_html__('Month', 'idev-cookie-consent-pro') . '</th><th class="r">' . esc_html($choices['accept']) . '</th><th class="r">' . esc_html($choices['reject']) . '</th><th class="r">' . esc_html($choices['custom']) . '</th><th class="r">' . esc_html__('Total', 'idev-cookie-consent-pro') . '</th></tr></thead><tbody>';
    foreach ($d['months'] as $m) $o .= '<tr><td>' . esc_html(idev_format_month($m['m'] . '-01')) . '</td><td class="r">' . (int) $m['acc'] . '</td><td class="r">' . (int) $m['rej'] . '</td><td class="r">' . (int) $m['cus'] . '</td><td class="r">' . (int) $m['n'] . '</td></tr>';
    if (!$d['months']) $o .= '<tr><td colspan="5">—</td></tr>';
    $o .= '</tbody></table><h2>' . esc_html__('Policy versions in use', 'idev-cookie-consent-pro') . '</h2><table><thead><tr><th>' . esc_html__('Version', 'idev-cookie-consent-pro') . '</th><th class="r">' . esc_html__('Answers', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('First', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Last', 'idev-cookie-consent-pro') . '</th></tr></thead><tbody>';
    foreach ($d['versions'] as $v) $o .= '<tr><td>' . esc_html($v['v']) . '</td><td class="r">' . (int) $v['n'] . '</td><td>' . esc_html(idev_ccp_local($v['first'])) . '</td><td>' . esc_html(idev_ccp_local($v['last'])) . '</td></tr>';
    if (!$d['versions']) $o .= '<tr><td colspan="4">—</td></tr>';
    $o .= '</tbody></table><h2>' . esc_html__('Settings check', 'idev-cookie-consent-pro') . '</h2><table>';
    foreach (idev_ccp_checklist() as [$l, $ok]) $o .= '<tr><td>' . esc_html($l) . '</td><td class="' . ($ok ? 'ok' : 'bad') . '">' . ($ok ? '✓ ' . esc_html__('Yes', 'idev-cookie-consent-pro') : '✗ ' . esc_html__('Check', 'idev-cookie-consent-pro')) . '</td></tr>';
    $o .= '</table>';
    $rc = idev_ccp_request_counts();
    $o .= '<h2>' . esc_html__('Privacy requests', 'idev-cookie-consent-pro') . '</h2><table class="kv"><tr><td>' . esc_html__('Open', 'idev-cookie-consent-pro') . '</td><td>' . (int) $rc['open'] . '</td></tr><tr><td>' . esc_html__('Past the reply date', 'idev-cookie-consent-pro') . '</td><td' . ($rc['late'] ? ' class="bad"' : '') . '>' . (int) $rc['late'] . '</td></tr><tr><td>' . esc_html__('Completed', 'idev-cookie-consent-pro') . '</td><td>' . (int) ($rc['done'] ?? 0) . '</td></tr></table>';
    $o .= '<p class="foot">' . esc_html__('This report summarises the consent log kept by iDev Cookie Consent. It supports, but does not replace, your own data protection records.', 'idev-cookie-consent-pro') . '</p>';
    return $o;
}

function idev_ccp_report_csv($from, $to) {
    $d = idev_ccp_report_data($from, $to);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="consent-report-' . $from . '-' . $to . '.csv"');
    $out = fopen('php://output', 'w'); // phpcs:ignore WordPress.WP.AlternativeFunctions
    fwrite($out, "\xEF\xBB\xBF"); // phpcs:ignore WordPress.WP.AlternativeFunctions
    fputcsv($out, ['month', 'accepted_all', 'rejected', 'chose_categories', 'total']);
    foreach ($d['months'] as $m) fputcsv($out, [$m['m'], $m['acc'], $m['rej'], $m['cus'], $m['n']]);
    fclose($out); // phpcs:ignore WordPress.WP.AlternativeFunctions
}

add_action('init', function () {
    if (!function_exists('idev_register_doc_designer')) return;
    idev_register_doc_designer('ccp', [
        'option' => 'idev_ccp_doc_design', 'docs' => ['receipt' => __('Consent receipt', 'idev-cookie-consent-pro'), 'report' => __('Cookie consent report', 'idev-cookie-consent-pro')],
        'preview' => function ($doc, $design) {
            add_filter('pre_option_idev_ccp_doc_design', function () use ($design) { return $design; });
            if ($doc === 'report') { [$from, $to] = idev_ccp_period(); return idev_ccp_print_page(__('Cookie consent report', 'idev-cookie-consent-pro'), idev_ccp_report_html($from, $to), true); }
            global $wpdb;
            $cid = (string) $wpdb->get_var($wpdb->prepare('SELECT consent_id FROM %i ORDER BY id DESC LIMIT 1', idev_cc_table())); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            return idev_ccp_print_page(__('Consent receipt', 'idev-cookie-consent-pro'), idev_ccp_receipt_html($cid), true);
        },
    ]);
}, 30);
