<?php
/** Tables, settings, encryption and small helpers. */
defined('ABSPATH') || exit;

function idev_ccp_t($name) { global $wpdb; return $wpdb->prefix . 'idev_ccp_' . $name; }

function idev_ccp_install() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $c = $wpdb->get_charset_collate();
    dbDelta('CREATE TABLE ' . idev_ccp_t('policies') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  version varchar(20) NOT NULL,
  hash char(64) NOT NULL,
  snapshot longtext NOT NULL,
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY version (version)
) $c;");
    dbDelta('CREATE TABLE ' . idev_ccp_t('requests') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  ref varchar(30) NOT NULL,
  type varchar(20) NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'new',
  data longtext NOT NULL,
  email_hash char(64) NOT NULL DEFAULT '',
  consent_id varchar(40) NOT NULL DEFAULT '',
  due_date date NOT NULL,
  ip_hash char(64) NOT NULL DEFAULT '',
  log longtext NOT NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY ref (ref),
  KEY status (status),
  KEY email_hash (email_hash)
) $c;");
    update_option('idev_ccp_db', IDEV_CCP_VERSION, false);
}
add_action('plugins_loaded', function () { if (get_option('idev_ccp_db') !== IDEV_CCP_VERSION) idev_ccp_install(); }, 21);

add_action('init', function () {
    load_plugin_textdomain('idev-cookie-consent-pro', false, dirname(plugin_basename(IDEV_CCP_FILE)) . '/languages');
});

/* ---------- Settings ---------- */

function idev_ccp_defaults() {
    return [
        'contact_email' => get_option('admin_email'), 'notify_email' => get_option('admin_email'), 'controller' => get_bloginfo('name'),
        'due_days' => '30', 'retention' => '36',
        'types' => 'access,portability,correct,delete,object,restrict,withdraw,other',
        'intro' => 'ท่านสามารถใช้สิทธิของเจ้าของข้อมูลส่วนบุคคลตามพระราชบัญญัติคุ้มครองข้อมูลส่วนบุคคล พ.ศ. 2562 ได้ผ่านแบบฟอร์มนี้ เราจะตอบกลับภายใน 30 วัน และอาจขอเอกสารยืนยันตัวตนก่อนดำเนินการ',
        'intro_en' => 'You can use your rights as a data subject under Thailand\'s Personal Data Protection Act (and the GDPR) with this form. We will reply within 30 days and may ask you to confirm your identity first.',
        'notice' => 'เราใช้ข้อมูลในแบบฟอร์มนี้เพื่อดำเนินการตามคำขอของท่านเท่านั้น และเก็บไว้เป็นหลักฐานตามกฎหมาย',
        'notice_en' => 'We use the information in this form only to handle your request and keep it as a legal record.',
        'scan_urls' => '',
    ];
}
function idev_ccp_settings() { $s = get_option('idev_ccp_settings', []); return array_merge(idev_ccp_defaults(), is_array($s) ? $s : []); }

/* ---------- Encryption (request details are personal data) ---------- */

function idev_ccp_key() { return hash('sha256', 'idev-ccp|' . wp_salt('auth') . '|' . wp_salt('secure_auth'), true); }
function idev_ccp_encrypt($data) {
    $plain = wp_json_encode($data, JSON_UNESCAPED_UNICODE);
    $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
    return 'c1:' . base64_encode($nonce . sodium_crypto_secretbox($plain, $nonce, idev_ccp_key()));
}
function idev_ccp_decrypt($cipher) {
    if (strpos((string) $cipher, 'c1:') !== 0) return [];
    $raw = base64_decode(substr($cipher, 3), true);
    if ($raw === false || strlen($raw) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) return [];
    $p = sodium_crypto_secretbox_open(substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), idev_ccp_key());
    $d = $p === false ? null : json_decode($p, true);
    return is_array($d) ? $d : [];
}
function idev_ccp_hash($value) { return hash_hmac('sha256', strtolower(trim((string) $value)), wp_salt('auth')); }

/* ---------- Helpers ---------- */

function idev_ccp_now() { return current_time('mysql'); }
function idev_ccp_url($tab = 'requests', $args = []) { return add_query_arg(array_merge(['page' => 'idev-ccp', 'tab' => $tab], $args), admin_url('admin.php')); }
function idev_ccp_local($gmt) { return get_date_from_gmt($gmt, 'Y-m-d H:i'); }
function idev_ccp_choice_labels() {
    return ['accept' => __('Accepted all', 'idev-cookie-consent-pro'), 'reject' => __('Rejected', 'idev-cookie-consent-pro'), 'custom' => __('Chose categories', 'idev-cookie-consent-pro')];
}
function idev_ccp_cat_labels() {
    $out = ['necessary' => __('Necessary', 'idev-cookie-consent-pro'), 'analytics' => __('Statistics', 'idev-cookie-consent-pro'), 'external' => __('External media', 'idev-cookie-consent-pro'), 'marketing' => __('Marketing', 'idev-cookie-consent-pro')];
    return $out;
}
function idev_ccp_cats_text($csv) {
    $l = idev_ccp_cat_labels();
    return implode(', ', array_map(function ($c) use ($l) { return $l[$c] ?? $c; }, array_filter(explode(',', (string) $csv))));
}

/** Flash message after a redirect. */
function idev_ccp_redirect($url, $msg = '', $type = 'success') {
    if ($msg !== '') set_transient('idev_ccp_flash_' . get_current_user_id(), [$msg, $type], 60);
    wp_safe_redirect($url);
    exit;
}
function idev_ccp_flash() {
    $f = get_transient('idev_ccp_flash_' . get_current_user_id());
    if (!$f) return;
    delete_transient('idev_ccp_flash_' . get_current_user_id());
    echo '<div class="notice notice-' . esc_attr($f[1]) . ' is-dismissible"><p>' . esc_html($f[0]) . '</p></div>';
}
