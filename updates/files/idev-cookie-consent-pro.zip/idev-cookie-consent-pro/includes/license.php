<?php
/** Licence: without a key everything works, printed reports and receipts carry "TRIAL". */
defined('ABSPATH') || exit;

add_action('init', function () {
    idev_register_license('cc_pro', [
        'name' => 'iDev Cookie Consent Pro', 'plugin' => 'idev-cookie-consent-pro',
        'free' => __('Trial: everything works; printed reports and consent receipts say "TRIAL".', 'idev-cookie-consent-pro'),
        'pro' => __('Lifetime licence for one website.', 'idev-cookie-consent-pro'),
        'price' => '1,900 ' . __('THB', 'idev-cookie-consent-pro'),
        'usage' => function () { return esc_html(idev_ccp_licensed() ? __('Licensed', 'idev-cookie-consent-pro') : __('Trial', 'idev-cookie-consent-pro')); },
    ]);
    idev_register_plugin('idev-cookie-consent-pro', ['name' => 'iDev Cookie Consent Pro', 'version' => IDEV_CCP_VERSION, 'description' => __('Privacy requests, consent receipts, evidence reports, policy versions and cookie scanner.', 'idev-cookie-consent-pro'), 'settings' => admin_url('admin.php?page=idev-ccp'), 'docs' => 'https://idevapp.me/plugins/idev-cookie-consent/#pro']);
}, 5);
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_CCP_FILE, admin_url('admin.php?page=idev-ccp'), 'https://idevapp.me/plugins/idev-cookie-consent/#pro'); }, 25);

function idev_ccp_licensed() { return function_exists('idev_is_licensed') && idev_is_licensed('cc_pro'); }
function idev_ccp_trial_banner() {
    if (idev_ccp_licensed() || !current_user_can('manage_options')) return '';
    return idev_license_upsell('cc_pro', esc_html__('Trial: every feature works, but printed reports and consent receipts say "TRIAL". Enter your licence key to remove it.', 'idev-cookie-consent-pro'));
}
