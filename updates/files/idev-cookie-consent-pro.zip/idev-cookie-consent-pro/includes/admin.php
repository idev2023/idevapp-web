<?php
/** Admin: iDevApp → Privacy (Pro) with tabs Requests / Reports / Policy versions / Cookie scanner / Settings. */
defined('ABSPATH') || exit;

add_action('admin_menu', function () {
    $c = idev_ccp_request_counts();
    $badge = $c['open'] ? ' <span class="awaiting-mod">' . (int) $c['open'] . '</span>' : '';
    add_submenu_page('idevapp', __('Privacy (Pro)', 'idev-cookie-consent-pro'), __('Privacy (Pro)', 'idev-cookie-consent-pro') . $badge, 'manage_options', 'idev-ccp', 'idev_ccp_page');
}, 21);

add_action('admin_enqueue_scripts', function ($hook) {
    if (strpos((string) $hook, 'idev-ccp') === false) return;
    wp_add_inline_style('idev-admin', '.idev-ccp-bad{color:#b32d2e;font-weight:600}.idev-ccp-ok{color:#008a20;font-weight:600}.idev-stat.bad strong{color:#b32d2e}.idev-ccp-src{color:#646970;word-break:break-all}.idev-ccp-late td:first-child{box-shadow:inset 4px 0 #d63638}.idev-ccp-grid{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);gap:16px;align-items:start}@media(max-width:1100px){.idev-ccp-grid{grid-template-columns:1fr}}.idev-ccp-log{margin:0;padding:0;list-style:none}.idev-ccp-log li{border-left:3px solid #c3c4c7;padding:4px 10px;margin:0 0 8px}.idev-ccp-log small{color:#646970}.idev-ccp-snap{background:#f6f7f7;border-radius:8px;padding:8px 12px}.idev-ccp-kv th{width:32%;text-align:left}.idev-ccp-filter{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:10px 0}');
});

/* ---------- Form posts (before output, then redirect) ---------- */

add_action('admin_init', function () {
    if (sanitize_key($_GET['page'] ?? '') !== 'idev-ccp' || ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || empty($_POST['idev_ccp_action'])) return; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked per action below
    if (!current_user_can('manage_options')) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-cookie-consent-pro'), 403);
    $action = sanitize_key($_POST['idev_ccp_action']); // phpcs:ignore WordPress.Security.NonceVerification.Missing
    check_admin_referer('idev_ccp_' . $action);
    $id = (int) ($_POST['id'] ?? 0);
    switch ($action) {
        case 'scan':
            $d = idev_ccp_scan_run();
            /* translators: 1: services found, 2: pages */
            idev_ccp_redirect(idev_ccp_url('scanner'), sprintf(__('Scan finished: %1$d services found on %2$d pages.', 'idev-cookie-consent-pro'), $d['summary']['services'], $d['summary']['pages']));
            // no break: redirect exits
        case 'settings':
            $in = (array) wp_unslash($_POST['idev_ccp'] ?? []); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per field
            $s = idev_settings_sanitize(idev_ccp_setting_fields(), $in, idev_ccp_settings());
            $s['types'] = implode(',', array_intersect(array_keys(idev_ccp_request_types()), array_map('sanitize_key', (array) ($_POST['idev_ccp_types'] ?? []))));
            $s['scan_urls'] = implode("\n", array_filter(array_map('esc_url_raw', preg_split('/\s+/', (string) ($in['scan_urls'] ?? '')))));
            update_option('idev_ccp_settings', $s, false);
            idev_ccp_redirect(idev_ccp_url('settings'), __('Saved.', 'idev-cookie-consent-pro'));
            // no break
        case 'status':
            idev_ccp_request_status($id, sanitize_key($_POST['status'] ?? ''), sanitize_textarea_field(wp_unslash($_POST['note'] ?? '')));
            idev_ccp_redirect(idev_ccp_url('requests', ['id' => $id]), __('Saved.', 'idev-cookie-consent-pro'));
            // no break
        case 'reply':
            $r = idev_ccp_request($id);
            $subject = sanitize_text_field(wp_unslash($_POST['subject'] ?? ''));
            $body = sanitize_textarea_field(wp_unslash($_POST['body'] ?? ''));
            if (!$r || $subject === '' || $body === '') idev_ccp_redirect(idev_ccp_url('requests', ['id' => $id]), __('Please write a subject and a message.', 'idev-cookie-consent-pro'), 'error');
            $s = idev_ccp_settings();
            $sent = wp_mail($r['d']['email'], $subject, $body, is_email($s['contact_email']) ? ['Reply-To: ' . $s['contact_email']] : []);
            idev_ccp_request_log($id, $sent ? 'mail' : 'mail_failed', $subject . "\n\n" . $body);
            idev_ccp_redirect(idev_ccp_url('requests', ['id' => $id]), $sent ? __('E-mail sent.', 'idev-cookie-consent-pro') : __('The e-mail could not be sent. Check the website\'s e-mail settings.', 'idev-cookie-consent-pro'), $sent ? 'success' : 'error');
            // no break
        case 'wprequest':
            $r = idev_ccp_request($id);
            $kind = ($_POST['kind'] ?? '') === 'remove' ? 'remove_personal_data' : 'export_personal_data';
            $res = $r ? wp_create_user_request($r['d']['email'], $kind) : new WP_Error('x', 'Not found');
            if (!is_wp_error($res)) { wp_send_user_request($res); idev_ccp_request_log($id, 'wp_request', $kind); }
            idev_ccp_redirect(idev_ccp_url('requests', ['id' => $id]), is_wp_error($res) ? $res->get_error_message() : __('WordPress sent the person a confirmation e-mail. After they confirm, finish it in Tools → Export / Erase Personal Data.', 'idev-cookie-consent-pro'), is_wp_error($res) ? 'error' : 'success');
            // no break
        case 'erase_consent':
            global $wpdb;
            $r = idev_ccp_request($id);
            $n = $r && $r['consent_id'] !== '' ? (int) $wpdb->query($wpdb->prepare('DELETE FROM %i WHERE consent_id = %s', idev_cc_table(), $r['consent_id'])) : 0; // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            /* translators: %d: number of records */
            idev_ccp_request_log($id, 'erase_consent', sprintf(__('%d consent records deleted', 'idev-cookie-consent-pro'), $n));
            /* translators: %d: number of records */
            idev_ccp_redirect(idev_ccp_url('requests', ['id' => $id]), sprintf(__('%d consent records deleted.', 'idev-cookie-consent-pro'), $n));
            // no break
        case 'manual':
            $nid = idev_ccp_request_create(['type' => sanitize_key($_POST['type'] ?? ''), 'name' => sanitize_text_field(wp_unslash($_POST['name'] ?? '')), 'email' => sanitize_email(wp_unslash($_POST['email'] ?? '')), 'phone' => sanitize_text_field(wp_unslash($_POST['phone'] ?? '')), 'details' => sanitize_textarea_field(wp_unslash($_POST['details'] ?? '')), 'consent_id' => sanitize_text_field(wp_unslash($_POST['consent_id'] ?? ''))], 'staff');
            if (is_wp_error($nid)) idev_ccp_redirect(idev_ccp_url('requests', ['new' => 1]), $nid->get_error_message(), 'error');
            idev_ccp_redirect(idev_ccp_url('requests', ['id' => $nid]), __('Request added.', 'idev-cookie-consent-pro'));
            // no break
        case 'delete':
            global $wpdb;
            $wpdb->delete(idev_ccp_t('requests'), ['id' => $id]); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            idev_ccp_redirect(idev_ccp_url('requests'), __('Request deleted.', 'idev-cookie-consent-pro'));
    }
});

add_action('admin_post_idev_ccp_export', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idev_ccp_export')) wp_die('Forbidden', 403);
    $types = idev_ccp_request_types(); $st = idev_ccp_statuses();
    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="privacy-requests-' . wp_date('Ymd') . '.csv"');
    $out = fopen('php://output', 'w'); // phpcs:ignore WordPress.WP.AlternativeFunctions
    fwrite($out, "\xEF\xBB\xBF"); // phpcs:ignore WordPress.WP.AlternativeFunctions
    fputcsv($out, ['ref', 'received', 'type', 'status', 'reply_by', 'last_update', 'name', 'email', 'phone']);
    foreach (idev_ccp_requests('', 5000) as $r) fputcsv($out, array_map(function ($v) { return preg_match('/^[=+\-@\t\r]/', (string) $v) ? "'" . $v : $v; }, [$r['ref'], $r['created_at'], $types[$r['type']] ?? $r['type'], $st[$r['status']] ?? $r['status'], $r['due_date'], $r['updated_at'], $r['d']['name'] ?? '', $r['d']['email'] ?? '', $r['d']['phone'] ?? '']));
    fclose($out); // phpcs:ignore WordPress.WP.AlternativeFunctions
    exit;
});

/* ---------- Page ---------- */

function idev_ccp_page() {
    $tabs = ['requests' => __('Privacy requests', 'idev-cookie-consent-pro'), 'reports' => __('Reports & receipts', 'idev-cookie-consent-pro'), 'policies' => __('Policy versions', 'idev-cookie-consent-pro'), 'scanner' => __('Cookie scanner', 'idev-cookie-consent-pro'), 'settings' => __('Settings', 'idev-cookie-consent-pro')];
    $tab = sanitize_key($_GET['tab'] ?? 'requests'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $tabs['docs'] = __('Print design', 'idev-cookie-consent-pro');
    if (!isset($tabs[$tab])) $tab = 'requests';
    idev_page_open(__('Privacy (Pro)', 'idev-cookie-consent-pro'), __('Privacy requests, consent evidence and cookie checks', 'idev-cookie-consent-pro'), ['tabs' => $tabs, 'current' => $tab, 'url' => 'idev_ccp_url',
        'chip' => idev_ccp_licensed() ? [__('Licensed', 'idev-cookie-consent-pro'), 'ok'] : [__('Trial', 'idev-cookie-consent-pro'), 'trial'],
        'icons' => ['requests' => 'mail', 'reports' => 'chart', 'policies' => 'file', 'scanner' => 'search', 'settings' => 'gear', 'docs' => 'palette']]);
    idev_ccp_flash();
    echo wp_kses_post(idev_ccp_trial_banner());
    if ($tab === 'docs') { if (isset($_GET['saved'])) echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Saved.', 'idev-cookie-consent-pro') . '</p></div>'; idev_doc_designer_ui('ccp', idev_ccp_url('docs')); echo '</div>'; return; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    call_user_func('idev_ccp_tab_' . $tab);
    echo '</div>';
}

function idev_ccp_form_open($action, $extra = '') {
    return '<form method="post" action="' . esc_url(idev_ccp_url(sanitize_key($_GET['tab'] ?? 'requests'))) . '" ' . $extra . '><input type="hidden" name="idev_ccp_action" value="' . esc_attr($action) . '">' . wp_nonce_field('idev_ccp_' . $action, '_wpnonce', true, false); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
}
function idev_ccp_kses_admin() {
    $a = ['class' => true, 'id' => true, 'name' => true, 'value' => true, 'type' => true, 'method' => true, 'action' => true, 'rows' => true, 'placeholder' => true, 'required' => true, 'selected' => true, 'checked' => true, 'href' => true, 'target' => true, 'style' => true, 'onclick' => true, 'colspan' => true, 'open' => true, 'size' => true];
    $t = [];
    foreach (['form', 'input', 'select', 'option', 'textarea', 'button', 'label', 'p', 'div', 'span', 'a', 'b', 'small', 'br', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'h2', 'h3', 'details', 'summary', 'ul', 'li', 'code', 'strong'] as $tag) $t[$tag] = $a;
    return $t;
}

function idev_ccp_tab_requests() {
    $id = (int) ($_GET['id'] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if ($id) { idev_ccp_request_view($id); return; }
    if (!empty($_GET['new'])) { idev_ccp_request_new(); return; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $filter = sanitize_key($_GET['status'] ?? 'open'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $counts = idev_ccp_request_counts();
    $types = idev_ccp_request_types(); $st = idev_ccp_statuses();
    echo '<div class="idev-ccp-filter">';
    $links = ['open' => __('Open', 'idev-cookie-consent-pro') . ' (' . $counts['open'] . ')'] + array_map(function ($l) { return $l; }, $st) + ['' => __('All', 'idev-cookie-consent-pro')];
    foreach ($links as $k => $l) echo '<a class="button' . (($filter === 'all' ? '' : $filter) === $k ? ' button-primary' : '') . '" href="' . esc_url(idev_ccp_url('requests', ['status' => $k === '' ? 'all' : $k])) . '">' . esc_html($l . (isset($st[$k]) && !empty($counts[$k]) ? ' (' . $counts[$k] . ')' : '')) . '</a>';
    echo ' <a class="button" href="' . esc_url(idev_ccp_url('requests', ['new' => 1])) . '">＋ ' . esc_html__('Add a request received by phone, letter or e-mail', 'idev-cookie-consent-pro') . '</a> <a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=idev_ccp_export'), 'idev_ccp_export')) . '">' . esc_html__('Download register (CSV)', 'idev-cookie-consent-pro') . '</a></div>';
    if ($counts['late']) echo '<div class="notice notice-error inline"><p>' . esc_html(sprintf(/* translators: %d: number of requests */ _n('%d request is past its reply date.', '%d requests are past their reply date.', $counts['late'], 'idev-cookie-consent-pro'), $counts['late'])) . '</p></div>';
    $rows = idev_ccp_requests($filter === 'all' ? '' : $filter);
    echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Reference', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Received', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Request', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Name', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Reply by', 'idev-cookie-consent-pro') . '</th><th>' . esc_html__('Status', 'idev-cookie-consent-pro') . '</th></tr></thead><tbody>';
    if (!$rows) echo '<tr><td colspan="6">' . esc_html__('No requests.', 'idev-cookie-consent-pro') . ' ' . esc_html__('Add the form to a page with the "Privacy request form" block or [idev_privacy_request].', 'idev-cookie-consent-pro') . '</td></tr>';
    foreach ($rows as $r) echo '<tr' . ($r['overdue'] ? ' class="idev-ccp-late"' : '') . '><td><a href="' . esc_url(idev_ccp_url('requests', ['id' => $r['id']])) . '"><b>' . esc_html($r['ref']) . '</b></a></td><td>' . esc_html(substr($r['created_at'], 0, 16)) . '</td><td>' . esc_html($types[$r['type']] ?? $r['type']) . '</td><td>' . esc_html($r['d']['name'] ?? '') . '<br><small>' . esc_html($r['d']['email'] ?? '') . '</small></td><td>' . ($r['overdue'] ? '<span class="idev-ccp-bad">' : '<span>') . esc_html(idev_format_day($r['due_date'])) . '</span></td><td>' . esc_html($st[$r['status']] ?? $r['status']) . '</td></tr>';
    echo '</tbody></table>';
}

function idev_ccp_request_new() {
    echo '<p><a href="' . esc_url(idev_ccp_url('requests')) . '">← ' . esc_html__('Privacy requests', 'idev-cookie-consent-pro') . '</a></p><div class="idev-card">' . idev_ccp_form_open('manual') . '<table class="form-table"><tr><th>' . esc_html__('Request', 'idev-cookie-consent-pro') . '</th><td><select name="type">';
    foreach (idev_ccp_request_types() as $k => $l) echo '<option value="' . esc_attr($k) . '">' . esc_html($l) . '</option>';
    echo '</select></td></tr>';
    foreach (['name' => __('Full name', 'idev-cookie-consent-pro'), 'email' => __('E-mail', 'idev-cookie-consent-pro'), 'phone' => __('Phone', 'idev-cookie-consent-pro'), 'consent_id' => __('Cookie consent ID', 'idev-cookie-consent-pro')] as $k => $l) echo '<tr><th>' . esc_html($l) . '</th><td><input name="' . esc_attr($k) . '" class="regular-text"' . ($k === 'name' || $k === 'email' ? ' required' : '') . '></td></tr>';
    echo '<tr><th>' . esc_html__('Details', 'idev-cookie-consent-pro') . '</th><td><textarea name="details" rows="4" class="large-text"></textarea></td></tr></table><p><button class="button button-primary">' . esc_html__('Add request', 'idev-cookie-consent-pro') . '</button></p></form></div>';
}

function idev_ccp_request_view($id) {
    $r = idev_ccp_request($id);
    if (!$r) { echo '<p>' . esc_html__('Request not found.', 'idev-cookie-consent-pro') . '</p>'; return; }
    $types = idev_ccp_request_types(); $st = idev_ccp_statuses(); $d = $r['d'];
    echo '<p><a href="' . esc_url(idev_ccp_url('requests')) . '">← ' . esc_html__('Privacy requests', 'idev-cookie-consent-pro') . '</a></p><div class="idev-ccp-grid"><div>';
    echo '<div class="idev-card"><h2>' . esc_html($r['ref'] . ' · ' . ($types[$r['type']] ?? $r['type'])) . '</h2><table class="widefat idev-ccp-kv"><tbody>';
    $rows = [__('Status', 'idev-cookie-consent-pro') => $st[$r['status']] ?? $r['status'], __('Received', 'idev-cookie-consent-pro') => substr($r['created_at'], 0, 16), __('Reply by', 'idev-cookie-consent-pro') => idev_format_day($r['due_date']) . ($r['overdue'] ? ' — ' . __('late', 'idev-cookie-consent-pro') : ''), __('Name', 'idev-cookie-consent-pro') => $d['name'] ?? '', __('E-mail', 'idev-cookie-consent-pro') => $d['email'] ?? '', __('Phone', 'idev-cookie-consent-pro') => $d['phone'] ?? '', __('Cookie consent ID', 'idev-cookie-consent-pro') => $r['consent_id'] ?: '—'];
    foreach ($rows as $k => $v) echo '<tr><th>' . esc_html($k) . '</th><td>' . esc_html($v) . '</td></tr>';
    echo '<tr><th>' . esc_html__('Details', 'idev-cookie-consent-pro') . '</th><td>' . nl2br(esc_html($d['details'] ?? '')) . '</td></tr></tbody></table></div>';
    // consent records
    if ($r['consent_id'] !== '') {
        $cons = idev_ccp_consents_by_id($r['consent_id']);
        echo '<div class="idev-card"><h3>' . esc_html__('Cookie consent records for this ID', 'idev-cookie-consent-pro') . '</h3>';
        if (!$cons) echo '<p>' . esc_html__('None found.', 'idev-cookie-consent-pro') . '</p>';
        else {
            echo '<ul>';
            foreach ($cons as $c) echo '<li>' . esc_html(idev_ccp_local($c['created_at']) . ' · ' . (idev_ccp_choice_labels()[$c['choice']] ?? $c['choice']) . ' · ' . idev_ccp_cats_text($c['categories'])) . '</li>';
            echo '</ul><p><a class="button" target="_blank" href="' . esc_url(idev_ccp_print_url('receipt', ['cid' => $r['consent_id']])) . '">🖨 ' . esc_html__('Consent receipt', 'idev-cookie-consent-pro') . '</a></p>';
            echo idev_ccp_form_open('erase_consent', 'onsubmit="return confirm(\'' . esc_js(__('Delete these consent records? This cannot be undone.', 'idev-cookie-consent-pro')) . '\')"') . '<input type="hidden" name="id" value="' . (int) $id . '"><p><button class="button">' . esc_html__('Delete these consent records', 'idev-cookie-consent-pro') . '</button></p></form>';
        }
        echo '</div>';
    }
    echo '<div class="idev-card"><h3>' . esc_html__('Reply by e-mail', 'idev-cookie-consent-pro') . '</h3>' . idev_ccp_form_open('reply') . '<input type="hidden" name="id" value="' . (int) $id . '"><p><input name="subject" class="large-text" value="' . esc_attr(sprintf(/* translators: %s: reference number */ __('Your request %s', 'idev-cookie-consent-pro'), $r['ref'])) . '"></p><p><textarea name="body" rows="6" class="large-text" placeholder="' . esc_attr__('Message to the person', 'idev-cookie-consent-pro') . '"></textarea></p><p><button class="button button-primary">' . esc_html__('Send e-mail', 'idev-cookie-consent-pro') . '</button></p></form></div>';
    echo '</div><div>';
    echo '<div class="idev-card"><h3>' . esc_html__('Status', 'idev-cookie-consent-pro') . '</h3>' . idev_ccp_form_open('status') . '<input type="hidden" name="id" value="' . (int) $id . '"><p><select name="status">';
    foreach ($st as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($r['status'], $k, false) . '>' . esc_html($l) . '</option>';
    echo '</select></p><p><textarea name="note" rows="3" class="large-text" placeholder="' . esc_attr__('Note (what was checked or done, e.g. identity confirmed with ID card)', 'idev-cookie-consent-pro') . '"></textarea></p><p><button class="button button-primary">' . esc_html__('Save', 'idev-cookie-consent-pro') . '</button></p></form></div>';
    if (in_array($r['type'], ['access', 'portability', 'delete'], true)) {
        echo '<div class="idev-card"><h3>' . esc_html__('WordPress personal data tools', 'idev-cookie-consent-pro') . '</h3><p class="description">' . esc_html__('For data kept in WordPress (comments, user account, forms of other plugins), WordPress can e-mail the person a confirmation link, then export or erase their data.', 'idev-cookie-consent-pro') . '</p>' . idev_ccp_form_open('wprequest') . '<input type="hidden" name="id" value="' . (int) $id . '"><input type="hidden" name="kind" value="' . ($r['type'] === 'delete' ? 'remove' : 'export') . '"><p><button class="button">' . esc_html($r['type'] === 'delete' ? __('Start a WordPress erase request', 'idev-cookie-consent-pro') : __('Start a WordPress export request', 'idev-cookie-consent-pro')) . '</button></p></form></div>';
    }
    echo '<div class="idev-card"><h3>' . esc_html__('History', 'idev-cookie-consent-pro') . '</h3><ul class="idev-ccp-log">';
    foreach (array_reverse($r['log_items']) as $l) {
        $u = get_userdata((int) $l['u']);
        $what = strpos($l['a'], 'status:') === 0 ? sprintf(/* translators: %s: status */ __('Status → %s', 'idev-cookie-consent-pro'), $st[substr($l['a'], 7)] ?? substr($l['a'], 7)) : ([
            'created' => $l['m'] === 'staff' ? __('Added by staff', 'idev-cookie-consent-pro') : __('Received from the website form', 'idev-cookie-consent-pro'),
            'mail' => __('E-mail sent', 'idev-cookie-consent-pro'), 'mail_failed' => __('E-mail failed', 'idev-cookie-consent-pro'),
            'wp_request' => __('WordPress personal data request started', 'idev-cookie-consent-pro'), 'erase_consent' => __('Consent records deleted', 'idev-cookie-consent-pro'),
        ][$l['a']] ?? $l['a']);
        $msg = in_array($l['a'], ['created', 'wp_request'], true) ? '' : $l['m'];
        echo '<li><b>' . esc_html($what) . '</b><br><small>' . esc_html(idev_ccp_local($l['t']) . ($u ? ' · ' . $u->display_name : '')) . '</small>' . ($msg !== '' ? '<br>' . nl2br(esc_html($msg)) : '') . '</li>';
    }
    echo '</ul></div>';
    echo '<details><summary>' . esc_html__('Delete this request', 'idev-cookie-consent-pro') . '</summary>' . idev_ccp_form_open('delete', 'onsubmit="return confirm(\'' . esc_js(__('Delete this request and its history?', 'idev-cookie-consent-pro')) . '\')"') . '<input type="hidden" name="id" value="' . (int) $id . '"><p class="description">' . esc_html__('Keep requests as evidence for as long as your policy says (often 1–3 years) before deleting.', 'idev-cookie-consent-pro') . '</p><p><button class="button">' . esc_html__('Delete', 'idev-cookie-consent-pro') . '</button></p></form></details>';
    echo '</div></div>';
}

function idev_ccp_tab_reports() {
    [$from, $to] = idev_ccp_period();
    echo '<div class="idev-ccp-grid"><div class="idev-card"><h2>' . esc_html__('Evidence report', 'idev-cookie-consent-pro') . '</h2><p class="description">' . esc_html__('Totals of accept / reject / choose, categories, policy versions and a settings check, for an audit or your data protection records.', 'idev-cookie-consent-pro') . '</p>';
    echo '<form method="get" action="' . esc_url(admin_url('admin-post.php')) . '" target="_blank"><input type="hidden" name="action" value="idev_ccp_print"><input type="hidden" name="what" value="report"><input type="hidden" name="_wpnonce" value="' . esc_attr(wp_create_nonce('idev_ccp_print')) . '"><p><input type="date" name="from" value="' . esc_attr($from) . '"> – <input type="date" name="to" value="' . esc_attr($to) . '"></p><p><button class="button button-primary">🖨 ' . esc_html__('Open report', 'idev-cookie-consent-pro') . '</button> <button class="button" name="what" value="report_csv">' . esc_html__('CSV', 'idev-cookie-consent-pro') . '</button></p></form>';
    echo '<h3>' . esc_html__('Settings check', 'idev-cookie-consent-pro') . '</h3><ul>';
    foreach (idev_ccp_checklist() as [$l, $ok]) echo '<li>' . ($ok ? '<span class="idev-ccp-ok">✓</span> ' : '<span class="idev-ccp-bad">✗</span> ') . esc_html($l) . '</li>';
    echo '</ul></div><div class="idev-card"><h2>' . esc_html__('Consent receipt', 'idev-cookie-consent-pro') . '</h2><p class="description">' . esc_html__('When a visitor asks what they agreed to, enter their consent ID (shown in the privacy request, or in their browser\'s "idev_consent" cookie between the | signs).', 'idev-cookie-consent-pro') . '</p>';
    echo '<form method="get" action="' . esc_url(admin_url('admin-post.php')) . '" target="_blank"><input type="hidden" name="action" value="idev_ccp_print"><input type="hidden" name="what" value="receipt"><input type="hidden" name="_wpnonce" value="' . esc_attr(wp_create_nonce('idev_ccp_print')) . '"><p><input name="cid" class="regular-text" placeholder="' . esc_attr__('Consent ID', 'idev-cookie-consent-pro') . '" required></p><p><button class="button button-primary">🖨 ' . esc_html__('Make receipt', 'idev-cookie-consent-pro') . '</button></p></form></div></div>';
}

function idev_ccp_setting_fields() {
    return [
        ['controller', __('Data controller (organisation name)', 'idev-cookie-consent-pro'), 'text', __('Printed on reports and receipts.', 'idev-cookie-consent-pro')],
        ['contact_email', __('Privacy contact e-mail', 'idev-cookie-consent-pro'), 'email', __('Shown to people who send a request; replies go here.', 'idev-cookie-consent-pro')],
        ['notify_email', __('Notify about new requests', 'idev-cookie-consent-pro'), 'email'],
        ['due_days', __('Reply within (days)', 'idev-cookie-consent-pro'), 'number', __('PDPA: within 30 days of receiving the request.', 'idev-cookie-consent-pro'), [1, 90]],
        ['retention', __('Keep consent records for (months)', 'idev-cookie-consent-pro'), 'number', __('Older records are deleted automatically every day.', 'idev-cookie-consent-pro'), [1, 120]],
        ['intro', __('Form introduction (Thai)', 'idev-cookie-consent-pro'), 'textarea'], ['intro_en', __('Form introduction (English)', 'idev-cookie-consent-pro'), 'textarea'],
        ['notice', __('Privacy notice under the form (Thai)', 'idev-cookie-consent-pro'), 'textarea'], ['notice_en', __('Privacy notice under the form (English)', 'idev-cookie-consent-pro'), 'textarea'],
        ['scan_urls', __('Extra pages to scan', 'idev-cookie-consent-pro'), 'textarea', __('One address per line, e.g. your booking or contact page.', 'idev-cookie-consent-pro')],
    ];
}
function idev_ccp_tab_settings() {
    $s = idev_ccp_settings();
    echo idev_ccp_form_open('settings');
    idev_settings_table('idev_ccp', idev_ccp_setting_fields(), $s);
    $on = explode(',', $s['types']);
    echo '<table class="form-table"><tr><th>' . esc_html__('Requests people can choose', 'idev-cookie-consent-pro') . '</th><td>';
    foreach (idev_ccp_request_types() as $k => $l) echo '<label style="display:block"><input type="checkbox" name="idev_ccp_types[]" value="' . esc_attr($k) . '"' . checked(in_array($k, $on, true), true, false) . '> ' . esc_html($l) . '</label>';
    echo '</td></tr></table>';
    submit_button();
    echo '</form><div class="idev-card"><h3>' . esc_html__('Request form on your website', 'idev-cookie-consent-pro') . '</h3><p>' . esc_html__('Add the "Privacy request form" block to a page (e.g. "Your privacy rights"), or the shortcode', 'idev-cookie-consent-pro') . ' <code>[idev_privacy_request]</code>. ' . esc_html__('Link to it from your privacy policy.', 'idev-cookie-consent-pro') . '</p></div>';
}

/* Retention of the free plugin's consent log. */
add_filter('idev_cc_log_months', function () { return max(1, (int) idev_ccp_settings()['retention']); });
