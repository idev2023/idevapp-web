=== iDev Cookie Consent Pro ===
Contributors: idevapp2023
Tags: pdpa, gdpr, privacy, data subject request, cookie scanner
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add-on for iDev Cookie Consent: privacy request form and register, consent receipts, evidence reports, policy versions and a cookie scanner.

== Description ==

Needs the free plugin **iDev Cookie Consent**.

* **Privacy requests (PDPA sections 30–36 / GDPR articles 15–21):** form block / [idev_privacy_request], reference number, confirmation e-mail, register with a 30-day reply date, status, notes, e-mail replies, history, CSV. Names and e-mail addresses are stored encrypted.
* **Consent receipts:** everything recorded for one consent ID, with the exact banner text and privacy policy the visitor saw. Print or save as PDF.
* **Evidence report:** accept / reject / choose by month, categories, policy versions, settings check and open requests.
* **Policy versions:** a copy of the banner text, categories and privacy policy page is kept every time they change.
* **Cookie scanner:** opens your pages like a first-time visitor and lists tracking scripts, pixels and embeds that run before consent.
* **Retention:** choose how long consent records are kept.

Licence: 1,900 THB, lifetime, one website. Without a key everything works and printed documents say "TRIAL".

== Changelog ==

= 1.1.2 =
* Dates show the Buddhist year (พ.ศ.) and Thai month names on Thai pages, and the Gregorian year on English pages, everywhere WordPress formats a date.

= 1.0.0 =
* First release.
