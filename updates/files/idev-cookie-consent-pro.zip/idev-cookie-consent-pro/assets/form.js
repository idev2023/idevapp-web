/* iDev Cookie Consent Pro — privacy request form. */
(function () {
  'use strict';
  var C = window.IDEV_CCP || {};
  document.querySelectorAll('.idev-ccp-form').forEach(function (form) {
    var m = document.cookie.match(new RegExp('(?:^|; )' + (C.cookie || 'idev_consent') + '=([^;]*)'));
    if (m) { var parts = decodeURIComponent(m[1]).split('|'); if (parts[1]) form.elements.consent_id.value = parts[1]; }
    var msg = form.querySelector('.idev-ccp-msg'), btn = form.querySelector('button[type=submit]');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!form.reportValidity()) return;
      var data = {};
      Array.prototype.forEach.call(form.elements, function (el) {
        if (!el.name) return;
        if (el.type === 'radio') { if (el.checked) data[el.name] = el.value; return; }
        if (el.type === 'checkbox') { data[el.name] = el.checked ? 1 : 0; return; }
        data[el.name] = el.value;
      });
      btn.disabled = true; var label = btn.textContent; btn.textContent = C.sending || '…';
      msg.className = 'idev-ccp-msg'; msg.textContent = '';
      fetch(C.api, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data), credentials: 'omit' })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          if (j && j.ok) {
            form.querySelectorAll('fieldset, .idev-ccp-grid, label, .idev-ccp-notice, p:not(.idev-ccp-intro)').forEach(function (el) { if (!el.contains(msg)) el.hidden = true; });
            msg.className = 'idev-ccp-msg ok'; msg.textContent = j.message || '';
          } else { msg.className = 'idev-ccp-msg err'; msg.textContent = (j && j.error) || C.error; btn.disabled = false; btn.textContent = label; }
        })
        .catch(function () { msg.className = 'idev-ccp-msg err'; msg.textContent = C.error; btn.disabled = false; btn.textContent = label; });
    });
  });
})();
