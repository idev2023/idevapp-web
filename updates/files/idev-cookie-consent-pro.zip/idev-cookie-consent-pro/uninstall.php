<?php
defined('WP_UNINSTALL_PLUGIN') || exit;
// Privacy requests and policy copies are evidence: they are kept unless the site owner opts in to delete them.
if (!apply_filters('idev_ccp_uninstall_delete_data', false)) return;
global $wpdb;
foreach (['requests', 'policies'] as $t) $wpdb->query($wpdb->prepare('DROP TABLE IF EXISTS %i', $wpdb->prefix . 'idev_ccp_' . $t)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
foreach (['idev_ccp_settings', 'idev_ccp_db', 'idev_ccp_scan', 'idev_ccp_policy_init'] as $o) delete_option($o);
