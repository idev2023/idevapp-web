=== iDev News Ticker ===
Contributors: idevapp2023
Donate link: https://idevapp.me/
Tags: ticker, announcement bar, notice
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Static or scrolling announcement bars at the top of the site with start/end time, link and colours.

== Description ==

Static or scrolling announcement bars at the top of the site with start/end time, link and colours.

= Features =

* Static, slow, normal or fast scrolling
* Pauses on hover; respects reduced motion
* Automatic placement or shortcode [idev_ticker]

Thai and English interface. Works with any theme. Part of the iDevApp plugin suite for hospitals and clinics — all iDev plugins appear under the **iDevApp** menu.

== Installation ==

1. Plugins → Add New → Upload Plugin, choose the zip, Install, Activate.
2. Open **iDevApp** in the admin menu for settings.

== Changelog ==

= 1.0.0 =
* First release.
