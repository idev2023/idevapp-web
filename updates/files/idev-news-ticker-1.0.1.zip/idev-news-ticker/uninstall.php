<?php
defined('WP_UNINSTALL_PLUGIN') || exit;
delete_option('idev_news_ticker');
