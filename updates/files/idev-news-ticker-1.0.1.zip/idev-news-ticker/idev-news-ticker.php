<?php
/**
 * Plugin Name:       iDev News Ticker
 * Plugin URI:        https://idevapp.me/plugins/idev-news-ticker
 * Description:       Announcement bars at the top of the site: static or scrolling (slow / normal / fast), with start/end time, link and your colours. Pauses on hover and respects "reduce motion". Thai / English.
 * Version:           1.0.1
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-news-ticker
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// Loaded once: the same plugin may also be inside an iDevApp package (I-Clinic / I-Drug) or a Pro version.
if (defined('IDEV_NT_VERSION')) return;

define('IDEV_NT_VERSION', '1.0.1');
define('IDEV_NT_FILE', __FILE__);
require_once __DIR__ . '/common/idev-common.php';
require_once __DIR__ . '/includes/ticker.php';
register_activation_hook(__FILE__, 'idev_nt_migrate');
