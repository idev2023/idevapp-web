<?php
defined('ABSPATH') || exit;

function idev_nt_settings() {
    $s = get_option('idev_news_ticker', []);
    return array_merge(['placement' => 'auto', 'bg' => '#e9234d', 'text' => '#ffffff', 'tag_bg' => '#bd1337', 'max_width' => '1240'], is_array($s) ? $s : []);
}
function idev_nt_meta($id, $k) { return (string) get_post_meta($id, "_idev_{$k}", true); }

add_action('init', function () {
    load_plugin_textdomain('idev-news-ticker', false, dirname(plugin_basename(IDEV_NT_FILE)) . '/languages');
    register_post_type('idev_ticker', [
        'labels' => ['name' => __('Announcement bars', 'idev-news-ticker'), 'singular_name' => __('Announcement', 'idev-news-ticker'), 'add_new' => __('Add announcement', 'idev-news-ticker'), 'add_new_item' => __('Add announcement', 'idev-news-ticker'), 'edit_item' => __('Edit announcement', 'idev-news-ticker'), 'all_items' => __('Announcement bars', 'idev-news-ticker'), 'not_found' => __('No announcements yet', 'idev-news-ticker')],
        'public' => false, 'show_ui' => true, 'show_in_menu' => 'idevapp', 'supports' => ['title'], 'map_meta_cap' => true,
    ]);
    idev_register_plugin('idev-news-ticker', ['name' => 'iDev News Ticker', 'version' => IDEV_NT_VERSION, 'description' => __('Static or scrolling announcement bars.', 'idev-news-ticker'), 'settings' => admin_url('edit.php?post_type=idev_ticker'), 'docs' => 'https://idevapp.me/plugins/idev-news-ticker']);
});
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_NT_FILE, admin_url('admin.php?page=idev-nt-settings'), 'https://idevapp.me/plugins/idev-news-ticker'); });

add_filter('enter_title_here', function ($t, $post) { return $post->post_type === 'idev_ticker' ? __('Label, e.g. "Important"', 'idev-news-ticker') : $t; }, 10, 2);
add_action('add_meta_boxes_idev_ticker', function () { add_meta_box('idev_nt_box', __('Announcement', 'idev-news-ticker'), 'idev_nt_box', 'idev_ticker', 'normal', 'high'); });

function idev_nt_modes() { return ['static' => __('Static', 'idev-news-ticker'), 'scroll-slow' => __('Scroll slowly', 'idev-news-ticker'), 'scroll' => __('Scroll', 'idev-news-ticker'), 'scroll-fast' => __('Scroll fast', 'idev-news-ticker')]; }

function idev_nt_box($post) {
    wp_nonce_field('idev_nt', 'idev_nt_nonce');
    $local = function ($k) use ($post) { $x = idev_nt_meta($post->ID, $k); return $x ? esc_attr(str_replace(' ', 'T', $x)) : ''; };
    $mode = idev_nt_meta($post->ID, 'display_mode') ?: 'static';
    echo '<div class="idev-form"><label>' . esc_html__('Label (English)', 'idev-news-ticker') . '<input name="idev_nt[title_en]" value="' . esc_attr(idev_nt_meta($post->ID, 'title_en')) . '"></label>';
    echo '<label>' . esc_html__('Message (Thai)', 'idev-news-ticker') . '<textarea name="idev_nt[body]" rows="3">' . esc_textarea(idev_nt_meta($post->ID, 'body')) . '</textarea></label>';
    echo '<label>' . esc_html__('Message (English)', 'idev-news-ticker') . '<textarea name="idev_nt[body_en]" rows="3">' . esc_textarea(idev_nt_meta($post->ID, 'body_en')) . '</textarea></label>';
    echo '<label>' . esc_html__('Link when clicked (optional)', 'idev-news-ticker') . '<input name="idev_nt[link_url]" value="' . esc_attr(idev_nt_meta($post->ID, 'link_url')) . '"></label>';
    echo '<label>' . esc_html__('Display', 'idev-news-ticker') . '<select name="idev_nt[display_mode]">';
    foreach (idev_nt_modes() as $v => $l) echo '<option value="' . $v . '"' . selected($mode, $v, false) . '>' . esc_html($l) . '</option>';
    echo '</select></label><div class="idev-grid2"><label>' . esc_html__('Show from (empty = now)', 'idev-news-ticker') . '<input type="datetime-local" name="idev_nt[starts_at]" value="' . $local('starts_at') . '"></label><label>' . esc_html__('Show until (empty = no end)', 'idev-news-ticker') . '<input type="datetime-local" name="idev_nt[ends_at]" value="' . $local('ends_at') . '"></label></div>';
    echo '<p class="description">' . esc_html__('To pause, switch to Draft. Scrolling stops while the mouse is over it and is not used when the visitor prefers reduced motion.', 'idev-news-ticker') . '</p></div>';
}

add_action('save_post_idev_ticker', function ($id) {
    if (!isset($_POST['idev_nt_nonce']) || !wp_verify_nonce(sanitize_key($_POST['idev_nt_nonce']), 'idev_nt')) return;
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $id)) return;
    $in = wp_unslash($_POST['idev_nt'] ?? []);
    update_post_meta($id, '_idev_title_en', sanitize_text_field($in['title_en'] ?? ''));
    foreach (['body', 'body_en'] as $k) update_post_meta($id, "_idev_{$k}", sanitize_textarea_field($in[$k] ?? ''));
    update_post_meta($id, '_idev_link_url', idev_safe_url($in['link_url'] ?? ''));
    update_post_meta($id, '_idev_display_mode', array_key_exists($in['display_mode'] ?? '', idev_nt_modes()) ? $in['display_mode'] : 'static');
    foreach (['starts_at', 'ends_at'] as $k) { $x = str_replace('T', ' ', sanitize_text_field($in[$k] ?? '')); update_post_meta($id, "_idev_{$k}", preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $x) ? $x : ''); }
});

function idev_nt_active() {
    $now = (new DateTimeImmutable('now', wp_timezone()))->format('Y-m-d H:i');
    return array_values(array_filter(get_posts(['post_type' => 'idev_ticker', 'post_status' => 'publish', 'numberposts' => 10, 'orderby' => 'date', 'order' => 'DESC']), function ($p) use ($now) {
        $a = idev_nt_meta($p->ID, 'starts_at'); $b = idev_nt_meta($p->ID, 'ends_at');
        return !(($a !== '' && $a > $now) || ($b !== '' && $b <= $now));
    }));
}

add_filter('manage_idev_ticker_posts_columns', function ($c) { return ['cb' => $c['cb'], 'title' => __('Label', 'idev-news-ticker'), 'idev_msg' => __('Message', 'idev-news-ticker'), 'idev_mode' => __('Display', 'idev-news-ticker'), 'idev_live' => __('Now', 'idev-news-ticker'), 'date' => $c['date']]; });
add_action('manage_idev_ticker_posts_custom_column', function ($col, $id) {
    if ($col === 'idev_msg') echo esc_html(wp_trim_words(idev_nt_meta($id, 'body'), 14));
    if ($col === 'idev_mode') echo esc_html(idev_nt_modes()[idev_nt_meta($id, 'display_mode') ?: 'static'] ?? '');
    if ($col === 'idev_live') echo in_array($id, wp_list_pluck(idev_nt_active(), 'ID'), true) ? '<span style="color:#0a7d55;font-weight:600">● ' . esc_html__('Showing', 'idev-news-ticker') . '</span>' : '<span style="color:#8a8f98">' . esc_html__('Not showing', 'idev-news-ticker') . '</span>';
}, 10, 2);

/* ---------- Output ---------- */

/** Announcement bars as HTML. Themes may call this where they want the bars (and declare add_theme_support('idev-news-ticker')). */
function idev_ticker_render() {
    $items = idev_nt_active();
    if (!$items) return '';
    $s = idev_nt_settings();
    $speeds = ['scroll-slow' => 0.45, 'scroll' => 0.3, 'scroll-fast' => 0.18];
    $css = '.idev-nt{background:' . esc_attr($s['bg']) . ';color:' . esc_attr($s['text']) . ';font-size:14px;font-weight:600;line-height:1.5}.idev-nt-inner{display:flex;align-items:center;gap:12px;width:min(' . (int) $s['max_width'] . 'px,calc(100% - 32px));margin:0 auto;padding:9px 0;overflow:hidden}.idev-nt-tag{flex:none;background:' . esc_attr($s['tag_bg']) . ';padding:3px 10px;border-radius:5px;font-size:13px}.idev-nt a{color:inherit;text-decoration:none}.idev-nt-text{min-width:0}.idev-nt-ticker{position:relative;flex:1;min-width:0;overflow:hidden;mask-image:linear-gradient(90deg,transparent,#000 3%,#000 97%,transparent)}.idev-nt-track{display:inline-flex;white-space:nowrap;animation:idev-nt-scroll linear infinite}.idev-nt-track span{padding-right:80px}.idev-nt-ticker:hover .idev-nt-track{animation-play-state:paused}@keyframes idev-nt-scroll{from{transform:translateX(0)}to{transform:translateX(-50%)}}.idev-nt-sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}@media(prefers-reduced-motion:reduce){.idev-nt-track{animation:none;white-space:normal}.idev-nt-track span+span{display:none}}';
    $html = '<style id="idev-nt-css">' . $css . '</style><div class="idev-nt-wrap" role="region" aria-label="' . esc_attr__('Announcements', 'idev-news-ticker') . '">';
    foreach ($items as $p) {
        $label = idev_pick($p->post_title, idev_nt_meta($p->ID, 'title_en')) ?: __('Notice', 'idev-news-ticker');
        $body = idev_pick(idev_nt_meta($p->ID, 'body'), idev_nt_meta($p->ID, 'body_en'));
        if ($body === '') continue;
        $url = idev_href(idev_nt_meta($p->ID, 'link_url'));
        $text = esc_html($body);
        if ($url) $text = '<a href="' . esc_url($url) . '">' . $text . '</a>';
        $speed = $speeds[idev_nt_meta($p->ID, 'display_mode')] ?? 0;
        $tag = '<span class="idev-nt-tag">! ' . esc_html($label) . '</span>';
        if (!$speed) { $html .= '<div class="idev-nt"><div class="idev-nt-inner">' . $tag . '<span class="idev-nt-text">' . $text . '</span></div></div>'; continue; }
        $sec = max(12, (int) round(mb_strlen($body) * $speed));
        $html .= '<div class="idev-nt"><div class="idev-nt-inner">' . $tag . '<div class="idev-nt-ticker"><span class="idev-nt-sr">' . esc_html($body) . '</span><div class="idev-nt-track" style="animation-duration:' . $sec . 's" aria-hidden="true"><span>' . $text . '</span><span>' . $text . '</span></div></div></div></div>';
    }
    return $html . '</div>';
}
add_shortcode('idev_ticker', 'idev_ticker_render');
add_action('wp_body_open', function () {
    if (idev_nt_settings()['placement'] === 'auto' && !current_theme_supports('idev-news-ticker')) echo idev_ticker_render();
}, 5);

/* ---------- Settings ---------- */

add_action('admin_menu', function () { add_submenu_page('idevapp', __('Announcement bar settings', 'idev-news-ticker'), __('Announcement bar settings', 'idev-news-ticker'), 'manage_options', 'idev-nt-settings', 'idev_nt_settings_page'); }, 20);
function idev_nt_settings_page() {
    $fields = [
        ['placement', __('Where', 'idev-news-ticker'), 'select', __('Automatic: at the very top of every page (themes with wp_body_open). Manual: shortcode [idev_ticker] or the PHP function idev_ticker_render().', 'idev-news-ticker'), ['auto' => __('Automatic (top of page)', 'idev-news-ticker'), 'manual' => __('Manual', 'idev-news-ticker')]],
        ['bg', __('Background colour', 'idev-news-ticker'), 'color'], ['text', __('Text colour', 'idev-news-ticker'), 'color'], ['tag_bg', __('Label colour', 'idev-news-ticker'), 'color'],
        ['max_width', __('Content width (px)', 'idev-news-ticker'), 'number', '', [600, 2000]],
    ];
    $s = idev_nt_settings();
    if (isset($_POST['idev_news_ticker']) && check_admin_referer('idev_nt_settings')) { $s = idev_settings_sanitize($fields, $_POST['idev_news_ticker'], $s); update_option('idev_news_ticker', $s); echo '<div class="notice notice-success"><p>' . esc_html__('Saved.', 'idev-news-ticker') . '</p></div>'; }
    idev_admin_header(__('Announcement bar settings', 'idev-news-ticker'));
    echo '<form method="post">';
    wp_nonce_field('idev_nt_settings');
    idev_settings_table('idev_news_ticker', $fields, $s);
    submit_button();
    echo '</form><p><a class="button button-primary" href="' . esc_url(admin_url('edit.php?post_type=idev_ticker')) . '">' . esc_html__('Manage announcements', 'idev-news-ticker') . '</a></p></div>';
}

function idev_nt_migrate() {
    global $wpdb;
    if (get_option('idev_nt_migrated')) return;
    $ids = $wpdb->get_col("SELECT ID FROM {$wpdb->posts} WHERE post_type='ah_notice'");
    if ($ids) {
        $list = implode(',', array_map('intval', $ids));
        $wpdb->query("UPDATE {$wpdb->posts} SET post_type='idev_ticker' WHERE ID IN ({$list})");
        foreach (['title_en', 'body', 'body_en', 'display_mode', 'starts_at', 'ends_at'] as $k) $wpdb->query($wpdb->prepare("INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) SELECT post_id, %s, meta_value FROM {$wpdb->postmeta} WHERE meta_key=%s AND post_id IN ({$list})", "_idev_{$k}", "ah_{$k}"));
    }
    update_option('idev_nt_migrated', 1, false);
}
