<?php
defined('ABSPATH') || exit;

function idev_pa_settings() {
    $s = get_option('idev_post_attachments', []);
    return array_merge(['post_types' => ['post'], 'position' => 'after', 'style' => 'list', 'show_size' => '1', 'count' => '1', 'new_tab' => '1', 'color' => '#0f766e'], is_array($s) ? $s : []);
}

add_action('init', function () {
    load_plugin_textdomain('idev-post-attachments', false, dirname(plugin_basename(IDEV_PA_FILE)) . '/languages');
    idev_register_plugin('idev-post-attachments', ['name' => 'iDev Post Attachments', 'version' => IDEV_PA_VERSION, 'description' => __('Download lists for posts and pages.', 'idev-post-attachments'), 'settings' => admin_url('admin.php?page=idev-pa-settings'), 'docs' => 'https://idevapp.me/plugins/idev-post-attachments']);
    idev_register_block('idev/attachments', __('File attachments', 'idev-post-attachments'), 'paperclip', __('Download list of the files attached to this post.', 'idev-post-attachments'), [
        'title' => ['text', __('Heading (empty = default)', 'idev-post-attachments'), ''],
        'style' => ['select', __('Style', 'idev-post-attachments'), '', ['' => __('As in settings', 'idev-post-attachments'), 'list' => __('List', 'idev-post-attachments'), 'cards' => __('Cards', 'idev-post-attachments')]],
    ], function ($a) { return idev_attachments_render(get_the_ID(), ['title' => $a['title'] ?? '', 'style' => $a['style'] ?? '']); });
});
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_PA_FILE, admin_url('admin.php?page=idev-pa-settings'), 'https://idevapp.me/plugins/idev-post-attachments'); });

/** Files attached to a post: [id, label, url, name, title, size, ext, downloads]. */
function idev_attachments_get($post_id) {
    $list = json_decode((string) get_post_meta($post_id, '_idev_attachments', true), true);
    $files = [];
    foreach (is_array($list) ? $list : [] as $item) {
        $id = (int) ($item['id'] ?? 0);
        $path = $id ? get_attached_file($id) : '';
        if (!$path) continue;
        $files[] = ['id' => $id, 'label' => (string) ($item['label'] ?? ''), 'label_en' => (string) ($item['label_en'] ?? ''), 'url' => wp_get_attachment_url($id), 'name' => wp_basename($path), 'title' => get_the_title($id), 'size' => file_exists($path) ? filesize($path) : 0, 'ext' => strtolower(pathinfo($path, PATHINFO_EXTENSION)), 'downloads' => (int) get_post_meta($id, '_idev_downloads', true)];
    }
    return $files;
}

/* ---------- Editor ---------- */

add_action('add_meta_boxes', function ($type) {
    if (in_array($type, (array) idev_pa_settings()['post_types'], true)) add_meta_box('idev_pa_box', __('File attachments', 'idev-post-attachments'), 'idev_pa_box', $type, 'normal', 'default');
});
function idev_pa_box($post) {
    wp_nonce_field('idev_pa', 'idev_pa_nonce');
    $files = idev_attachments_get($post->ID);
    echo '<div id="idev-pa" data-files="' . esc_attr(wp_json_encode($files)) . '"></div><input type="hidden" name="idev_pa_files" id="idev-pa-input" value="' . esc_attr(wp_json_encode(array_map(function ($f) { return ['id' => $f['id'], 'label' => $f['label'], 'label_en' => $f['label_en']]; }, $files))) . '">';
}
add_action('admin_enqueue_scripts', function ($hook) {
    if (!in_array($hook, ['post.php', 'post-new.php'], true) || !in_array(get_current_screen()->post_type ?? '', (array) idev_pa_settings()['post_types'], true)) return;
    wp_enqueue_media();
    wp_enqueue_script('idev-pa-admin', plugins_url('assets/admin.js', IDEV_PA_FILE), ['jquery', 'jquery-ui-sortable'], IDEV_PA_VERSION, true);
    wp_enqueue_style('idev-pa-admin', plugins_url('assets/admin.css', IDEV_PA_FILE), [], IDEV_PA_VERSION);
    wp_localize_script('idev-pa-admin', 'IDEV_PA', ['t' => [
        'add' => __('Attach files', 'idev-post-attachments'), 'pick' => __('Choose documents', 'idev-post-attachments'), 'remove' => __('Remove', 'idev-post-attachments'),
        'empty' => __('No files attached yet.', 'idev-post-attachments'), 'hint' => __('Drag to reorder. Empty name = file title.', 'idev-post-attachments'),
        'name' => __('Name shown (Thai)', 'idev-post-attachments'), 'name_en' => __('Name shown (English, optional)', 'idev-post-attachments'), 'downloads' => __('downloads', 'idev-post-attachments'),
    ]]);
});
add_action('save_post', function ($post_id, $post) {
    if (!isset($_POST['idev_pa_nonce']) || !wp_verify_nonce(sanitize_key($_POST['idev_pa_nonce']), 'idev_pa')) return;
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $post_id)) return;
    $list = json_decode(wp_unslash((string) ($_POST['idev_pa_files'] ?? '[]')), true);
    $clean = [];
    foreach (is_array($list) ? $list : [] as $item) {
        $id = (int) ($item['id'] ?? 0);
        if ($id && get_post_type($id) === 'attachment') $clean[] = ['id' => $id, 'label' => mb_substr(sanitize_text_field($item['label'] ?? ''), 0, 200), 'label_en' => mb_substr(sanitize_text_field($item['label_en'] ?? ''), 0, 200)];
    }
    update_post_meta($post_id, '_idev_attachments', wp_slash(wp_json_encode($clean, JSON_UNESCAPED_UNICODE)));
}, 10, 2);

/* ---------- Front end ---------- */

function idev_pa_size($bytes) {
    if ($bytes <= 0) return '';
    $u = ['B', 'KB', 'MB', 'GB']; $i = 0;
    while ($bytes >= 1024 && $i < 3) { $bytes /= 1024; $i++; }
    return round($bytes, $i > 1 ? 1 : 0) . ' ' . $u[$i];
}
function idev_pa_type_color($ext) {
    $map = ['pdf' => '#d93025', 'doc' => '#2b579a', 'docx' => '#2b579a', 'odt' => '#2b579a', 'xls' => '#217346', 'xlsx' => '#217346', 'csv' => '#217346', 'ods' => '#217346', 'ppt' => '#d24726', 'pptx' => '#d24726', 'zip' => '#6b5b95', 'jpg' => '#0b7285', 'jpeg' => '#0b7285', 'png' => '#0b7285'];
    return $map[$ext] ?? '#5f6b7a';
}
function idev_pa_link($file, $post_id) {
    return idev_pa_settings()['count'] ? add_query_arg(['idev_dl' => $file['id'], 'p_ref' => $post_id], home_url('/')) : $file['url'];
}

/** Download list HTML for a post. $args: title, style (list|cards). */
function idev_attachments_render($post_id = 0, $args = []) {
    $post_id = $post_id ?: get_the_ID();
    $files = $post_id ? idev_attachments_get($post_id) : [];
    if (!$files) return '';
    $s = idev_pa_settings();
    $style = in_array($args['style'] ?? '', ['list', 'cards'], true) ? $args['style'] : $s['style'];
    $title = ($args['title'] ?? '') !== '' ? $args['title'] : __('Attached documents', 'idev-post-attachments');
    $target = $s['new_tab'] ? ' target="_blank" rel="noopener"' : '';
    $html = '<section class="idev-pa idev-pa-' . esc_attr($style) . '" style="--idev-pa:' . esc_attr($s['color']) . '"><h2 class="idev-pa-title">' . idev_icon('paperclip') . esc_html($title) . ' <span>(' . count($files) . ')</span></h2><ul>';
    foreach ($files as $f) {
        $name = idev_pick($f['label'], $f['label_en']) ?: ($f['title'] ?: $f['name']);
        $meta = [strtoupper($f['ext'])];
        if ($s['show_size'] && $f['size']) $meta[] = idev_pa_size($f['size']);
        if ($s['count'] && $f['downloads']) $meta[] = sprintf(_n('%s download', '%s downloads', $f['downloads'], 'idev-post-attachments'), number_format_i18n($f['downloads']));
        $html .= '<li><a href="' . esc_url(idev_pa_link($f, $post_id)) . '"' . $target . ' download><span class="idev-pa-badge" style="background:' . esc_attr(idev_pa_type_color($f['ext'])) . '">' . esc_html(strtoupper(mb_substr($f['ext'], 0, 4))) . '</span><span class="idev-pa-main"><strong>' . esc_html($name) . '</strong><small>' . esc_html(implode(' · ', $meta)) . '</small></span><span class="idev-pa-dl">' . idev_icon('download') . '<span>' . esc_html__('Download', 'idev-post-attachments') . '</span></span></a></li>';
    }
    return $html . '</ul></section>';
}
add_shortcode('idev_attachments', function ($a) { $a = shortcode_atts(['post' => 0, 'title' => '', 'style' => ''], $a); return idev_attachments_render((int) $a['post'], $a); });

add_filter('the_content', function ($content) {
    $s = idev_pa_settings();
    if ($s['position'] === 'manual' || current_theme_supports('idev-post-attachments') || !is_singular() || !in_the_loop() || !is_main_query()) return $content;
    if (!in_array(get_post_type(), (array) $s['post_types'], true) || has_shortcode($content, 'idev_attachments') || has_block('idev/attachments')) return $content;
    $list = idev_attachments_render(get_the_ID());
    return $s['position'] === 'before' ? $list . $content : $content . $list;
}, 20);

add_action('wp_enqueue_scripts', function () { wp_enqueue_style('idev-pa', plugins_url('assets/front.css', IDEV_PA_FILE), [], IDEV_PA_VERSION); });

/* Download counter: only files that are attached to a published post they belong to. */
add_action('template_redirect', function () {
    if (empty($_GET['idev_dl'])) return;
    $id = (int) $_GET['idev_dl'];
    $ref = (int) ($_GET['p_ref'] ?? 0);
    $ok = $ref && get_post_status($ref) === 'publish' && empty(get_post($ref)->post_password) && in_array($id, wp_list_pluck(idev_attachments_get($ref), 'id'), true);
    if (!$ok) { status_header(404); nocache_headers(); exit; }
    if (!preg_match('/bot|crawl|spider|preview/i', $_SERVER['HTTP_USER_AGENT'] ?? '')) update_post_meta($id, '_idev_downloads', (int) get_post_meta($id, '_idev_downloads', true) + 1);
    nocache_headers();
    wp_safe_redirect(wp_get_attachment_url($id), 302, 'iDev Post Attachments');
    exit;
});
add_filter('allowed_redirect_hosts', function ($hosts) { $u = wp_parse_url(wp_get_upload_dir()['baseurl']); if (!empty($u['host'])) $hosts[] = $u['host']; return $hosts; });

/* ---------- Settings ---------- */

add_action('admin_menu', function () { add_submenu_page('idevapp', __('File attachments', 'idev-post-attachments'), __('File attachments', 'idev-post-attachments'), 'manage_options', 'idev-pa-settings', 'idev_pa_settings_page'); }, 20);
function idev_pa_settings_page() {
    $types = [];
    foreach (get_post_types(['public' => true], 'objects') as $t) if ($t->name !== 'attachment') $types[$t->name] = $t->labels->name;
    $s = idev_pa_settings();
    $fields = [
        ['position', __('Where to show the list', 'idev-post-attachments'), 'select', __('Manual: use the "File attachments" block or the shortcode [idev_attachments].', 'idev-post-attachments'), ['after' => __('After the content', 'idev-post-attachments'), 'before' => __('Before the content', 'idev-post-attachments'), 'manual' => __('Manual', 'idev-post-attachments')]],
        ['style', __('Style', 'idev-post-attachments'), 'select', '', ['list' => __('List', 'idev-post-attachments'), 'cards' => __('Cards', 'idev-post-attachments')]],
        ['color', __('Accent colour', 'idev-post-attachments'), 'color'],
        ['show_size', __('Show file size', 'idev-post-attachments'), 'checkbox'],
        ['count', __('Count downloads', 'idev-post-attachments'), 'checkbox', __('Links go through your site so each download is counted (bots are ignored).', 'idev-post-attachments')],
        ['new_tab', __('Open in a new tab', 'idev-post-attachments'), 'checkbox'],
    ];
    if (isset($_POST['idev_post_attachments']) && check_admin_referer('idev_pa_settings')) {
        $in = wp_unslash($_POST['idev_post_attachments']);
        $s = idev_settings_sanitize($fields, $in, $s);
        $s['post_types'] = array_values(array_intersect(array_keys($types), array_map('sanitize_key', (array) ($in['post_types'] ?? []))));
        update_option('idev_post_attachments', $s);
        echo '<div class="notice notice-success"><p>' . esc_html__('Saved.', 'idev-post-attachments') . '</p></div>';
    }
    idev_admin_header(__('File attachments', 'idev-post-attachments'));
    echo '<form method="post">';
    wp_nonce_field('idev_pa_settings');
    $boxes = '';
    foreach ($types as $k => $l) $boxes .= '<label style="margin-right:16px"><input type="checkbox" name="idev_post_attachments[post_types][]" value="' . esc_attr($k) . '"' . checked(in_array($k, (array) $s['post_types'], true), true, false) . '> ' . esc_html($l) . '</label>';
    array_unshift($fields, ['_types', __('Use on', 'idev-post-attachments'), 'html', '', $boxes]);
    idev_settings_table('idev_post_attachments', $fields, $s);
    submit_button();
    echo '</form></div>';
}

/* Copies Andaman Hub attachments (ah_attachments) once. */
function idev_pa_migrate() {
    global $wpdb;
    if (get_option('idev_pa_migrated')) return;
    $wpdb->query("INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) SELECT post_id, '_idev_attachments', meta_value FROM {$wpdb->postmeta} WHERE meta_key='ah_attachments' AND post_id NOT IN (SELECT post_id FROM (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_idev_attachments') x)");
    update_option('idev_pa_migrated', 1, false);
}
