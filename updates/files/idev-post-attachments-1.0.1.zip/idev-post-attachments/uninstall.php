<?php
defined('WP_UNINSTALL_PLUGIN') || exit;
delete_option('idev_post_attachments');
delete_option('idev_pa_migrated');
