=== iDev Post Attachments ===
Contributors: idevapp2023
Donate link: https://idevapp.me/
Tags: attachments, download, pdf, documents
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Attach PDF, Word, Excel and other files to posts and pages, with names, file type, size and a download counter.

== Description ==

Attach PDF, Word, Excel and other files to posts and pages, with names, file type, size and a download counter.

= Features =

* Drag to reorder, Thai/English names
* List or card style, block and shortcode [idev_attachments]
* Download counter (bots ignored)

Thai and English interface. Works with any theme. Part of the iDevApp plugin suite for hospitals and clinics — all iDev plugins appear under the **iDevApp** menu.

== Installation ==

1. Plugins → Add New → Upload Plugin, choose the zip, Install, Activate.
2. Open **iDevApp** in the admin menu for settings.

== Changelog ==

= 1.0.0 =
* First release.
