/* iDev Post Attachments — editor: pick files, name them (TH/EN), drag to order. */
(function ($) {
  const root = document.getElementById('idev-pa');
  const input = document.getElementById('idev-pa-input');
  if (!root || !input) return;
  const T = (window.IDEV_PA && IDEV_PA.t) || {};
  let files = [];
  try { files = JSON.parse(root.dataset.files || '[]'); } catch (e) { files = []; }
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const sync = () => { input.value = JSON.stringify(files.map((f) => ({ id: f.id, label: f.label || '', label_en: f.label_en || '' }))); };
  function render() {
    sync();
    root.innerHTML = (files.length
      ? '<ul class="idev-pa-files">' + files.map((f, i) => `<li data-i="${i}"><span class="idev-pa-grip" title="${esc(T.hint)}">⋮⋮</span><span class="idev-pa-ext">${esc((f.ext || '').toUpperCase())}</span><span class="idev-pa-fields"><input data-k="label" data-i="${i}" value="${esc(f.label)}" placeholder="${esc(T.name)}: ${esc(f.title || f.name)}"><input data-k="label_en" data-i="${i}" value="${esc(f.label_en)}" placeholder="${esc(T.name_en)}"><small>${esc(f.name)}${f.downloads ? ' · ' + f.downloads + ' ' + esc(T.downloads) : ''}</small></span><button type="button" class="button-link-delete" data-remove="${i}">${esc(T.remove)}</button></li>`).join('') + '</ul>'
      : '<p class="idev-pa-empty">' + esc(T.empty) + '</p>')
      + '<p><button type="button" class="button" data-add>＋ ' + esc(T.add) + '</button> <span class="description">' + esc(T.hint) + '</span></p>';
    $(root).find('.idev-pa-files').sortable({ handle: '.idev-pa-grip', axis: 'y', update() {
      const order = $(root).find('.idev-pa-files > li').map((_, li) => Number(li.dataset.i)).get();
      files = order.map((i) => files[i]);
      render();
    } });
  }
  root.addEventListener('input', (e) => { const el = e.target; if (el.dataset.k) { files[Number(el.dataset.i)][el.dataset.k] = el.value; sync(); } });
  root.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    e.preventDefault();
    if (b.dataset.remove !== undefined) { files.splice(Number(b.dataset.remove), 1); render(); return; }
    if (b.dataset.add === undefined) return;
    const frame = wp.media({ title: T.pick, multiple: true, button: { text: T.add } });
    frame.on('select', () => {
      frame.state().get('selection').each((a) => {
        const d = a.toJSON();
        if (!files.some((f) => f.id === d.id)) files.push({ id: d.id, label: '', label_en: '', title: d.title, name: d.filename, ext: (d.filename.split('.').pop() || '').toLowerCase() });
      });
      render();
    });
    frame.open();
  });
  render();
})(jQuery);
