<?php
defined('ABSPATH') || exit;

define('IDW_THEME2_VERSION', wp_get_theme('idevapp-theme-2')->get('Version') ?: '1.0.0'); // new files reach visitors after each update

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('align-wide');
    add_theme_support('responsive-embeds');
    add_theme_support('html5', ['search-form', 'gallery', 'caption', 'style', 'script']);
    add_theme_support('custom-logo', ['height' => 96, 'width' => 96, 'flex-width' => true, 'flex-height' => true]);
    add_theme_support('editor-styles');
    add_editor_style(['assets/site.css', 'assets/wp.css']);
    register_nav_menus(['primary' => 'เมนูหลัก']);
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('idevapp-fonts', 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Thai:wght@300;400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap', [], null);
    wp_enqueue_style('idevapp-site', get_template_directory_uri() . '/assets/site.css', [], IDW_THEME2_VERSION);
    wp_enqueue_style('idevapp-wp', get_template_directory_uri() . '/assets/wp.css', ['idevapp-site'], IDW_THEME2_VERSION);
    wp_enqueue_script('idevapp-theme-2', get_template_directory_uri() . '/assets/theme.js', [], IDW_THEME2_VERSION, ['in_footer' => true, 'strategy' => 'defer']);
});

add_action('enqueue_block_editor_assets', function () {
    wp_enqueue_style('idevapp-fonts', 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Thai:wght@300;400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap', [], null);
});

add_action('wp_head', function () {
    echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
}, 1);

// The theme needs the iDevApp Hub plugin (language, settings, schedule, blocks).
function idevapp_ready() { return function_exists('ihub_t'); }
add_action('admin_notices', function () {
    if (!idevapp_ready()) echo '<div class="notice notice-error"><p>ธีมแบบที่ 2 ต้องใช้โมดูล <strong>ศูนย์บริการ (Hub)</strong> ของปลั๊กอิน iDevApp Website — เปิดได้ที่ <a href="' . esc_url(admin_url('admin.php?page=idw-modules')) . '">iDevApp Website → โมดูล</a></p></div>';
});
add_action('template_redirect', function () {
    if (!idevapp_ready() && !is_admin()) wp_die('เว็บไซต์กำลังปรับปรุง กรุณากลับมาใหม่ภายหลัง', get_bloginfo('name'), ['response' => 503]);
});

add_filter('document_title_separator', function () { return '|'; });
add_filter('excerpt_more', function () { return '…'; });

function idevapp_logo_url() {
    $id = get_theme_mod('custom_logo');
    $url = $id ? wp_get_attachment_image_url($id, 'thumbnail') : '';
    return $url ?: get_template_directory_uri() . '/images/site-symbol.png';
}

function idevapp_brand($class = 'brand') {
    $local = ihub_site_local();
    return '<a class="' . esc_attr($class) . '" href="' . esc_url(home_url('/')) . '" aria-label="' . esc_attr($local['name'] . ' ' . ihub_t('header.home')) . '"><img class="brand-logo" src="' . esc_url(idevapp_logo_url()) . '" alt="" width="48" height="48"><span><strong>' . esc_html($local['name']) . '</strong><small>' . esc_html($local['tagline']) . '</small></span></a>';
}

/** Flat main menu with the old markup: <a class="active">. */
class IdevApp_Menu_Walker extends Walker_Nav_Menu {
    public function start_lvl(&$output, $depth = 0, $args = null) {}
    public function end_lvl(&$output, $depth = 0, $args = null) {}
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $classes = (array) $item->classes;
        $active = array_intersect(['current-menu-item', 'current_page_item', 'current-page-ancestor', 'current_page_parent', 'current-menu-ancestor'], $classes);
        if ($item->url === home_url('/') || $item->url === home_url()) $active = is_front_page() ? ['x'] : [];
        if (is_search() || is_404()) $active = [];
        $target = $item->target === '_blank' ? ' target="_blank" rel="noopener noreferrer"' : '';
        $output .= '<a href="' . esc_url($item->url) . '"' . ($active ? ' class="active" aria-current="page"' : '') . $target . '>' . esc_html($item->title) . '</a>';
    }
    public function end_el(&$output, $item, $depth = 0, $args = null) {}
}

function idevapp_menu() {
    if (has_nav_menu('primary')) return wp_nav_menu(['theme_location' => 'primary', 'container' => false, 'items_wrap' => '%3$s', 'walker' => new IdevApp_Menu_Walker(), 'echo' => false, 'depth' => 1]);
    $html = '';
    foreach (ihub_t('fallbackMenu') as [$href, $label]) $html .= '<a href="' . esc_url(home_url($href)) . '">' . esc_html($label) . '</a>';
    return $html;
}

/** Title band at the top of inner pages. */
function idevapp_page_top($title, $summary = '', $kicker = '', $back = '', $banner = '') {
    $style = $banner ? ' style="background-image:linear-gradient(90deg, rgba(13,26,41,.88), rgba(13,26,41,.35)), url(&quot;' . esc_url($banner) . '&quot;)"' : '';
    echo '<section class="subpage-top' . ($banner ? ' page-banner' : '') . '"' . $style . '><div class="container">';
    if ($back) echo $back;
    if ($kicker !== '') echo '<span class="section-kicker">' . esc_html($kicker) . '</span>';
    echo '<h1>' . wp_kses_post($title) . '</h1>';
    if ($summary !== '') echo '<p>' . esc_html($summary) . '</p>';
    echo '</div></section>';
}

/** "Cards" layout: every <h3> starts a card; text before the first <h3> is the intro. */
function idevapp_split_cards($html) {
    $parts = preg_split('/<h3[^>]*>/i', $html);
    $intro = array_shift($parts);
    $cards = [];
    foreach ($parts as $part) {
        $end = stripos($part, '</h3>');
        $cards[] = $end === false ? ['title' => '', 'body' => $part] : ['title' => wp_strip_all_tags(substr($part, 0, $end)), 'body' => substr($part, $end + 5)];
    }
    return [$intro, $cards];
}

/** One page with its layout options (port of the old [slug] page). */
function idevapp_render_page($post) {
    $o = ihub_page_options($post->ID);
    $content = apply_filters('the_content', get_the_content(null, false, $post));
    $title = get_the_title($post);
    $summary = ihub_pick($post->post_excerpt, ihub_en_meta($post->ID, 'excerpt'));
    $image = get_the_post_thumbnail_url($post, 'full');
    $layout = $o['layout'];
    $local = ihub_site_local();
    $phone = ihub_setting('phone');
    $map = $o['show_map'] ? ihub_render_map() : '';
    $cta = $o['show_contact'] ? '<div class="contact-callout"><h2>' . esc_html(ihub_t('page.askTitle')) . '</h2><a class="button button-teal" href="' . esc_url(home_url('/contact')) . '">' . esc_html(ihub_t('page.contactUs')) . '</a></div>' : '';

    if ($layout === 'full') {
        if ($o['show_title']) idevapp_page_top($title, $summary);
        echo '<div class="page-blocks">' . $content . '</div>';
        if ($map || $cta) echo '<section class="section page-section"><div class="container page-body">' . $map . $cta . '</div></section>';
        return;
    }
    $banner = $layout === 'banner' && $image ? $image : '';
    if ($o['show_title'] || $banner) idevapp_page_top($title, $summary, '', '', $banner);
    $img = $image && !$banner ? '<img class="article-image" src="' . esc_url($image) . '" alt="">' : '';
    if ($layout === 'cards') {
        [$intro, $cards] = idevapp_split_cards($content);
        $icons = ['plus', 'emergency', 'xray', 'news', 'travel', 'clock', 'phone', 'pin'];
        $tones = ['mint', 'rose', 'sky', 'lavender'];
        $body = $img . (trim(wp_strip_all_tags($intro)) !== '' ? '<div class="article-content">' . $intro . '</div>' : '') . '<div class="service-grid page-cards">';
        foreach ($cards as $i => $card) $body .= '<article class="service-card"><span class="service-icon ' . $tones[$i % 4] . '">' . ihub_icon($icons[$i % 8]) . '</span>' . ($card['title'] !== '' ? '<h3>' . esc_html($card['title']) . '</h3>' : '') . '<div class="article-content card-body">' . $card['body'] . '</div></article>';
        $body .= '</div>';
    } elseif ($layout === 'sidebar') {
        $body = '<div class="page-with-sidebar"><div>' . $img . '<div class="article-content">' . $content . '</div></div><aside class="page-sidebar"><div class="sidebar-card"><h2>' . esc_html(ihub_t('contact.title')) . '</h2><p>' . ihub_icon('pin') . ' ' . esc_html($local['address']) . '</p><p>' . ihub_icon('phone') . ' <a href="tel:' . esc_attr($phone) . '">' . esc_html($phone) . '</a></p><small>' . esc_html(ihub_t('contact.emergencyNote')) . '</small><a class="button button-teal" href="' . esc_url(home_url('/contact')) . '">' . esc_html(ihub_t('page.contactUs')) . '</a></div></aside></div>';
    } else {
        $body = $img . '<div class="article-content">' . $content . '</div>';
    }
    echo '<section class="section page-section layout-' . esc_attr($layout) . '"><div class="container page-body">' . $body . $map . $cta . '</div></section>';
}

/* ---------- 1.3: colours (Appearance → Customize → สีของธีม) ---------- */

function idevapp_colors() {
    return [
        'primary' => ['สีหลัก (ปุ่ม ลิงก์ ไอคอน)', '#169c91'],
        'primary_dark' => ['สีหลักเข้ม (ตัวอักษรลิงก์ hover)', '#117e76'],
        'accent' => ['สีเน้น (ปุ่มโทร ปุ่มสำคัญ ประกาศ)', '#ed345d'],
        'dark' => ['สีพื้นเข้ม (แถบบน ส่วนท้าย บล็อกพื้นเข้ม)', '#0d2a34'],
        'light' => ['สีพื้นอ่อน (บล็อกพื้นอ่อน หัวหน้าย่อย)', '#f4f8f8'],
        'ink' => ['สีตัวอักษร', '#172737'],
    ];
}
add_action('customize_register', function ($wp) {
    $wp->add_section('idevapp_colors', ['title' => 'สีของธีม (iDevApp)', 'priority' => 30, 'description' => 'เปลี่ยนสีทั้งเว็บ — ปุ่ม ลิงก์ ไอคอน แถบบน ส่วนท้าย และบล็อกพื้นเข้ม/พื้นอ่อน']);
    $wp->add_setting('idevapp_preset', ['default' => '', 'sanitize_callback' => 'sanitize_key', 'transport' => 'refresh']);
    $wp->add_control('idevapp_preset', ['section' => 'idevapp_colors', 'type' => 'select', 'label' => 'ชุดสีสำเร็จรูป (เลือกแล้วกด "เผยแพร่")', 'choices' => ['' => '— กำหนดเอง —'] + array_map(function ($p) { return $p['name']; }, idevapp_presets())]);
    foreach (idevapp_colors() as $key => [$label, $default]) {
        $wp->add_setting("idevapp_color_{$key}", ['default' => $default, 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'refresh']);
        $wp->add_control(new WP_Customize_Color_Control($wp, "idevapp_color_{$key}", ['section' => 'idevapp_colors', 'label' => $label]));
    }
});
function idevapp_presets() {
    return [
        'idevapp' => ['name' => 'iDevApp (เขียวน้ำทะเล)', 'primary' => '#169c91', 'primary_dark' => '#117e76', 'accent' => '#ed345d', 'dark' => '#0d2a34', 'light' => '#f4f8f8', 'ink' => '#172737'],
        'ocean' => ['name' => 'Ocean (น้ำเงิน)', 'primary' => '#1d6fd1', 'primary_dark' => '#1758a6', 'accent' => '#f0592a', 'dark' => '#0f2442', 'light' => '#f2f6fc', 'ink' => '#15233a'],
        'forest' => ['name' => 'Forest (เขียว)', 'primary' => '#2f8f4e', 'primary_dark' => '#24703c', 'accent' => '#e2a400', 'dark' => '#132b1d', 'light' => '#f3f8f3', 'ink' => '#1b2a20'],
        'royal' => ['name' => 'Royal (ม่วง)', 'primary' => '#6b4fc4', 'primary_dark' => '#553da0', 'accent' => '#e2457a', 'dark' => '#1e1838', 'light' => '#f6f4fc', 'ink' => '#1f1b33'],
        'sunset' => ['name' => 'Sunset (ส้มอิฐ)', 'primary' => '#c75b2a', 'primary_dark' => '#a2481f', 'accent' => '#1f8a8a', 'dark' => '#2c1a12', 'light' => '#fbf6f2', 'ink' => '#2a1d17'],
        'mourning' => ['name' => 'ไว้ทุกข์ (ขาว-ดำ)', 'primary' => '#3d3d3d', 'primary_dark' => '#222222', 'accent' => '#555555', 'dark' => '#111111', 'light' => '#f4f4f4', 'ink' => '#1a1a1a'],
    ];
}
// Choosing a preset fills in the colours.
add_action('customize_save_after', function () {
    $p = get_theme_mod('idevapp_preset');
    $all = idevapp_presets();
    if (!$p || !isset($all[$p])) return;
    foreach (array_keys(idevapp_colors()) as $k) set_theme_mod("idevapp_color_{$k}", $all[$p][$k]);
    set_theme_mod('idevapp_preset', '');
});
function idevapp_color($key) {
    $c = idevapp_colors();
    return sanitize_hex_color(get_theme_mod("idevapp_color_{$key}", $c[$key][1])) ?: $c[$key][1];
}
function idevapp_mix($hex, $white) { // lighten towards white (0..1)
    $h = ltrim($hex, '#'); $r = hexdec(substr($h, 0, 2)); $g = hexdec(substr($h, 2, 2)); $b = hexdec(substr($h, 4, 2));
    $f = function ($v) use ($white) { return (int) round($v + (255 - $v) * $white); };
    return sprintf('#%02x%02x%02x', $f($r), $f($g), $f($b));
}
add_action('wp_head', function () {
    $p = idevapp_color('primary'); $pd = idevapp_color('primary_dark'); $a = idevapp_color('accent'); $d = idevapp_color('dark'); $l = idevapp_color('light'); $ink = idevapp_color('ink');
    $defaults = array_map(function ($c) { return $c[1]; }, idevapp_colors());
    if ([$p, $pd, $a, $d, $l, $ink] === array_values($defaults)) return; // default colours: nothing to override
    $css = ":root{--teal:{$p};--teal-dark:{$pd};--coral:{$a};--navy:{$d};--ink:{$ink};--ihub-dark:{$d};--ihub-light:{$l};--ihub-soft:" . idevapp_mix($p, .9) . "}"
        . ".topline{background:{$d}}.footer,.contact-band,.pb-block.bg-dark{background:{$d}}.pb-block.bg-teal{background:linear-gradient(135deg,{$p},{$pd})}"
        . ".pb-block.bg-light,.subpage-top,.news-section{background:{$l}}.language{background:{$pd}}.announcement{background:{$a}}"
        . ".brand-mark{background:linear-gradient(140deg," . idevapp_mix($p, .25) . ",{$p})}.hero h1 em{color:" . idevapp_mix($p, .3) . "}"
        . ".news-category,.empty-news>span{background:" . idevapp_mix($p, .88) . ";color:{$pd}}.button-coral{background:{$a}}";
    echo '<style id="idevapp-colors">' . $css . "</style>\n";
}, 30);

/* iDev plugins: the theme places the announcement bar (header) and the file list (single news) itself. */
add_action('after_setup_theme', function () {
    add_theme_support('idev-news-ticker');
    add_theme_support('idev-post-attachments');
});
