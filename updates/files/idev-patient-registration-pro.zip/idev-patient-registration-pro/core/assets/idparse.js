/* iDev Patient Registration — reads OCR text from a passport (ICAO 9303 MRZ) or a Thai ID card.
   Pure functions (no DOM), also used by the tests. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.IDevIdParse = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  const MONTHS_EN = { JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6, JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12 };
  const MONTHS_TH = { 'ม.ค.': 1, 'ก.พ.': 2, 'มี.ค.': 3, 'เม.ย.': 4, 'พ.ค.': 5, 'มิ.ย.': 6, 'ก.ค.': 7, 'ส.ค.': 8, 'ก.ย.': 9, 'ต.ค.': 10, 'พ.ย.': 11, 'ธ.ค.': 12 };
  const pad = (n) => String(n).padStart(2, '0');
  const iso = (y, m, d) => {
    const date = new Date(Date.UTC(y, m - 1, d));
    return date.getUTCFullYear() === y && date.getUTCMonth() === m - 1 && date.getUTCDate() === d ? `${y}-${pad(m)}-${pad(d)}` : '';
  };

  /* ---------- Passport MRZ (TD3: 2 × 44 characters) ---------- */
  const mrzValue = (c) => (c === '<' ? 0 : /\d/.test(c) ? Number(c) : c.charCodeAt(0) - 55);
  function checkDigit(text) {
    const w = [7, 3, 1];
    let sum = 0;
    for (let i = 0; i < text.length; i++) sum += mrzValue(text[i]) * w[i % 3];
    return String(sum % 10);
  }
  // OCR confusions, by what the position must contain.
  const toDigits = (s) => s.replace(/[OQDU]/g, '0').replace(/[IL|T]/g, '1').replace(/Z/g, '2').replace(/S/g, '5').replace(/G/g, '6').replace(/B/g, '8').replace(/A/g, '4');
  const toLetters = (s) => s.replace(/0/g, 'O').replace(/1/g, 'I').replace(/2/g, 'Z').replace(/5/g, 'S').replace(/6/g, 'G').replace(/8/g, 'B').replace(/4/g, 'A');
  const clean = (s) => String(s).toUpperCase()
    .replace(/[«‹＜〈(\[{]/g, '<')
    .replace(/\s+/g, '')
    .replace(/[^A-Z0-9<]/g, '')
    // runs like "<K<<" or "<<C<" inside filler areas are almost always misread fillers
    .replace(/<[KCEX](?=<)/g, '<<').replace(/(?<=<)[KCEX]</g, '<<');

  /** Normalise one MRZ line 2 candidate and score it by valid check digits. */
  function readLine2(raw) {
    let l = (raw + '<'.repeat(44)).slice(0, 44);
    // fixed digit positions: 9 (doc check), 13–19 (birth + check), 21–27 (expiry + check), 42–43
    const fixDigits = (s, a, b) => s.slice(0, a) + toDigits(s.slice(a, b)) + s.slice(b);
    l = fixDigits(l, 9, 10); l = fixDigits(l, 13, 20); l = fixDigits(l, 21, 28); l = fixDigits(l, 43, 44);
    l = l.slice(0, 10) + toLetters(l.slice(10, 13)) + l.slice(13);
    let doc = l.slice(0, 9);
    const docCheck = l[9];
    if (checkDigit(doc) !== docCheck) {
      // Thai passports: 2 letters + 7 digits (e.g. AA1234567); many others are digits only.
      const tries = [toLetters(doc.slice(0, 2)) + toDigits(doc.slice(2)), toDigits(doc), toLetters(doc.slice(0, 1)) + toDigits(doc.slice(1))];
      const ok = tries.find((t) => checkDigit(t) === docCheck);
      if (ok) doc = ok;
    }
    const dob = l.slice(13, 19), exp = l.slice(21, 27);
    let personal = l.slice(28, 42);
    const personalCheck = l[42];
    if (checkDigit(personal) !== personalCheck && /[0-9]/.test(personal)) { const alt = toDigits(personal.replace(/<+$/, '')).padEnd(14, '<'); if (checkDigit(alt) === personalCheck) personal = alt; }
    const composite = doc + l[9] + dob + l[19] + exp + l[27] + personal + l[42];
    const checks = {
      document: checkDigit(doc) === docCheck,
      birthdate: /^\d{6}$/.test(dob) && checkDigit(dob) === l[19],
      expiry: /^\d{6}$/.test(exp) && checkDigit(exp) === l[27],
      personal: personal.replace(/</g, '') === '' ? (personalCheck === '<' || personalCheck === '0') : checkDigit(personal) === personalCheck,
      composite: checkDigit(composite) === l[43],
    };
    return { line: doc + l.slice(9, 28) + personal + l.slice(42), doc, dob, exp, personal, sex: l[20], nationality: l.slice(10, 13), checks, score: Object.values(checks).filter(Boolean).length };
  }

  function parseMrz(text) {
    const lines = String(text || '').split(/\r?\n/).map(clean).filter((l) => l.length >= 28);
    let best = null;
    for (let i = 0; i < lines.length; i++) {
      const c = lines[i];
      // line 2 looks like: 9 chars, digit, 3 letters, 6 digits ...
      const candidates = [c];
      // OCR sometimes glues the two lines or adds a stray char at the start: also try shifted windows.
      for (let s = 1; s <= Math.min(3, c.length - 30); s++) candidates.push(c.slice(s));
      for (const cand of candidates) {
        if (!/^[A-Z0-9<]{9}[0-9OQDUISZGB][A-Z0-9<]{3}[0-9OQDUISZGB]{6}/.test(cand)) continue;
        const r = readLine2(cand);
        if (!best || r.score > best.score) best = { ...r, index: i };
      }
    }
    if (!best || best.score < 2) return null;
    // Line 1: OCR often shortens the "<<<<" runs, so look at every line, not only long ones.
    const all = String(text || '').split(/\r?\n/).map(clean).filter(Boolean);
    const isL1 = (l) => /^P[<KC]?[A-Z0-9]{3}[A-Z0-9]*<</.test(l) && !/^[A-Z0-9<]{9}\d[A-Z<]{3}\d{6}/.test(l);
    const at = all.findIndex((l) => l.startsWith(lines[best.index].slice(0, 12)));
    let l1 = '';
    for (let j = (at > -1 ? at : all.length) - 1; j >= 0 && !l1; j--) if (isL1(all[j])) l1 = all[j];
    if (!l1) l1 = all.find(isL1) || '';
    l1 = l1.replace(/^P[KC]/, 'P<');
    if (!/^P</.test(l1) && /^P[A-Z]{3}/.test(l1)) l1 = 'P<' + l1.slice(1);
    const issuer = toLetters(l1.slice(2, 5)).replace(/</g, '');
    // Names end at the first run of 3+ fillers; anything after it is noise.
    const body = toLetters(l1.slice(5)).split(/<{3,}/)[0];
    const names = body.split('<<');
    const fix = (s) => (s || '').replace(/</g, ' ').replace(/[^A-Z ]/g, '').replace(/\s+/g, ' ').trim();
    const title = (s) => s.toLowerCase().replace(/(^|[\s-])[a-z]/g, (c) => c.toUpperCase());
    const nowYY = new Date().getFullYear() % 100;
    const dob = best.dob;
    const yy = Number(dob.slice(0, 2));
    const birthdate = /^\d{6}$/.test(dob) ? iso(yy > nowYY ? 1900 + yy : 2000 + yy, Number(dob.slice(2, 4)), Number(dob.slice(4, 6))) : '';
    const exp = best.exp;
    const expiry = /^\d{6}$/.test(exp) ? iso(2000 + Number(exp.slice(0, 2)), Number(exp.slice(2, 4)), Number(exp.slice(4, 6))) : '';
    const nationality = toLetters(best.nationality).replace(/</g, '');
    const out = {
      doc_type: 'passport',
      passport_no: best.doc.replace(/</g, ''),
      nationality,
      issuer,
      birthdate,
      expiry,
      sex: best.sex === 'F' ? 'female' : best.sex === 'M' ? 'male' : '',
      last_name_en: title(fix(names[0])),
      first_name_en: title(fix(names.slice(1).join(' '))),
      checks: best.checks,
      score: best.score,
    };
    // Thai passports carry the 13-digit national ID in the personal number field.
    const personal = best.personal.replace(/</g, '');
    if (/^\d{13}$/.test(personal) && validThaiId(personal)) out.cid = personal;
    return out;
  }

  /** Best of several OCR attempts (different crops / thresholds): most valid check digits wins. */
  function bestMrz(texts) {
    const results = texts.map(parseMrz).filter(Boolean);
    if (!results.length) return null;
    const top = Math.max(...results.map((r) => r.score));
    const good = results.filter((r) => r.score === top);
    // Names are not protected by check digits: take the one most attempts agree on.
    const votes = {};
    for (const r of results) { if (!r.last_name_en) continue; const k = r.last_name_en + '|' + r.first_name_en; votes[k] = (votes[k] || 0) + 1; }
    const pick = Object.keys(votes).sort((a, b) => votes[b] - votes[a] || b.length - a.length)[0];
    const best = Object.assign({}, good[0]);
    if (pick) { const [l, f] = pick.split('|'); best.last_name_en = l; best.first_name_en = f; best.name_votes = votes[pick]; } else best.name_votes = 0;
    return best;
  }

  /* ---------- Thai national ID card (front) ---------- */
  function validThaiId(cid) {
    if (!/^\d{13}$/.test(cid)) return false;
    let sum = 0;
    for (let i = 0; i < 12; i++) sum += Number(cid[i]) * (13 - i);
    return (11 - (sum % 11)) % 10 === Number(cid[12]);
  }
  const PREFIX_TH = ['เด็กชาย', 'เด็กหญิง', 'นางสาว', 'นาง', 'นาย', 'ด.ช.', 'ด.ญ.', 'น.ส.'];

  /**
   * The 13-digit ID number. Printed on the card as "1 2345 67890 12 3" on one line; digits are only joined
   * within a line (joining across lines, or sliding along a long run, finds a check-digit match in noise).
   */
  function findCid(text) {
    const lines = String(text || '').replace(/[OoQD]/g, '0').replace(/[Il|]/g, '1').split(/\n/);
    const grouped = /(?:^|[^\d])(\d)[ \t-]*(\d{4})[ \t-]*(\d{5})[ \t-]*(\d{2})[ \t-]*(\d)(?!\d)/;
    for (const l of lines) { const m = l.match(grouped); if (m) { const c = m.slice(1, 6).join(''); if (validThaiId(c)) return c; } }
    for (const l of lines) {
      for (const run of l.match(/\d[\d \t-]{11,20}\d/g) || []) {
        const d = run.replace(/\D/g, '');
        if (d.length === 13 && validThaiId(d)) return d;
      }
    }
    return '';
  }

  function parseThaiId(text) {
    const flat = String(text || '').replace(/\r/g, '');
    const out = { doc_type: 'thai_id' };
    const cid = findCid(flat);
    if (cid) out.cid = cid;
    const en = flat.match(/Name\s*[:.]?\s*(Mr|Mrs|Miss|Ms|Master)\.?[ \t]+([A-Za-z][A-Za-z-]+(?:[ \t][A-Za-z][A-Za-z-]+)?)/i);
    if (en) { out.prefix_en = en[1][0].toUpperCase() + en[1].slice(1).toLowerCase(); out.first_name_en = en[2].trim(); }
    const last = flat.match(/Last\s*name\s*[:.]?\s*([A-Za-z][A-Za-z-]+)/i);
    if (last) out.last_name_en = last[1];
    const thLine = flat.split('\n').find((l) => /ชื่อตัวและชื่อสกุล|ชื่อ-?สกุล/.test(l)) || flat.split('\n').find((l) => PREFIX_TH.some((p) => l.trim().startsWith(p))) || '';
    if (thLine) {
      const rest = thLine.replace(/.*(ชื่อตัวและชื่อสกุล|ชื่อ-?สกุล)\s*/, '').trim();
      const prefix = PREFIX_TH.find((p) => rest.startsWith(p));
      const words = (prefix ? rest.slice(prefix.length) : rest).trim().split(/\s+/).filter((w) => /^[฀-๿]+$/.test(w));
      if (prefix) out.prefix = prefix.replace('ด.ช.', 'เด็กชาย').replace('ด.ญ.', 'เด็กหญิง').replace('น.ส.', 'นางสาว');
      if (words.length >= 2) { out.first_name = words[0]; out.last_name = words.slice(1).join(' '); }
    }
    const dobEn = flat.match(/Date\s*of\s*Birth\s*[:.]?\s*(\d{1,2})\s*([A-Za-z]{3})[a-z]*\.?\s*(\d{4})/i);
    const dobTh = flat.match(/เกิดวันที่\s*(\d{1,2})\s*([฀-๿.]+?)\s*(\d{4})/);
    if (dobEn && MONTHS_EN[dobEn[2].toUpperCase()]) out.birthdate = iso(Number(dobEn[3]), MONTHS_EN[dobEn[2].toUpperCase()], Number(dobEn[1]));
    else if (dobTh) {
      const month = MONTHS_TH[dobTh[2]] || MONTHS_TH[dobTh[2].replace(/\.?$/, '.')];
      if (month) out.birthdate = iso(Number(dobTh[3]) - 543, month, Number(dobTh[1]));
    }
    const prefix = out.prefix || out.prefix_en || '';
    if (/^(นาย|เด็กชาย|Master|Mr(?!s))/i.test(prefix)) out.sex = 'male';
    else if (/^(นาง|นางสาว|เด็กหญิง|Mrs|Miss|Ms)/i.test(prefix)) out.sex = 'female';
    const addr = flat.match(/ที่อยู่\s*(.+(?:\n(?!.*(?:วันออกบัตร|Date of Issue|วันบัตรหมดอายุ)).+)?)/);
    if (addr) out.address = addr[1].replace(/\s*\n\s*/g, ' ').trim();
    return out;
  }

  /**
   * Thai name from the OCR words of the name line, split where the gap between words is widest.
   * Tesseract often puts spaces inside a Thai word ("ศุ ภ ชัย"), so splitting on spaces is not reliable;
   * on the card the gap between the first name and the last name is the wide one.
   * words: [{ text, bbox: { x0, x1 } }] in reading order. Returns { prefix, first_name, last_name } or null.
   */
  function thaiNameFromWords(words) {
    let t = (words || []).map((w) => ({ s: String(w.text || '').replace(/[^฀-๿.]/g, ''), x0: w.bbox ? w.bbox.x0 : 0, x1: w.bbox ? w.bbox.x1 : 0 })).filter((w) => w.s);
    // the label "ชื่อตัวและชื่อสกุล", however it was split into words
    if (t.length && t[0].s.startsWith('ชื่อ')) {
      let acc = '', cut = -1;
      for (let i = 0; i < t.length && acc.length < 24; i++) { acc += t[i].s; if (/สกุล$/.test(acc)) { cut = i + 1; break; } }
      if (cut > 0) t = t.slice(cut);
    }
    // the title, alone or stuck to the first name
    const head = t.slice(0, 3).map((w) => w.s).join('');
    const prefix = PREFIX_TH.find((x) => head.startsWith(x)) || '';
    let left = prefix.length;
    while (left > 0 && t.length) {
      if (t[0].s.length <= left) { left -= t[0].s.length; t.shift(); } else { t[0] = Object.assign({}, t[0], { s: t[0].s.slice(left) }); left = 0; }
    }
    if (t.length < 2) return null;
    let at = 1, gap = -Infinity;
    for (let i = 1; i < t.length; i++) { const g = t[i].x0 - t[i - 1].x1; if (g > gap) { gap = g; at = i; } }
    const first = t.slice(0, at).map((w) => w.s).join('').replace(/\.+$/, ''), last = t.slice(at).map((w) => w.s).join('').replace(/\.+$/, '');
    if (!first || !last) return null;
    return { prefix: prefix.replace('ด.ช.', 'เด็กชาย').replace('ด.ญ.', 'เด็กหญิง').replace('น.ส.', 'นางสาว'), first_name: first, last_name: last };
  }
  /**
   * Where to cut the name for a second reading: from just after the label "ชื่อตัวและชื่อสกุล" to the end of
   * the line, with room above and below for the vowels and tone marks. Tesseract reads the name far better
   * without the label in the picture. line: { bbox, words } from a first reading. Returns a box in the same pixels.
   */
  function thaiNameBox(line) {
    if (!line || !line.bbox) return null;
    const b = line.bbox, lh = Math.max(8, b.y1 - b.y0);
    const words = (line.words || []).filter((w) => w.bbox && String(w.text || '').trim());
    const skel = (s) => String(s || '').replace(/[^ก-ฮ]/g, ''); // consonants only: marks are what goes missing
    let start = b.x0;
    let acc = '';
    for (let i = 0; i < words.length; i++) {
      acc += skel(words[i].text);
      // "ชื่อตัวและชื่อสกุล" → ชอตวลชอสกล; accept a few misread letters
      if (acc.length >= 6 && acc.length <= 14 && /กล$|สกล$|สกุล$/.test(acc) && /^ช/.test(acc)) { start = words[i].bbox.x1; break; }
      if (acc.length > 14) break;
    }
    if (start === b.x0) {
      // no label found: start at the title if there is one
      const t = words.findIndex((w, i) => /^(นาย|นาง|เด็ก|ด\.|น\.)/.test(words.slice(i, i + 3).map((x) => x.text).join('')));
      if (t > 0) start = words[t].bbox.x0 - lh * 0.1;
    }
    // Height from the letters themselves (median top / bottom of the name's words), then room for the marks:
    // vowels and tone marks above reach about half a letter up, ุ ู below about 0.45. The line box is no guide:
    // it may or may not include marks the first reading missed.
    const name = words.filter((w) => w.bbox.x0 >= start - 1);
    const med = (a) => { const v = a.slice().sort((x, y) => x - y); return v.length ? v[Math.floor(v.length / 2)] : 0; };
    let top = name.length >= 3 ? med(name.map((w) => w.bbox.y0)) : b.y0, bot = name.length >= 3 ? med(name.map((w) => w.bbox.y1)) : b.y1;
    if (bot - top < 6) { top = b.y0; bot = b.y1; }
    const core = bot - top;
    return { x0: Math.max(0, start + core * 0.15), y0: Math.max(0, top - core * 0.7), x1: b.x1 + core * 0.6, y1: bot + core * 0.8, lh: core };
  }
  /** How many Thai vowel / tone marks written above or below a letter (ั ิ ี ึ ื ุ ู ฺ ็ ่ ้ ๊ ๋ ์ ํ). */
  function thaiMarks(s) { return (String(s || '').match(/[\u0E31\u0E34-\u0E3A\u0E47-\u0E4E]/g) || []).length; }
  return { parseMrz, bestMrz, parseThaiId, validThaiId, checkDigit, findCid, thaiMarks, thaiNameFromWords, thaiNameBox };
});
