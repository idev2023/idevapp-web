/* iDev Patient Registration — on-device OCR (Tesseract.js, loaded only when needed).
   Passport: several MRZ crops × thresholds, character whitelist, best result by check digits.
   Thai ID card: number band with digits only, then Thai + English text. Nothing is sent to a server. */
(function (root) {
  const P = root.IDevIdParse;

  /* ---------- image helpers (canvas) ---------- */
  const W = (s) => s.naturalWidth || s.videoWidth || s.width;
  const H = (s) => s.naturalHeight || s.videoHeight || s.height;
  function crop(src, x, y, w, h, targetW) {
    const sw = W(src), sh = H(src);
    const sx = Math.max(0, Math.round(x * sw)), sy = Math.max(0, Math.round(y * sh));
    const cw = Math.min(sw - sx, Math.round(w * sw)), ch = Math.min(sh - sy, Math.round(h * sh));
    const scale = targetW ? targetW / cw : 1;
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(cw * scale)); c.height = Math.max(1, Math.round(ch * scale));
    const ctx = c.getContext('2d');
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(src, sx, sy, cw, ch, 0, 0, c.width, c.height);
    return c;
  }
  function rotate180(src) {
    const c = document.createElement('canvas'); c.width = W(src); c.height = H(src);
    const ctx = c.getContext('2d'); ctx.translate(c.width, c.height); ctx.rotate(Math.PI); ctx.drawImage(src, 0, 0);
    return c;
  }
  /** A quarter turn: dir -1 = anticlockwise, 1 = clockwise. For a card photographed sideways. */
  function rotate90(src, dir) {
    const c = document.createElement('canvas'); c.width = H(src); c.height = W(src);
    const ctx = c.getContext('2d');
    if (dir < 0) { ctx.translate(0, c.height); ctx.rotate(-Math.PI / 2); } else { ctx.translate(c.width, 0); ctx.rotate(Math.PI / 2); }
    ctx.drawImage(src, 0, 0);
    return c;
  }
  /** Straightens a photo taken a few degrees off: the angle (−7°…7°) whose text rows line up best
      (largest variance of the row darkness on a small black & white copy). */
  function deskew(src) {
    // local black & white: letters are dark against what is around them; a dark table or background is not
    const small = binarize(crop(src, 0, 0, 1, 1, 700), 18, 0.012);
    const { g } = grayData(small);
    const w = small.width, h = small.height;
    const pts = [];
    for (let y = 0; y < h; y += 1) for (let x = 0; x < w; x += 1) if (g[y * w + x] < 128) pts.push(x - w / 2, y - h / 2);
    if (pts.length < 200) return src;
    let best = 0, bestScore = -1;
    for (let a = -7; a <= 7; a += 0.5) {
      const r = (a * Math.PI) / 180, sin = Math.sin(r), cos = Math.cos(r);
      const rows = new Float64Array(h * 2);
      for (let i = 0; i < pts.length; i += 2) { const yy = Math.round(pts[i] * sin + pts[i + 1] * cos + h); if (yy >= 0 && yy < rows.length) rows[yy]++; }
      let m = 0; for (const v of rows) m += v; m /= rows.length;
      let vsum = 0; for (const v of rows) vsum += (v - m) * (v - m);
      if (vsum > bestScore) { bestScore = vsum; best = a; }
    }
    if (typeof console !== "undefined" && root.IDEV_OCR_DEBUG) console.log("deskew", best);
    if (Math.abs(best) < 1) return src;
    const r = (best * Math.PI) / 180;
    const sw = W(src), sh = H(src);
    const c = document.createElement('canvas');
    c.width = Math.round(Math.abs(sw * Math.cos(r)) + Math.abs(sh * Math.sin(r)));
    c.height = Math.round(Math.abs(sw * Math.sin(r)) + Math.abs(sh * Math.cos(r)));
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
    ctx.translate(c.width / 2, c.height / 2); ctx.rotate(r); ctx.drawImage(src, -sw / 2, -sh / 2);
    return c;
  }
  function grayData(c) {
    const ctx = c.getContext('2d');
    const img = ctx.getImageData(0, 0, c.width, c.height);
    const g = new Uint8ClampedArray(c.width * c.height);
    for (let i = 0, j = 0; i < img.data.length; i += 4, j++) g[j] = 0.299 * img.data[i] + 0.587 * img.data[i + 1] + 0.114 * img.data[i + 2];
    return { ctx, img, g };
  }
  /** Contrast stretch (ignores 2% extremes) — good for Thai ID cards with a pattern background. */
  function contrast(c) {
    const { ctx, img, g } = grayData(c);
    const hist = new Uint32Array(256); g.forEach((v) => hist[v | 0]++);
    let lo = 0, hi = 255, acc = 0; const cut = g.length * 0.02;
    while (lo < 255 && (acc += hist[lo]) < cut) lo++;
    acc = 0; while (hi > 0 && (acc += hist[hi]) < cut) hi--;
    const k = 255 / Math.max(1, hi - lo);
    for (let j = 0, i = 0; j < g.length; j++, i += 4) { const v = Math.max(0, Math.min(255, (g[j] - lo) * k)); img.data[i] = img.data[i + 1] = img.data[i + 2] = v; }
    ctx.putImageData(img, 0, 0);
    return c;
  }
  /** Black & white with a local (adaptive) threshold: copes with shadows and glare on phone photos. */
  function binarize(c, bias = 12, radiusFactor = 0.02) {
    const { ctx, img, g } = grayData(c);
    const w = c.width, h = c.height;
    const r = Math.max(8, Math.round(Math.min(w, h) * radiusFactor * 2.5));
    const ii = new Float64Array((w + 1) * (h + 1)); // integral image
    for (let y = 1; y <= h; y++) { let row = 0; for (let x = 1; x <= w; x++) { row += g[(y - 1) * w + x - 1]; ii[y * (w + 1) + x] = ii[(y - 1) * (w + 1) + x] + row; } }
    for (let y = 0; y < h; y++) {
      const y0 = Math.max(0, y - r), y1 = Math.min(h, y + r + 1);
      for (let x = 0; x < w; x++) {
        const x0 = Math.max(0, x - r), x1 = Math.min(w, x + r + 1);
        const sum = ii[y1 * (w + 1) + x1] - ii[y0 * (w + 1) + x1] - ii[y1 * (w + 1) + x0] + ii[y0 * (w + 1) + x0];
        const mean = sum / ((x1 - x0) * (y1 - y0));
        const v = g[y * w + x] < mean - bias ? 0 : 255;
        const i = (y * w + x) * 4; img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
      }
    }
    ctx.putImageData(img, 0, 0);
    return c;
  }
  /** Variance of the Laplacian on a small grey copy: higher = sharper. Used by the camera to wait for focus. */
  function sharpness(src, x = 0.1, y = 0.1, w = 0.8, h = 0.8) {
    const c = crop(src, x, y, w, h, 320);
    const { g } = grayData(c);
    const cw = c.width, ch = c.height;
    let n = 0, mean = 0, m2 = 0;
    for (let yy = 1; yy < ch - 1; yy++) for (let xx = 1; xx < cw - 1; xx++) {
      const i = yy * cw + xx;
      const lap = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - cw] - g[i + cw];
      n++; const d = lap - mean; mean += d / n; m2 += d * (lap - mean);
    }
    return n ? m2 / n : 0;
  }

  const MRZ_BANDS = [[0.70, 0.30], [0.62, 0.38], [0.76, 0.24], [0.52, 0.48]];
  /** Image variants to read, most likely first: the usual band (normal, then upside down), then the others. */
  function* mrzSequence(src) {
    let flipped = null;
    const flip = () => flipped || (flipped = rotate180(src));
    const make = (img, [y, h], bw) => (bw ? binarize(crop(img, 0, y, 1, h, 1800)) : contrast(crop(img, 0, y, 1, h, 1800)));
    yield make(src, MRZ_BANDS[0], true); yield make(src, MRZ_BANDS[0], false);
    yield make(flip(), MRZ_BANDS[0], true);
    for (const band of MRZ_BANDS.slice(1)) { yield make(src, band, true); yield make(src, band, false); }
    yield make(flip(), MRZ_BANDS[0], false);
    for (const band of MRZ_BANDS.slice(1)) { yield make(flip(), band, true); yield make(flip(), band, false); }
  }
  function mrzVariants(src) { return Array.from(mrzSequence(src)); }

  /* ---------- engine ---------- */
  let loading = null;
  function loadEngine(cfg) {
    if (root.Tesseract) return Promise.resolve(root.Tesseract);
    if (!loading) loading = new Promise((resolve, reject) => {
      const s = document.createElement('script'); s.src = cfg.script; s.async = true;
      s.onload = () => resolve(root.Tesseract); s.onerror = reject; document.head.appendChild(s);
    });
    return loading;
  }
  async function worker(cfg, langs, logger) {
    const T = await loadEngine(cfg);
    const opts = { logger };
    if (cfg.workerPath) opts.workerPath = cfg.workerPath;
    if (cfg.corePath) opts.corePath = cfg.corePath;
    if (cfg.langPath) opts.langPath = cfg.langPath;
    return T.createWorker(langs, 1, opts);
  }

  /**
   * Reads a document. type: 'passport' | 'thai_id'. progress(0..1).
   * Returns parsed fields (see IDevIdParse) or null.
   */
  async function read(cfg, src, type, progress) {
    const step = (p) => progress && progress(Math.min(1, p));
    if (type === 'passport') {
      const w = await worker(cfg, 'eng', () => {});
      try {
        await w.setParameters({ tessedit_char_whitelist: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<', tessedit_pageseg_mode: '6', preserve_interword_spaces: '0' });
        const texts = [];
        const total = 16;
        let i = 0;
        for (const img of mrzSequence(src)) {
          step(++i / total);
          const { data } = await w.recognize(img);
          texts.push(data.text || '');
          const best = P.bestMrz(texts);
          // Good enough: line 2 passes its check digits and two readings agree on the name.
          if (best && best.score >= 4 && (best.name_votes >= 2 || (i >= 4 && best.name_votes >= 1))) return best;
          if (i >= 8 && best && best.score >= 3) return best;
        }
        return P.bestMrz(texts);
      } finally { await w.terminate(); }
    }
    // Thai ID card: 1) the big number near the top, digits only; 2) the whole card in Thai + English.
    const out = {};
    // a tall photo means the card was photographed sideways: of the two quarter turns, keep the one where the
    // English words printed on the card read (a 13-digit number with a good check digit can come out of noise)
    const wd = await worker(cfg, 'eng', () => {});
    try {
      if (H(src) > W(src) * 1.15) {
        let best = -1, pick = null;
        for (const img of [rotate90(src, -1), rotate90(src, 1)]) {
          await wd.setParameters({ tessedit_char_whitelist: '', tessedit_pageseg_mode: '3' });
          const { data } = await wd.recognize(contrast(crop(img, 0, 0, 1, 1, 1000)));
          const hits = ((data.text || '').match(/Thai|National|Identification|Number|Name|Last|Date|Birth|Issue|Expiry|Card/gi) || []).length;
          if (hits > best) { best = hits; pick = img; }
        }
        src = pick;
      }
      src = deskew(src);
      await wd.setParameters({ tessedit_char_whitelist: '0123456789 ', tessedit_pageseg_mode: '6' });
      for (const [y, h] of [[0.08, 0.22], [0.04, 0.32]]) {
        step(y === 0.08 ? 0.15 : 0.3);
        const { data } = await wd.recognize(binarize(crop(src, 0.25, y, 0.75, h, 1600)));
        const cid = P.findCid(data.text);
        if (cid) { out.cid = cid; break; }
      }
    } finally { await wd.terminate(); }
    const wt = await worker(cfg, 'tha+eng', (m) => { if (m.status === 'recognizing text') step(0.35 + m.progress * 0.45); });
    let r, lines = [], card;
    try {
      card = crop(src, 0, 0, 1, 1, 1600);
      const { data } = await wt.recognize(contrast(crop(card, 0, 0, 1, 1)), {}, { text: true, blocks: true });
      r = P.parseThaiId(data.text || '');
      lines = data.lines || [];
    } finally { await wt.terminate(); }
    const isNameLine = (l) => /ชื่อตัว|ชื่อ\s*-?\s*สกุล|ชื่อสกุล/.test((l.text || '').replace(/\s+/g, ''));
    // or, when the label was misread, the line in the top half with a title (not the officer's name at the bottom)
    const titled = (l) => /(นาย|นางสาว|นาง|เด็กชาย|เด็กหญิง|ด\.ช\.|ด\.ญ\.)\s*[\u0E01-\u0E2E]/.test((l.text || '').replace(/\s+/g, ''))
      && !/[()]|เกิด|ศาสนา|ที่อยู่/.test(l.text || '') && l.bbox && l.bbox.y0 < H(card) * 0.5;
    const line = lines.find(isNameLine) || lines.find(titled);
    // first and last name split at the widest gap on the card, not at any space Tesseract put inside a word
    if (line && line.words) { const n = P.thaiNameFromWords(line.words); if (n) { r.first_name = n.first_name; r.last_name = n.last_name; if (n.prefix) r.prefix = n.prefix; } }
    // 2) The name alone, without the label and enlarged: read like this, Tesseract keeps the small vowels and
    //    tone marks it drops on a whole-card reading. Several pictures; the name most of them agree on wins.
    const box = P.thaiNameBox(line);
    if (box) {
      step(0.8);
      const cw = W(card), ch = H(card);
      const x1 = Math.min(cw, box.x1), y1 = Math.min(ch, box.y1);
      const scale = Math.max(1, Math.min(4, 70 / box.lh)); // letters about 70 px high
      // cut from the photo itself (not the 1600 px copy) so the small marks keep every pixel they have
      const strip = crop(src, box.x0 / cw, box.y0 / ch, (x1 - box.x0) / cw, (y1 - box.y0) / ch, Math.round((x1 - box.x0) * scale));
      const wl = await worker(cfg, 'tha', () => {});
      const votes = {};
      try {
        const runs = [['7', () => strip], ['6', () => strip], ['7', () => contrast(crop(strip, 0, 0, 1, 1))]];
        for (let i = 0; i < runs.length; i++) {
          step(0.83 + i * 0.05);
          await wl.setParameters({ tessedit_pageseg_mode: runs[i][0] });
          const { data } = await wl.recognize(runs[i][1](), {}, { text: true, blocks: true });
          // psm 6 may also read a bit of the lines above / below: use the line with a title or the most Thai
          const ls = (data.lines || []).filter((l) => /[ก-ฮ]/.test(l.text || ''));
          const best = ls.find((l) => /^\s*(นาย|นาง|เด็ก|ด\.|น\.)/.test(l.text || '')) || ls.sort((a, b) => (b.text || '').length - (a.text || '').length)[0];
          const n = (best && P.thaiNameFromWords(best.words)) || P.parseThaiId('ชื่อตัวและชื่อสกุล ' + ((best && best.text) || data.text || ''));
          if (!n || !n.first_name || !n.last_name) continue;
          const k = n.first_name + ' ' + n.last_name;
          votes[k] = votes[k] || { n, c: 0 }; votes[k].c++;
          if (i === 1 && votes[k].c === 2) break; // the first two agree: no need for a third
        }
      } finally { await wl.terminate(); }
      const pick = Object.values(votes).sort((a, b) => b.c - a.c || P.thaiMarks(b.n.first_name + b.n.last_name) - P.thaiMarks(a.n.first_name + a.n.last_name))[0];
      if (pick) { r.first_name = pick.n.first_name; r.last_name = pick.n.last_name; if (pick.n.prefix) r.prefix = pick.n.prefix; }
      if (/^(นาย|เด็กชาย)/.test(r.prefix || '')) r.sex = 'male'; else if (/^(นาง|เด็กหญิง)/.test(r.prefix || '')) r.sex = 'female';
    }
    step(1);
    // two readings of the number that disagree: Thai IDs for Thai citizens start with 1–8, a leading 0 is more often noise
    if (out.cid && r.cid && out.cid !== r.cid && out.cid[0] === '0' && r.cid[0] !== '0') out.cid = r.cid;
    return Object.assign(r, out.cid ? { cid: out.cid } : {});
  }

  root.IDevOcr = { read, crop, binarize, contrast, sharpness, mrzVariants, rotate180, rotate90 };
})(typeof self !== 'undefined' ? self : this);
