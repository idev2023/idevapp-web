=== iDevApp Website ===
Contributors: idevapp
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.0.11
License: GPLv2 or later

ระบบเว็บไซต์ครบชุดในปลั๊กอินเดียว: ตัวช่วยตั้งค่าเว็บไซต์ ธีมแบบที่ 1 / แบบที่ 2 ประกาศข่าว (ตั้งเวลา อ่าน PDF อนุมัติ) และโมดูลที่เปิด / ปิดได้

ติดตั้ง: ปลั๊กอิน → เพิ่มใหม่ → อัปโหลดปลั๊กอิน → เลือก idevapp-website.zip → เปิดใช้งาน แล้วทำตามตัวช่วยตั้งค่า
อัปเดต: อัตโนมัติภายใน 12 ชั่วโมงจาก GitHub ของ iDevApp หรือกดที่ iDevApp Website → อัปเดต

พัฒนาโดย iDevApp · https://idevapp.me/
