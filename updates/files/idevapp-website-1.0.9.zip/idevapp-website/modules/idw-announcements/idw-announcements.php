<?php
/**
 * Module: ประกาศข่าว
 * One form for every announcement: หมวด · หัวเรื่อง · สรุป · รายละเอียด · รูปปก · ไฟล์แนบ
 *  - publish now or at a set date and time, and hide it again automatically at a set time
 *  - read a PDF (text or scanned) and fill in the title, summary and details, attach the PDF, use page 1 as the cover
 *  - approval: news from people without approval rights waits for a news approver (can be switched off)
 * Announcements are ordinary WordPress posts, so every theme shows them.
 */
defined('ABSPATH') || exit;
if (defined('IDW_ANN_VERSION')) return;
define('IDW_ANN_VERSION', defined('IDW_VERSION') ? IDW_VERSION : '1.0.0');
define('IDW_ANN_URL', plugin_dir_url(__FILE__));

/* ---------- settings & rights ---------- */

function idw_ann_settings() {
    $d = ['approval' => '1', 'pdf' => '1', 'ocr' => '1', 'cover' => '1', 'notify' => '1', 'default_cat' => 0,
        'news_months' => (int) get_theme_mod('hos_news_months', 6), 'slide_months' => (int) get_theme_mod('hos_slide_months', 6), // earlier sites kept these in the theme
        'pdf_body' => '0', 'sum_words' => 50];
    return wp_parse_args((array) get_option('idw_ann', []), $d);
}
/** อายุสูงสุด (เดือน) ของข่าวบนหน้าแรก / ภาพสไลด์ · 0 = แสดงทั้งหมด — ใช้ได้ทุกธีม */
function idw_ann_months($kind = 'news') {
    $s = idw_ann_settings();
    return max(0, min(120, (int) ($kind === 'slide' ? $s['slide_months'] : $s['news_months'])));
}
function idw_ann_can_approve($user_id = null) { return $user_id ? user_can($user_id, 'idw_news_approve') : current_user_can('idw_news_approve'); }
/** Does news by this user need approval? */
function idw_ann_needs_approval() { return idw_ann_settings()['approval'] === '1' && !idw_ann_can_approve(); }

function idw_ann_install() {
    foreach (['administrator', 'editor'] as $r) { $role = get_role($r); if ($role) $role->add_cap('idw_news_approve'); }
    if (!wp_next_scheduled('idw_ann_expire')) wp_schedule_event(time() + 60, 'hourly', 'idw_ann_expire');
}
register_activation_hook(__FILE__, 'idw_ann_install');
add_action('admin_init', function () { if (get_option('idw_ann_v') !== '1') { idw_ann_install(); update_option('idw_ann_v', '1'); } });

add_filter('ihub_rbac_caps', function ($g) {
    $k = 'ข่าวสาร ตารางออกตรวจ และเครื่องมือเว็บไซต์';
    if (isset($g[$k])) $g[$k] = ['idw_news_approve' => ['อนุมัติประกาศข่าว (ผู้ดูแลข่าว)', 'ประกาศจะแสดงบนเว็บเมื่อผู้มีสิทธิ์นี้อนุมัติ']] + $g[$k];
    return $g;
});

/* Every post written by someone who needs approval waits for it — also edits of published news, from any screen. */
add_filter('wp_insert_post_data', function ($data) {
    if (($data['post_type'] ?? '') !== 'post' || !get_current_user_id() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) return $data;
    if (in_array($data['post_status'], ['publish', 'future'], true) && idw_ann_needs_approval()) $data['post_status'] = 'pending';
    return $data;
}, 20);

add_action('transition_post_status', function ($new, $old, $post) {
    if ($post->post_type !== 'post' || $new === $old) return;
    if ($new === 'pending') {
        update_post_meta($post->ID, '_idw_ann_sent', time());
        delete_post_meta($post->ID, '_idw_ann_note');
        if (idw_ann_settings()['notify'] !== '1') return;
        $to = array_values(array_filter(array_map('strval', (array) get_users(['capability' => 'idw_news_approve', 'fields' => 'user_email'])), 'is_email'));
        foreach (array_slice($to, 0, 20) as $addr) wp_mail($addr, '[ข่าวรออนุมัติ] ' . $post->post_title, "มีประกาศรออนุมัติ: {$post->post_title}\nโดย " . get_the_author_meta('display_name', $post->post_author) . "\n\nตรวจและอนุมัติ: " . admin_url('admin.php?page=idw-news&tab=review'));
    }
    if (in_array($new, ['publish', 'future'], true)) delete_post_meta($post->ID, '_idw_ann_expired');
}, 10, 3);

/* Hide automatically when the "show until" time has passed. */
add_action('idw_ann_expire', 'idw_ann_run_expiry');
function idw_ann_run_expiry() {
    $ids = get_posts(['post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 100, 'fields' => 'ids', 'meta_query' => [['key' => '_idw_ann_expire', 'value' => time(), 'compare' => '<=', 'type' => 'NUMERIC']]]); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
    foreach ($ids as $id) {
        wp_update_post(['ID' => $id, 'post_status' => 'draft']);
        update_post_meta($id, '_idw_ann_expired', time());
        delete_post_meta($id, '_idw_ann_expire');
    }
}
/* Also catch it on page views between cron runs (cheap: one query every 10 minutes). */
add_action('init', function () {
    if (get_transient('idw_ann_exp_check')) return;
    set_transient('idw_ann_exp_check', 1, 10 * MINUTE_IN_SECONDS);
    idw_ann_run_expiry();
}, 99);

/* ---------- helpers ---------- */

function idw_ann_attach_key() { return (function_exists('idw_module_on') && idw_module_on('attachments')) || defined('IDEV_PA_VERSION') ? '_idev_attachments' : 'ihub_attachments'; }
function idw_ann_get_files($post_id) {
    $list = json_decode((string) get_post_meta($post_id, idw_ann_attach_key(), true), true);
    $out = [];
    foreach (is_array($list) ? $list : [] as $f) {
        $id = (int) ($f['id'] ?? 0);
        if ($id && get_post_type($id) === 'attachment') $out[] = ['id' => $id, 'label' => (string) ($f['label'] ?? ''), 'name' => wp_basename((string) get_attached_file($id)), 'url' => wp_get_attachment_url($id)];
    }
    return $out;
}
function idw_ann_template($term_id) {
    foreach (['idw_news_template', 'ihub_news_template'] as $k) { $t = (string) get_term_meta($term_id, $k, true); if ($t !== '') return $t; }
    return '<h3>รายละเอียด</h3><p>…</p><h3>วัน เวลา และสถานที่</h3><p>…</p><h3>ติดต่อสอบถาม</h3><p>โทร …</p>';
}
function idw_ann_dt($ts, $with_time = true) {
    $ts = (int) $ts;
    if (function_exists('idev_format_datetime')) return idev_format_datetime(wp_date($with_time ? 'Y-m-d H:i' : 'Y-m-d', $ts));
    return wp_date($with_time ? 'j M Y H:i' : 'j M Y', $ts);
}
function idw_ann_counts() {
    $c = wp_count_posts('post');
    return ['publish' => (int) ($c->publish ?? 0), 'future' => (int) ($c->future ?? 0), 'pending' => (int) ($c->pending ?? 0), 'draft' => (int) ($c->draft ?? 0), 'trash' => (int) ($c->trash ?? 0)];
}
/** Local "Y-m-d H:i" from a date and a time field, or ''. */
function idw_ann_local($date, $time) {
    $date = sanitize_text_field($date); $time = sanitize_text_field($time ?: '00:00');
    $d = DateTime::createFromFormat('Y-m-d H:i', $date . ' ' . substr($time, 0, 5), wp_timezone());
    return $d ? $d->format('Y-m-d H:i:s') : '';
}

/* ---------- menu ---------- */

add_action('admin_menu', function () {
    $n = idw_ann_can_approve() ? idw_ann_counts()['pending'] : 0;
    add_menu_page('ประกาศข่าว', 'ประกาศข่าว' . ($n ? ' <span class="awaiting-mod">' . $n . '</span>' : ''), 'edit_posts', 'idw-news', 'idw_ann_page', 'dashicons-megaphone', 3);
    add_submenu_page('idw-news', 'เขียนประกาศ', 'เขียนประกาศ', 'edit_posts', 'idw-news', 'idw_ann_page');
    add_submenu_page('idw-news', 'ประกาศทั้งหมด', 'ประกาศทั้งหมด', 'edit_posts', 'idw-news&tab=list', '__return_null');
    if (idw_ann_can_approve()) add_submenu_page('idw-news', 'รออนุมัติ', 'รออนุมัติ' . ($n ? ' <span class="awaiting-mod">' . $n . '</span>' : ''), 'edit_posts', 'idw-news&tab=review', '__return_null');
    add_submenu_page('idw-news', 'หมวดข่าว', 'หมวดข่าว', 'manage_categories', 'edit-tags.php?taxonomy=category');
    add_submenu_page('idw-news', 'ตั้งค่าประกาศข่าว', 'ตั้งค่า', 'manage_options', 'idw-news&tab=settings', '__return_null');
});
/* submenu items with a tab: keep the menu open on the right item */
add_filter('submenu_file', function ($file, $parent) {
    if ($parent !== 'idw-news' || ($_GET['page'] ?? '') !== 'idw-news') return $file; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $tab = sanitize_key($_GET['tab'] ?? 'write'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    return in_array($tab, ['list', 'review', 'settings'], true) ? 'idw-news&tab=' . $tab : 'idw-news';
}, 10, 2);

/* category screen: article template */
add_action('category_edit_form_fields', function ($term) {
    echo '<tr class="form-field"><th scope="row"><label>แม่แบบเนื้อหาประกาศ</label></th><td>';
    wp_editor(idw_ann_template($term->term_id), 'idw_news_template', ['textarea_name' => 'idw_news_template', 'textarea_rows' => 8, 'media_buttons' => false]);
    echo '<p class="description">ข้อความเริ่มต้นของ “รายละเอียด” เมื่อเขียนประกาศในหมวดนี้</p></td></tr>';
});
add_action('edited_category', function ($term_id) {
    if (!current_user_can('manage_categories') || !isset($_POST['idw_news_template'])) return; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- term screen checks its nonce
    update_term_meta($term_id, 'idw_news_template', wp_kses_post(wp_unslash($_POST['idw_news_template']))); // phpcs:ignore WordPress.Security.NonceVerification.Missing
});

/* ---------- saving ---------- */

add_action('admin_post_idw_ann_save', function () {
    if (!current_user_can('edit_posts') || !check_admin_referer('idw_ann_save')) wp_die('ไม่มีสิทธิ์', 403);
    $id = (int) ($_POST['post_id'] ?? 0);
    if ($id && (!current_user_can('edit_post', $id) || get_post_type($id) !== 'post')) wp_die('ไม่มีสิทธิ์', 403);
    $back = admin_url('admin.php?page=idw-news');
    $title = sanitize_text_field(wp_unslash($_POST['title'] ?? ''));
    $cat = (int) ($_POST['cat'] ?? 0);
    if ($title === '' || !$cat || !term_exists($cat, 'category')) { wp_safe_redirect(add_query_arg(['tab' => 'write', 'post' => $id, 'err' => 'need'], $back)); exit; }
    $go = sanitize_key($_POST['go'] ?? 'draft');
    $send = $go === 'send';
    $arr = ['post_type' => 'post', 'post_title' => $title, 'post_excerpt' => sanitize_textarea_field(wp_unslash($_POST['summary'] ?? '')), 'post_content' => wp_kses_post(wp_unslash($_POST['details'] ?? '')), 'post_category' => [$cat]];
    $arr['post_status'] = $send ? (idw_ann_needs_approval() ? 'pending' : 'publish') : 'draft';
    // when: now or a set date and time
    $when = sanitize_key($_POST['when'] ?? 'now');
    $local = $when === 'later' ? idw_ann_local(wp_unslash($_POST['pub_date'] ?? ''), wp_unslash($_POST['pub_time'] ?? '')) : '';
    if ($local !== '') {
        $arr['post_date'] = $local;
        $arr['post_date_gmt'] = get_gmt_from_date($local);
        $arr['edit_date'] = true;
    } elseif ($id && get_post_status($id) === 'future') {
        $arr['post_date'] = current_time('mysql');
        $arr['post_date_gmt'] = current_time('mysql', true);
        $arr['edit_date'] = true;
    }
    if ($id) { $arr['ID'] = $id; $id = wp_update_post(wp_slash($arr), true); } else { $id = wp_insert_post(wp_slash($arr), true); }
    if (is_wp_error($id)) wp_die(esc_html($id->get_error_message()));
    // show until
    $exp = !empty($_POST['expire_on']) ? idw_ann_local(wp_unslash($_POST['exp_date'] ?? ''), wp_unslash($_POST['exp_time'] ?? '')) : '';
    if ($exp !== '') update_post_meta($id, '_idw_ann_expire', (int) get_gmt_from_date($exp, 'U')); else delete_post_meta($id, '_idw_ann_expire');
    // pin to the top
    if (current_user_can('edit_others_posts')) { if (!empty($_POST['sticky'])) stick_post($id); else unstick_post($id); }
    $cover = (int) ($_POST['cover'] ?? 0);
    if ($cover && get_post_type($cover) === 'attachment') set_post_thumbnail($id, $cover); elseif (!$cover) delete_post_thumbnail($id);
    $files = [];
    foreach (array_map('intval', (array) ($_POST['files'] ?? [])) as $i => $fid) {
        if ($fid && get_post_type($fid) === 'attachment') {
            $files[] = ['id' => $fid, 'label' => mb_substr(sanitize_text_field(wp_unslash($_POST['file_labels'][$i] ?? '')), 0, 200), 'label_en' => ''];
            if (!wp_get_post_parent_id($fid)) wp_update_post(['ID' => $fid, 'post_parent' => $id]);
        }
    }
    update_post_meta($id, idw_ann_attach_key(), wp_slash(wp_json_encode($files, JSON_UNESCAPED_UNICODE)));
    if (!empty($_POST['from_pdf'])) update_post_meta($id, '_idw_ann_from_pdf', 1);
    $real = get_post_status($id);
    wp_safe_redirect(add_query_arg(['tab' => 'list', 'done' => $real, 'id' => $id], $back));
    exit;
});

/** Small form button: trash / restore / delete one announcement. */
function idw_ann_del_button($id, $do, $label, $class, $confirm = '') {
    return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="ann-inline"' . ($confirm ? ' onsubmit="return confirm(' . esc_attr(wp_json_encode($confirm)) . ')"' : '') . '>' . wp_nonce_field('idw_ann_del_' . $id, '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_ann_del"><input type="hidden" name="post_id" value="' . (int) $id . '"><input type="hidden" name="do" value="' . esc_attr($do) . '"><button class="' . esc_attr($class) . '">' . esc_html($label) . '</button></form>';
}
add_action('admin_post_idw_ann_del', function () {
    $id = (int) ($_POST['post_id'] ?? 0);
    if (!$id || get_post_type($id) !== 'post' || !current_user_can('delete_post', $id) || !check_admin_referer('idw_ann_del_' . $id)) wp_die('ไม่มีสิทธิ์', 403);
    $do = sanitize_key($_POST['do'] ?? 'trash');
    $title = get_the_title($id);
    if ($do === 'restore') { wp_untrash_post($id); $done = 'restored'; }
    elseif ($do === 'delete' && get_post_status($id) === 'trash') {
        // files that were attached only to this announcement go with it
        foreach (idw_ann_get_files($id) as $f) if ((int) wp_get_post_parent_id($f['id']) === $id) wp_delete_attachment($f['id'], true);
        wp_delete_post($id, true);
        $done = 'deleted';
    } else { wp_trash_post($id); $done = 'trashed'; }
    if (function_exists('idw_sec_log')) idw_sec_log('setting', ['trashed' => 'ลบประกาศ (ถังขยะ): ', 'restored' => 'กู้คืนประกาศ: ', 'deleted' => 'ลบประกาศถาวร: '][$done] . $title);
    wp_safe_redirect(admin_url('admin.php?page=idw-news&tab=list&done=' . $done . ($done === 'restored' ? '' : '&status=' . ($done === 'trashed' ? '' : 'trash'))));
    exit;
});

add_action('admin_post_idw_ann_review', function () {
    $id = (int) ($_POST['post_id'] ?? 0);
    if (!idw_ann_can_approve() || !check_admin_referer('idw_ann_review_' . $id) || get_post_type($id) !== 'post') wp_die('ไม่มีสิทธิ์', 403);
    $post = get_post($id);
    $author = get_userdata($post->post_author);
    $me = wp_get_current_user()->display_name;
    if (($_POST['decision'] ?? '') === 'approve') {
        wp_update_post(['ID' => $id, 'post_status' => 'publish']);
        update_post_meta($id, '_idw_ann_approved', ['by' => $me, 'at' => time()]);
        $st = get_post_status($id);
        if ($author && $author->user_email && idw_ann_settings()['notify'] === '1') wp_mail($author->user_email, '[อนุมัติแล้ว] ' . $post->post_title, "ประกาศ “{$post->post_title}” ได้รับการอนุมัติแล้ว" . ($st === 'future' ? ' จะแสดงบนเว็บเมื่อ ' . idw_ann_dt(get_post_timestamp($id)) : ' และแสดงบนเว็บแล้ว') . "\n" . get_permalink($id));
        $done = 'approved';
    } else {
        $note = sanitize_textarea_field(wp_unslash($_POST['note'] ?? ''));
        wp_update_post(['ID' => $id, 'post_status' => 'draft']);
        update_post_meta($id, '_idw_ann_note', ['by' => $me, 'at' => time(), 'text' => $note]);
        if ($author && $author->user_email && idw_ann_settings()['notify'] === '1') wp_mail($author->user_email, '[ส่งกลับแก้ไข] ' . $post->post_title, "ประกาศ “{$post->post_title}” ถูกส่งกลับให้แก้ไข\n\n{$note}\n\nแก้ไข: " . admin_url('admin.php?page=idw-news&tab=write&post=' . $id));
        $done = 'returned';
    }
    wp_safe_redirect(admin_url('admin.php?page=idw-news&tab=review&done=' . $done));
    exit;
});

add_action('admin_post_idw_ann_settings', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_ann_settings')) wp_die('ไม่มีสิทธิ์', 403);
    $s = [];
    foreach (['approval', 'pdf', 'ocr', 'cover', 'notify', 'pdf_body'] as $k) $s[$k] = empty($_POST[$k]) ? '0' : '1';
    $s['default_cat'] = (int) ($_POST['default_cat'] ?? 0);
    $s['news_months'] = max(0, min(120, (int) ($_POST['news_months'] ?? 6)));
    $s['slide_months'] = max(0, min(120, (int) ($_POST['slide_months'] ?? 6)));
    $s['sum_words'] = max(10, min(300, (int) ($_POST['sum_words'] ?? 50)));
    do_action('litespeed_purge_all');
    update_option('idw_ann', $s);
    wp_safe_redirect(admin_url('admin.php?page=idw-news&tab=settings&done=saved'));
    exit;
});

/* ---------- pages ---------- */

function idw_ann_page() {
    if (!current_user_can('edit_posts')) wp_die('ไม่มีสิทธิ์');
    $approver = idw_ann_can_approve();
    $c = idw_ann_counts();
    $tab = sanitize_key($_GET['tab'] ?? 'write'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if ($tab === 'review' && !$approver) $tab = 'list';
    if ($tab === 'settings' && !current_user_can('manage_options')) $tab = 'list';
    $tabs = ['write' => ['เขียนประกาศ', 'dashicons-edit'], 'list' => ['ประกาศทั้งหมด', 'dashicons-list-view']];
    if ($approver) $tabs['review'] = ['รออนุมัติ', 'dashicons-yes-alt'];
    if (current_user_can('manage_options')) $tabs['settings'] = ['ตั้งค่า', 'dashicons-admin-generic'];
    echo '<div class="wrap idw ann"><div class="ann-head"><div class="ann-title"><span class="ann-logo dashicons dashicons-megaphone"></span><div><h1>ประกาศข่าว</h1><p>เขียนครั้งเดียว แสดงบนเว็บตามเวลาที่ตั้ง — ' . ($approver ? 'คุณเป็นผู้ดูแลข่าว เผยแพร่ได้ทันที' : (idw_ann_needs_approval() ? 'ประกาศจะแสดงเมื่อผู้ดูแลข่าวอนุมัติ' : 'เผยแพร่ได้ทันที')) . '</p></div></div>';
    echo '<div class="ann-stats"><a href="' . esc_url(admin_url('admin.php?page=idw-news&tab=list&status=publish')) . '"><b>' . (int) $c['publish'] . '</b><span>เผยแพร่</span></a><a href="' . esc_url(admin_url('admin.php?page=idw-news&tab=list&status=future')) . '" class="i"><b>' . (int) $c['future'] . '</b><span>ตั้งเวลา</span></a><a href="' . esc_url(admin_url('admin.php?page=idw-news&tab=' . ($approver ? 'review' : 'list&status=pending'))) . '" class="w"><b>' . (int) $c['pending'] . '</b><span>รออนุมัติ</span></a><a href="' . esc_url(admin_url('admin.php?page=idw-news&tab=list&status=draft')) . '" class="d"><b>' . (int) $c['draft'] . '</b><span>ร่าง</span></a></div></div>';
    echo '<nav class="ann-tabs">';
    foreach ($tabs as $k => [$l, $ic]) echo '<a class="' . ($k === $tab ? 'on' : '') . '" href="' . esc_url(admin_url('admin.php?page=idw-news&tab=' . $k)) . '"><span class="dashicons ' . esc_attr($ic) . '"></span>' . esc_html($l) . ($k === 'review' && $c['pending'] ? ' <i>' . (int) $c['pending'] . '</i>' : '') . '</a>';
    echo '<a class="new" href="' . esc_url(admin_url('admin.php?page=idw-news&tab=write')) . '"><span class="dashicons dashicons-plus-alt2"></span>ประกาศใหม่</a></nav><hr class="wp-header-end">';
    $done = sanitize_key($_GET['done'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $msgs = ['pending' => 'ส่งขออนุมัติแล้ว — จะแสดงบนเว็บเมื่อผู้ดูแลข่าวอนุมัติ', 'draft' => 'บันทึกร่างแล้ว', 'publish' => 'เผยแพร่แล้ว', 'future' => 'ตั้งเวลาเผยแพร่แล้ว', 'approved' => 'อนุมัติแล้ว', 'returned' => 'ส่งกลับให้ผู้เขียนแก้ไขแล้ว', 'saved' => 'บันทึกการตั้งค่าแล้ว', 'trashed' => 'ย้ายไปถังขยะแล้ว — กู้คืนได้ที่แท็บ “ถังขยะ”', 'restored' => 'กู้คืนแล้ว (เป็นฉบับร่าง)', 'deleted' => 'ลบถาวรแล้ว'];
    if (isset($msgs[$done])) {
        $extra = '';
        $pid = (int) ($_GET['id'] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ($pid && $done === 'future') $extra = ' · จะแสดงเมื่อ ' . idw_ann_dt(get_post_timestamp($pid));
        if ($pid && $done === 'publish') $extra = ' · <a href="' . esc_url(get_permalink($pid)) . '" target="_blank">ดูบนเว็บ ↗</a>';
        echo '<div class="ann-toast"><span class="dashicons dashicons-yes"></span>' . esc_html($msgs[$done]) . wp_kses_post($extra) . '</div>';
    }
    if (($_GET['err'] ?? '') === 'need') echo '<div class="ann-toast err"><span class="dashicons dashicons-warning"></span>กรุณาเลือกหมวดข่าวและใส่หัวเรื่อง</div>'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if ($tab === 'review') idw_ann_review_tab();
    elseif ($tab === 'list') idw_ann_list_tab();
    elseif ($tab === 'settings') idw_ann_settings_tab();
    else idw_ann_form();
    echo '<p class="ann-foot">ประกาศข่าว · iDevApp Website · พัฒนาโดย <a href="https://idevapp.me/" target="_blank" rel="noopener">iDevApp</a></p></div>';
}

function idw_ann_form() {
    $id = (int) ($_GET['post'] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $post = $id ? get_post($id) : null;
    if ($post && ($post->post_type !== 'post' || !current_user_can('edit_post', $id))) $post = null;
    $set = idw_ann_settings();
    $cats = get_terms(['taxonomy' => 'category', 'hide_empty' => false, 'orderby' => 'term_id']);
    $cur = $post ? (int) (wp_get_post_categories($post->ID)[0] ?? 0) : (int) $set['default_cat'];
    $tpl = []; $slugs = [];
    foreach ($cats as $c) { $tpl[$c->term_id] = idw_ann_template($c->term_id); $slugs[$c->term_id] = $c->slug . ' ' . $c->name; }
    $note = $post ? get_post_meta($post->ID, '_idw_ann_note', true) : null;
    $cover = $post ? (int) get_post_thumbnail_id($post->ID) : 0;
    $files = $post ? idw_ann_get_files($post->ID) : [];
    $media = current_user_can('upload_files');
    if ($media) wp_enqueue_media();
    $future = $post && $post->post_status === 'future';
    $ts = $post ? get_post_timestamp($post) : time() + HOUR_IN_SECONDS;
    $exp = $post ? (int) get_post_meta($post->ID, '_idw_ann_expire', true) : 0;
    $tz = wp_timezone();
    $approver = !idw_ann_needs_approval();

    if (is_array($note) && ($note['text'] ?? '') !== '' && $post->post_status === 'draft') echo '<div class="ann-toast warn"><span class="dashicons dashicons-format-chat"></span><div><b>ผู้ดูแลข่าวส่งกลับให้แก้ไข</b> (' . esc_html($note['by'] . ' · ' . idw_ann_dt((int) $note['at'])) . ')<br>' . esc_html($note['text']) . '</div></div>';
    if ($post && $post->post_status === 'publish' && !$approver) echo '<div class="ann-toast info"><span class="dashicons dashicons-info"></span>ประกาศนี้แสดงบนเว็บอยู่ ถ้าแก้ไขแล้วส่ง จะต้องรออนุมัติใหม่</div>';
    if ($post && get_post_meta($post->ID, '_idw_ann_expired', true)) echo '<div class="ann-toast info"><span class="dashicons dashicons-hidden"></span>ประกาศนี้ซ่อนอัตโนมัติเมื่อ ' . esc_html(idw_ann_dt((int) get_post_meta($post->ID, '_idw_ann_expired', true))) . ' — ตั้งเวลาซ่อนใหม่แล้วเผยแพร่อีกครั้งได้</div>';

    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="ann-form" id="ann-form">' . wp_nonce_field('idw_ann_save', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_ann_save"><input type="hidden" name="post_id" value="' . (int) ($post->ID ?? 0) . '"><input type="hidden" name="from_pdf" id="ann-from-pdf" value="">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div class="ann-main">';
    // PDF import
    if ($set['pdf'] === '1' && $media) {
        echo '<div class="ann-card ann-pdf" id="ann-pdf"><input type="file" id="ann-pdf-file" accept="application/pdf,.pdf" hidden>';
        echo '<div class="ann-drop" id="ann-drop" tabindex="0" role="button"><span class="ic dashicons dashicons-pdf"></span><div><b>มีไฟล์ประกาศเป็น PDF? ลากมาวางที่นี่</b><span>ระบบจะอ่านหัวเรื่องและเนื้อหามาเติมให้ แนบไฟล์ และใช้หน้าแรกเป็นรูปปกได้ · รองรับทั้ง PDF ข้อความและไฟล์สแกน</span></div><span class="idw-btn sm">เลือกไฟล์ PDF</span></div>';
        echo '<div class="ann-pdf-busy" id="ann-pdf-busy" hidden><span class="spinner is-active"></span><div><b id="ann-pdf-step">กำลังอ่านไฟล์…</b><div class="bar"><i id="ann-pdf-bar"></i></div></div></div>';
        echo '<div class="ann-pdf-out" id="ann-pdf-out" hidden><div class="hd"><span class="dashicons dashicons-media-document"></span><b id="ann-pdf-name"></b><span class="idw-chip" id="ann-pdf-meta"></span><button type="button" class="button-link" id="ann-pdf-reset">อ่านไฟล์อื่น</button></div><div class="grid"><canvas id="ann-pdf-thumb"></canvas><div class="fields">'
            . '<label>หัวเรื่องที่อ่านได้<input type="text" id="ann-pdf-title" class="idw-in"></label><label>สรุปสั้น <small>(ไม่เกิน ' . (int) $set['sum_words'] . ' คำ — ตั้งได้ที่แท็บ ตั้งค่า)</small><textarea id="ann-pdf-sum" rows="3" class="idw-in"></textarea></label><p class="hint" id="ann-pdf-hint"></p>'
            . '<div class="opts"><label><input type="checkbox" id="ann-pdf-use-title" checked> หัวเรื่อง</label><label><input type="checkbox" id="ann-pdf-use-sum" checked> สรุป</label><label><input type="checkbox" id="ann-pdf-use-body" checked> รายละเอียด</label><label><input type="checkbox" id="ann-pdf-use-cat" checked> หมวดที่เดา: <b id="ann-pdf-cat">—</b></label><label><input type="checkbox" id="ann-pdf-use-attach" checked> แนบไฟล์ PDF</label>' . ($set['cover'] === '1' ? '<label><input type="checkbox" id="ann-pdf-use-cover"' . ($cover ? '' : ' checked') . '> ใช้หน้าแรกเป็นรูปปก</label>' : '') . '</div>'
            . '<button type="button" class="idw-btn pri" id="ann-pdf-fill"><span class="dashicons dashicons-download"></span>เติมลงฟอร์ม</button></div></div></div></div>';
    }
    // 1 category
    echo '<div class="ann-card"><span class="ann-step">1</span><h3>หมวดข่าว <em>*</em></h3><div class="ann-cats" id="ann-cats">';
    foreach ($cats as $c) echo '<label><input type="radio" name="cat" value="' . (int) $c->term_id . '"' . checked($cur, $c->term_id, false) . ' required><span>' . esc_html($c->name) . '</span></label>';
    if (current_user_can('manage_categories')) echo '<a class="ann-cat-add" href="' . esc_url(admin_url('edit-tags.php?taxonomy=category')) . '">＋ จัดการหมวด</a>';
    echo '</div></div>';
    // 2 title & summary
    echo '<div class="ann-card"><span class="ann-step">2</span><h3>หัวเรื่องและสรุป</h3><label class="ann-l"><span>หัวเรื่อง <em>*</em></span><input name="title" id="ann-title" required maxlength="200" value="' . esc_attr($post->post_title ?? '') . '" placeholder="เช่น ประกาศรับสมัครพนักงานราชการ ตำแหน่ง …" class="ann-title-in"><span class="cnt" data-for="ann-title"></span></label>';
    echo '<label class="ann-l"><span>สรุปสั้น ๆ <small>แสดงใต้หัวเรื่องและในการ์ดข่าว</small></span><textarea name="summary" id="ann-sum" rows="3" maxlength="1500" placeholder="ประโยคเดียวที่บอกว่าประกาศนี้เกี่ยวกับอะไร ใคร เมื่อไร">' . esc_textarea($post->post_excerpt ?? '') . '</textarea><span class="cnt" data-for="ann-sum"></span></label></div>';
    // 3 details
    echo '<div class="ann-card"><span class="ann-step">3</span><h3>รายละเอียด <button type="button" class="idw-btn sm" id="ann-tpl"><span class="dashicons dashicons-media-text"></span>ใส่แม่แบบของหมวดนี้</button></h3>';
    wp_editor($post->post_content ?? '', 'idw_ann_details', ['textarea_name' => 'details', 'textarea_rows' => 16, 'media_buttons' => $media, 'editor_height' => 360]);
    echo '</div></div><div class="ann-side">';
    // when
    $d = function ($t) use ($tz) { return wp_date('Y-m-d', $t, $tz); };
    $t = function ($t) use ($tz) { return wp_date('H:i', $t, $tz); };
    echo '<div class="ann-card ann-when"><h3><span class="dashicons dashicons-calendar-alt"></span>เวลาเผยแพร่</h3><div class="ann-seg"><label><input type="radio" name="when" value="now"' . checked(!$future, true, false) . '><span>ทันที</span></label><label><input type="radio" name="when" value="later"' . checked($future, true, false) . '><span>ตั้งวัน-เวลา</span></label></div>';
    echo '<div class="ann-later" id="ann-later"' . ($future ? '' : ' hidden') . '><div class="row"><label>วันที่<input type="date" name="pub_date" id="ann-pub-date" value="' . esc_attr($d($ts)) . '" class="idw-in"></label><label>เวลา<input type="time" name="pub_time" id="ann-pub-time" value="' . esc_attr($t($ts)) . '" class="idw-in"></label></div><p class="be" id="ann-pub-be"></p><div class="quick"><button type="button" data-q="tomorrow8">พรุ่งนี้ 08:00</button><button type="button" data-q="monday8">จันทร์หน้า 08:00</button><button type="button" data-q="plus1h">อีก 1 ชม.</button></div></div>';
    echo '<label class="ann-check"><input type="checkbox" name="expire_on" id="ann-exp-on" value="1"' . checked((bool) $exp, true, false) . '> ซ่อนอัตโนมัติเมื่อหมดเวลา</label><div class="ann-exp" id="ann-exp"' . ($exp ? '' : ' hidden') . '><div class="row"><label>วันที่<input type="date" name="exp_date" id="ann-exp-date" value="' . esc_attr($exp ? $d($exp) : $d(time() + 30 * DAY_IN_SECONDS)) . '" class="idw-in"></label><label>เวลา<input type="time" name="exp_time" id="ann-exp-time" value="' . esc_attr($exp ? $t($exp) : '23:59') . '" class="idw-in"></label></div><p class="be" id="ann-exp-be"></p></div>';
    if (current_user_can('edit_others_posts')) echo '<label class="ann-check"><input type="checkbox" name="sticky" value="1"' . checked($post && is_sticky($post->ID), true, false) . '> ปักหมุดไว้บนสุด</label>';
    echo '</div>';
    if ($media) {
        echo '<div class="ann-card"><h3><span class="dashicons dashicons-format-image"></span>รูปหน้าปก</h3><div id="ann-cover-prev" class="ann-cover">' . ($cover ? wp_get_attachment_image($cover, 'medium') : '<span><span class="dashicons dashicons-format-image"></span>ยังไม่มีรูป</span>') . '</div><input type="hidden" name="cover" id="ann-cover" value="' . (int) $cover . '"><div class="ann-row"><button type="button" class="idw-btn sm" id="ann-cover-pick">เลือกรูป</button><button type="button" class="button-link" id="ann-cover-clear">นำออก</button></div></div>';
        echo '<div class="ann-card"><h3><span class="dashicons dashicons-paperclip"></span>ไฟล์แนบ <small>PDF Word Excel รูป</small></h3><ul id="ann-files" class="ann-files">';
        foreach ($files as $f) echo '<li><input type="hidden" name="files[]" value="' . (int) $f['id'] . '"><span class="fn"><span class="dashicons dashicons-media-default"></span>' . esc_html($f['name']) . '</span><input name="file_labels[]" value="' . esc_attr($f['label']) . '" placeholder="ชื่อที่แสดง" class="idw-in"><button type="button" class="button-link-delete" data-rm aria-label="ลบ"><span class="dashicons dashicons-no-alt"></span></button></li>';
        echo '</ul><button type="button" class="idw-btn sm" id="ann-file-add"><span class="dashicons dashicons-plus-alt2"></span>แนบไฟล์</button></div>';
    }
    $send = $approver ? 'เผยแพร่' : 'ส่งขออนุมัติ';
    echo '<div class="ann-card ann-send"><button class="idw-btn pri lg" name="go" value="send" id="ann-send" data-now="' . esc_attr($send) . '" data-later="' . esc_attr($approver ? 'ตั้งเวลาเผยแพร่' : 'ส่งขออนุมัติ (ตั้งเวลา)') . '"><span class="dashicons dashicons-yes"></span><span class="t">' . esc_html($send) . '</span></button><button class="idw-btn" name="go" value="draft" formnovalidate>บันทึกร่าง</button>';
    if ($post && $post->post_status !== 'auto-draft') echo '<a class="idw-btn link" href="' . esc_url($post->post_status === 'publish' ? get_permalink($post) : get_preview_post_link($post)) . '" target="_blank">ดูตัวอย่าง ↗</a>';
    if ($post && current_user_can('delete_post', $post->ID)) echo '<button type="submit" form="ann-del-form" class="idw-btn link ann-del" onclick="return confirm(\'ย้ายประกาศนี้ไปถังขยะ? (กู้คืนได้)\')"><span class="dashicons dashicons-trash"></span>ลบประกาศนี้</button>';
    echo '<p class="hint">' . ($approver ? 'คุณเผยแพร่ได้ทันที' : 'ประกาศจะยังไม่แสดงจนกว่าผู้ดูแลข่าวจะอนุมัติ') . '</p></div></div></form>';

    if ($post && current_user_can('delete_post', $post->ID)) echo '<form id="ann-del-form" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('idw_ann_del_' . $post->ID, '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_ann_del"><input type="hidden" name="post_id" value="' . (int) $post->ID . '"><input type="hidden" name="do" value="trash"></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    wp_enqueue_script('idw-ann', IDW_ANN_URL . 'assets/ann.js', ['jquery'], IDW_ANN_VERSION, true);
    wp_localize_script('idw-ann', 'IDW_ANN', [
        'tpl' => $tpl, 'cats' => $slugs, 'rest' => esc_url_raw(rest_url('wp/v2/media')), 'nonce' => wp_create_nonce('wp_rest'),
        'ocr' => $set['ocr'] === '1', 'cover' => $set['cover'] === '1', 'body' => $set['pdf_body'] === '1', 'words' => (int) $set['sum_words'],
        'pdfjs' => 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', 'pdfworker' => 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js',
        'cmaps' => 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/cmaps/', 'tess' => 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js',
        'months' => ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'], 'days' => ['อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์'],
    ]);
}

function idw_ann_status_chip($p) {
    if ($p->post_status === 'draft' && is_array(get_post_meta($p->ID, '_idw_ann_note', true))) return '<span class="idw-chip bad">ส่งกลับแก้ไข</span>';
    if ($p->post_status === 'draft' && get_post_meta($p->ID, '_idw_ann_expired', true)) return '<span class="idw-chip">หมดเวลาแสดง</span>';
    $map = ['publish' => ['เผยแพร่', 'ok'], 'pending' => ['รออนุมัติ', 'warn'], 'draft' => ['ร่าง', ''], 'future' => ['ตั้งเวลา', 'info']];
    [$l, $c] = $map[$p->post_status] ?? [$p->post_status, ''];
    return '<span class="idw-chip ' . $c . '">' . esc_html($l) . '</span>';
}

function idw_ann_list_tab() {
    $status = sanitize_key($_GET['status'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $s = sanitize_text_field(wp_unslash($_GET['s'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $cat = (int) ($_GET['cat'] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $paged = max(1, (int) ($_GET['paged'] ?? 1)); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $q = ['post_type' => 'post', 'post_status' => in_array($status, ['publish', 'future', 'pending', 'draft', 'trash'], true) ? $status : ['draft', 'pending', 'publish', 'future'], 'posts_per_page' => 20, 'paged' => $paged, 'orderby' => 'modified', 's' => $s];
    if ($cat) $q['cat'] = $cat;
    if ($status === 'future') { $q['orderby'] = 'date'; $q['order'] = 'ASC'; }
    if (!current_user_can('edit_others_posts')) $q['author'] = get_current_user_id();
    $query = new WP_Query($q);
    $base = admin_url('admin.php?page=idw-news&tab=list');
    $c = idw_ann_counts();
    echo '<div class="ann-filter"><div class="ann-pills">';
    foreach (['' => ['ทั้งหมด', $c['publish'] + $c['future'] + $c['pending'] + $c['draft']], 'publish' => ['เผยแพร่', $c['publish']], 'future' => ['ตั้งเวลา', $c['future']], 'pending' => ['รออนุมัติ', $c['pending']], 'draft' => ['ร่าง', $c['draft']], 'trash' => ['ถังขยะ', $c['trash']]] as $k => [$l, $n]) echo '<a class="' . ($k === $status ? 'on' : '') . '" href="' . esc_url(add_query_arg(['status' => $k, 'cat' => $cat ?: null, 's' => $s ?: null], $base)) . '">' . esc_html($l) . ' <i>' . (int) $n . '</i></a>';
    echo '</div><form method="get" class="ann-search"><input type="hidden" name="page" value="idw-news"><input type="hidden" name="tab" value="list"><input type="hidden" name="status" value="' . esc_attr($status) . '"><select name="cat" class="idw-in" onchange="this.form.submit()"><option value="">ทุกหมวด</option>';
    foreach (get_terms(['taxonomy' => 'category', 'hide_empty' => false]) as $t) echo '<option value="' . (int) $t->term_id . '"' . selected($cat, $t->term_id, false) . '>' . esc_html($t->name) . '</option>';
    echo '</select><input type="search" name="s" value="' . esc_attr($s) . '" placeholder="ค้นหาประกาศ…" class="idw-in"></form></div>';
    if (!$query->have_posts()) { echo '<div class="ann-card idw-empty"><span class="dashicons dashicons-megaphone" style="font-size:40px;width:40px;height:40px"></span><p>ยังไม่มีประกาศ' . ($status || $s || $cat ? 'ที่ตรงกับตัวกรอง' : '') . '</p><a class="idw-btn pri" href="' . esc_url(admin_url('admin.php?page=idw-news&tab=write')) . '">เขียนประกาศแรก</a></div>'; return; }
    echo '<div class="ann-list">';
    foreach ($query->posts as $p) {
        $cats = get_the_category($p->ID);
        $exp = (int) get_post_meta($p->ID, '_idw_ann_expire', true);
        $files = count(idw_ann_get_files($p->ID));
        $when = $p->post_status === 'future' ? '<span class="idw-chip info"><span class="dashicons dashicons-clock"></span>แสดง ' . esc_html(idw_ann_dt(get_post_timestamp($p))) . '</span>' : '';
        if ($exp) $when .= '<span class="idw-chip"><span class="dashicons dashicons-hidden"></span>ซ่อน ' . esc_html(idw_ann_dt($exp)) . '</span>';
        echo '<div class="ann-item"><div class="th">' . (has_post_thumbnail($p) ? get_the_post_thumbnail($p, 'thumbnail') : '<span class="dashicons dashicons-media-document"></span>') . '</div><div class="tx"><div class="top">' . idw_ann_status_chip($p) . ($cats ? '<span class="idw-chip">' . esc_html($cats[0]->name) . '</span>' : '') . (is_sticky($p->ID) ? '<span class="idw-chip acc">ปักหมุด</span>' : '') . $when . ($files ? '<span class="idw-chip"><span class="dashicons dashicons-paperclip"></span>' . (int) $files . '</span>' : '') . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '<a class="tt" href="' . esc_url(admin_url('admin.php?page=idw-news&tab=write&post=' . $p->ID)) . '">' . esc_html($p->post_title ?: '(ไม่มีหัวเรื่อง)') . '</a><small>' . esc_html(get_the_author_meta('display_name', $p->post_author)) . ' · แก้ไข ' . esc_html(idw_ann_dt(get_post_timestamp($p, 'modified'))) . ($p->post_status === 'publish' ? ' · เผยแพร่ ' . esc_html(idw_ann_dt(get_post_timestamp($p), false)) : '') . '</small></div><div class="ac">';
        if ($p->post_status === 'trash') {
            if (current_user_can('delete_post', $p->ID)) echo idw_ann_del_button($p->ID, 'restore', 'กู้คืน', 'idw-btn sm pri') . idw_ann_del_button($p->ID, 'delete', 'ลบถาวร', 'idw-btn sm ann-del', 'ลบ “' . $p->post_title . '” ถาวร พร้อมข้อมูลของประกาศนี้ — กู้คืนไม่ได้'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        } else {
            if (current_user_can('edit_post', $p->ID)) echo '<a class="idw-btn sm" href="' . esc_url(admin_url('admin.php?page=idw-news&tab=write&post=' . $p->ID)) . '">แก้ไข</a>';
            echo '<a class="idw-btn sm link" target="_blank" href="' . esc_url($p->post_status === 'publish' ? get_permalink($p) : get_preview_post_link($p)) . '">ดู ↗</a>';
            if (current_user_can('delete_post', $p->ID)) echo idw_ann_del_button($p->ID, 'trash', 'ลบ', 'idw-btn sm link ann-del', 'ย้าย “' . $p->post_title . '” ไปถังขยะ? (กู้คืนได้ที่แท็บ ถังขยะ)'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
        echo '</div></div>';
    }
    echo '</div>';
    if ($query->max_num_pages > 1) {
        echo '<div class="ann-pages">' . wp_kses_post(paginate_links(['base' => add_query_arg('paged', '%#%'), 'format' => '', 'current' => $paged, 'total' => $query->max_num_pages, 'prev_text' => '‹', 'next_text' => '›'])) . '</div>';
    }
}

function idw_ann_review_tab() {
    $posts = get_posts(['post_type' => 'post', 'post_status' => 'pending', 'numberposts' => 50, 'orderby' => 'date', 'order' => 'ASC']);
    if (!$posts) { echo '<div class="ann-card idw-empty"><span class="dashicons dashicons-smiley" style="font-size:40px;width:40px;height:40px;color:#16a34a"></span><p>ไม่มีประกาศรออนุมัติ</p></div>'; return; }
    foreach ($posts as $p) {
        $cats = get_the_category($p->ID);
        $files = idw_ann_get_files($p->ID);
        $ts = get_post_timestamp($p);
        $sched = $p->post_date_gmt !== '0000-00-00 00:00:00' && $ts > time();
        $sent = (int) get_post_meta($p->ID, '_idw_ann_sent', true);
        echo '<div class="ann-review"><div class="main">' . (has_post_thumbnail($p) ? get_the_post_thumbnail($p, 'medium', ['class' => 'img']) : '') . '<div><div class="top"><span class="idw-chip">' . esc_html($cats ? $cats[0]->name : '') . '</span>' . ($sched ? '<span class="idw-chip info">ตั้งเวลาแสดง ' . esc_html(idw_ann_dt($ts)) . '</span>' : '') . '</div><h2>' . esc_html($p->post_title) . '</h2><p class="sum">' . esc_html($p->post_excerpt) . '</p>';
        echo '<details><summary>อ่านรายละเอียด</summary><div class="body">' . wp_kses_post(wpautop($p->post_content)) . '</div></details>';
        if ($files) { echo '<p class="files">'; foreach ($files as $f) echo '<a href="' . esc_url($f['url']) . '" target="_blank"><span class="dashicons dashicons-paperclip"></span>' . esc_html($f['label'] ?: $f['name']) . '</a>'; echo '</p>'; }
        echo '<small>โดย ' . esc_html(get_the_author_meta('display_name', $p->post_author)) . ' · ส่งเมื่อ ' . esc_html(idw_ann_dt($sent ?: get_post_timestamp($p, 'modified'))) . ' · <a href="' . esc_url(get_preview_post_link($p)) . '" target="_blank">ดูตัวอย่างบนเว็บ ↗</a></small></div></div>';
        $form = function ($decision, $label, $class, $extra = '') use ($p) { return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('idw_ann_review_' . $p->ID, '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_ann_review"><input type="hidden" name="post_id" value="' . (int) $p->ID . '"><input type="hidden" name="decision" value="' . $decision . '">' . $extra . '<button class="idw-btn ' . $class . '">' . $label . '</button></form>'; };
        echo '<div class="act">' . $form('approve', '<span class="dashicons dashicons-yes"></span>' . ($sched ? 'อนุมัติ (แสดงตามเวลาที่ตั้ง)' : 'อนุมัติ แสดงบนเว็บ'), 'pri lg') . $form('return', 'ส่งกลับแก้ไข', '', '<textarea name="note" rows="2" class="idw-in" placeholder="บอกผู้เขียนว่าต้องแก้อะไร" required></textarea>') . '<a class="idw-btn link" href="' . esc_url(admin_url('admin.php?page=idw-news&tab=write&post=' . $p->ID)) . '">แก้เองก่อนอนุมัติ</a></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
}

function idw_ann_settings_tab() {
    $s = idw_ann_settings();
    $row = function ($k, $t, $d) use ($s) { return '<label class="idw-opt"><span class="idw-switch"><input type="checkbox" name="' . $k . '" value="1"' . checked($s[$k], '1', false) . '><span></span></span><span><b>' . esc_html($t) . '</b><small>' . esc_html($d) . '</small></span></label>'; };
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="ann-card ann-settings">' . wp_nonce_field('idw_ann_settings', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_ann_settings"><h3>การเผยแพร่</h3><div class="idw-opts">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo $row('approval', 'ต้องอนุมัติก่อนแสดงบนเว็บ', 'ประกาศของผู้ที่ไม่มีสิทธิ์ “อนุมัติประกาศข่าว” จะรอผู้ดูแลข่าวอนุมัติ (ผู้ดูแลระบบและบรรณาธิการอนุมัติได้)'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo $row('notify', 'แจ้งเตือนทางอีเมล', 'แจ้งผู้ดูแลข่าวเมื่อมีประกาศรออนุมัติ และแจ้งผู้เขียนเมื่ออนุมัติหรือส่งกลับ'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div><h3>อ่านไฟล์ PDF</h3><div class="idw-opts">';
    echo $row('pdf', 'นำเข้าจาก PDF', 'อ่านหัวเรื่องและสรุปสั้นจากไฟล์ PDF มาเติมในฟอร์ม (อ่านในเบราว์เซอร์ ไฟล์ไม่ถูกส่งไปที่อื่น)'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label class="idw-opt ann-num"><span class="ann-num-in"><input type="number" name="sum_words" min="10" max="300" value="' . (int) $s['sum_words'] . '"> คำ</span><span><b>ความยาวสรุปสั้น</b><small>สรุปที่อ่านจาก PDF ยาวไม่เกินจำนวนคำนี้ (ตัดที่ท้ายคำ ไม่ตัดกลางคำ) · แนะนำ 30–60 คำ</small></span></label>';
    echo $row('pdf_body', 'เติมรายละเอียดทั้งฉบับด้วย', 'ปิดไว้ = เติมเฉพาะหัวเรื่องและสรุปสั้น (ไฟล์ PDF แนบให้ผู้อ่านเปิดเอง) · เปิด = คัดข้อความทั้งฉบับลงช่องรายละเอียดด้วย'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo $row('ocr', 'อ่านไฟล์สแกน (OCR)', 'ไฟล์ที่เป็นภาพสแกน: อ่านตัวอักษรไทย / อังกฤษจากภาพ ใช้เวลาประมาณ 10–30 วินาที'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo $row('cover', 'ใช้หน้าแรกเป็นรูปปก', 'สร้างรูปปกจากหน้าแรกของ PDF ให้อัตโนมัติ'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div><h3>ข่าวและภาพที่เก่าแล้ว</h3><div class="idw-opts">';
    echo '<label class="idw-opt ann-num"><span class="ann-num-in"><input type="number" name="news_months" min="0" max="120" value="' . (int) $s['news_months'] . '"> เดือน</span><span><b>ไม่แสดงข่าวที่เก่ากว่า</b><small>ข่าวบนหน้าแรกและบล็อกข่าวล่าสุด แสดงเฉพาะข่าวที่ไม่เก่ากว่านี้ · หน้ารวมข่าวและข่าวย้อนหลังยังแสดงครบ · 0 = แสดงทุกข่าว</small></span></label>';
    echo '<label class="idw-opt ann-num"><span class="ann-num-in"><input type="number" name="slide_months" min="0" max="120" value="' . (int) $s['slide_months'] . '"> เดือน</span><span><b>ไม่แสดงภาพสไลด์ที่อัปโหลดนานกว่า</b><small>กันแบนเนอร์งานที่ผ่านไปนานแล้วค้างบนหน้าแรก · 0 = แสดงทุกภาพ</small></span></label>';
    echo '</div><h3>ค่าเริ่มต้น</h3><label class="idw-field" style="max-width:360px">หมวดข่าวเริ่มต้น<select name="default_cat"><option value="0">— ไม่เลือก —</option>';
    foreach (get_terms(['taxonomy' => 'category', 'hide_empty' => false]) as $t) echo '<option value="' . (int) $t->term_id . '"' . selected((int) $s['default_cat'], $t->term_id, false) . '>' . esc_html($t->name) . '</option>';
    echo '</select></label><p style="margin-top:18px"><button class="idw-btn pri">บันทึก</button> <a class="idw-btn link" href="' . esc_url(admin_url('edit-tags.php?taxonomy=category')) . '">หมวดข่าวและแม่แบบเนื้อหา →</a></p></form>';
}

add_action('admin_enqueue_scripts', function () {
    if (($_GET['page'] ?? '') !== 'idw-news') return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (wp_style_is('idw-admin', 'registered')) wp_enqueue_style('idw-admin');
    wp_enqueue_style('idw-ann', IDW_ANN_URL . 'assets/ann.css', wp_style_is('idw-admin', 'registered') ? ['idw-admin'] : [], IDW_ANN_VERSION);
});
