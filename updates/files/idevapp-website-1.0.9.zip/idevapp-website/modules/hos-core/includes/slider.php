<?php
/**
 * แทน Smart Slider 3:
 * - post type "สไลด์หน้าแรก" (hos_slide): ชื่อ = หัวข้อ, คำโปรย = ข้อความรอง, ภาพเด่น = ภาพสไลด์, ลิงก์, ลำดับ
 * - ปุ่มนำเข้าสไลด์เดิมจากตาราง Smart Slider 3 (nextend2_smartslider3_slides)
 * - shortcode [smartslider3 slider="x"] เดิมยังใช้ได้ (แสดงสไลด์ชุดนี้)
 */
defined( 'ABSPATH' ) || exit;

add_action( 'init', 'hos_register_slide_type' );
function hos_register_slide_type() {
	register_post_type( 'hos_slide', array(
		'labels'       => array( 'name' => 'สไลด์หน้าแรก', 'singular_name' => 'สไลด์', 'add_new_item' => 'เพิ่มสไลด์', 'edit_item' => 'แก้ไขสไลด์', 'menu_name' => 'สไลด์หน้าแรก' ),
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => false, // managed on the "สไลด์หน้าแรก" page (includes/slider-admin.php)
		'menu_icon'    => 'dashicons-images-alt2',
		'menu_position' => 21,
		'supports'     => array( 'title', 'excerpt', 'thumbnail', 'page-attributes' ),
	) );
}

add_action( 'add_meta_boxes_hos_slide', function () {
	add_meta_box( 'hos-slide-link', 'ลิงก์เมื่อคลิก', function ( $post ) {
		wp_nonce_field( 'hos_slide', 'hos_slide_nonce' );
		echo '<input type="url" class="widefat" name="hos_slide_link" value="' . esc_attr( get_post_meta( $post->ID, '_hos_slide_link', true ) ) . '" placeholder="https://">';
		echo '<p class="description">ภาพสไลด์ = "ภาพเด่น" (แนะนำ 1920×700) · ข้อความรอง = "ข้อความสรุป" · ลำดับ = "ลำดับ" ในกล่องคุณสมบัติ</p>';
	}, 'hos_slide', 'normal', 'high' );
} );

add_action( 'save_post_hos_slide', function ( $post_id ) {
	if ( isset( $_POST['hos_slide_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hos_slide_nonce'] ) ), 'hos_slide' ) && current_user_can( 'edit_post', $post_id ) ) {
		update_post_meta( $post_id, '_hos_slide_link', esc_url_raw( wp_unslash( isset( $_POST['hos_slide_link'] ) ? $_POST['hos_slide_link'] : '' ) ) );
	}
} );

/** สไลด์ที่เผยแพร่ เรียงตามลำดับ: array of [title, subtitle, image, link] */
if ( ! function_exists( 'hos_get_slides' ) ) { // the theme may load first (e.g. while the plugin is being switched on)
function hos_get_slides() {
	$out = array();
	$today = wp_date( 'Y-m-d' );
	foreach ( get_posts( array( 'post_type' => 'hos_slide', 'post_status' => 'publish', 'numberposts' => 20, 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'DESC' ) ) ) as $s ) {
		$from  = (string) get_post_meta( $s->ID, '_hos_slide_from', true );
		$until = (string) get_post_meta( $s->ID, '_hos_slide_until', true );
		$from  = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ? $from : ''; // only real dates count
		$until = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $until ) ? $until : '';
		if ( ( $from && $from > $today ) || ( $until && $until < $today ) ) {
			continue; // นอกช่วงเวลาที่ตั้งไว้
		}
		$months = function_exists( 'idw_ann_months' ) ? idw_ann_months( 'slide' ) : max( 0, (int) get_theme_mod( 'hos_slide_months', 6 ) );
		$tid    = (int) get_post_thumbnail_id( $s );
		if ( $months && $tid && (int) get_post_time( 'U', true, $tid ) < strtotime( '-' . $months . ' months' ) ) {
			continue; // ภาพเก่าเกินกำหนด (ตั้งที่ ประกาศข่าว › ตั้งค่า)
		}
		$img = get_the_post_thumbnail_url( $s, 'full' );
		if ( ! $img ) {
			$img = get_post_meta( $s->ID, '_hos_slide_image', true ); // จากการนำเข้า
		}
		$out[] = array(
			'title'    => get_the_title( $s ),
			'subtitle' => $s->post_excerpt,
			'image'    => $img,
			'link'     => get_post_meta( $s->ID, '_hos_slide_link', true ),
		);
	}
	return $out;
}
}

/** แสดงสไลด์ (theme มี template ของตัวเอง นี่คือ fallback สำหรับ shortcode) */
function hos_render_slider() {
	if ( function_exists( 'hos_theme_slider' ) ) {
		ob_start();
		hos_theme_slider();
		return ob_get_clean();
	}
	$slides = hos_get_slides();
	if ( ! $slides ) {
		return '';
	}
	$html = '<div class="hos-sc-slider">';
	foreach ( $slides as $s ) {
		$img   = $s['image'] ? '<img src="' . esc_url( $s['image'] ) . '" alt="' . esc_attr( $s['title'] ) . '">' : '';
		$html .= $s['link'] ? '<a href="' . esc_url( $s['link'] ) . '">' . $img . '</a>' : $img;
	}
	return $html . '</div>';
}
add_shortcode( 'hos_slider', 'hos_render_slider' );
add_action( 'init', function () {
	if ( ! shortcode_exists( 'smartslider3' ) ) {
		add_shortcode( 'smartslider3', 'hos_render_slider' );
	}
}, 20 );

/** นำเข้าสไลด์จาก Smart Slider 3 (ตารางยังอยู่ในฐานข้อมูลแม้ปิด plugin) */
function hos_import_smartslider() {
	global $wpdb;
	$table = $wpdb->prefix . 'nextend2_smartslider3_slides';
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
		return new WP_Error( 'no_table', 'ไม่พบตาราง Smart Slider 3 ในฐานข้อมูล' );
	}
	$rows  = $wpdb->get_results( "SELECT id, title, description, params, ordering, published FROM {$table} ORDER BY slider, ordering" ); // phpcs:ignore
	$count = 0;
	$base  = wp_get_upload_dir();
	foreach ( $rows as $r ) {
		if ( get_posts( array( 'post_type' => 'hos_slide', 'post_status' => 'any', 'meta_key' => '_hos_ss3_id', 'meta_value' => $r->id, 'fields' => 'ids', 'numberposts' => 1 ) ) ) {
			continue;
		}
		$p     = json_decode( (string) $r->params, true );
		$image = is_array( $p ) && ! empty( $p['backgroundImage'] ) ? $p['backgroundImage'] : '';
		$image = str_replace( array( '$upload$', '$/' ), array( $base['baseurl'], home_url( '/' ) ), $image );
		$link  = is_array( $p ) && ! empty( $p['href'] ) ? $p['href'] : '';
		if ( $link && '#' !== $link && ! preg_match( '#^https?://#', $link ) ) {
			$link = home_url( '/' . ltrim( $link, '/' ) );
		}
		$id = wp_insert_post( array(
			'post_type'    => 'hos_slide',
			'post_status'  => $r->published ? 'publish' : 'draft',
			'post_title'   => wp_strip_all_tags( $r->title ),
			'post_excerpt' => wp_strip_all_tags( (string) $r->description ),
			'menu_order'   => (int) $r->ordering,
		) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_hos_ss3_id', $r->id );
			update_post_meta( $id, '_hos_slide_image', esc_url_raw( $image ) );
			if ( $link && '#' !== $link ) {
				update_post_meta( $id, '_hos_slide_link', esc_url_raw( $link ) );
			}
			$att = $image ? attachment_url_to_postid( $image ) : 0;
			if ( $att ) {
				set_post_thumbnail( $id, $att );
			}
			$count++;
		}
	}
	return $count;
}
