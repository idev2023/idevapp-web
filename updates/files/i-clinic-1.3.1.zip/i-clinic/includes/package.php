<?php
/**
 * iDevApp package (I-Clinic / I-Clinic Pro / I-Drug): one plugin with the modules inside (modules/), its own home
 * screen with the day's numbers, shortcuts and a set-up checklist, the menus grouped under it, and the edition's
 * features (job orders in I-Clinic Pro, ขย. books in I-Drug).
 */
defined('ABSPATH') || exit;

function idev_pkg_editions() {
    return [
        'clinic' => ['name' => 'I-Clinic', 'desc' => __('Clinic system: examination room and patient records, registration, online appointments, doctors\' schedule, dispensing and stock', 'idev-package'), 'profile' => 'clinic'],
        'job' => ['name' => 'I-Clinic Pro', 'desc' => __('Clinic and shop system with job orders and the examination room: eye clinics, optical shops, hearing aids, dental labs', 'idev-package'), 'profile' => 'optical'],
        'pharmacy' => ['name' => 'I-Drug', 'desc' => __('Pharmacy system: sales, stock by lot and expiry, drug labels and ขย. books', 'idev-package'), 'profile' => 'pharmacy'],
    ];
}
function idev_pkg() { return idev_pkg_editions()[IDEV_PACKAGE]; }
function idev_pkg_licensed() { return function_exists('idev_is_licensed') && idev_is_licensed('store'); }

/* Edition features in the shop module. */
add_filter('idev_store_feature', function ($on, $feature) {
    if ($feature === 'jobs') return IDEV_PACKAGE === 'job';
    if ($feature === 'khy') return IDEV_PACKAGE === 'pharmacy';
    return $on;
}, 10, 2);

/** First install: shop type of the edition, flush links. */
function idev_pkg_install() {
    if (function_exists('idev_hol_install')) idev_hol_install();
    if (function_exists('idev_cs_register_types')) { idev_cs_register_types(); if (function_exists('idev_cs_migrate')) idev_cs_migrate(); }
    if (function_exists('idev_medreg_install')) idev_medreg_install();
    if (function_exists('idev_appt_install')) { idev_appt_install(); update_option('idev_appt_flush', 1, false); }
    if (function_exists('idev_apro_install')) idev_apro_install();
    if (function_exists('idev_store_install')) idev_store_install();
    if (function_exists('idev_emr_install')) idev_emr_install();
    $s = get_option('idev_store_settings', []);
    if (!is_array($s) || empty($s['profile'])) { $s = is_array($s) ? $s : []; $s['profile'] = idev_pkg()['profile']; update_option('idev_store_settings', $s); }
    if (!get_option('idev_pkg_installed')) update_option('idev_pkg_installed', time(), false);
    flush_rewrite_rules();
}

/** Separately installed copies of the modules are switched off: the package contains them. */
function idev_pkg_takeover() {
    if (!function_exists('is_plugin_active')) require_once ABSPATH . 'wp-admin/includes/plugin.php';
    $off = [];
    foreach (['idev-thai-holidays', 'idev-clinic-schedule', 'idev-patient-registration', 'idev-patient-registration-pro', 'idev-appointments', 'idev-appointments-pro', 'idev-store'] as $m) {
        $f = $m . '/' . $m . '.php';
        if (is_plugin_active($f)) { deactivate_plugins($f, true); $off[] = $m; }
    }
    foreach (array_diff(['i-clinic', 'i-clinic-pro', 'i-drug'], [IDEV_PACKAGE_SLUG]) as $p) if (is_plugin_active($p . '/' . $p . '.php')) { deactivate_plugins($p . '/' . $p . '.php', true); $off[] = $p; }
    if ($off) set_transient('idev_pkg_took_over', $off, 600);
}
add_action('admin_init', 'idev_pkg_takeover');
/* First load of this edition (e.g. switched from another package in the same request): set up once. */
add_action('admin_init', function () { if (get_option('idev_pkg_edition') !== IDEV_PACKAGE) { idev_pkg_install(); update_option('idev_pkg_edition', IDEV_PACKAGE, false); } }, 5);
add_action('admin_notices', function () {
    $off = get_transient('idev_pkg_took_over');
    if (!$off || !current_user_can('activate_plugins')) return;
    delete_transient('idev_pkg_took_over');
    /* translators: 1: package name, 2: plugin names */
    echo '<div class="notice notice-success is-dismissible"><p>' . esc_html(sprintf(__('%1$s already contains these plugins, so the separate copies were switched off (settings and data are kept): %2$s', 'idev-package'), IDEV_PACKAGE_NAME, implode(', ', $off))) . '</p></div>';
});

/* ---------- Menu: the package first, its modules right under it ---------- */

add_action('admin_menu', function () {
    add_menu_page(IDEV_PACKAGE_NAME, IDEV_PACKAGE_NAME, 'read', 'idev-pkg', 'idev_pkg_home', 'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#a7aaad" d="M8 2h4v6h6v4h-6v6H8v-6H2V8h6z"/></svg>'), 2);
    add_submenu_page('idev-pkg', IDEV_PACKAGE_NAME, __('Home', 'idev-package'), 'read', 'idev-pkg', 'idev_pkg_home');
}, 1);
add_filter('custom_menu_order', '__return_true');
add_filter('menu_order', function ($order) {
    $mine = ['idev-pkg', 'idev-emr', 'idev-store', 'idev-medreg', 'idev-appt', 'edit.php?post_type=idev_provider'];
    $rest = array_values(array_diff($order, $mine));
    $at = array_search('index.php', $rest, true);
    array_splice($rest, $at === false ? 0 : $at + 1, 0, array_values(array_intersect($mine, $order)));
    return $rest;
}, 99);

add_action('admin_enqueue_scripts', function ($hook) {
    if (strpos((string) $hook, 'idev-pkg') === false) return;
    wp_enqueue_style('idev-pkg', plugins_url('assets/package.css', IDEV_PACKAGE_FILE), [], IDEV_PACKAGE_VERSION);
});

/* ---------- Home ---------- */

function idev_pkg_count($sql, ...$args) { global $wpdb; return (int) $wpdb->get_var($args ? $wpdb->prepare($sql, ...$args) : $sql); } // phpcs:ignore WordPress.DB

function idev_pkg_home() {
    global $wpdb;
    $today = idev_today();
    $chip = idev_pkg_licensed() ? [__('Licensed', 'idev-package'), 'ok'] : [__('Trial', 'idev-package'), 'trial'];
    idev_page_open(IDEV_PACKAGE_NAME, idev_pkg()['desc'], ['chip' => $chip, 'help' => 'https://idevapp.me/#systems']);
    if (!idev_pkg_licensed() && current_user_can('manage_options')) echo wp_kses_post(idev_license_upsell('package', sprintf(esc_html__('Trial: everything works; receipts and reports print "TRIAL". Enter your %s licence key to use it for real.', 'idev-package'), IDEV_PACKAGE_NAME)));
    // Numbers today
    $stats = [];
    if (function_exists('idev_store_t')) {
        $stats[] = [function_exists('idev_store_money') ? idev_store_money(idev_pkg_count('SELECT COALESCE(SUM(amount),0) FROM ' . idev_store_t('payments') . ' WHERE void = 0 AND created_at BETWEEN %s AND %s', $today . ' 00:00:00', $today . ' 23:59:59')) : '', __('Received today', 'idev-package'), admin_url('admin.php?page=idev-store-bills'), 'accent'];
        $stats[] = [idev_pkg_count('SELECT COUNT(*) FROM ' . idev_store_t('bills') . " WHERE status <> 'void' AND created_at BETWEEN %s AND %s", $today . ' 00:00:00', $today . ' 23:59:59'), __('Bills today', 'idev-package'), admin_url('admin.php?page=idev-store-bills'), ''];
    }
    if (function_exists('idev_emr_t')) $stats[] = [idev_pkg_count('SELECT COUNT(*) FROM ' . idev_emr_t('visits') . " WHERE visit_date = %s AND status <> 'cancelled'", $today), __('Patients seen today', 'idev-package'), admin_url('admin.php?page=idev-emr'), 'accent'];
    if (function_exists('idev_appt_table')) $stats[] = [idev_pkg_count('SELECT COUNT(*) FROM ' . idev_appt_table() . " WHERE appt_date = %s AND status IN ('pending','confirmed','completed')", $today), __('Appointments today', 'idev-package'), admin_url('admin.php?page=idev-appt'), ''];
    if (function_exists('idev_medreg_table')) $stats[] = [idev_pkg_count('SELECT COUNT(*) FROM ' . idev_medreg_table() . " WHERE status IN ('pending','error')"), __('New patients to check', 'idev-package'), admin_url('admin.php?page=idev-medreg'), ''];
    if (function_exists('idev_store_low_count')) $stats[] = [idev_store_low_count(), __('Low stock', 'idev-package'), admin_url('admin.php?page=idev-store-stock&low=1'), ''];
    if (function_exists('idev_store_expiring')) $stats[] = [count(idev_store_expiring()), __('Expiring soon', 'idev-package'), admin_url('admin.php?page=idev-store-reports&tab=expiry'), ''];
    echo '<div class="idev-stats">';
    foreach ($stats as [$v, $l, $u, $c]) echo '<a class="idev-stat ' . esc_attr($c) . '" href="' . esc_url($u) . '" style="text-decoration:none"><strong>' . esc_html((string) $v) . '</strong><span>' . esc_html($l) . '</span></a>';
    echo '</div>';
    // Shortcuts
    $tiles = [];
    if (function_exists('idev_emr_t')) $tiles[] = ['idev-emr', 'stethoscope', __('Examination room', 'idev-package'), __('Today\'s queue, screening, doctor\'s notes, prescriptions, re-med, drug allergies', 'idev-package')];
    if (function_exists('idev_emr_t')) $tiles[] = ['idev-emr-patients', 'heart', __('Patient records', 'idev-package'), __('History of every visit, drug allergies, underlying diseases, weight and BP trends', 'idev-package')];
    $tiles[] = ['idev-store-pos', 'cart', IDEV_PACKAGE === 'pharmacy' ? __('Sell / dispense', 'idev-package') : __('Sell / receive payment', 'idev-package'), __('Scan or search items, print the receipt and drug labels, PromptPay QR', 'idev-package')];
    if (IDEV_PACKAGE === 'job') $tiles[] = ['idev-store-jobs', 'wrench', __('Job orders', 'idev-package'), __('Glasses, lenses, devices: prescription, deposit, pick-up time', 'idev-package')];
    $tiles[] = ['idev-medreg', 'idcard', IDEV_PACKAGE === 'pharmacy' ? __('Customer registration', 'idev-package') : __('New patients', 'idev-package'), __('Online registration with ID card / passport, HN and patient card', 'idev-package')];
    $tiles[] = ['idev-appt', 'calendar', __('Appointments', 'idev-package'), __('Today\'s list, confirm, move, reminders on LINE / SMS', 'idev-package')];
    $tiles[] = ['idev-store-stock', 'box', __('Stock', 'idev-package'), __('Items, lots and expiry dates, receive goods, import CSV', 'idev-package')];
    $tiles[] = ['idev-store-customers', 'users', __('Customers', 'idev-package'), __('History of bills and jobs for each customer', 'idev-package')];
    $tiles[] = ['idev-store-reports', 'chart', __('Reports', 'idev-package'), IDEV_PACKAGE === 'pharmacy' ? __('Money received, best sellers, stock value, ขย. 9–13', 'idev-package') : __('Money received, best sellers, stock value, expiring lots', 'idev-package')];
    $tiles[] = ['edit.php?post_type=idev_provider', 'stethoscope', IDEV_PACKAGE === 'pharmacy' ? __('Pharmacists\' hours', 'idev-package') : __('Doctors\' schedule', 'idev-package'), __('Who works when; the booking times come from here', 'idev-package')];
    if (current_user_can('manage_options')) $tiles[] = ['idev-store-docs', 'palette', __('Receipts & e-mail design', 'idev-package'), __('Templates for receipts, reports, e-mails and the patient card', 'idev-package')];
    echo '<div class="idev-tiles">';
    foreach ($tiles as [$page, $icon, $title, $desc]) {
        $url = strpos($page, '.php') ? admin_url($page) : admin_url('admin.php?page=' . $page);
        echo '<a class="idev-tile" href="' . esc_url($url) . '"><span class="ic">' . idev_icon($icon) . '</span><strong>' . esc_html($title) . '</strong><small>' . esc_html($desc) . '</small></a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG
    }
    echo '</div>';
    if (current_user_can('manage_options')) { idev_pkg_checklist(); idev_pkg_appmode_card(); }
    idev_page_close();
}

/** Set-up checklist. */
function idev_pkg_checklist() {
    $st = function_exists('idev_store_settings') ? idev_store_settings() : [];
    $has_items = function_exists('idev_store_t') ? idev_pkg_count('SELECT COUNT(*) FROM ' . idev_store_t('items')) > 0 : true;
    $providers = (int) wp_count_posts('idev_provider')->publish;
    $appt = function_exists('idev_appt_settings') ? idev_appt_settings() : [];
    $steps = [
        [!empty($st['shop_name']) && !empty($st['address']), __('Shop / clinic details', 'idev-package'), __('Name, address, phone, tax ID and logo for receipts', 'idev-package'), 'admin.php?page=idev-store-settings'],
        [!empty($st['promptpay']), __('PromptPay', 'idev-package'), __('Phone or tax ID number for the QR code on bills', 'idev-package'), 'admin.php?page=idev-store-settings'],
        [$has_items, IDEV_PACKAGE === 'pharmacy' ? __('Add medicines', 'idev-package') : __('Add items', 'idev-package'), __('One by one or import a CSV file', 'idev-package'), 'admin.php?page=idev-store-stock'],
        [$providers > 0, IDEV_PACKAGE === 'pharmacy' ? __('Pharmacists', 'idev-package') : __('Doctors and clinics', 'idev-package'), __('Working hours; online booking times come from them', 'idev-package'), 'edit.php?post_type=idev_provider'],
        [!empty($appt['page']), __('Online booking page', 'idev-package'), __('A page with the "Book an appointment" block', 'idev-package'), 'admin.php?page=idev-appt-settings'],
        [idev_pkg_count("SELECT COUNT(*) FROM {$GLOBALS['wpdb']->posts} WHERE post_status = 'publish' AND (post_content LIKE '%idev_patient_registration%' OR post_content LIKE '%wp:idev/patient-registration%')") > 0, __('Registration page', 'idev-package'), __('A page with the "Patient registration" block', 'idev-package'), 'admin.php?page=idev-medreg-settings'],
        ...(function_exists('idev_emr_t') ? [[(bool) get_users(['capability' => 'idev_emr_doctor', 'meta_key' => 'idev_emr_license', 'meta_compare' => '!=', 'meta_value' => '', 'number' => 1, 'fields' => 'ID']), __('Doctors\' licence numbers', 'idev-package'), __('Names and licence numbers for medical certificates; give staff their access', 'idev-package'), 'admin.php?page=idev-emr-settings&tab=doctors']] : []),
        [(bool) get_option('idev_store_doc_design'), __('Choose a receipt design', 'idev-package'), __('Classic, modern or formal, with your logo', 'idev-package'), 'admin.php?page=idev-store-docs'],
        [idev_pkg_licensed(), __('Enter the licence key', 'idev-package'), __('Removes "TRIAL" from receipts and reports', 'idev-package'), 'admin.php?page=idev-license'],
    ];
    $done = count(array_filter(array_column($steps, 0)));
    echo '<div class="idev-card"><h2>' . esc_html__('Set up', 'idev-package') . ' <small>' . esc_html($done . ' / ' . count($steps)) . '</small></h2><ol class="idev-steps">';
    foreach ($steps as [$ok, $title, $desc, $url]) echo '<li class="' . ($ok ? 'done' : '') . '"><div><b>' . esc_html($title) . '</b><small>' . esc_html($desc) . '</small></div><a class="button' . ($ok ? '' : ' button-primary') . '" href="' . esc_url(admin_url($url)) . '">' . esc_html($ok ? __('Change', 'idev-package') : __('Set up', 'idev-package')) . '</a></li>';
    echo '</ol></div>';
}

/** Program mode switch for the whole site. */
function idev_pkg_appmode_card() {
    $on = function_exists('idev_app_site_on') && idev_app_site_on();
    echo '<div class="idev-card"><h2>' . esc_html__('Program mode', 'idev-package') . ' <small>' . esc_html($on ? __('On', 'idev-package') : __('Off', 'idev-package')) . '</small></h2><p>' . esc_html__('The back office looks like a clinic program: only the system\'s menus, a branded login screen, and everyone starts on their own work (doctor → doctor\'s room, nurse → queue, cashier → sales). Administrators can switch to the WordPress menus from the top bar.', 'idev-package') . '</p><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('idev_pkg_appmode');
    echo '<input type="hidden" name="action" value="idev_pkg_appmode"><input type="hidden" name="on" value="' . ($on ? '0' : '1') . '"><button class="button' . ($on ? '' : ' button-primary') . '">' . esc_html($on ? __('Turn off', 'idev-package') : __('Turn on', 'idev-package')) . '</button></form></div>';
}
add_action('admin_post_idev_pkg_appmode', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idev_pkg_appmode')) wp_die('Forbidden', 403);
    update_option('idev_pkg_appmode', ($_POST['on'] ?? '1') === '1' ? '1' : '0');
    wp_safe_redirect(admin_url('admin.php?page=idev-pkg'));
    exit;
});
