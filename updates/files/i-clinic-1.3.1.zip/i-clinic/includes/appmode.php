<?php
/**
 * Program mode: the back office looks and works like a clinic program, not like WordPress.
 * - only the system's menus (WordPress menus hidden), app-style side menu and top bar, no WordPress footer
 * - after login everyone lands on their own work: doctor → doctor's room, nurse → queue, cashier → sales
 * - branded login screen
 * Site switch: option idev_pkg_appmode ('1' on, default). Administrators can switch themselves to the
 * normal WordPress menus from the top bar (user meta idev_app_mode).
 */
defined('ABSPATH') || exit;

function idev_app_site_on() { return get_option('idev_pkg_appmode', '1') === '1'; }
function idev_app_mode() {
    if (!idev_app_site_on()) return false;
    if (!is_user_logged_in()) return true;
    if (!current_user_can('manage_options')) return true;
    return get_user_meta(get_current_user_id(), 'idev_app_mode', true) !== '0';
}
function idev_app_clinic_name() {
    $s = function_exists('idev_store_settings') ? idev_store_settings() : [];
    return trim((string) ($s['shop_name'] ?? '')) ?: get_bloginfo('name');
}
function idev_app_logo() {
    $s = function_exists('idev_store_settings') ? idev_store_settings() : [];
    return (string) ($s['logo'] ?? '');
}

/** Where each person starts. */
function idev_app_home_url($user = null) {
    $user = $user ?: wp_get_current_user();
    if (!$user || !$user->ID) return admin_url();
    $can = function ($cap) use ($user) { return user_can($user, $cap); };
    if ($can('idev_emr_doctor') && !$can('manage_options') && function_exists('idev_emr_t')) return admin_url('admin.php?page=idev-emr-doctor');
    if ($can('idev_store_manage') && !$can('manage_options')) return admin_url('admin.php?page=idev-store-pos');
    if ($can('idev_emr') && !$can('manage_options') && function_exists('idev_emr_t')) return admin_url('admin.php?page=idev-emr');
    if ($can('idev_store') && !$can('manage_options') && !$can('idev_appt_manage')) return admin_url('admin.php?page=idev-store-pos');
    return admin_url('admin.php?page=idev-pkg');
}
add_filter('login_redirect', function ($to, $requested, $user) {
    if (!idev_app_site_on() || is_wp_error($user) || !$user instanceof WP_User) return $to;
    $default = !$requested || $requested === admin_url() || strpos($requested, 'wp-admin/index.php') !== false || rtrim($requested, '/') === rtrim(admin_url(), '/');
    return $default ? idev_app_home_url($user) : $to;
}, 20, 3);

/* Dashboard → the person's start page. */
add_action('admin_init', function () {
    global $pagenow;
    if (!idev_app_mode() || wp_doing_ajax() || $pagenow !== 'index.php' || !empty($_GET['page'])) return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    wp_safe_redirect(idev_app_home_url());
    exit;
}, 1);

/* Only the system's menus. */
add_action('admin_menu', function () {
    if (!idev_app_mode()) return;
    global $menu;
    $keep = ['idevapp', 'edit.php?post_type=idev_provider', 'profile.php'];
    foreach ((array) $menu as $item) {
        $slug = $item[2] ?? '';
        if ($slug === '' || strpos($slug, 'idev') === 0 || in_array($slug, $keep, true)) continue;
        remove_menu_page($slug);
    }
}, 9999);
/* Short menu names that read like a program. */
add_action('admin_menu', function () {
    if (!idev_app_mode()) return;
    global $menu;
    foreach ((array) $menu as $k => $item) if (($item[2] ?? '') === 'idev-pkg') $menu[$k][0] = __('Home', 'idev-package');
}, 10000);

/* Top bar: clinic name, the person, a switch for administrators. */
add_action('admin_bar_menu', function ($bar) {
    if (!idev_app_mode()) {
        if (idev_app_site_on() && current_user_can('manage_options') && is_admin()) $bar->add_node(['id' => 'idev-app-switch', 'title' => '▣ ' . __('Program mode', 'idev-package'), 'href' => wp_nonce_url(admin_url('admin-post.php?action=idev_app_switch&to=1'), 'idev_app_switch')]);
        return;
    }
    foreach (['wp-logo', 'comments', 'new-content', 'updates', 'customize', 'search', 'view-site', 'edit', 'site-editor', 'command-palette'] as $n) $bar->remove_node($n);
    $site = $bar->get_node('site-name');
    if ($site) { $site->title = esc_html(idev_app_clinic_name()); $site->href = idev_app_home_url(); $bar->add_node((array) $site); }
    $bar->remove_node('view-site');
    $bar->add_node(['id' => 'idev-app-product', 'title' => esc_html(IDEV_PACKAGE_NAME), 'meta' => ['class' => 'idev-app-product']]);
    if (current_user_can('manage_options')) $bar->add_node(['id' => 'idev-app-switch', 'parent' => 'top-secondary', 'title' => __('WordPress menus', 'idev-package'), 'href' => wp_nonce_url(admin_url('admin-post.php?action=idev_app_switch&to=0'), 'idev_app_switch')]);
}, 999);
add_action('admin_post_idev_app_switch', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idev_app_switch')) wp_die('Forbidden', 403);
    update_user_meta(get_current_user_id(), 'idev_app_mode', ($_GET['to'] ?? '1') === '1' ? '1' : '0');
    wp_safe_redirect(($_GET['to'] ?? '1') === '1' ? idev_app_home_url() : admin_url('plugins.php'));
    exit;
});
/* Staff never see the WordPress bar on the public pages. */
add_filter('show_admin_bar', function ($show) { return idev_app_site_on() && !current_user_can('manage_options') ? false : $show; }, 20);

add_filter('admin_title', function ($title, $plain) { return idev_app_mode() ? $plain . ' · ' . idev_app_clinic_name() : $title; }, 10, 2);
add_filter('admin_footer_text', function ($t) { return idev_app_mode() ? '' : $t; }, 99);
add_filter('update_footer', function ($t) { return idev_app_mode() ? '' : $t; }, 99);
add_filter('admin_body_class', function ($c) { return idev_app_mode() ? $c . ' idev-appmode' : $c; });

add_action('admin_enqueue_scripts', function () {
    if (!idev_app_mode()) return;
    wp_enqueue_style('idev-appmode', plugins_url('assets/appmode.css', IDEV_PACKAGE_FILE), [], IDEV_PACKAGE_VERSION);
});
/* Brand block above the side menu. */
add_action('adminmenu', function () {
    if (!idev_app_mode()) return;
    $u = wp_get_current_user();
    $logo = idev_app_logo();
    $roles = ['administrator' => __('Administrator', 'idev-package'), 'idev_emr_doctor' => __('Doctor', 'idev-package'), 'idev_store_manager' => __('Shop manager', 'idev-package'), 'idev_emr_nurse' => __('Nurse / staff', 'idev-package'), 'idev_store_staff' => __('Shop staff', 'idev-package')];
    $role = '';
    foreach ($roles as $k => $l) if (in_array($k, (array) $u->roles, true)) { $role = $l; break; }
    echo '<li class="idev-app-brand"><a href="' . esc_url(idev_app_home_url()) . '">' . ($logo ? '<img src="' . esc_url($logo) . '" alt="">' : '<span class="mk">' . esc_html(mb_substr(idev_app_clinic_name(), 0, 1)) . '</span>') . '<span class="nm"><b>' . esc_html(idev_app_clinic_name()) . '</b><small>' . esc_html(IDEV_PACKAGE_NAME) . '</small></span></a></li>';
    echo '<li class="idev-app-user"><span class="av">' . esc_html(mb_substr($u->display_name, 0, 1)) . '</span><span><b>' . esc_html($u->display_name) . '</b><small>' . esc_html($role) . '</small></span><a href="' . esc_url(wp_logout_url(wp_login_url())) . '" title="' . esc_attr__('Log out', 'idev-package') . '">⏻</a></li>';
});

add_action('admin_footer', function () {
    if (idev_app_mode()) echo '<script>(function(){var m=document.getElementById("adminmenu"),b=m&&m.querySelector(".idev-app-brand");if(b)m.insertBefore(b,m.firstChild)})();</script>';
});

/* ---------- Login screen ---------- */

add_action('login_enqueue_scripts', function () {
    if (!idev_app_site_on()) return;
    wp_enqueue_style('idev-applogin', plugins_url('assets/appmode.css', IDEV_PACKAGE_FILE), [], IDEV_PACKAGE_VERSION);
});
add_filter('login_headerurl', function ($u) { return idev_app_site_on() ? home_url('/') : $u; });
add_filter('login_headertext', function ($t) { return idev_app_site_on() ? idev_app_clinic_name() : $t; });
add_filter('login_body_class', function ($c) { if (idev_app_site_on()) $c[] = 'idev-applogin'; return $c; });
add_action('login_header', function () {
    if (!idev_app_site_on()) return;
    $logo = idev_app_logo();
    $feats = [__('Today\'s queue and doctor\'s room', 'idev-package'), __('Patient records, drug allergies, re-med', 'idev-package'), __('Dispensing, stock, receipts, PromptPay', 'idev-package'), __('Online appointments with reminders', 'idev-package')];
    echo '<aside class="idev-login-side"><div class="in">' . ($logo ? '<img class="lg" src="' . esc_url($logo) . '" alt="">' : '') . '<span class="pr">' . esc_html(IDEV_PACKAGE_NAME) . '</span><h1>' . esc_html(idev_app_clinic_name()) . '</h1><p>' . esc_html(function_exists('idev_pkg') ? idev_pkg()['desc'] : '') . '</p><ul>';
    foreach ($feats as $f) echo '<li>' . esc_html($f) . '</li>';
    echo '</ul><small>iDevApp · idevapp.me</small></div></aside>';
});
add_action('login_footer', function () {
    if (!idev_app_site_on()) return;
    echo '<script>document.querySelectorAll("#backtoblog a").forEach(function(a){a.textContent="← ' . esc_js(__('Patient services', 'idev-package')) . '"});</script>';
});
