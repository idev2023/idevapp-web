<?php
/*
 * ตั้งค่าตัวเชื่อมนัดหมาย → HOSxP (ตาราง oapp) — คัดลอกไฟล์นี้เป็น config.php แล้วแก้ค่า
 *
 * สำคัญ: ชื่อตาราง/คอลัมน์ด้านล่างเป็นเพียง "ตัวอย่าง" ผู้ดูแลระบบ HOSxP ของโรงพยาบาลต้องตรวจกับฐานข้อมูลจริง
 * (php hosxp-appointments.php --check) และทดสอบในโหมด dry-run ก่อนเปลี่ยนเป็น insert
 * การเขียนข้อมูลลงฐานข้อมูล HOSxP ต้องได้รับอนุญาตจาก BMS และโรงพยาบาล — โรงพยาบาลเป็นผู้ตัดสินใจและรับผิดชอบเอง
 */
return [
    // เว็บไซต์ และรหัสตัวเชื่อม (หลังบ้าน → Appointments → Reports & Pro → HOSxP → Create new connector key)
    'site_url' => 'https://example.com/',
    'token'    => 'idap_ใส่รหัสที่นี่',
    'api'      => 'idev-appt/v1/connector',   // ไม่ต้องแก้

    // ฐานข้อมูล HOSxP — แนะนำสร้าง user แยก ให้สิทธิ์เฉพาะ SELECT/INSERT/UPDATE ตาราง oapp และ SELECT/UPDATE serial
    'db' => [
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'name'    => 'hos',
        'user'    => 'web_appointment',
        'pass'    => '',
        'charset' => 'utf8',   // ถ้าฐานข้อมูลเป็น tis620 ให้ใส่ 'tis620'
    ],

    // dry-run = อ่านอย่างเดียว แสดงว่าจะบันทึกอะไร ไม่เขียน HOSxP ไม่ส่งผลกลับเว็บ (เริ่มต้นใช้โหมดนี้)
    // insert  = บันทึกนัดใหม่ / แก้วันเวลาเมื่อเลื่อน / ทำเครื่องหมายเมื่อยกเลิก
    'mode' => 'dry-run',

    'oapp_table' => 'oapp',
    'id_column'  => 'oapp_id',

    // วิธีออกเลข oapp_id ใหม่
    //   serial = ตาราง serial ของ HOSxP (name = 'oapp_id')
    //   max    = MAX(oapp_id) + 1
    //   auto   = คอลัมน์เป็น AUTO_INCREMENT (ให้ฐานข้อมูลออกเลขเอง)
    'id' => ['method' => 'serial', 'serial_table' => 'serial', 'serial_name' => 'oapp_id', 'name_column' => 'name', 'value_column' => 'serial_no'],

    // กันบันทึกซ้ำ: ค้นหานัดเดิมจาก hn + คอลัมน์ที่เก็บเลขอ้างอิงเว็บ (APT-...) ก่อนสร้างใหม่ — เว้นว่างเพื่อปิด
    'match_column' => 'note',

    // รหัสคลินิก/แพทย์ ถ้าหน้าเว็บไม่ได้ใส่ไว้ที่แพทย์/คลินิกนั้น
    'default_clinic' => '',
    'default_doctor' => '',

    // คอลัมน์ในตาราง oapp => ค่าที่บันทึกเมื่อสร้างนัดใหม่ ({...} คือข้อมูลจากเว็บ)
    // คอลัมน์ที่ไม่มีในฐานข้อมูลจะถูกข้ามพร้อมแจ้งเตือน
    // ข้อมูลที่มี: {oapp_id} {hn} {name} {phone} {date} {start} {end} {clinic} {doctor} {provider} {branch} {reason}
    //   {ref} {source} {cancel_reason} {today} {now} {time_now} {guid}
    'insert' => [
        'hos_guid'      => '{guid}',
        'oapp_id'       => '{oapp_id}',
        'hn'            => '{hn}',
        'clinic'        => '{clinic}',
        'doctor'        => '{doctor}',
        'nextdate'      => '{date}',
        'nexttime'      => '{start}',
        'nexttime_end'  => '{end}',
        'app_cause'     => '{reason}',
        'contact_point' => '{phone}',
        'note'          => 'นัดผ่านเว็บ {ref}',
        'entry_date'    => '{today}',
        'entry_time'    => '{time_now}',
        'app_user'      => 'web',
    ],

    // เมื่อผู้ป่วย/เจ้าหน้าที่เลื่อนนัดบนเว็บ
    'update' => [
        'nextdate'     => '{date}',
        'nexttime'     => '{start}',
        'nexttime_end' => '{end}',
        'clinic'       => '{clinic}',
        'doctor'       => '{doctor}',
        'note'         => 'นัดผ่านเว็บ {ref} (เลื่อนนัด {now})',
    ],

    // เมื่อยกเลิกบนเว็บ — ตัวเชื่อมไม่ลบแถวใน HOSxP เพียงแก้ค่าตามนี้ (ให้โรงพยาบาลกำหนดวิธีที่ถูกต้องเอง)
    'cancel' => [
        'note' => 'ยกเลิกผ่านเว็บ {ref} {now} {cancel_reason}',
    ],

    'timezone' => 'Asia/Bangkok',
    'log_file' => __DIR__ . '/connector.log',
];
