<?php
/** Designed e-mails for the six appointment messages (iDevApp e-mail designer) and the printed report look. */
defined('ABSPATH') || exit;

const IDEV_APRO_EMAIL_OPTION = 'idev_appt_email_design';

function idev_apro_mail_titles($lang) {
    $en = $lang === 'en';
    return ['received' => $en ? 'Appointment request received' : 'ได้รับคำขอนัดหมาย', 'confirmed' => $en ? 'Your appointment is confirmed' : 'ยืนยันนัดหมายแล้ว', 'reminder' => $en ? 'Appointment reminder' : 'แจ้งเตือนนัดหมาย', 'day' => $en ? 'Your appointment is today' : 'วันนี้มีนัดหมาย', 'cancelled' => $en ? 'Appointment cancelled' : 'ยกเลิกนัดหมายแล้ว', 'rescheduled' => $en ? 'Appointment moved' : 'เปลี่ยนเวลานัดแล้ว'];
}

/** Message text without the paragraphs that only repeat the details shown in the details box. */
function idev_apro_mail_body($tpl, $vars) {
    $keep = [];
    foreach (preg_split("/\n{2,}/", trim(str_replace("\r", '', (string) $tpl))) as $para) {
        $rest = preg_replace('/\{(provider|date|time|location|ref|status)\}|เวลา|เลขที่|at|,|·|–|-|\s/u', '', $para);
        if ($rest !== '') $keep[] = $para;
    }
    return strtr(implode("\n\n", $keep), $vars);
}

/** Parts of the e-mail: details box, button, calendar link, footer. */
function idev_apro_mail_parts($type, $lang, $vars, $body_tpl, $manage = '', $ics = '') {
    $en = $lang === 'en';
    $s = idev_appt_settings();
    $rows = [[$en ? 'Doctor / clinic' : 'แพทย์ / คลินิก', $vars['{provider}']], [$en ? 'Date' : 'วันที่', $vars['{date}']], [$en ? 'Time' : 'เวลา', $vars['{time}']]];
    if (($vars['{location}'] ?? '') !== '') $rows[] = [$en ? 'Place' : 'สถานที่', $vars['{location}']];
    $rows[] = [$en ? 'Reference' : 'เลขที่นัด', $vars['{ref}']];
    if ($type === 'received') $rows[] = [$en ? 'Status' : 'สถานะ', $en ? 'Waiting for confirmation' : 'รอเจ้าหน้าที่ยืนยัน'];
    $phone = $vars['{phone}'] ?? $s['phone'];
    $footer = trim(idev_pick($s['location'], $s['location_en'], $lang) . ($phone ? "\n" . ($en ? 'Questions? Call ' : 'สอบถาม โทร ') . $phone : ''));
    $title = idev_apro_mail_titles($lang)[$type] ?? '';
    return [
        'lang' => $lang, 'site' => $vars['{site}'], 'title' => $title, 'preheader' => $vars['{date}'] . ' ' . $vars['{time}'] . ' · ' . $vars['{provider}'],
        'text' => idev_apro_mail_body($body_tpl, $vars), 'rows' => $type === 'cancelled' ? array_slice($rows, 0, 3) : $rows,
        'button' => $manage && $type !== 'cancelled' ? [$en ? 'View, move or cancel' : 'ดู เลื่อน หรือยกเลิกนัด', $manage] : null,
        'links' => $ics && in_array($type, ['received', 'confirmed', 'rescheduled', 'reminder'], true) ? [[$en ? '+ Add to my calendar' : '+ เพิ่มลงปฏิทิน', $ics]] : [],
        'footer' => $footer,
    ];
}

add_filter('idev_appt_mail_render', function ($html, $type, $title, $text, $a) {
    if (!idev_apro_active()) return $html;
    $lang = ($a['p']['lang'] ?? 'th') === 'en' ? 'en' : 'th';
    $s = idev_appt_settings();
    $sfx = $lang === 'en' ? '_en' : '';
    $tpl = $s['tpl_' . $type . '_body' . $sfx] ?: $s['tpl_' . $type . '_body'];
    $vars = idev_appt_vars($a);
    $body = apply_filters('idev_appt_mail_text', $tpl, $type, $a); // LINE line etc.
    $manage = idev_appt_manage_url($a);
    $ics = $manage ? add_query_arg('t', idev_appt_token($a), rest_url('idev-appt/v1/ics')) : '';
    return idev_email_render(idev_email_design(IDEV_APRO_EMAIL_OPTION), idev_apro_mail_parts($type, $lang, $vars, $body, $manage, $ics));
}, 10, 5);

/* ---------- Designer ---------- */

function idev_apro_sample_vars($lang) {
    $en = $lang === 'en';
    $prov = $en ? 'Dr. Sample Goodheart · Internal medicine' : 'นพ.ตัวอย่าง ใจดี · อายุรกรรม';
    foreach (function_exists('idev_appt_providers') ? idev_appt_providers() : [] as $p) { $prov = idev_appt_provider_name($p, $lang); break; }
    $s = idev_appt_settings();
    $day = idev_add_days(idev_today(), 3);
    return ['{name}' => $en ? 'Ms. Somjai Sample' : 'คุณสมใจ ตัวอย่าง', '{ref}' => 'APT-' . wp_date('ymd') . '-AB12C', '{date}' => idev_format_day($day, $lang, true), '{time}' => '09:00–09:20',
        '{provider}' => $prov, '{location}' => idev_pick($s['location'], $s['location_en'], $lang) ?: ($en ? 'Building 1, 2nd floor' : 'อาคาร 1 ชั้น 2'), '{status}' => $en ? 'confirmed' : 'ยืนยันแล้ว',
        '{reason}' => $en ? 'Reason: the doctor is away' : 'เหตุผล: แพทย์ติดภารกิจ', '{phone}' => $s['phone'] ?: '076-000-000', '{site}' => get_bloginfo('name'), '{branch}' => '', '{link}' => home_url('/')];
}

add_action('init', function () {
    if (!function_exists('idev_register_email_designer')) return;
    idev_register_email_designer('appt', [
        'option' => IDEV_APRO_EMAIL_OPTION,
        'types' => idev_appt_mail_types(),
        'vars' => '{name} {ref} {date} {time} {provider} {location} {status} {reason} {phone} {site}',
        'texts' => function ($type) {
            $s = idev_appt_settings();
            return ['enabled' => ($s['mail_' . $type] ?? '0') === '1', 'subject' => $s['tpl_' . $type . '_subject'] ?? '', 'body' => $s['tpl_' . $type . '_body'] ?? '', 'subject_en' => $s['tpl_' . $type . '_subject_en'] ?? '', 'body_en' => $s['tpl_' . $type . '_body_en'] ?? ''];
        },
        'save_texts' => function ($type, $t) {
            $s = get_option('idev_appt_settings', []);
            $s = is_array($s) ? $s : [];
            $s['mail_' . $type] = $t['enabled'] ? '1' : '0';
            foreach (['subject', 'body', 'subject_en', 'body_en'] as $k) $s['tpl_' . $type . '_' . $k] = $t[$k];
            update_option('idev_appt_settings', $s);
        },
        'sample_vars' => 'idev_apro_sample_vars',
        'preview' => function ($type, $lang, $design, $t) {
            $vars = idev_apro_sample_vars($lang);
            $body = $t['body' . ($lang === 'en' ? '_en' : '')] ?: $t['body'];
            return idev_email_render($design, idev_apro_mail_parts($type, $lang, $vars, $body, home_url('/?appt=sample'), home_url('/?ics=sample')));
        },
        'locked' => function () { return idev_apro_active() ? '' : esc_html__('The trial has ended: e-mails use the plain built-in design until a licence key is entered.', 'idev-appointments-pro'); },
    ]);
    if (function_exists('idev_register_doc_designer')) idev_register_doc_designer('appt', [
        'option' => 'idev_appt_doc_design', 'docs' => ['report' => __('Appointment report', 'idev-appointments-pro')], 'papers' => ['a4' => 'A4', 'a4l' => __('A4 landscape', 'idev-appointments-pro')],
        'preview' => function ($doc, $design, $paper) {
            $args = ['from' => wp_date('Y-m-01'), 'to' => wp_date('Y-m-t'), 'branch' => '', 'provider' => 0];
            return idev_apro_report_page($args, idev_apro_report_data($args), $design, $paper ?: 'a4', true);
        },
    ]);
}, 30);
