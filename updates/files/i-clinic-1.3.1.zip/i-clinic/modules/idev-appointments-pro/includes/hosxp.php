<?php
/**
 * HOSxP connector (appointments → HOSxP "oapp").
 * The website never connects to HOSxP. A small program inside the hospital asks the website for new / changed / cancelled
 * appointments and writes them to HOSxP the way the hospital sets it up. Off until an administrator accepts the notice.
 */
defined('ABSPATH') || exit;

function idev_apro_hx_ready() {
    $s = idev_apro_settings();
    return $s['hx_on'] === '1' && $s['hx_accept'] !== '' && idev_apro_active();
}

/* ---------- Queue of changed appointments ---------- */

function idev_apro_hx_dirty() { $q = get_option('idev_apro_hx_dirty', []); return is_array($q) ? array_map('intval', $q) : []; }
function idev_apro_hx_mark($id) {
    if (!idev_apro_hx_ready()) return;
    $q = idev_apro_hx_dirty();
    if (!in_array((int) $id, $q, true)) { $q[] = (int) $id; update_option('idev_apro_hx_dirty', array_slice($q, -2000), false); }
}
add_action('idev_appt_created', function ($id) { idev_apro_hx_mark($id); }, 30);
add_action('idev_appt_status', function ($id) { idev_apro_hx_mark($id); }, 30);
add_action('idev_appt_rescheduled', function ($id) { idev_apro_hx_mark($id); }, 30);
add_action('idev_medreg_hn_issued', function ($reg_id) { // the HN arrived after booking: send those appointments now
    global $wpdb;
    $r = function_exists('idev_medreg_get') ? idev_medreg_get($reg_id) : null;
    if ($r) foreach ($wpdb->get_col($wpdb->prepare('SELECT id FROM %i WHERE reg_ref = %s', idev_appt_table(), $r['ref'])) as $id) idev_apro_hx_mark($id); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}, 20);

/** What the connector should do with this appointment, or null (skip / not yet). */
function idev_apro_hx_item($a) {
    $p = $a['p'];
    $hx = $p['_hx'] ?? [];
    $oapp = (string) ($hx['oapp_id'] ?? '');
    if ($a['status'] === 'cancelled' || $a['status'] === 'no_show') {
        if ($oapp === '') return ['skip' => true];
        $action = 'cancel';
    } elseif ($a['status'] === 'confirmed') {
        if (empty($p['hn'])) return null; // wait for the HN (registration approved / typed by staff)
        $action = 'upsert';
    } else {
        return ['skip' => true]; // pending (not confirmed yet) or completed: nothing to send
    }
    $prov = idev_apro_provider($a['provider_id']);
    return [
        'id' => (int) $a['id'], 'ref' => $a['ref'], 'action' => $action, 'oapp_id' => $oapp,
        'hn' => (string) ($p['hn'] ?? ''), 'name' => (string) ($p['name'] ?? ''), 'phone' => (string) ($p['phone'] ?? ''),
        'date' => $a['appt_date'], 'start' => $a['start_time'], 'end' => $a['end_time'],
        'clinic' => (string) get_post_meta($a['provider_id'], '_idev_apro_hx_clinic', true), 'doctor' => (string) get_post_meta($a['provider_id'], '_idev_apro_hx_doctor', true),
        'provider' => $prov ? $prov['name'] : '', 'branch' => idev_apro_branch_of($a['provider_id']),
        'reason' => (string) ($p['reason'] ?? ''), 'cancel_reason' => (string) ($p['cancel_reason'] ?? ''), 'source' => $a['source'],
    ];
}

function idev_apro_hx_queue() {
    $out = []; $keep = []; $wait = 0;
    foreach (idev_apro_hx_dirty() as $id) {
        if (count($out) >= 50) { $keep[] = $id; continue; } // next run
        $a = idev_appt_get($id);
        if (!$a) continue;
        $item = idev_apro_hx_item($a);
        if ($item === null) { if ($a['appt_date'] >= idev_today()) { $keep[] = $id; $wait++; } continue; } // still waiting for an HN
        if (!empty($item['skip'])) continue;
        $out[] = $item; $keep[] = $id; // removed when the connector sends the result
    }
    update_option('idev_apro_hx_dirty', $keep, false);
    return ['items' => $out, 'waiting_for_hn' => $wait];
}

function idev_apro_hx_result(WP_REST_Request $r) {
    $id = (int) $r->get_param('id');
    $status = sanitize_key((string) $r->get_param('status'));
    $a = idev_appt_get($id);
    if (!$a || !in_array($status, ['synced', 'cancelled', 'error'], true)) return new WP_Error('idev_bad', 'Unknown appointment or status', ['status' => 400]);
    $old = $a['p']['_hx'] ?? [];
    $a['p']['_hx'] = [
        'status' => $status, 'at' => time(),
        'oapp_id' => preg_replace('/[^0-9A-Za-z._-]/', '', (string) ($r->get_param('oapp_id') ?: ($old['oapp_id'] ?? ''))),
        'message' => mb_substr(sanitize_text_field((string) $r->get_param('message')), 0, 300),
    ];
    idev_appt_log($a['p'], 'HOSxP: ' . $status . ($a['p']['_hx']['oapp_id'] !== '' ? ' oapp ' . $a['p']['_hx']['oapp_id'] : '') . ($a['p']['_hx']['message'] !== '' ? ' — ' . $a['p']['_hx']['message'] : ''));
    idev_appt_save($id, $a['p']);
    update_option('idev_apro_hx_dirty', array_values(array_diff(idev_apro_hx_dirty(), [$id])), false);
    return ['ok' => true];
}

function idev_apro_hx_auth(WP_REST_Request $r) {
    $hash = get_option('idev_apro_hx_token_hash');
    $header = (string) $r->get_header('authorization');
    if (!$hash || stripos($header, 'Bearer ') !== 0 || !hash_equals($hash, hash('sha256', trim(substr($header, 7))))) return new WP_Error('idev_forbidden', 'Invalid token', ['status' => 401]);
    $allow = array_filter(array_map('trim', explode(',', (string) idev_apro_settings()['hx_ips'])));
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
    if ($allow && !in_array($ip, $allow, true)) return new WP_Error('idev_forbidden', 'IP address not allowed: ' . $ip, ['status' => 403]);
    if (!idev_apro_active()) return new WP_Error('idev_licence_required', 'The HOSxP connector needs an iDev Appointments Pro licence for ' . idev_license_domain() . ' (iDevApp → Licences).', ['status' => 402]);
    $s = idev_apro_settings();
    if ($s['hx_on'] !== '1' || $s['hx_accept'] === '') return new WP_Error('idev_off', 'The HOSxP connector is switched off on the website (Appointments → Pro → HOSxP).', ['status' => 409]);
    update_option('idev_apro_hx_seen', time(), false);
    return true;
}

add_action('rest_api_init', function () {
    register_rest_route('idev-appt/v1', '/connector/ping', ['methods' => 'GET', 'permission_callback' => 'idev_apro_hx_auth', 'callback' => function () { return ['ok' => true, 'site' => home_url('/'), 'plugin' => 'idev-appointments-pro', 'version' => IDEV_APRO_VERSION, 'waiting' => count(idev_apro_hx_dirty())]; }]);
    register_rest_route('idev-appt/v1', '/connector/queue', ['methods' => 'GET', 'permission_callback' => 'idev_apro_hx_auth', 'callback' => 'idev_apro_hx_queue']);
    register_rest_route('idev-appt/v1', '/connector/result', ['methods' => 'POST', 'permission_callback' => 'idev_apro_hx_auth', 'callback' => 'idev_apro_hx_result']);
});

/* ---------- Admin ---------- */

function idev_apro_hx_notice() {
    return __('The HOSxP connector is an optional tool. Connecting to the HOSxP database needs permission from BMS (the HOSxP developer) and the hospital\'s own approval. The hospital decides whether to use it, sets up which tables and columns it writes, tests it in dry-run mode and checks the data in HOSxP. iDevApp provides the tool as it is and is not responsible for data written to HOSxP, for the HOSxP system, or for any effect on hospital work.', 'idev-appointments-pro');
}

function idev_apro_tab_hosxp() {
    $s = idev_apro_settings();
    $new = get_transient('idev_apro_hx_new_token_' . get_current_user_id());
    if ($new) { delete_transient('idev_apro_hx_new_token_' . get_current_user_id()); echo '<div class="notice notice-warning inline"><p><strong>' . esc_html__('Connector key (copy it now — it will not be shown again):', 'idev-appointments-pro') . '</strong></p><p><code style="font-size:15px;user-select:all">' . esc_html($new) . '</code></p></div>'; }
    echo '<div class="idev-card idev-apro-warn"><h3>⚠ ' . esc_html__('Before you use it', 'idev-appointments-pro') . '</h3><p>' . esc_html(idev_apro_hx_notice()) . '</p>';
    if ($s['hx_accept'] !== '') {
        $acc = explode('|', $s['hx_accept']);
        /* translators: 1: user name, 2: date */
        echo '<p class="idev-apro-ok">✓ ' . esc_html(sprintf(__('Accepted by %1$s on %2$s', 'idev-appointments-pro'), $acc[1] ?? '', isset($acc[0]) ? wp_date('j M Y H:i', (int) $acc[0]) : '')) . '</p>';
    }
    echo '</div><form method="post"><input type="hidden" name="idev_apro_action" value="hosxp">' . wp_nonce_field('idev_apro_hosxp', '_wpnonce', true, false) . '<table class="form-table">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<tr><th>' . esc_html__('I understand', 'idev-appointments-pro') . '</th><td><label><input type="checkbox" name="hx_accept" value="1"' . checked($s['hx_accept'] !== '', true, false) . '> ' . esc_html__('The hospital has permission, decides to use the connector and is responsible for checking the data (notice above).', 'idev-appointments-pro') . '</label></td></tr>';
    echo '<tr><th>' . esc_html__('Connector', 'idev-appointments-pro') . '</th><td><label><input type="checkbox" name="hx_on" value="1"' . checked($s['hx_on'], '1', false) . '> ' . esc_html__('On — collect confirmed, moved and cancelled appointments for the connector', 'idev-appointments-pro') . '</label></td></tr>';
    echo '<tr><th>' . esc_html__('Connector IP addresses (optional)', 'idev-appointments-pro') . '</th><td><input class="regular-text" name="hx_ips" value="' . esc_attr($s['hx_ips']) . '"><p class="description">' . esc_html__('Public IP addresses of the hospital, separated by commas. Empty = any address with the right connector key.', 'idev-appointments-pro') . '</p></td></tr></table>';
    submit_button();
    echo '</form>';
    if ($s['hx_accept'] === '') return;
    $seen = (int) get_option('idev_apro_hx_seen');
    $link = function ($do, $label, $confirm = '') { return '<a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=idev_apro_hx&do=' . $do), 'idev_apro_hx')) . '"' . ($confirm ? ' onclick="return confirm(\'' . esc_js($confirm) . '\')"' : '') . '>' . esc_html($label) . '</a>'; };
    echo '<div class="idev-card"><h3>' . esc_html__('HOSxP connector', 'idev-appointments-pro') . '</h3>';
    echo '<p>' . esc_html__('Key:', 'idev-appointments-pro') . ' ' . (get_option('idev_apro_hx_token_hash') ? '✓' : '<strong>' . esc_html__('not created yet', 'idev-appointments-pro') . '</strong>') . ' · ' . esc_html__('Last contact:', 'idev-appointments-pro') . ' ' . ($seen ? esc_html(wp_date('j M Y H:i', $seen)) : esc_html__('never', 'idev-appointments-pro')) . ' · ' . esc_html__('Waiting:', 'idev-appointments-pro') . ' ' . (int) count(idev_apro_hx_dirty()) . '</p>';
    echo '<p>' . esc_html__('Website address for the connector:', 'idev-appointments-pro') . ' <code>' . esc_html(home_url('/')) . '</code> · API <code>idev-appt/v1/connector</code></p>';
    echo '<p>' . $link('token', __('Create new connector key', 'idev-appointments-pro'), __('Create a new key? The old one stops working immediately.', 'idev-appointments-pro')) . ' ' . $link('zip', __('Download connector (zip)', 'idev-appointments-pro')) . ' ' . $link('resend', __('Send upcoming appointments again', 'idev-appointments-pro'), __('Put every confirmed appointment from today on into the queue again?', 'idev-appointments-pro')) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- links escaped in $link
    echo '<ol class="description"><li>' . esc_html__('Set the HOSxP clinic and doctor codes on each doctor / clinic (Clinic schedule → edit).', 'idev-appointments-pro') . '</li><li>' . esc_html__('Give the zip to the hospital IT. They copy config.sample.php to config.php, enter the key and check the oapp table columns with --check.', 'idev-appointments-pro') . '</li><li>' . esc_html__('Run in dry-run mode first and compare with HOSxP. Change to insert only after the hospital has checked it.', 'idev-appointments-pro') . '</li><li>' . esc_html__('Only confirmed appointments with an HN are sent. Cancelled ones are sent only if they were sent before.', 'idev-appointments-pro') . '</li></ol></div>';
}

function idev_apro_save_hosxp() {
    $s = get_option('idev_apro_settings', []);
    $s = is_array($s) ? $s : [];
    $cur = idev_apro_settings();
    // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce checked by the caller
    if (!empty($_POST['hx_accept'])) { if ($cur['hx_accept'] === '') { $u = wp_get_current_user(); $s['hx_accept'] = time() . '|' . $u->user_login; } } else $s['hx_accept'] = '';
    $s['hx_on'] = !empty($_POST['hx_on']) && $s['hx_accept'] !== '' ? '1' : '0';
    $s['hx_ips'] = implode(', ', array_filter(array_map(function ($ip) { $ip = trim($ip); return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : ''; }, explode(',', sanitize_text_field(wp_unslash($_POST['hx_ips'] ?? ''))))));
    // phpcs:enable
    update_option('idev_apro_settings', $s, false);
}

add_action('admin_post_idev_apro_hx', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idev_apro_hx')) wp_die('Forbidden', 403);
    if (idev_apro_settings()['hx_accept'] === '') wp_die(esc_html__('Accept the notice on the HOSxP tab first.', 'idev-appointments-pro'), 409);
    $do = sanitize_key($_GET['do'] ?? '');
    if ($do === 'token') {
        $token = 'idap_' . bin2hex(random_bytes(24));
        update_option('idev_apro_hx_token_hash', hash('sha256', $token), false);
        set_transient('idev_apro_hx_new_token_' . get_current_user_id(), $token, 300);
        idev_apro_redirect(idev_apro_url('hosxp'));
    }
    if ($do === 'resend') {
        global $wpdb;
        $ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM %i WHERE appt_date >= %s AND status = 'confirmed' ORDER BY appt_date, start_time LIMIT 2000", idev_appt_table(), idev_today())); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        update_option('idev_apro_hx_dirty', array_values(array_unique(array_merge(idev_apro_hx_dirty(), array_map('intval', $ids)))), false);
        /* translators: %d: number */
        idev_apro_redirect(idev_apro_url('hosxp'), sprintf(__('%d appointments put in the queue.', 'idev-appointments-pro'), count($ids)));
    }
    $dir = IDEV_APRO_DIR . '/connector';
    $zip_path = wp_tempnam('hosxp-appointments.zip');
    $zip = new ZipArchive();
    $zip->open($zip_path, ZipArchive::OVERWRITE);
    foreach (['hosxp-appointments.php', 'config.sample.php', 'README-TH.md'] as $f) if (is_file("$dir/$f")) $zip->addFile("$dir/$f", "hosxp-appointments/$f");
    $zip->close();
    nocache_headers();
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="hosxp-appointments.zip"');
    header('Content-Length: ' . filesize($zip_path));
    readfile($zip_path); // phpcs:ignore WordPress.WP.AlternativeFunctions
    wp_delete_file($zip_path);
    exit;
});
