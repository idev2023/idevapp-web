<?php
/**
 * WhatsApp: automatic messages through the WhatsApp Business Cloud API (Meta) and a click-to-chat button for staff.
 * Meta only allows messages that start a conversation through templates approved in WhatsApp Manager, so each event
 * has a template name; the values ({name}, {date} …) are sent as the template's {{1}}, {{2}} … in the order set here.
 */
defined('ABSPATH') || exit;

function idev_apro_wa_on() {
    $s = idev_apro_settings();
    return $s['wa_on'] === '1' && $s['wa_phone_id'] !== '' && $s['wa_token'] !== '';
}

/** E.164 digits for WhatsApp: Thai 0XXXXXXXXX → 66XXXXXXXXX, others as given (+ removed). */
function idev_apro_wa_number($phone) { return idev_apro_msisdn($phone); }

/** Returns [ok, info]; info 'skip' when the event has no template. */
function idev_apro_send_wa($phone, $event, $vars, $lang = 'th') {
    $s = idev_apro_settings();
    $tpl = trim((string) ($s['wa_t_' . $event] ?? ''));
    if ($tpl === '') return [false, 'skip'];
    $to = idev_apro_wa_number($phone);
    if (strlen($to) < 9) return [false, 'no phone'];
    $params = [];
    foreach (array_filter(array_map('trim', explode('|', (string) $s['wa_params']))) as $ph) {
        $v = trim((string) strtr($ph, $vars));
        $params[] = ['type' => 'text', 'text' => $v !== '' ? mb_substr($v, 0, 1000) : '-'];
    }
    $body = ['messaging_product' => 'whatsapp', 'to' => $to, 'type' => 'template', 'template' => ['name' => $tpl, 'language' => ['code' => $lang === 'en' ? ($s['wa_lang_en'] ?: 'en') : ($s['wa_lang_th'] ?: 'th')]]];
    if ($params) $body['template']['components'] = [['type' => 'body', 'parameters' => $params]];
    $res = wp_remote_post('https://graph.facebook.com/' . rawurlencode($s['wa_api'] ?: 'v21.0') . '/' . rawurlencode($s['wa_phone_id']) . '/messages', [
        'timeout' => 20, 'headers' => ['Authorization' => 'Bearer ' . $s['wa_token'], 'Content-Type' => 'application/json'], 'body' => wp_json_encode($body, JSON_UNESCAPED_UNICODE),
    ]);
    if (is_wp_error($res)) return [false, $res->get_error_message()];
    $code = wp_remote_retrieve_response_code($res);
    $json = json_decode(wp_remote_retrieve_body($res), true);
    if ($code >= 200 && $code < 300) return [true, 'HTTP ' . $code . ' ' . ($json['messages'][0]['id'] ?? '')];
    return [false, 'HTTP ' . $code . ' ' . mb_substr((string) ($json['error']['message'] ?? wp_remote_retrieve_body($res)), 0, 160)];
}

/* Click-to-chat in the Appointments screen and the doctor portal: opens WhatsApp with the message filled in. */
add_filter('idev_appt_portal_row', function ($row, $a) {
    $s = idev_apro_settings();
    if (!idev_apro_active() || $s['wa_click'] !== '1' || empty($row['phone']) || empty($a['p'])) return $row;
    $event = ['pending' => 'received', 'cancelled' => 'cancelled'][$a['status']] ?? ($a['appt_date'] === idev_today() ? 'day' : ($a['status'] === 'confirmed' ? 'reminder' : 'confirmed'));
    $lang = ($a['p']['lang'] ?? 'th') === 'en' ? 'en' : 'th';
    $text = idev_apro_text($event, idev_appt_vars($a) + ['{link}' => idev_appt_manage_url($a), '{branch}' => ''], $lang);
    $row['links'][] = ['WhatsApp', 'https://wa.me/' . idev_apro_wa_number($row['phone']) . '?text=' . rawurlencode($text)];
    return $row;
}, 10, 2);

function idev_apro_wa_fields() {
    $f = [
        ['heading_wa', 'WhatsApp', 'heading', __('Automatic messages need a WhatsApp Business account on the Meta Cloud API and message templates approved by Meta. The click-to-chat button works without an account.', 'idev-appointments-pro')],
        ['wa_click', __('Click-to-chat button', 'idev-appointments-pro'), 'checkbox', __('A WhatsApp button on each appointment (Appointments screen and doctor portal) opens WhatsApp with the message filled in. Free, sent by the staff member.', 'idev-appointments-pro')],
        ['wa_on', __('Automatic WhatsApp messages', 'idev-appointments-pro'), 'checkbox'],
        ['wa_phone_id', __('Phone number ID', 'idev-appointments-pro'), 'text', __('Meta for Developers → your app → WhatsApp → API Setup.', 'idev-appointments-pro')],
        ['wa_token', __('Access token', 'idev-appointments-pro'), 'text', __('A permanent token of a system user (Business Settings → System users). Meta charges per conversation.', 'idev-appointments-pro')],
        ['wa_lang_th', __('Template language (Thai)', 'idev-appointments-pro'), 'text'], ['wa_lang_en', __('Template language (English)', 'idev-appointments-pro'), 'text'],
        ['wa_params', __('Values sent as {{1}}, {{2}} …', 'idev-appointments-pro'), 'text', __('Separated by |. Example template text: "{{1}} your appointment on {{2}} at {{3}} with {{4}} (ref. {{5}})".', 'idev-appointments-pro')],
    ];
    foreach (idev_apro_events() + ['waitlist' => __('Waiting list: a time is free', 'idev-appointments-pro')] as $k => $l) $f[] = ['wa_t_' . $k, sprintf(__('Template name: %s', 'idev-appointments-pro'), $l), 'text'];
    $f[] = ['chat_first', __('Chat first', 'idev-appointments-pro'), 'checkbox', __('Do not send the SMS when the message reached the patient on LINE or WhatsApp (saves SMS costs).', 'idev-appointments-pro')];
    return $f;
}
