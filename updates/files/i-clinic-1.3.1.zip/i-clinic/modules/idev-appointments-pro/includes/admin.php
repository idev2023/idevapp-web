<?php
/** Appointments → Pro: reports, waiting list, branches, LINE / SMS, HOSxP. */
defined('ABSPATH') || exit;

function idev_apro_tabs() {
    $t = ['home' => __('Overview', 'idev-appointments-pro'), 'reports' => __('Reports', 'idev-appointments-pro'), 'waitlist' => __('Waiting list', 'idev-appointments-pro')];
    if (current_user_can('manage_options')) $t += ['messages' => __('LINE · WhatsApp · SMS', 'idev-appointments-pro'), 'emails' => __('E-mail design', 'idev-appointments-pro'), 'docs' => __('Print design', 'idev-appointments-pro'), 'branches' => __('Branches', 'idev-appointments-pro'), 'hosxp' => 'HOSxP'];
    return $t;
}

add_action('admin_menu', function () {
    add_submenu_page('idev-appt', __('Appointments Pro', 'idev-appointments-pro'), __('Reports & Pro', 'idev-appointments-pro'), 'idev_appt_manage', 'idev-apro', 'idev_apro_page');
}, 20);

add_action('admin_enqueue_scripts', function ($hook) {
    if (strpos((string) $hook, 'idev-apro') === false) return;
    wp_register_style('idev-apro-admin', false, [], IDEV_APRO_VERSION);
    wp_enqueue_style('idev-apro-admin');
    wp_add_inline_style('idev-apro-admin', '.idev-apro-ok{color:#047857;font-weight:600}.idev-apro-bad{color:#b91c1c;font-weight:600}.idev-apro-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin:14px 0}.idev-apro-two{display:grid;grid-template-columns:1fr 1fr;gap:20px}@media(max-width:900px){.idev-apro-two{grid-template-columns:1fr}}.idev-apro-bar{display:inline-block;height:10px;background:#0f766e;border-radius:3px;vertical-align:middle;min-width:2px}.idev-apro-filter{display:flex;flex-wrap:wrap;gap:6px;align-items:center;background:#fff;border:1px solid #e2e6ea;border-radius:12px;padding:10px;margin:0 0 12px}.idev-apro-warn{border-left:4px solid #d97706}td.r,th.r{text-align:right}.idev-ch-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:14px}.idev-ch{background:#fff;border:1px solid #e2e6ea;border-radius:14px;padding:4px 18px 10px}.idev-ch h2{display:flex;align-items:center;gap:8px;font-size:16px}.idev-ch h2 svg{width:22px;height:22px}.idev-ch .form-table,.idev-ch .form-table tbody,.idev-ch .form-table tr,.idev-ch .form-table th,.idev-ch .form-table td{display:block;width:auto;padding:2px 0}.idev-ch .form-table tr{margin-bottom:10px}.idev-ch .regular-text{width:100%}.idev-ch .form-table th{font-weight:600}.idev-ch-line h2 svg{color:#06c755}.idev-ch-wa h2 svg{color:#25d366}.idev-ch-sms h2 svg{color:#2563eb}.idev-ch .idev-chip{margin-left:auto}.idev-texts summary{cursor:pointer;font-weight:600;padding:10px 0}');
});

function idev_apro_page() {
    $tabs = idev_apro_tabs();
    $tab = sanitize_key($_GET['tab'] ?? 'home'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (!isset($tabs[$tab])) $tab = 'home';
    $chip = idev_apro_licensed() ? [__('Licensed', 'idev-appointments-pro'), 'ok'] : (idev_apro_active() ? [idev_apro_status_text(), 'trial'] : [idev_apro_status_text(), 'off']);
    idev_page_open(__('Appointments Pro', 'idev-appointments-pro'), __('Reminders on LINE, WhatsApp and SMS, waiting list, branches, reports and designed e-mails', 'idev-appointments-pro'), [
        'tabs' => $tabs, 'current' => $tab, 'url' => 'idev_apro_url', 'chip' => $chip, 'help' => 'https://idevapp.me/plugins/idev-appointments/#pro',
        'icons' => ['home' => 'home', 'reports' => 'chart', 'waitlist' => 'list', 'messages' => 'chat', 'emails' => 'mail', 'docs' => 'receipt', 'branches' => 'building', 'hosxp' => 'refresh'],
    ]);
    echo wp_kses_post(idev_apro_banner());
    idev_apro_flash();
    if (isset($_GET['saved'])) echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Saved.', 'idev-appointments-pro') . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (!idev_apro_active() && !in_array($tab, ['home', 'reports'], true)) echo '<div class="notice notice-warning inline"><p>' . esc_html__('Paused: the trial has ended. Settings can still be changed.', 'idev-appointments-pro') . '</p></div>';
    if ($tab === 'emails') idev_email_designer_ui('appt', idev_apro_url('emails'));
    elseif ($tab === 'docs') idev_doc_designer_ui('appt', idev_apro_url('docs'));
    else call_user_func('idev_apro_tab_' . $tab);
    idev_page_close();
}

/** Overview: today, the last 30 days, channels and what is left to set up. */
function idev_apro_tab_home() {
    global $wpdb;
    $t = idev_appt_table();
    $today = idev_today();
    // phpcs:disable WordPress.DB.DirectDatabaseQuery
    $n_today = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE appt_date=%s AND status IN ('pending','confirmed','completed','no_show')", $t, $today));
    $n_pending = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE status='pending' AND appt_date>=%s", $t, $today));
    $n_week = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE appt_date BETWEEN %s AND %s AND status IN ('pending','confirmed')", $t, $today, idev_add_days($today, 6)));
    $st = $wpdb->get_results($wpdb->prepare('SELECT status, COUNT(*) n FROM %i WHERE appt_date BETWEEN %s AND %s GROUP BY status', $t, idev_add_days($today, -30), idev_add_days($today, -1)), OBJECT_K);
    $wait = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE status IN ('waiting','notified')", idev_apro_t('waitlist')));
    $msg = $wpdb->get_row($wpdb->prepare('SELECT SUM(ok=1) ok, SUM(ok=0) bad FROM %i WHERE created_at >= %s', idev_apro_t('messages'), gmdate('Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS)), ARRAY_A);
    // phpcs:enable
    $came = (int) ($st['completed']->n ?? 0); $ns = (int) ($st['no_show']->n ?? 0);
    $cards = [[number_format_i18n($n_today), __('Appointments today', 'idev-appointments-pro'), 'accent'], [number_format_i18n($n_pending), __('Waiting for confirmation', 'idev-appointments-pro'), ''], [number_format_i18n($n_week), __('Next 7 days', 'idev-appointments-pro'), ''],
        [idev_apro_rate($ns, $ns + $came), __('No-show rate (30 days)', 'idev-appointments-pro'), ''], [number_format_i18n($wait), __('On the waiting list', 'idev-appointments-pro'), ''], [number_format_i18n((int) ($msg['ok'] ?? 0)), __('Messages sent (7 days)', 'idev-appointments-pro') . ((int) ($msg['bad'] ?? 0) ? ' · ' . sprintf(__('%d failed', 'idev-appointments-pro'), (int) $msg['bad']) : ''), '']];
    echo '<div class="idev-stats">';
    foreach ($cards as [$v, $l, $c]) echo '<div class="idev-stat ' . esc_attr($c) . '"><strong>' . esc_html($v) . '</strong><span>' . esc_html($l) . '</span></div>';
    echo '</div>';
    if (!current_user_can('manage_options')) return;
    $s = idev_apro_settings();
    $steps = [
        [$s['line_token'] !== '' && $s['line_secret'] !== '', __('Connect LINE Official Account', 'idev-appointments-pro'), __('Patients link LINE by sending their appointment reference; reminders then go to LINE.', 'idev-appointments-pro'), 'messages'],
        [idev_apro_wa_on() || $s['wa_click'] === '1', __('WhatsApp for foreign patients', 'idev-appointments-pro'), __('Click-to-chat button for staff, or automatic messages through the Meta Cloud API.', 'idev-appointments-pro'), 'messages'],
        [$s['sms'] !== 'none', __('SMS for everyone else', 'idev-appointments-pro'), __('ThaiBulkSMS or any SMS service by webhook.', 'idev-appointments-pro'), 'messages'],
        [(bool) get_option(IDEV_APRO_EMAIL_OPTION), __('Design the e-mails', 'idev-appointments-pro'), __('Choose a template, add your logo and colours, check the six messages.', 'idev-appointments-pro'), 'emails'],
        [(bool) idev_apro_branches(), __('Branches (if you have more than one)', 'idev-appointments-pro'), __('A booking page per branch and staff who see only their branch.', 'idev-appointments-pro'), 'branches'],
        [$s['wait_on'] === '1', __('Waiting list', 'idev-appointments-pro'), __('When a day is full, patients leave their name and hear when a time is free.', 'idev-appointments-pro'), 'waitlist'],
    ];
    echo '<div class="idev-apro-two"><div class="idev-card"><h2>' . esc_html__('Set up', 'idev-appointments-pro') . '</h2><ol class="idev-steps">';
    foreach ($steps as [$done, $title, $desc, $tab]) echo '<li class="' . ($done ? 'done' : '') . '"><div><b>' . esc_html($title) . '</b><small>' . esc_html($desc) . '</small></div><a class="button' . ($done ? '' : ' button-primary') . '" href="' . esc_url(idev_apro_url($tab)) . '">' . esc_html($done ? __('Change', 'idev-appointments-pro') : __('Set up', 'idev-appointments-pro')) . '</a></li>';
    echo '</ol></div><div class="idev-card"><h2>' . esc_html__('Channels', 'idev-appointments-pro') . '</h2><table class="widefat striped"><tbody>';
    $ch = [['LINE', $s['line_token'] !== '' && $s['line_secret'] !== ''], ['WhatsApp API', idev_apro_wa_on()], [__('WhatsApp click-to-chat', 'idev-appointments-pro'), $s['wa_click'] === '1'], ['SMS', $s['sms'] !== 'none'], [__('E-mail', 'idev-appointments-pro'), true]];
    foreach ($ch as [$n, $on]) echo '<tr><td>' . esc_html($n) . '</td><td class="r">' . ($on ? '<span class="idev-apro-ok">● ' . esc_html__('On', 'idev-appointments-pro') . '</span>' : '<span style="color:#8a8f98">○ ' . esc_html__('Off', 'idev-appointments-pro') . '</span>') . '</td></tr>';
    echo '</tbody></table><p><a class="button" href="' . esc_url(idev_apro_url('reports')) . '">' . esc_html__('Open reports', 'idev-appointments-pro') . '</a> <a class="button" href="' . esc_url(admin_url('admin.php?page=idev-appt')) . '">' . esc_html__('Appointments', 'idev-appointments-pro') . '</a></p></div></div>';
}

/* Form posts on the Pro screen. */
add_action('admin_init', function () {
    if (empty($_POST['idev_apro_action'])) return;
    $action = sanitize_key(wp_unslash($_POST['idev_apro_action']));
    $admin_only = ['branches', 'messages', 'test_sms', 'hosxp'];
    if (!current_user_can(in_array($action, $admin_only, true) ? 'manage_options' : 'idev_appt_manage')) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-appointments-pro'), 403);
    check_admin_referer('idev_apro_' . $action);
    switch ($action) {
        case 'branches':
            idev_apro_save_branches();
            idev_apro_redirect(idev_apro_url('branches'), __('Branches saved.', 'idev-appointments-pro'));
            break;
        case 'messages':
            $old = idev_apro_settings();
            $in = (array) ($_POST['idev_apro'] ?? []); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized by idev_settings_sanitize
            $new = idev_settings_sanitize(idev_apro_message_fields(), $in, $old);
            foreach (idev_apro_secret_keys() as $k) if (($new[$k] ?? '') === '') $new[$k] = $old[$k];
            update_option('idev_apro_settings', array_intersect_key(array_merge($old, $new), idev_apro_defaults()), false);
            idev_apro_redirect(idev_apro_url('messages'), __('Settings saved.', 'idev-appointments-pro'));
            break;
        case 'test_sms':
            $phone = sanitize_text_field(wp_unslash($_POST['phone'] ?? ''));
            /* translators: %s: site name */
            $via = ($_POST['via'] ?? '') === 'wa' ? 'wa' : 'sms';
            if ($via === 'wa') {
                [$ok, $info] = idev_apro_send_wa($phone, 'confirmed', idev_apro_sample_vars('th'), 'th');
                if ($info === 'skip') { $ok = false; $info = __('Enter the template name for "Confirmed" first.', 'idev-appointments-pro'); }
            } else {
                [$ok, $info] = idev_apro_send_sms($phone, sprintf(__('%s: test message from iDev Appointments Pro', 'idev-appointments-pro'), get_bloginfo('name')), ['event' => 'test', 'ref' => '']);
            }
            idev_apro_log_msg(0, 0, $via, 'test', idev_apro_mask($phone), $ok, $info);
            idev_apro_redirect(idev_apro_url('messages'), ($ok ? __('Sent.', 'idev-appointments-pro') : __('Not sent:', 'idev-appointments-pro')) . ' ' . $info, $ok ? 'success' : 'error');
            break;
        case 'wait_settings':
            $old = idev_apro_settings();
            $fields = [['wait_on', '', 'checkbox'], ['wait_notify', '', 'number', '', [1, 20]], ['wait_days', '', 'number', '', [1, 180]]];
            $new = idev_settings_sanitize($fields, (array) ($_POST['idev_apro'] ?? []), $old); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            update_option('idev_apro_settings', array_intersect_key(array_merge($old, $new), idev_apro_defaults()), false);
            idev_apro_redirect(idev_apro_url('waitlist'), __('Settings saved.', 'idev-appointments-pro'));
            break;
        case 'wait_status':
            global $wpdb;
            $status = sanitize_key($_POST['status'] ?? '');
            if (in_array($status, ['booked', 'closed'], true)) $wpdb->update(idev_apro_t('waitlist'), ['status' => $status], ['id' => (int) ($_POST['id'] ?? 0)]); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            idev_apro_redirect(wp_get_referer() ?: idev_apro_url('waitlist'));
            break;
        case 'hosxp':
            idev_apro_save_hosxp();
            idev_apro_redirect(idev_apro_url('hosxp'), __('Settings saved.', 'idev-appointments-pro'));
            break;
    }
});
