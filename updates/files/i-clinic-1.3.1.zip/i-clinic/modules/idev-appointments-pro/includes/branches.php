<?php
/**
 * Branches: each doctor/clinic belongs to a branch; the booking page can show one branch (?branch=code or the block setting),
 * e-mails and messages use the branch's address and phone, and staff can be limited to their branches.
 */
defined('ABSPATH') || exit;

/** [code => [name, name_en, address, address_en, phone]] */
function idev_apro_branches() {
    $b = get_option('idev_apro_branches', []);
    return is_array($b) ? $b : [];
}
function idev_apro_branch_of($provider_id) { return (string) get_post_meta((int) $provider_id, '_idev_apro_branch', true); }
function idev_apro_branch_name($code, $lang = null) {
    $b = idev_apro_branches()[$code] ?? null;
    return $b ? idev_pick($b['name'], $b['name_en'] ?? '', $lang) : '';
}

/* Doctor / clinic edit screen: branch, HOSxP codes. */
add_action('idev_appt_provider_box_after', function ($post) {
    $branches = idev_apro_branches();
    $cur = idev_apro_branch_of($post->ID);
    echo '<hr><p><strong>' . esc_html__('Appointments Pro', 'idev-appointments-pro') . '</strong></p>';
    if ($branches) {
        echo '<label>' . esc_html__('Branch', 'idev-appointments-pro') . '<select name="idev_apro[branch]"><option value="">—</option>';
        foreach ($branches as $code => $b) echo '<option value="' . esc_attr($code) . '"' . selected($cur, $code, false) . '>' . esc_html($b['name']) . '</option>';
        echo '</select></label>';
    }
    echo '<label>' . esc_html__('HOSxP clinic code', 'idev-appointments-pro') . '<input name="idev_apro[hx_clinic]" value="' . esc_attr(get_post_meta($post->ID, '_idev_apro_hx_clinic', true)) . '" placeholder="001"></label>';
    echo '<label>' . esc_html__('HOSxP doctor code', 'idev-appointments-pro') . '<input name="idev_apro[hx_doctor]" value="' . esc_attr(get_post_meta($post->ID, '_idev_apro_hx_doctor', true)) . '" placeholder="0001"></label>';
});
add_action('idev_appt_provider_saved', function ($id) {
    if (!isset($_POST['idev_apro'])) return; // nonce checked by iDev Appointments before this action
    $in = map_deep(wp_unslash((array) $_POST['idev_apro']), 'sanitize_text_field'); // phpcs:ignore WordPress.Security.NonceVerification.Missing
    if (isset($in['branch'])) update_post_meta($id, '_idev_apro_branch', array_key_exists($in['branch'], idev_apro_branches()) ? $in['branch'] : '');
    foreach (['hx_clinic', 'hx_doctor'] as $k) update_post_meta($id, '_idev_apro_' . $k, preg_replace('/[^0-9A-Za-z._-]/', '', (string) ($in[$k] ?? '')));
});

/* Booking page: one branch. */
add_filter('idev_appt_public_providers', function ($list, $r) {
    $code = sanitize_key((string) $r->get_param('branch'));
    if ($code === '' || !idev_apro_active()) return $list;
    return array_values(array_filter($list, function ($p) use ($code) { return idev_apro_branch_of($p['id']) === $code; }));
}, 10, 2);

/* E-mails and messages: the branch address and phone. */
add_filter('idev_appt_vars', function ($vars, $a, $lang) {
    if (!idev_apro_active()) return $vars;
    $b = idev_apro_branches()[idev_apro_branch_of($a['provider_id'])] ?? null;
    if (!$b) return $vars;
    $vars['{branch}'] = idev_pick($b['name'], $b['name_en'] ?? '', $lang);
    $addr = idev_pick($b['address'] ?? '', $b['address_en'] ?? '', $lang);
    if ($addr !== '') $vars['{location}'] = trim($vars['{branch}'] . ' ' . $addr);
    if (!empty($b['phone'])) $vars['{phone}'] = $b['phone'];
    return $vars;
}, 10, 3);

/* Staff limited to their branches (user profile). Administrators always see everything. */
add_filter('idev_appt_user_providers', function ($ids, $user_id) {
    if (!idev_apro_active() || user_can($user_id, 'manage_options')) return $ids;
    $mine = (array) get_user_meta($user_id, 'idev_apro_branches', true);
    $mine = array_filter($mine);
    if (!$mine) return $ids;
    return array_values(array_filter($ids, function ($id) use ($mine) { return in_array(idev_apro_branch_of($id), $mine, true); }));
}, 10, 2);
$idev_apro_user_box = function ($user) {
    if (!current_user_can('manage_options') || !idev_apro_branches()) return;
    $mine = (array) get_user_meta($user->ID, 'idev_apro_branches', true);
    echo '<h2>' . esc_html__('Appointment branches', 'idev-appointments-pro') . '</h2><table class="form-table"><tr><th>' . esc_html__('Sees appointments of', 'idev-appointments-pro') . '</th><td>';
    wp_nonce_field('idev_apro_user', 'idev_apro_user_nonce');
    foreach (idev_apro_branches() as $code => $b) echo '<label style="display:block"><input type="checkbox" name="idev_apro_branches[]" value="' . esc_attr($code) . '"' . checked(in_array($code, $mine, true), true, false) . '> ' . esc_html($b['name']) . '</label>';
    echo '<p class="description">' . esc_html__('None ticked = all branches. Applies to staff and doctors in the Appointments screen and the doctor portal.', 'idev-appointments-pro') . '</p></td></tr></table>';
};
add_action('show_user_profile', $idev_apro_user_box);
add_action('edit_user_profile', $idev_apro_user_box);
$idev_apro_user_save = function ($user_id) {
    if (!current_user_can('manage_options') || !isset($_POST['idev_apro_user_nonce']) || !wp_verify_nonce(sanitize_key($_POST['idev_apro_user_nonce']), 'idev_apro_user')) return;
    $codes = array_values(array_intersect(array_keys(idev_apro_branches()), array_map('sanitize_key', (array) wp_unslash($_POST['idev_apro_branches'] ?? []))));
    update_user_meta($user_id, 'idev_apro_branches', $codes);
};
add_action('personal_options_update', $idev_apro_user_save);
add_action('edit_user_profile_update', $idev_apro_user_save);

/* [idev_branches] — choose a branch, then book. */
function idev_apro_branches_html() {
    $url = idev_appt_booking_url();
    $lang = idev_lang();
    if (!$url || !idev_apro_branches()) return '';
    $o = '<div class="idev-apro-branches">';
    foreach (idev_apro_branches() as $code => $b) {
        $o .= '<a class="idev-apro-branch" href="' . esc_url(add_query_arg('branch', $code, $url)) . '"><strong>' . esc_html(idev_pick($b['name'], $b['name_en'] ?? '', $lang)) . '</strong>';
        $addr = idev_pick($b['address'] ?? '', $b['address_en'] ?? '', $lang);
        if ($addr !== '') $o .= '<span>' . esc_html($addr) . '</span>';
        if (!empty($b['phone'])) $o .= '<span>☎ ' . esc_html($b['phone']) . '</span>';
        $o .= '</a>';
    }
    return $o . '</div>';
}
add_shortcode('idev_branches', function () { wp_enqueue_style('idev-apro-front', plugins_url('assets/front.css', IDEV_APRO_FILE), [], IDEV_APRO_VERSION); return idev_apro_branches_html(); });
add_action('init', function () {
    idev_register_block('idev/branches', __('Branches (book an appointment)', 'idev-appointments-pro'), 'location', __('List of branches; each opens the booking page for that branch.', 'idev-appointments-pro'), [], function () { wp_enqueue_style('idev-apro-front', plugins_url('assets/front.css', IDEV_APRO_FILE), [], IDEV_APRO_VERSION); return idev_apro_branches_html(); });
});

/* Admin tab */
function idev_apro_tab_branches() {
    $branches = idev_apro_branches();
    echo '<p class="description">' . esc_html__('Add branches, then choose the branch on each doctor / clinic (Clinic schedule → edit → Online booking). Booking page for one branch: add ?branch=CODE to its address, set "Branch code" on the booking block, or use [idev_branches] to let visitors choose.', 'idev-appointments-pro') . '</p>';
    echo '<form method="post"><input type="hidden" name="idev_apro_action" value="branches">' . wp_nonce_field('idev_apro_branches', '_wpnonce', true, false) . '<table class="widefat striped"><thead><tr><th>' . esc_html__('Code', 'idev-appointments-pro') . '</th><th>' . esc_html__('Name (Thai)', 'idev-appointments-pro') . '</th><th>' . esc_html__('Name (English)', 'idev-appointments-pro') . '</th><th>' . esc_html__('Address (Thai)', 'idev-appointments-pro') . '</th><th>' . esc_html__('Address (English)', 'idev-appointments-pro') . '</th><th>' . esc_html__('Phone', 'idev-appointments-pro') . '</th><th>' . esc_html__('Doctors / clinics', 'idev-appointments-pro') . '</th></tr></thead><tbody>';
    $count = [];
    foreach (function_exists('idev_cs_providers') ? idev_cs_providers(true) : [] as $p) { $c = idev_apro_branch_of($p['id']); if ($c !== '') $count[$c] = ($count[$c] ?? 0) + 1; }
    $rows = $branches + ['' => []];
    $i = 0;
    foreach ($rows as $code => $b) {
        $f = function ($k, $w = '') use ($b, $i) { return '<input name="b[' . $i . '][' . $k . ']" value="' . esc_attr($b[$k] ?? '') . '"' . ($w ? ' style="width:' . $w . '"' : '') . '>'; };
        echo '<tr><td><input name="b[' . $i . '][code]" value="' . esc_attr($code) . '" style="width:90px" placeholder="' . ($code === '' ? esc_attr__('new', 'idev-appointments-pro') : '') . '"></td><td>' . $f('name') . '</td><td>' . $f('name_en') . '</td><td>' . $f('address') . '</td><td>' . $f('address_en') . '</td><td>' . $f('phone', '120px') . '</td><td>' . (int) ($count[$code] ?? 0) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- inputs escaped in $f
        $i++;
    }
    echo '</tbody></table><p class="description">' . esc_html__('Code: short English letters or numbers (e.g. main, north). Empty the code to delete a branch.', 'idev-appointments-pro') . '</p>';
    submit_button(__('Save branches', 'idev-appointments-pro'));
    echo '</form>';
    if ($branches) echo '<div class="idev-card"><h3>' . esc_html__('Booking links', 'idev-appointments-pro') . '</h3><ul>' . implode('', array_map(function ($code) { $u = idev_appt_booking_url(); return '<li><code>' . esc_html($u ? add_query_arg('branch', $code, $u) : '?branch=' . $code) . '</code></li>'; }, array_keys($branches))) . '</ul><p>' . esc_html__('Shortcode for a page that lists the branches:', 'idev-appointments-pro') . ' <code>[idev_branches]</code></p></div>';
}
function idev_apro_save_branches() {
    $out = [];
    foreach ((array) wp_unslash($_POST['b'] ?? []) as $row) { // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nonce checked by the caller; fields sanitized below
        $code = sanitize_key($row['code'] ?? '');
        if ($code === '' || empty($row['name'])) continue;
        $out[$code] = ['name' => sanitize_text_field($row['name']), 'name_en' => sanitize_text_field($row['name_en'] ?? ''), 'address' => sanitize_text_field($row['address'] ?? ''), 'address_en' => sanitize_text_field($row['address_en'] ?? ''), 'phone' => sanitize_text_field($row['phone'] ?? '')];
    }
    update_option('idev_apro_branches', $out, false);
}
