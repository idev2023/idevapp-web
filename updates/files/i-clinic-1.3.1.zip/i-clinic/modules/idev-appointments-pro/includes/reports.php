<?php
/** Reports: totals, no-show and cancellation rates by doctor/clinic, branch, weekday and hour; printable and CSV. */
defined('ABSPATH') || exit;

function idev_apro_report_args() {
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only filters
    $from = sanitize_text_field(wp_unslash($_GET['from'] ?? ''));
    $to = sanitize_text_field(wp_unslash($_GET['to'] ?? ''));
    $args = [
        'from' => idev_is_valid_date($from) ? $from : wp_date('Y-m-01'),
        'to' => idev_is_valid_date($to) ? $to : wp_date('Y-m-t'),
        'branch' => sanitize_key($_GET['branch'] ?? ''),
        'provider' => (int) ($_GET['provider'] ?? 0),
    ];
    // phpcs:enable
    return $args;
}

/** Appointment rows (not decrypted) for the filters. */
function idev_apro_report_rows($args) {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare('SELECT id, ref, provider_id, appt_date, start_time, status, source, created_at, data FROM %i WHERE appt_date BETWEEN %s AND %s ORDER BY appt_date, start_time', idev_appt_table(), $args['from'], $args['to']), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    $allowed = current_user_can('manage_options') ? null : idev_appt_user_providers();
    return array_values(array_filter($rows, function ($r) use ($args, $allowed) {
        if ($args['provider'] && (int) $r['provider_id'] !== $args['provider']) return false;
        if ($args['branch'] !== '' && idev_apro_branch_of($r['provider_id']) !== $args['branch']) return false;
        if ($allowed !== null && !in_array((int) $r['provider_id'], $allowed, true)) return false;
        return true;
    }));
}

function idev_apro_report_data($args) {
    $rows = idev_apro_report_rows($args);
    $st = array_fill_keys(array_keys(idev_appt_statuses()), 0);
    $by = []; $wd = array_fill(1, 7, 0); $hours = []; $src = []; $lead = []; $branches = [];
    foreach ($rows as $r) {
        $st[$r['status']] = ($st[$r['status']] ?? 0) + 1;
        $pid = (int) $r['provider_id'];
        $by[$pid] = $by[$pid] ?? array_fill_keys(array_keys(idev_appt_statuses()), 0) + ['total' => 0];
        $by[$pid][$r['status']]++; $by[$pid]['total']++;
        $b = idev_apro_branch_of($pid);
        $branches[$b] = $branches[$b] ?? ['total' => 0, 'no_show' => 0, 'completed' => 0, 'cancelled' => 0];
        $branches[$b]['total']++;
        if (isset($branches[$b][$r['status']])) $branches[$b][$r['status']]++;
        if ($r['status'] !== 'cancelled') { $wd[(int) wp_date('N', strtotime($r['appt_date'] . ' 12:00'))]++; $h = substr($r['start_time'], 0, 2); $hours[$h] = ($hours[$h] ?? 0) + 1; }
        $src[$r['source']] = ($src[$r['source']] ?? 0) + 1;
        $lead[] = max(0, (strtotime($r['appt_date'] . ' ' . $r['start_time']) - strtotime(get_date_from_gmt($r['created_at']))) / DAY_IN_SECONDS);
    }
    ksort($hours);
    return ['rows' => $rows, 'total' => count($rows), 'status' => $st, 'by' => $by, 'weekday' => $wd, 'hours' => $hours, 'source' => $src, 'branches' => $branches, 'lead' => $lead ? array_sum($lead) / count($lead) : 0];
}
function idev_apro_rate($a, $b) { return $b > 0 ? round($a * 100 / $b, 1) . '%' : '—'; }

function idev_apro_report_html($args, $d) {
    $labels = idev_appt_statuses();
    $o = '<div class="idev-apro-stats">';
    $cards = [[__('Appointments', 'idev-appointments-pro'), number_format_i18n($d['total'])],
        [__('Came', 'idev-appointments-pro'), number_format_i18n($d['status']['completed'])],
        [__('Did not come (no-show)', 'idev-appointments-pro'), idev_apro_rate($d['status']['no_show'], $d['status']['no_show'] + $d['status']['completed'])],
        [__('Cancelled', 'idev-appointments-pro'), idev_apro_rate($d['status']['cancelled'], $d['total'])],
        [__('Booked ahead (average days)', 'idev-appointments-pro'), number_format_i18n($d['lead'], 1)]];
    foreach ($cards as [$l, $v]) $o .= '<div class="idev-stat"><strong>' . esc_html($v) . '</strong><span>' . esc_html($l) . '</span></div>';
    $o .= '</div><p class="description">' . esc_html__('No-show rate = did not come ÷ (came + did not come). Mark appointments as Done or Did not come in the Appointments screen so the rates are right.', 'idev-appointments-pro') . '</p>';
    $o .= '<h3>' . esc_html__('By status', 'idev-appointments-pro') . '</h3><table class="widefat striped"><tbody>';
    foreach ($d['status'] as $k => $n) $o .= '<tr><td>' . esc_html($labels[$k] ?? $k) . '</td><td class="r">' . esc_html(number_format_i18n($n)) . '</td><td class="r">' . esc_html(idev_apro_rate($n, $d['total'])) . '</td></tr>';
    $o .= '</tbody></table><h3>' . esc_html__('By doctor / clinic', 'idev-appointments-pro') . '</h3><table class="widefat striped"><thead><tr><th>' . esc_html__('Doctor / clinic', 'idev-appointments-pro') . '</th><th>' . esc_html__('Branch', 'idev-appointments-pro') . '</th><th class="r">' . esc_html__('Total', 'idev-appointments-pro') . '</th><th class="r">' . esc_html($labels['completed']) . '</th><th class="r">' . esc_html($labels['no_show']) . '</th><th class="r">' . esc_html($labels['cancelled']) . '</th><th class="r">' . esc_html__('No-show rate', 'idev-appointments-pro') . '</th></tr></thead><tbody>';
    uasort($d['by'], function ($a, $b) { return $b['total'] <=> $a['total']; });
    foreach ($d['by'] as $pid => $x) { $p = idev_apro_provider($pid); $o .= '<tr><td>' . esc_html($p ? $p['name'] : '#' . $pid) . '</td><td>' . esc_html(idev_apro_branch_name(idev_apro_branch_of($pid))) . '</td><td class="r">' . (int) $x['total'] . '</td><td class="r">' . (int) $x['completed'] . '</td><td class="r">' . (int) $x['no_show'] . '</td><td class="r">' . (int) $x['cancelled'] . '</td><td class="r">' . esc_html(idev_apro_rate($x['no_show'], $x['no_show'] + $x['completed'])) . '</td></tr>'; }
    if (!$d['by']) $o .= '<tr><td colspan="7">—</td></tr>';
    $o .= '</tbody></table>';
    if (count($d['branches']) > 1 || (count($d['branches']) === 1 && !isset($d['branches']['']))) {
        $o .= '<h3>' . esc_html__('By branch', 'idev-appointments-pro') . '</h3><table class="widefat striped"><tbody>';
        foreach ($d['branches'] as $b => $x) $o .= '<tr><td>' . esc_html($b === '' ? __('(no branch)', 'idev-appointments-pro') : idev_apro_branch_name($b)) . '</td><td class="r">' . (int) $x['total'] . '</td><td class="r">' . esc_html__('No-show rate', 'idev-appointments-pro') . ' ' . esc_html(idev_apro_rate($x['no_show'], $x['no_show'] + $x['completed'])) . '</td></tr>';
        $o .= '</tbody></table>';
    }
    $days = idev_weekdays(idev_lang());
    $max = max(1, max($d['weekday']));
    $o .= '<div class="idev-apro-two"><div><h3>' . esc_html__('Busiest days', 'idev-appointments-pro') . '</h3><table class="widefat">';
    foreach ($d['weekday'] as $i => $n) $o .= '<tr><td style="width:90px">' . esc_html($days[$i - 1] ?? $i) . '</td><td><span class="idev-apro-bar" style="width:' . round($n * 85 / $max) . '%"></span> ' . (int) $n . '</td></tr>';
    $o .= '</table></div><div><h3>' . esc_html__('Busiest hours', 'idev-appointments-pro') . '</h3><table class="widefat">';
    $hmax = max(1, $d['hours'] ? max($d['hours']) : 1);
    foreach ($d['hours'] as $h => $n) $o .= '<tr><td style="width:90px">' . esc_html($h . ':00') . '</td><td><span class="idev-apro-bar" style="width:' . round($n * 85 / $hmax) . '%"></span> ' . (int) $n . '</td></tr>';
    if (!$d['hours']) $o .= '<tr><td>—</td></tr>';
    $o .= '</table></div></div><h3>' . esc_html__('Booked by', 'idev-appointments-pro') . '</h3><p>';
    $src = ['web' => __('Patients online', 'idev-appointments-pro'), 'staff' => __('Staff', 'idev-appointments-pro')];
    foreach ($d['source'] as $k => $n) $o .= esc_html(($src[$k] ?? $k) . ': ' . $n . ' (' . idev_apro_rate($n, $d['total']) . ')') . ' &nbsp; ';
    return $o . '</p>';
}

function idev_apro_tab_reports() {
    $args = idev_apro_report_args();
    $d = idev_apro_report_data($args);
    echo '<form method="get" class="idev-apro-filter"><input type="hidden" name="page" value="idev-apro"><input type="hidden" name="tab" value="reports"><input type="date" name="from" value="' . esc_attr($args['from']) . '"> – <input type="date" name="to" value="' . esc_attr($args['to']) . '"> ';
    if (idev_apro_branches()) { echo '<select name="branch"><option value="">' . esc_html__('All branches', 'idev-appointments-pro') . '</option>'; foreach (idev_apro_branches() as $c => $b) echo '<option value="' . esc_attr($c) . '"' . selected($args['branch'], $c, false) . '>' . esc_html($b['name']) . '</option>'; echo '</select> '; }
    echo '<select name="provider"><option value="0">' . esc_html__('All doctors / clinics', 'idev-appointments-pro') . '</option>';
    foreach (function_exists('idev_cs_providers') ? idev_cs_providers(true) : [] as $p) echo '<option value="' . (int) $p['id'] . '"' . selected($args['provider'], (int) $p['id'], false) . '>' . esc_html($p['name']) . '</option>';
    $q = ['action' => 'idev_apro_report', '_wpnonce' => wp_create_nonce('idev_apro_report')] + $args;
    echo '</select> <button class="button button-primary">' . esc_html__('Show', 'idev-appointments-pro') . '</button> <a class="button" target="_blank" href="' . esc_url(add_query_arg($q + ['what' => 'print'], admin_url('admin-post.php'))) . '">🖨 ' . esc_html__('Print', 'idev-appointments-pro') . '</a> <a class="button" href="' . esc_url(add_query_arg($q + ['what' => 'csv'], admin_url('admin-post.php'))) . '">' . esc_html__('Download list (CSV)', 'idev-appointments-pro') . '</a></form>';
    echo wp_kses_post(idev_apro_report_html($args, $d));
}

add_action('admin_post_idev_apro_report', function () {
    if (!current_user_can('idev_appt_manage') || !wp_verify_nonce(sanitize_key($_GET['_wpnonce'] ?? ''), 'idev_apro_report')) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-appointments-pro'), 403);
    $args = idev_apro_report_args();
    $d = idev_apro_report_data($args);
    nocache_headers();
    if (($_GET['what'] ?? '') === 'csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="appointments-' . $args['from'] . '-' . $args['to'] . '.csv"');
        $out = fopen('php://output', 'w'); // phpcs:ignore WordPress.WP.AlternativeFunctions
        fwrite($out, "\xEF\xBB\xBF"); // phpcs:ignore WordPress.WP.AlternativeFunctions
        $personal = current_user_can('manage_options');
        fputcsv($out, array_merge(['ref', 'date', 'time', 'doctor_clinic', 'branch', 'status', 'booked_by', 'booked_at'], $personal ? ['name', 'hn', 'phone'] : []));
        $labels = idev_appt_statuses();
        foreach ($d['rows'] as $r) {
            $p = idev_apro_provider($r['provider_id']);
            $line = [$r['ref'], $r['appt_date'], $r['start_time'], $p ? $p['name'] : $r['provider_id'], idev_apro_branch_name(idev_apro_branch_of($r['provider_id'])), $labels[$r['status']] ?? $r['status'], $r['source'], get_date_from_gmt($r['created_at'], 'Y-m-d H:i')];
            if ($personal) { $x = idev_appt_hydrate($r)['p']; $line = array_merge($line, [$x['name'] ?? '', $x['hn'] ?? '', $x['phone'] ?? '']); }
            fputcsv($out, array_map(function ($v) { return preg_match('/^[=+\-@\t\r]/', (string) $v) ? "'" . $v : $v; }, $line));
        }
        fclose($out); // phpcs:ignore WordPress.WP.AlternativeFunctions
        exit;
    }
    $paper = sanitize_key($_GET['paper'] ?? '') === 'a4l' ? 'a4l' : 'a4'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    echo idev_apro_report_page($args, $d, idev_doc_design('idev_appt_doc_design'), $paper, false); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts
    exit;
});

/** The printed report (iDevApp document look). */
function idev_apro_report_page($args, $d, $design, $paper = 'a4', $preview = false) {
    $sub = idev_format_day($args['from']) . ' – ' . idev_format_day($args['to']) . ($args['branch'] ? ' · ' . idev_apro_branch_name($args['branch']) : '') . ($args['provider'] && ($p = idev_apro_provider($args['provider'])) ? ' · ' . $p['name'] : '');
    $s = idev_appt_settings();
    $q = ['action' => 'idev_apro_report', 'what' => 'print', '_wpnonce' => wp_create_nonce('idev_apro_report')] + $args;
    $css = '<style>.idev-apro-stats{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin:10px 0}.idev-stat{border:1px solid #c9d0d6;border-radius:8px;padding:8px}.idev-stat strong{display:block;font-size:18px;color:var(--dc)}.idev-stat span{font-size:.85em;color:#444}.idev-apro-two{display:grid;grid-template-columns:1fr 1fr;gap:16px}.idev-apro-bar{display:inline-block;height:10px;background:var(--dc);border-radius:3px;vertical-align:middle}.description{color:#555;font-size:11.5px}h3{color:var(--dc)}</style>';
    return idev_doc_page([
        'title' => __('Appointment report', 'idev-appointments-pro'), 'design' => $design, 'paper' => $paper, 'preview' => $preview, 'trial' => !idev_apro_licensed(),
        'org' => ['name' => get_bloginfo('name'), 'address' => idev_pick($s['location'], $s['location_en']), 'phone' => $s['phone'], 'meta' => '<p class="muted">' . esc_html($sub) . '</p>'],
        'papers' => ['A4' => add_query_arg($q + ['paper' => 'a4'], admin_url('admin-post.php')), __('A4 landscape', 'idev-appointments-pro') => add_query_arg($q + ['paper' => 'a4l'], admin_url('admin-post.php'))],
        'body' => $css . wp_kses_post(idev_apro_report_html($args, $d)) . idev_doc_signatures($design) . idev_doc_footer($design, wp_date('j M Y H:i')),
    ]);
}
