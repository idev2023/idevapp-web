<?php
/** Tables, settings, licence and trial, helpers. */
defined('ABSPATH') || exit;

function idev_apro_t($name) { global $wpdb; return $wpdb->prefix . 'idev_apro_' . $name; }

function idev_apro_install() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $c = $wpdb->get_charset_collate();
    dbDelta('CREATE TABLE ' . idev_apro_t('messages') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  appt_id bigint(20) unsigned NOT NULL DEFAULT 0,
  wait_id bigint(20) unsigned NOT NULL DEFAULT 0,
  channel varchar(10) NOT NULL,
  event varchar(20) NOT NULL,
  recipient varchar(40) NOT NULL DEFAULT '',
  ok tinyint(1) NOT NULL DEFAULT 0,
  info varchar(255) NOT NULL DEFAULT '',
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY appt_id (appt_id),
  KEY created_at (created_at)
) $c;");
    dbDelta('CREATE TABLE ' . idev_apro_t('waitlist') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  ref varchar(24) NOT NULL,
  provider_id bigint(20) unsigned NOT NULL,
  date_from date DEFAULT NULL,
  date_to date DEFAULT NULL,
  status varchar(12) NOT NULL DEFAULT 'waiting',
  data longtext NOT NULL,
  patient_key char(64) NOT NULL DEFAULT '',
  offered varchar(255) NOT NULL DEFAULT '',
  notified_at datetime DEFAULT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY provider (provider_id, status),
  KEY patient_key (patient_key)
) $c;");
    dbDelta('CREATE TABLE ' . idev_apro_t('line') . " (
  patient_key char(64) NOT NULL,
  user_id varchar(64) NOT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (patient_key),
  KEY user_id (user_id)
) $c;");
    if (!get_option('idev_apro_trial_start')) update_option('idev_apro_trial_start', time(), false);
    update_option('idev_apro_db', IDEV_APRO_VERSION, false);
}
add_action('plugins_loaded', function () { if (get_option('idev_apro_db') !== IDEV_APRO_VERSION) idev_apro_install(); }, 21);

add_action('init', function () {
    load_plugin_textdomain('idev-appointments-pro', false, dirname(plugin_basename(IDEV_APRO_FILE)) . '/languages');
});

/* ---------- Licence: product "appt" (keys issued for iDev Appointments 1.1 and the I-Clinic / I-Drug packages work) ---------- */

const IDEV_APRO_TRIAL_DAYS = 14;

add_action('init', function () {
    if (!function_exists('idev_register_license')) return;
    idev_register_license('appt', [
        'name' => 'iDev Appointments Pro', 'plugin' => 'idev-appointments-pro',
        /* translators: %d: number of days */
        'free' => sprintf(__('Free trial for %d days after installing.', 'idev-appointments-pro'), IDEV_APRO_TRIAL_DAYS),
        'pro' => __('LINE and SMS reminders, waiting list, branches, reports and the HOSxP connector. Lifetime, one website.', 'idev-appointments-pro'),
        'price' => '3,900 ' . __('THB', 'idev-appointments-pro'),
        'note' => __('Connecting to the HOSxP database needs permission from BMS (the HOSxP developer). How the connector writes to HOSxP is decided and checked by the hospital.', 'idev-appointments-pro'),
        'usage' => function () { return esc_html(idev_apro_status_text()); },
    ]);
    idev_register_plugin('idev-appointments-pro', ['name' => 'iDev Appointments Pro', 'version' => IDEV_APRO_VERSION, 'description' => __('LINE / SMS reminders, waiting list, branches, reports and HOSxP connector.', 'idev-appointments-pro'), 'settings' => admin_url('admin.php?page=idev-apro'), 'docs' => 'https://idevapp.me/plugins/idev-appointments/#pro']);
}, 5);
add_action('plugins_loaded', function () { if (function_exists('idev_plugin_links')) idev_plugin_links(IDEV_APRO_FILE, admin_url('admin.php?page=idev-apro'), 'https://idevapp.me/plugins/idev-appointments/#pro'); }, 25);

function idev_apro_licensed() { return function_exists('idev_is_licensed') && idev_is_licensed('appt'); }
function idev_apro_trial_left() {
    $start = (int) get_option('idev_apro_trial_start', time());
    return max(0, (int) ceil(($start + IDEV_APRO_TRIAL_DAYS * DAY_IN_SECONDS - time()) / DAY_IN_SECONDS));
}
/** Pro features run when licensed or during the trial. */
function idev_apro_active() { return idev_apro_licensed() || idev_apro_trial_left() > 0; }
function idev_apro_status_text() {
    if (idev_apro_licensed()) return __('Licensed', 'idev-appointments-pro');
    $left = idev_apro_trial_left();
    /* translators: %d: days */
    return $left ? sprintf(_n('Trial: %d day left', 'Trial: %d days left', $left, 'idev-appointments-pro'), $left) : __('Trial ended — Pro features are paused', 'idev-appointments-pro');
}
function idev_apro_banner() {
    if (idev_apro_licensed() || !current_user_can('manage_options')) return '';
    $left = idev_apro_trial_left();
    $msg = $left
        /* translators: %d: days */
        ? sprintf(_n('Trial: %d day left. Every Pro feature works; reports say "TRIAL".', 'Trial: %d days left. Every Pro feature works; reports say "TRIAL".', $left, 'idev-appointments-pro'), $left)
        : __('The trial has ended: reminders, the waiting list, branches and the HOSxP connector are paused. Enter a licence key to turn them on again. Your settings and data are kept.', 'idev-appointments-pro');
    return idev_license_upsell('appt', esc_html($msg));
}

/* ---------- Settings ---------- */

function idev_apro_defaults() {
    return [
        'sms' => 'none', 'sms_key' => '', 'sms_secret' => '', 'sms_sender' => '', 'webhook_url' => '', 'webhook_secret' => '',
        'line_token' => '', 'line_secret' => '', 'line_oa' => '',
        'wa_click' => '1', 'wa_on' => '0', 'wa_phone_id' => '', 'wa_token' => '', 'wa_api' => 'v21.0', 'wa_lang_th' => 'th', 'wa_lang_en' => 'en', 'wa_params' => '{name}|{date}|{time}|{provider}|{ref}',
        'wa_t_received' => '', 'wa_t_confirmed' => '', 'wa_t_reminder' => '', 'wa_t_day' => '', 'wa_t_cancelled' => '', 'wa_t_rescheduled' => '', 'wa_t_waitlist' => '', 'chat_first' => '1',
        'ev_received' => '0', 'ev_confirmed' => '1', 'ev_reminder' => '1', 'ev_day' => '0', 'ev_cancelled' => '1', 'ev_rescheduled' => '1',
        'm_received' => '{site}: ได้รับคำขอนัด {ref} {date} {time} {provider} รอยืนยัน',
        'm_confirmed' => '{site}: ยืนยันนัด {date} {time} {provider} เลขที่ {ref} ดู/เลื่อน/ยกเลิก {link}',
        'm_reminder' => '{site}: เตือนนัด {date} {time} {provider} {location} เลื่อน/ยกเลิก {link}',
        'm_day' => '{site}: วันนี้มีนัด {time} {provider} {location}',
        'm_cancelled' => '{site}: ยกเลิกนัด {ref} {date} {time} แล้ว {reason}',
        'm_rescheduled' => '{site}: เปลี่ยนนัดเป็น {date} {time} {provider} เลขที่ {ref} {link}',
        'm_waitlist' => '{site}: มีคิวว่าง {date} กับ {provider} จองได้ที่ {link} (ใครจองก่อนได้ก่อน)',
        'm_received_en' => '{site}: appointment request {ref} {date} {time} {provider} received, waiting for confirmation',
        'm_confirmed_en' => '{site}: appointment confirmed {date} {time} {provider}, ref {ref}. View/move/cancel {link}',
        'm_reminder_en' => '{site}: reminder {date} {time} {provider} {location}. Move/cancel {link}',
        'm_day_en' => '{site}: your appointment today {time} {provider} {location}',
        'm_cancelled_en' => '{site}: appointment {ref} {date} {time} cancelled {reason}',
        'm_rescheduled_en' => '{site}: appointment moved to {date} {time} {provider}, ref {ref} {link}',
        'm_waitlist_en' => '{site}: a time is free on {date} with {provider}. Book at {link} (first come, first served)',
        'wait_on' => '1', 'wait_notify' => '3', 'wait_days' => '30',
        'hx_on' => '0', 'hx_accept' => '', 'hx_ips' => '',
    ];
}
function idev_apro_settings() { $s = get_option('idev_apro_settings', []); return array_merge(idev_apro_defaults(), is_array($s) ? $s : []); }

/* ---------- Helpers ---------- */

function idev_apro_url($tab = 'reports', $args = []) { return add_query_arg(array_merge(['page' => 'idev-apro', 'tab' => $tab], $args), admin_url('admin.php')); }
function idev_apro_mask($phone) { $d = preg_replace('/\D/', '', (string) $phone); return strlen($d) > 4 ? str_repeat('•', strlen($d) - 4) . substr($d, -4) : $d; }
function idev_apro_redirect($url, $msg = '', $type = 'success') {
    if ($msg !== '') set_transient('idev_apro_flash_' . get_current_user_id(), [$msg, $type], 60);
    wp_safe_redirect($url);
    exit;
}
function idev_apro_flash() {
    $f = get_transient('idev_apro_flash_' . get_current_user_id());
    if (!$f) return;
    delete_transient('idev_apro_flash_' . get_current_user_id());
    echo '<div class="notice notice-' . esc_attr($f[1]) . ' is-dismissible"><p>' . esc_html($f[0]) . '</p></div>';
}
/** Provider (doctor / clinic) record even when booking is switched off. */
function idev_apro_provider($id) {
    $post = get_post((int) $id);
    if (!$post || !function_exists('idev_cs_provider')) return null;
    return idev_cs_provider($post) + ['appt' => idev_appt_provider_cfg($post->ID)];
}
