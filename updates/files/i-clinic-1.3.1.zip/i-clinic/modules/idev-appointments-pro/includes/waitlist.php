<?php
/**
 * Waiting list: when no time suits, a patient leaves their name for a doctor/clinic and a range of dates.
 * When an appointment in that range is cancelled or moved, the first people waiting get a message with a booking link
 * (first come, first served — nothing is held for them).
 */
defined('ABSPATH') || exit;

function idev_apro_wait_statuses() {
    return ['waiting' => __('Waiting', 'idev-appointments-pro'), 'notified' => __('Told about a free time', 'idev-appointments-pro'), 'booked' => __('Booked', 'idev-appointments-pro'), 'closed' => __('Closed', 'idev-appointments-pro')];
}

/* ---------- Form under the booking page ---------- */

add_filter('idev_appt_booking_after', function ($html, $cfg) {
    $s = idev_apro_settings();
    if (!idev_apro_active() || $s['wait_on'] !== '1') return $html;
    $lang = $cfg['lang'] ?? idev_lang();
    $en = $lang === 'en';
    wp_enqueue_style('idev-apro-front', plugins_url('assets/front.css', IDEV_APRO_FILE), [], IDEV_APRO_VERSION);
    wp_enqueue_script('idev-apro-wait', plugins_url('assets/waitlist.js', IDEV_APRO_FILE), [], IDEV_APRO_VERSION, true);
    $providers = idev_appt_providers();
    if (!empty($cfg['branch'])) $providers = array_values(array_filter($providers, function ($p) use ($cfg) { return idev_apro_branch_of($p['id']) === $cfg['branch']; }));
    if (!$providers) return $html;
    $pre = (int) ($cfg['provider']['id'] ?? 0);
    $o = '<details class="idev-apro-wait" data-api="' . esc_attr(rest_url('idev-apro/v1/waitlist')) . '" data-lang="' . esc_attr($lang) . '"><summary>' . esc_html($en ? 'No time that suits you? Join the waiting list' : 'ไม่มีเวลาที่สะดวก? ลงชื่อรอคิวว่าง') . '</summary><form novalidate>';
    $o .= '<p class="idev-apro-wait-intro">' . esc_html($en ? 'If an appointment is cancelled, we will send you a message with a link to book that time. First come, first served.' : 'ถ้ามีผู้ยกเลิกนัด เราจะส่งข้อความพร้อมลิงก์ให้จองเวลานั้น ใครจองก่อนได้ก่อน') . '</p>';
    $o .= '<label>' . esc_html($en ? 'Doctor / clinic' : 'แพทย์ / คลินิก') . '<select name="provider" required>';
    foreach ($providers as $p) $o .= '<option value="' . (int) $p['id'] . '"' . selected($pre, (int) $p['id'], false) . '>' . esc_html(idev_appt_provider_name($p, $lang)) . '</option>';
    $o .= '</select></label><div class="idev-apro-grid"><label>' . esc_html($en ? 'From' : 'ตั้งแต่วันที่') . '<input type="date" name="from" min="' . esc_attr(idev_today()) . '" value="' . esc_attr(idev_today()) . '"></label><label>' . esc_html($en ? 'To' : 'ถึงวันที่') . '<input type="date" name="to" min="' . esc_attr(idev_today()) . '" value="' . esc_attr(idev_add_days(idev_today(), (int) $s['wait_days'])) . '"></label>';
    $o .= '<label>' . esc_html($en ? 'Full name' : 'ชื่อ-นามสกุล') . ' *<input name="name" required maxlength="120" autocomplete="name"></label><label>' . esc_html($en ? 'Mobile phone' : 'เบอร์มือถือ') . ' *<input name="phone" type="tel" required maxlength="20" autocomplete="tel"></label>';
    $o .= '<label>' . esc_html($en ? 'E-mail' : 'อีเมล') . '<input name="email" type="email" maxlength="120" autocomplete="email"></label><label>HN<input name="hn" maxlength="20"></label></div>';
    $o .= '<p class="idev-apro-hp" aria-hidden="true"><input name="website" tabindex="-1" autocomplete="off"></p>';
    $o .= '<label class="idev-apro-check"><input type="checkbox" name="consent" value="1" required> <span>' . esc_html($en ? 'I agree that my name and contact details are kept to tell me about a free time, and deleted after the dates above.' : 'ยินยอมให้เก็บชื่อและช่องทางติดต่อเพื่อแจ้งเมื่อมีคิวว่าง และลบเมื่อพ้นช่วงวันที่ข้างต้น') . '</span></label>';
    $o .= '<p><button type="submit">' . esc_html($en ? 'Join the waiting list' : 'ลงชื่อรอคิว') . '</button></p><div class="idev-apro-msg" role="status" aria-live="polite"></div></form></details>';
    return $html . $o;
}, 10, 2);

add_action('rest_api_init', function () {
    register_rest_route('idev-apro/v1', '/waitlist', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'idev_apro_wait_rest']);
});
function idev_apro_wait_rest(WP_REST_Request $r) {
    global $wpdb;
    $en = $r->get_param('lang') === 'en';
    $m = function ($th, $e) use ($en) { return $en ? $e : $th; };
    $err = function ($msg, $code = 400) { return new WP_REST_Response(['ok' => false, 'error' => $msg], $code); };
    if (!idev_apro_active() || idev_apro_settings()['wait_on'] !== '1') return $err($m('ปิดรับรายชื่อรอคิว', 'The waiting list is closed'), 403);
    if (trim((string) $r->get_param('website')) !== '') return ['ok' => true];
    if (!$r->get_param('consent')) return $err($m('กรุณากดยินยอม', 'Please tick the consent box'));
    $ip = hash('sha256', sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? '')) . wp_salt('nonce'));
    $rate = 'idev_apro_wait_' . substr($ip, 0, 20);
    if ((int) get_transient($rate) >= 5) return $err($m('ส่งบ่อยเกินไป กรุณาลองใหม่ภายหลัง', 'Too many tries. Please try later.'), 429);
    $provider = idev_appt_provider((int) $r->get_param('provider'));
    if (!$provider) return $err($m('ไม่พบแพทย์/คลินิก', 'Doctor or clinic not found'));
    $name = mb_substr(sanitize_text_field((string) $r->get_param('name')), 0, 120);
    $phone = preg_replace('/[^\d+]/', '', (string) $r->get_param('phone'));
    $email = sanitize_email((string) $r->get_param('email'));
    if ($name === '' || strlen(preg_replace('/\D/', '', $phone)) < 9) return $err($m('กรุณากรอกชื่อและเบอร์มือถือ', 'Please enter your name and mobile number'));
    $today = idev_today();
    $from = idev_is_valid_date((string) $r->get_param('from')) ? max($today, (string) $r->get_param('from')) : $today;
    $to = idev_is_valid_date((string) $r->get_param('to')) ? (string) $r->get_param('to') : idev_add_days($from, (int) idev_apro_settings()['wait_days']);
    if ($to < $from) $to = $from;
    $hn = strtoupper(preg_replace('/[^0-9A-Za-z-]/', '', (string) $r->get_param('hn')));
    $key = $hn !== '' ? idev_appt_hash('HN|' . $hn) : idev_appt_hash('PHONE|' . preg_replace('/\D/', '', $phone));
    $dup = $wpdb->get_var($wpdb->prepare("SELECT ref FROM %i WHERE patient_key=%s AND provider_id=%d AND status IN ('waiting','notified')", idev_apro_t('waitlist'), $key, $provider['id'])); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    if ($dup) return ['ok' => true, 'ref' => $dup, 'message' => $m('คุณอยู่ในรายชื่อรอคิวของแพทย์/คลินิกนี้แล้ว', 'You are already on the waiting list for this doctor or clinic.')];
    $ref = 'WL-' . wp_date('ymd') . '-' . strtoupper(wp_generate_password(4, false));
    $data = ['name' => $name, 'phone' => $phone, 'email' => $email, 'hn' => $hn, 'lang' => $en ? 'en' : 'th', 'consent' => gmdate('c')];
    $wpdb->insert(idev_apro_t('waitlist'), ['ref' => $ref, 'provider_id' => $provider['id'], 'date_from' => $from, 'date_to' => $to, 'status' => 'waiting', 'data' => idev_appt_encrypt(wp_json_encode($data, JSON_UNESCAPED_UNICODE)), 'patient_key' => $key, 'created_at' => current_time('mysql', true)]); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    set_transient($rate, (int) get_transient($rate) + 1, HOUR_IN_SECONDS);
    /* translators: 1: reference, 2: from date, 3: to date */
    return ['ok' => true, 'ref' => $ref, 'message' => sprintf($m('ลงชื่อรอคิวแล้ว (%1$s) ช่วง %2$s – %3$s เราจะส่งข้อความเมื่อมีคิวว่าง', 'You are on the waiting list (%1$s) for %2$s – %3$s. We will send a message when a time is free.'), $ref, idev_format_day($from, $en ? 'en' : 'th'), idev_format_day($to, $en ? 'en' : 'th'))];
}

/* ---------- A time became free ---------- */

function idev_apro_wait_offer($provider_id, $date) {
    global $wpdb;
    $s = idev_apro_settings();
    if (!idev_apro_active() || $s['wait_on'] !== '1' || $date < idev_today()) return 0;
    $provider = idev_appt_provider($provider_id);
    if (!$provider) return 0;
    // still a place that day?
    $free = array_filter(idev_appt_slots($provider, $date), function ($sl) { return $sl['open']; });
    if (!$free) return 0;
    $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE provider_id=%d AND status IN ('waiting','notified') AND (date_from IS NULL OR date_from<=%s) AND (date_to IS NULL OR date_to>=%s) AND offered NOT LIKE %s ORDER BY id LIMIT %d", idev_apro_t('waitlist'), $provider_id, $date, $date, '%' . $wpdb->esc_like($date) . '%', max(1, (int) $s['wait_notify'])), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    $n = 0;
    foreach ($rows as $w) {
        $plain = idev_appt_decrypt($w['data']);
        $d = $plain ? (json_decode($plain, true) ?: []) : [];
        $lang = ($d['lang'] ?? 'th') === 'en' ? 'en' : 'th';
        $link = add_query_arg('date', $date, idev_appt_provider_url($provider));
        $vars = ['{site}' => get_bloginfo('name'), '{name}' => $d['name'] ?? '', '{date}' => idev_format_day($date, $lang, true), '{provider}' => idev_appt_provider_name($provider, $lang), '{link}' => $link, '{ref}' => $w['ref'], '{time}' => '', '{location}' => '', '{branch}' => idev_apro_branch_name(idev_apro_branch_of($provider_id), $lang), '{phone}' => idev_appt_settings()['phone'], '{reason}' => ''];
        $text = idev_apro_text('waitlist', $vars, $lang);
        [$sent] = idev_apro_deliver(['patient_key' => $w['patient_key'], 'phone' => $d['phone'] ?? '', 'lang' => $lang], $text, $vars, [0, (int) $w['id'], 'waitlist', $w['ref']]);
        $ok_any = $sent > 0;
        if (is_email($d['email'] ?? '')) {
            $en = $lang === 'en';
            $html = idev_email_render(idev_email_design('idev_appt_email_design'), ['lang' => $lang, 'title' => $en ? 'A time is free' : 'มีคิวว่างแล้ว', 'preheader' => $vars['{date}'] . ' — ' . $vars['{provider}'],
                'text' => ($en ? 'Dear ' : 'เรียน คุณ') . ($d['name'] ?? '') . "\n\n" . ($en ? 'An appointment was cancelled, so a time is now free. It is first come, first served.' : 'มีผู้ยกเลิกนัด จึงมีเวลาว่าง ใครจองก่อนได้ก่อน'),
                'rows' => [[$en ? 'Date' : 'วันที่', $vars['{date}']], [$en ? 'Doctor / clinic' : 'แพทย์ / คลินิก', $vars['{provider}']], [$en ? 'Waiting list no.' : 'เลขที่รอคิว', $w['ref']]],
                'button' => [$en ? 'Book this time' : 'จองเวลานี้', $link], 'footer' => idev_appt_settings()['phone'] ? ($en ? 'Questions? Call ' : 'สอบถาม โทร ') . idev_appt_settings()['phone'] : '']);
            $ok = wp_mail($d['email'], ($en ? 'A time is free: ' : 'มีคิวว่าง: ') . $vars['{date}'] . ' — ' . $vars['{provider}'], $html, ['Content-Type: text/html; charset=UTF-8']);
            idev_apro_log_msg(0, $w['id'], 'email', 'waitlist', $d['email'], $ok, $ok ? 'sent' : 'failed');
            $ok_any = $ok_any || $ok;
        }
        $wpdb->update(idev_apro_t('waitlist'), ['status' => 'notified', 'offered' => mb_substr(trim($w['offered'] . ' ' . $date), -250), 'notified_at' => current_time('mysql', true)], ['id' => (int) $w['id']]); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        if ($ok_any) $n++;
    }
    return $n;
}
add_action('idev_appt_status', function ($id, $status) {
    if ($status !== 'cancelled') return;
    $a = idev_appt_get($id);
    if ($a) idev_apro_wait_offer((int) $a['provider_id'], $a['appt_date']);
}, 30, 2);
add_action('idev_appt_rescheduled', function ($id) {
    $a = idev_appt_get($id);
    $prevs = $a ? (array) ($a['p']['previous'] ?? []) : [];
    $prev = $prevs ? (string) end($prevs) : '';
    if ($prev) idev_apro_wait_offer((int) $a['provider_id'], substr($prev, 0, 10));
}, 30);

/* Booked from the waiting list: someone in the list books with the same HN / phone. */
add_action('idev_appt_created', function ($id) {
    global $wpdb;
    $a = idev_appt_get($id);
    if (!$a) return;
    $keys = array_filter([$a['patient_key'], !empty($a['p']['phone']) ? idev_appt_hash('PHONE|' . preg_replace('/\D/', '', $a['p']['phone'])) : '']);
    foreach ($keys as $k) $wpdb->query($wpdb->prepare("UPDATE %i SET status='booked' WHERE provider_id=%d AND patient_key=%s AND status IN ('waiting','notified')", idev_apro_t('waitlist'), $a['provider_id'], $k)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}, 30);

/* Daily: close entries whose dates have passed and remove their personal data after 30 days. */
add_action('idev_appt_cron', function () {
    global $wpdb;
    $t = idev_apro_t('waitlist');
    // phpcs:disable WordPress.DB.DirectDatabaseQuery
    $wpdb->query($wpdb->prepare("UPDATE %i SET status='closed' WHERE status IN ('waiting','notified') AND date_to < %s", $t, idev_today()));
    $wpdb->query($wpdb->prepare("DELETE FROM %i WHERE status IN ('closed','booked') AND created_at < %s", $t, gmdate('Y-m-d H:i:s', time() - 120 * DAY_IN_SECONDS)));
    // phpcs:enable
}, 30);

/* ---------- Admin tab ---------- */

function idev_apro_tab_waitlist() {
    global $wpdb;
    $st = idev_apro_wait_statuses();
    $filter = sanitize_key($_GET['status'] ?? 'waiting'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    echo '<form method="post" class="idev-card"><input type="hidden" name="idev_apro_action" value="wait_settings">' . wp_nonce_field('idev_apro_wait_settings', '_wpnonce', true, false); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    idev_settings_table('idev_apro', [
        ['wait_on', __('Show the waiting list under the booking form', 'idev-appointments-pro'), 'checkbox'],
        ['wait_notify', __('People told about each free day', 'idev-appointments-pro'), 'number', __('The first ones in the list for that doctor/clinic and date. First come, first served.', 'idev-appointments-pro'), [1, 20]],
        ['wait_days', __('Default range (days)', 'idev-appointments-pro'), 'number', '', [1, 180]],
    ], idev_apro_settings());
    submit_button(null, 'secondary', 'submit', false);
    echo '</form><p>';
    foreach (['waiting' => $st['waiting'], 'notified' => $st['notified'], 'booked' => $st['booked'], 'closed' => $st['closed'], 'all' => __('All', 'idev-appointments-pro')] as $k => $l) echo '<a class="button' . ($filter === $k ? ' button-primary' : '') . '" href="' . esc_url(idev_apro_url('waitlist', ['status' => $k])) . '">' . esc_html($l) . '</a> ';
    echo '</p>';
    $t = idev_apro_t('waitlist');
    $rows = $filter === 'all' ? $wpdb->get_results($wpdb->prepare('SELECT * FROM %i ORDER BY id DESC LIMIT 300', $t), ARRAY_A) : $wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE status=%s ORDER BY id LIMIT 300', $t, $filter), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Reference', 'idev-appointments-pro') . '</th><th>' . esc_html__('Doctor / clinic', 'idev-appointments-pro') . '</th><th>' . esc_html__('Dates', 'idev-appointments-pro') . '</th><th>' . esc_html__('Name', 'idev-appointments-pro') . '</th><th>' . esc_html__('Phone', 'idev-appointments-pro') . '</th><th>' . esc_html__('Status', 'idev-appointments-pro') . '</th><th></th></tr></thead><tbody>';
    if (!$rows) echo '<tr><td colspan="7">' . esc_html__('Nobody is waiting.', 'idev-appointments-pro') . '</td></tr>';
    foreach ($rows as $w) {
        $plain = idev_appt_decrypt($w['data']);
        $d = $plain ? (json_decode($plain, true) ?: []) : [];
        $p = idev_apro_provider($w['provider_id']);
        echo '<tr><td><b>' . esc_html($w['ref']) . '</b><br><small>' . esc_html(get_date_from_gmt($w['created_at'], 'Y-m-d H:i')) . '</small></td><td>' . esc_html($p ? $p['name'] : '#' . $w['provider_id']) . '</td><td>' . esc_html(idev_format_day($w['date_from']) . ' – ' . idev_format_day($w['date_to'])) . ($w['offered'] ? '<br><small>' . esc_html__('Offered:', 'idev-appointments-pro') . ' ' . esc_html($w['offered']) . '</small>' : '') . '</td><td>' . esc_html($d['name'] ?? '') . (!empty($d['hn']) ? '<br><small>HN ' . esc_html($d['hn']) . '</small>' : '') . '</td><td>' . esc_html($d['phone'] ?? '') . '<br><small>' . esc_html($d['email'] ?? '') . '</small></td><td>' . esc_html($st[$w['status']] ?? $w['status']) . '</td><td>';
        if (in_array($w['status'], ['waiting', 'notified'], true)) foreach (['booked' => __('Booked', 'idev-appointments-pro'), 'closed' => __('Remove', 'idev-appointments-pro')] as $k => $l) echo '<form method="post" style="display:inline"><input type="hidden" name="idev_apro_action" value="wait_status"><input type="hidden" name="id" value="' . (int) $w['id'] . '"><input type="hidden" name="status" value="' . esc_attr($k) . '">' . wp_nonce_field('idev_apro_wait_status', '_wpnonce', true, false) . '<button class="button button-small">' . esc_html($l) . '</button></form> '; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '</td></tr>';
    }
    echo '</tbody></table>';
}
