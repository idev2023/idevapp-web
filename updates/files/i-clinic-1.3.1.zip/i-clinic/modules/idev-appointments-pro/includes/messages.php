<?php
/**
 * LINE and SMS messages: confirmation, reminders, changes and waiting-list offers.
 * SMS: ThaiBulkSMS, or any SMS gateway through a webhook. LINE: Messaging API of the hospital's LINE Official Account;
 * a patient links LINE by sending their appointment reference to the account.
 */
defined('ABSPATH') || exit;

function idev_apro_events() {
    return ['received' => __('Request received (waiting for confirmation)', 'idev-appointments-pro'), 'confirmed' => __('Confirmed', 'idev-appointments-pro'), 'reminder' => __('Reminder before the day', 'idev-appointments-pro'), 'day' => __('On the day', 'idev-appointments-pro'), 'cancelled' => __('Cancelled', 'idev-appointments-pro'), 'rescheduled' => __('Moved', 'idev-appointments-pro')];
}

/* ---------- Senders ---------- */

/** Thai mobile number in international form: 0812345678 → 66812345678. */
function idev_apro_msisdn($phone) {
    $d = preg_replace('/\D/', '', (string) $phone);
    if (strpos($d, '0') === 0 && strlen($d) === 10) return '66' . substr($d, 1);
    return $d;
}

/** Returns [ok, info]. */
function idev_apro_send_sms($phone, $text, $meta = []) {
    $s = idev_apro_settings();
    $to = idev_apro_msisdn($phone);
    if (strlen($to) < 9) return [false, 'no phone'];
    if ($s['sms'] === 'thaibulksms') {
        if ($s['sms_key'] === '' || $s['sms_secret'] === '') return [false, 'ThaiBulkSMS key missing'];
        $res = wp_remote_post('https://api-v2.thaibulksms.com/sms', ['timeout' => 20, 'headers' => ['Authorization' => 'Basic ' . base64_encode($s['sms_key'] . ':' . $s['sms_secret']), 'Accept' => 'application/json'],
            'body' => array_filter(['msisdn' => $to, 'message' => $text, 'sender' => $s['sms_sender']])]);
    } elseif ($s['sms'] === 'webhook') {
        if (!wp_http_validate_url($s['webhook_url'])) return [false, 'webhook URL missing'];
        $res = wp_remote_post($s['webhook_url'], ['timeout' => 20, 'headers' => ['Content-Type' => 'application/json', 'X-iDev-Secret' => $s['webhook_secret']], 'body' => wp_json_encode(['to' => $to, 'phone' => $phone, 'message' => $text] + $meta, JSON_UNESCAPED_UNICODE)]);
    } else return [false, 'SMS off'];
    if (is_wp_error($res)) return [false, $res->get_error_message()];
    $code = wp_remote_retrieve_response_code($res);
    return [$code >= 200 && $code < 300, 'HTTP ' . $code . ' ' . mb_substr(wp_strip_all_tags(wp_remote_retrieve_body($res)), 0, 160)];
}

function idev_apro_line_api($path, $body) {
    $s = idev_apro_settings();
    if ($s['line_token'] === '') return [false, 'LINE token missing'];
    $res = wp_remote_post('https://api.line.me/v2/bot/message/' . $path, ['timeout' => 20, 'headers' => ['Authorization' => 'Bearer ' . $s['line_token'], 'Content-Type' => 'application/json'], 'body' => wp_json_encode($body, JSON_UNESCAPED_UNICODE)]);
    if (is_wp_error($res)) return [false, $res->get_error_message()];
    $code = wp_remote_retrieve_response_code($res);
    return [$code === 200, 'HTTP ' . $code . ' ' . mb_substr(wp_remote_retrieve_body($res), 0, 160)];
}
function idev_apro_send_line($user_id, $text) { return idev_apro_line_api('push', ['to' => $user_id, 'messages' => [['type' => 'text', 'text' => mb_substr($text, 0, 4900)]]]); }
function idev_apro_line_user($patient_key) {
    global $wpdb;
    if ($patient_key === '') return '';
    return (string) $wpdb->get_var($wpdb->prepare('SELECT user_id FROM %i WHERE patient_key = %s', idev_apro_t('line'), $patient_key)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}

function idev_apro_log_msg($appt_id, $wait_id, $channel, $event, $to, $ok, $info) {
    global $wpdb;
    $wpdb->insert(idev_apro_t('messages'), ['appt_id' => (int) $appt_id, 'wait_id' => (int) $wait_id, 'channel' => $channel, 'event' => $event, 'recipient' => mb_substr((string) $to, 0, 40), 'ok' => $ok ? 1 : 0, 'info' => mb_substr((string) $info, 0, 250), 'created_at' => current_time('mysql', true)]); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}

/* ---------- Appointment messages ---------- */

function idev_apro_text($key, $vars, $lang) {
    $s = idev_apro_settings();
    $tpl = $lang === 'en' && ($s['m_' . $key . '_en'] ?? '') !== '' ? $s['m_' . $key . '_en'] : $s['m_' . $key];
    return trim(preg_replace('/[ \t]+/', ' ', strtr($tpl, $vars)));
}

/**
 * Sends one message to a patient on the channels that are on: LINE (if the patient linked LINE), WhatsApp and SMS.
 * With "chat first" on, SMS is skipped when LINE or WhatsApp reached the patient. Returns [sent count, channels].
 * $to: patient_key, phone, lang. $log: [appt_id, wait_id, event, ref]. $vars: placeholders for WhatsApp templates.
 */
function idev_apro_deliver($to, $text, $vars, $log) {
    $s = idev_apro_settings();
    [$appt_id, $wait_id, $event, $ref] = $log;
    $sent = 0; $used = [];
    $line = idev_apro_line_user($to['patient_key'] ?? '');
    if ($line !== '') {
        [$ok, $info] = idev_apro_send_line($line, $text);
        idev_apro_log_msg($appt_id, $wait_id, 'line', $event, 'LINE', $ok, $info);
        if ($ok) { $sent++; $used[] = 'LINE'; }
    }
    $phone = (string) ($to['phone'] ?? '');
    if ($phone !== '' && idev_apro_wa_on()) {
        [$ok, $info] = idev_apro_send_wa($phone, $event, $vars, $to['lang'] ?? 'th');
        if ($info !== 'skip') {
            idev_apro_log_msg($appt_id, $wait_id, 'wa', $event, idev_apro_mask($phone), $ok, $info);
            if ($ok) { $sent++; $used[] = 'WhatsApp'; }
        }
    }
    if ($phone !== '' && $s['sms'] !== 'none' && !($s['chat_first'] === '1' && $sent > 0)) {
        [$ok, $info] = idev_apro_send_sms($phone, $text, ['event' => $event, 'ref' => $ref]);
        idev_apro_log_msg($appt_id, $wait_id, 'sms', $event, idev_apro_mask($phone), $ok, $info);
        if ($ok) { $sent++; $used[] = 'SMS'; }
    }
    return [$sent, $used];
}

/** Sends the message for one event. Returns the number of messages sent. */
function idev_apro_notify($appt_id, $event) {
    if (!idev_apro_active()) return 0;
    $s = idev_apro_settings();
    if (($s['ev_' . $event] ?? '0') !== '1') return 0;
    $a = idev_appt_get($appt_id);
    if (!$a || !$a['readable']) return 0;
    $lang = ($a['p']['lang'] ?? 'th') === 'en' ? 'en' : 'th';
    $vars = idev_appt_vars($a) + ['{link}' => idev_appt_manage_url($a), '{branch}' => ''];
    $text = idev_apro_text($event, $vars, $lang);
    [$sent, $used] = idev_apro_deliver(['patient_key' => $a['patient_key'], 'phone' => $a['p']['phone'] ?? '', 'lang' => $lang], $text, $vars, [$appt_id, 0, $event, $a['ref']]);
    if ($sent) { $a2 = idev_appt_get($appt_id); idev_appt_log($a2['p'], 'ข้อความ ' . $event . ' (' . implode(', ', $used) . ')', 'system'); idev_appt_save($appt_id, $a2['p']); }
    return $sent;
}

add_action('idev_appt_created', function ($id, $status) { idev_apro_notify($id, $status === 'confirmed' ? 'confirmed' : 'received'); }, 20, 2);
add_action('idev_appt_status', function ($id, $status) { if (in_array($status, ['confirmed', 'cancelled'], true)) idev_apro_notify($id, $status); }, 20, 2);
add_action('idev_appt_rescheduled', function ($id) { idev_apro_notify($id, 'rescheduled'); }, 20);

/* Reminders: same timing as the e-mail reminders (Appointments → Settings), own flags pb / pd. */
add_action('idev_appt_cron', function () {
    global $wpdb;
    if (!idev_apro_active()) return;
    $s = idev_appt_settings();
    $now = idev_appt_now();
    $today = $now->format('Y-m-d');
    $hour = (int) $now->format('G');
    $t = idev_appt_table();
    $mark = function ($row, $flag) use ($wpdb, $t) { $f = array_filter(explode(',', $row['reminders'])); $f[] = $flag; $wpdb->update($t, ['reminders' => implode(',', array_unique($f))], ['id' => (int) $row['id']]); }; // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    $days = (int) $s['remind_days'];
    // phpcs:disable WordPress.DB.DirectDatabaseQuery
    if ($days > 0 && $hour >= (int) $s['remind_hour']) {
        foreach ($wpdb->get_results($wpdb->prepare("SELECT id, reminders FROM %i WHERE status='confirmed' AND appt_date=%s AND reminders NOT LIKE %s", $t, idev_add_days($today, $days), '%pb%'), ARRAY_A) as $row) { $mark($row, 'pb'); idev_apro_notify($row['id'], 'reminder'); }
    }
    if ($hour >= (int) $s['day_hour']) {
        foreach ($wpdb->get_results($wpdb->prepare("SELECT id, reminders FROM %i WHERE status='confirmed' AND appt_date=%s AND start_time>%s AND reminders NOT LIKE %s", $t, $today, $now->format('H:i'), '%pd%'), ARRAY_A) as $row) { $mark($row, 'pd'); idev_apro_notify($row['id'], 'day'); }
    }
    // phpcs:enable
}, 20);

/* E-mails: how to get LINE reminders. */
add_filter('idev_appt_mail_text', function ($text, $type, $a) {
    $s = idev_apro_settings();
    if (!idev_apro_active() || $s['line_token'] === '' || $s['line_oa'] === '' || !in_array($type, ['received', 'confirmed'], true) || idev_apro_line_user($a['patient_key']) !== '') return $text;
    $en = ($a['p']['lang'] ?? 'th') === 'en';
    /* translators: 1: LINE account ID, 2: appointment reference */
    return $text . "\n\n" . sprintf($en ? 'Get reminders on LINE: add %1$s as a friend and send the reference %2$s.' : 'รับแจ้งเตือนทาง LINE: เพิ่มเพื่อน %1$s แล้วพิมพ์เลขที่นัด %2$s', $s['line_oa'], $a['ref']);
}, 10, 3);

/* ---------- LINE webhook: link a patient by their appointment reference ---------- */

add_action('rest_api_init', function () {
    register_rest_route('idev-apro/v1', '/line', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'idev_apro_line_webhook']);
});
function idev_apro_line_webhook(WP_REST_Request $r) {
    $s = idev_apro_settings();
    $body = $r->get_body();
    $sig = (string) $r->get_header('x-line-signature');
    if ($s['line_secret'] === '' || !hash_equals(base64_encode(hash_hmac('sha256', $body, $s['line_secret'], true)), $sig)) return new WP_REST_Response(['ok' => false], 401);
    $data = json_decode($body, true);
    foreach ((array) ($data['events'] ?? []) as $ev) {
        $uid = (string) ($ev['source']['userId'] ?? '');
        $token = (string) ($ev['replyToken'] ?? '');
        if ($uid === '' || ($ev['type'] ?? '') !== 'message' || ($ev['message']['type'] ?? '') !== 'text') {
            if (($ev['type'] ?? '') === 'follow' && $token) idev_apro_line_api('reply', ['replyToken' => $token, 'messages' => [['type' => 'text', 'text' => "ขอบคุณที่เพิ่มเพื่อน\nพิมพ์เลขที่นัด (เช่น APT-261028-ABCDE) เพื่อรับแจ้งเตือนนัดหมายทาง LINE\n\nThank you. Send your appointment reference (e.g. APT-261028-ABCDE) to get reminders here."]]]);
            continue;
        }
        $msg = strtoupper(trim((string) $ev['message']['text']));
        if (!preg_match('/APT-\d{6}-[A-Z0-9]{5}/', $msg, $m)) continue;
        $reply = idev_apro_line_link($uid, $m[0]);
        if ($token) idev_apro_line_api('reply', ['replyToken' => $token, 'messages' => [['type' => 'text', 'text' => $reply]]]);
    }
    return ['ok' => true];
}
function idev_apro_line_link($uid, $ref) {
    global $wpdb;
    $id = (int) $wpdb->get_var($wpdb->prepare('SELECT id FROM %i WHERE ref = %s', idev_appt_table(), $ref)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    $a = $id ? idev_appt_get($id) : null;
    if (!$a || $a['patient_key'] === '') return "ไม่พบเลขที่นัดนี้ กรุณาตรวจอีกครั้ง\nReference not found.";
    $wpdb->replace(idev_apro_t('line'), ['patient_key' => $a['patient_key'], 'user_id' => $uid, 'created_at' => current_time('mysql', true)], ['%s', '%s', '%s']); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- explicit formats: wpdb treats a user_id column as a number
    idev_appt_log($a['p'], 'เชื่อม LINE แล้ว', 'patient');
    idev_appt_save($id, $a['p']);
    $v = idev_appt_vars($a);
    return 'เชื่อม LINE เรียบร้อย จะแจ้งเตือนนัดหมายทางนี้' . "\n" . $v['{date}'] . ' ' . $v['{time}'] . "\n" . $v['{provider}'] . "\n\nLINE linked: you will get your appointment reminders here.";
}

/* ---------- Admin tab ---------- */

/** Values never shown again in the form. */
function idev_apro_secret_keys() { return ['sms_secret', 'webhook_secret', 'line_token', 'line_secret', 'wa_token']; }
function idev_apro_message_fields() {
    $f = [
        ['heading', __('SMS', 'idev-appointments-pro'), 'heading', __('Costs are charged by your SMS provider. Messages go to the phone number the patient gave when booking.', 'idev-appointments-pro')],
        ['sms', __('SMS service', 'idev-appointments-pro'), 'select', '', ['none' => __('Off', 'idev-appointments-pro'), 'thaibulksms' => 'ThaiBulkSMS', 'webhook' => __('Other service (webhook)', 'idev-appointments-pro')]],
        ['sms_key', __('ThaiBulkSMS API key', 'idev-appointments-pro'), 'text'], ['sms_secret', __('ThaiBulkSMS API secret', 'idev-appointments-pro'), 'text'],
        ['sms_sender', __('Sender name', 'idev-appointments-pro'), 'text', __('Registered with the SMS provider; empty = the provider\'s default.', 'idev-appointments-pro')],
        ['webhook_url', __('Webhook URL', 'idev-appointments-pro'), 'url', __('POST JSON {to, phone, message, event, ref} with header X-iDev-Secret — for any SMS gateway or your own system.', 'idev-appointments-pro')],
        ['webhook_secret', __('Webhook secret', 'idev-appointments-pro'), 'text'],
        ['heading2', __('LINE Official Account', 'idev-appointments-pro'), 'heading', __('LINE Developers → your Messaging API channel. Set the webhook URL below in the channel and turn "Use webhook" on.', 'idev-appointments-pro')],
        ['line_token', __('Channel access token', 'idev-appointments-pro'), 'text'], ['line_secret', __('Channel secret', 'idev-appointments-pro'), 'text'],
        ['line_oa', __('LINE ID of the account', 'idev-appointments-pro'), 'text', __('e.g. @yourhospital — shown to patients in e-mails so they can add it.', 'idev-appointments-pro')],
    ];
    $f = array_merge($f, idev_apro_wa_fields(), [
        ['heading3', __('When to send', 'idev-appointments-pro'), 'heading', __('Reminders use the same day and hour as the e-mail reminders (Appointments → Settings).', 'idev-appointments-pro')],
    ]);
    foreach (idev_apro_events() as $k => $l) $f[] = ['ev_' . $k, $l, 'checkbox'];
    $f[] = ['heading4', __('Message texts', 'idev-appointments-pro'), 'heading', '{site} {name} {ref} {date} {time} {provider} {location} {branch} {phone} {reason} {link}'];
    foreach (idev_apro_events() + ['waitlist' => __('Waiting list: a time is free', 'idev-appointments-pro')] as $k => $l) { $f[] = ['m_' . $k, $l . ' (TH)', 'textarea']; $f[] = ['m_' . $k . '_en', $l . ' (EN)', 'textarea']; }
    return $f;
}
function idev_apro_tab_messages() {
    global $wpdb;
    $vals = idev_apro_settings();
    $all = idev_apro_message_fields();
    $by = [];
    foreach ($all as $f) {
        if (in_array($f[0], idev_apro_secret_keys(), true) && $vals[$f[0]] !== '') { $vals[$f[0]] = ''; $f[3] = __('Saved. Leave empty to keep it.', 'idev-appointments-pro'); }
        $by[$f[0]] = $f;
    }
    $pick = function ($keys) use ($by) { return array_values(array_intersect_key($by, array_flip($keys))); };
    $s = idev_apro_settings();
    $chip = function ($on, $text_on = '', $text_off = '') { return '<span class="idev-chip ' . ($on ? 'ok' : 'off') . '">' . esc_html($on ? ($text_on ?: __('On', 'idev-appointments-pro')) : ($text_off ?: __('Not set up', 'idev-appointments-pro'))) . '</span>'; };
    echo '<form method="post"><input type="hidden" name="idev_apro_action" value="messages">' . wp_nonce_field('idev_apro_messages', '_wpnonce', true, false); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div class="idev-ch-grid">';
    // LINE
    echo '<div class="idev-ch idev-ch-line"><h2>' . idev_icon('line') . ' LINE ' . $chip($s['line_token'] !== '' && $s['line_secret'] !== '') . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<p class="description">' . esc_html__('Patients add your LINE Official Account and send their appointment reference (it is in the confirmation e-mail). From then on their messages come on LINE — free of charge within your LINE OA plan.', 'idev-appointments-pro') . '</p><p><b>Webhook URL</b><br><code style="user-select:all">' . esc_html(rest_url('idev-apro/v1/line')) . '</code></p>';
    idev_settings_table('idev_apro', $pick(['line_token', 'line_secret', 'line_oa']), $vals);
    echo '</div>';
    // WhatsApp
    echo '<div class="idev-ch idev-ch-wa"><h2>' . idev_icon('whatsapp') . ' WhatsApp ' . $chip(idev_apro_wa_on() || $s['wa_click'] === '1', idev_apro_wa_on() ? __('API on', 'idev-appointments-pro') : __('Click-to-chat', 'idev-appointments-pro')) . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<p class="description">' . esc_html__('For foreign patients. The click-to-chat button needs no account. Automatic messages need the WhatsApp Business Cloud API (Meta) and a template approved by Meta for each message.', 'idev-appointments-pro') . '</p>';
    idev_settings_table('idev_apro', $pick(['wa_click', 'wa_on', 'wa_phone_id', 'wa_token', 'wa_params', 'wa_lang_th', 'wa_lang_en']), $vals);
    echo '<details class="idev-texts"><summary>' . esc_html__('Template names', 'idev-appointments-pro') . '</summary>';
    idev_settings_table('idev_apro', array_values(array_filter($by, function ($k) { return strpos($k, 'wa_t_') === 0; }, ARRAY_FILTER_USE_KEY)), $vals);
    echo '</details></div>';
    // SMS
    echo '<div class="idev-ch idev-ch-sms"><h2>' . idev_icon('phone') . ' SMS ' . $chip($s['sms'] !== 'none', $s['sms'] === 'thaibulksms' ? 'ThaiBulkSMS' : 'Webhook') . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<p class="description">' . esc_html__('Reaches every patient with a mobile number. Costs are charged by your SMS provider.', 'idev-appointments-pro') . '</p>';
    idev_settings_table('idev_apro', $pick(['sms', 'sms_key', 'sms_secret', 'sms_sender', 'webhook_url', 'webhook_secret', 'chat_first']), $vals);
    echo '</div></div>';
    // When + texts
    echo '<div class="idev-card"><h2>' . esc_html__('When to send', 'idev-appointments-pro') . '</h2><p class="description">' . esc_html__('Applies to LINE, WhatsApp and SMS. Reminders use the same day and hour as the e-mail reminders (Appointments → Settings).', 'idev-appointments-pro') . '</p>';
    idev_settings_table('idev_apro', array_values(array_filter($by, function ($k) { return strpos($k, 'ev_') === 0; }, ARRAY_FILTER_USE_KEY)), $vals);
    echo '<details class="idev-texts"><summary>' . esc_html__('Message texts (LINE and SMS)', 'idev-appointments-pro') . '</summary><p class="description">{site} {name} {ref} {date} {time} {provider} {location} {branch} {phone} {reason} {link}</p>';
    idev_settings_table('idev_apro', array_values(array_filter($by, function ($k) { return strpos($k, 'm_') === 0; }, ARRAY_FILTER_USE_KEY)), $vals);
    echo '</details></div>';
    submit_button(__('Save', 'idev-appointments-pro'));
    echo '</form><form method="post" class="idev-card"><input type="hidden" name="idev_apro_action" value="test_sms">' . wp_nonce_field('idev_apro_test_sms', '_wpnonce', true, false) . '<h2>' . esc_html__('Send a test message', 'idev-appointments-pro') . '</h2><p><input name="phone" placeholder="08xxxxxxxx"> <select name="via"><option value="sms">SMS</option><option value="wa">WhatsApp (' . esc_html__('template "confirmed"', 'idev-appointments-pro') . ')</option></select> <button class="button">' . esc_html__('Send', 'idev-appointments-pro') . '</button></p></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM %i ORDER BY id DESC LIMIT 50', idev_apro_t('messages')), ARRAY_A); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    echo '<div class="idev-card"><h2>' . esc_html__('Last messages', 'idev-appointments-pro') . '</h2><table class="widefat striped"><thead><tr><th>' . esc_html__('Time', 'idev-appointments-pro') . '</th><th>' . esc_html__('Channel', 'idev-appointments-pro') . '</th><th>' . esc_html__('Event', 'idev-appointments-pro') . '</th><th>' . esc_html__('To', 'idev-appointments-pro') . '</th><th>' . esc_html__('Result', 'idev-appointments-pro') . '</th></tr></thead><tbody>';
    if (!$rows) echo '<tr><td colspan="5">—</td></tr>';
    $names = ['line' => 'LINE', 'wa' => 'WhatsApp', 'sms' => 'SMS', 'email' => 'E-mail'];
    foreach ($rows as $m) echo '<tr><td>' . esc_html(get_date_from_gmt($m['created_at'], 'Y-m-d H:i')) . '</td><td>' . esc_html($names[$m['channel']] ?? $m['channel']) . '</td><td>' . esc_html($m['event']) . '</td><td>' . esc_html($m['recipient']) . '</td><td>' . ($m['ok'] ? '<span class="idev-apro-ok">✓</span> ' : '<span class="idev-apro-bad">✗</span> ') . '<small>' . esc_html($m['info']) . '</small></td></tr>';
    echo '</tbody></table></div>';
}
