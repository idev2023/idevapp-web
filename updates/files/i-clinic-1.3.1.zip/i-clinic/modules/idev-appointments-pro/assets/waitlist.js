/* iDev Appointments Pro — waiting list form. */
(function () {
  'use strict';
  document.querySelectorAll('.idev-apro-wait').forEach(function (box) {
    var form = box.querySelector('form'), msg = box.querySelector('.idev-apro-msg'), btn = form.querySelector('button[type=submit]');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!form.reportValidity()) return;
      var data = { lang: box.dataset.lang };
      Array.prototype.forEach.call(form.elements, function (el) { if (el.name) data[el.name] = el.type === 'checkbox' ? (el.checked ? 1 : 0) : el.value; });
      btn.disabled = true; msg.className = 'idev-apro-msg'; msg.textContent = '…';
      fetch(box.dataset.api, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data), credentials: 'omit' })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          if (j && j.ok) { msg.className = 'idev-apro-msg ok'; msg.textContent = j.message || ''; form.querySelectorAll('label, .idev-apro-grid, p:not(.idev-apro-wait-intro)').forEach(function (el) { if (!el.contains(msg)) el.hidden = true; }); }
          else { msg.className = 'idev-apro-msg err'; msg.textContent = (j && (j.error || j.message)) || 'Error'; btn.disabled = false; }
        })
        .catch(function () { msg.className = 'idev-apro-msg err'; msg.textContent = 'Error'; btn.disabled = false; });
    });
  });
})();
