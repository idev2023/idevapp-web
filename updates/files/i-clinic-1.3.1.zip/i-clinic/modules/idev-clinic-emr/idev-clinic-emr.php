<?php
/**
 * Plugin Name:       iDev Clinic Records
 * Plugin URI:        https://idevapp.me/#systems
 * Description:       Examination room for clinics (part of I-Clinic): today's queue, screening and vital signs, doctor's notes, ICD-10 diagnosis, prescriptions from stock with drug labels, re-med, drug allergy alerts, patient history, follow-up appointments, medical certificates and reports.
 * Version:           1.1.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-clinic-emr
 * Domain Path:       /languages
 */
defined('ABSPATH') || exit;

if (defined('IDEV_EMR_VERSION')) return;

define('IDEV_EMR_VERSION', '1.1.0');
define('IDEV_EMR_FILE', __FILE__);
define('IDEV_EMR_DIR', plugin_dir_path(__FILE__));
define('IDEV_EMR_URL', plugin_dir_url(__FILE__));

if (is_file(__DIR__ . '/common/idev-common.php')) require_once dirname(__DIR__, 2) . '/common/idev-common.php';
require_once __DIR__ . '/includes/core.php';
require_once __DIR__ . '/includes/icd10.php';
require_once __DIR__ . '/includes/visits.php';
require_once __DIR__ . '/includes/rest.php';
require_once __DIR__ . '/includes/print.php';
require_once __DIR__ . '/includes/admin.php';
require_once __DIR__ . '/includes/admin-visit.php';
require_once __DIR__ . '/includes/admin-patient.php';
require_once __DIR__ . '/includes/reports.php';
require_once __DIR__ . '/includes/settings.php';

register_activation_hook(__FILE__, 'idev_emr_install');
