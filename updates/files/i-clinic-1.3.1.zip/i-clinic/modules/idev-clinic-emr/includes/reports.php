<?php
/** Reports: visits per day, new patients, common diagnoses, per doctor, money from the visits' bills. */
defined('ABSPATH') || exit;

function idev_emr_report_data($from, $to, $doctor = 0) {
    global $wpdb;
    $visits = idev_emr_visits(['from' => $from, 'to' => $to, 'doctor_id' => $doctor, 'not_cancelled' => true, 'limit' => 20000]);
    $days = []; $dx = []; $docs = []; $patients = []; $money = 0.0; $bills = [];
    foreach ($visits as $v) {
        $days[$v['visit_date']] = ($days[$v['visit_date']] ?? 0) + 1;
        $patients[$v['customer_id']] = true;
        foreach ($v['d']['dx'] as $i => $x) { if ($i > 0) continue; $k = $x['code'] ?: $x['name']; if ($k === '') continue; $dx[$k] = ['code' => $x['code'], 'name' => $x['name'], 'n' => ($dx[$k]['n'] ?? 0) + 1]; }
        $docs[$v['doctor_id']] = ($docs[$v['doctor_id']] ?? 0) + 1;
        if ($v['bill_id']) $bills[] = $v['bill_id'];
    }
    if ($bills && function_exists('idev_store_t')) $money = (float) $wpdb->get_var('SELECT COALESCE(SUM(total),0) FROM ' . idev_store_t('bills') . " WHERE status <> 'void' AND id IN (" . implode(',', array_map('intval', $bills)) . ')'); // phpcs:ignore WordPress.DB
    $new = function_exists('idev_store_t') ? (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . idev_store_t('customers') . ' WHERE created_at BETWEEN %s AND %s', $from . ' 00:00:00', $to . ' 23:59:59')) : 0;
    uasort($dx, function ($a, $b) { return $b['n'] - $a['n']; });
    arsort($docs);
    ksort($days);
    return ['visits' => count($visits), 'patients' => count($patients), 'new' => $new, 'money' => $money, 'days' => $days, 'dx' => array_slice($dx, 0, 20, true), 'docs' => $docs];
}

function idev_emr_page_reports() {
    $from = idev_is_valid_date($_GET['from'] ?? '') ? $_GET['from'] : wp_date('Y-m-01'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $to = idev_is_valid_date($_GET['to'] ?? '') ? $_GET['to'] : idev_today(); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $doctor = (int) ($_GET['doctor'] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $r = idev_emr_report_data($from, $to, $doctor);
    idev_emr_head(__('Reports', 'idev-clinic-emr'), idev_format_day($from) . ' – ' . idev_format_day($to), 'idev-emr-reports');
    echo '<form class="emr-filter"><input type="hidden" name="page" value="idev-emr-reports"><label>' . esc_html__('From', 'idev-clinic-emr') . ' <input type="date" name="from" value="' . esc_attr($from) . '"></label> <label>' . esc_html__('To', 'idev-clinic-emr') . ' <input type="date" name="to" value="' . esc_attr($to) . '"></label> <select name="doctor"><option value="0">' . esc_html__('All doctors', 'idev-clinic-emr') . '</option>';
    foreach (idev_emr_doctors() as $uid => $n) echo '<option value="' . (int) $uid . '"' . selected($doctor, $uid, false) . '>' . esc_html($n) . '</option>';
    echo '</select> <button class="button">' . esc_html__('Show', 'idev-clinic-emr') . '</button> ';
    foreach ([__('Today', 'idev-clinic-emr') => [idev_today(), idev_today()], __('This month', 'idev-clinic-emr') => [wp_date('Y-m-01'), idev_today()], __('Last month', 'idev-clinic-emr') => [wp_date('Y-m-01', strtotime('first day of last month')), wp_date('Y-m-t', strtotime('last day of last month'))]] as $l => [$a, $b]) echo '<a class="button-link" href="' . esc_url(idev_emr_url('idev-emr-reports', ['from' => $a, 'to' => $b])) . '">' . esc_html($l) . '</a> ';
    echo '<a class="button" target="_blank" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=idev_emr_report_print&from=' . $from . '&to=' . $to . '&doctor=' . $doctor), 'idev_emr_report')) . '">🖨 ' . esc_html__('Print', 'idev-clinic-emr') . '</a></form>';
    echo '<div class="emr-stats">';
    foreach ([[__('Visits', 'idev-clinic-emr'), number_format($r['visits']), 'stethoscope'], [__('Patients', 'idev-clinic-emr'), number_format($r['patients']), 'users'], [__('New patients', 'idev-clinic-emr'), number_format($r['new']), 'user'], [__('Billed', 'idev-clinic-emr'), function_exists('idev_store_money') ? idev_store_money($r['money']) : number_format($r['money'], 2), 'receipt']] as [$l, $n, $ic]) echo '<div class="emr-stat">' . idev_icon($ic) . '<b>' . esc_html($n) . '</b><span>' . esc_html($l) . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div><div class="emr-report">' . idev_emr_report_body($r) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    idev_page_close();
}

function idev_emr_report_body($r, $print = false) {
    $o = '';
    $max = $r['days'] ? max($r['days']) : 1;
    $o .= '<div class="idev-card"><h2>' . esc_html__('Visits per day', 'idev-clinic-emr') . '</h2>';
    if (!$r['days']) $o .= '<p class="emr-empty">—</p>';
    else { $o .= '<table class="widefat striped emr-rtable"><tbody>'; foreach ($r['days'] as $d => $n) $o .= '<tr><td>' . esc_html(idev_format_day($d)) . '</td><td class="bar"><i style="width:' . round($n / $max * 85) . '%"></i></td><td class="r"><b>' . (int) $n . '</b></td></tr>'; $o .= '</tbody></table>'; }
    $o .= '</div><div class="idev-card"><h2>' . esc_html__('Most common diagnoses', 'idev-clinic-emr') . '</h2>';
    if (!$r['dx']) $o .= '<p class="emr-empty">—</p>';
    else { $o .= '<table class="widefat striped emr-rtable"><thead><tr><th>#</th><th>ICD-10</th><th>' . esc_html__('Diagnosis', 'idev-clinic-emr') . '</th><th class="r">' . esc_html__('Visits', 'idev-clinic-emr') . '</th></tr></thead><tbody>'; $i = 0; foreach ($r['dx'] as $x) $o .= '<tr><td>' . (++$i) . '</td><td><code>' . esc_html($x['code'] ?: '—') . '</code></td><td>' . esc_html($x['name']) . '</td><td class="r"><b>' . (int) $x['n'] . '</b></td></tr>'; $o .= '</tbody></table>'; }
    $o .= '</div><div class="idev-card"><h2>' . esc_html__('By doctor', 'idev-clinic-emr') . '</h2><table class="widefat striped emr-rtable"><tbody>';
    foreach ($r['docs'] as $uid => $n) $o .= '<tr><td>' . esc_html($uid ? idev_emr_doctor($uid)['name'] : __('Not set', 'idev-clinic-emr')) . '</td><td class="r"><b>' . (int) $n . '</b></td></tr>';
    if (!$r['docs']) $o .= '<tr><td>—</td></tr>';
    return $o . '</tbody></table></div>';
}

add_action('admin_post_idev_emr_report_print', function () {
    if (!idev_emr_can() || !check_admin_referer('idev_emr_report')) wp_die('Forbidden', 403);
    $from = idev_is_valid_date($_GET['from'] ?? '') ? $_GET['from'] : idev_today();
    $to = idev_is_valid_date($_GET['to'] ?? '') ? $_GET['to'] : idev_today();
    $r = idev_emr_report_data($from, $to, (int) ($_GET['doctor'] ?? 0));
    $sum = '<div class="meta"><b>' . esc_html__('Period', 'idev-clinic-emr') . '</b><span>' . esc_html(idev_format_day($from) . ' – ' . idev_format_day($to)) . '</span><b>' . esc_html__('Visits', 'idev-clinic-emr') . '</b><span>' . (int) $r['visits'] . '</span><b>' . esc_html__('Patients', 'idev-clinic-emr') . '</b><span>' . (int) $r['patients'] . '</span><b>' . esc_html__('New patients', 'idev-clinic-emr') . '</b><span>' . (int) $r['new'] . '</span><b>' . esc_html__('Billed', 'idev-clinic-emr') . '</b><span>' . esc_html(number_format($r['money'], 2)) . '</span></div>';
    $body = str_replace(['<div class="idev-card">', 'widefat striped emr-rtable'], ['<div>', ''], idev_emr_report_body($r, true));
    $body = preg_replace('#<td class="bar">.*?</td>#', '', $body);
    nocache_headers();
    echo idev_doc_page(['title' => __('Examination room report', 'idev-clinic-emr'), 'body' => $sum . $body, 'design' => idev_emr_doc_design(), 'paper' => 'a4', 'org' => idev_emr_org(), 'trial' => idev_emr_trial()]); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    exit;
});
