<?php
/** Menu, shared admin helpers and the queue of the day. */
defined('ABSPATH') || exit;

add_action('admin_menu', function () {
    if (!idev_emr_can() || !idev_emr_ready()) return;
    $waiting = (int) $GLOBALS['wpdb']->get_var($GLOBALS['wpdb']->prepare('SELECT COUNT(*) FROM ' . idev_emr_t('visits') . " WHERE visit_date = %s AND status IN ('waiting','screened','exam')", idev_today()));
    add_menu_page(__('Examination room', 'idev-clinic-emr'), __('Examination room', 'idev-clinic-emr') . ($waiting ? ' <span class="awaiting-mod">' . $waiting . '</span>' : ''), 'idev_emr', 'idev-emr', 'idev_emr_page_queue', 'dashicons-heart', 5);
    add_submenu_page('idev-emr', __('Today\'s queue', 'idev-clinic-emr'), __('Today\'s queue', 'idev-clinic-emr'), 'idev_emr', 'idev-emr', 'idev_emr_page_queue');
    add_submenu_page('idev-emr', __('Doctor\'s room', 'idev-clinic-emr'), __('Doctor\'s room', 'idev-clinic-emr'), 'idev_emr_doctor', 'idev-emr-doctor', 'idev_emr_page_doctor');
    add_submenu_page('idev-emr', __('Patients', 'idev-clinic-emr'), __('Patients', 'idev-clinic-emr'), 'idev_emr', 'idev-emr-patients', 'idev_emr_page_patients');
    add_submenu_page('idev-emr', __('Visit', 'idev-clinic-emr'), '', 'idev_emr', 'idev-emr-visit', 'idev_emr_page_visit');
    add_submenu_page('idev-emr', __('Reports', 'idev-clinic-emr'), __('Reports', 'idev-clinic-emr'), 'idev_emr', 'idev-emr-reports', 'idev_emr_page_reports');
    add_submenu_page('idev-emr', __('Examination room settings', 'idev-clinic-emr'), __('Settings', 'idev-clinic-emr'), 'manage_options', 'idev-emr-settings', 'idev_emr_page_settings');
});
/* The visit screen is opened from the queue; hide its empty menu entry. */
add_action('admin_head', function () { echo '<style>#adminmenu a[href="admin.php?page=idev-emr-visit"]{display:none}</style>'; });

add_action('admin_enqueue_scripts', function ($hook) {
    if (strpos((string) $hook, 'idev-emr') === false) return;
    wp_enqueue_style('idev-emr', IDEV_EMR_URL . 'assets/emr.css', [], IDEV_EMR_VERSION);
    wp_enqueue_script('idev-emr', IDEV_EMR_URL . 'assets/emr.js', [], IDEV_EMR_VERSION, true);
    wp_localize_script('idev-emr', 'IDEV_EMR', idev_emr_js_cfg());
});
function idev_emr_js_cfg() {
    return [
        'api' => esc_url_raw(rest_url('idev-emr/v1/')), 'store' => esc_url_raw(rest_url('idev-store/v1/')), 'nonce' => wp_create_nonce('wp_rest'),
        't' => [
            'search' => __('Type HN, name or phone…', 'idev-clinic-emr'), 'none' => __('Not found.', 'idev-clinic-emr'), 'add' => __('Add to queue', 'idev-clinic-emr'), 'open' => __('Open chart', 'idev-clinic-emr'),
            'newPatient' => __('New patient', 'idev-clinic-emr'), 'allergy' => __('Allergy', 'idev-clinic-emr'), 'itemSearch' => __('Search medicine / service in stock…', 'idev-clinic-emr'),
            'qty' => __('Qty', 'idev-clinic-emr'), 'price' => __('Price', 'idev-clinic-emr'), 'use' => __('Directions (on the label)', 'idev-clinic-emr'), 'remove' => __('Remove', 'idev-clinic-emr'),
            'stock' => __('in stock', 'idev-clinic-emr'), 'service' => __('service', 'idev-clinic-emr'), 'total' => __('Total', 'idev-clinic-emr'), 'noOrders' => __('No medicines or services yet. Search above, or use Re-med.', 'idev-clinic-emr'),
            'allergyHit' => __('ALLERGY WARNING: the patient is allergic to %s', 'idev-clinic-emr'), 'ack' => __('I have checked; give anyway', 'idev-clinic-emr'),
            'mustAck' => __('Please check the drug allergy warning (tick the box) or remove the drug.', 'idev-clinic-emr'), 'remedDone' => __('Copied %d items from the visit of %s.', 'idev-clinic-emr'),
            'dxSearch' => __('Type a code or disease (Thai / English)…', 'idev-clinic-emr'), 'dxFree' => __('Use as typed', 'idev-clinic-emr'), 'principal' => __('Principal', 'idev-clinic-emr'),
            'noSlots' => __('No free times on this day.', 'idev-clinic-emr'), 'chooseTime' => __('— time —', 'idev-clinic-emr'), 'left' => __('free', 'idev-clinic-emr'), 'ind' => __('Indication', 'idev-clinic-emr'), 'warn' => __('Warning', 'idev-clinic-emr'),
            'fill' => __('Fill in', 'idev-clinic-emr'), 'remedSel' => __('Re-med from an earlier visit…', 'idev-clinic-emr'), 'unsaved' => __('You have unsaved changes.', 'idev-clinic-emr'), 'low' => __('low', 'idev-clinic-emr'), 'out' => __('out of stock', 'idev-clinic-emr'),
        ],
        'builder' => function_exists('idev_store_pos_drug_cfg') ? (idev_store_pos_drug_cfg()['builder'] ?? null) : null,
    ];
}

/** Page header with the tabs of the examination room. */
function idev_emr_head($title, $subtitle = '', $current = '') {
    $tabs = ['idev-emr' => __('Today\'s queue', 'idev-clinic-emr')];
    if (idev_emr_can('doctor')) $tabs['idev-emr-doctor'] = __('Doctor\'s room', 'idev-clinic-emr');
    $tabs += ['idev-emr-patients' => __('Patients', 'idev-clinic-emr'), 'idev-emr-reports' => __('Reports', 'idev-clinic-emr')];
    if (current_user_can('manage_options')) $tabs['idev-emr-settings'] = __('Settings', 'idev-clinic-emr');
    $licensed = function_exists('idev_store_licensed') && idev_store_licensed();
    idev_page_open($title, $subtitle ?: (defined('IDEV_PACKAGE_NAME') ? IDEV_PACKAGE_NAME : __('Examination room', 'idev-clinic-emr')), ['tabs' => $tabs, 'current' => $current ?: sanitize_key($_GET['page'] ?? 'idev-emr'), 'chip' => $licensed ? [__('Licensed', 'idev-clinic-emr'), 'ok'] : [__('Trial', 'idev-clinic-emr'), 'trial'], // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        'url' => function ($k) { return idev_emr_url($k); }, 'icons' => ['idev-emr-doctor' => 'stethoscope', 'idev-emr' => 'list', 'idev-emr-patients' => 'users', 'idev-emr-reports' => 'chart', 'idev-emr-settings' => 'gear']]);
    idev_emr_flash();
}

/* ---------- Form posts (post → redirect → get) ---------- */

add_action('admin_init', function () {
    $page = sanitize_key($_GET['page'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || strpos($page, 'idev-emr') !== 0 || empty($_POST['idev_emr_action'])) return;
    $action = sanitize_key($_POST['idev_emr_action']);
    if (!idev_emr_can()) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-clinic-emr'), 403);
    check_admin_referer('idev_emr_' . $action);
    do_action('idev_emr_post_' . $action);
});
function idev_emr_form($action, $extra = '') { return '<form method="post" ' . $extra . '>' . wp_nonce_field('idev_emr_' . $action, '_wpnonce', true, false) . '<input type="hidden" name="idev_emr_action" value="' . esc_attr($action) . '">'; }
function idev_emr_redirect($url, $msg = '', $type = 'success') {
    if ($msg !== '') set_transient('idev_emr_flash_' . get_current_user_id(), [$msg, $type], 60);
    wp_safe_redirect($url);
    exit;
}
function idev_emr_flash() {
    $f = get_transient('idev_emr_flash_' . get_current_user_id());
    if (!$f) return;
    delete_transient('idev_emr_flash_' . get_current_user_id());
    echo '<div class="notice notice-' . esc_attr($f[1]) . ' is-dismissible"><p>' . wp_kses_post($f[0]) . '</p></div>';
}

add_action('idev_emr_post_queue_add', function () {
    $r = idev_emr_visit_create(['customer_id' => (int) $_POST['customer_id'], 'doctor_id' => (int) ($_POST['doctor_id'] ?? 0)]);
    if (is_wp_error($r)) idev_emr_redirect(idev_emr_url('idev-emr'), $r->get_error_message(), 'error');
    $v = idev_emr_visit($r);
    idev_emr_redirect(idev_emr_url('idev-emr'), sprintf(__('%1$s added to the queue: no. %2$d', 'idev-clinic-emr'), esc_html(idev_store_customer($v['customer_id'])['name']), $v['queue_no']));
});
add_action('idev_emr_post_checkin', function () {
    $r = idev_emr_checkin_appt((int) $_POST['appt_id']);
    if (is_wp_error($r)) idev_emr_redirect(idev_emr_url('idev-emr'), $r->get_error_message(), 'error');
    idev_emr_redirect(idev_emr_url('idev-emr'), sprintf(__('Checked in: queue no. %d', 'idev-clinic-emr'), idev_emr_visit($r)['queue_no']));
});
add_action('idev_emr_post_move', function () {
    $id = (int) $_POST['visit'];
    $to = sanitize_key($_POST['to'] ?? '');
    $labels = idev_emr_statuses();
    if (!isset($labels[$to])) idev_emr_redirect(idev_emr_url('idev-emr'));
    if ($to === 'cancelled') { $v = idev_emr_visit($id); if ($v && idev_emr_billed($v)) idev_emr_redirect(idev_emr_url('idev-emr'), __('This visit has a bill. Void the bill first.', 'idev-clinic-emr'), 'error'); }
    idev_emr_visit_save($id, ['status' => $to], $labels[$to]);
    $back = !empty($_POST['back']) ? esc_url_raw(wp_unslash($_POST['back'])) : idev_emr_url('idev-emr');
    idev_emr_redirect($back);
});

/* ---------- Small view helpers ---------- */

function idev_emr_status_chip($s) { return '<span class="emr-st st-' . esc_attr($s) . '">' . esc_html(idev_emr_statuses()[$s] ?? $s) . '</span>'; }
function idev_emr_patient_line($c, $p = null, $link = true) {
    $p = $p ?: idev_emr_profile($c['id']);
    $sex = $p['sex'] !== '' ? (idev_emr_sexes()[$p['sex']] ?? '') : '';
    $bits = array_filter(['HN ' . ($c['hn'] ?: '—'), trim($sex . ' ' . idev_emr_age($c['birthdate']))]);
    $name = $link ? '<a href="' . esc_url(idev_emr_url('idev-emr-patients', ['id' => $c['id']])) . '">' . esc_html($c['name']) . '</a>' : esc_html($c['name']);
    $al = $p['allergies'] ? ' <span class="emr-tag red" title="' . esc_attr(implode(', ', array_column($p['allergies'], 'drug'))) . '">⚠ ' . esc_html__('Allergy', 'idev-clinic-emr') . '</span>' : '';
    return '<b class="emr-pname">' . $name . '</b>' . $al . '<small class="emr-pmeta">' . esc_html(implode(' · ', $bits)) . '</small>';
}
function idev_emr_move_button($v, $to, $label, $primary = false, $back = '') {
    return idev_emr_form('move', 'class="emr-inline"') . '<input type="hidden" name="visit" value="' . (int) $v['id'] . '"><input type="hidden" name="to" value="' . esc_attr($to) . '">' . ($back ? '<input type="hidden" name="back" value="' . esc_attr($back) . '">' : '') . '<button class="button' . ($primary ? ' button-primary' : '') . '">' . esc_html($label) . '</button></form>';
}

/* ---------- Today's queue ---------- */

function idev_emr_page_queue() {
    $date = idev_is_valid_date($_GET['date'] ?? '') ? $_GET['date'] : idev_today(); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $today = $date === idev_today();
    $visits = idev_emr_visits(['date' => $date]);
    $by = [];
    foreach ($visits as $v) $by[$v['status']][] = $v;
    idev_emr_head(__('Today\'s queue', 'idev-clinic-emr'), idev_format_day($date, null, true, true));
    if (!idev_emr_ready()) { echo '<p>' . esc_html__('The shop module (patients, stock, bills) is not active.', 'idev-clinic-emr') . '</p>'; idev_page_close(); return; }
    // Day switch + search
    echo '<div class="emr-top"><div class="emr-days"><a class="button" href="' . esc_url(idev_emr_url('idev-emr', ['date' => idev_add_days($date, -1)])) . '">‹</a><input type="date" value="' . esc_attr($date) . '" onchange="location.href=\'' . esc_js(idev_emr_url('idev-emr')) . '&date=\'+this.value"><a class="button" href="' . esc_url(idev_emr_url('idev-emr', ['date' => idev_add_days($date, 1)])) . '">›</a>' . ($today ? '' : ' <a class="button" href="' . esc_url(idev_emr_url('idev-emr')) . '">' . esc_html__('Today', 'idev-clinic-emr') . '</a>') . '</div>';
    if ($today) {
        echo '<div class="emr-find" data-mode="queue">' . idev_icon('search') . '<input type="search" class="emr-find-in" placeholder="' . esc_attr__('Add a patient to the queue: HN, name or phone…', 'idev-clinic-emr') . '" autocomplete="off"><div class="emr-find-out"></div></div>';
        echo '<a class="button button-primary button-hero emr-newpt" href="' . esc_url(idev_emr_url('idev-emr-patients', ['id' => 'new', 'queue' => 1])) . '">＋ ' . esc_html__('New patient', 'idev-clinic-emr') . '</a>';
    }
    echo '</div>';
    // hidden form used by the search results
    echo idev_emr_form('queue_add', 'id="emr-queue-form"') . '<input type="hidden" name="customer_id" value=""></form>';
    // Stats
    $count = function ($s) use ($by) { return count($by[$s] ?? []); };
    echo '<div class="emr-stats">';
    foreach (['waiting' => 'user', 'screened' => 'clock', 'exam' => 'stethoscope', 'pay' => 'receipt', 'done' => 'shield'] as $s => $ic) echo '<div class="emr-stat st-' . $s . '">' . idev_icon($ic) . '<b>' . (int) $count($s) . '</b><span>' . esc_html(idev_emr_statuses()[$s]) . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div>';
    // Board
    $cols = ['waiting' => [], 'screened' => ['exam'], 'pay' => [], 'done' => []];
    echo '<div class="emr-board">';
    foreach ($cols as $s => $also) {
        $list = array_merge($by[$s] ?? [], ...array_map(function ($x) use ($by) { return $by[$x] ?? []; }, $also));
        usort($list, function ($a, $b) { return $a['queue_no'] - $b['queue_no']; });
        $title = $s === 'screened' ? __('Doctor', 'idev-clinic-emr') : idev_emr_statuses()[$s];
        echo '<section class="emr-col col-' . esc_attr($s) . '"><h3>' . esc_html($title) . ' <span>' . count($list) . '</span></h3>';
        if (!$list) echo '<p class="emr-empty">—</p>';
        foreach ($list as $v) idev_emr_queue_card($v);
        echo '</section>';
    }
    echo '</div>';
    if (!empty($by['cancelled'])) {
        echo '<details class="emr-cancelled"><summary>' . esc_html(sprintf(__('Cancelled (%d)', 'idev-clinic-emr'), count($by['cancelled']))) . '</summary>';
        foreach ($by['cancelled'] as $v) { $c = idev_store_customer($v['customer_id']); echo '<div>#' . (int) $v['queue_no'] . ' ' . esc_html($c['name'] ?? '') . ' ' . idev_emr_move_button($v, 'waiting', __('Back to queue', 'idev-clinic-emr')) . '</div>'; }
        echo '</details>';
    }
    // Appointments today
    if ($today && function_exists('idev_appt_table')) {
        $appts = idev_emr_today_appts();
        echo '<div class="idev-card emr-appts"><h2>' . idev_icon('calendar') . esc_html__('Appointments today — not checked in', 'idev-clinic-emr') . ' <small>' . count($appts) . '</small></h2>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        if (!$appts) echo '<p class="description">' . esc_html__('No more appointments waiting today.', 'idev-clinic-emr') . '</p>';
        else {
            echo '<table class="widefat striped"><tbody>';
            foreach ($appts as $a) echo '<tr><td><b>' . esc_html($a['time']) . '</b></td><td>' . esc_html($a['name']) . ($a['hn'] ? ' <small>HN ' . esc_html($a['hn']) . '</small>' : '') . '<br><small>' . esc_html($a['provider'] . ($a['reason'] ? ' · ' . $a['reason'] : '')) . '</small></td><td class="r">' . idev_emr_form('checkin') . '<input type="hidden" name="appt_id" value="' . (int) $a['id'] . '"><button class="button button-primary">' . esc_html__('Check in', 'idev-clinic-emr') . '</button></form></td></tr>';
            echo '</tbody></table>';
        }
        echo '</div>';
    }
    idev_page_close();
}

function idev_emr_queue_card($v) {
    $c = idev_store_customer($v['customer_id']);
    if (!$c) return;
    $p = idev_emr_profile($c['id']);
    $open = idev_emr_url('idev-emr-visit', ['id' => $v['id']]);
    $vit = $v['d']['vitals'];
    $doc = $v['doctor_id'] ? idev_emr_doctor($v['doctor_id'])['name'] : '';
    echo '<article class="emr-card st-' . esc_attr($v['status']) . '"><div class="q">' . (int) $v['queue_no'] . '</div><div class="b">' . idev_emr_patient_line($c, $p, false); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $line = array_filter([$v['d']['cc'] ? mb_strimwidth($v['d']['cc'], 0, 60, '…') : '', $vit ? (isset($vit['sbp']) ? 'BP ' . $vit['sbp'] . '/' . ($vit['dbp'] ?? '') : '') . (isset($vit['temp']) ? ' T ' . $vit['temp'] : '') : '']);
    if ($line) echo '<small class="emr-cc">' . esc_html(implode(' · ', $line)) . '</small>';
    if ($v['status'] === 'exam') echo '<span class="emr-tag blue">' . esc_html__('With doctor', 'idev-clinic-emr') . ($doc ? ': ' . esc_html($doc) : '') . '</span>';
    echo '<div class="acts">';
    if ($v['status'] === 'waiting') echo '<a class="button button-primary" href="' . esc_url($open . '#screen') . '">' . esc_html__('Screening', 'idev-clinic-emr') . '</a>';
    elseif (in_array($v['status'], ['screened', 'exam'], true) && idev_emr_can('doctor')) echo idev_emr_form('call', 'class="emr-inline"') . '<input type="hidden" name="visit" value="' . (int) $v['id'] . '"><button class="button button-primary">' . esc_html__('Examine', 'idev-clinic-emr') . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    elseif (in_array($v['status'], ['screened', 'exam'], true)) echo '<a class="button" href="' . esc_url($open) . '">' . esc_html__('Open', 'idev-clinic-emr') . '</a>';
    elseif ($v['status'] === 'pay') {
        $bill = idev_emr_bill($v);
        echo $bill ? '<a class="button button-primary" href="' . esc_url(idev_store_url('idev-store-bills', ['id' => $bill['id']])) . '">' . esc_html__('Receive payment', 'idev-clinic-emr') . ' ' . esc_html(idev_store_money($bill['total'] - $bill['paid'])) . '</a>' : '<a class="button button-primary" href="' . esc_url($open . '#orders') . '">' . esc_html__('Bill', 'idev-clinic-emr') . '</a>';
        if ($bill && function_exists('idev_store_label_lines') && idev_store_label_lines($bill)) echo '<a class="button" target="_blank" href="' . esc_url(idev_store_print_url('label', $bill['id'])) . '">' . esc_html__('Drug labels', 'idev-clinic-emr') . '</a>';
        echo idev_emr_move_button($v, 'done', __('Done', 'idev-clinic-emr')); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    } else echo '<a class="button" href="' . esc_url($open) . '">' . esc_html__('Open', 'idev-clinic-emr') . '</a>';
    if (in_array($v['status'], ['waiting', 'screened'], true)) echo idev_emr_move_button($v, 'cancelled', '✕'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div></div></article>';
}

/* ---------- Doctor's room: only the doctor's work ---------- */

add_action('idev_emr_post_call', function () {
    if (!idev_emr_can('doctor')) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-clinic-emr'), 403);
    $id = (int) ($_POST['visit'] ?? 0);
    if (!$id) { $next = idev_emr_doctor_waiting(get_current_user_id()); $id = $next ? $next[0]['id'] : 0; }
    if (!$id) idev_emr_redirect(idev_emr_url('idev-emr-doctor'), __('Nobody is waiting.', 'idev-clinic-emr'), 'info');
    $v = idev_emr_visit($id);
    if ($v && in_array($v['status'], ['waiting', 'screened', 'exam'], true)) idev_emr_visit_save($id, ['status' => 'exam', 'doctor_id' => get_current_user_id()], __('Called in by the doctor', 'idev-clinic-emr'));
    wp_safe_redirect(idev_emr_url('idev-emr-visit', ['id' => $id]) . '#exam');
    exit;
});
/** Waiting for this doctor: screened, for him/her or for any doctor (queue order). */
function idev_emr_doctor_waiting($uid) {
    return array_values(array_filter(idev_emr_visits(['date' => idev_today(), 'status' => ['screened']]), function ($v) use ($uid) { return !$v['doctor_id'] || $v['doctor_id'] === $uid; }));
}
function idev_emr_page_doctor() {
    $uid = get_current_user_id();
    $me = idev_emr_doctor($uid);
    $all = idev_emr_visits(['date' => idev_today()]);
    $waiting = idev_emr_doctor_waiting($uid);
    $mine = array_values(array_filter($all, function ($v) use ($uid) { return $v['status'] === 'exam' && $v['doctor_id'] === $uid; }));
    $done = array_values(array_filter($all, function ($v) use ($uid) { return in_array($v['status'], ['pay', 'done'], true) && $v['doctor_id'] === $uid; }));
    $screening = count(array_filter($all, function ($v) { return $v['status'] === 'waiting'; }));
    idev_emr_head(__('Doctor\'s room', 'idev-clinic-emr'), $me['name'] . ' · ' . idev_format_day(idev_today(), null, true, true), 'idev-emr-doctor');
    echo '<div class="emr-stats">';
    foreach ([[count($waiting), __('Waiting for you', 'idev-clinic-emr'), 'clock', 'st-exam'], [count($mine), __('With you now', 'idev-clinic-emr'), 'stethoscope', ''], [$screening, __('At screening', 'idev-clinic-emr'), 'user', 'st-waiting'], [count($done), __('Seen today', 'idev-clinic-emr'), 'shield', '']] as [$n, $l, $ic, $c]) echo '<div class="emr-stat ' . esc_attr($c) . '">' . idev_icon($ic) . '<b>' . (int) $n . '</b><span>' . esc_html($l) . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div><div class="emr-droom">';
    // Next patient
    $next = $waiting[0] ?? null;
    echo '<section class="idev-card emr-next"><h2>' . esc_html__('Next patient', 'idev-clinic-emr') . '</h2>';
    if ($next) {
        $c = idev_store_customer($next['customer_id']);
        $p = idev_emr_profile($next['customer_id']);
        echo '<div class="emr-next-b"><div class="emr-q big">' . (int) $next['queue_no'] . '</div><div>' . idev_emr_patient_line($c, $p, false); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        if ($next['d']['cc']) echo '<p class="emr-cc big">' . esc_html($next['d']['cc']) . '</p>';
        $vt = idev_emr_vitals_text($next['d']['vitals']);
        if ($vt) echo '<p class="emr-vline">' . esc_html($vt) . '</p>';
        if ($p['allergies']) echo '<p class="emr-tag red">⚠ ' . esc_html(implode(', ', array_column($p['allergies'], 'drug'))) . '</p>';
        echo '</div></div>' . idev_emr_form('call') . '<input type="hidden" name="visit" value="' . (int) $next['id'] . '"><button class="button button-primary emr-callbtn">' . esc_html__('Call in and examine', 'idev-clinic-emr') . ' ▶</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    } else echo '<p class="emr-empty big">' . esc_html__('Nobody is waiting for the doctor right now.', 'idev-clinic-emr') . ($screening ? ' ' . esc_html(sprintf(_n('%d patient is at screening.', '%d patients are at screening.', $screening, 'idev-clinic-emr'), $screening)) : '') . '</p>';
    echo '</section>';
    // With me now
    $row = function ($v, $btn, $primary) {
        $c = idev_store_customer($v['customer_id']);
        $o = '<tr><td class="q"><b>' . (int) $v['queue_no'] . '</b></td><td>' . idev_emr_patient_line($c, null, false) . ($v['d']['cc'] ? '<small class="emr-cc">' . esc_html(mb_strimwidth($v['d']['cc'], 0, 70, '…')) . '</small>' : '') . '</td><td class="r">';
        if ($btn === 'call') $o .= idev_emr_form('call', 'class="emr-inline"') . '<input type="hidden" name="visit" value="' . (int) $v['id'] . '"><button class="button' . ($primary ? ' button-primary' : '') . '">' . esc_html__('Examine', 'idev-clinic-emr') . '</button></form>';
        else $o .= '<a class="button' . ($primary ? ' button-primary' : '') . '" href="' . esc_url(idev_emr_url('idev-emr-visit', ['id' => $v['id']]) . ($btn === 'open' ? '#exam' : '')) . '">' . esc_html($btn === 'open' ? __('Continue', 'idev-clinic-emr') : __('Open', 'idev-clinic-emr')) . '</a>';
        return $o . '</td></tr>';
    };
    echo '<section class="idev-card"><h2>' . esc_html__('With you now', 'idev-clinic-emr') . '</h2>';
    echo $mine ? '<table class="widefat emr-dtable"><tbody>' . implode('', array_map(function ($v) use ($row) { return $row($v, 'open', true); }, $mine)) . '</tbody></table>' : '<p class="emr-empty">—</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</section></div><div class="emr-cols2"><section class="idev-card"><h2>' . esc_html__('Waiting for you', 'idev-clinic-emr') . ' <small>' . count($waiting) . '</small></h2>';
    echo $waiting ? '<table class="widefat striped emr-dtable"><tbody>' . implode('', array_map(function ($v) use ($row) { return $row($v, 'call', false); }, $waiting)) . '</tbody></table>' : '<p class="emr-empty">—</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</section><section class="idev-card"><h2>' . esc_html__('Seen today', 'idev-clinic-emr') . ' <small>' . count($done) . '</small></h2>';
    echo $done ? '<table class="widefat striped emr-dtable"><tbody>' . implode('', array_map(function ($v) use ($row) { return $row($v, 'view', false); }, array_reverse($done))) . '</tbody></table>' : '<p class="emr-empty">—</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</section></div>';
    // Refresh every 30 s while nobody types
    echo '<script>setInterval(function(){if(document.visibilityState==="visible"&&!document.activeElement.matches("input,textarea,select"))location.reload()},30000)</script>';
    idev_page_close();
}
