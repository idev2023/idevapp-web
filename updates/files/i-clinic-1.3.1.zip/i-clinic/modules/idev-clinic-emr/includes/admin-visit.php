<?php
/** The visit screen: screening, examination, diagnosis, orders with re-med, follow-up, certificate, bill. */
defined('ABSPATH') || exit;

add_action('idev_emr_post_visit_save', function () {
    $id = (int) $_POST['visit'];
    $v = idev_emr_visit($id);
    if (!$v) idev_emr_redirect(idev_emr_url('idev-emr'));
    $go = sanitize_key($_POST['go'] ?? 'save');
    $doctor = idev_emr_can('doctor');
    $in = [];
    foreach (['vitals', 'cc', 'pi', 'pmh', 'nurse_note', 'pe', 'plan', 'advice', 'procedures', 'cert', 'followup'] as $k) if (isset($_POST[$k])) $in[$k] = wp_unslash($_POST[$k]);
    if ($doctor) $in['dx'] = wp_unslash($_POST['dx'] ?? []);
    if ($doctor && isset($_POST['orders_json'])) $in['orders'] = json_decode(wp_unslash($_POST['orders_json']), true) ?: [];
    if (isset($_POST['doctor_id'])) $in['doctor_id'] = (int) $_POST['doctor_id'];
    $log = [];
    if (!empty($in['vitals']) && array_filter((array) $in['vitals'], 'strlen') && !$v['d']['vitals']) $log[] = __('Vital signs', 'idev-clinic-emr');
    // status
    if ($go === 'to_doctor' && $v['status'] === 'waiting') { $in['status'] = 'screened'; $log[] = __('Sent to doctor', 'idev-clinic-emr'); }
    if ($doctor && in_array($v['status'], ['waiting', 'screened'], true) && $go !== 'to_doctor') { $in['status'] = 'exam'; if (empty($in['doctor_id']) && !$v['doctor_id']) $in['doctor_id'] = get_current_user_id(); }
    if ($go === 'done') $in['status'] = 'done';
    // allergy overrides are written in the log
    if (!empty($in['orders'])) {
        $al = idev_emr_profile($v['customer_id'])['allergies'];
        foreach ($in['orders'] as $o) if (idev_emr_allergy_hits($al, [$o['name'] ?? '', $o['generic'] ?? ''])) $log[] = sprintf(__('Allergy warning confirmed for %s', 'idev-clinic-emr'), sanitize_text_field($o['name'] ?? ''));
    }
    idev_emr_visit_save($id, $in, implode(' · ', $log) ?: __('Saved', 'idev-clinic-emr'));
    $msg = __('Saved.', 'idev-clinic-emr');
    $url = idev_emr_url('idev-emr-visit', ['id' => $id]);
    // follow-up appointment
    if (!empty($_POST['followup']['book']) && empty(idev_emr_visit($id)['d']['followup']['appt_id'])) {
        $r = idev_emr_book_followup($id);
        $msg .= ' ' . (is_wp_error($r) ? '<b>' . esc_html__('Follow-up not booked:', 'idev-clinic-emr') . '</b> ' . esc_html($r->get_error_message()) : esc_html__('Follow-up appointment booked.', 'idev-clinic-emr'));
    }
    if ($go === 'finish') {
        // Doctor: done. With medicines / services / a consultation fee → bill (payment and medicines), else the visit is done.
        $fee = (int) idev_emr_settings()['consult_item'];
        $go = (idev_emr_visit($id)['o'] || $fee) ? 'bill' : 'done';
        if ($go === 'done') { idev_emr_visit_save($id, ['status' => 'done'], __('Examination finished', 'idev-clinic-emr')); idev_emr_redirect($doctor ? idev_emr_url('idev-emr-doctor') : idev_emr_url('idev-emr'), $msg); }
    }
    if ($go === 'bill') {
        $b = idev_emr_visit_bill($id);
        if (is_wp_error($b)) idev_emr_redirect($url . '#orders', $msg . ' ' . esc_html($b->get_error_message()), 'error');
        if ($doctor && !current_user_can('idev_store_manage') && !current_user_can('manage_options') || !empty($_POST['to_room'])) idev_emr_redirect(idev_emr_url('idev-emr-doctor'), sprintf(__('%s: sent to payment and medicines.', 'idev-clinic-emr'), esc_html(idev_store_customer($v['customer_id'])['name'])) . ' ' . $msg);
        set_transient('idev_store_flash_' . get_current_user_id(), [sprintf(__('Bill for %1$s (%2$s). Receive the payment, then print the receipt and drug labels.', 'idev-clinic-emr'), esc_html(idev_store_customer($v['customer_id'])['name']), esc_html($v['vn'])), 'success'], 60);
        wp_safe_redirect(idev_store_url('idev-store-bills', ['id' => $b]));
        exit;
    }
    if ($go === 'to_doctor' || $go === 'done') idev_emr_redirect($doctor && $go === 'done' ? idev_emr_url('idev-emr-doctor') : idev_emr_url('idev-emr'), $msg);
    idev_emr_redirect($url . (!empty($_POST['anchor']) ? '#' . sanitize_key($_POST['anchor']) : ''), $msg);
});

function idev_emr_page_visit() {
    $v = idev_emr_visit((int) ($_GET['id'] ?? 0)); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $c = $v ? idev_emr_patient($v['customer_id']) : null;
    if (!$v || !$c) { idev_emr_head(__('Visit', 'idev-clinic-emr'), '', 'idev-emr'); echo '<p>' . esc_html__('Visit not found.', 'idev-clinic-emr') . '</p>'; idev_page_close(); return; }
    $p = $c['profile'];
    $d = $v['d'];
    $doctor = idev_emr_can('doctor');
    $bill = idev_emr_bill($v);
    $billed = $bill && $bill['status'] !== 'void';
    $ro = $doctor ? '' : ' readonly';
    idev_emr_head(sprintf(__('Queue %1$d · %2$s', 'idev-clinic-emr'), $v['queue_no'], $c['name']), $v['vn'] . ' · ' . idev_format_day($v['visit_date'], null, true), 'idev-emr');

    // Patient bar
    echo '<div class="emr-pbar"><div class="emr-q">' . (int) $v['queue_no'] . '</div><div class="emr-pbar-b">' . idev_emr_patient_line($c, $p) . '</div><div class="emr-pbar-s">' . idev_emr_status_chip($v['status']) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo idev_emr_steps($v['status']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo idev_emr_allergy_banner($p); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if ($p['alert']) echo '<div class="emr-alert">' . idev_icon('bell') . esc_html($p['alert']) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if ($p['chronic']) echo '<div class="emr-chronic"><b>' . esc_html__('Underlying diseases', 'idev-clinic-emr') . ':</b> ' . esc_html(preg_replace('/\s*\n\s*/', ', ', $p['chronic'])) . '</div>';

    $history = array_values(array_filter(idev_emr_visits(['customer_id' => $c['id'], 'not_cancelled' => true, 'limit' => 30]), function ($x) use ($v) { return $x['id'] !== $v['id']; }));
    $remed = array_values(array_map(function ($h) { return ['id' => $h['id'], 'date' => idev_format_day($h['visit_date']), 'vn' => $h['vn'], 'dx' => implode(', ', array_map(function ($x) { return trim($x['code'] . ' ' . $x['name']); }, $h['d']['dx'])), 'orders' => $h['o']]; }, array_filter($history, function ($h) { return !empty($h['o']); })));
    $cfg = ['allergies' => $p['allergies'], 'families' => idev_emr_allergy_families(), 'orders' => $v['o'], 'dx' => $d['dx'], 'remed' => array_slice($remed, 0, 10), 'locked' => $billed || !$doctor, 'doctor' => $doctor];

    echo idev_emr_form('visit_save', 'id="emr-visit" class="emr-visit"') . '<input type="hidden" name="visit" value="' . (int) $v['id'] . '"><input type="hidden" name="anchor" value=""><script type="application/json" id="emr-visit-data">' . wp_json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div class="emr-cols"><div class="emr-main">';

    // 1. Screening
    $fold = $doctor && $v['status'] !== 'waiting';
    echo '<section class="idev-card emr-sec' . ($fold ? ' folded' : '') . '" id="screen"><h2><span class="n">1</span>' . esc_html__('Screening and vital signs', 'idev-clinic-emr') . ($fold ? ' <button type="button" class="button button-small emr-unfold">' . esc_html__('Edit', 'idev-clinic-emr') . '</button>' : '') . '</h2>';
    if ($fold) {
        $vt = idev_emr_vitals_text($d['vitals']);
        echo '<div class="emr-sum"><p class="emr-vline big">' . ($vt !== '' ? esc_html($vt) : '<span class="emr-muted">' . esc_html__('No vital signs recorded', 'idev-clinic-emr') . '</span>') . '</p>';
        foreach (['cc' => __('Chief complaint (CC)', 'idev-clinic-emr'), 'pi' => __('Present illness (PI)', 'idev-clinic-emr'), 'pmh' => __('Past history / current medicines', 'idev-clinic-emr'), 'nurse_note' => __('Nurse note', 'idev-clinic-emr')] as $k => $l) if ($d[$k] !== '') echo '<p><b>' . esc_html($l) . ':</b> ' . nl2br(esc_html($d[$k])) . '</p>';
        echo '</div>';
    }
    echo '<div class="emr-screen-f"' . ($fold ? ' hidden' : '') . '><div class="emr-vitals">';
    foreach (idev_emr_vital_fields() as $k => [$label, $unit, $attrs]) {
        $val = $d['vitals'][$k] ?? '';
        echo '<label class="emr-vf ' . esc_attr(idev_emr_vital_flag($k, $val)) . '" data-k="' . esc_attr($k) . '"><span>' . esc_html($label) . '</span><input type="number" inputmode="decimal" name="vitals[' . esc_attr($k) . ']" value="' . esc_attr($val) . '" ' . $attrs . '><em>' . esc_html($unit) . '</em></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed attrs
    }
    $bmi = idev_emr_bmi($d['vitals']);
    echo '<div class="emr-vf bmi"><span>BMI</span><b id="emr-bmi">' . esc_html($bmi ?: '—') . '</b><em id="emr-bmi-t"></em></div></div>';
    echo '<div class="emr-grid2"><label class="emr-f"><span>' . esc_html__('Chief complaint (CC)', 'idev-clinic-emr') . '</span><textarea name="cc" rows="2" placeholder="' . esc_attr__('e.g. fever and sore throat for 2 days', 'idev-clinic-emr') . '">' . esc_textarea($d['cc']) . '</textarea></label>';
    echo '<label class="emr-f"><span>' . esc_html__('Present illness (PI)', 'idev-clinic-emr') . '</span><textarea name="pi" rows="2">' . esc_textarea($d['pi']) . '</textarea></label>';
    echo '<label class="emr-f"><span>' . esc_html__('Past history / current medicines', 'idev-clinic-emr') . '</span><textarea name="pmh" rows="2">' . esc_textarea($d['pmh']) . '</textarea></label>';
    echo '<label class="emr-f"><span>' . esc_html__('Nurse note', 'idev-clinic-emr') . '</span><textarea name="nurse_note" rows="2">' . esc_textarea($d['nurse_note']) . '</textarea></label></div>';
    echo '</div></section>';

    // 2. Examination
    echo '<section class="idev-card emr-sec" id="exam"><h2><span class="n">2</span>' . esc_html__('Examination and diagnosis', 'idev-clinic-emr') . '</h2>';
    if (!$doctor) echo '<p class="description">' . esc_html__('Only doctors can write this part.', 'idev-clinic-emr') . '</p>';
    $doctors = idev_emr_doctors();
    echo '<div class="emr-grid2"><label class="emr-f"><span>' . esc_html__('Doctor', 'idev-clinic-emr') . '</span><select name="doctor_id"><option value="0">—</option>';
    foreach ($doctors as $uid => $name) echo '<option value="' . (int) $uid . '"' . selected($v['doctor_id'] ?: ($doctor ? get_current_user_id() : 0), $uid, false) . '>' . esc_html($name) . '</option>';
    echo '</select></label><span></span>';
    echo '<label class="emr-f wide"><span>' . esc_html__('Physical examination (PE)', 'idev-clinic-emr') . '</span><textarea name="pe" rows="3"' . $ro . ' placeholder="' . esc_attr__('e.g. Injected pharynx, tonsils not enlarged, lungs clear', 'idev-clinic-emr') . '">' . esc_textarea($d['pe']) . '</textarea></label></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div class="emr-f wide"><span>' . esc_html__('Diagnosis (ICD-10)', 'idev-clinic-emr') . '</span><div id="emr-dx" class="emr-dxbox"></div></div>';
    echo '<div class="emr-grid2"><label class="emr-f"><span>' . esc_html__('Treatment / procedures', 'idev-clinic-emr') . '</span><textarea name="procedures" rows="2"' . $ro . ' placeholder="' . esc_attr__('e.g. wound dressing, injection, nebulizer', 'idev-clinic-emr') . '">' . esc_textarea($d['procedures']) . '</textarea></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label class="emr-f"><span>' . esc_html__('Plan', 'idev-clinic-emr') . '</span><textarea name="plan" rows="2"' . $ro . '>' . esc_textarea($d['plan']) . '</textarea></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label class="emr-f"><span>' . esc_html__('Advice for the patient', 'idev-clinic-emr') . '</span><textarea name="advice" rows="2"' . $ro . ' placeholder="' . esc_attr__('e.g. drink plenty of water, rest, come back if the fever lasts over 3 days', 'idev-clinic-emr') . '">' . esc_textarea($d['advice']) . '</textarea></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label class="emr-f"><span>' . esc_html__('Doctor\'s note (not printed)', 'idev-clinic-emr') . '</span><textarea name="note" rows="2"' . $ro . '>' . esc_textarea($d['note']) . '</textarea></label></div></section>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

    // 3. Orders
    echo '<section class="idev-card emr-sec" id="orders"><h2><span class="n">3</span>' . esc_html__('Medicines and services', 'idev-clinic-emr') . '</h2>';
    if ($billed) echo '<p class="emr-billed">' . idev_icon('receipt') . sprintf(esc_html__('On bill %1$s (%2$s). To change medicines, void the bill first.', 'idev-clinic-emr'), '<a href="' . esc_url(idev_store_url('idev-store-bills', ['id' => $bill['id']])) . '">' . esc_html($bill['no']) . '</a>', esc_html(idev_store_bill_statuses()[$bill['status']] ?? $bill['status'])) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div id="emr-orders"></div><input type="hidden" name="orders_json" id="emr-orders-json" value="">';
    $fee = (int) idev_emr_settings()['consult_item'];
    if ($fee && function_exists('idev_store_item') && ($it = idev_store_item($fee))) echo '<p class="description">' . esc_html(sprintf(__('The consultation fee "%1$s" (%2$s) is added to the bill automatically.', 'idev-clinic-emr'), $it['name'], idev_store_money($it['price']))) . '</p>';
    echo '</section>';

    // 4. Follow-up and certificate
    $f = $d['followup'];
    echo '<section class="idev-card emr-sec" id="next"><h2><span class="n">4</span>' . esc_html__('Follow-up and medical certificate', 'idev-clinic-emr') . '</h2><div class="emr-grid2"><div><h3>' . esc_html__('Next appointment', 'idev-clinic-emr') . '</h3>';
    if (!empty($f['appt_id'])) echo '<p class="emr-ok">✓ ' . esc_html(sprintf(__('Booked: %1$s %2$s', 'idev-clinic-emr'), idev_format_day($f['date'] ?? '', null, true), $f['time'] ?? '')) . ' <a href="' . esc_url(admin_url('admin.php?page=idev-appt')) . '">' . esc_html__('Appointments', 'idev-clinic-emr') . ' →</a></p>';
    elseif (function_exists('idev_appt_providers_all') && ($provs = idev_appt_providers_all())) {
        echo '<div class="emr-fu"><label class="emr-f"><span>' . esc_html__('Doctor / clinic', 'idev-clinic-emr') . '</span><select name="followup[provider]" id="emr-fu-p"><option value="">—</option>';
        foreach ($provs as $pr) echo '<option value="' . (int) $pr['id'] . '"' . selected($f['provider'] ?? 0, $pr['id'], false) . '>' . esc_html($pr['name']) . '</option>';
        echo '</select></label><div class="emr-fu-d"><label class="emr-f"><span>' . esc_html__('Date', 'idev-clinic-emr') . '</span><input type="date" name="followup[date]" id="emr-fu-d" value="' . esc_attr($f['date'] ?? '') . '" min="' . esc_attr(idev_today()) . '"></label><div class="emr-quickd">';
        foreach ([3, 7, 14, 30, 60, 90] as $n) echo '<button type="button" class="button button-small" data-days="' . (int) $n . '">' . esc_html(sprintf($n >= 30 ? __('%d mo', 'idev-clinic-emr') : __('%d d', 'idev-clinic-emr'), $n >= 30 ? $n / 30 : $n)) . '</button>';
        echo '</div></div><label class="emr-f"><span>' . esc_html__('Time', 'idev-clinic-emr') . '</span><select name="followup[time]" id="emr-fu-t" data-value="' . esc_attr($f['time'] ?? '') . '"><option value="">' . esc_html__('— time —', 'idev-clinic-emr') . '</option></select></label>';
        echo '<label class="emr-f"><span>' . esc_html__('Note', 'idev-clinic-emr') . '</span><input type="text" name="followup[note]" value="' . esc_attr($f['note'] ?? '') . '" placeholder="' . esc_attr__('e.g. check blood pressure, lab results', 'idev-clinic-emr') . '"></label>';
        echo '<label class="emr-check"><input type="checkbox" name="followup[book]" value="1"> ' . esc_html__('Book this appointment when I save (the patient gets LINE / SMS / e-mail reminders)', 'idev-clinic-emr') . '</label></div>';
    } else {
        echo '<div class="emr-fu"><label class="emr-f"><span>' . esc_html__('Date', 'idev-clinic-emr') . '</span><input type="date" name="followup[date]" value="' . esc_attr($f['date'] ?? '') . '"></label><label class="emr-f"><span>' . esc_html__('Note', 'idev-clinic-emr') . '</span><input type="text" name="followup[note]" value="' . esc_attr($f['note'] ?? '') . '"></label></div>';
    }
    $cert = idev_emr_cert_data($v);
    $dis = $doctor ? '' : ' disabled';
    echo '</div><div><h3>' . esc_html__('Medical certificate', 'idev-clinic-emr') . '</h3><div class="emr-seg">';
    foreach (idev_emr_cert_types() as $k => $l) echo '<label><input type="radio" name="cert[type]" value="' . esc_attr($k) . '"' . checked($cert['type'], $k, false) . $dis . '> ' . esc_html($l) . '</label>';
    echo '</div><div data-cert="sick"' . ($cert['type'] === 'sick' ? '' : ' hidden') . '><div class="emr-grid2 tight"><label class="emr-f"><span>' . esc_html__('Rest (days)', 'idev-clinic-emr') . '</span><input type="number" min="0" max="90" name="cert[days]" value="' . esc_attr($cert['days']) . '"' . $ro . '></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label class="emr-f"><span>' . esc_html__('From', 'idev-clinic-emr') . '</span><input type="date" name="cert[from]" value="' . esc_attr($cert['from'] ?: $v['visit_date']) . '"' . $ro . '></label></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label class="emr-f"><span>' . esc_html__('For (purpose)', 'idev-clinic-emr') . '</span><input type="text" name="cert[purpose]" value="' . esc_attr($cert['purpose']) . '"' . $ro . ' placeholder="' . esc_attr__('e.g. sick leave, job application, driving licence', 'idev-clinic-emr') . '"></label></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div data-cert="health"' . ($cert['type'] === 'health' ? '' : ' hidden') . '><p class="description">' . esc_html__('Part 1 (history): leave empty for "No".', 'idev-clinic-emr') . '</p><div class="emr-grid2 tight">';
    foreach (['h_acc' => __('Accident and surgery', 'idev-clinic-emr'), 'h_hosp' => __('Admitted to hospital', 'idev-clinic-emr'), 'h_epi' => __('Epilepsy', 'idev-clinic-emr'), 'h_other' => __('Other important history', 'idev-clinic-emr')] as $k => $l) echo '<label class="emr-f"><span>' . esc_html($l) . '</span><input type="text" name="cert[' . $k . ']" value="' . esc_attr($cert[$k]) . '"' . $ro . '></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div><div class="emr-seg"><label><input type="radio" name="cert[general]" value="normal"' . checked($cert['general'], 'normal', false) . $dis . '> ' . esc_html__('General condition normal', 'idev-clinic-emr') . '</label><label><input type="radio" name="cert[general]" value="abnormal"' . checked($cert['general'], 'abnormal', false) . $dis . '> ' . esc_html__('Abnormal', 'idev-clinic-emr') . '</label></div>';
    echo '<div class="emr-grid2 tight"><label class="emr-f"><span>' . esc_html__('Abnormal (specify)', 'idev-clinic-emr') . '</span><input type="text" name="cert[general_note]" value="' . esc_attr($cert['general_note']) . '"' . $ro . '></label><label class="emr-f"><span>' . esc_html__('Other diseases found', 'idev-clinic-emr') . '</span><input type="text" name="cert[other_disease]" value="' . esc_attr($cert['other_disease']) . '"' . $ro . '></label></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label class="emr-f"><span>' . esc_html__('Doctor\'s opinion', 'idev-clinic-emr') . '</span><textarea name="cert[opinion]" rows="2"' . $ro . '>' . esc_textarea($cert['opinion']) . '</textarea></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<p><a class="button" target="_blank" href="' . esc_url(idev_emr_print_url('cert', $v['id'])) . '">🖨 ' . esc_html__('Print certificate', 'idev-clinic-emr') . '</a> <span class="description">' . esc_html__('Save first so the print shows your changes.', 'idev-clinic-emr') . '</span></p></div></div></section>';
    echo '</div>';

    // Sidebar: history with re-med
    echo '<aside class="emr-side"><div class="idev-card emr-sidehist"><h3>' . idev_icon('list') . esc_html__('Earlier visits', 'idev-clinic-emr') . '</h3>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if (!$history) echo '<p class="emr-empty">' . esc_html__('First visit.', 'idev-clinic-emr') . '</p>';
    foreach (array_slice($history, 0, 6) as $h) {
        echo '<div class="emr-sh"><div class="emr-sh-h"><b>' . esc_html(idev_format_day($h['visit_date'])) . '</b>';
        if ($h['o'] && $doctor && !$billed) echo '<button type="button" class="button button-small emr-remed" data-id="' . (int) $h['id'] . '">↻ ' . esc_html__('Re-med', 'idev-clinic-emr') . '</button>';
        echo '</div>';
        if ($h['d']['dx']) echo '<div class="emr-sh-dx">' . esc_html(implode(', ', array_map(function ($x) { return trim($x['code'] . ' ' . $x['name']); }, $h['d']['dx']))) . '</div>';
        $vt = idev_emr_vitals_text(array_intersect_key($h['d']['vitals'], array_flip(['weight', 'sbp', 'dbp', 'temp'])));
        if ($vt) echo '<small>' . esc_html($vt) . '</small>';
        if ($h['o']) echo '<ul>' . implode('', array_map(function ($o) { return '<li>' . esc_html($o['name'] . ' × ' . idev_store_qty($o['qty'])) . '</li>'; }, $h['o'])) . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '<a href="' . esc_url(idev_emr_url('idev-emr-visit', ['id' => $h['id']])) . '">' . esc_html__('Open', 'idev-clinic-emr') . ' →</a></div>';
    }
    if (count($history) > 6) echo '<p><a href="' . esc_url(idev_emr_url('idev-emr-patients', ['id' => $c['id']])) . '">' . esc_html__('All history', 'idev-clinic-emr') . ' →</a></p>';
    echo '</div><div class="idev-card"><h3>' . esc_html__('Log', 'idev-clinic-emr') . '</h3><ul class="emr-log">';
    foreach (array_reverse(array_slice($v['log'], -8)) as $l) echo '<li><small>' . esc_html(substr($l['at'], 11, 5) . ' · ' . $l['by']) . '</small> ' . esc_html($l['text']) . '</li>';
    echo '</ul></div></aside></div>';

    // Action bar: only what this person needs now
    $fee = (int) idev_emr_settings()['consult_item'];
    $back = $doctor ? idev_emr_url('idev-emr-doctor') : idev_emr_url('idev-emr');
    echo '<div class="emr-actions"><div class="emr-actions-in"><a class="button button-large emr-back" href="' . esc_url($back) . '">← ' . esc_html($doctor ? __('Doctor\'s room', 'idev-clinic-emr') : __('Queue', 'idev-clinic-emr')) . '</a>';
    $st = $v['status'];
    if ($st === 'waiting') {
        echo '<button class="button button-large" name="go" value="save">' . esc_html__('Save', 'idev-clinic-emr') . '</button><button class="button button-primary button-hero emr-go" name="go" value="to_doctor">' . esc_html__('Send to doctor', 'idev-clinic-emr') . ' →</button>';
    } elseif (in_array($st, ['screened', 'exam'], true) && $doctor) {
        echo '<button class="button button-large" name="go" value="save">' . esc_html__('Save for now', 'idev-clinic-emr') . '</button><button class="button button-primary button-hero emr-go" name="go" value="finish">✓ ' . esc_html($v['o'] || $fee ? __('Examination done → payment & medicines', 'idev-clinic-emr') : __('Examination done', 'idev-clinic-emr')) . '</button>';
    } elseif (in_array($st, ['screened', 'exam'], true)) {
        echo '<button class="button button-large" name="go" value="save">' . esc_html__('Save', 'idev-clinic-emr') . '</button><span class="emr-hint">' . esc_html__('Waiting for the doctor', 'idev-clinic-emr') . '</span>';
    } else {
        echo '<button class="button button-large" name="go" value="save">' . esc_html__('Save changes', 'idev-clinic-emr') . '</button>';
        if ($billed && $bill['status'] !== 'paid' && !($doctor && !current_user_can('idev_store_manage') && !current_user_can('manage_options'))) echo '<a class="button button-primary button-hero emr-go" href="' . esc_url(idev_store_url('idev-store-bills', ['id' => $bill['id']])) . '">' . idev_icon('receipt') . esc_html(sprintf(__('Receive payment %s', 'idev-clinic-emr'), idev_store_money($bill['total'] - $bill['paid']))) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        elseif ($billed) echo '<span class="emr-hint">' . esc_html($bill['status'] === 'paid' ? __('Paid', 'idev-clinic-emr') : __('Sent to payment and medicines', 'idev-clinic-emr')) . '</span>';
        elseif ($st === 'pay' && ($doctor || $v['o'])) echo '<button class="button button-primary button-hero emr-go" name="go" value="bill">' . idev_icon('receipt') . esc_html__('Make the bill', 'idev-clinic-emr') . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
    // print menu
    echo '<details class="emr-print"><summary class="button button-large">🖨 ' . esc_html__('Print', 'idev-clinic-emr') . ' ▾</summary><div>';
    echo '<a target="_blank" href="' . esc_url(idev_emr_print_url('cert', $v['id'])) . '">' . esc_html__('Medical certificate', 'idev-clinic-emr') . '</a><a target="_blank" href="' . esc_url(idev_emr_print_url('opd', $v['id'])) . '">' . esc_html__('Visit summary', 'idev-clinic-emr') . '</a>';
    if ($billed && function_exists('idev_store_label_lines') && idev_store_label_lines($bill)) echo '<a target="_blank" href="' . esc_url(idev_store_print_url('label', $bill['id'])) . '">' . esc_html__('Drug labels', 'idev-clinic-emr') . '</a>';
    if ($billed) echo '<a target="_blank" href="' . esc_url(idev_store_print_url('bill', $bill['id'])) . '">' . esc_html__('Receipt', 'idev-clinic-emr') . '</a>';
    echo '</div></details><span class="emr-dirty" hidden>● ' . esc_html__('Not saved', 'idev-clinic-emr') . '</span></div></div></form>';
    idev_page_close();
}

/** Where the visit is: ① screening → ② doctor → ③ payment / medicines → ④ done. */
function idev_emr_steps($status) {
    $steps = ['waiting' => __('Screening', 'idev-clinic-emr'), 'exam' => __('Doctor', 'idev-clinic-emr'), 'pay' => __('Payment / medicines', 'idev-clinic-emr'), 'done' => __('Done', 'idev-clinic-emr')];
    $at = ['waiting' => 0, 'screened' => 1, 'exam' => 1, 'pay' => 2, 'done' => 3, 'cancelled' => -1][$status] ?? 0;
    $o = '<ol class="emr-steps">';
    $i = 0;
    foreach ($steps as $l) { $o .= '<li class="' . ($i < $at ? 'ok' : ($i === $at ? 'now' : '')) . '"><span>' . ($i < $at ? '✓' : $i + 1) . '</span>' . esc_html($l) . '</li>'; $i++; }
    return $o . '</ol>';
}
