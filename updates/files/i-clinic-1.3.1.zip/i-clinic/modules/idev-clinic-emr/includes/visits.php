<?php
/**
 * Visits (VN): queue of the day → screening → doctor → payment / dispensing → done.
 * Clinical data (vital signs, notes, diagnoses, orders) is encrypted; bill and stock go through the shop module.
 */
defined('ABSPATH') || exit;

function idev_emr_statuses() {
    return [
        'waiting' => __('Waiting for screening', 'idev-clinic-emr'),
        'screened' => __('Waiting for doctor', 'idev-clinic-emr'),
        'exam' => __('With doctor', 'idev-clinic-emr'),
        'pay' => __('Payment / medicines', 'idev-clinic-emr'),
        'done' => __('Done', 'idev-clinic-emr'),
        'cancelled' => __('Cancelled', 'idev-clinic-emr'),
    ];
}
/** Vital signs: key => [label, unit, input attrs]. */
function idev_emr_vital_fields() {
    return [
        'weight' => [__('Weight', 'idev-clinic-emr'), 'kg', 'step="0.1" min="0" max="400"'],
        'height' => [__('Height', 'idev-clinic-emr'), 'cm', 'step="0.1" min="0" max="250"'],
        'temp' => [__('Temp.', 'idev-clinic-emr'), '°C', 'step="0.1" min="30" max="45"'],
        'sbp' => [__('BP sys.', 'idev-clinic-emr'), 'mmHg', 'step="1" min="40" max="300"'],
        'dbp' => [__('BP dia.', 'idev-clinic-emr'), 'mmHg', 'step="1" min="20" max="200"'],
        'pulse' => [__('Pulse', 'idev-clinic-emr'), '/min', 'step="1" min="20" max="250"'],
        'rr' => [__('Resp. rate', 'idev-clinic-emr'), '/min', 'step="1" min="4" max="80"'],
        'spo2' => [__('SpO₂', 'idev-clinic-emr'), '%', 'step="1" min="50" max="100"'],
        'pain' => [__('Pain score', 'idev-clinic-emr'), '/10', 'step="1" min="0" max="10"'],
        'dtx' => [__('Blood sugar (DTX)', 'idev-clinic-emr'), 'mg/dL', 'step="1" min="10" max="900"'],
        'waist' => [__('Waist', 'idev-clinic-emr'), 'cm', 'step="0.5" min="0" max="250"'],
    ];
}
function idev_emr_bmi($v) { $w = (float) ($v['weight'] ?? 0); $h = (float) ($v['height'] ?? 0) / 100; return $w > 0 && $h > 0 ? round($w / ($h * $h), 1) : ''; }
/** Values outside the usual adult range get a warning colour. */
function idev_emr_vital_flag($k, $v) {
    if ($v === '' || $v === null) return '';
    $v = (float) $v;
    $r = ['temp' => [35.5, 37.5], 'sbp' => [90, 139], 'dbp' => [60, 89], 'pulse' => [50, 110], 'rr' => [10, 24], 'spo2' => [95, 100], 'pain' => [0, 6], 'dtx' => [70, 180]][$k] ?? null;
    return $r && ($v < $r[0] || $v > $r[1]) ? 'hi' : '';
}

function idev_emr_visit_row($r) {
    if (!$r) return null;
    foreach (['id', 'customer_id', 'queue_no', 'doctor_id', 'appt_id', 'bill_id', 'created_by'] as $k) $r[$k] = (int) $r[$k];
    $r['d'] = array_merge(['vitals' => [], 'cc' => '', 'pi' => '', 'pmh' => '', 'pe' => '', 'dx' => [], 'plan' => '', 'advice' => '', 'note' => '', 'nurse_note' => '', 'followup' => [], 'cert' => [], 'procedures' => ''], idev_emr_dec($r['data']));
    $r['o'] = idev_emr_dec($r['orders']);
    $r['log'] = json_decode((string) $r['log'], true) ?: [];
    unset($r['data'], $r['orders']);
    return $r;
}
function idev_emr_visit($id) {
    global $wpdb;
    return idev_emr_visit_row($wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_emr_t('visits') . ' WHERE id = %d', $id), ARRAY_A));
}
/** $a: date, status (string|array), customer_id, doctor_id, from, to, limit, open (bool: not done/cancelled). */
function idev_emr_visits($a = []) {
    global $wpdb;
    $w = ['1=1']; $args = [];
    if (!empty($a['date'])) { $w[] = 'visit_date = %s'; $args[] = $a['date']; }
    if (!empty($a['from'])) { $w[] = 'visit_date >= %s'; $args[] = $a['from']; }
    if (!empty($a['to'])) { $w[] = 'visit_date <= %s'; $args[] = $a['to']; }
    if (!empty($a['customer_id'])) { $w[] = 'customer_id = %d'; $args[] = (int) $a['customer_id']; }
    if (!empty($a['doctor_id'])) { $w[] = 'doctor_id = %d'; $args[] = (int) $a['doctor_id']; }
    if (!empty($a['status'])) { $st = (array) $a['status']; $w[] = 'status IN (' . implode(',', array_fill(0, count($st), '%s')) . ')'; $args = array_merge($args, $st); }
    if (!empty($a['not_cancelled'])) $w[] = "status <> 'cancelled'";
    $order = !empty($a['customer_id']) ? 'visit_date DESC, id DESC' : 'visit_date ASC, queue_no ASC';
    $sql = 'SELECT * FROM ' . idev_emr_t('visits') . ' WHERE ' . implode(' AND ', $w) . " ORDER BY $order LIMIT " . (int) ($a['limit'] ?? 500);
    return array_map('idev_emr_visit_row', $wpdb->get_results($args ? $wpdb->prepare($sql, ...$args) : $sql, ARRAY_A)); // phpcs:ignore WordPress.DB
}
function idev_emr_open_visit($customer_id, $date = '') {
    global $wpdb;
    $id = (int) $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . idev_emr_t('visits') . " WHERE customer_id = %d AND visit_date = %s AND status NOT IN ('done','cancelled') ORDER BY id DESC LIMIT 1", $customer_id, $date ?: idev_today()));
    return $id ? idev_emr_visit($id) : null;
}

function idev_emr_log(&$log, $text) {
    $u = wp_get_current_user();
    $log[] = ['at' => idev_emr_now(), 'by' => $u && $u->ID ? $u->display_name : 'system', 'text' => $text];
    if (count($log) > 80) $log = array_slice($log, -80);
}

/** Opens a visit (adds the patient to today's queue). $in: customer_id, doctor_id, appt_id, cc, orders (re-med), dx. Returns id or WP_Error. */
function idev_emr_visit_create($in) {
    global $wpdb;
    $cid = (int) ($in['customer_id'] ?? 0);
    if (!$cid || !idev_store_customer($cid)) return new WP_Error('patient', __('Patient not found.', 'idev-clinic-emr'));
    $date = idev_today();
    if (empty($in['force']) && ($open = idev_emr_open_visit($cid, $date))) return $open['id'];
    $q = 1 + (int) $wpdb->get_var($wpdb->prepare('SELECT MAX(queue_no) FROM ' . idev_emr_t('visits') . ' WHERE visit_date = %s', $date));
    $vn = idev_store_next_no('VN');
    $log = [];
    idev_emr_log($log, !empty($in['appt_id']) ? __('Checked in from appointment', 'idev-clinic-emr') : __('Added to queue', 'idev-clinic-emr'));
    $d = ['cc' => sanitize_textarea_field($in['cc'] ?? '')];
    if (!empty($in['dx'])) $d['dx'] = $in['dx'];
    $status = idev_emr_settings()['queue_screen'] === '1' ? 'waiting' : 'screened';
    $now = idev_emr_now();
    $wpdb->insert(idev_emr_t('visits'), ['vn' => $vn, 'customer_id' => $cid, 'visit_date' => $date, 'queue_no' => $q, 'status' => $status, 'doctor_id' => (int) ($in['doctor_id'] ?? 0), 'appt_id' => (int) ($in['appt_id'] ?? 0),
        'data' => idev_emr_enc($d), 'orders' => idev_emr_enc(idev_emr_orders_clean($in['orders'] ?? [])), 'log' => wp_json_encode($log, JSON_UNESCAPED_UNICODE), 'created_by' => get_current_user_id(), 'created_at' => $now, 'updated_at' => $now]);
    $id = (int) $wpdb->insert_id;
    if (!$id) return new WP_Error('db', __('Could not save. Please try again.', 'idev-clinic-emr'));
    if (!empty($in['appt_id']) && function_exists('idev_appt_set_status')) idev_appt_set_status((int) $in['appt_id'], 'completed', 'staff');
    do_action('idev_emr_visit_created', $id);
    return $id;
}

/** Saves parts of a visit. $in may contain: vitals, cc, pi, pmh, pe, dx, plan, advice, note, nurse_note, procedures, orders, cert, followup, doctor_id, status. */
function idev_emr_visit_save($id, $in, $log_text = '') {
    global $wpdb;
    $v = idev_emr_visit($id);
    if (!$v) return new WP_Error('visit', __('Visit not found.', 'idev-clinic-emr'));
    $d = $v['d'];
    $doctor = idev_emr_can('doctor');
    if (isset($in['vitals'])) {
        $vit = [];
        foreach (idev_emr_vital_fields() as $k => $f) { $n = idev_emr_num($in['vitals'][$k] ?? ''); if ($n !== '') $vit[$k] = $n; }
        $d['vitals'] = $vit;
    }
    foreach (['cc', 'pi', 'pmh', 'nurse_note'] as $k) if (isset($in[$k])) $d[$k] = sanitize_textarea_field($in[$k]);
    if ($doctor) {
        foreach (['pe', 'plan', 'advice', 'note', 'procedures'] as $k) if (isset($in[$k])) $d[$k] = sanitize_textarea_field($in[$k]);
        if (isset($in['dx'])) $d['dx'] = idev_emr_dx_clean($in['dx']);
        if (isset($in['cert'])) $d['cert'] = idev_emr_cert_clean($in['cert']);
    }
    if (isset($in['followup'])) $d['followup'] = array_merge($d['followup'] ?: [], idev_emr_followup_clean($in['followup']));
    $row = ['data' => idev_emr_enc($d), 'updated_at' => idev_emr_now()];
    if ($doctor && isset($in['orders']) && !idev_emr_billed($v)) $row['orders'] = idev_emr_enc(idev_emr_orders_clean($in['orders']));
    if (isset($in['doctor_id'])) $row['doctor_id'] = (int) $in['doctor_id'];
    if (!empty($in['status']) && isset(idev_emr_statuses()[$in['status']])) {
        $row['status'] = $in['status'];
        if ($in['status'] === 'done' && !$v['done_at']) $row['done_at'] = idev_emr_now();
    }
    $log = $v['log'];
    if ($log_text !== '') idev_emr_log($log, $log_text);
    $row['log'] = wp_json_encode($log, JSON_UNESCAPED_UNICODE);
    $wpdb->update(idev_emr_t('visits'), $row, ['id' => $id]);
    do_action('idev_emr_visit_saved', $id);
    return true;
}

function idev_emr_dx_clean($list) {
    $out = [];
    foreach ((array) $list as $x) {
        $name = sanitize_text_field($x['name'] ?? '');
        $code = strtoupper(preg_replace('/[^A-Za-z0-9.]/', '', (string) ($x['code'] ?? '')));
        if ($name === '' && $code === '') continue;
        $out[] = ['code' => $code, 'name' => $name, 'type' => count($out) ? 'secondary' : 'principal'];
    }
    return array_slice($out, 0, 12);
}
/** Orders: drugs / supplies (item_id from stock) and services. use / ind / warn go on the drug label. */
function idev_emr_orders_clean($list) {
    $out = [];
    foreach ((array) $list as $o) {
        $name = sanitize_text_field($o['name'] ?? '');
        if ($name === '') continue;
        $qty = idev_store_num($o['qty'] ?? 1);
        if ($qty <= 0) continue;
        $out[] = ['item_id' => (int) ($o['item_id'] ?? 0), 'name' => $name, 'qty' => $qty, 'unit' => sanitize_text_field($o['unit'] ?? ''), 'price' => idev_store_num($o['price'] ?? 0),
            'use' => sanitize_textarea_field($o['use'] ?? ''), 'ind' => sanitize_text_field($o['ind'] ?? ''), 'warn' => sanitize_text_field($o['warn'] ?? ''), 'kind' => ($o['kind'] ?? '') === 'service' ? 'service' : 'product',
            'generic' => sanitize_text_field($o['generic'] ?? ''), 'ack' => !empty($o['ack']) ? 1 : 0];
    }
    return array_slice($out, 0, 60);
}
function idev_emr_cert_clean($c) {
    $c = (array) $c;
    $days = max(0, min(90, (int) ($c['days'] ?? 0)));
    $from = idev_is_valid_date($c['from'] ?? '') ? $c['from'] : '';
    $type = ($c['type'] ?? '') === 'health' ? 'health' : 'sick';
    $t = function ($k) use ($c) { return sanitize_text_field($c[$k] ?? ''); };
    return ['type' => $type, 'days' => $days, 'from' => $from, 'opinion' => sanitize_textarea_field($c['opinion'] ?? ''), 'purpose' => $t('purpose'), 'fit' => $type === 'health' ? 1 : 0,
        'h_acc' => $t('h_acc'), 'h_hosp' => $t('h_hosp'), 'h_epi' => $t('h_epi'), 'h_other' => $t('h_other'), 'general' => ($c['general'] ?? '') === 'abnormal' ? 'abnormal' : 'normal', 'general_note' => $t('general_note'), 'other_disease' => $t('other_disease')];
}
function idev_emr_followup_clean($f) {
    $f = (array) $f;
    return array_filter(['date' => idev_is_valid_date($f['date'] ?? '') ? $f['date'] : '', 'time' => preg_match('/^\d{2}:\d{2}$/', (string) ($f['time'] ?? '')) ? $f['time'] : '', 'provider' => (int) ($f['provider'] ?? 0), 'note' => sanitize_text_field($f['note'] ?? ''), 'appt_id' => (int) ($f['appt_id'] ?? 0)], function ($x) { return $x !== '' && $x !== 0; });
}

/* ---------- Bill ---------- */

function idev_emr_bill($v) { return $v['bill_id'] && function_exists('idev_store_bill') ? idev_store_bill($v['bill_id']) : null; }
function idev_emr_billed($v) { $b = idev_emr_bill($v); return $b && $b['status'] !== 'void'; }

/** Creates the bill of the visit (orders + consultation fee) and takes the medicines out of stock. Returns bill id or WP_Error. */
function idev_emr_visit_bill($id) {
    global $wpdb;
    $v = idev_emr_visit($id);
    if (!$v) return new WP_Error('visit', __('Visit not found.', 'idev-clinic-emr'));
    if (idev_emr_billed($v)) return $v['bill_id'];
    $lines = [];
    $fee = (int) idev_emr_settings()['consult_item'];
    if ($fee && ($it = idev_store_item($fee)) && !array_filter($v['o'], function ($o) use ($fee) { return (int) $o['item_id'] === $fee; })) $lines[] = ['item_id' => $fee, 'name' => $it['name'], 'qty' => 1, 'price' => $it['price']];
    foreach ($v['o'] as $o) $lines[] = ['item_id' => $o['item_id'], 'name' => $o['name'], 'qty' => $o['qty'], 'price' => $o['price'], 'label' => $o['use'] !== '' || $o['ind'] !== '' ? ['use' => $o['use'], 'ind' => $o['ind'], 'warn' => $o['warn']] : []];
    if (!$lines) return new WP_Error('empty', __('Nothing to bill: add medicines, services or a consultation fee (Settings).', 'idev-clinic-emr'));
    $bill = idev_store_bill_create(['customer_id' => $v['customer_id'], 'lines' => $lines, 'note' => $v['vn'], 'stock_type' => 'sale']);
    if (is_wp_error($bill)) return $bill;
    $log = $v['log'];
    idev_emr_log($log, sprintf(__('Bill %s created', 'idev-clinic-emr'), idev_store_bill($bill)['no']));
    $wpdb->update(idev_emr_t('visits'), ['bill_id' => $bill, 'status' => in_array($v['status'], ['done'], true) ? 'done' : 'pay', 'log' => wp_json_encode($log, JSON_UNESCAPED_UNICODE), 'updated_at' => idev_emr_now()], ['id' => $id]);
    return $bill;
}
/* A visit is done when its bill is fully paid. */
add_action('idev_store_bill_paid', function ($bill_id) { idev_emr_mark_paid($bill_id); });
function idev_emr_mark_paid($bill_id) {
    global $wpdb;
    $id = (int) $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . idev_emr_t('visits') . " WHERE bill_id = %d AND status = 'pay'", $bill_id));
    if ($id) idev_emr_visit_save($id, ['status' => 'done'], __('Paid', 'idev-clinic-emr'));
}

/* ---------- Follow-up appointment ---------- */

/** Books the follow-up in iDev Appointments (when installed). Returns appointment id or WP_Error. */
function idev_emr_book_followup($visit_id) {
    $v = idev_emr_visit($visit_id);
    $f = $v['d']['followup'] ?? [];
    if (empty($f['date']) || empty($f['time']) || empty($f['provider'])) return new WP_Error('followup', __('Choose the doctor / clinic, date and time.', 'idev-clinic-emr'));
    if (!function_exists('idev_appt_create')) return new WP_Error('appt', __('The appointments module is not active.', 'idev-clinic-emr'));
    $p = idev_store_customer($v['customer_id']);
    $hn = (string) $p['hn'];
    $patient = ['verified' => true, 'hn' => $hn, 'reg_ref' => '', 'name' => $p['name'], 'email' => $p['email'], 'phone' => $p['phone'], 'dob' => (string) $p['birthdate'], 'patient_key' => $hn !== '' ? idev_appt_hash('HN|' . strtoupper($hn)) : idev_appt_hash('C|' . $p['id'])];
    $r = idev_appt_create(['provider' => $f['provider'], 'date' => $f['date'], 'start' => $f['time'], 'patient' => $patient, 'name' => $p['name'], 'phone' => $p['phone'], 'email' => $p['email'], 'reason' => $f['note'] ?: __('Follow-up', 'idev-clinic-emr'), 'lang' => 'th', 'source' => 'staff'], true);
    if (is_wp_error($r)) return $r;
    idev_emr_visit_save($visit_id, ['followup' => ['appt_id' => $r[0]]], sprintf(__('Follow-up booked: %s', 'idev-clinic-emr'), idev_format_day($f['date']) . ' ' . $f['time']));
    return $r[0];
}

/* ---------- Today's appointments (check-in) ---------- */

function idev_emr_today_appts() {
    global $wpdb;
    if (!function_exists('idev_appt_table')) return [];
    $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . idev_appt_table() . " WHERE appt_date = %s AND status IN ('pending','confirmed') ORDER BY start_time", idev_today()), ARRAY_A);
    $out = [];
    foreach ($rows as $r) {
        $a = idev_appt_hydrate($r);
        $prov = get_the_title((int) $a['provider_id']);
        $out[] = ['id' => (int) $a['id'], 'time' => $a['start_time'], 'name' => $a['p']['name'] ?? '', 'hn' => $a['p']['hn'] ?? '', 'phone' => $a['p']['phone'] ?? '', 'dob' => $a['p']['dob'] ?? '', 'email' => $a['p']['email'] ?? '', 'reason' => $a['p']['reason'] ?? '', 'provider' => $prov, 'status' => $a['status']];
    }
    return $out;
}
/** Check-in: finds the patient by HN or phone (or creates one) and opens the visit. */
function idev_emr_checkin_appt($appt_id) {
    global $wpdb;
    foreach (idev_emr_today_appts() as $a) {
        if ($a['id'] !== (int) $appt_id) continue;
        $t = idev_store_t('customers');
        $cid = 0;
        if ($a['hn'] !== '') $cid = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE hn = %s LIMIT 1", $a['hn']));
        if (!$cid && $a['phone'] !== '') $cid = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE phone = %s AND name = %s LIMIT 1", idev_store_phone($a['phone']), $a['name']));
        if (!$cid) { $cid = idev_emr_patient_save(['name' => $a['name'] ?: __('Patient', 'idev-clinic-emr'), 'phone' => $a['phone'], 'email' => $a['email'], 'hn' => $a['hn'], 'birthdate' => $a['dob']]); if (is_wp_error($cid)) return $cid; }
        return idev_emr_visit_create(['customer_id' => $cid, 'appt_id' => $a['id'], 'cc' => $a['reason']]);
    }
    return new WP_Error('appt', __('Appointment not found.', 'idev-clinic-emr'));
}
