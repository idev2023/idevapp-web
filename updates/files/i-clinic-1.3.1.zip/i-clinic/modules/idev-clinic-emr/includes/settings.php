<?php
/** Settings: general, doctors (names and licence numbers), print design. */
defined('ABSPATH') || exit;

add_action('admin_post_idev_emr_settings', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idev_emr_settings')) wp_die('Forbidden', 403);
    $tab = sanitize_key($_POST['tab'] ?? 'general');
    if ($tab === 'doctors') {
        foreach ((array) ($_POST['doc'] ?? []) as $uid => $x) {
            $uid = (int) $uid;
            if (!$uid || !user_can($uid, 'idev_emr_doctor')) continue;
            update_user_meta($uid, 'idev_emr_title_name', sanitize_text_field(wp_unslash($x['name'] ?? '')));
            update_user_meta($uid, 'idev_emr_license', sanitize_text_field(wp_unslash($x['license'] ?? '')));
        }
        $add = (int) ($_POST['add_user'] ?? 0);
        $role = sanitize_key($_POST['add_role'] ?? '');
        if ($add && in_array($role, ['idev_emr_doctor', 'idev_emr_nurse'], true) && ($u = get_userdata($add)) && !in_array('administrator', $u->roles, true)) $u->add_role($role);
    } else {
        $d = idev_emr_defaults();
        $in = wp_unslash($_POST['s'] ?? []);
        $s = idev_emr_settings();
        $s['hn_mode'] = ($in['hn_mode'] ?? '') === 'running' ? 'running' : 'year';
        $s['hn_prefix'] = preg_replace('/[^A-Za-z0-9-]/', '', (string) ($in['hn_prefix'] ?? ''));
        $s['clinic_license'] = sanitize_text_field($in['clinic_license'] ?? '');
        $s['consult_item'] = (int) ($in['consult_item'] ?? 0);
        $s['queue_screen'] = !empty($in['queue_screen']) ? '1' : '0';
        $s['show_price_on_opd'] = !empty($in['show_price_on_opd']) ? '1' : '0';
        $s['cert_text'] = sanitize_text_field($in['cert_text'] ?? '') ?: $d['cert_text'];
        $s['cert_rest_text'] = sanitize_text_field($in['cert_rest_text'] ?? '') ?: $d['cert_rest_text'];
        $s['opd_paper'] = isset(idev_emr_papers()[$in['opd_paper'] ?? '']) ? $in['opd_paper'] : 'a5';
        $s['cert_paper'] = isset(idev_emr_papers()[$in['cert_paper'] ?? '']) ? $in['cert_paper'] : 'a4';
        $s['icd_custom'] = sanitize_textarea_field($in['icd_custom'] ?? '');
        update_option('idev_emr_settings', $s, false);
        $GLOBALS['idev_emr_flush'] = true;
    }
    wp_safe_redirect(add_query_arg(['saved' => 1], idev_emr_url('idev-emr-settings', ['tab' => $tab])));
    exit;
});

function idev_emr_page_settings() {
    $tab = sanitize_key($_GET['tab'] ?? 'general'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    idev_emr_head(__('Examination room settings', 'idev-clinic-emr'), '', 'idev-emr-settings');
    if (isset($_GET['saved'])) echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Saved.', 'idev-clinic-emr') . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $tabs = ['general' => __('General', 'idev-clinic-emr'), 'doctors' => __('Doctors and staff', 'idev-clinic-emr'), 'print' => __('Print design', 'idev-clinic-emr')];
    echo '<div class="emr-subtabs">';
    foreach ($tabs as $k => $l) echo '<a class="' . ($k === $tab ? 'on' : '') . '" href="' . esc_url(idev_emr_url('idev-emr-settings', ['tab' => $k])) . '">' . esc_html($l) . '</a>';
    echo '</div>';
    if ($tab === 'print') { idev_doc_designer_ui('emr', idev_emr_url('idev-emr-settings', ['tab' => 'print'])); idev_page_close(); return; }
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('idev_emr_settings');
    echo '<input type="hidden" name="action" value="idev_emr_settings"><input type="hidden" name="tab" value="' . esc_attr($tab) . '">';
    if ($tab === 'doctors') idev_emr_settings_doctors(); else idev_emr_settings_general();
    echo '<p><button class="button button-primary button-hero">' . esc_html__('Save', 'idev-clinic-emr') . '</button></p></form>';
    idev_page_close();
}

function idev_emr_settings_general() {
    $s = idev_emr_settings();
    $services = function_exists('idev_store_items') ? idev_store_items(['kind' => 'service', 'limit' => 200]) : [];
    echo '<div class="idev-card"><h2>' . esc_html__('Patients and queue', 'idev-clinic-emr') . '</h2><table class="form-table">';
    echo '<tr><th>' . esc_html__('HN numbers', 'idev-clinic-emr') . '</th><td><label><input type="radio" name="s[hn_mode]" value="year"' . checked($s['hn_mode'], 'year', false) . '> ' . esc_html__('By year: 69-00001 (Thai year, starts again every year)', 'idev-clinic-emr') . '</label><br><label><input type="radio" name="s[hn_mode]" value="running"' . checked($s['hn_mode'], 'running', false) . '> ' . esc_html__('Running number: 000001', 'idev-clinic-emr') . '</label><p><input type="text" name="s[hn_prefix]" value="' . esc_attr($s['hn_prefix']) . '" size="6" placeholder="' . esc_attr__('prefix', 'idev-clinic-emr') . '"> <span class="description">' . esc_html__('Optional, e.g. "K" → K69-00001. Patients who already have an HN keep it.', 'idev-clinic-emr') . '</span></p></td></tr>';
    echo '<tr><th>' . esc_html__('Screening step', 'idev-clinic-emr') . '</th><td><label><input type="checkbox" name="s[queue_screen]" value="1"' . checked($s['queue_screen'], '1', false) . '> ' . esc_html__('New patients in the queue go to screening (vital signs) first', 'idev-clinic-emr') . '</label><p class="description">' . esc_html__('Untick for small clinics where the doctor does everything: patients go straight to "Waiting for doctor".', 'idev-clinic-emr') . '</p></td></tr>';
    echo '<tr><th>' . esc_html__('Consultation fee', 'idev-clinic-emr') . '</th><td><select name="s[consult_item]"><option value="0">' . esc_html__('— none —', 'idev-clinic-emr') . '</option>';
    foreach ($services as $it) echo '<option value="' . (int) $it['id'] . '"' . selected($s['consult_item'], $it['id'], false) . '>' . esc_html($it['name'] . ' (' . idev_store_money($it['price']) . ')') . '</option>';
    echo '</select><p class="description">' . esc_html__('Added to every bill from the examination room. Make it under Stock → New item, type "Service".', 'idev-clinic-emr') . '</p></td></tr>';
    echo '<tr><th>' . esc_html__('Clinic licence no.', 'idev-clinic-emr') . '</th><td><input type="text" name="s[clinic_license]" value="' . esc_attr($s['clinic_license']) . '" class="regular-text"><p class="description">' . esc_html__('Printed under the clinic name on certificates and visit summaries.', 'idev-clinic-emr') . '</p></td></tr></table></div>';
    echo '<div class="idev-card"><h2>' . esc_html__('Documents', 'idev-clinic-emr') . '</h2><table class="form-table">';
    $paper = function ($k) use ($s) { $o = '<select name="s[' . $k . ']">'; foreach (idev_emr_papers() as $p => $l) $o .= '<option value="' . $p . '"' . selected($s[$k], $p, false) . '>' . $l . '</option>'; return $o . '</select>'; };
    echo '<tr><th>' . esc_html__('Paper', 'idev-clinic-emr') . '</th><td>' . esc_html__('Medical certificate', 'idev-clinic-emr') . ' ' . $paper('cert_paper') . ' &nbsp; ' . esc_html__('Visit summary', 'idev-clinic-emr') . ' ' . $paper('opd_paper') . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<tr><th>' . esc_html__('Certificate text', 'idev-clinic-emr') . '</th><td><input type="text" name="s[cert_text]" value="' . esc_attr($s['cert_text']) . '" class="large-text"><p><input type="text" name="s[cert_rest_text]" value="' . esc_attr($s['cert_rest_text']) . '" class="large-text"></p><p class="description">' . esc_html__('Second line is used when the doctor gives rest days: {days} {from} {to}.', 'idev-clinic-emr') . '</p></td></tr>';
    echo '<tr><th>' . esc_html__('Prices on the visit summary', 'idev-clinic-emr') . '</th><td><label><input type="checkbox" name="s[show_price_on_opd]" value="1"' . checked($s['show_price_on_opd'], '1', false) . '> ' . esc_html__('Show the amount of each item', 'idev-clinic-emr') . '</label></td></tr></table></div>';
    echo '<div class="idev-card"><h2>' . esc_html__('Your own diagnosis codes', 'idev-clinic-emr') . '</h2><p class="description">' . esc_html(sprintf(__('About %d common ICD-10 codes are built in (Thai and English). Add your own, one per line: CODE | Thai name | English name', 'idev-clinic-emr'), count(idev_emr_icd_builtin()))) . '</p><textarea name="s[icd_custom]" rows="5" class="large-text code" placeholder="Z01.4 | ตรวจภายใน | Gynaecological examination">' . esc_textarea($s['icd_custom']) . '</textarea></div>';
}

function idev_emr_settings_doctors() {
    $docs = get_users(['capability' => 'idev_emr_doctor', 'orderby' => 'display_name']);
    $nurses = get_users(['role' => 'idev_emr_nurse', 'orderby' => 'display_name']);
    echo '<div class="idev-card"><h2>' . esc_html__('Doctors', 'idev-clinic-emr') . '</h2><p class="description">' . esc_html__('The name and licence number are printed on medical certificates and visit summaries.', 'idev-clinic-emr') . '</p><table class="widefat striped"><thead><tr><th>' . esc_html__('User', 'idev-clinic-emr') . '</th><th>' . esc_html__('Name on documents', 'idev-clinic-emr') . '</th><th>' . esc_html__('Medical licence no.', 'idev-clinic-emr') . '</th></tr></thead><tbody>';
    foreach ($docs as $u) echo '<tr><td>' . esc_html($u->display_name) . ' <small>(' . esc_html($u->user_login) . ')</small></td><td><input type="text" name="doc[' . (int) $u->ID . '][name]" value="' . esc_attr(get_user_meta($u->ID, 'idev_emr_title_name', true)) . '" placeholder="' . esc_attr__('e.g. นพ. สมชาย ใจดี', 'idev-clinic-emr') . '" class="regular-text"></td><td><input type="text" name="doc[' . (int) $u->ID . '][license]" value="' . esc_attr(get_user_meta($u->ID, 'idev_emr_license', true)) . '" placeholder="ว.12345"></td></tr>';
    echo '</tbody></table></div><div class="idev-card"><h2>' . esc_html__('Nurses and staff', 'idev-clinic-emr') . '</h2><p>' . esc_html($nurses ? implode(', ', wp_list_pluck($nurses, 'display_name')) : '—') . '</p>';
    echo '<h3>' . esc_html__('Give a user access', 'idev-clinic-emr') . '</h3><p>';
    wp_dropdown_users(['name' => 'add_user', 'show_option_none' => __('— user —', 'idev-clinic-emr'), 'option_none_value' => 0]);
    echo ' <select name="add_role"><option value="idev_emr_doctor">' . esc_html__('Clinic doctor', 'idev-clinic-emr') . '</option><option value="idev_emr_nurse">' . esc_html__('Clinic nurse / staff', 'idev-clinic-emr') . '</option></select></p>';
    echo '<p class="description">' . sprintf(esc_html__('New staff: %s first, then give access here. Doctors can examine, diagnose and prescribe; nurses / staff can add patients to the queue, screen and take payments.', 'idev-clinic-emr'), '<a href="' . esc_url(admin_url('user-new.php')) . '">' . esc_html__('add a user', 'idev-clinic-emr') . '</a>') . '</p></div>';
}
