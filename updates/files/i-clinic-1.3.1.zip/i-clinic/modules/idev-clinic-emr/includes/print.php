<?php
/** Printouts: visit summary (OPD card) and medical certificate, with the shared document designer (3 templates). */
defined('ABSPATH') || exit;

function idev_emr_print_url($type, $id, $paper = '') {
    return add_query_arg(array_filter(['action' => 'idev_emr_print', 'type' => $type, 'id' => $id, 'paper' => $paper, '_wpnonce' => wp_create_nonce('idev_emr_print_' . $type . $id)]), admin_url('admin-post.php'));
}
function idev_emr_papers() { return ['a4' => 'A4', 'a5' => 'A5']; }
function idev_emr_doc_design() { return function_exists('idev_doc_design') ? idev_doc_design('idev_emr_doc_design') : []; }
function idev_emr_org() {
    $s = function_exists('idev_store_settings') ? idev_store_settings() : [];
    $e = idev_emr_settings();
    $line = $e['clinic_license'] !== '' ? __('Licence no.', 'idev-clinic-emr') . ' ' . $e['clinic_license'] : '';
    return ['name' => $s['shop_name'] ?? get_bloginfo('name'), 'address' => $s['address'] ?? '', 'phone' => $s['phone'] ?? '', 'tax_id' => '', 'logo' => $s['logo'] ?? '', 'line' => $line];
}
function idev_emr_trial() { return function_exists('idev_store_licensed') && !idev_store_licensed(); }

add_action('admin_post_idev_emr_print', function () {
    $type = sanitize_key($_GET['type'] ?? '');
    $id = (int) ($_GET['id'] ?? 0);
    if (!idev_emr_can() || !wp_verify_nonce($_GET['_wpnonce'] ?? '', 'idev_emr_print_' . $type . $id)) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-clinic-emr'), 403);
    $v = idev_emr_visit($id);
    $c = $v ? idev_emr_patient($v['customer_id']) : null;
    if (!$c) wp_die('Not found', 404);
    $s = idev_emr_settings();
    $paper = sanitize_key($_GET['paper'] ?? '') ?: ($type === 'cert' ? $s['cert_paper'] : $s['opd_paper']);
    if (!isset(idev_emr_papers()[$paper])) $paper = 'a4';
    $papers = [];
    foreach (idev_emr_papers() as $k => $l) $papers[$l] = idev_emr_print_url($type, $id, $k);
    nocache_headers();
    echo idev_emr_doc($type, $v, $c, idev_emr_doc_design(), $paper, $papers); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- full HTML page, escaped inside
    exit;
});

function idev_emr_doc($type, $v, $c, $design, $paper, $papers = [], $preview = false) {
    if ($type === 'cert') return idev_emr_cert_page($v, $c, $design, $paper, $papers, $preview);
    $body = $type === 'cert' ? idev_emr_doc_cert($v, $c) : idev_emr_doc_opd($v, $c);
    $title = $type === 'cert' ? __('Medical certificate', 'idev-clinic-emr') : __('Visit summary', 'idev-clinic-emr');
    $css = '<style>.emrd-grid{display:grid;grid-template-columns:repeat(4,auto);gap:2px 14px;margin:6px 0 10px}.emrd-grid b{font-weight:normal;color:#555}.emrd-sec{margin:8px 0}.emrd-sec h3{margin:0 0 2px;font-size:1em;color:var(--dc,#000)}'
        . '.emrd-al{border:1.5px solid #b91c1c;color:#b91c1c;padding:4px 8px;font-weight:bold;margin:6px 0}.emrd-p{text-indent:2.5em;line-height:2;margin:6px 0}.emrd-line{border-bottom:1px dotted #000;padding:0 6px;font-weight:bold;white-space:nowrap}'
        . '.emrd-sign{margin:40px 0 0 auto;width:60%;text-align:center;line-height:1.9}.emrd-sign span{display:block;border-top:1px dotted #000;margin-top:34px}.emrd-no{text-align:right;font-size:.9em}.f-a5 .emrd-grid{grid-template-columns:repeat(2,auto)}</style>';
    return idev_doc_page(['title' => $title, 'body' => $css . $body, 'design' => $design, 'paper' => $paper, 'org' => idev_emr_org(), 'trial' => idev_emr_trial(), 'papers' => $papers, 'preview' => $preview]);
}

function idev_emr_doc_patient_grid($v, $c) {
    $p = $c['profile'];
    $rows = [
        __('Name', 'idev-clinic-emr') => $c['name'], 'HN' => $c['hn'],
        __('Age', 'idev-clinic-emr') => trim(($p['sex'] !== '' ? idev_emr_sexes()[$p['sex']] : '') . ' ' . idev_emr_age($c['birthdate'], $v['visit_date'])), __('Date', 'idev-clinic-emr') => idev_format_day($v['visit_date'], null, true),
        'VN' => $v['vn'], __('Phone', 'idev-clinic-emr') => $c['phone'],
    ];
    $o = '<div class="emrd-grid">';
    foreach ($rows as $k => $val) $o .= '<b>' . esc_html($k) . '</b><span>' . esc_html($val ?: '—') . '</span>';
    return $o . '</div>';
}

function idev_emr_doc_opd($v, $c) {
    $d = $v['d'];
    $p = $c['profile'];
    $o = idev_emr_doc_patient_grid($v, $c);
    $o .= $p['allergies'] ? '<div class="emrd-al">⚠ ' . esc_html__('Drug allergy:', 'idev-clinic-emr') . ' ' . esc_html(implode(', ', array_map(function ($a) { return $a['drug'] . ($a['reaction'] ? ' (' . $a['reaction'] . ')' : ''); }, $p['allergies']))) . '</div>' : '';
    $sec = function ($t, $text) { return $text !== '' ? '<div class="emrd-sec"><h3>' . esc_html($t) . '</h3>' . nl2br(esc_html($text)) . '</div>' : ''; };
    $o .= $sec(__('Vital signs', 'idev-clinic-emr'), idev_emr_vitals_text($d['vitals']));
    $o .= $sec(__('Chief complaint (CC)', 'idev-clinic-emr'), $d['cc']) . $sec(__('Present illness (PI)', 'idev-clinic-emr'), $d['pi']) . $sec(__('Past history / current medicines', 'idev-clinic-emr'), $d['pmh']) . $sec(__('Physical examination (PE)', 'idev-clinic-emr'), $d['pe']);
    $o .= $sec(__('Diagnosis', 'idev-clinic-emr'), implode("\n", array_map(function ($x) { return trim($x['code'] . ' ' . $x['name']); }, $d['dx'])));
    $o .= $sec(__('Treatment / procedures', 'idev-clinic-emr'), $d['procedures']);
    if ($v['o']) {
        $price = idev_emr_settings()['show_price_on_opd'] === '1';
        $o .= '<div class="emrd-sec"><h3>' . esc_html__('Medicines and services', 'idev-clinic-emr') . '</h3><table><thead><tr><th>' . esc_html__('Item', 'idev-clinic-emr') . '</th><th>' . esc_html__('Directions', 'idev-clinic-emr') . '</th><th class="r">' . esc_html__('Qty', 'idev-clinic-emr') . '</th>' . ($price ? '<th class="r">' . esc_html__('Amount', 'idev-clinic-emr') . '</th>' : '') . '</tr></thead><tbody>';
        foreach ($v['o'] as $x) $o .= '<tr><td>' . esc_html($x['name']) . '</td><td>' . esc_html($x['use']) . '</td><td class="r">' . esc_html(idev_store_qty($x['qty']) . ($x['unit'] ? ' ' . $x['unit'] : '')) . '</td>' . ($price ? '<td class="r">' . esc_html(number_format($x['qty'] * $x['price'], 2)) . '</td>' : '') . '</tr>';
        $o .= '</tbody></table></div>';
    }
    $o .= $sec(__('Advice', 'idev-clinic-emr'), $d['advice']);
    if (!empty($d['followup']['date'])) $o .= $sec(__('Next appointment', 'idev-clinic-emr'), idev_format_day($d['followup']['date'], null, true) . (!empty($d['followup']['time']) ? ' ' . $d['followup']['time'] : '') . (!empty($d['followup']['note']) ? ' — ' . $d['followup']['note'] : ''));
    $doc = idev_emr_doctor($v['doctor_id']);
    $o .= '<div class="emrd-sign"><span></span>(' . esc_html($doc['name'] ?: '..............................') . ')<br>' . esc_html__('Doctor', 'idev-clinic-emr') . ($doc['license'] ? ' · ' . esc_html__('Licence no.', 'idev-clinic-emr') . ' ' . esc_html($doc['license']) : '') . '</div>';
    return $o;
}

/** "วันที่ 29 เดือน ตุลาคม พ.ศ. 2569" / "29 October 2026". */
function idev_emr_formal_date($date) {
    if (!idev_is_valid_date((string) $date)) return '';
    $lang = idev_lang();
    [$y, $m, $d] = array_map('intval', explode('-', $date));
    return sprintf(__('day %1$d month %2$s year %3$d', 'idev-clinic-emr'), $d, idev_months($lang, true)[$m - 1], $lang === 'en' ? $y : $y + 543);
}
function idev_emr_cert_types() { return ['sick' => __('Medical certificate (illness / sick leave)', 'idev-clinic-emr'), 'health' => __('Health certificate (standard 2-part form)', 'idev-clinic-emr')]; }
function idev_emr_cert_data($v) {
    $c = array_merge(['type' => '', 'days' => 0, 'from' => $v['visit_date'], 'opinion' => '', 'purpose' => '', 'fit' => 0, 'h_acc' => '', 'h_hosp' => '', 'h_epi' => '', 'h_other' => '', 'general' => 'normal', 'general_note' => '', 'other_disease' => ''], $v['d']['cert'] ?: []);
    if (!isset(idev_emr_cert_types()[$c['type']])) $c['type'] = $c['fit'] ? 'health' : 'sick';
    return $c;
}

/** Filled-in dotted line. */
function idev_emr_dots($t, $min = 24) { return '<span class="fl">' . ($t !== '' && $t !== null ? esc_html($t) : str_repeat('&nbsp;', $min)) . '</span>'; }
function idev_emr_box($on) { return '<span class="bx">' . ($on ? '✓' : '') . '</span>'; }

/** Medical certificate: formal page (own layout, A4 / A5). */
function idev_emr_cert_page($v, $c, $design, $paper, $papers = [], $preview = false) {
    $cert = idev_emr_cert_data($v);
    $doc = idev_emr_doctor($v['doctor_id']);
    $org = idev_emr_org();
    $p = $c['profile'];
    $d = $v['d'];
    $D = 'idev_emr_dots';
    $color = sanitize_hex_color($design['color'] ?? '') ?: '#0f766e';
    $logo = ($design['show_logo'] ?? '1') === '1' ? (($design['logo'] ?? '') ?: ($org['logo'] ?? '')) : '';
    $idno = $p['id_no'] !== '' ? $p['id_no'] : '';
    $age = idev_emr_age($c['birthdate'], $v['visit_date']);
    $head = '<header class="ch">' . ($logo ? '<img src="' . esc_url($logo) . '" alt="">' : '') . '<div class="org"><b>' . esc_html($org['name']) . '</b><span>' . nl2br(esc_html(trim($org['address']))) . '</span><span>' . esc_html(implode(' · ', array_filter([$org['phone'] ? __('Tel.', 'idev-clinic-emr') . ' ' . $org['phone'] : '', $org['line']]))) . '</span></div></header>';
    $body = '';
    if ($cert['type'] === 'health') {
        $chronic = trim(preg_replace('/\s*\n\s*/', ', ', $p['chronic']));
        $hist = function ($n, $label, $text) use ($D) { return '<p class="hl">' . $n . '. ' . esc_html($label) . ' &nbsp; ' . idev_emr_box($text === '') . ' ' . esc_html__('No', 'idev-clinic-emr') . ' &nbsp; ' . idev_emr_box($text !== '') . ' ' . esc_html__('Yes (specify)', 'idev-clinic-emr') . ' ' . $D($text, 30) . '</p>'; };
        $body .= '<h1>' . esc_html__('MEDICAL CERTIFICATE', 'idev-clinic-emr') . '</h1><div class="no">' . esc_html__('No.', 'idev-clinic-emr') . ' ' . esc_html($v['vn']) . '</div>';
        $body .= '<section class="part"><h2>' . esc_html__('Part 1: for the person requesting the certificate', 'idev-clinic-emr') . '</h2>';
        $body .= '<p>' . sprintf(esc_html__('I, %1$s, address %2$s, ID card no. %3$s, request a health certificate with the following health history:', 'idev-clinic-emr'), $D($c['name'], 30), $D(preg_replace('/\s*\n\s*/', ' ', $c['data']['address'] ?? ''), 40), $D($idno, 20)) . '</p>';
        $body .= $hist(1, __('Underlying disease', 'idev-clinic-emr'), $chronic) . $hist(2, __('Accident and surgery', 'idev-clinic-emr'), $cert['h_acc']) . $hist(3, __('Admitted to hospital', 'idev-clinic-emr'), $cert['h_hosp']) . $hist(4, __('Epilepsy', 'idev-clinic-emr'), $cert['h_epi']);
        $body .= '<p class="hl">5. ' . esc_html__('Other important history', 'idev-clinic-emr') . ' ' . $D($cert['h_other'], 40) . '</p>';
        $body .= '<div class="sg sm"><span class="ln"></span>' . esc_html__('Signature of the person requesting', 'idev-clinic-emr') . '<br>' . esc_html(idev_emr_formal_date($v['visit_date'])) . '</div></section>';
        $vit = $d['vitals'];
        $body .= '<section class="part"><h2>' . esc_html__('Part 2: for the doctor', 'idev-clinic-emr') . '</h2>';
        $body .= '<p>' . esc_html__('Place of examination', 'idev-clinic-emr') . ' ' . $D($org['name'], 30) . ' ' . esc_html(idev_emr_formal_date($v['visit_date'])) . '</p>';
        $body .= '<p class="ind">' . sprintf(esc_html__('(1) I, %1$s, medical licence no. %2$s, of %3$s, have examined %4$s on %5$s, with these details: weight %6$s kg, height %7$s cm, blood pressure %8$s mmHg, pulse %9$s /min.', 'idev-clinic-emr'),
            $D($doc['name'], 26), $D($doc['license'], 10), $D($org['name'], 26), $D($c['name'], 26), $D(idev_emr_formal_date($v['visit_date']), 20), $D((string) ($vit['weight'] ?? ''), 6), $D((string) ($vit['height'] ?? ''), 6), $D(isset($vit['sbp']) ? $vit['sbp'] . '/' . ($vit['dbp'] ?? '') : '', 8), $D((string) ($vit['pulse'] ?? ''), 5)) . '</p>';
        $body .= '<p class="hl">' . esc_html__('General condition:', 'idev-clinic-emr') . ' &nbsp; ' . idev_emr_box($cert['general'] === 'normal') . ' ' . esc_html__('Normal', 'idev-clinic-emr') . ' &nbsp; ' . idev_emr_box($cert['general'] === 'abnormal') . ' ' . esc_html__('Abnormal (specify)', 'idev-clinic-emr') . ' ' . $D($cert['general'] === 'abnormal' ? $cert['general_note'] : '', 30) . '</p>';
        $body .= '<p class="ind">' . esc_html__('I certify that this person is not disabled to the point of being unable to work, shows no signs of psychosis, mental disorder or intellectual disability, no signs of drug addiction or chronic alcoholism, and no signs or symptoms of the following diseases:', 'idev-clinic-emr') . '</p><ol class="dz"><li>' . esc_html__('Leprosy in the infectious stage or with symptoms repugnant to society', 'idev-clinic-emr') . '</li><li>' . esc_html__('Tuberculosis in the dangerous stage', 'idev-clinic-emr') . '</li><li>' . esc_html__('Elephantiasis with symptoms repugnant to society', 'idev-clinic-emr') . '</li><li>' . esc_html__('Others (if any)', 'idev-clinic-emr') . ' ' . $D($cert['other_disease'], 30) . '</li></ol>';
        $body .= '<p class="hl">' . esc_html__('(2) Doctor\'s conclusion and advice', 'idev-clinic-emr') . ' ' . $D($cert['opinion'], 50) . '</p>';
        $body .= idev_emr_cert_sign($doc) . '<div class="note"><b>' . esc_html__('Notes', 'idev-clinic-emr') . '</b> ' . esc_html__('(1) Must be a doctor registered with a licence to practise medicine. (2) This certificate is valid for one month from the date of examination. (3) This certificate is a preliminary examination; part 1 is filled in by the person requesting it.', 'idev-clinic-emr') . '</div>';
    } else {
        $dx = implode(', ', array_map(function ($x) { return $x['name'] ?: $x['code']; }, $d['dx']));
        $s = idev_emr_settings();
        $body .= '<h1>' . esc_html__('MEDICAL CERTIFICATE', 'idev-clinic-emr') . '</h1>';
        $body .= '<div class="meta"><div>' . esc_html__('No.', 'idev-clinic-emr') . ' ' . $D($v['vn'], 12) . '</div><div>' . esc_html__('Place of examination', 'idev-clinic-emr') . ' ' . $D($org['name'], 20) . '</div><div>' . esc_html(idev_emr_formal_date($v['visit_date'])) . '</div></div>';
        $body .= '<p class="ind">' . sprintf(esc_html__('I, %1$s, licensed medical practitioner no. %2$s, working at %3$s, have examined %4$s, ID card / passport no. %5$s, age %6$s, HN %7$s, on %8$s.', 'idev-clinic-emr'),
            $D($doc['name'], 26), $D($doc['license'], 10), $D($org['name'], 26), $D($c['name'], 26), $D($idno, 20), $D($age, 8), $D($c['hn'], 10), $D(idev_emr_formal_date($v['visit_date']), 20)) . '</p>';
        $body .= '<p class="ind">' . esc_html__('Examination result / diagnosis:', 'idev-clinic-emr') . ' ' . $D($dx !== '' ? $dx : $s['cert_text'], 50) . '</p>';
        $op = trim($cert['opinion']);
        if ($cert['days'] > 0) {
            $from = $cert['from'] ?: $v['visit_date'];
            $op = trim($op . ' ' . strtr($s['cert_rest_text'], ['{days}' => (string) $cert['days'], '{from}' => idev_format_day($from, null, false, true), '{to}' => idev_format_day(idev_add_days($from, $cert['days'] - 1), null, false, true)]));
        }
        $body .= '<p class="ind">' . esc_html__('Doctor\'s opinion:', 'idev-clinic-emr') . ' ' . $D($op, 60) . '</p>';
        if ($cert['purpose'] !== '') $body .= '<p class="ind">' . esc_html__('This certificate is issued for:', 'idev-clinic-emr') . ' ' . $D($cert['purpose'], 30) . '</p>';
        $body .= idev_emr_cert_sign($doc) . '<div class="note">' . esc_html__('This certificate covers the examination on the date above only. Without the doctor\'s signature and the clinic stamp it is not valid.', 'idev-clinic-emr') . '</div>';
    }
    $sizes = ['a4' => ['A4', '210mm', '297mm', '16px'], 'a5' => ['A5', '148mm', '210mm', '12.5px']][$paper] ?? ['A4', '210mm', '297mm', '16px'];
    $bar = '';
    if (!$preview) { foreach ($papers as $l => $u) $bar .= '<a href="' . esc_url($u) . '">' . esc_html($l) . '</a>'; $bar = '<div class="bar">' . $bar . '<button onclick="window.print()">🖨 ' . esc_html__('Print', 'idev-clinic-emr') . '</button></div>'; }
    $trial = idev_emr_trial() ? '<div class="trial">TRIAL</div>' : '';
    return '<!doctype html><html lang="' . esc_attr(idev_lang()) . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . esc_html__('Medical certificate', 'idev-clinic-emr') . ' ' . esc_html($v['vn']) . '</title>'
        . '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;600;700&display=swap" rel="stylesheet"><style>'
        . '@page{size:' . $sizes[0] . ';margin:0}*{box-sizing:border-box}body{margin:0;background:#e9edf0;color:#111;font-family:Sarabun,"TH Sarabun New","Leelawadee UI",Tahoma,sans-serif}'
        . '.bar{position:sticky;top:0;z-index:3;display:flex;gap:6px;justify-content:center;padding:10px;background:#1d2327}.bar a,.bar button{font:13px Tahoma,sans-serif;color:#fff;background:#3c434a;border:0;border-radius:6px;padding:7px 12px;text-decoration:none;cursor:pointer}.bar button{background:#00a32a;font-weight:bold}'
        . '.pg{width:' . $sizes[1] . ';min-height:' . $sizes[2] . ';margin:16px auto;background:#fff;padding:9mm;box-shadow:0 2px 14px rgba(0,0,0,.15);font-size:' . $sizes[3] . ';line-height:1.75;position:relative}'
        . '.fr{border:2.5px double ' . $color . ';min-height:calc(' . $sizes[2] . ' - 18mm);padding:7mm 9mm;position:relative}'
        . '.ch{display:flex;flex-direction:column;align-items:center;text-align:center;gap:2px;padding-bottom:3mm;border-bottom:1px solid ' . $color . '}.ch img{max-height:20mm;max-width:45mm;margin-bottom:2px}.ch .org{display:flex;flex-direction:column;align-items:center}.ch b{font-size:1.25em;color:' . $color . '}.ch span{font-size:.86em;line-height:1.4;color:#333}'
        . 'h1{text-align:center;font-size:1.65em;letter-spacing:.06em;margin:5mm 0 2mm}h2{font-size:1.02em;margin:3mm 0 1mm;padding:1px 8px;border-left:4px solid ' . $color . ';background:#f5f7f8}'
        . '.no{text-align:right;font-size:.9em}.meta{display:flex;flex-direction:column;align-items:flex-end;margin:0 0 3mm}.ind{text-indent:2.5em;margin:1.5mm 0}.hl{margin:1mm 0}.fl{border-bottom:1px dotted #000;padding:0 .4em;font-weight:600}'
        . '.bx{display:inline-block;width:.95em;height:.95em;border:1px solid #000;text-align:center;line-height:.9em;font-weight:700;vertical-align:-.1em}.dz{margin:0 0 1mm 3em;padding:0}.dz li{margin:0}'
        . '.sg{display:grid;grid-template-columns:32mm 1fr;gap:6mm;align-items:end;margin-top:9mm}.stamp{border:1px dashed #999;height:30mm;display:flex;align-items:center;justify-content:center;text-align:center;color:#999;font-size:.75em;border-radius:50%}'
        . '.sign{text-align:center;line-height:1.6}.sign .ln{display:inline-block;border-bottom:1px dotted #000;width:62%;height:8mm;vertical-align:bottom;margin-left:2mm}.sg.sm{display:block;text-align:right;margin-top:3mm}.sg.sm .ln{display:inline-block;width:55mm;border-bottom:1px dotted #000;height:7mm}'
        . '.note{margin-top:6mm;font-size:.78em;color:#444;border-top:1px solid #ddd;padding-top:2mm;line-height:1.5}.part{margin-bottom:2mm}'
        . '.trial{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:bold 110px sans-serif;color:rgba(0,0,0,.07);transform:rotate(-28deg);pointer-events:none}'
        . '@media print{body{background:#fff}.bar{display:none}.pg{margin:0;box-shadow:none}}'
        . '</style></head><body>' . $bar . '<div class="pg"><div class="fr">' . $trial . $head . $body . '</div></div>' . ($preview ? '' : '<script>if(location.hash==="#print")addEventListener("load",function(){setTimeout(print,500)})</script>') . '</body></html>';
}
function idev_emr_cert_sign($doc) {
    return '<div class="sg"><div class="stamp">' . esc_html__('Clinic stamp', 'idev-clinic-emr') . '</div><div class="sign"><div>' . esc_html__('Signed', 'idev-clinic-emr') . '<span class="ln"></span></div>(' . ($doc['name'] !== '' ? esc_html($doc['name']) : str_repeat('&nbsp;', 40)) . ')<br>' . esc_html__('Examining doctor', 'idev-clinic-emr') . '<br>' . esc_html__('Medical licence no.', 'idev-clinic-emr') . ' ' . idev_emr_dots($doc['license'], 12) . '</div></div>';
}

/* Designer: Print design → Examination room (same three templates as receipts). */
add_action('init', function () {
    if (!function_exists('idev_register_doc_designer')) return;
    idev_register_doc_designer('emr', [
        'option' => 'idev_emr_doc_design', 'docs' => ['cert' => __('Medical certificate', 'idev-clinic-emr'), 'health' => __('Health certificate (2 parts)', 'idev-clinic-emr'), 'opd' => __('Visit summary', 'idev-clinic-emr')], 'papers' => idev_emr_papers(),
        'preview' => function ($doc, $design, $paper) { [$v, $c] = idev_emr_doc_sample(); if ($doc === 'health') $v['d']['cert']['type'] = 'health'; return idev_emr_doc($doc === 'opd' ? 'opd' : 'cert', $v, $c, $design, isset(idev_emr_papers()[$paper]) ? $paper : 'a4', [], true); },
    ]);
}, 30);
/** Sample visit for the designer (fictional data). */
function idev_emr_doc_sample() {
    $today = idev_today();
    $v = ['id' => 0, 'vn' => 'VN' . wp_date('ym') . '-0012', 'customer_id' => 0, 'visit_date' => $today, 'queue_no' => 3, 'status' => 'done', 'doctor_id' => get_current_user_id(), 'bill_id' => 0, 'log' => [],
        'd' => ['vitals' => ['weight' => 62, 'height' => 165, 'temp' => 38.2, 'sbp' => 122, 'dbp' => 78, 'pulse' => 96, 'rr' => 20, 'spo2' => 98], 'cc' => 'ไข้ เจ็บคอ 2 วัน', 'pi' => 'ไข้ต่ำ ๆ เจ็บคอเวลากลืน ไม่ไอ ไม่มีน้ำมูก', 'pmh' => '', 'pe' => 'Pharynx injected, tonsils 1+ no exudate, lungs clear', 'dx' => [['code' => 'J02.9', 'name' => 'คออักเสบเฉียบพลัน', 'type' => 'principal']],
            'plan' => '', 'advice' => 'ดื่มน้ำมาก ๆ พักผ่อน หากไข้ไม่ลดใน 3 วันให้กลับมาพบแพทย์', 'note' => '', 'nurse_note' => '', 'procedures' => '', 'followup' => ['date' => idev_add_days($today, 7), 'time' => '10:00', 'note' => 'ติดตามอาการ'], 'cert' => ['type' => 'sick', 'days' => 2, 'from' => $today, 'opinion' => '', 'purpose' => 'ลาป่วย', 'fit' => 0]],
        'o' => [['item_id' => 0, 'name' => 'Paracetamol 500 mg', 'qty' => 20, 'unit' => 'เม็ด', 'price' => 1, 'use' => 'รับประทานครั้งละ 1 เม็ด ทุก 4–6 ชั่วโมง เวลามีไข้', 'ind' => '', 'warn' => '', 'kind' => 'product'], ['item_id' => 0, 'name' => 'Chlorpheniramine 4 mg', 'qty' => 10, 'unit' => 'เม็ด', 'price' => 1, 'use' => 'รับประทานครั้งละ 1 เม็ด วันละ 3 ครั้ง หลังอาหาร', 'ind' => '', 'warn' => '', 'kind' => 'product']]];
    $c = ['id' => 0, 'name' => 'นางสาวสมใจ ใจดี', 'hn' => '69-00012', 'phone' => '0812345678', 'birthdate' => (string) ((int) wp_date('Y') - 29) . '-04-12', 'email' => '', 'data' => [],
        'profile' => ['sex' => 'f', 'id_no' => '1234567890123', 'blood' => 'O', 'chronic' => '', 'allergies' => [['drug' => 'Penicillin', 'reaction' => 'ผื่นลมพิษ', 'severity' => 'moderate', 'certainty' => 'certain']], 'no_allergy' => '', 'alert' => '', 'emergency' => '', 'rights' => '', 'note' => '']];
    return [$v, $c];
}
