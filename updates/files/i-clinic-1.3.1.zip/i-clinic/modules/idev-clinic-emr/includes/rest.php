<?php
/** REST idev-emr/v1 for the examination screens (staff only). */
defined('ABSPATH') || exit;

function idev_emr_public_patient($c) {
    $p = idev_emr_profile($c['id']);
    return ['id' => $c['id'], 'hn' => $c['hn'], 'name' => $c['name'], 'phone' => $c['phone'], 'age' => idev_emr_age($c['birthdate']), 'sex' => $p['sex'],
        'allergy' => implode(', ', array_column($p['allergies'], 'drug')), 'url' => idev_emr_url('idev-emr-patients', ['id' => $c['id']])];
}

add_action('rest_api_init', function () {
    $ns = 'idev-emr/v1';
    $staff = function () { return idev_emr_can(); };
    register_rest_route($ns, '/patients', ['methods' => 'GET', 'permission_callback' => $staff, 'callback' => function (WP_REST_Request $r) {
        return array_map('idev_emr_public_patient', idev_emr_patient_find((string) $r->get_param('q'), 12));
    }]);
    register_rest_route($ns, '/icd', ['methods' => 'GET', 'permission_callback' => $staff, 'callback' => function (WP_REST_Request $r) {
        return idev_emr_icd_search((string) $r->get_param('q'), 15);
    }]);
    register_rest_route($ns, '/slots', ['methods' => 'GET', 'permission_callback' => $staff, 'callback' => function (WP_REST_Request $r) {
        if (!function_exists('idev_appt_provider')) return [];
        $p = idev_appt_provider((int) $r->get_param('provider'));
        $date = (string) $r->get_param('date');
        if (!$p || !idev_is_valid_date($date)) return [];
        return array_values(array_map(function ($s) { return ['time' => $s['start'], 'left' => $s['left'], 'past' => $s['past']]; }, idev_appt_slots($p, $date, true)));
    }]);
});
