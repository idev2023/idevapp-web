<?php
/**
 * Tables, roles, settings, patient profile (allergies, chronic diseases) and helpers.
 * Patients are the customers of the shop module (one list for the clinic): name, phone, HN stay searchable;
 * everything clinical is encrypted with the key shared by the iDev patient plugins.
 */
defined('ABSPATH') || exit;

function idev_emr_t($name) { global $wpdb; return $wpdb->prefix . 'idev_emr_' . $name; }
function idev_emr_ready() { return function_exists('idev_store_customer') && function_exists('idev_store_json_enc'); }

function idev_emr_install() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $c = $wpdb->get_charset_collate();
    dbDelta('CREATE TABLE ' . idev_emr_t('profiles') . " (
  customer_id bigint(20) unsigned NOT NULL,
  sex char(1) NOT NULL DEFAULT '',
  data longtext NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (customer_id)
) $c;");
    dbDelta('CREATE TABLE ' . idev_emr_t('visits') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  vn varchar(32) NOT NULL,
  customer_id bigint(20) unsigned NOT NULL,
  visit_date date NOT NULL,
  queue_no int(10) unsigned NOT NULL DEFAULT 0,
  status varchar(12) NOT NULL DEFAULT 'waiting',
  doctor_id bigint(20) unsigned NOT NULL DEFAULT 0,
  appt_id bigint(20) unsigned NOT NULL DEFAULT 0,
  bill_id bigint(20) unsigned NOT NULL DEFAULT 0,
  data longtext NOT NULL,
  orders longtext NOT NULL,
  log longtext NOT NULL,
  created_by bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  done_at datetime DEFAULT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY vn (vn),
  KEY customer_id (customer_id),
  KEY visit_date (visit_date, status),
  KEY doctor_id (doctor_id)
) $c;");
    if (!get_role('idev_emr_doctor')) add_role('idev_emr_doctor', __('Clinic doctor', 'idev-clinic-emr'), ['read' => true, 'idev_emr' => true, 'idev_emr_doctor' => true, 'idev_store' => true]);
    if (!get_role('idev_emr_nurse')) add_role('idev_emr_nurse', __('Clinic nurse / staff', 'idev-clinic-emr'), ['read' => true, 'idev_emr' => true, 'idev_store' => true]);
    foreach (['administrator'] as $r) { $role = get_role($r); if ($role) { $role->add_cap('idev_emr'); $role->add_cap('idev_emr_doctor'); $role->add_cap('idev_emr_manage'); } }
    update_option('idev_emr_db', IDEV_EMR_VERSION, false);
}
add_action('plugins_loaded', function () { if (get_option('idev_emr_db') !== IDEV_EMR_VERSION) idev_emr_install(); }, 20);

add_action('init', function () {
    load_plugin_textdomain('idev-clinic-emr', false, dirname(plugin_basename(IDEV_EMR_FILE)) . '/languages');
    if (function_exists('idev_register_plugin')) idev_register_plugin('idev-clinic-emr', ['name' => __('Clinic records', 'idev-clinic-emr'), 'version' => IDEV_EMR_VERSION, 'description' => __('Queue, examination notes, prescriptions, re-med, drug allergies and patient history.', 'idev-clinic-emr'), 'settings' => admin_url('admin.php?page=idev-emr-settings'), 'docs' => 'https://idevapp.me/#systems']);
});

/* ---------- Settings ---------- */

function idev_emr_defaults() {
    return [
        'hn_mode' => 'year', 'hn_prefix' => '', 'consult_item' => 0, 'clinic_license' => '', 'queue_screen' => '1',
        'cert_text' => 'ได้มาตรวจรักษาที่สถานพยาบาลแห่งนี้ จริง',
        'cert_rest_text' => 'สมควรพักรักษาตัวเป็นเวลา {days} วัน ตั้งแต่วันที่ {from} ถึงวันที่ {to}',
        'icd_custom' => '', 'opd_paper' => 'a5', 'cert_paper' => 'a4', 'show_price_on_opd' => '0',
    ];
}
function idev_emr_settings() {
    static $cache = null;
    if ($cache === null || !empty($GLOBALS['idev_emr_flush'])) { $s = get_option('idev_emr_settings', []); $cache = array_merge(idev_emr_defaults(), is_array($s) ? $s : []); $GLOBALS['idev_emr_flush'] = false; }
    return $cache;
}

/* ---------- Capabilities and helpers ---------- */

function idev_emr_can($what = 'staff') {
    if ($what === 'doctor') return current_user_can('idev_emr_doctor');
    if ($what === 'manage') return current_user_can('idev_emr_manage') || current_user_can('manage_options');
    return current_user_can('idev_emr');
}
function idev_emr_url($page, $args = []) { return add_query_arg($args, admin_url('admin.php?page=' . $page)); }
function idev_emr_now() { return current_time('mysql'); }
function idev_emr_enc($data) { return idev_store_json_enc($data); }
function idev_emr_dec($cipher) { return idev_store_json_dec($cipher); }
function idev_emr_num($v) { $v = str_replace(',', '.', trim((string) $v)); return is_numeric($v) ? round((float) $v, 2) : ''; }

/** Age as "34 ปี 2 เดือน" (years only from 6 years on). */
function idev_emr_age($birthdate, $on = '') {
    if (!$birthdate || !idev_is_valid_date($birthdate)) return '';
    try { $d = (new DateTime($birthdate))->diff(new DateTime($on ?: idev_today())); } catch (Exception $e) { return ''; }
    if ($d->invert) return '';
    if ($d->y >= 6) return sprintf(__('%d y', 'idev-clinic-emr'), $d->y);
    if ($d->y >= 1) return sprintf(__('%1$d y %2$d m', 'idev-clinic-emr'), $d->y, $d->m);
    return $d->m ? sprintf(__('%1$d m %2$d d', 'idev-clinic-emr'), $d->m, $d->d) : sprintf(__('%d d', 'idev-clinic-emr'), $d->d);
}
function idev_emr_sexes() { return ['' => '—', 'm' => __('Male', 'idev-clinic-emr'), 'f' => __('Female', 'idev-clinic-emr')]; }
function idev_emr_blood_groups() { return ['', 'A', 'B', 'AB', 'O']; }
function idev_emr_severities() { return ['mild' => __('Mild', 'idev-clinic-emr'), 'moderate' => __('Moderate', 'idev-clinic-emr'), 'severe' => __('Severe / anaphylaxis', 'idev-clinic-emr')]; }
function idev_emr_certainties() { return ['certain' => __('Certain', 'idev-clinic-emr'), 'probable' => __('Probable', 'idev-clinic-emr'), 'possible' => __('Possible / patient says', 'idev-clinic-emr')]; }

/** Name of the doctor for documents: WP display name + licence no. from the user profile. */
function idev_emr_doctor($user_id) {
    $u = $user_id ? get_userdata($user_id) : null;
    if (!$u) return ['id' => 0, 'name' => '', 'license' => ''];
    $name = trim((string) get_user_meta($u->ID, 'idev_emr_title_name', true)) ?: $u->display_name;
    return ['id' => $u->ID, 'name' => $name, 'license' => (string) get_user_meta($u->ID, 'idev_emr_license', true)];
}
/** Users who may examine. */
function idev_emr_doctors() {
    $out = [];
    foreach (get_users(['capability' => 'idev_emr_doctor', 'orderby' => 'display_name', 'fields' => ['ID']]) as $u) $out[(int) $u->ID] = idev_emr_doctor((int) $u->ID)['name'];
    return $out;
}

/* ---------- HN ---------- */

/** Next HN: year mode "69-00012" (Thai year, restarts every year) or running "000123", with an optional prefix. */
function idev_emr_next_hn() {
    global $wpdb;
    $s = idev_emr_settings();
    $year = (int) wp_date('Y') + 543;
    $key = $s['hn_mode'] === 'year' ? 'HN' . substr((string) $year, -2) : 'HN';
    $t = idev_store_t('counters');
    if (!$wpdb->query($wpdb->prepare("UPDATE $t SET n = n + 1 WHERE k = %s", $key))) {
        // first HN of the period: start after the highest number already used
        $wpdb->insert($t, ['k' => $key, 'n' => 1]);
    }
    for ($i = 0; $i < 50; $i++) {
        $n = (int) $wpdb->get_var($wpdb->prepare("SELECT n FROM $t WHERE k = %s", $key));
        $hn = $s['hn_prefix'] . ($s['hn_mode'] === 'year' ? substr((string) $year, -2) . '-' . str_pad((string) $n, 5, '0', STR_PAD_LEFT) : str_pad((string) $n, 6, '0', STR_PAD_LEFT));
        if (!$wpdb->get_var($wpdb->prepare('SELECT id FROM ' . idev_store_t('customers') . ' WHERE hn = %s', $hn))) return $hn;
        $wpdb->query($wpdb->prepare("UPDATE $t SET n = n + 1 WHERE k = %s", $key));
    }
    return $s['hn_prefix'] . wp_date('ymdHis');
}

/* ---------- Patient profile ---------- */

function idev_emr_profile($customer_id) {
    global $wpdb;
    $r = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_emr_t('profiles') . ' WHERE customer_id = %d', $customer_id), ARRAY_A);
    $d = $r ? idev_emr_dec($r['data']) : [];
    return array_merge(['sex' => $r['sex'] ?? '', 'id_no' => '', 'blood' => '', 'chronic' => '', 'allergies' => [], 'no_allergy' => '', 'alert' => '', 'emergency' => '', 'rights' => '', 'note' => ''], $d, ['sex' => $r['sex'] ?? '']);
}
function idev_emr_profile_save($customer_id, $p) {
    global $wpdb;
    $old = idev_emr_profile($customer_id);
    $data = [
        'id_no' => preg_replace('/[^0-9A-Za-z]/', '', (string) ($p['id_no'] ?? $old['id_no'])),
        'blood' => in_array($p['blood'] ?? '', idev_emr_blood_groups(), true) ? $p['blood'] : $old['blood'],
        'chronic' => sanitize_textarea_field($p['chronic'] ?? $old['chronic']),
        'alert' => sanitize_text_field($p['alert'] ?? $old['alert']),
        'emergency' => sanitize_text_field($p['emergency'] ?? $old['emergency']),
        'rights' => sanitize_text_field($p['rights'] ?? $old['rights']),
        'note' => sanitize_textarea_field($p['note'] ?? $old['note']),
        'no_allergy' => isset($p['allergies']) ? (!empty($p['no_allergy']) ? '1' : '') : $old['no_allergy'],
        'allergies' => isset($p['allergies']) ? idev_emr_allergies_clean($p['allergies']) : $old['allergies'],
    ];
    if ($data['allergies']) $data['no_allergy'] = '';
    $sex = isset($p['sex']) && isset(idev_emr_sexes()[$p['sex']]) ? $p['sex'] : $old['sex'];
    $wpdb->replace(idev_emr_t('profiles'), ['customer_id' => (int) $customer_id, 'sex' => $sex, 'data' => idev_emr_enc($data), 'updated_at' => idev_emr_now()]);
}
function idev_emr_allergies_clean($list) {
    $out = [];
    foreach ((array) $list as $a) {
        $drug = sanitize_text_field($a['drug'] ?? '');
        if ($drug === '') continue;
        $out[] = ['drug' => $drug, 'reaction' => sanitize_text_field($a['reaction'] ?? ''), 'severity' => isset(idev_emr_severities()[$a['severity'] ?? '']) ? $a['severity'] : 'moderate',
            'certainty' => isset(idev_emr_certainties()[$a['certainty'] ?? '']) ? $a['certainty'] : 'certain', 'date' => sanitize_text_field($a['date'] ?? '') ?: wp_date('Y-m-d')];
    }
    return $out;
}

/** Patient = shop customer + profile. */
function idev_emr_patient($id) {
    $c = idev_emr_ready() ? idev_store_customer((int) $id) : null;
    if (!$c) return null;
    $c['profile'] = idev_emr_profile($c['id']);
    $c['age'] = idev_emr_age($c['birthdate']);
    return $c;
}
/** Creates / updates a patient (customer + profile). Returns id or WP_Error. */
function idev_emr_patient_save($in, $id = 0) {
    $in = (array) $in;
    if (!$id && trim((string) ($in['hn'] ?? '')) === '') $in['hn'] = idev_emr_next_hn();
    if ($id && !isset($in['hn'])) $in['hn'] = idev_store_customer($id)['hn'] ?? '';
    $name = trim(implode(' ', array_filter([sanitize_text_field($in['prefix'] ?? ''), sanitize_text_field($in['first'] ?? ''), sanitize_text_field($in['last'] ?? '')])));
    if ($name !== '' && empty($in['name'])) $in['name'] = $name;
    $r = idev_store_customer_save($in, $id);
    if (is_wp_error($r)) return $r;
    idev_emr_profile_save($r, $in['profile'] ?? []);
    return $r;
}
function idev_emr_patient_find($q, $limit = 15) { return idev_emr_ready() ? idev_store_customers($q, $limit) : []; }

/** Allergy text matching: "penicillin" warns for "Amoxicillin"? No — only names that contain each other, plus a few known families. */
function idev_emr_allergy_families() {
    return [
        'penicillin' => ['penicillin', 'amoxicillin', 'ampicillin', 'cloxacillin', 'dicloxacillin', 'augmentin', 'amoxy', 'เพนนิซิลลิน', 'อะม็อกซี'],
        'sulfa' => ['sulfa', 'sulfamethoxazole', 'co-trimoxazole', 'bactrim', 'ซัลฟา'],
        'nsaid' => ['nsaid', 'ibuprofen', 'diclofenac', 'naproxen', 'mefenamic', 'piroxicam', 'meloxicam', 'aspirin', 'celecoxib', 'etoricoxib', 'indomethacin'],
        'cephalosporin' => ['cephalosporin', 'cephalexin', 'cefalexin', 'cefazolin', 'cefuroxime', 'cefixime', 'ceftriaxone', 'cefdinir', 'cefaclor'],
        'quinolone' => ['quinolone', 'ciprofloxacin', 'norfloxacin', 'ofloxacin', 'levofloxacin', 'moxifloxacin'],
        'macrolide' => ['macrolide', 'erythromycin', 'azithromycin', 'clarithromycin', 'roxithromycin'],
        'tetracycline' => ['tetracycline', 'doxycycline', 'minocycline'],
    ];
}
/** Allergies that match a drug: [allergy entries]. $names: item name, generic name … */
function idev_emr_allergy_hits($allergies, $names) {
    $hay = mb_strtolower(implode(' | ', array_filter((array) $names)));
    if ($hay === '') return [];
    $hits = [];
    foreach ((array) $allergies as $a) {
        $drug = mb_strtolower(trim($a['drug']));
        if ($drug === '' || mb_strlen($drug) < 3) continue;
        $words = [$drug];
        foreach (idev_emr_allergy_families() as $fam => $members) if (in_array($drug, $members, true) || strpos($drug, $fam) !== false) $words = array_merge($words, $members);
        foreach ($words as $w) if (mb_strlen($w) >= 4 && mb_strpos($hay, $w) !== false) { $hits[] = $a; break; }
    }
    return $hits;
}

/** Red allergy banner for screens. */
function idev_emr_allergy_banner($profile, $compact = false) {
    $al = $profile['allergies'] ?? [];
    if (!$al) return !empty($profile['no_allergy']) ? '<div class="emr-allergy none">' . idev_icon('shield') . esc_html__('No known drug allergy (NKDA)', 'idev-clinic-emr') . '</div>' : '<div class="emr-allergy unknown">' . esc_html__('Drug allergy: not asked yet', 'idev-clinic-emr') . '</div>';
    $sev = idev_emr_severities();
    $items = array_map(function ($a) use ($sev, $compact) { return '<b>' . esc_html($a['drug']) . '</b>' . (!$compact && $a['reaction'] ? ' — ' . esc_html($a['reaction']) : '') . (!$compact && $a['severity'] === 'severe' ? ' <em>' . esc_html($sev['severe']) . '</em>' : ''); }, $al);
    return '<div class="emr-allergy">⚠ ' . esc_html__('Drug allergy:', 'idev-clinic-emr') . ' ' . implode(', ', $items) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above
}
