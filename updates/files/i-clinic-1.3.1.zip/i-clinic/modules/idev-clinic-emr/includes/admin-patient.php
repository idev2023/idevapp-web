<?php
/** Patients: list, chart (profile, drug allergies, history with re-med, trends). */
defined('ABSPATH') || exit;

add_action('idev_emr_post_patient_save', function () {
    $id = (int) ($_POST['id'] ?? 0);
    $in = wp_unslash($_POST['p'] ?? []);
    $in['profile'] = wp_unslash($_POST['profile'] ?? []);
    $in['profile']['allergies'] = wp_unslash($_POST['allergies'] ?? []);
    $r = idev_emr_patient_save($in, $id);
    if (is_wp_error($r)) idev_emr_redirect(idev_emr_url('idev-emr-patients', ['id' => $id ?: 'new']), $r->get_error_message(), 'error');
    if (!empty($_POST['queue'])) {
        $v = idev_emr_visit_create(['customer_id' => $r]);
        if (!is_wp_error($v)) idev_emr_redirect(idev_emr_url('idev-emr'), sprintf(__('Patient saved and added to the queue: no. %d', 'idev-clinic-emr'), idev_emr_visit($v)['queue_no']));
    }
    idev_emr_redirect(idev_emr_url('idev-emr-patients', ['id' => $r]), __('Patient saved.', 'idev-clinic-emr'));
});
/* Re-med: today's visit with the medicines of an earlier visit. */
add_action('idev_emr_post_remed', function () {
    if (!idev_emr_can('doctor')) wp_die(esc_html__('Only a doctor can re-med.', 'idev-clinic-emr'), 403);
    $from = idev_emr_visit((int) $_POST['from']);
    if (!$from) idev_emr_redirect(idev_emr_url('idev-emr-patients'));
    $open = idev_emr_open_visit($from['customer_id']);
    if ($open && !idev_emr_billed($open)) {
        idev_emr_visit_save($open['id'], ['orders' => array_merge($open['o'], $from['o'])], sprintf(__('Re-med from %s', 'idev-clinic-emr'), $from['vn']));
        $id = $open['id'];
    } else {
        $id = idev_emr_visit_create(['customer_id' => $from['customer_id'], 'orders' => $from['o'], 'doctor_id' => get_current_user_id(), 'force' => (bool) $open, 'cc' => __('Re-med', 'idev-clinic-emr'), 'dx' => array_map(function ($d) { return ['code' => $d['code'], 'name' => $d['name']]; }, $from['d']['dx'])]);
        if (is_wp_error($id)) idev_emr_redirect(idev_emr_url('idev-emr-patients', ['id' => $from['customer_id']]), $id->get_error_message(), 'error');
    }
    idev_emr_redirect(idev_emr_url('idev-emr-visit', ['id' => $id]) . '#orders', sprintf(__('Medicines copied from %s. Check the doses and quantities, then save.', 'idev-clinic-emr'), $from['vn']));
});

function idev_emr_page_patients() {
    $id = $_GET['id'] ?? ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if ($id === 'new') { idev_emr_patient_form(null); return; }
    if ($id) { idev_emr_chart((int) $id); return; }
    $q = sanitize_text_field(wp_unslash($_GET['q'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $list = idev_emr_patient_find($q, 100);
    idev_emr_head(__('Patients', 'idev-clinic-emr'));
    echo '<div class="emr-top"><form class="emr-find static"><input type="hidden" name="page" value="idev-emr-patients">' . idev_icon('search') . '<input type="search" name="q" value="' . esc_attr($q) . '" placeholder="' . esc_attr__('HN, name or phone…', 'idev-clinic-emr') . '"></form><a class="button button-primary button-hero emr-newpt" href="' . esc_url(idev_emr_url('idev-emr-patients', ['id' => 'new'])) . '">＋ ' . esc_html__('New patient', 'idev-clinic-emr') . '</a></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div class="idev-card"><table class="widefat striped emr-table"><thead><tr><th>HN</th><th>' . esc_html__('Name', 'idev-clinic-emr') . '</th><th>' . esc_html__('Age', 'idev-clinic-emr') . '</th><th>' . esc_html__('Phone', 'idev-clinic-emr') . '</th><th>' . esc_html__('Last visit', 'idev-clinic-emr') . '</th><th></th></tr></thead><tbody>';
    global $wpdb;
    foreach ($list as $c) {
        $p = idev_emr_profile($c['id']);
        $last = $wpdb->get_var($wpdb->prepare('SELECT MAX(visit_date) FROM ' . idev_emr_t('visits') . " WHERE customer_id = %d AND status <> 'cancelled'", $c['id']));
        echo '<tr><td><b>' . esc_html($c['hn'] ?: '—') . '</b></td><td><a href="' . esc_url(idev_emr_url('idev-emr-patients', ['id' => $c['id']])) . '"><b>' . esc_html($c['name']) . '</b></a>' . ($p['allergies'] ? ' <span class="emr-tag red">⚠ ' . esc_html(implode(', ', array_column($p['allergies'], 'drug'))) . '</span>' : '') . '</td><td>' . esc_html(trim(($p['sex'] !== '' ? idev_emr_sexes()[$p['sex']] : '') . ' ' . idev_emr_age($c['birthdate'])) ?: '—') . '</td><td>' . esc_html($c['phone']) . '</td><td>' . esc_html($last ? idev_format_day($last) : '—') . '</td><td class="r">' . idev_emr_form('queue_add', 'class="emr-inline"') . '<input type="hidden" name="customer_id" value="' . (int) $c['id'] . '"><button class="button">' . esc_html__('Add to queue', 'idev-clinic-emr') . '</button></form></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
    if (!$list) echo '<tr><td colspan="6" class="emr-empty">' . esc_html__('No patients found.', 'idev-clinic-emr') . '</td></tr>';
    echo '</tbody></table></div>';
    idev_page_close();
}

/** Profile form (new patient or edit), with the allergy editor. */
function idev_emr_patient_form($c, $embedded = false) {
    $p = $c ? idev_emr_profile($c['id']) : idev_emr_profile(0);
    $v = $c ?: ['id' => 0, 'name' => '', 'phone' => '', 'email' => '', 'line_id' => '', 'hn' => '', 'birthdate' => '', 'data' => []];
    if (!$embedded) idev_emr_head($c ? $c['name'] : __('New patient', 'idev-clinic-emr'), $c ? 'HN ' . $c['hn'] : __('HN is given automatically; you can type your own.', 'idev-clinic-emr'), 'idev-emr-patients');
    $queue = !$c && !empty($_GET['queue']); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    echo idev_emr_form('patient_save', 'class="emr-pform"') . '<input type="hidden" name="id" value="' . (int) $v['id'] . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $f = function ($label, $name, $value, $type = 'text', $attrs = '') { return '<label class="emr-f"><span>' . esc_html($label) . '</span><input type="' . esc_attr($type) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '" ' . $attrs . '></label>'; };
    $sel = function ($label, $name, $opts, $value) { $o = '<label class="emr-f"><span>' . esc_html($label) . '</span><select name="' . esc_attr($name) . '">'; foreach ($opts as $k => $l) $o .= '<option value="' . esc_attr($k) . '"' . selected((string) $value, (string) $k, false) . '>' . esc_html($l) . '</option>'; return $o . '</select></label>'; };
    echo '<div class="idev-card"><h2>' . idev_icon('user') . esc_html__('Patient details', 'idev-clinic-emr') . '</h2><div class="emr-grid">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo $f(__('Full name', 'idev-clinic-emr'), 'p[name]', $v['name'], 'text', 'required class="wide"') . $f('HN', 'p[hn]', $v['hn'], 'text', 'placeholder="' . esc_attr__('automatic', 'idev-clinic-emr') . '"') // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        . $sel(__('Sex', 'idev-clinic-emr'), 'profile[sex]', idev_emr_sexes(), $p['sex']) . $f(__('Date of birth', 'idev-clinic-emr'), 'p[birthdate]', (string) $v['birthdate'], 'date')
        . $f(__('Phone', 'idev-clinic-emr'), 'p[phone]', $v['phone'], 'tel') . $f(__('ID card / passport no.', 'idev-clinic-emr'), 'profile[id_no]', $p['id_no'])
        . $f(__('E-mail', 'idev-clinic-emr'), 'p[email]', $v['email'], 'email') . $f('LINE ID', 'p[line_id]', $v['line_id'])
        . $sel(__('Blood group', 'idev-clinic-emr'), 'profile[blood]', array_combine(idev_emr_blood_groups(), array_map(function ($b) { return $b ?: '—'; }, idev_emr_blood_groups())), $p['blood'])
        . $f(__('Health cover / rights', 'idev-clinic-emr'), 'profile[rights]', $p['rights'], 'text', 'placeholder="' . esc_attr__('e.g. self-pay, social security, insurance', 'idev-clinic-emr') . '"')
        . $f(__('Emergency contact', 'idev-clinic-emr'), 'profile[emergency]', $p['emergency'], 'text', 'class="wide" placeholder="' . esc_attr__('name, relation, phone', 'idev-clinic-emr') . '"');
    echo '<label class="emr-f wide"><span>' . esc_html__('Address', 'idev-clinic-emr') . '</span><textarea name="p[address]" rows="2">' . esc_textarea($v['data']['address'] ?? '') . '</textarea></label>';
    echo '<label class="emr-f wide"><span>' . esc_html__('Underlying diseases', 'idev-clinic-emr') . '</span><textarea name="profile[chronic]" rows="2" placeholder="' . esc_attr__('e.g. hypertension, diabetes', 'idev-clinic-emr') . '">' . esc_textarea($p['chronic']) . '</textarea></label>';
    echo '<label class="emr-f wide"><span>' . esc_html__('Alert for staff (shown on every screen)', 'idev-clinic-emr') . '</span><input type="text" name="profile[alert]" value="' . esc_attr($p['alert']) . '" placeholder="' . esc_attr__('e.g. G6PD deficiency, pregnant, pacemaker', 'idev-clinic-emr') . '"></label>';
    echo '</div></div>';
    // Allergies
    echo '<div class="idev-card emr-alcard"><h2>⚠ ' . esc_html__('Drug allergies', 'idev-clinic-emr') . '</h2><table class="widefat emr-altable"><thead><tr><th>' . esc_html__('Drug / group', 'idev-clinic-emr') . '</th><th>' . esc_html__('Reaction', 'idev-clinic-emr') . '</th><th>' . esc_html__('Severity', 'idev-clinic-emr') . '</th><th>' . esc_html__('Certainty', 'idev-clinic-emr') . '</th><th></th></tr></thead><tbody>';
    $rows = $p['allergies'] ?: [];
    $rows[] = ['drug' => '', 'reaction' => '', 'severity' => 'moderate', 'certainty' => 'certain'];
    foreach ($rows as $i => $a) {
        echo '<tr><td><input type="text" name="allergies[' . $i . '][drug]" value="' . esc_attr($a['drug']) . '" placeholder="' . esc_attr__('e.g. Penicillin, Sulfa, Ibuprofen', 'idev-clinic-emr') . '"></td><td><input type="text" name="allergies[' . $i . '][reaction]" value="' . esc_attr($a['reaction']) . '" placeholder="' . esc_attr__('e.g. rash, swollen eyes, breathless', 'idev-clinic-emr') . '"></td><td><select name="allergies[' . $i . '][severity]">';
        foreach (idev_emr_severities() as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($a['severity'], $k, false) . '>' . esc_html($l) . '</option>';
        echo '</select></td><td><select name="allergies[' . $i . '][certainty]">';
        foreach (idev_emr_certainties() as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($a['certainty'], $k, false) . '>' . esc_html($l) . '</option>';
        echo '</select><input type="hidden" name="allergies[' . $i . '][date]" value="' . esc_attr($a['date'] ?? '') . '"></td><td><button type="button" class="button-link emr-alx" title="' . esc_attr__('Remove', 'idev-clinic-emr') . '">✕</button></td></tr>';
    }
    echo '</tbody></table><p><button type="button" class="button emr-aladd">＋ ' . esc_html__('Add allergy', 'idev-clinic-emr') . '</button> <label class="emr-nkda"><input type="checkbox" name="profile[no_allergy]" value="1"' . checked($p['no_allergy'], '1', false) . '> ' . esc_html__('Asked: no known drug allergy (NKDA)', 'idev-clinic-emr') . '</label></p>';
    echo '<p class="description">' . esc_html__('When a doctor orders a drug whose name matches an allergy (also common groups such as penicillins, sulfa, NSAIDs, cephalosporins), the system warns and asks to confirm.', 'idev-clinic-emr') . '</p></div>';
    echo '<div class="emr-bar"><button class="button button-primary button-hero">' . esc_html__('Save', 'idev-clinic-emr') . '</button>';
    if (!$c) echo ' <label><input type="checkbox" name="queue" value="1"' . checked($queue, true, false) . '> ' . esc_html__('Add to today\'s queue', 'idev-clinic-emr') . '</label>';
    echo '</div></form>';
    if (!$embedded) idev_page_close();
}

/** Patient chart. */
function idev_emr_chart($id) {
    $c = idev_emr_patient($id);
    if (!$c) { idev_emr_head(__('Patients', 'idev-clinic-emr')); echo '<p>' . esc_html__('Patient not found.', 'idev-clinic-emr') . '</p>'; idev_page_close(); return; }
    $p = $c['profile'];
    $edit = !empty($_GET['edit']); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    idev_emr_head($c['name'], 'HN ' . ($c['hn'] ?: '—'), 'idev-emr-patients');
    if ($edit) { idev_emr_patient_form($c, true); idev_page_close(); return; }
    $visits = idev_emr_visits(['customer_id' => $id, 'not_cancelled' => true, 'limit' => 200]);
    $open = idev_emr_open_visit($id);
    // Summary header
    $sex = $p['sex'] !== '' ? (idev_emr_sexes()[$p['sex']] ?? '') : '';
    echo '<div class="emr-ptop"><div class="emr-avatar">' . esc_html(mb_substr($c['name'], 0, 1)) . '</div><div class="emr-pinfo"><h2>' . esc_html($c['name']) . '</h2><div class="emr-chips">';
    foreach (array_filter(['HN ' . ($c['hn'] ?: '—'), trim($sex . ' ' . $c['age']), $c['birthdate'] ? idev_format_day($c['birthdate']) : '', $p['blood'] ? __('Blood', 'idev-clinic-emr') . ' ' . $p['blood'] : '', $c['phone'], $p['rights']]) as $chip) echo '<span>' . esc_html($chip) . '</span>';
    echo '</div></div><div class="emr-pacts">';
    if ($open) echo '<a class="button button-primary button-hero" href="' . esc_url(idev_emr_url('idev-emr-visit', ['id' => $open['id']])) . '">' . esc_html(sprintf(__('Open today\'s visit (queue %d)', 'idev-clinic-emr'), $open['queue_no'])) . '</a>';
    else echo idev_emr_form('queue_add', 'class="emr-inline"') . '<input type="hidden" name="customer_id" value="' . (int) $id . '"><button class="button button-primary button-hero">＋ ' . esc_html__('Add to today\'s queue', 'idev-clinic-emr') . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<a class="button button-hero" href="' . esc_url(idev_emr_url('idev-emr-patients', ['id' => $id, 'edit' => 1])) . '">' . esc_html__('Edit details', 'idev-clinic-emr') . '</a></div></div>';
    echo idev_emr_allergy_banner($p); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if ($p['alert']) echo '<div class="emr-alert">' . idev_icon('bell') . esc_html($p['alert']) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div class="emr-cols"><div class="emr-main"><div class="idev-card"><h2>' . idev_icon('list') . esc_html__('Treatment history', 'idev-clinic-emr') . ' <small>' . esc_html(sprintf(_n('%d visit', '%d visits', count($visits), 'idev-clinic-emr'), count($visits))) . '</small></h2>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if (!$visits) echo '<p class="emr-empty">' . esc_html__('No visits yet.', 'idev-clinic-emr') . '</p>';
    foreach ($visits as $v) idev_emr_history_item($v);
    echo '</div></div><aside class="emr-side">';
    echo '<div class="idev-card"><h3>' . esc_html__('Underlying diseases', 'idev-clinic-emr') . '</h3><p>' . nl2br(esc_html($p['chronic'] ?: '—')) . '</p>';
    if ($p['emergency']) echo '<h3>' . esc_html__('Emergency contact', 'idev-clinic-emr') . '</h3><p>' . esc_html($p['emergency']) . '</p>';
    if (!empty($c['data']['address'])) echo '<h3>' . esc_html__('Address', 'idev-clinic-emr') . '</h3><p>' . nl2br(esc_html($c['data']['address'])) . '</p>';
    echo '</div>';
    echo idev_emr_trend_card($visits); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if (function_exists('idev_store_bills')) {
        echo '<div class="idev-card"><h3>' . esc_html__('Bills', 'idev-clinic-emr') . '</h3><table class="widefat striped"><tbody>';
        $bills = idev_store_bills(['customer_id' => $id, 'limit' => 10]);
        foreach ($bills as $b) echo '<tr><td><a href="' . esc_url(idev_store_url('idev-store-bills', ['id' => $b['id']])) . '">' . esc_html($b['no']) . '</a></td><td>' . esc_html(idev_format_day(substr($b['created_at'], 0, 10))) . '</td><td class="r">' . esc_html(idev_store_money($b['total'], false)) . '</td></tr>';
        if (!$bills) echo '<tr><td>—</td></tr>';
        echo '</tbody></table></div>';
    }
    echo '</aside></div>';
    idev_page_close();
}

/** One visit in the history: date, doctor, diagnosis, vital signs, medicines, re-med. */
function idev_emr_history_item($v, $compact = false) {
    $d = $v['d'];
    $doc = $v['doctor_id'] ? idev_emr_doctor($v['doctor_id'])['name'] : '';
    echo '<div class="emr-hist"><div class="emr-hdate"><b>' . esc_html(idev_format_day($v['visit_date'])) . '</b><small>' . esc_html($v['vn']) . '</small></div><div class="emr-hbody">';
    echo '<div class="emr-hhead">' . ($d['dx'] ? implode('', array_map(function ($x) { return '<span class="emr-dx">' . ($x['code'] ? '<code>' . esc_html($x['code']) . '</code> ' : '') . esc_html($x['name']) . '</span>'; }, $d['dx'])) : '<span class="emr-muted">' . esc_html__('No diagnosis', 'idev-clinic-emr') . '</span>') . ($doc ? '<small>' . esc_html($doc) . '</small>' : '') . '</div>';
    if ($d['cc']) echo '<p><b>CC:</b> ' . esc_html($d['cc']) . '</p>';
    $vit = idev_emr_vitals_text($d['vitals']);
    if ($vit) echo '<p class="emr-vline">' . esc_html($vit) . '</p>';
    if (!$compact && $d['pe']) echo '<p><b>PE:</b> ' . nl2br(esc_html($d['pe'])) . '</p>';
    if ($v['o']) {
        echo '<ul class="emr-meds">';
        foreach ($v['o'] as $o) echo '<li><b>' . esc_html($o['name']) . '</b> × ' . esc_html(idev_store_qty($o['qty']) . ($o['unit'] ? ' ' . $o['unit'] : '')) . ($o['use'] ? '<small>' . esc_html($o['use']) . '</small>' : '') . '</li>';
        echo '</ul>';
    }
    if (!$compact && $d['advice']) echo '<p><b>' . esc_html__('Advice', 'idev-clinic-emr') . ':</b> ' . nl2br(esc_html($d['advice'])) . '</p>';
    echo '<div class="emr-hacts"><a class="button button-small" href="' . esc_url(idev_emr_url('idev-emr-visit', ['id' => $v['id']])) . '">' . esc_html__('Open', 'idev-clinic-emr') . '</a>';
    if ($v['o'] && idev_emr_can('doctor')) echo idev_emr_form('remed', 'class="emr-inline"') . '<input type="hidden" name="from" value="' . (int) $v['id'] . '"><button class="button button-small button-primary">↻ ' . esc_html__('Re-med', 'idev-clinic-emr') . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<a class="button button-small" target="_blank" href="' . esc_url(idev_emr_print_url('opd', $v['id'])) . '">' . esc_html__('Print', 'idev-clinic-emr') . '</a></div></div></div>';
}
function idev_emr_vitals_text($vit) {
    if (!$vit) return '';
    $o = [];
    if (isset($vit['weight'])) $o[] = 'BW ' . $vit['weight'] . ' kg';
    if (isset($vit['height'])) $o[] = 'Ht ' . $vit['height'] . ' cm';
    if ($bmi = idev_emr_bmi($vit)) $o[] = 'BMI ' . $bmi;
    if (isset($vit['temp'])) $o[] = 'T ' . $vit['temp'] . '°C';
    if (isset($vit['sbp'])) $o[] = 'BP ' . $vit['sbp'] . '/' . ($vit['dbp'] ?? '-');
    if (isset($vit['pulse'])) $o[] = 'P ' . $vit['pulse'];
    if (isset($vit['rr'])) $o[] = 'RR ' . $vit['rr'];
    if (isset($vit['spo2'])) $o[] = 'SpO₂ ' . $vit['spo2'] . '%';
    if (isset($vit['dtx'])) $o[] = 'DTX ' . $vit['dtx'];
    if (isset($vit['pain'])) $o[] = 'Pain ' . $vit['pain'] . '/10';
    return implode(' · ', $o);
}

/** Small charts of weight and blood pressure over the visits (SVG, no library). */
function idev_emr_trend_card($visits) {
    $pts = array_reverse(array_values(array_filter(array_map(function ($v) { return ['d' => $v['visit_date'], 'w' => $v['d']['vitals']['weight'] ?? null, 's' => $v['d']['vitals']['sbp'] ?? null, 'di' => $v['d']['vitals']['dbp'] ?? null]; }, $visits), function ($x) { return $x['w'] !== null || $x['s'] !== null; })));
    $pts = array_slice($pts, -12);
    if (count($pts) < 2) return '';
    $chart = function ($series, $colors, $label, $unit) use ($pts) {
        $vals = array_filter(array_merge(...array_map(function ($k) use ($pts) { return array_column($pts, $k); }, $series)), function ($x) { return $x !== null; });
        if (count($vals) < 2) return '';
        $min = floor(min($vals) * 0.95); $max = ceil(max($vals) * 1.05); if ($max <= $min) $max = $min + 1;
        $W = 280; $H = 90; $n = count($pts);
        $x = function ($i) use ($W, $n) { return round(8 + $i * ($W - 16) / max(1, $n - 1), 1); };
        $y = function ($v) use ($H, $min, $max) { return round($H - 8 - ($v - $min) * ($H - 16) / ($max - $min), 1); };
        $svg = '<svg viewBox="0 0 ' . $W . ' ' . $H . '" class="emr-spark" role="img" aria-label="' . esc_attr($label) . '">';
        foreach ($series as $si => $k) {
            $line = []; $dots = '';
            foreach ($pts as $i => $p) if ($p[$k] !== null) { $line[] = $x($i) . ',' . $y($p[$k]); $dots .= '<circle cx="' . $x($i) . '" cy="' . $y($p[$k]) . '" r="3" fill="' . $colors[$si] . '"><title>' . esc_html(idev_format_day($p['d']) . ': ' . $p[$k] . ' ' . $unit) . '</title></circle>'; }
            $svg .= '<polyline fill="none" stroke="' . $colors[$si] . '" stroke-width="2" points="' . implode(' ', $line) . '"/>' . $dots;
        }
        $last = end($pts);
        $now = implode('/', array_filter(array_map(function ($k) use ($last) { return $last[$k]; }, $series), function ($x) { return $x !== null; }));
        return '<div class="emr-trend"><div><b>' . esc_html($label) . '</b><span>' . esc_html($now . ' ' . $unit) . '</span></div>' . $svg . '</svg></div>';
    };
    return '<div class="idev-card"><h3>' . esc_html__('Trends', 'idev-clinic-emr') . '</h3>' . $chart(['w'], ['#0f766e'], __('Weight', 'idev-clinic-emr'), 'kg') . $chart(['s', 'di'], ['#c2410c', '#2563eb'], __('Blood pressure', 'idev-clinic-emr'), 'mmHg') . '</div>';
}
