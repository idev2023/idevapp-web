<?php
/** Doctor portal (front-end page) and the Appointments screen in the back office — the same app. */
defined('ABSPATH') || exit;

add_action('admin_menu', function () {
    global $wpdb;
    $cap = current_user_can('idev_appt_manage') ? 'idev_appt_manage' : 'idev_appt_doctor';
    $n = 0;
    $mine = current_user_can('idev_appt_manage') || current_user_can('idev_appt_doctor') ? idev_appt_user_providers() : [];
    if ($mine) $n = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . idev_appt_table() . " WHERE status='pending' AND appt_date >= %s AND provider_id IN (" . implode(',', array_map('intval', $mine)) . ')', idev_today()));
    add_menu_page(__('Appointments', 'idev-appointments'), __('Appointments', 'idev-appointments') . ($n ? ' <span class="awaiting-mod">' . $n . '</span>' : ''), $cap, 'idev-appt', function () {
        echo '<div class="wrap idev-wrap">';
        idev_admin_header(__('Appointments', 'idev-appointments'));
        echo idev_appt_portal_app(true) . '</div>';
    }, 'dashicons-calendar-alt', 5);
});

add_action('init', function () {
    wp_register_style('idev-appt-portal', IDEV_APPT_URL . 'assets/portal.css', [], IDEV_APPT_VERSION);
    wp_register_script('idev-appt-portal', IDEV_APPT_URL . 'assets/portal.js', ['wp-api-fetch'], IDEV_APPT_VERSION, true);
    idev_register_block('idev/doctor-portal', __('Doctor portal', 'idev-appointments'), 'id', __('Doctors sign in to see, confirm and move their appointments.', 'idev-appointments'), [], function () { return idev_appt_portal_app(false); });
});
add_shortcode('idev_doctor_portal', function () { return idev_appt_portal_app(false); });

function idev_appt_portal_strings() {
    return [
        'today' => __('Today', 'idev-appointments'), 'day' => __('Day', 'idev-appointments'), 'week' => __('Week', 'idev-appointments'), 'pending' => __('Waiting for confirmation', 'idev-appointments'),
        'allProviders' => __('All doctors and clinics', 'idev-appointments'), 'search' => __('Search name, HN, phone', 'idev-appointments'), 'empty' => __('No appointments.', 'idev-appointments'),
        'confirm' => __('Confirm', 'idev-appointments'), 'move' => __('Move', 'idev-appointments'), 'cancel' => __('Cancel', 'idev-appointments'), 'done' => __('Came', 'idev-appointments'), 'noShow' => __('Did not come', 'idev-appointments'),
        'undo' => __('Back to confirmed', 'idev-appointments'), 'reason' => __('Reason (sent to the patient)', 'idev-appointments'), 'note' => __('Add note', 'idev-appointments'), 'save' => __('Save', 'idev-appointments'), 'close' => __('Close', 'idev-appointments'),
        'newAppt' => __('New appointment', 'idev-appointments'), 'provider' => __('Doctor / clinic', 'idev-appointments'), 'date' => __('Date', 'idev-appointments'), 'time' => __('Time', 'idev-appointments'),
        'name' => __('Patient name', 'idev-appointments'), 'hn' => __('HN', 'idev-appointments'), 'phone' => __('Phone', 'idev-appointments'), 'email' => __('E-mail', 'idev-appointments'), 'dob' => __('Date of birth', 'idev-appointments'),
        'reasonVisit' => __('Reason for the visit', 'idev-appointments'), 'create' => __('Create appointment', 'idev-appointments'), 'full' => __('full', 'idev-appointments'), 'left' => __('%d left', 'idev-appointments'),
        'overbook' => __('Full slots can still be chosen by staff.', 'idev-appointments'), 'chooseTime' => __('Choose a new time', 'idev-appointments'), 'unverified' => __('HN not checked', 'idev-appointments'),
        'newReg' => __('New patient (registered online)', 'idev-appointments'), 'history' => __('History', 'idev-appointments'), 'error' => __('Something went wrong. Please try again.', 'idev-appointments'),
        'confirmAll' => __('Confirm all on this list', 'idev-appointments'), 'sure' => __('Are you sure?', 'idev-appointments'), 'print' => __('Print', 'idev-appointments'), 'byStaff' => __('booked by staff', 'idev-appointments'),
        'noTimes' => __('No clinic times on this day.', 'idev-appointments'), 'statuses' => idev_appt_statuses(),
    ];
}

function idev_appt_portal_app($admin) {
    if (!is_user_logged_in()) {
        return '<div class="idev-portal-login"><h2>' . esc_html__('Doctor portal', 'idev-appointments') . '</h2><p>' . esc_html__('Please sign in to see your appointments.', 'idev-appointments') . '</p>' . wp_login_form(['echo' => false, 'redirect' => get_permalink() ?: home_url('/')]) . '</div>';
    }
    if (!current_user_can('idev_appt_manage') && !current_user_can('idev_appt_doctor')) return '<p>' . esc_html__('Your account is not linked to a doctor or clinic. Please contact the administrator.', 'idev-appointments') . '</p>';
    if (!idev_appt_user_providers()) return '<p>' . esc_html__('No doctor or clinic is linked to your account yet. The administrator can link it on the doctor\'s edit page (Online booking → Doctor\'s login).', 'idev-appointments') . '</p>';
    wp_enqueue_style('idev-appt-portal');
    wp_enqueue_script('idev-appt-portal');
    $cfg = ['lang' => idev_lang(), 'staff' => current_user_can('idev_appt_manage'), 'admin' => $admin, 'today' => idev_today(), 'user' => wp_get_current_user()->display_name, 'logout' => wp_logout_url(get_permalink() ?: home_url('/')),
        'weekdays' => idev_weekdays_short(idev_lang()), 'months' => idev_months(idev_lang()), 't' => idev_appt_portal_strings(), 'accent' => idev_appt_settings()['accent']];
    wp_add_inline_script('idev-appt-portal', 'window.wpApiSettings = window.wpApiSettings || ' . wp_json_encode(['root' => esc_url_raw(rest_url()), 'nonce' => wp_create_nonce('wp_rest')]) . ';', 'before');
    return '<div class="idev-portal' . ($admin ? ' is-admin' : '') . '" style="--idev-appt:' . esc_attr($cfg['accent']) . '" data-idev-portal="' . esc_attr(wp_json_encode($cfg, JSON_UNESCAPED_UNICODE)) . '"></div>';
}
