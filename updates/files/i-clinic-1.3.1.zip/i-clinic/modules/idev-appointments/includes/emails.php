<?php
/** E-mails to patients and staff, reminders (WP-Cron, hourly) and calendar files. */
defined('ABSPATH') || exit;

function idev_appt_vars($a) {
    $s = idev_appt_settings();
    $en = ($a['p']['lang'] ?? 'th') === 'en';
    $lang = $en ? 'en' : 'th';
    $provider = function_exists('idev_cs_provider') && ($post = get_post($a['provider_id'])) ? idev_cs_provider($post) : ['name' => '', 'name_en' => '', 'specialty' => '', 'specialty_en' => ''];
    $pname = idev_pick($provider['name'], $provider['name_en'], $lang);
    $spec = idev_pick($provider['specialty'], $provider['specialty_en'], $lang);
    $reason = (string) ($a['p']['cancel_reason'] ?? '');
    /** Filter: placeholders for e-mails and messages (add-ons: branch location and phone). */
    return apply_filters('idev_appt_vars', [
        '{name}' => $a['p']['name'] ?: ($en ? 'patient' : 'ผู้ป่วย'), '{ref}' => $a['ref'], '{date}' => idev_format_day($a['appt_date'], $lang, true), '{time}' => $a['start_time'] . '–' . $a['end_time'],
        '{provider}' => trim($pname . ($spec !== '' ? ' · ' . $spec : '')), '{location}' => idev_pick($s['location'], $s['location_en'], $lang), '{status}' => idev_appt_status_label($a['status'], $lang),
        '{reason}' => $reason !== '' ? ($en ? 'Reason: ' : 'เหตุผล: ') . $reason : '', '{phone}' => $s['phone'], '{site}' => get_bloginfo('name'),
    ], $a, $lang);
}
function idev_appt_status_label($status, $lang) {
    $th = ['pending' => 'รอยืนยัน', 'confirmed' => 'ยืนยันแล้ว', 'cancelled' => 'ยกเลิก', 'completed' => 'มาตามนัดแล้ว', 'no_show' => 'ไม่มาตามนัด'];
    $en = ['pending' => 'waiting for confirmation', 'confirmed' => 'confirmed', 'cancelled' => 'cancelled', 'completed' => 'done', 'no_show' => 'did not come'];
    return ($lang === 'en' ? $en : $th)[$status] ?? $status;
}
function idev_appt_manage_url($a) {
    $t = idev_appt_token($a);
    $base = idev_appt_booking_url();
    return $t && $base ? add_query_arg('appt', $t, $base) : '';
}
function idev_appt_mail_html($title, $text, $a, $button = true) {
    $s = idev_appt_settings();
    $en = ($a['p']['lang'] ?? 'th') === 'en';
    $c = sanitize_hex_color($s['accent']) ?: '#0f766e';
    $body = '';
    foreach (preg_split("/\n{2,}/", trim($text)) as $para) $body .= '<p style="margin:0 0 14px">' . nl2br(esc_html(trim($para))) . '</p>';
    $url = $button ? idev_appt_manage_url($a) : '';
    $btn = $url ? '<p style="margin:22px 0 6px"><a href="' . esc_url($url) . '" style="display:inline-block;background:' . $c . ';color:#fff;text-decoration:none;padding:12px 22px;border-radius:999px;font-weight:bold">' . ($en ? 'View, move or cancel' : 'ดู เลื่อน หรือยกเลิกนัด') . '</a></p>' : '';
    $ics = $url && in_array($a['status'], ['confirmed', 'pending'], true) ? '<p style="margin:6px 0 0;font-size:13px"><a href="' . esc_url(add_query_arg('t', idev_appt_token($a), rest_url('idev-appt/v1/ics'))) . '" style="color:' . $c . '">' . ($en ? 'Add to my calendar' : 'เพิ่มลงปฏิทิน') . '</a></p>' : '';
    return '<div style="font-family:Tahoma,Arial,sans-serif;background:#f3f6f8;padding:24px"><div style="max-width:580px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden;border:1px solid #e3e9ee">'
        . '<div style="background:' . $c . ';color:#fff;padding:18px 22px"><strong style="font-size:17px">' . esc_html(get_bloginfo('name')) . '</strong><br><span style="font-size:13px;opacity:.85">' . esc_html($title) . '</span></div>'
        . '<div style="padding:22px;color:#172737;font-size:15px;line-height:1.7">' . $body . '<p style="margin:0;color:#70808d;font-size:13px">' . ($en ? 'Reference' : 'เลขที่นัด') . ' ' . esc_html($a['ref']) . '</p>' . $btn . $ics . '</div>'
        . ($s['phone'] ? '<div style="padding:14px 22px;background:#f7f9fa;color:#70808d;font-size:12px">' . ($en ? 'Questions? Call ' : 'สอบถาม โทร ') . esc_html($s['phone']) . '</div>' : '') . '</div></div>';
}

/** Patient e-mail of one type. Returns true when sent. */
function idev_appt_notify($id, $type) {
    $a = idev_appt_get($id);
    if (!$a || !$a['readable']) return false;
    $s = idev_appt_settings();
    if (($s['mail_' . $type] ?? '0') !== '1') return false;
    $to = $a['p']['contact_email'] ?? '';
    if (!is_email($to)) return false;
    $en = ($a['p']['lang'] ?? 'th') === 'en';
    $sfx = $en ? '_en' : '';
    $vars = idev_appt_vars($a);
    $subject = strtr($s['tpl_' . $type . '_subject' . $sfx] ?: $s['tpl_' . $type . '_subject'], $vars);
    $text = strtr($s['tpl_' . $type . '_body' . $sfx] ?: $s['tpl_' . $type . '_body'], $vars);
    /** Filter: e-mail text before it is sent (add-ons: how to get LINE reminders). */
    $text = apply_filters('idev_appt_mail_text', $text, $type, $a);
    $titles = ['received' => $en ? 'Appointment request' : 'คำขอนัดหมาย', 'confirmed' => $en ? 'Appointment confirmed' : 'ยืนยันนัดหมาย', 'reminder' => $en ? 'Reminder' : 'แจ้งเตือนนัดหมาย', 'day' => $en ? 'Today' : 'นัดหมายวันนี้', 'cancelled' => $en ? 'Appointment cancelled' : 'ยกเลิกนัดหมาย', 'rescheduled' => $en ? 'Appointment moved' : 'เปลี่ยนเวลานัด'];
    /** Filter: the whole e-mail HTML (add-ons: designed e-mails). Empty = the built-in design. */
    $html = (string) apply_filters('idev_appt_mail_render', '', $type, $titles[$type] ?? '', $text, $a);
    if ($html === '') $html = idev_appt_mail_html($titles[$type] ?? '', $text, $a, $type !== 'cancelled');
    $ok = wp_mail($to, $subject, $html, ['Content-Type: text/html; charset=UTF-8']);
    if ($ok) { $a2 = idev_appt_get($id); idev_appt_log($a2['p'], 'อีเมล: ' . $type, 'system'); idev_appt_save($id, $a2['p']); }
    return $ok;
}

/** Staff and doctor notices (no health details; link to the portal). */
function idev_appt_notify_staff($id, $event) {
    $a = idev_appt_get($id);
    if (!$a) return;
    $s = idev_appt_settings();
    $to = array_filter(array_map('trim', explode(',', (string) $s['staff_email'])), 'is_email');
    if ($s['notify_doctors'] === '1') foreach (idev_appt_provider_cfg($a['provider_id'])['users'] as $uid) { $u = get_userdata($uid); if ($u && is_email($u->user_email)) $to[] = $u->user_email; }
    $to = array_unique($to);
    if (!$to) return;
    $v = idev_appt_vars(['p' => ['lang' => 'th'] + $a['p']] + $a);
    $label = ['new' => $a['status'] === 'pending' ? 'มีคำขอนัดหมายใหม่ (รอยืนยัน)' : 'มีนัดหมายใหม่', 'cancelled' => 'ผู้ป่วยยกเลิกนัด', 'rescheduled' => 'ผู้ป่วยเลื่อนนัด'][$event] ?? $event;
    $portal = idev_appt_portal_url();
    $html = '<div style="font-family:Tahoma,Arial,sans-serif;font-size:15px;line-height:1.7"><p><strong>' . esc_html($label) . '</strong></p><p>' . esc_html($v['{provider}']) . '<br>' . esc_html($v['{date}'] . ' ' . $v['{time}']) . '<br>' . esc_html($a['ref']) . '</p>' . ($portal ? '<p><a href="' . esc_url($portal) . '">เปิดตารางนัด</a></p>' : '') . '<p style="color:#70808d;font-size:12px">อีเมลนี้ไม่มีข้อมูลสุขภาพของผู้ป่วย</p></div>';
    foreach ($to as $email) wp_mail($email, $label . ' ' . $v['{date}'] . ' ' . $a['start_time'], $html, ['Content-Type: text/html; charset=UTF-8']);
}

/* ---------- Reminders ---------- */

add_action('idev_appt_cron', 'idev_appt_run_reminders');
function idev_appt_run_reminders() {
    global $wpdb;
    $s = idev_appt_settings();
    $now = idev_appt_now();
    $today = $now->format('Y-m-d');
    $hour = (int) $now->format('G');
    $t = idev_appt_table();
    $sent = 0;
    $mark = function ($row, $flag) use ($wpdb, $t) { $flags = array_filter(explode(',', $row['reminders'])); $flags[] = $flag; $wpdb->update($t, ['reminders' => implode(',', array_unique($flags))], ['id' => (int) $row['id']]); };
    $days = (int) $s['remind_days'];
    if ($days > 0 && $hour >= (int) $s['remind_hour']) {
        foreach ($wpdb->get_results($wpdb->prepare("SELECT id, reminders FROM {$t} WHERE status='confirmed' AND appt_date=%s AND reminders NOT LIKE '%%before%%'", idev_add_days($today, $days)), ARRAY_A) as $row) {
            $mark($row, 'before');
            if (idev_appt_notify($row['id'], 'reminder')) $sent++;
        }
    }
    if ($hour >= (int) $s['day_hour']) {
        $after = $now->format('H:i');
        foreach ($wpdb->get_results($wpdb->prepare("SELECT id, reminders FROM {$t} WHERE status='confirmed' AND appt_date=%s AND start_time>%s AND reminders NOT LIKE '%%day%%'", $today, $after), ARRAY_A) as $row) {
            $mark($row, 'day');
            if (idev_appt_notify($row['id'], 'day')) $sent++;
        }
    }
    update_option('idev_appt_cron_last', ['at' => time(), 'sent' => $sent], false);
    return $sent;
}

/* ---------- Calendar file (.ics) ---------- */

function idev_appt_ics($a) {
    $v = idev_appt_vars($a);
    $tz = wp_timezone();
    $fmt = function ($date, $time) use ($tz) { return (new DateTimeImmutable("$date $time", $tz))->setTimezone(new DateTimeZone('UTC'))->format('Ymd\THis\Z'); };
    $esc = function ($x) { return preg_replace('/([,;\\\\])/', '\\\\$1', str_replace("\n", '\\n', (string) $x)); };
    $lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//iDevApp//Appointments//EN', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'BEGIN:VEVENT',
        'UID:' . $a['ref'] . '@' . wp_parse_url(home_url(), PHP_URL_HOST), 'DTSTAMP:' . gmdate('Ymd\THis\Z'), 'DTSTART:' . $fmt($a['appt_date'], $a['start_time']), 'DTEND:' . $fmt($a['appt_date'], $a['end_time']),
        'SUMMARY:' . $esc(get_bloginfo('name') . ' – ' . $v['{provider}']), 'LOCATION:' . $esc($v['{location}']), 'DESCRIPTION:' . $esc($a['ref'] . ($v['{phone}'] ? ' · ' . $v['{phone}'] : '')),
        'BEGIN:VALARM', 'TRIGGER:-PT2H', 'ACTION:DISPLAY', 'DESCRIPTION:' . $esc($v['{provider}']), 'END:VALARM', 'END:VEVENT', 'END:VCALENDAR'];
    return implode("\r\n", $lines) . "\r\n";
}
