<?php
/**
 * Barcode / QR sheets of items and services: scan them at the sales screen or in the examination room instead of
 * searching. Items without their own barcode / SKU get the printed code IDS00012 (idev_store_item_code).
 */
defined('ABSPATH') || exit;

function idev_store_codes_url($args = []) { return add_query_arg(array_merge(['action' => 'idev_store_codes', '_wpnonce' => wp_create_nonce('idev_store_codes')], $args), admin_url('admin-post.php')); }

/** One code as SVG: barcode (Code 128) or QR. */
function idev_store_code_svg($code, $type, $h = 42) {
    idev_load_qr();
    return $type === 'qr' ? idev_qr_svg($code, 92, 'M') : idev_code128_svg($code, $h, 1.3);
}

add_action('admin_post_idev_store_codes', function () {
    if (!idev_store_can() || !wp_verify_nonce($_GET['_wpnonce'] ?? '', 'idev_store_codes')) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-store'), 403);
    $type = ($_GET['type'] ?? '') === 'qr' ? 'qr' : 'barcode';
    $layout = ($_GET['layout'] ?? '') === 'labels' ? 'labels' : 'sheet';
    $copies = max(1, min(100, (int) ($_GET['copies'] ?? 1)));
    $ids = array_filter(array_map('intval', explode(',', (string) ($_GET['ids'] ?? ''))));
    if ($ids) $items = array_filter(array_map('idev_store_item', $ids));
    else $items = idev_store_items(['kind' => in_array($_GET['kind'] ?? '', ['product', 'service'], true) ? $_GET['kind'] : '', 'category' => sanitize_text_field(wp_unslash($_GET['category'] ?? '')), 'limit' => 500]);
    $s = idev_store_settings();
    $title = __('Barcodes', 'idev-store') . ' · ' . $s['shop_name'];
    $body = '';
    if ($layout === 'sheet') {
        $groups = [];
        foreach ($items as $i) $groups[$i['kind'] === 'service' ? __('Services', 'idev-store') : ($i['category'] !== '' ? $i['category'] : __('Items', 'idev-store'))][] = $i;
        foreach ($groups as $g => $list) {
            $body .= '<h2>' . esc_html($g) . '</h2><div class="sheet-grid t-' . $type . '">';
            foreach ($list as $i) {
                $code = idev_store_item_code($i);
                $body .= '<div class="cell"><div class="c">' . idev_store_code_svg($code, $type) . '<small>' . esc_html($code) . '</small></div><div class="t"><b>' . esc_html($i['name']) . '</b>' . (!empty($i['attrs']['generic']) ? '<span>' . esc_html($i['attrs']['generic']) . '</span>' : '') . '<em>' . esc_html(idev_store_money($i['price'])) . ($i['unit'] ? ' / ' . esc_html($i['unit']) : '') . '</em></div></div>';
            }
            $body .= '</div>';
        }
    } else {
        foreach ($items as $i) {
            $code = idev_store_item_code($i);
            for ($n = 0; $n < $copies; $n++) $body .= '<div class="lbl t-' . $type . '"><b>' . esc_html($i['name']) . '</b>' . idev_store_code_svg($code, $type, 34) . '<small>' . esc_html($code) . ' · ' . esc_html(idev_store_money($i['price'])) . '</small></div>';
        }
    }
    if (!$items) $body = '<p>' . esc_html__('No items.', 'idev-store') . '</p>';
    $lw = (float) $s['label_w']; $lh = (float) $s['label_h'];
    nocache_headers();
    ?><!doctype html><html lang="<?php echo esc_attr(idev_lang()); ?>"><head><meta charset="utf-8"><title><?php echo esc_html($title); ?></title><style>
*{box-sizing:border-box}body{margin:0;font-family:Tahoma,"Leelawadee UI",Sarabun,sans-serif;background:#e9edf0;color:#000}
.bar{position:sticky;top:0;display:flex;gap:6px;justify-content:center;flex-wrap:wrap;padding:10px;background:#1d2327;z-index:2}.bar a,.bar button{font:13px Tahoma,sans-serif;color:#fff;background:#3c434a;border:0;border-radius:6px;padding:7px 12px;text-decoration:none;cursor:pointer}.bar a.on{background:#2271b1}.bar button{background:#00a32a;font-weight:bold}
.page{background:#fff;width:210mm;margin:16px auto;padding:10mm;box-shadow:0 2px 14px rgba(0,0,0,.15)}
h1{font-size:16px;margin:0 0 4px}h1 small{font-weight:normal;color:#555}h2{font-size:13px;margin:12px 0 6px;padding:3px 8px;background:#f1f1f1;border-left:4px solid #000}
.sheet-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:0}.sheet-grid.t-qr{grid-template-columns:repeat(3,1fr)}
.cell{display:flex;gap:8px;align-items:center;border:1px dashed #bbb;padding:6px 8px;break-inside:avoid;page-break-inside:avoid;min-height:22mm}
.cell .c{text-align:center;flex:none}.cell .c svg{display:block;max-width:58mm;height:auto}.t-qr .cell .c svg{width:22mm;height:22mm}.cell small{font:10px monospace;display:block}
.cell .t{min-width:0}.cell .t b{display:block;font-size:12.5px;line-height:1.3}.cell .t span{display:block;font-size:11px;color:#444}.cell .t em{font-style:normal;font-weight:bold;font-size:12px}
.labels{display:flex;flex-wrap:wrap;gap:2mm}
.lbl{width:<?php echo esc_attr($lw); ?>mm;height:<?php echo esc_attr($lh); ?>mm;border:1px dashed #bbb;padding:2mm;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;overflow:hidden;break-inside:avoid;page-break-inside:avoid}
.lbl b{font-size:11px;line-height:1.2;max-height:2.4em;overflow:hidden}.lbl svg{max-width:100%;height:auto;margin:1mm 0}.lbl.t-qr svg{width:min(60%,24mm);height:auto}.lbl small{font:9px monospace}
@media print{body{background:#fff}.bar{display:none}.page{margin:0;box-shadow:none;width:auto;padding:0}.cell,.lbl{border-color:#ddd}}
@page{size:A4;margin:8mm}
</style></head><body><div class="bar"><?php
    $q = array_diff_key($_GET, ['action' => 1, '_wpnonce' => 1]); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    foreach (['barcode' => __('Barcode', 'idev-store'), 'qr' => 'QR'] as $k => $l) echo '<a class="' . ($type === $k ? 'on' : '') . '" href="' . esc_url(idev_store_codes_url(array_merge($q, ['type' => $k]))) . '">' . esc_html($l) . '</a>';
    foreach (['sheet' => __('List sheet (A4)', 'idev-store'), 'labels' => __('Stickers', 'idev-store')] as $k => $l) echo '<a class="' . ($layout === $k ? 'on' : '') . '" href="' . esc_url(idev_store_codes_url(array_merge($q, ['layout' => $k]))) . '">' . esc_html($l) . '</a>';
    ?><button onclick="window.print()">🖨 <?php esc_html_e('Print', 'idev-store'); ?></button></div><div class="page"><?php
    if ($layout === 'sheet') echo '<h1>' . esc_html($s['shop_name']) . ' <small>· ' . esc_html__('Scan the code at the sales screen or in the examination room', 'idev-store') . ' · ' . esc_html(idev_format_day(idev_today())) . '</small></h1>' . $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    else echo '<div class="labels">' . $body . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    ?></div></body></html><?php
    exit;
});

/** The options page: Stock → Print barcodes / QR. */
function idev_store_codes_page() {
    idev_store_head(__('Print barcodes / QR', 'idev-store'), __('A sheet of medicines and services to scan, or stickers for the shelves', 'idev-store'));
    echo '<p><a href="' . esc_url(idev_store_url('idev-store-stock')) . '">← ' . esc_html__('Stock', 'idev-store') . '</a></p><div class="idev-card"><form method="get" action="' . esc_url(admin_url('admin-post.php')) . '" target="_blank">';
    echo '<input type="hidden" name="action" value="idev_store_codes"><input type="hidden" name="_wpnonce" value="' . esc_attr(wp_create_nonce('idev_store_codes')) . '"><table class="form-table">';
    echo '<tr><th>' . esc_html__('Items', 'idev-store') . '</th><td><label><input type="radio" name="kind" value="" checked> ' . esc_html__('Everything', 'idev-store') . '</label> &nbsp; <label><input type="radio" name="kind" value="product"> ' . esc_html__('Medicines / products', 'idev-store') . '</label> &nbsp; <label><input type="radio" name="kind" value="service"> ' . esc_html__('Services (consultation, procedures…)', 'idev-store') . '</label></td></tr>';
    echo '<tr><th>' . esc_html__('Category', 'idev-store') . '</th><td><select name="category"><option value="">' . esc_html__('All categories', 'idev-store') . '</option>';
    foreach (idev_store_categories() as $c) echo '<option>' . esc_html($c) . '</option>';
    echo '</select></td></tr><tr><th>' . esc_html__('Code', 'idev-store') . '</th><td><label><input type="radio" name="type" value="barcode" checked> ' . esc_html__('Barcode (any scanner)', 'idev-store') . '</label> &nbsp; <label><input type="radio" name="type" value="qr"> ' . esc_html__('QR code (2D scanners, phone camera)', 'idev-store') . '</label></td></tr>';
    echo '<tr><th>' . esc_html__('Layout', 'idev-store') . '</th><td><label><input type="radio" name="layout" value="sheet" checked> ' . esc_html__('List sheet A4: name, price and code, grouped by category — keep it at the counter', 'idev-store') . '</label><br><label><input type="radio" name="layout" value="labels"> ' . esc_html__('Stickers, size from Settings → drug label', 'idev-store') . '</label> · ' . esc_html__('copies of each', 'idev-store') . ' <input type="number" name="copies" value="1" min="1" max="100" style="width:70px"></td></tr></table>';
    echo '<p><button class="button button-primary button-hero">🖨 ' . esc_html__('Open the print page', 'idev-store') . '</button></p><p class="description">' . esc_html__('Items without their own barcode get a code such as IDS00012. Scanning it at the sales screen or in the examination room adds the item.', 'idev-store') . '</p></form></div></div>';
}
