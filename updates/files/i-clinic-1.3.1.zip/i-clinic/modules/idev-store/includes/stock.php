<?php
/**
 * Stock: items, lots (lot number + expiry date) and an append-only movement ledger.
 * Stock goes out first-expiry-first-out; every change writes a move with the balance after it.
 */
defined('ABSPATH') || exit;

function idev_store_item_row($r) {
    if (!$r) return null;
    $r['attrs'] = json_decode($r['attrs'] ?: '{}', true) ?: [];
    foreach (['price', 'cost', 'min_qty', 'qty'] as $k) $r[$k] = (float) $r[$k];
    foreach (['id', 'track', 'lots', 'active'] as $k) $r[$k] = (int) $r[$k];
    return $r;
}
/** Code printed as barcode / QR: the item's barcode, else its SKU, else IDS00012. */
function idev_store_item_code($i) { return $i['barcode'] !== '' ? $i['barcode'] : ($i['sku'] !== '' ? $i['sku'] : 'IDS' . str_pad((string) $i['id'], 5, '0', STR_PAD_LEFT)); }
/** Pack used when receiving: [pack unit, units per pack] or null. E.g. ['กล่อง', 100] for a box of 100 tablets. */
function idev_store_pack($i) {
    $n = (float) ($i['attrs']['pack_size'] ?? 0);
    $u = trim((string) ($i['attrs']['pack_unit'] ?? ''));
    return $n > 1 && $u !== '' ? [$u, $n] : null;
}
/** Quantity in packs and units: "3 กล่อง 20 เม็ด". */
function idev_store_qty_text($i, $qty) {
    $pack = idev_store_pack($i);
    $unit = $i['unit'];
    if (!$pack || abs($qty) < $pack[1]) return trim(idev_store_qty($qty) . ' ' . $unit);
    $sign = $qty < 0 ? '-' : '';
    $q = abs($qty);
    $packs = floor($q / $pack[1] + 0.00001);
    $rest = round($q - $packs * $pack[1], 2);
    return $sign . idev_store_qty($packs) . ' ' . $pack[0] . ($rest > 0 ? ' ' . idev_store_qty($rest) . ' ' . $unit : '');
}
function idev_store_item($id) {
    global $wpdb;
    return idev_store_item_row($wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_store_t('items') . ' WHERE id = %d', $id), ARRAY_A));
}
function idev_store_item_by_code($code) {
    global $wpdb;
    $code = trim((string) $code);
    if ($code === '') return null;
    // Printed code of items without their own barcode / SKU: IDS + item no. (see idev_store_item_code)
    if (preg_match('/^IDS0*(\d+)$/i', $code, $m) && ($it = idev_store_item((int) $m[1])) && $it['active']) return $it;
    return idev_store_item_row($wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_store_t('items') . ' WHERE active = 1 AND (barcode = %s OR sku = %s) ORDER BY id LIMIT 1', $code, $code), ARRAY_A));
}
/** Items for lists and the sales screen. $args: q, category, kind, low (1), active (1|0|all), limit, offset. */
function idev_store_items($args = []) {
    global $wpdb;
    $t = idev_store_t('items');
    $w = ['1=1']; $p = [];
    $active = $args['active'] ?? '1';
    if ($active !== 'all') { $w[] = 'active = %d'; $p[] = (int) $active; }
    if (!empty($args['q'])) { $like = '%' . $wpdb->esc_like(trim($args['q'])) . '%'; $w[] = '(name LIKE %s OR name_en LIKE %s OR sku LIKE %s OR barcode LIKE %s OR category LIKE %s)'; array_push($p, $like, $like, $like, $like, $like); }
    if (!empty($args['category'])) { $w[] = 'category = %s'; $p[] = $args['category']; }
    if (!empty($args['kind'])) { $w[] = 'kind = %s'; $p[] = $args['kind']; }
    if (!empty($args['low'])) $w[] = 'track = 1 AND qty <= min_qty';
    $limit = max(1, min(500, (int) ($args['limit'] ?? 100)));
    $sql = "SELECT * FROM $t WHERE " . implode(' AND ', $w) . ' ORDER BY category, name LIMIT ' . $limit . ' OFFSET ' . max(0, (int) ($args['offset'] ?? 0));
    $rows = $wpdb->get_results($p ? $wpdb->prepare($sql, $p) : $sql, ARRAY_A);
    return array_map('idev_store_item_row', $rows);
}
function idev_store_attrs_clean($a) {
    $o = [];
    foreach (array_filter((array) $a, 'strlen') as $k => $v) $o[sanitize_key($k)] = $k === 'use' ? sanitize_textarea_field($v) : sanitize_text_field($v);
    return $o;
}
function idev_store_lot($id) {
    global $wpdb;
    return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_store_t('lots') . ' WHERE id = %d', $id), ARRAY_A);
}
function idev_store_categories() {
    global $wpdb;
    return $wpdb->get_col('SELECT DISTINCT category FROM ' . idev_store_t('items') . " WHERE category <> '' ORDER BY category");
}

/** Creates or updates an item. Returns the id or WP_Error. */
function idev_store_item_save($in, $id = 0) {
    global $wpdb;
    $name = sanitize_text_field($in['name'] ?? '');
    if ($name === '') return new WP_Error('name', __('Please enter a name.', 'idev-store'));
    $kind = in_array($in['kind'] ?? '', ['product', 'service'], true) ? $in['kind'] : 'product';
    $row = [
        'sku' => sanitize_text_field($in['sku'] ?? ''), 'barcode' => sanitize_text_field($in['barcode'] ?? ''),
        'name' => $name, 'name_en' => sanitize_text_field($in['name_en'] ?? ''), 'category' => sanitize_text_field($in['category'] ?? ''),
        'unit' => sanitize_text_field($in['unit'] ?? ''), 'kind' => $kind,
        'track' => $kind === 'service' ? 0 : (empty($in['track']) ? 0 : 1), 'lots' => $kind === 'service' ? 0 : (empty($in['lots']) ? 0 : 1),
        'price' => idev_store_num($in['price'] ?? 0), 'cost' => idev_store_num4($in['cost'] ?? 0), 'min_qty' => idev_store_num($in['min_qty'] ?? 0),
        'attrs' => wp_json_encode(idev_store_attrs_clean($in['attrs'] ?? []), JSON_UNESCAPED_UNICODE),
        'active' => isset($in['active']) ? (int) (bool) $in['active'] : 1, 'updated_at' => idev_store_now(),
    ];
    foreach (['sku', 'barcode'] as $k) {
        if ($row[$k] === '') continue;
        $dup = $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . idev_store_t('items') . " WHERE $k = %s AND id <> %d", $row[$k], $id));
        if ($dup) return new WP_Error($k, sprintf(__('Another item already uses this code (%s).', 'idev-store'), $row[$k]));
    }
    if ($id) { $wpdb->update(idev_store_t('items'), $row, ['id' => $id]); return $id; }
    $row['created_at'] = $row['updated_at'];
    $wpdb->insert(idev_store_t('items'), $row);
    return (int) $wpdb->insert_id;
}

function idev_store_lots($item_id, $only_stock = false) {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . idev_store_t('lots') . ' WHERE item_id = %d' . ($only_stock ? ' AND qty <> 0' : '') . ' ORDER BY CASE WHEN expiry IS NULL THEN 1 ELSE 0 END, expiry, id', $item_id), ARRAY_A);
    foreach ($rows as &$r) { $r['qty'] = (float) $r['qty']; $r['cost'] = (float) $r['cost']; $r['id'] = (int) $r['id']; }
    return $rows;
}
function idev_store_sync_qty($item_id) {
    global $wpdb;
    $q = (float) $wpdb->get_var($wpdb->prepare('SELECT COALESCE(SUM(qty),0) FROM ' . idev_store_t('lots') . ' WHERE item_id = %d', $item_id));
    $wpdb->update(idev_store_t('items'), ['qty' => $q, 'updated_at' => idev_store_now()], ['id' => $item_id]);
    return $q;
}
function idev_store_move($item_id, $lot_id, $qty, $type, $ref = '', $note = '') {
    global $wpdb;
    $bal = idev_store_sync_qty($item_id);
    $wpdb->insert(idev_store_t('moves'), ['item_id' => $item_id, 'lot_id' => $lot_id, 'qty' => $qty, 'balance' => $bal, 'type' => $type, 'ref' => (string) $ref, 'note' => mb_substr((string) $note, 0, 250), 'user_id' => get_current_user_id(), 'created_at' => idev_store_now()]);
}
function idev_store_lot_for($item_id, $lot_no = '', $expiry = null, $cost = 0) {
    global $wpdb;
    $t = idev_store_t('lots');
    $expiry = $expiry && idev_is_valid_date($expiry) ? $expiry : null;
    $id = $expiry
        ? $wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE item_id = %d AND lot_no = %s AND expiry = %s", $item_id, $lot_no, $expiry))
        : $wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE item_id = %d AND lot_no = %s AND expiry IS NULL", $item_id, $lot_no));
    if ($id) return (int) $id;
    $wpdb->insert($t, ['item_id' => $item_id, 'lot_no' => $lot_no, 'expiry' => $expiry, 'qty' => 0, 'cost' => $cost, 'created_at' => idev_store_now()]);
    return (int) $wpdb->insert_id;
}

/** Stock in (receive, return, count). $a: lot_no, expiry, cost, type, ref, note. */
function idev_store_stock_in($item_id, $qty, $a = []) {
    global $wpdb;
    $item = idev_store_item($item_id);
    $qty = idev_store_num($qty);
    if (!$item || $qty <= 0) return new WP_Error('qty', __('Please check the item and quantity.', 'idev-store'));
    if (!$item['track']) return 0;
    $lot_no = $item['lots'] ? sanitize_text_field($a['lot_no'] ?? '') : '';
    $expiry = $item['lots'] ? ($a['expiry'] ?? null) : null;
    $cost = isset($a['cost']) && $a['cost'] !== '' ? idev_store_num4($a['cost']) : $item['cost'];
    $lot = !empty($a['lot_id']) ? (int) $a['lot_id'] : idev_store_lot_for($item_id, $lot_no, $expiry, $cost);
    $wpdb->query($wpdb->prepare('UPDATE ' . idev_store_t('lots') . ' SET qty = qty + %f WHERE id = %d', $qty, $lot));
    if (($a['type'] ?? 'receive') === 'receive' && $cost > 0) $wpdb->update(idev_store_t('items'), ['cost' => $cost], ['id' => $item_id]);
    idev_store_move($item_id, $lot, $qty, $a['type'] ?? 'receive', $a['ref'] ?? '', $a['note'] ?? '');
    return $lot;
}

/**
 * Stock out, first expiry first. Returns the lots used [[lot_id, qty, lot_no, expiry]] or WP_Error when there is not
 * enough stock (unless negative stock is allowed in the settings).
 */
function idev_store_stock_out($item_id, $qty, $type = 'sale', $ref = '', $note = '') {
    global $wpdb;
    $item = idev_store_item($item_id);
    $qty = idev_store_num($qty);
    if (!$item || $qty <= 0) return new WP_Error('qty', __('Please check the item and quantity.', 'idev-store'));
    if (!$item['track']) return [];
    if ($item['qty'] + 0.0001 < $qty && idev_store_settings()['allow_negative'] !== '1') {
        return new WP_Error('stock', sprintf(__('Not enough %1$s in stock (have %2$s).', 'idev-store'), $item['name'], idev_store_qty($item['qty'])));
    }
    $left = $qty; $used = [];
    foreach (idev_store_lots($item_id, true) as $lot) {
        if ($left <= 0) break;
        if ($lot['qty'] <= 0) continue;
        $take = min($left, $lot['qty']);
        $wpdb->query($wpdb->prepare('UPDATE ' . idev_store_t('lots') . ' SET qty = qty - %f WHERE id = %d', $take, $lot['id']));
        idev_store_move($item_id, $lot['id'], -$take, $type, $ref, $note);
        $used[] = [$lot['id'], $take, $lot['lot_no'], $lot['expiry']];
        $left = round($left - $take, 2);
    }
    if ($left > 0) { // allowed to go below zero: book it on the item's plain lot
        $lot = idev_store_lot_for($item_id);
        $wpdb->query($wpdb->prepare('UPDATE ' . idev_store_t('lots') . ' SET qty = qty - %f WHERE id = %d', $left, $lot));
        idev_store_move($item_id, $lot, -$left, $type, $ref, $note);
        $used[] = [$lot, $left, '', null];
    }
    return $used;
}

/** Puts stock back into the lots it came from (void a sale). */
function idev_store_stock_back($item_id, $used, $ref, $note = '') {
    global $wpdb;
    foreach ((array) $used as $u) {
        [$lot, $q] = $u;
        $wpdb->query($wpdb->prepare('UPDATE ' . idev_store_t('lots') . ' SET qty = qty + %f WHERE id = %d', $q, $lot));
        idev_store_move($item_id, (int) $lot, $q, 'void', $ref, $note);
    }
}

/** Stock count / correction of one lot to the counted quantity. */
function idev_store_stock_count($item_id, $lot_id, $counted, $note = '') {
    global $wpdb;
    $lot = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_store_t('lots') . ' WHERE id = %d AND item_id = %d', $lot_id, $item_id), ARRAY_A);
    if (!$lot) $lot_id = idev_store_lot_for($item_id);
    $before = $lot ? (float) $lot['qty'] : 0.0;
    $diff = round(idev_store_num($counted) - $before, 2);
    if (abs($diff) < 0.001) return 0;
    $wpdb->update(idev_store_t('lots'), ['qty' => idev_store_num($counted)], ['id' => $lot_id]);
    idev_store_move($item_id, $lot_id, $diff, 'count', '', $note);
    return $diff;
}

function idev_store_moves($item_id, $limit = 100) {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare('SELECT m.*, l.lot_no, l.expiry FROM ' . idev_store_t('moves') . ' m LEFT JOIN ' . idev_store_t('lots') . ' l ON l.id = m.lot_id WHERE m.item_id = %d ORDER BY m.id DESC LIMIT %d', $item_id, $limit), ARRAY_A);
}
function idev_store_move_types() {
    return ['receive' => __('Received', 'idev-store'), 'sale' => __('Sold / dispensed', 'idev-store'), 'job' => __('Used in job order', 'idev-store'), 'count' => __('Stock count', 'idev-store'), 'void' => __('Returned (voided bill)', 'idev-store'), 'return' => __('Returned to supplier', 'idev-store'), 'loss' => __('Damaged / expired', 'idev-store')];
}

/** Lots that expire within N days (and still have stock). */
function idev_store_expiring($days = null) {
    global $wpdb;
    $days = $days ?? (int) idev_store_settings()['expiry_days'];
    return $wpdb->get_results($wpdb->prepare('SELECT l.*, i.name, i.unit FROM ' . idev_store_t('lots') . ' l JOIN ' . idev_store_t('items') . ' i ON i.id = l.item_id WHERE l.qty > 0 AND l.expiry IS NOT NULL AND l.expiry <= %s ORDER BY l.expiry', idev_add_days(idev_today(), $days)), ARRAY_A);
}
function idev_store_low_count() {
    global $wpdb;
    return (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . idev_store_t('items') . ' WHERE active = 1 AND track = 1 AND qty <= min_qty AND min_qty > 0');
}
