<?php
/**
 * Bills (sales / dispensing), their lines and payments. One bill can be paid in parts (deposit, balance);
 * each payment gets its own receipt number: RC2610-0007-1, RC2610-0007-2 …
 */
defined('ABSPATH') || exit;

/** Totals with VAT per the settings: none / included in prices / added on top. */
function idev_store_totals($subtotal, $discount) {
    $s = idev_store_settings();
    $net = max(0, round($subtotal - $discount, 2));
    $rate = (float) $s['vat_rate'];
    if ($s['vat'] === 'excluded') { $vat = round($net * $rate / 100, 2); return ['vat' => $vat, 'total' => round($net + $vat, 2)]; }
    if ($s['vat'] === 'included') return ['vat' => round($net * $rate / (100 + $rate), 2), 'total' => $net];
    return ['vat' => 0.0, 'total' => $net];
}

/**
 * Creates a bill and takes the items out of stock.
 * $in: customer_id, job_id, lines [[item_id, name, qty, price, discount]], discount, note, stock_type, payments [[method, amount, received]].
 * Returns bill id or WP_Error (nothing is saved on error).
 */
function idev_store_bill_create($in) {
    global $wpdb;
    $lines = [];
    $need = [];
    foreach ((array) ($in['lines'] ?? []) as $l) {
        $item = !empty($l['item_id']) ? idev_store_item((int) $l['item_id']) : null;
        $qty = idev_store_num($l['qty'] ?? 1);
        if ($qty <= 0) continue;
        $name = sanitize_text_field($l['name'] ?? '') ?: ($item['name'] ?? '');
        if ($name === '') continue;
        $price = isset($l['price']) && $l['price'] !== '' ? idev_store_num($l['price']) : (float) ($item['price'] ?? 0);
        $disc = min(idev_store_num($l['discount'] ?? 0), $price * $qty);
        $lines[] = ['item' => $item, 'name' => $name, 'qty' => $qty, 'price' => $price, 'discount' => $disc, 'total' => round($price * $qty - $disc, 2), 'label' => idev_store_label_clean($l['label'] ?? [])];
        if ($item && $item['track']) $need[$item['id']] = ($need[$item['id']] ?? 0) + $qty;
    }
    if (!$lines) return new WP_Error('lines', __('Please add at least one item.', 'idev-store'));
    if (idev_store_settings()['allow_negative'] !== '1') {
        foreach ($need as $iid => $q) { $it = idev_store_item($iid); if ($it['qty'] + 0.0001 < $q) return new WP_Error('stock', sprintf(__('Not enough %1$s in stock (have %2$s).', 'idev-store'), $it['name'], idev_store_qty($it['qty']))); }
    }
    $info = idev_store_sale_info_clean($in['info'] ?? []);
    $ok = idev_store_sale_info_check($lines, $info, (int) ($in['customer_id'] ?? 0));
    if (is_wp_error($ok)) return $ok;
    $subtotal = array_sum(array_column($lines, 'total'));
    $discount = min(idev_store_num($in['discount'] ?? 0), $subtotal);
    $tot = idev_store_totals($subtotal, $discount);
    $no = idev_store_next_no(idev_store_settings()['prefix_bill']);
    $now = idev_store_now();
    $wpdb->insert(idev_store_t('bills'), ['no' => $no, 'customer_id' => (int) ($in['customer_id'] ?? 0), 'job_id' => (int) ($in['job_id'] ?? 0), 'status' => 'open', 'subtotal' => $subtotal, 'discount' => $discount, 'vat' => $tot['vat'], 'total' => $tot['total'], 'paid' => 0, 'note' => sanitize_text_field($in['note'] ?? ''), 'info' => $info ? idev_store_json_enc($info) : '', 'user_id' => get_current_user_id(), 'created_at' => $now, 'updated_at' => $now]);
    $bill_id = (int) $wpdb->insert_id;
    if (!$bill_id) return new WP_Error('db', __('Could not save the bill. Please try again.', 'idev-store'));
    foreach ($lines as $l) {
        $used = $l['item'] ? idev_store_stock_out($l['item']['id'], $l['qty'], $in['stock_type'] ?? 'sale', $no) : [];
        if (is_wp_error($used)) $used = [];
        $text = implode(', ', array_filter(array_map(function ($u) { return trim(($u[2] ? 'Lot ' . $u[2] : '') . ($u[3] ? ' EXP ' . $u[3] : '')); }, $used)));
        $wpdb->insert(idev_store_t('lines'), ['bill_id' => $bill_id, 'item_id' => $l['item']['id'] ?? 0, 'name' => $l['name'], 'qty' => $l['qty'], 'price' => $l['price'], 'discount' => $l['discount'], 'total' => $l['total'],
            'info' => wp_json_encode(array_filter(['t' => $text, 'u' => array_map(function ($u) { return [$u[0], $u[1]]; }, $used), 'l' => $l['label']]), JSON_UNESCAPED_UNICODE)]);
    }
    foreach ((array) ($in['payments'] ?? []) as $p) if (idev_store_num($p['amount'] ?? 0) > 0) idev_store_bill_pay($bill_id, $p['method'] ?? 'cash', $p['amount'], $p['received'] ?? null);
    idev_store_bill_status($bill_id);
    do_action('idev_store_bill_created', $bill_id);
    return $bill_id;
}

/** Records a payment. Returns payment id or WP_Error. */
function idev_store_bill_pay($bill_id, $method, $amount, $received = null) {
    global $wpdb;
    $bill = idev_store_bill($bill_id);
    if (!$bill || $bill['status'] === 'void') return new WP_Error('bill', __('Bill not found.', 'idev-store'));
    $amount = min(idev_store_num($amount), round($bill['total'] - $bill['paid'], 2));
    if ($amount <= 0) return new WP_Error('amount', __('Nothing left to pay on this bill.', 'idev-store'));
    $method = array_key_exists($method, idev_store_pay_methods()) ? $method : 'cash';
    $received = $method === 'cash' && $received !== null && $received !== '' ? max($amount, idev_store_num($received)) : $amount;
    $n = 1 + (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . idev_store_t('payments') . ' WHERE bill_id = %d', $bill_id));
    $wpdb->insert(idev_store_t('payments'), ['bill_id' => $bill_id, 'no' => $bill['no'] . '-' . $n, 'method' => $method, 'amount' => $amount, 'received' => $received, 'change_amount' => round($received - $amount, 2), 'user_id' => get_current_user_id(), 'created_at' => idev_store_now()]);
    $id = (int) $wpdb->insert_id;
    idev_store_bill_status($bill_id);
    return $id;
}
function idev_store_bill_status($bill_id) {
    global $wpdb;
    $paid = (float) $wpdb->get_var($wpdb->prepare('SELECT COALESCE(SUM(amount),0) FROM ' . idev_store_t('payments') . ' WHERE bill_id = %d AND void = 0', $bill_id));
    $b = $wpdb->get_row($wpdb->prepare('SELECT total, status FROM ' . idev_store_t('bills') . ' WHERE id = %d', $bill_id), ARRAY_A);
    if (!$b) return;
    $status = $b['status'] === 'void' ? 'void' : ($paid + 0.005 >= (float) $b['total'] ? 'paid' : 'open');
    $wpdb->update(idev_store_t('bills'), ['paid' => $paid, 'status' => $status, 'updated_at' => idev_store_now()], ['id' => $bill_id]);
    if ($status === 'paid' && $b['status'] !== 'paid') do_action('idev_store_bill_paid', $bill_id);
}

function idev_store_bill($id) {
    global $wpdb;
    $b = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_store_t('bills') . ' WHERE id = %d', $id), ARRAY_A);
    if (!$b) return null;
    foreach (['subtotal', 'discount', 'vat', 'total', 'paid'] as $k) $b[$k] = (float) $b[$k];
    $b['id'] = (int) $b['id'];
    $b['lines'] = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . idev_store_t('lines') . ' WHERE bill_id = %d ORDER BY id', $id), ARRAY_A);
    foreach ($b['lines'] as &$l) { $i = json_decode($l['info'] ?: '{}', true) ?: []; $l['lot_text'] = $i['t'] ?? ''; $l['used'] = $i['u'] ?? []; $l['label'] = $i['l'] ?? []; }
    unset($l);
    $b['payments'] = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . idev_store_t('payments') . ' WHERE bill_id = %d ORDER BY id', $id), ARRAY_A);
    $b['info'] = !empty($b['info']) ? idev_store_json_dec($b['info']) : [];
    $b['customer'] = idev_store_customer((int) $b['customer_id']);
    $b['balance'] = round($b['total'] - $b['paid'], 2);
    return $b;
}
function idev_store_bill_by_no($no) {
    global $wpdb;
    $id = $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . idev_store_t('bills') . ' WHERE no = %s', $no));
    return $id ? idev_store_bill((int) $id) : null;
}

/** Voids a bill: stock goes back to its lots and payments are cancelled. */
function idev_store_bill_void($id, $reason = '') {
    global $wpdb;
    $b = idev_store_bill($id);
    if (!$b || $b['status'] === 'void') return new WP_Error('bill', __('Bill not found.', 'idev-store'));
    foreach ($b['lines'] as $l) if ((int) $l['item_id'] && $l['used']) idev_store_stock_back((int) $l['item_id'], $l['used'], $b['no'], $reason);
    $wpdb->update(idev_store_t('payments'), ['void' => 1], ['bill_id' => $id]);
    $wpdb->update(idev_store_t('bills'), ['status' => 'void', 'paid' => 0, 'note' => mb_substr(trim($b['note'] . ' | ' . sprintf(__('Voided: %s', 'idev-store'), $reason), ' |'), 0, 250), 'updated_at' => idev_store_now()], ['id' => $id]);
    do_action('idev_store_bill_voided', $id);
    return true;
}

function idev_store_bills($args = []) {
    global $wpdb;
    $t = idev_store_t('bills');
    $w = ['1=1']; $p = [];
    if (!empty($args['from'])) { $w[] = 'created_at >= %s'; $p[] = $args['from'] . ' 00:00:00'; }
    if (!empty($args['to'])) { $w[] = 'created_at <= %s'; $p[] = $args['to'] . ' 23:59:59'; }
    if (!empty($args['customer_id'])) { $w[] = 'customer_id = %d'; $p[] = (int) $args['customer_id']; }
    if (!empty($args['status'])) { $w[] = 'status = %s'; $p[] = $args['status']; }
    if (!empty($args['q'])) { $w[] = 'no LIKE %s'; $p[] = '%' . $wpdb->esc_like($args['q']) . '%'; }
    $sql = "SELECT * FROM $t WHERE " . implode(' AND ', $w) . ' ORDER BY id DESC LIMIT ' . max(1, min(500, (int) ($args['limit'] ?? 100)));
    return $wpdb->get_results($p ? $wpdb->prepare($sql, $p) : $sql, ARRAY_A);
}

/** Changes the directions on a sold line (re-print a label). */
function idev_store_line_label_save($line_id, $label) {
    global $wpdb;
    $t = idev_store_t('lines');
    $info = json_decode((string) $wpdb->get_var($wpdb->prepare("SELECT info FROM $t WHERE id = %d", $line_id)) ?: '{}', true) ?: [];
    $info['l'] = idev_store_label_clean($label);
    return $wpdb->update($t, ['info' => wp_json_encode(array_filter($info), JSON_UNESCAPED_UNICODE)], ['id' => $line_id]) !== false;
}
