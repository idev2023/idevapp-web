=== iDev Thai Holidays ===
Contributors: idevapp2023
Donate link: https://idevapp.me/
Tags: holidays, thailand, calendar
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Annual Thai public holidays: fixed holidays added automatically, import from Google Calendar, mark which days close the clinics. Used by the clinic

== Description ==

Annual Thai public holidays: fixed holidays added automatically, import from Google Calendar, mark which days close the clinics. Used by the clinic schedule and appointments.

= Features =

* Automatic fixed holidays each year
* Import Thai holidays from Google Calendar
* Closed / open per holiday
* Shortcode [idev_holidays]

Thai and English interface. Works with any theme. Part of the iDevApp plugin suite for hospitals and clinics — all iDev plugins appear under the **iDevApp** menu.

== Installation ==

1. Plugins → Add New → Upload Plugin, choose the zip, Install, Activate.
2. Open **iDevApp** in the admin menu for settings.

== Changelog ==

= 1.0.2 =
* Dates show the Buddhist year (พ.ศ.) and Thai month names on Thai pages, and the Gregorian year on English pages, everywhere WordPress formats a date.

= 1.0.0 =
* First release.
