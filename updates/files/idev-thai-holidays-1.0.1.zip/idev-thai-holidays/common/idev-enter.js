/* iDevApp: Enter moves to the next field (like a desktop program) instead of sending the form.
   Inside .idev-wrap only. Search boxes (type=search) keep their own Enter (scan / pick the first result).
   Textareas keep Enter for a new line; Ctrl+Enter there moves on. Add data-enter="submit" to opt out. */
(function () {
  'use strict';
  var SKIP = /^(search|submit|button|checkbox|radio|file|hidden|reset|image|color|range)$/;
  function fields(scope) {
    return [].slice.call(scope.querySelectorAll('input,select,textarea,button')).filter(function (f) {
      if (f.disabled || f.readOnly || f.tabIndex < 0 || f.type === 'hidden') return false;
      if (f.closest('[hidden]') || f.closest('details:not([open]) > :not(summary)')) return false;
      var r = f.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    });
  }
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' || e.isComposing || e.altKey || e.shiftKey) return;
    var t = e.target;
    if (!t.closest || !t.closest('.idev-wrap') || t.closest('[data-enter="submit"]')) return;
    var tag = t.tagName;
    if (tag === 'TEXTAREA' && !e.ctrlKey && !e.metaKey) return;
    if (tag === 'INPUT' && SKIP.test(t.type)) return;
    if (tag !== 'INPUT' && tag !== 'SELECT' && tag !== 'TEXTAREA') return;
    e.preventDefault();
    var scope = t.form || t.closest('.idev-card') || t.closest('.idev-wrap');
    var list = fields(scope), i = list.indexOf(t);
    for (var j = i + 1; j < list.length; j++) {
      var n = list[j];
      if (n.tagName === 'BUTTON' && !n.matches('.button-primary,[type=submit]')) continue;
      n.focus();
      if (n.select && n.tagName === 'INPUT' && !SKIP.test(n.type)) try { n.select(); } catch (x) { /* number inputs in some browsers */ }
      return;
    }
  }, true);
})();
