<?php
/**
 * iDevApp QR Code encoder (byte mode, versions 1–40, all error-correction levels, automatic mask).
 * Algorithm after the QR Code specification (ISO/IEC 18004) as explained by Project Nayuki (MIT).
 */
defined('ABSPATH') || exit;

if (!class_exists('IDev_QR')) :
final class IDev_QR {
    const ECC = ['L' => 0, 'M' => 1, 'Q' => 2, 'H' => 3];
    const FORMAT_BITS = ['L' => 1, 'M' => 0, 'Q' => 3, 'H' => 2];
    const ECC_PER_BLOCK = [
        [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
        [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
        [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
        [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    ];
    const NUM_BLOCKS = [
        [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],
        [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],
        [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68],
        [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81],
    ];

    private $size; private $version; private $ecl;
    private $mod = []; private $fn = [];

    /** Matrix of booleans (true = dark) for $text (UTF-8 bytes). */
    public static function matrix($text, $ecl = 'M') {
        $ecl = isset(self::ECC[$ecl]) ? $ecl : 'M';
        $bytes = array_values(unpack('C*', (string) $text) ?: []);
        for ($v = 1; $v <= 40; $v++) {
            $cap = self::dataCodewords($v, $ecl) * 8;
            $need = 4 + ($v < 10 ? 8 : 16) + 8 * count($bytes);
            if ($need <= $cap) break;
        }
        if ($v > 40) throw new InvalidArgumentException('Text too long for a QR code');
        // Boost error correction when it still fits.
        foreach (['M', 'Q', 'H'] as $better) if (self::ECC[$better] > self::ECC[$ecl] && $need <= self::dataCodewords($v, $better) * 8) $ecl = $better;
        $bits = [];
        $put = function ($val, $len) use (&$bits) { for ($i = $len - 1; $i >= 0; $i--) $bits[] = ($val >> $i) & 1; };
        $put(4, 4);
        $put(count($bytes), $v < 10 ? 8 : 16);
        foreach ($bytes as $b) $put($b, 8);
        $cap = self::dataCodewords($v, $ecl) * 8;
        $put(0, min(4, $cap - count($bits)));
        $put(0, (8 - count($bits) % 8) % 8);
        for ($pad = 0xEC; count($bits) < $cap; $pad ^= 0xEC ^ 0x11) $put($pad, 8);
        $data = [];
        foreach (array_chunk($bits, 8) as $chunk) { $n = 0; foreach ($chunk as $bit) $n = ($n << 1) | $bit; $data[] = $n; }
        $qr = new self($v, $ecl);
        return $qr->build($data);
    }

    private static function rawModules($v) {
        $r = (16 * $v + 128) * $v + 64;
        if ($v >= 2) { $n = intdiv($v, 7) + 2; $r -= (25 * $n - 10) * $n - 55; if ($v >= 7) $r -= 36; }
        return $r;
    }
    private static function dataCodewords($v, $ecl) {
        $e = self::ECC[$ecl];
        return intdiv(self::rawModules($v), 8) - self::ECC_PER_BLOCK[$e][$v] * self::NUM_BLOCKS[$e][$v];
    }

    private function __construct($version, $ecl) {
        $this->version = $version; $this->ecl = $ecl; $this->size = $version * 4 + 17;
        $this->mod = array_fill(0, $this->size, array_fill(0, $this->size, false));
        $this->fn = $this->mod;
    }

    private function build($data) {
        $this->drawFunctionPatterns();
        $all = $this->addEcc($data);
        $this->drawCodewords($all);
        $best = 0; $bestScore = PHP_INT_MAX;
        for ($m = 0; $m < 8; $m++) {
            $this->applyMask($m); $this->drawFormat($m);
            $s = $this->penalty();
            if ($s < $bestScore) { $best = $m; $bestScore = $s; }
            $this->applyMask($m);
        }
        $this->applyMask($best); $this->drawFormat($best);
        return $this->mod;
    }

    private function set($x, $y, $dark) { $this->mod[$y][$x] = (bool) $dark; $this->fn[$y][$x] = true; }

    private function drawFunctionPatterns() {
        $n = $this->size;
        for ($i = 0; $i < $n; $i++) { $this->set(6, $i, $i % 2 === 0); $this->set($i, 6, $i % 2 === 0); }
        foreach ([[3, 3], [$n - 4, 3], [3, $n - 4]] as [$cx, $cy]) {
            for ($dy = -4; $dy <= 4; $dy++) for ($dx = -4; $dx <= 4; $dx++) {
                $d = max(abs($dx), abs($dy)); $x = $cx + $dx; $y = $cy + $dy;
                if ($x >= 0 && $x < $n && $y >= 0 && $y < $n) $this->set($x, $y, $d !== 2 && $d !== 4);
            }
        }
        $pos = $this->alignmentPositions(); $c = count($pos);
        for ($i = 0; $i < $c; $i++) for ($j = 0; $j < $c; $j++) {
            if (($i === 0 && $j === 0) || ($i === 0 && $j === $c - 1) || ($i === $c - 1 && $j === 0)) continue;
            for ($dy = -2; $dy <= 2; $dy++) for ($dx = -2; $dx <= 2; $dx++) $this->set($pos[$i] + $dx, $pos[$j] + $dy, max(abs($dx), abs($dy)) !== 1);
        }
        $this->drawFormat(0);
        if ($this->version >= 7) {
            $rem = $this->version;
            for ($i = 0; $i < 12; $i++) $rem = ($rem << 1) ^ (($rem >> 11) * 0x1F25);
            $bits = ($this->version << 12) | $rem;
            for ($i = 0; $i < 18; $i++) {
                $b = ($bits >> $i) & 1; $a = $n - 11 + $i % 3; $bb = intdiv($i, 3);
                $this->set($a, $bb, $b); $this->set($bb, $a, $b);
            }
        }
    }
    private function alignmentPositions() {
        if ($this->version === 1) return [];
        $num = intdiv($this->version, 7) + 2;
        $step = $this->version === 32 ? 26 : (int) (ceil(($this->version * 4 + 4) / ($num * 2 - 2)) * 2);
        $res = [6];
        for ($pos = $this->size - 7; count($res) < $num; $pos -= $step) array_splice($res, 1, 0, [$pos]);
        return $res;
    }
    private function drawFormat($mask) {
        $data = (self::FORMAT_BITS[$this->ecl] << 3) | $mask;
        $rem = $data;
        for ($i = 0; $i < 10; $i++) $rem = ($rem << 1) ^ (($rem >> 9) * 0x537);
        $bits = (($data << 10) | $rem) ^ 0x5412;
        $n = $this->size;
        $b = function ($i) use ($bits) { return ($bits >> $i) & 1; };
        for ($i = 0; $i <= 5; $i++) $this->set(8, $i, $b($i));
        $this->set(8, 7, $b(6)); $this->set(8, 8, $b(7)); $this->set(7, 8, $b(8));
        for ($i = 9; $i < 15; $i++) $this->set(14 - $i, 8, $b($i));
        for ($i = 0; $i < 8; $i++) $this->set($n - 1 - $i, 8, $b($i));
        for ($i = 8; $i < 15; $i++) $this->set(8, $n - 15 + $i, $b($i));
        $this->set(8, $n - 8, true);
    }

    private function addEcc($data) {
        $e = self::ECC[$this->ecl]; $v = $this->version;
        $numBlocks = self::NUM_BLOCKS[$e][$v]; $eccLen = self::ECC_PER_BLOCK[$e][$v];
        $raw = intdiv(self::rawModules($v), 8);
        $numShort = $numBlocks - $raw % $numBlocks; $shortLen = intdiv($raw, $numBlocks);
        $div = self::rsDivisor($eccLen);
        $blocks = []; $k = 0;
        for ($i = 0; $i < $numBlocks; $i++) {
            $len = $shortLen - $eccLen + ($i < $numShort ? 0 : 1);
            $dat = array_slice($data, $k, $len); $k += $len;
            $ecc = self::rsRemainder($dat, $div);
            if ($i < $numShort) $dat[] = 0;
            $blocks[] = array_merge($dat, $ecc);
        }
        $out = [];
        $blockLen = count($blocks[0]);
        for ($i = 0; $i < $blockLen; $i++) foreach ($blocks as $j => $blk) {
            if ($i !== $shortLen - $eccLen || $j >= $numShort) $out[] = $blk[$i];
        }
        return $out;
    }
    private static function gfMul($x, $y) {
        $z = 0;
        for ($i = 7; $i >= 0; $i--) { $z = ($z << 1) ^ (($z >> 7) * 0x11D); $z ^= (($y >> $i) & 1) * $x; }
        return $z & 0xFF;
    }
    private static function rsDivisor($degree) {
        $r = array_fill(0, $degree, 0); $r[$degree - 1] = 1; $root = 1;
        for ($i = 0; $i < $degree; $i++) {
            for ($j = 0; $j < $degree; $j++) { $r[$j] = self::gfMul($r[$j], $root); if ($j + 1 < $degree) $r[$j] ^= $r[$j + 1]; }
            $root = self::gfMul($root, 0x02);
        }
        return $r;
    }
    private static function rsRemainder($data, $div) {
        $r = array_fill(0, count($div), 0);
        foreach ($data as $b) {
            $f = $b ^ array_shift($r); $r[] = 0;
            foreach ($div as $i => $c) $r[$i] ^= self::gfMul($c, $f);
        }
        return $r;
    }

    private function drawCodewords($data) {
        $n = $this->size; $i = 0; $total = count($data) * 8;
        for ($right = $n - 1; $right >= 1; $right -= 2) {
            if ($right === 6) $right = 5;
            for ($vert = 0; $vert < $n; $vert++) for ($j = 0; $j < 2; $j++) {
                $x = $right - $j; $up = (($right + 1) & 2) === 0; $y = $up ? $n - 1 - $vert : $vert;
                if (!$this->fn[$y][$x] && $i < $total) { $this->mod[$y][$x] = (($data[$i >> 3] >> (7 - ($i & 7))) & 1) === 1; $i++; }
            }
        }
    }
    private function applyMask($m) {
        $n = $this->size;
        for ($y = 0; $y < $n; $y++) for ($x = 0; $x < $n; $x++) {
            if ($this->fn[$y][$x]) continue;
            switch ($m) {
                case 0: $inv = ($x + $y) % 2 === 0; break;
                case 1: $inv = $y % 2 === 0; break;
                case 2: $inv = $x % 3 === 0; break;
                case 3: $inv = ($x + $y) % 3 === 0; break;
                case 4: $inv = (intdiv($x, 3) + intdiv($y, 2)) % 2 === 0; break;
                case 5: $inv = $x * $y % 2 + $x * $y % 3 === 0; break;
                case 6: $inv = ($x * $y % 2 + $x * $y % 3) % 2 === 0; break;
                default: $inv = (($x + $y) % 2 + $x * $y % 3) % 2 === 0;
            }
            if ($inv) $this->mod[$y][$x] = !$this->mod[$y][$x];
        }
    }
    private function penalty() {
        $n = $this->size; $score = 0; $dark = 0;
        $lines = [];
        for ($y = 0; $y < $n; $y++) $lines[] = $this->mod[$y];
        for ($x = 0; $x < $n; $x++) $lines[] = array_column($this->mod, $x);
        foreach ($lines as $line) {
            $run = 1;
            for ($i = 1; $i <= $n; $i++) {
                if ($i < $n && $line[$i] === $line[$i - 1]) { $run++; continue; }
                if ($run >= 5) $score += 3 + ($run - 5);
                $run = 1;
            }
            $s = implode('', array_map('intval', $line));
            $score += 40 * (substr_count('0000' . $s . '0000', '00001011101') + substr_count('0000' . $s . '0000', '10111010000'));
        }
        for ($y = 0; $y < $n - 1; $y++) for ($x = 0; $x < $n - 1; $x++) {
            $c = $this->mod[$y][$x];
            if ($c === $this->mod[$y][$x + 1] && $c === $this->mod[$y + 1][$x] && $c === $this->mod[$y + 1][$x + 1]) $score += 3;
        }
        foreach ($this->mod as $row) foreach ($row as $c) if ($c) $dark++;
        $total = $n * $n;
        $k = (int) ceil(abs($dark * 20 - $total * 10) / $total) - 1;
        return $score + max(0, $k) * 10;
    }
}
endif;

/** QR code as a GD image (caller destroys it). $scale = pixels per module, $quiet = modules of margin. */
function idev_qr_image($text, $scale = 8, $quiet = 2, $ecl = 'M', $dark = [0, 0, 0], $light = [255, 255, 255]) {
    $m = IDev_QR::matrix($text, $ecl);
    $n = count($m);
    $px = ($n + 2 * $quiet) * $scale;
    $im = imagecreatetruecolor($px, $px);
    $bg = imagecolorallocate($im, $light[0], $light[1], $light[2]);
    $fg = imagecolorallocate($im, $dark[0], $dark[1], $dark[2]);
    imagefill($im, 0, 0, $bg);
    for ($y = 0; $y < $n; $y++) for ($x = 0; $x < $n; $x++) if ($m[$y][$x]) imagefilledrectangle($im, ($x + $quiet) * $scale, ($y + $quiet) * $scale, ($x + $quiet + 1) * $scale - 1, ($y + $quiet + 1) * $scale - 1, $fg);
    return $im;
}
/** QR code PNG bytes. */
function idev_qr_png($text, $scale = 8, $quiet = 2, $ecl = 'M') {
    $im = idev_qr_image($text, $scale, $quiet, $ecl);
    ob_start(); imagepng($im); $png = ob_get_clean();
    imagedestroy($im);
    return $png;
}
/** QR code as inline SVG (crisp at any size). */
function idev_qr_svg($text, $size = 160, $ecl = 'M', $color = '#000') {
    $m = IDev_QR::matrix($text, $ecl);
    $n = count($m); $q = 2; $path = '';
    for ($y = 0; $y < $n; $y++) for ($x = 0; $x < $n; $x++) if ($m[$y][$x]) $path .= 'M' . ($x + $q) . ' ' . ($y + $q) . 'h1v1h-1z';
    $w = $n + 2 * $q;
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $w . ' ' . $w . '" width="' . (int) $size . '" height="' . (int) $size . '" shape-rendering="crispEdges" role="img" aria-label="QR"><rect width="100%" height="100%" fill="#fff"/><path fill="' . esc_attr($color) . '" d="' . $path . '"/></svg>';
}

/** Code 128 (set B) as SVG (no GD needed). */
if (!function_exists('idev_code128_svg')) :
function idev_code128_svg($text, $height = 40, $module = 1.4) {
    $patterns = ['212222','222122','222221','121223','121322','131222','122213','122312','132212','221213','221312','231212','112232','122132','122231','113222','123122','123221','223211','221132','221231','213212','223112','312131','311222','321122','321221','312212','322112','322211','212123','212321','232121','111323','131123','131321','112313','132113','132311','211313','231113','231311','112133','112331','132131','113123','113321','133121','313121','211331','231131','213113','213311','213131','311123','311321','331121','312113','312311','332111','314111','221411','431111','111224','111422','121124','121421','141122','141221','112214','112412','122114','122411','142112','142211','241211','221114','413111','241112','134111','111242','121142','121241','114212','124112','124211','411212','421112','421211','212141','214121','412121','111143','111341','131141','114113','114311','411113','411311','113141','114131','311141','411131','211412','211214','211232','2331112'];
    $text = preg_replace('/[^\x20-\x7E]/', '', (string) $text);
    $codes = [104];
    foreach (str_split($text) as $ch) $codes[] = ord($ch) - 32;
    $sum = 104;
    foreach (array_slice($codes, 1) as $i => $c) $sum += $c * ($i + 1);
    $codes[] = $sum % 103;
    $codes[] = 106;
    $x = 10; $rects = '';
    foreach ($codes as $c) foreach (str_split($patterns[$c]) as $i => $w) { if ($i % 2 === 0) $rects .= '<rect x="' . $x . '" width="' . $w . '" height="' . $height . '"/>'; $x += (int) $w; }
    $W = $x + 10;
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $W . ' ' . $height . '" width="' . round($W * $module) . '" height="' . (int) $height . '" preserveAspectRatio="none" shape-rendering="crispEdges" role="img" aria-label="' . esc_attr($text) . '"><rect width="100%" height="100%" fill="#fff"/><g fill="#000">' . $rects . '</g></svg>';
}
endif;

/** Code 128 (set B) barcode as a GD image. */
if (!function_exists('idev_code128_image')) :
function idev_code128_image($text, $height = 70, $module = 2) {
    $patterns = ['212222','222122','222221','121223','121322','131222','122213','122312','132212','221213','221312','231212','112232','122132','122231','113222','123122','123221','223211','221132','221231','213212','223112','312131','311222','321122','321221','312212','322112','322211','212123','212321','232121','111323','131123','131321','112313','132113','132311','211313','231113','231311','112133','112331','132131','113123','113321','133121','313121','211331','231131','213113','213311','213131','311123','311321','331121','312113','312311','332111','314111','221411','431111','111224','111422','121124','121421','141122','141221','112214','112412','122114','122411','142112','142211','241211','221114','413111','241112','134111','111242','121142','121241','114212','124112','124211','411212','421112','421211','212141','214121','412121','111143','111341','131141','114113','114311','411113','411311','113141','114131','311141','411131','211412','211214','211232','2331112'];
    $text = preg_replace('/[^\x20-\x7E]/', '', (string) $text);
    $codes = [104]; // start B
    foreach (str_split($text) as $char) $codes[] = ord($char) - 32;
    $sum = 104;
    foreach (array_slice($codes, 1) as $i => $code) $sum += $code * ($i + 1);
    $codes[] = $sum % 103;
    $codes[] = 106; // stop
    $bars = '';
    foreach ($codes as $code) $bars .= $patterns[$code];
    $width = 0;
    foreach (str_split($bars) as $w) $width += (int) $w;
    $quiet = 10;
    $image = imagecreate(($width + $quiet * 2) * $module, $height);
    $white = imagecolorallocate($image, 255, 255, 255);
    $black = imagecolorallocate($image, 0, 0, 0);
    imagefill($image, 0, 0, $white);
    $x = $quiet * $module;
    foreach (str_split($bars) as $i => $w) {
        $w = (int) $w * $module;
        if ($i % 2 === 0) imagefilledrectangle($image, $x, 0, $x + $w - 1, $height - 1, $black);
        $x += $w;
    }
    return $image;
}
/** Code 128 barcode PNG bytes. */
function idev_code128_png($text, $height = 70, $module = 2) {
    $im = idev_code128_image($text, $height, $module);
    ob_start(); imagepng($im); imagedestroy($im);
    return ob_get_clean();
}
endif;
