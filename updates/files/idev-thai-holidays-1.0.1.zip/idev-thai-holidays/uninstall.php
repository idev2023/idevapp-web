<?php
defined('WP_UNINSTALL_PLUGIN') || exit;
global $wpdb;
if (get_option('idev_holidays_keep_data', '1') !== '1') $wpdb->query('DROP TABLE IF EXISTS ' . $wpdb->prefix . 'idev_holidays');
delete_option('idev_hol_db');
