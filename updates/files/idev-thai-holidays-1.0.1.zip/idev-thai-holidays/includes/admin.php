<?php
defined('ABSPATH') || exit;

add_action('init', function () {
    load_plugin_textdomain('idev-thai-holidays', false, dirname(plugin_basename(IDEV_HOL_FILE)) . '/languages');
    idev_register_plugin('idev-thai-holidays', ['name' => 'iDev Thai Holidays', 'version' => IDEV_HOL_VERSION, 'description' => __('Annual holidays, filled in automatically.', 'idev-thai-holidays'), 'settings' => admin_url('admin.php?page=idev-holidays'), 'docs' => 'https://idevapp.me/plugins/idev-thai-holidays']);
});
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_HOL_FILE, admin_url('admin.php?page=idev-holidays'), 'https://idevapp.me/plugins/idev-thai-holidays'); });

add_action('admin_menu', function () {
    add_submenu_page('idevapp', __('Annual holidays', 'idev-thai-holidays'), __('Annual holidays', 'idev-thai-holidays'), 'edit_posts', 'idev-holidays', 'idev_hol_page');
});

add_action('admin_post_idev_holiday', function () {
    if (!current_user_can('edit_posts') || !check_admin_referer('idev_holiday')) wp_die(esc_html__('Not allowed.', 'idev-thai-holidays'));
    global $wpdb;
    $table = idev_hol_table();
    $year = (int) ($_POST['year'] ?? gmdate('Y'));
    $do = sanitize_key($_POST['do'] ?? '');
    $back = ['page' => 'idev-holidays', 'year' => $year];
    if ($do === 'fill') {
        try { $back['imported'] = sanitize_key($_POST['source'] ?? '') === 'google' ? idev_holidays_import_google($year) : idev_holidays_add_fixed($year); }
        catch (Exception $e) { $back['error'] = 'google'; }
    } elseif ($do === 'delete') {
        $wpdb->delete($table, ['id' => (int) $_POST['id']]);
        $back['deleted'] = 1;
    } elseif ($do === 'settings' && current_user_can('manage_options')) {
        update_option('idev_holidays', ['auto' => empty($_POST['auto']) ? '0' : '1', 'google' => empty($_POST['google']) ? '0' : '1', 'country' => 'th']);
        $back['saved'] = 1;
    } else {
        $date = sanitize_text_field(wp_unslash($_POST['holiday_date'] ?? ''));
        $name = mb_substr(sanitize_text_field(wp_unslash($_POST['name'] ?? '')), 0, 200);
        $data = ['holiday_date' => $date, 'name' => $name, 'name_en' => mb_substr(sanitize_text_field(wp_unslash($_POST['name_en'] ?? '')), 0, 200), 'closes_clinics' => empty($_POST['closes_clinics']) ? 0 : 1];
        $id = (int) ($_POST['id'] ?? 0);
        if (!idev_is_valid_date($date) || $name === '') $back['error'] = 'invalid';
        elseif ((int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE holiday_date=%s AND name=%s AND id<>%d", $date, $name, $id))) $back['error'] = 'duplicate';
        elseif ($id) { $wpdb->update($table, $data, ['id' => $id]); $back['saved'] = 1; }
        else { $wpdb->insert($table, $data + ['source' => 'manual']); $back['saved'] = 1; }
    }
    wp_safe_redirect(add_query_arg($back, admin_url('admin.php')));
    exit;
});

function idev_hol_form_open($year, $extra = '') {
    return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"' . $extra . '>' . wp_nonce_field('idev_holiday', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idev_holiday"><input type="hidden" name="year" value="' . (int) $year . '">';
}

function idev_hol_page() {
    $this_year = (int) substr(idev_today(), 0, 4);
    $year = isset($_GET['year']) && preg_match('/^\d{4}$/', $_GET['year']) ? (int) $_GET['year'] : $this_year;
    idev_holidays_ensure_years([$year]);
    $rows = idev_holidays_get("{$year}-01-01", "{$year}-12-31");
    $lang = strpos(get_user_locale(), 'th') === 0 ? 'th' : 'en';
    $year_label = function ($y) use ($lang) { return $lang === 'th' ? 'พ.ศ. ' . ($y + 543) . ' (' . $y . ')' : (string) $y; };
    $sources = ['builtin' => __('Automatic', 'idev-thai-holidays'), 'google' => 'Google', 'manual' => __('Added by hand', 'idev-thai-holidays')];
    $errors = ['invalid' => __('Choose a date and type the holiday name.', 'idev-thai-holidays'), 'duplicate' => __('This holiday already exists on that day.', 'idev-thai-holidays'), 'google' => __('Could not reach Google Calendar (the server may have no internet access). You can add holidays by hand.', 'idev-thai-holidays')];
    idev_admin_header(__('Annual holidays', 'idev-thai-holidays') . ' ' . $year_label($year), __('Days marked "closes clinics" replace the clinic times in iDev Clinic Schedule.', 'idev-thai-holidays'));
    foreach (['saved' => __('Saved.', 'idev-thai-holidays'), 'deleted' => __('Deleted.', 'idev-thai-holidays')] as $k => $t) if (isset($_GET[$k])) echo '<div class="notice notice-success"><p>' . esc_html($t) . '</p></div>';
    if (isset($_GET['imported'])) echo '<div class="notice notice-success"><p>' . esc_html(sprintf(__('%d holidays added (existing days are not duplicated).', 'idev-thai-holidays'), (int) $_GET['imported'])) . '</p></div>';
    if (isset($_GET['error'])) echo '<div class="notice notice-error"><p>' . esc_html($errors[$_GET['error']] ?? '') . '</p></div>';
    $nav = admin_url('admin.php?page=idev-holidays&year=');
    echo '<p><a class="button" href="' . esc_url($nav . ($year - 1)) . '">← ' . esc_html($year_label($year - 1)) . '</a> <strong style="margin:0 10px">' . esc_html($year_label($year)) . '</strong> <a class="button" href="' . esc_url($nav . ($year + 1)) . '">' . esc_html($year_label($year + 1)) . ' →</a></p>';
    echo '<div class="idev-box"><h2>' . esc_html__('Add a holiday', 'idev-thai-holidays') . '</h2>' . idev_hol_form_open($year, ' class="idev-hol-add"');
    echo '<label>' . esc_html__('Date', 'idev-thai-holidays') . '<input type="date" name="holiday_date" required value="' . $year . '-01-01"></label><label>' . esc_html__('Name (Thai)', 'idev-thai-holidays') . '<input name="name" required></label><label>' . esc_html__('Name (English)', 'idev-thai-holidays') . '<input name="name_en"></label><label class="idev-inline"><input type="checkbox" name="closes_clinics" value="1" checked> ' . esc_html__('Closes clinics', 'idev-thai-holidays') . '</label><button class="button button-primary">' . esc_html__('Add', 'idev-thai-holidays') . '</button></form>';
    echo '<p>' . idev_hol_form_open($year, ' style="display:inline"') . '<input type="hidden" name="do" value="fill"><input type="hidden" name="source" value="builtin"><button class="button">↻ ' . esc_html__('Fill in fixed public holidays', 'idev-thai-holidays') . '</button></form> ';
    echo idev_hol_form_open($year, ' style="display:inline"') . '<input type="hidden" name="do" value="fill"><input type="hidden" name="source" value="google"><button class="button">⬇ ' . esc_html__('Import Thai holidays from Google Calendar', 'idev-thai-holidays') . '</button></form></p>';
    echo '<p class="description">' . esc_html__('Lunar holidays (Makha, Visakha, Asanha Bucha, Khao Phansa) and substitution days change every year: check them when the cabinet announces them.', 'idev-thai-holidays') . '</p></div>';
    echo '<div class="idev-box"><h2>' . esc_html(sprintf(__('Holidays (%d)', 'idev-thai-holidays'), count($rows))) . '</h2>';
    if (!$rows) echo '<p>' . esc_html__('No holidays this year.', 'idev-thai-holidays') . '</p>';
    foreach ($rows as $r) {
        echo '<div class="idev-hol-row">' . idev_hol_form_open($year) . '<input type="hidden" name="id" value="' . (int) $r['id'] . '">';
        echo '<span class="idev-hol-date"><strong>' . esc_html(idev_format_day($r['holiday_date'], $lang, true)) . '</strong><small>' . esc_html($sources[$r['source']] ?? $r['source']) . '</small></span>';
        echo '<input type="date" name="holiday_date" value="' . esc_attr($r['holiday_date']) . '"><input name="name" value="' . esc_attr($r['name']) . '"><input name="name_en" value="' . esc_attr($r['name_en']) . '" placeholder="English">';
        echo '<label class="idev-inline"><input type="checkbox" name="closes_clinics" value="1"' . checked($r['closes_clinics'], true, false) . '> ' . esc_html__('Closes clinics', 'idev-thai-holidays') . '</label><button class="button">' . esc_html__('Save', 'idev-thai-holidays') . '</button></form>';
        echo idev_hol_form_open($year, ' onsubmit="return confirm(\'' . esc_js(__('Delete this holiday?', 'idev-thai-holidays')) . '\')"') . '<input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="' . (int) $r['id'] . '"><button class="button-link-delete">' . esc_html__('Delete', 'idev-thai-holidays') . '</button></form></div>';
    }
    echo '</div>';
    if (current_user_can('manage_options')) {
        $s = idev_hol_settings();
        echo '<div class="idev-box"><h2>' . esc_html__('Settings', 'idev-thai-holidays') . '</h2>' . idev_hol_form_open($year) . '<input type="hidden" name="do" value="settings">';
        echo '<p><label><input type="checkbox" name="auto" value="1"' . checked($s['auto'], '1', false) . '> ' . esc_html__('Fill in each new year automatically (once per year)', 'idev-thai-holidays') . '</label><br><label><input type="checkbox" name="google" value="1"' . checked($s['google'], '1', false) . '> ' . esc_html__('Also import from Google Calendar (needs internet access on the server)', 'idev-thai-holidays') . '</label></p>';
        echo '<p class="description">' . esc_html__('Show a list on a page: [idev_holidays] or [idev_holidays year="2026" only_closed="1"].', 'idev-thai-holidays') . '</p><button class="button">' . esc_html__('Save settings', 'idev-thai-holidays') . '</button></form></div>';
    }
    echo '<style>.idev-hol-add{display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end}.idev-hol-add label{display:flex;flex-direction:column;font-weight:600;gap:4px}.idev-inline{flex-direction:row!important;align-items:center}.idev-hol-row{display:flex;align-items:center;gap:10px;border-top:1px solid #f0f0f1;padding:8px 0}.idev-hol-row form:first-child{display:flex;flex-wrap:wrap;gap:8px;align-items:center;flex:1}.idev-hol-date{min-width:170px}.idev-hol-date strong,.idev-hol-date small{display:block}.idev-hol-date small{color:#646970}</style></div>';
}
