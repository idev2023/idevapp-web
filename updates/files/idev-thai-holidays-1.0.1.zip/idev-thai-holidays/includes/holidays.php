<?php
defined('ABSPATH') || exit;

function idev_hol_table() { global $wpdb; return $wpdb->prefix . 'idev_holidays'; }

function idev_hol_install() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $table = idev_hol_table();
    dbDelta("CREATE TABLE {$table} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  holiday_date date NOT NULL,
  name varchar(200) NOT NULL,
  name_en varchar(200) NOT NULL DEFAULT '',
  closes_clinics tinyint(1) NOT NULL DEFAULT 1,
  source varchar(20) NOT NULL DEFAULT 'manual',
  PRIMARY KEY  (id),
  UNIQUE KEY holiday_date_name (holiday_date,name(150)),
  KEY holiday_date (holiday_date)
) {$wpdb->get_charset_collate()};");
    // Bring over holidays from the Andaman Hub plugin (once).
    $old = $wpdb->prefix . 'ah_holidays';
    if (!get_option('idev_hol_migrated') && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $old)) === $old) {
        $wpdb->query("INSERT IGNORE INTO {$table} (holiday_date, name, name_en, closes_clinics, source) SELECT holiday_date, name, name_en, closes_clinics, source FROM {$old}");
        foreach ($wpdb->get_col("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'ah\\_holidays\\_seeded\\_%'") as $name) add_option(str_replace('ah_holidays_seeded_', 'idev_hol_seeded_', $name), '1', '', false);
        update_option('idev_hol_migrated', 1, false);
    }
    update_option('idev_hol_db', IDEV_HOL_VERSION);
}

function idev_hol_settings() {
    $s = get_option('idev_holidays', []);
    return array_merge(['auto' => '1', 'google' => '1', 'country' => 'th'], is_array($s) ? $s : []);
}

/** Public holidays of Thailand that fall on the same date every year. */
function idev_hol_fixed() {
    return [
        ['01-01', 'วันขึ้นปีใหม่', "New Year's Day"], ['04-06', 'วันจักรี', 'Chakri Memorial Day'],
        ['04-13', 'วันสงกรานต์', 'Songkran Festival'], ['04-14', 'วันสงกรานต์', 'Songkran Festival'], ['04-15', 'วันสงกรานต์', 'Songkran Festival'],
        ['05-01', 'วันแรงงานแห่งชาติ', 'National Labour Day'], ['05-04', 'วันฉัตรมงคล', 'Coronation Day'],
        ['06-03', 'วันเฉลิมพระชนมพรรษาสมเด็จพระราชินี', "Queen Suthida's Birthday"], ['07-28', 'วันเฉลิมพระชนมพรรษาพระบาทสมเด็จพระเจ้าอยู่หัว', "King's Birthday"],
        ['08-12', 'วันแม่แห่งชาติ', "Mother's Day"], ['10-13', 'วันนวมินทรมหาราช', 'King Bhumibol Memorial Day'], ['10-23', 'วันปิยมหาราช', 'Chulalongkorn Day'],
        ['12-05', 'วันพ่อแห่งชาติ', "Father's Day"], ['12-10', 'วันรัฐธรรมนูญ', 'Constitution Day'], ['12-31', 'วันสิ้นปี', "New Year's Eve"],
    ];
}

/** Holidays between two dates (inclusive): [id, holiday_date, name, name_en, closes_clinics, source]. */
function idev_holidays_get($from, $to) {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare('SELECT id, holiday_date, name, name_en, closes_clinics, source FROM ' . idev_hol_table() . ' WHERE holiday_date BETWEEN %s AND %s ORDER BY holiday_date, name', $from, $to), ARRAY_A) ?: [];
    foreach ($rows as &$row) { $row['closes_clinics'] = (bool) (int) $row['closes_clinics']; $row['holiday_date'] = substr($row['holiday_date'], 0, 10); }
    return $rows;
}

/** The holiday that closes clinics on this date, or null. */
function idev_holiday_closed($date) {
    idev_holidays_ensure_years([(int) substr($date, 0, 4)]);
    foreach (idev_holidays_get($date, $date) as $h) if ($h['closes_clinics']) return $h;
    return null;
}

function idev_holiday_insert($date, $name, $name_en = '', $closes = true, $source = 'manual') {
    global $wpdb;
    $table = idev_hol_table();
    if ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE holiday_date=%s AND name=%s", $date, $name))) return false;
    return (bool) $wpdb->insert($table, ['holiday_date' => $date, 'name' => mb_substr($name, 0, 200), 'name_en' => mb_substr($name_en, 0, 200), 'closes_clinics' => $closes ? 1 : 0, 'source' => $source]);
}

function idev_holidays_add_fixed($year) {
    $added = 0;
    foreach (idev_hol_fixed() as [$md, $name, $en]) $added += idev_holiday_insert("{$year}-{$md}", $name, $en, true, 'builtin') ? 1 : 0;
    return $added;
}

function idev_hol_parse_ics($text) {
    $lines = preg_split('/\r?\n/', preg_replace('/\r?\n[ \t]/', '', (string) $text));
    $events = []; $current = null;
    foreach ($lines as $line) {
        if ($line === 'BEGIN:VEVENT') $current = [];
        elseif ($line === 'END:VEVENT') { if (!empty($current['date']) && !empty($current['summary'])) $events[] = $current + ['description' => '']; $current = null; }
        elseif (is_array($current) && strpos($line, ':') !== false) {
            [$key, $value] = explode(':', $line, 2);
            $value = trim(str_replace(['\\,', '\\n'], [',', "\n"], $value));
            if (strpos($key, 'DTSTART') === 0 && preg_match('/^(\d{4})(\d{2})(\d{2})/', $value, $m)) $current['date'] = "{$m[1]}-{$m[2]}-{$m[3]}";
            elseif ($key === 'SUMMARY') $current['summary'] = $value;
            elseif ($key === 'DESCRIPTION') $current['description'] = $value;
        }
    }
    return $events;
}

function idev_hol_fetch($lang) {
    $response = wp_remote_get("https://calendar.google.com/calendar/ical/{$lang}.th%23holiday%40group.v.calendar.google.com/public/basic.ics", ['timeout' => 8]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) throw new Exception('Google Calendar unreachable');
    return idev_hol_parse_ics(wp_remote_retrieve_body($response));
}

/** Thai public holidays incl. lunar and substitution days from Google's public calendar ("Observance" days are skipped). */
function idev_holidays_import_google($year) {
    $th = idev_hol_fetch('th');
    try { $en = idev_hol_fetch('en'); } catch (Exception $e) { $en = []; }
    $day_off = function ($e) { return !preg_match('/observance|วันสำคัญ/iu', $e['description']); };
    $english = [];
    foreach (array_filter($en, $day_off) as $e) $english[$e['date']] = $e['summary'];
    $added = 0;
    foreach (array_filter($th, $day_off) as $e) if (strpos($e['date'], "{$year}-") === 0) $added += idev_holiday_insert($e['date'], $e['summary'], $english[$e['date']] ?? '', true, 'google') ? 1 : 0;
    return $added;
}

/** First time a year is needed, fill it in (once, so deleted days stay deleted). */
function idev_holidays_ensure_years($years) {
    $s = idev_hol_settings();
    if ($s['auto'] !== '1') return;
    foreach (array_unique(array_map('intval', $years)) as $year) {
        if ($year < 2000 || $year > 2100) continue;
        if (!add_option("idev_hol_seeded_{$year}", '1', '', false)) continue;
        idev_holidays_add_fixed($year);
        if ($s['google'] === '1') { try { idev_holidays_import_google($year); } catch (Exception $e) { /* offline: fixed days only */ } }
    }
}

/** [idev_holidays year="2026"] — list of the year's holidays. */
add_shortcode('idev_holidays', function ($atts) {
    $atts = shortcode_atts(['year' => '', 'only_closed' => '0'], $atts);
    $year = preg_match('/^\d{4}$/', $atts['year']) ? (int) $atts['year'] : (int) substr(idev_today(), 0, 4);
    idev_holidays_ensure_years([$year]);
    $rows = idev_holidays_get("{$year}-01-01", "{$year}-12-31");
    if ($atts['only_closed'] === '1') $rows = array_filter($rows, function ($r) { return $r['closes_clinics']; });
    $lang = idev_lang();
    wp_register_style('idev-holidays', false, [], IDEV_HOL_VERSION);
    wp_enqueue_style('idev-holidays');
    wp_add_inline_style('idev-holidays', '.idev-holiday-list{width:100%;border-collapse:collapse;border:1px solid #e3eaec;border-radius:12px;overflow:hidden;font-size:15px}.idev-holiday-list th,.idev-holiday-list td{padding:10px 14px;border-bottom:1px solid #edf1f2;text-align:left}.idev-holiday-list thead th{background:#f4f8f8;font-size:13px}.idev-holiday-list tr:last-child td{border-bottom:0}.idev-holiday-list td:first-child{white-space:nowrap;color:#40535d;width:1%}');
    $html = '<table class="idev-holiday-list"><thead><tr><th>' . esc_html__('Date', 'idev-thai-holidays') . '</th><th>' . esc_html__('Holiday', 'idev-thai-holidays') . '</th></tr></thead><tbody>';
    foreach ($rows as $r) $html .= '<tr><td>' . esc_html(idev_format_day($r['holiday_date'], $lang, true)) . '</td><td>' . esc_html(idev_pick($r['name'], $r['name_en'])) . '</td></tr>';
    return $html . '</tbody></table>';
});
