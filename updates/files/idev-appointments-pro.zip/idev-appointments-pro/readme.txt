=== iDev Appointments Pro ===
Contributors: idevapp
Tags: appointments, clinic, line, sms, hosxp
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.4.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add-on for iDev Appointments: LINE and SMS reminders, waiting list, branches, reports and an optional HOSxP connector.

== Description ==

Needs the free plugin **iDev Appointments** 1.2 or newer. Free trial for 14 days; then a licence key turns the Pro features on.

* **LINE and SMS:** confirmed, moved, cancelled, reminder and same-day messages. SMS through ThaiBulkSMS or any service by webhook; LINE through your LINE Official Account (patients link by sending their appointment reference).
* **Waiting list:** when a day is full, patients leave their name; when a time becomes free (cancelled or moved), the first people in the list are told by LINE, SMS or e-mail.
* **Branches:** each doctor/clinic belongs to a branch; one booking page per branch (?branch=code), branch address and phone in messages, staff limited to their branches, [idev_branches] list.
* **Reports:** appointments by status, no-show and cancellation rates by doctor/clinic and branch, busiest days and hours, booking channel; print and CSV export.
* **HOSxP connector (optional):** a small PHP program inside the hospital writes confirmed, moved and cancelled appointments to the HOSxP appointment table. The website never connects to HOSxP. Using it needs permission from BMS and the hospital; the hospital sets it up, tests it in dry-run mode and checks the data. iDevApp provides the connector as it is and is not responsible for data written to HOSxP.

Licence: 3,900 THB, lifetime, one website (also included in the I-Clinic / I-Drug packages; keys issued for iDev Appointments 1.1 keep working).

== Changelog ==

= 1.4.0 =
* Includes iDev Appointments 1.5.0 (second booking order, doctor sees own or clinic appointments, HN edit and registration recheck).

= 1.3.0 =
* Includes iDev Appointments 1.4.0 (clinic / service steps, ID number, shared places, breaks).

= 1.2.0 =
* HOSxP connector sends the number of patients waiting for each doctor today (counts only) for the doctor's room; HN checked by the records desk is sent to HOSxP. Includes iDev Appointments 1.3.0.

= 1.1.4 =
* Includes iDev Appointments 1.2.4 (patients and status in the month calendar).

= 1.1.3 =
* Includes iDev Appointments 1.2.3 (month calendar for doctors and clinics).

= 1.1.2 =
* Includes iDev Appointments 1.2.2 (new doctor sign-in card).

= 1.0.0 =
* First version.
