<?php
/**
 * Plugin Name:       iDev Bilingual – Thai / English
 * Plugin URI:        https://idevapp.me/plugins/idev-bilingual
 * Description:       Switch the whole site between Thai and English: English title, excerpt and content for posts and pages, English menu labels, category names and site name, plus a TH/EN switcher. Works with any theme.
 * Version:           1.0.2
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-bilingual
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// Loaded once: the same plugin may also be inside an iDevApp package (I-Clinic / I-Drug) or a Pro version.
if (defined('IDEV_BL_VERSION')) return;

define('IDEV_BL_VERSION', '1.0.2');
define('IDEV_BL_FILE', __FILE__);
require_once __DIR__ . '/common/idev-common.php';
require_once __DIR__ . '/includes/core.php';
require_once __DIR__ . '/includes/admin.php';

register_activation_hook(__FILE__, 'idev_bl_activate');
