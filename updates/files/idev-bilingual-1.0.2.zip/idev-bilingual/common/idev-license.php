<?php
/**
 * iDevApp licences. A licence key is signed by iDevApp (Ed25519) and names the product and the website domain,
 * so it is checked here without any call home — it works on hospital intranets and never expires.
 *
 * Key: IDEV1.<base64url(JSON payload)>.<base64url(signature of the payload bytes)>
 * Payload: {"v":1,"p":"medreg","d":"example.com","n":"Customer","id":"L-…","i":"2026-10-27"}
 */
defined('ABSPATH') || exit;

/** iDevApp public keys (newest first). Old keys stay so licences already issued keep working. */
function idev_license_public_keys() {
    return ['mtqDRp9BbDwTafS5BkxW3N0Nl+UhtpU3qPLWbtyJTYE='];
}

/** Products that have a paid licence: [id => [name, plugin, free, pro, price, usage callback]]. */
function idev_register_license($product, $args) { $GLOBALS['idev_license_products'][$product] = $args; }
function idev_license_products() { return $GLOBALS['idev_license_products'] ?? []; }

/** This website's domain as written in licences: lower case, no "www.", no port. */
function idev_license_domain($url = null) {
    // A system installed on a clinic computer is opened by several names (computer name, LAN IP, localhost),
    // so its licence names one fixed local name. Only local names are accepted here, never a public domain.
    if (!$url && defined('IDEV_LICENSE_DOMAIN') && idev_license_is_local_name(IDEV_LICENSE_DOMAIN)) return strtolower(IDEV_LICENSE_DOMAIN);
    $host = strtolower((string) wp_parse_url($url ?: home_url('/'), PHP_URL_HOST));
    return preg_replace('/^www\./', '', $host);
}

/** A name that only exists inside a local network: no dot, .local / .lan / .home / .internal, or a private IP address. */
function idev_license_is_local_name($h) {
    $h = strtolower(trim((string) $h));
    if ($h === '' || !preg_match('/^[a-z0-9.-]+$/', $h)) return false;
    if (strpos($h, '.') === false) return true;
    if (preg_match('/\.(local|lan|home|internal)$/', $h)) return true;
    return filter_var($h, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && !filter_var($h, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
}

function idev_license_b64d($s) { return base64_decode(strtr($s, '-_', '+/') . str_repeat('=', (4 - strlen($s) % 4) % 4), true); }

/** Checks a key. Returns ['ok' => bool, 'data' => payload|null, 'error' => text]. */
function idev_license_check($key, $product = null) {
    $key = trim(preg_replace('/\s+/', '', (string) $key));
    $bad = ['ok' => false, 'data' => null, 'error' => __('This is not an iDevApp licence key.', 'idev-common')];
    $parts = explode('.', $key);
    if (count($parts) !== 3 || $parts[0] !== 'IDEV1') return $bad;
    $payload = idev_license_b64d($parts[1]);
    $sig = idev_license_b64d($parts[2]);
    if ($payload === false || $sig === false || strlen($sig) !== 64) return $bad;
    $valid = false;
    foreach (idev_license_public_keys() as $pk) {
        $pk = base64_decode($pk, true);
        try {
            if ($pk && strlen($pk) === 32 && sodium_crypto_sign_verify_detached($sig, $payload, $pk)) { $valid = true; break; }
        } catch (\Throwable $e) { /* try the next key */ }
    }
    if (!$valid) return ['ok' => false, 'data' => null, 'error' => __('The licence key is damaged or was not issued by iDevApp. Copy it again from the e-mail, the whole line.', 'idev-common')];
    $data = json_decode($payload, true);
    if (!is_array($data) || empty($data['p']) || empty($data['d'])) return $bad;
    if ($product && $data['p'] !== $product) {
        $names = idev_license_products();
        return ['ok' => false, 'data' => $data, 'error' => sprintf(__('This key is for %s.', 'idev-common'), $names[$data['p']]['name'] ?? $data['p'])];
    }
    $site = idev_license_domain();
    if (strtolower(preg_replace('/^www\./', '', $data['d'])) !== $site) {
        return ['ok' => false, 'data' => $data, 'error' => sprintf(__('This key is for the website %1$s, but this website is %2$s. Ask iDevApp to move the licence.', 'idev-common'), $data['d'], $site)];
    }
    return ['ok' => true, 'data' => $data, 'error' => ''];
}

/** The saved licence of a product, checked (cached per request). */
function idev_license($product) {
    static $cache = [];
    if (!isset($cache[$product])) {
        $keys = get_option('idev_licenses', []);
        $key = is_array($keys) ? ($keys[$product] ?? '') : '';
        $cache[$product] = $key === '' ? ['ok' => false, 'data' => null, 'error' => '', 'key' => ''] : idev_license_check($key, $product) + ['key' => $key];
    }
    return $cache[$product];
}
/** A product is licensed by its own key, or by a package key that includes it. */
function idev_is_licensed($product) {
    if (idev_license($product)['ok']) return true;
    if ($product === 'package') return false;
    $pkg = idev_license('package');
    return $pkg['ok'] && in_array($product, (array) ($pkg['data']['inc'] ?? []), true);
}
/** Packages sold by iDevApp (one key opens every plugin in the package). */
function idev_license_packages() {
    return [
        'clinic' => ['name' => 'I-Clinic', 'inc' => ['medreg', 'appt', 'store']],
        'job' => ['name' => 'I-Clinic Pro', 'inc' => ['medreg', 'appt', 'store', 'store_jobs']],
        'pharmacy' => ['name' => 'I-Drug', 'inc' => ['medreg', 'appt', 'store', 'store_pharmacy']],
    ];
}
add_action('init', function () {
    idev_register_license('package', ['name' => 'I-Clinic / I-Drug', 'plugin' => '',
        'free' => '—', 'pro' => __('I-Clinic · I-Clinic Pro · I-Drug: ready-to-use WordPress systems; one key opens every plugin in the set, with installation and one year of support.', 'idev-common'),
        'price' => __('Package', 'idev-common'), 'usage' => 'idev_license_package_usage']);
}, 4);
function idev_license_package_usage() {
    $pkg = idev_license('package');
    if (!$pkg['ok']) return '';
    $all = idev_license_packages();
    $names = [];
    $extra = ['store_jobs' => __('Job orders and pick-up', 'idev-common'), 'store_pharmacy' => __('Drug labels and ขย. books', 'idev-common')];
    foreach ((array) ($pkg['data']['inc'] ?? []) as $p) $names[] = idev_license_products()[$p]['name'] ?? ($extra[$p] ?? $p);
    return '<b>' . esc_html($all[$pkg['data']['pkg'] ?? '']['name'] ?? ($pkg['data']['pkg'] ?? '')) . '</b>: ' . esc_html(implode(' · ', $names));
}

/** Where to buy: the pricing page, and an e-mail with the details iDevApp needs to issue the key. */
function idev_license_buy_url() { return 'https://idevapp.me/plugins/#pricing'; }
function idev_license_mail_url($product) {
    $p = idev_license_products()[$product] ?? ['name' => $product];
    $subject = 'License ' . $p['name'] . ' — ' . idev_license_domain();
    $body = "ปลั๊กอิน / Plugin: {$p['name']}\nเว็บไซต์ / Website: " . idev_license_domain() . "\nชื่อโรงพยาบาล-คลินิก / Organisation:\nผู้ติดต่อ เบอร์โทร / Contact, phone:\n";
    return 'mailto:idevapp2023@gmail.com?subject=' . rawurlencode($subject) . '&body=' . rawurlencode($body);
}

/** "Free plan limit reached" style notice with buy / enter key buttons. */
function idev_license_upsell($product, $message) {
    return '<div class="idev-upsell"><p>' . wp_kses_post($message) . '</p><p><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=idev-license')) . '">' . esc_html__('Enter licence key', 'idev-common') . '</a> <a class="button" href="' . esc_url(idev_license_buy_url()) . '" target="_blank" rel="noopener">' . esc_html__('Prices', 'idev-common') . ' ↗</a></p></div>';
}

add_action('admin_menu', function () {
    if (!array_diff_key(idev_license_products(), ['package' => 1])) return; // only when a paid iDevApp plugin is installed
    add_submenu_page('idevapp', __('Licences', 'idev-common'), __('Licences', 'idev-common'), 'manage_options', 'idev-license', 'idev_license_page');
}, 99);

add_action('admin_post_idev_license', function () {
    if (!current_user_can('manage_options')) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-common'));
    check_admin_referer('idev_license');
    $product = sanitize_key($_POST['product'] ?? '');
    $keys = get_option('idev_licenses', []);
    if (!is_array($keys)) $keys = [];
    $msg = 'saved';
    if (!isset(idev_license_products()[$product])) $msg = 'error';
    elseif (!empty($_POST['remove'])) { unset($keys[$product]); $msg = 'removed'; }
    else {
        $key = trim(preg_replace('/\s+/', '', wp_unslash($_POST['key'] ?? '')));
        $check = idev_license_check($key, $product);
        if ($check['ok']) $keys[$product] = $key;
        else { set_transient('idev_license_error_' . get_current_user_id(), $check['error'], 120); $msg = 'invalid'; }
    }
    update_option('idev_licenses', $keys, true);
    wp_safe_redirect(add_query_arg(['page' => 'idev-license', 'msg' => $msg], admin_url('admin.php')) . '#' . $product);
    exit;
});

function idev_license_page() {
    idev_admin_header(__('Licences', 'idev-common'), __('Lifetime licences for this website. Keys are checked on this server; no data is sent to iDevApp.', 'idev-common'));
    $msg = sanitize_key($_GET['msg'] ?? '');
    if ($msg === 'saved') echo '<div class="notice notice-success"><p>' . esc_html__('Licence activated. Thank you!', 'idev-common') . '</p></div>';
    if ($msg === 'removed') echo '<div class="notice notice-warning"><p>' . esc_html__('Licence removed. The free plan applies again.', 'idev-common') . '</p></div>';
    if ($msg === 'invalid') {
        $err = get_transient('idev_license_error_' . get_current_user_id());
        echo '<div class="notice notice-error"><p>' . esc_html($err ?: __('The licence key is not valid.', 'idev-common')) . '</p></div>';
    }
    $domain = idev_license_domain();
    echo '<div class="idev-card idev-lic-site"><p>' . esc_html__('Licences are issued for one website. Give iDevApp this exact domain:', 'idev-common') . '</p><p><code class="idev-lic-domain">' . esc_html($domain) . '</code></p></div>';
    echo '<div class="idev-lic-grid">';
    foreach (idev_license_products() as $id => $p) {
        $lic = idev_license($id);
        $usage = isset($p['usage']) && is_callable($p['usage']) ? call_user_func($p['usage']) : '';
        echo '<div class="idev-card idev-lic" id="' . esc_attr($id) . '"><h2>' . esc_html($p['name']) . ' ';
        $via_pkg = !$lic['ok'] && $id !== 'package' && idev_is_licensed($id);
        echo $lic['ok'] ? '<span class="idev-badge pro">' . esc_html__('Licensed', 'idev-common') . '</span>' : ($via_pkg ? '<span class="idev-badge pro">' . esc_html__('In your package', 'idev-common') . '</span>' : '<span class="idev-badge">' . ($id === 'package' ? esc_html__('Not activated', 'idev-common') : esc_html__('Free plan', 'idev-common')) . '</span>');
        echo '</h2>';
        echo '<table class="idev-lic-plans"><tr><th>' . esc_html__('Free', 'idev-common') . '</th><td>' . esc_html($p['free']) . '</td></tr><tr><th>' . esc_html($p['price']) . '</th><td>' . esc_html($p['pro']) . '</td></tr></table>';
        if (!empty($p['note'])) echo '<p class="description">' . esc_html($p['note']) . '</p>';
        if ($usage !== '') echo '<p class="idev-lic-usage">' . wp_kses_post($usage) . '</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('idev_license');
        echo '<input type="hidden" name="action" value="idev_license"><input type="hidden" name="product" value="' . esc_attr($id) . '">';
        if ($via_pkg) {
            echo '<p>' . esc_html__('Opened by your iDevApp package licence.', 'idev-common') . '</p>';
        } elseif ($lic['ok']) {
            $d = $lic['data'];
            echo '<p>' . sprintf(esc_html__('Licensed to %1$s for %2$s · licence %3$s · issued %4$s', 'idev-common'), '<b>' . esc_html($d['n'] ?? '—') . '</b>', '<code>' . esc_html($d['d']) . '</code>', esc_html($d['id'] ?? '—'), esc_html($d['i'] ?? '—')) . '</p>';
            echo '<p><button class="button" name="remove" value="1" onclick="return confirm(\'' . esc_js(__('Remove the licence from this website?', 'idev-common')) . '\')">' . esc_html__('Remove licence', 'idev-common') . '</button></p>';
        } else {
            if ($lic['key'] !== '' && $lic['error']) echo '<div class="notice notice-error inline"><p>' . esc_html($lic['error']) . '</p></div>';
            echo '<p><textarea name="key" rows="3" class="large-text code" placeholder="IDEV1.…" spellcheck="false"></textarea></p>';
            echo '<p><button class="button button-primary">' . esc_html__('Activate', 'idev-common') . '</button> <a class="button" href="' . esc_url(idev_license_mail_url($id)) . '">' . esc_html__('Request a licence by e-mail', 'idev-common') . '</a> <a href="' . esc_url(idev_license_buy_url()) . '" target="_blank" rel="noopener">' . esc_html__('Prices', 'idev-common') . ' ↗</a></p>';
        }
        echo '</form></div>';
    }
    echo '</div><p class="idev-foot">' . esc_html__('All other iDevApp plugins are free.', 'idev-common') . ' · <a href="https://idevapp.me/plugins/" target="_blank" rel="noopener">idevapp.me/plugins</a></p></div>';
}
