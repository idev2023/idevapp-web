<?php
/**
 * iDevApp shared helpers (bundled with every iDevApp plugin; the first copy loaded is used).
 * https://idevapp.me/
 */
defined('ABSPATH') || exit;

/* ---------- Language ---------- */

/** Visitor language "th" or "en": from iDev Bilingual when active, else from the site language. */
function idev_lang() {
    if (function_exists('idev_bilingual_lang')) return idev_bilingual_lang();
    $locale = function_exists('determine_locale') ? determine_locale() : get_locale();
    return strpos((string) $locale, 'th') === 0 ? 'th' : 'en';
}
/** English text when English is shown and filled in, otherwise Thai. */
function idev_pick($th, $en, $lang = null) {
    $lang = $lang ?: idev_lang();
    return ($lang === 'en' && is_string($en) && trim($en) !== '') ? $en : (string) $th;
}
/** {th, en} array → text in the current language. */
function idev_tx($value, $lang = null) {
    if (!is_array($value)) return (string) $value;
    return idev_pick($value['th'] ?? '', $value['en'] ?? '', $lang);
}

/* ---------- Dates (YYYY-MM-DD, calculated in UTC so a time zone never shifts a day) ---------- */

function idev_parse_date($date) { return new DateTimeImmutable($date . ' 00:00:00', new DateTimeZone('UTC')); }
function idev_add_days($date, $days) { return idev_parse_date($date)->modify(($days >= 0 ? '+' : '') . (int) $days . ' days')->format('Y-m-d'); }
function idev_iso_weekday($date) { return (int) idev_parse_date($date)->format('N'); }
function idev_monday_of($date) { return idev_add_days($date, 1 - idev_iso_weekday($date)); }
function idev_today() { return (new DateTimeImmutable('now', wp_timezone()))->format('Y-m-d'); }
function idev_is_valid_date($value) {
    if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) return false;
    [$y, $m, $d] = array_map('intval', explode('-', $value));
    return checkdate($m, $d, $y);
}
function idev_months($lang, $long = false) {
    if ($lang === 'en') return $long ? ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] : ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return $long ? ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'] : ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
}
function idev_weekdays($lang, $short = false) {
    if ($lang === 'en') return $short ? ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] : ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    return $short ? ['จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.', 'อา.'] : ['จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์', 'อาทิตย์'];
}
/** "5 ธ.ค. 2569" / "5 Dec 2026"; with weekday "ส. 5 ธ.ค. 2569" / "Sat, 5 Dec 2026". */
function idev_format_day($date, $lang = null, $weekday = false, $long = false) {
    $lang = $lang ?: idev_lang();
    [$y, $m, $d] = array_map('intval', explode('-', $date));
    $text = $d . ' ' . idev_months($lang, $long)[$m - 1] . ' ' . ($lang === 'en' ? $y : $y + 543);
    if (!$weekday) return $text;
    $w = idev_weekdays($lang, true)[idev_iso_weekday($date) - 1];
    return $lang === 'en' ? "{$w}, {$text}" : "{$w} {$text}";
}
function idev_format_short($date, $lang = null) {
    $lang = $lang ?: idev_lang();
    [, $m, $d] = array_map('intval', explode('-', $date));
    return $d . ' ' . idev_months($lang)[$m - 1];
}
function idev_format_month($date, $lang = null) {
    $lang = $lang ?: idev_lang();
    [$y, $m] = array_map('intval', explode('-', $date));
    return idev_months($lang, true)[$m - 1] . ' ' . ($lang === 'en' ? $y : $y + 543);
}

/** "2026-12-05 14:30[:00]" → "5 ธ.ค. 2569 14:30" / "5 Dec 2026 14:30". */
function idev_format_datetime($value, $lang = null) {
    $value = (string) $value;
    if (!preg_match('/^(\d{4}-\d{2}-\d{2})(?:[ T](\d{2}:\d{2}))?/', $value, $m)) return $value;
    return idev_format_day($m[1], $lang) . (isset($m[2]) ? ' ' . $m[2] : '');
}

/* ---------- Year in WordPress dates: พ.ศ. on Thai pages, ค.ศ. on English pages ----------
 * Every date WordPress formats through wp_date() / date_i18n() / get_the_date() (posts, news, blocks, admin lists,
 * plugins) shows the Buddhist year when the page is shown in Thai. Only formats meant for people are changed:
 * one with a month or weekday name ("j F Y"), or day/month/year with "/", "." or spaces ("d/m/Y").
 * Month and weekday names are written in Thai too, so it reads right even without the Thai language pack.
 * Machine formats ("Y-m-d", "Ymd", "c", "U", "Y" alone) and REST, feeds, cron and WP-CLI are left in ค.ศ.
 * Turn it off with: add_filter('idev_buddhist_year', '__return_false');
 */
function idev_be_human_format($format) {
    $plain = preg_replace('/\\\\./s', '', (string) $format);
    if (!preg_match('/[Yy]/', $plain) || preg_match('/[Yy]-[mn]|[Yy][mn]/', $plain)) return false;
    if (preg_match('/[FMlD]/', $plain)) return true;
    return (bool) (preg_match('/[dj]/', $plain) && preg_match('/[mn]/', $plain) && preg_match('#[/. ]#', $plain));
}
function idev_be_active() {
    if ((defined('REST_REQUEST') && REST_REQUEST) || (defined('WP_CLI') && WP_CLI) || wp_doing_cron()) return false;
    if (did_action('wp') && function_exists('is_feed') && is_feed()) return false;
    if (!apply_filters('idev_buddhist_year', true)) return false;
    return idev_lang() === 'th';
}
/** The format with the year as พ.ศ. and month / weekday names in Thai, all as escaped literals. */
function idev_be_thai_format($format, DateTimeImmutable $dt) {
    $lit = function ($s) { $o = ''; foreach (preg_split('//u', (string) $s, -1, PREG_SPLIT_NO_EMPTY) as $ch) $o .= '\\' . $ch; return $o; };
    $year = (string) ((int) $dt->format('Y') + 543);
    $m = (int) $dt->format('n') - 1; $w = (int) $dt->format('N') - 1;
    $map = ['Y' => $year, 'y' => substr($year, -2), 'F' => idev_months('th', true)[$m], 'M' => idev_months('th')[$m],
        'l' => 'วัน' . idev_weekdays('th')[$w], 'D' => idev_weekdays('th', true)[$w]];
    $out = ''; $len = strlen($format);
    for ($i = 0; $i < $len; $i++) {
        $c = $format[$i];
        if ($c === '\\') { $out .= $c . ($format[$i + 1] ?? ''); $i++; continue; }
        $out .= isset($map[$c]) ? $lit($map[$c]) : $c;
    }
    return $out;
}
if (!defined('IDEV_BE_DATES')) {
    define('IDEV_BE_DATES', 1);
    add_filter('wp_date', function ($date, $format, $timestamp, $timezone) {
        static $busy = false;
        if ($busy || !idev_be_human_format($format) || !idev_be_active()) return $date;
        $tz = $timezone instanceof DateTimeZone ? $timezone : wp_timezone();
        $dt = (new DateTimeImmutable('@' . (int) $timestamp))->setTimezone($tz);
        if ($format === 'F j, Y') $format = 'j F Y'; // the English default reads day-first in Thai
        $busy = true;
        $out = wp_date(idev_be_thai_format($format, $dt), $timestamp, $tz);
        $busy = false;
        return $out === false ? $date : $out;
    }, 10, 4);
}

/* ---------- Links and icons ---------- */

/** Site path ("/news"), http(s), tel:, mailto: or #anchor; anything else becomes empty. */
function idev_safe_url($url) {
    $url = trim((string) $url);
    if ($url === '') return '';
    if ($url[0] === '/' && substr($url, 0, 2) !== '//' && substr($url, 0, 2) !== '/\\') return $url;
    if (preg_match('/^(tel|mailto):[^\s<>"]+$/i', $url)) return $url;
    if (preg_match('/^#[\w-]+$/', $url)) return $url;
    return preg_match('#^https?://#i', $url) ? esc_url_raw($url) : '';
}
function idev_href($url) {
    $url = idev_safe_url($url);
    return ($url !== '' && $url[0] === '/') ? home_url($url) : $url;
}

function idev_icon_paths() {
    return [
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'emergency' => '<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="M12 8v8M8 12h8"/>',
        'xray' => '<circle cx="12" cy="12" r="9"/><path d="M8 8l8 8M16 8l-8 8M12 3v18M3 12h18"/>',
        'travel' => '<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2.2 4.8-4.8 2.2 2.2-4.8 4.8-2.2Z"/>',
        'phone' => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.4 19.4 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8 8.9a16 16 0 0 0 6 6l1.2-1.3a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.8 2.1Z"/>',
        'pin' => '<path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'megaphone' => '<path d="m3 11 18-5v12L3 14v-3Z"/><path d="M11 16.5 13 22H8l-1.5-7.5M21 10v4"/>',
        'news' => '<path d="M5 4h14a2 2 0 0 1 2 2v14H5a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3Z"/><path d="M7 8h10M7 12h10M7 16h6"/>',
        'heart' => '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8Z"/>',
        'tooth' => '<path d="M7 3c-2.5 0-4 2-4 4.5 0 3 1.5 4.5 2 7.5.4 2.5 1 6 2.5 6s1.8-3.5 2.5-5.5c.3-.9 1.7-.9 2 0 .7 2 1 5.5 2.5 5.5s2.1-3.5 2.5-6c.5-3 2-4.5 2-7.5C21 5 19.5 3 17 3c-2 0-3 1-5 1S9 3 7 3Z"/>',
        'baby' => '<circle cx="12" cy="8" r="5"/><path d="M10 8h.01M14 8h.01M10.5 10.5c.8.6 2.2.6 3 0M5 21c1-4 4-6 7-6s6 2 7 6"/>',
        'eye' => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
        'pill' => '<path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/><path d="m8.5 8.5 7 7"/>',
        'lab' => '<path d="M9 3h6M10 3v6L4.5 18.5A1.7 1.7 0 0 0 6 21h12a1.7 1.7 0 0 0 1.5-2.5L14 9V3"/><path d="M7 15h10"/>',
        'stethoscope' => '<path d="M5 3v6a5 5 0 0 0 10 0V3M5 3H3M15 3h2"/><path d="M10 14v2a5 5 0 0 0 10 0v-3"/><circle cx="20" cy="11" r="2"/>',
        'ambulance' => '<path d="M3 17V7a1 1 0 0 1 1-1h10v11M14 10h4l3 3v4h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/><path d="M8 9v4M6 11h4"/>',
        'bed' => '<path d="M2 20V6M2 16h20v4M22 16v-4a3 3 0 0 0-3-3h-8v7"/><circle cx="6.5" cy="11.5" r="2"/>',
        'shield' => '<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/>',
        'users' => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
        'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
        'navigate' => '<path d="m3 11 18-8-8 18-2-8-8-2Z"/>',
        'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
        'up' => '<path d="m6 15 6-6 6 6"/>',
        'file' => '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9Z"/><path d="M14 3v6h6"/>',
        'paperclip' => '<path d="m21 11-8.6 8.6a5.5 5.5 0 0 1-7.8-7.8l8.6-8.6a3.7 3.7 0 0 1 5.2 5.2l-8.6 8.6a1.8 1.8 0 0 1-2.6-2.6L15.5 7"/>',
        'download' => '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
        'idcard' => '<rect x="2" y="5" width="20" height="14" rx="2"/><circle cx="8" cy="11" r="2.2"/><path d="M4.8 16.5c.6-1.6 1.8-2.4 3.2-2.4s2.6.8 3.2 2.4M14 10h5M14 13.5h4"/>',
        'passport' => '<rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="10" r="3.2"/><path d="M8.8 10h6.4M12 6.8c1 1 1.4 2 1.4 3.2s-.4 2.2-1.4 3.2c-1-1-1.4-2-1.4-3.2s.4-2.2 1.4-3.2M9 17h6"/>',
        'keyboard' => '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>',
        'camera' => '<path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1Z"/><circle cx="12" cy="13.5" r="3.5"/>',
        'image' => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.8"/><path d="m21 16-5-5-9 9"/>',
        'mail' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
        'chat' => '<path d="M20 12c0 4-3.6 7-8 7-1.2 0-2.3-.2-3.3-.6L4 20l1.3-3.5C4.5 15.2 4 13.7 4 12c0-4 3.6-7 8-7s8 3 8 7Z"/>',
        'whatsapp' => '<path d="M3.5 20.5 5 16.3A8.5 8.5 0 1 1 8 19.2Z"/><path d="M9 8.5c0 3.5 2.6 6.5 6.4 6.5l1-1.6-2-1-1 1c-1.2-.5-2.2-1.6-2.7-2.8l1-.9-.9-2.1H9.6Z"/>',
        'light' => '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.5.4.9 1 .9 1.6V16h5.2v-.5c0-.6.4-1.2.9-1.6A6 6 0 0 0 12 3Z"/>',
        'building' => '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4M8 6h.01M12 6h.01M16 6h.01M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M16 14h.01"/>',
        'chart' => '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
        'gear' => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/>',
        'list' => '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
        'palette' => '<circle cx="13.5" cy="6.5" r="1"/><circle cx="17.5" cy="10.5" r="1"/><circle cx="8.5" cy="7.5" r="1"/><circle cx="6.5" cy="12.5" r="1"/><path d="M12 2a10 10 0 0 0 0 20c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.4-.5-.8-.5-1.3 0-1.1.9-2 2-2h2.4A5.6 5.6 0 0 0 22 9.8C22 5.5 17.5 2 12 2Z"/>',
        'receipt' => '<path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2V3Z"/><path d="M9 8h6M9 12h6M9 16h3"/>',
        'box' => '<path d="M21 8 12 3 3 8v8l9 5 9-5V8Z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
        'cart' => '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.7 12.4a1 1 0 0 0 1 .8h9.6a1 1 0 0 0 1-.8L21 7H6"/>',
        'home' => '<path d="m3 11 9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1v-9Z"/>',
        'bell' => '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0"/>',
        'refresh' => '<path d="M21 12a9 9 0 0 1-15.5 6.2L3 16M3 12a9 9 0 0 1 15.5-6.2L21 8M21 3v5h-5M3 21v-5h5"/>',
        'wrench' => '<path d="M14.7 6.3a4 4 0 0 0 5 5L22 14l-8 8-2.3-2.3a4 4 0 0 0-5-5L4 12l8-8 2.7 2.3Z"/>',
        'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    ];
}
function idev_icon_names() { return array_keys(idev_icon_paths()); }
function idev_icon($name, $class = '') {
    $paths = idev_icon_paths();
    if ($name === 'line') return '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"' . ($class ? ' class="' . esc_attr($class) . '"' : '') . '><path d="M12 3C6.5 3 2 6.6 2 11c0 3.9 3.5 7.2 8.3 7.9.3.1.8.2.9.5.1.3.1.7 0 1l-.1.9c0 .3-.2 1 .9.5s5.9-3.5 8-6c1.4-1.6 2-3.2 2-4.8C22 6.6 17.5 3 12 3Z"/></svg>';
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' . ($class ? ' class="' . esc_attr($class) . '"' : '') . '>' . ($paths[$name] ?? $paths['plus']) . '</svg>';
}

/* ---------- Admin: one "iDevApp" menu for all iDevApp plugins ---------- */

$GLOBALS['idev_plugins'] = $GLOBALS['idev_plugins'] ?? [];
/** Each plugin registers itself for the iDevApp dashboard. */
function idev_register_plugin($slug, $args) { $GLOBALS['idev_plugins'][$slug] = $args + ['slug' => $slug]; }

foreach (['idev-license', 'idev-updater', 'idev-email', 'idev-docs'] as $idev_mod) if (file_exists(__DIR__ . '/' . $idev_mod . '.php')) require_once __DIR__ . '/' . $idev_mod . '.php';
unset($idev_mod);

add_action('admin_menu', function () {
    add_menu_page('iDevApp', 'iDevApp', 'edit_posts', 'idevapp', 'idev_render_dashboard', 'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#a7aaad" d="M10 1a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm-1 4h2v2H9V5Zm0 4h2v6H9V9Z"/></svg>'), 58);
    add_submenu_page('idevapp', __('iDevApp plugins', 'idev-common'), __('Dashboard', 'idev-common'), 'edit_posts', 'idevapp', 'idev_render_dashboard');
}, 5);

function idev_render_dashboard() {
    idev_admin_header('iDevApp', __('Plugins for clinics, hospitals and organisations', 'idev-common'));
    echo '<div class="idev-grid">';
    foreach ($GLOBALS['idev_plugins'] as $plugin) {
        $badge = '';
        foreach (function_exists('idev_license_products') ? idev_license_products() : [] as $pid => $lp) {
            if (($lp['plugin'] ?? '') !== ($plugin['slug'] ?? '')) continue;
            $badge = idev_is_licensed($pid) ? ' <span class="idev-badge pro">' . esc_html__('Licensed', 'idev-common') . '</span>' : ' <a class="idev-badge" href="' . esc_url(admin_url('admin.php?page=idev-license#' . $pid)) . '">' . esc_html__('Free plan', 'idev-common') . '</a>';
        }
        echo '<div class="idev-card"><h2>' . esc_html($plugin['name']) . ' <small>v' . esc_html($plugin['version']) . '</small>' . wp_kses_post($badge) . '</h2><p>' . esc_html($plugin['description']) . '</p><p>';
        if (!empty($plugin['settings'])) echo '<a class="button button-primary" href="' . esc_url($plugin['settings']) . '">' . esc_html__('Open', 'idev-common') . '</a> ';
        $docs = $plugin['docs'] ?? 'https://idevapp.me/';
        if ($docs) echo '<a class="button" href="' . esc_url($docs) . '" target="_blank" rel="noopener">' . esc_html__('Documentation', 'idev-common') . '</a>';
        echo '</p></div>';
    }
    echo '</div>';
    if (function_exists('idev_update_box')) idev_update_box();
    echo '<p class="idev-foot">iDevApp · <a href="https://idevapp.me/" target="_blank" rel="noopener">idevapp.me</a></p></div>';
}

/**
 * Page with the branded header and tabs. $a: tabs [slug => label], current, url (callable(slug) → URL),
 * chip [text, class ok|trial|off], icons [slug => icon name]. Close with idev_page_close().
 */
function idev_page_open($title, $subtitle = '', $a = []) {
    $help = $a['help'] ?? 'https://idevapp.me/';
    echo '<div class="wrap idev-wrap"><div class="idev-head"><span class="idev-logo">iDev<b>App</b></span><div><h1>' . esc_html($title);
    if (!empty($a['chip'])) echo ' <span class="idev-chip ' . esc_attr($a['chip'][1] ?? '') . '">' . esc_html($a['chip'][0]) . '</span>';
    echo '</h1>' . ($subtitle ? '<p>' . esc_html($subtitle) . '</p>' : '') . '</div>';
    if ($help) echo '<a class="idev-help" href="' . esc_url($help) . '" target="_blank" rel="noopener">' . esc_html__('Help & support', 'idev-common') . ' ↗</a>';
    echo '</div><hr class="wp-header-end">';
    if (!empty($a['tabs'])) {
        echo '<nav class="idev-nav">';
        foreach ($a['tabs'] as $k => $l) echo '<a class="' . ($k === ($a['current'] ?? '') ? 'on' : '') . '" href="' . esc_url(call_user_func($a['url'], $k)) . '">' . (!empty($a['icons'][$k]) ? idev_icon($a['icons'][$k]) : '') . esc_html($l) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- idev_icon returns fixed SVG
        echo '</nav>';
    }
}
function idev_page_close() { echo '</div>'; }

/** Branded page header; the caller closes the wrap with </div>. */
function idev_admin_header($title, $subtitle = '') {
    idev_page_open($title, $subtitle);
}

add_action('admin_enqueue_scripts', function () {
    $file = __DIR__ . '/idev-admin.css';
    if (file_exists($file)) wp_enqueue_style('idev-admin', plugins_url('idev-admin.css', __FILE__), [], IDEV_COMMON_VERSION);
    // Enter → next field on iDevApp screens
    if (is_file(__DIR__ . '/idev-enter.js')) wp_enqueue_script('idev-enter', plugins_url('idev-enter.js', __FILE__), [], IDEV_COMMON_VERSION, true);
});

/** Settings / Docs links on the Plugins screen. */
function idev_plugin_links($plugin_file, $settings_url, $docs = 'https://idevapp.me/') {
    add_filter('plugin_action_links_' . plugin_basename($plugin_file), function ($links) use ($settings_url) {
        array_unshift($links, '<a href="' . esc_url($settings_url) . '">' . esc_html__('Settings', 'idev-common') . '</a>');
        return $links;
    });
    add_filter('plugin_row_meta', function ($links, $file) use ($plugin_file, $docs) {
        if ($docs && $file === plugin_basename($plugin_file)) $links[] = '<a href="' . esc_url($docs) . '" target="_blank" rel="noopener">' . esc_html__('Documentation', 'idev-common') . '</a>';
        return $links;
    }, 10, 2);
}

/** Tags allowed in pre-built form markup passed to idev_settings_table() (type "html"). */
function idev_kses_form() {
    $a = ['type' => true, 'name' => true, 'value' => true, 'id' => true, 'class' => true, 'checked' => true, 'selected' => true, 'disabled' => true, 'readonly' => true, 'placeholder' => true, 'min' => true, 'max' => true, 'step' => true, 'size' => true, 'rows' => true, 'for' => true, 'style' => true, 'data-target' => true, 'href' => true, 'target' => true, 'rel' => true];
    return ['input' => $a, 'select' => $a, 'option' => $a, 'textarea' => $a, 'label' => $a, 'span' => $a, 'br' => [], 'p' => $a, 'div' => $a, 'button' => $a, 'a' => $a, 'small' => $a, 'b' => [], 'strong' => [], 'code' => [], 'img' => ['src' => true, 'alt' => true, 'style' => true, 'class' => true]];
}

/** Simple settings form helper: fields = [key, label, type, help, options]. */
function idev_settings_table($option, $fields, $values) {
    echo '<table class="form-table" role="presentation">';
    foreach ($fields as $field) {
        [$key, $label, $type, $help, $options] = array_pad($field, 5, '');
        $type = $type ?: 'text';
        $name = $option . '[' . $key . ']';
        $id = $option . '-' . $key;
        $value = $values[$key] ?? '';
        if ($type === 'heading') { echo '</table><h2 class="idev-section">' . esc_html($label) . '</h2>' . ($help ? '<p class="description">' . esc_html($help) . '</p>' : '') . '<table class="form-table" role="presentation">'; continue; }
        echo '<tr><th scope="row"><label for="' . esc_attr($id) . '">' . esc_html($label) . '</label></th><td>';
        if ($type === 'checkbox') echo '<label><input type="checkbox" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="1"' . checked($value, '1', false) . '> ' . esc_html__('On', 'idev-common') . '</label>';
        elseif ($type === 'textarea') echo '<textarea class="large-text" rows="4" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '">' . esc_textarea($value) . '</textarea>';
        elseif ($type === 'select') { echo '<select id="' . esc_attr($id) . '" name="' . esc_attr($name) . '">'; foreach ($options as $v => $l) echo '<option value="' . esc_attr($v) . '"' . selected($value, (string) $v, false) . '>' . esc_html($l) . '</option>'; echo '</select>'; }
        elseif ($type === 'html') echo wp_kses($options, idev_kses_form()); // markup built by the plugin
        elseif ($type === 'color') echo '<input type="color" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '">';
        elseif ($type === 'number') echo '<input type="number" class="small-text" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '"' . ($options ? ' min="' . (int) $options[0] . '" max="' . (int) $options[1] . '"' : '') . '>';
        elseif ($type === 'image') { wp_enqueue_media(); echo '<div class="idev-image-field"><input type="url" class="regular-text" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '"> <button type="button" class="button idev-pick-image" data-target="' . esc_attr($id) . '">' . esc_html__('Choose image', 'idev-common') . '</button>' . ($value ? '<br><img src="' . esc_url($value) . '" alt="" style="max-height:80px;margin-top:6px">' : '') . '</div>'; }
        else echo '<input type="' . ($type === 'url' ? 'url' : ($type === 'email' ? 'email' : 'text')) . '" class="regular-text" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '">';
        if ($help) echo '<p class="description">' . esc_html($help) . '</p>';
        echo '</td></tr>';
    }
    echo '</table>';
}
/** Sanitizes posted values for the fields above. */
function idev_settings_sanitize($fields, $input, $old = []) {
    $out = $old;
    foreach ($fields as $field) {
        [$key, , $type, , $options] = array_pad($field, 5, '');
        if ($type === 'heading' || $type === 'html') continue;
        $raw = isset($input[$key]) ? wp_unslash($input[$key]) : '';
        switch ($type) {
            case 'checkbox': $out[$key] = $raw ? '1' : '0'; break;
            case 'textarea': $out[$key] = sanitize_textarea_field($raw); break;
            case 'url': case 'image': $out[$key] = esc_url_raw(trim($raw), ['http', 'https']); break;
            case 'email': $out[$key] = sanitize_email($raw); break;
            case 'color': $out[$key] = sanitize_hex_color($raw) ?: ($old[$key] ?? ''); break;
            case 'number': $out[$key] = (string) (int) $raw; if ($options) $out[$key] = (string) max((int) $options[0], min((int) $options[1], (int) $raw)); break;
            case 'select': $out[$key] = array_key_exists($raw, (array) $options) ? $raw : ($old[$key] ?? ''); break;
            case 'raw': $out[$key] = trim((string) $raw); break;
            default: $out[$key] = sanitize_text_field($raw);
        }
    }
    return $out;
}

// "Choose image" buttons of idev_settings_fields(): attached to jQuery, which every admin page loads.
add_action('admin_enqueue_scripts', function () {
    wp_add_inline_script('jquery-core', "jQuery(function($){ $(document).on('click','.idev-pick-image',function(e){ e.preventDefault(); if(!window.wp||!wp.media)return; var t=$('#'+$(this).data('target')); var f=wp.media({multiple:false,library:{type:'image'}}); f.on('select',function(){ t.val(f.state().get('selection').first().toJSON().url).trigger('change'); }); f.open(); }); });");
});

/* ---------- Simple server-rendered blocks with a settings panel ---------- */

$GLOBALS['idev_blocks'] = $GLOBALS['idev_blocks'] ?? [];
/**
 * Registers a dynamic block. $fields: key => [control (text|textarea|select|toggle|number), label, default, options|[min,max]].
 */
function idev_register_block($name, $title, $icon, $description, $fields, $render) {
    $attributes = [];
    foreach ($fields as $key => $f) {
        $type = $f[0] === 'toggle' ? 'boolean' : ($f[0] === 'number' ? 'number' : 'string');
        $attributes[$key] = ['type' => $type, 'default' => $f[2]];
    }
    $GLOBALS['idev_blocks'][$name] = ['name' => $name, 'title' => $title, 'icon' => $icon, 'description' => $description, 'fields' => $fields];
    add_action('init', function () use ($name, $title, $icon, $description, $attributes, $render) {
        register_block_type($name, ['api_version' => 3, 'title' => $title, 'icon' => $icon, 'category' => 'idevapp', 'description' => $description, 'attributes' => $attributes + ['align' => ['type' => 'string', 'default' => '']], 'supports' => ['html' => false, 'align' => ['wide', 'full']], 'editor_script' => 'idev-blocks', 'render_callback' => $render]);
    }, 20);
}
add_action('init', function () {
    wp_register_script('idev-blocks', plugins_url('idev-blocks.js', IDEV_COMMON_DIR . '/idev-common.php'), ['wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render'], IDEV_COMMON_VERSION, true);
}, 5);
add_action('enqueue_block_editor_assets', function () {
    wp_add_inline_script('idev-blocks', 'window.IDEV_BLOCKS = ' . wp_json_encode(array_values($GLOBALS['idev_blocks']), JSON_UNESCAPED_UNICODE) . ';', 'before');
});
add_filter('block_categories_all', function ($categories) {
    foreach ($categories as $c) if ($c['slug'] === 'idevapp') return $categories;
    $categories[] = ['slug' => 'idevapp', 'title' => 'iDevApp', 'icon' => null];
    return $categories;
});

/* QR codes and barcodes are loaded only when needed. */
function idev_load_qr() { require_once IDEV_COMMON_DIR . '/idev-qr.php'; }
