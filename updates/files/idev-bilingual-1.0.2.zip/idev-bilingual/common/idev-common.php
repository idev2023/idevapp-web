<?php
/**
 * iDevApp shared helpers loader. Every iDevApp plugin bundles this folder; the newest bundled version is loaded
 * once all plugins are loaded (plugins_loaded), so plugins of different ages work together.
 * https://idevapp.me/
 */
defined('ABSPATH') || exit;
$GLOBALS['idev_common_candidates'] = $GLOBALS['idev_common_candidates'] ?? [];
$GLOBALS['idev_common_candidates'][__DIR__] = '1.8.0';
if (!function_exists('idev_common_boot')) {
    function idev_common_boot() {
        if (defined('IDEV_COMMON_VERSION')) return;
        $best = ''; $version = '0';
        foreach ($GLOBALS['idev_common_candidates'] as $dir => $v) if (version_compare($v, $version, '>')) { $best = $dir; $version = $v; }
        define('IDEV_COMMON_VERSION', $version);
        define('IDEV_COMMON_DIR', $best);
        require $best . '/idev-common-functions.php';
        add_action('init', function () {
            $mo = IDEV_COMMON_DIR . '/idev-common-' . determine_locale() . '.mo';
            if (file_exists($mo)) load_textdomain('idev-common', $mo);
        }, 1);
    }
    add_action('plugins_loaded', 'idev_common_boot', -1000);
}
if (did_action('plugins_loaded')) idev_common_boot();
