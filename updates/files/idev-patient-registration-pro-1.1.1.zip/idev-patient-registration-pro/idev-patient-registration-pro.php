<?php
/**
 * Plugin Name:       iDev Patient Registration Pro
 * Plugin URI:        https://idevapp.me/plugins/idev-patient-registration/#pro
 * Description:       Add-on for iDev Patient Registration: HOSxP connector (find or create the HN automatically and send the patient card) and automatic reading of Thai ID cards and passports on the patient's phone.
 * Version:           1.1.1
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-patient-registration-pro
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// Loaded once: the same plugin may also be inside an iDevApp package (I-Clinic / I-Drug) or a Pro version.
if (defined('IDEV_MRP_VERSION')) return;

define('IDEV_MRP_VERSION', '1.1.1');
define('IDEV_MRP_FILE', __FILE__);
define('IDEV_MRP_DIR', __DIR__);

if (!function_exists('idev_free_plugin_active')) {
    /** Is this plugin active as a separate plugin (this site or network)? */
    function idev_free_plugin_active($slug) {
        $f = $slug . '/' . $slug . '.php';
        if (in_array($f, (array) get_option('active_plugins', []), true)) return true;
        return is_multisite() && isset(((array) get_site_option('active_sitewide_plugins', []))[$f]);
    }
}
/* One plugin to install: the Pro zip contains the free plugin (iDev Patient Registration) in core/. */
// WordPress loads "idev-patient-registration-pro" before "idev-patient-registration": when the separate free plugin is still active, let it load itself
// (it is switched off on the next admin page) instead of loading the copy in core/ — loading both would be a fatal error.
if (!defined('IDEV_MEDREG_VERSION') && is_file(__DIR__ . '/core/idev-patient-registration.php') && !idev_free_plugin_active('idev-patient-registration')) require_once __DIR__ . '/core/idev-patient-registration.php';
require_once __DIR__ . '/common/idev-common.php';

add_action('plugins_loaded', function () {
    if (!function_exists('idev_medreg_settings')) {
        add_action('admin_notices', function () {
            if (!current_user_can('activate_plugins')) return;
            echo '<div class="notice notice-error"><p>' . esc_html__('iDev Patient Registration Pro needs the free plugin iDev Patient Registration (version 1.2 or newer). Please install and activate it.', 'idev-patient-registration-pro') . '</p></div>';
        });
        return;
    }
    foreach (['pro', 'cards', 'emails'] as $f) require_once __DIR__ . '/includes/' . $f . '.php';
}, 20);

register_activation_hook(__FILE__, function () use (&$idev_mrp_takeover) {
    if (function_exists('idev_medreg_install')) { idev_medreg_install(); idev_medreg_migrate_andaman(); }
    $idev_mrp_takeover();
});
/** The free plugin is inside this one: switch the separate free plugin off (settings and data are shared). */
$idev_mrp_takeover = function () {
    if (!is_dir(__DIR__ . '/core')) return;
    if (!function_exists('is_plugin_active')) require_once ABSPATH . 'wp-admin/includes/plugin.php';
    $free = 'idev-patient-registration/idev-patient-registration.php';
    if (!is_plugin_active($free)) return;
    deactivate_plugins($free, true);
    set_transient('idev_mrp_took_over', 1, 600);
};
add_action('admin_init', $idev_mrp_takeover);
add_action('admin_notices', function () {
    if (!get_transient('idev_mrp_took_over') || !current_user_can('activate_plugins')) return;
    delete_transient('idev_mrp_took_over');
    echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('The Pro version already contains the free plugin, so the separate free plugin was switched off. Your settings and data are kept. You can delete the free plugin.', 'idev-patient-registration-pro') . '</p></div>';
});
