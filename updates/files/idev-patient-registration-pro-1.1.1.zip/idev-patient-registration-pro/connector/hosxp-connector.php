<?php
/**
 * ตัวเชื่อม HOSxP สำหรับระบบลงทะเบียนผู้ป่วยใหม่ (ปลั๊กอิน iDev Patient Registration — https://idevapp.me/)
 * รันบนเครื่องใน รพ. ที่เข้าถึงฐานข้อมูล HOSxP ได้:  php hosxp-connector.php            (รันครั้งเดียว — ใช้กับ cron / Task Scheduler)
 *                                                    php hosxp-connector.php --loop 60  (วนทุก 60 วินาที)
 *                                                    php hosxp-connector.php --check    (ตรวจการเชื่อมต่อและคอลัมน์)
 * ต้องใช้ PHP 7.4+ ที่มี pdo_mysql และ curl (หรือ openssl)
 */

if (PHP_SAPI !== 'cli') { http_response_code(403); exit('CLI only'); }
$config_file = __DIR__ . '/config.php';
if (!file_exists($config_file)) { fwrite(STDERR, "ไม่พบ config.php — คัดลอก config.sample.php เป็น config.php แล้วแก้ค่า\n"); exit(1); }
$config = require $config_file;
date_default_timezone_set($config['timezone'] ?? 'Asia/Bangkok');
$args = array_slice($argv, 1);

function logline($message) {
    global $config;
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $message;
    echo $line . PHP_EOL;
    if (!empty($config['log_file'])) @file_put_contents($config['log_file'], $line . PHP_EOL, FILE_APPEND);
}

function api($method, $path, $data = null) {
    global $config;
    // iDev Patient Registration: idev-medreg/v1/connector · Andaman Hub (old config.php without 'api'): andaman/v1/hosxp
    $base = trim($config['api'] ?? 'andaman/v1/hosxp', '/');
    $url = rtrim($config['site_url'], '/') . '/wp-json/' . $base . '/' . ltrim($path, '/');
    $headers = ['Authorization: Bearer ' . $config['token'], 'Accept: application/json', 'User-Agent: iDev-HOSxP-Connector/1.1'];
    $body = $data === null ? null : json_encode($data, JSON_UNESCAPED_UNICODE);
    if ($body !== null) $headers[] = 'Content-Type: application/json';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => $headers, CURLOPT_TIMEOUT => 30, CURLOPT_CONNECTTIMEOUT => 10]);
        if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        $response = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        if ($response === false) throw new RuntimeException("เชื่อมต่อเว็บไม่ได้: $error");
    } else {
        $context = stream_context_create(['http' => ['method' => $method, 'header' => implode("\r\n", $headers), 'content' => $body ?? '', 'timeout' => 30, 'ignore_errors' => true]]);
        $response = @file_get_contents($url, false, $context);
        if ($response === false) throw new RuntimeException('เชื่อมต่อเว็บไม่ได้');
        preg_match('#HTTP/\S+ (\d+)#', $http_response_header[0] ?? '', $m);
        $code = (int) ($m[1] ?? 0);
    }
    $json = json_decode($response, true);
    if ($code === 401 || $code === 403) throw new RuntimeException("เว็บปฏิเสธรหัสตัวเชื่อม (HTTP $code) — ตรวจ token ใน config.php / IP ที่อนุญาต / Cloudflare");
    if ($code >= 400 || !is_array($json)) throw new RuntimeException("เว็บตอบกลับผิดปกติ (HTTP $code): " . substr((string) $response, 0, 200));
    return $json;
}

function db() {
    global $config;
    static $pdo = null;
    if ($pdo) return $pdo;
    $c = $config['db'];
    $dsn = "mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset={$c['charset']}";
    $pdo = new PDO($dsn, $c['user'], $c['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
    return $pdo;
}

function ident($name) {
    if (!preg_match('/^[A-Za-z0-9_]+$/', $name)) throw new RuntimeException("ชื่อตาราง/คอลัมน์ไม่ถูกต้อง: $name");
    return '`' . $name . '`';
}

function patient_columns() {
    global $config;
    static $columns = null;
    if ($columns === null) {
        $columns = [];
        foreach (db()->query('SHOW COLUMNS FROM ' . ident($config['patient_table'])) as $row) $columns[strtolower($row['Field'])] = $row;
    }
    return $columns;
}

function guid() {
    $b = random_bytes(16);
    $b[6] = chr(ord($b[6]) & 0x0f | 0x40);
    $b[8] = chr(ord($b[8]) & 0x3f | 0x80);
    return '{' . strtoupper(vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($b), 4))) . '}';
}

function values_for($person, $ref, $hn) {
    global $config;
    $iso = strtoupper($person['nationality'] ?? '');
    $nat = $config['nationality'][$iso] ?? ($config['nationality_default'] ?? '');
    $vars = [
        'hn' => $hn, 'prefix' => $person['prefix'] ?? '', 'first_name' => $person['first_name'] ?? '', 'last_name' => $person['last_name'] ?? '',
        'first_name_en' => $person['first_name_en'] ?? '', 'last_name_en' => $person['last_name_en'] ?? '',
        'sex' => $config['sex'][$person['sex'] ?? ''] ?? '', 'birthdate' => $person['birthdate'] ?? null, 'cid' => $person['cid'] ?? '',
        'passport_no' => $person['passport_no'] ?? '', 'nationality' => $nat, 'nationality_iso' => $iso, 'phone' => $person['phone'] ?? '', 'email' => $person['email'] ?? '',
        'address' => $person['address'] ?? '', 'lat' => $person['lat'] ?? '', 'lng' => $person['lng'] ?? '', 'drug_allergy' => $person['drug_allergy'] ?? '',
        'emergency_name' => $person['emergency_name'] ?? '', 'emergency_phone' => $person['emergency_phone'] ?? '', 'ref' => $ref,
        'line_id' => $person['line_id'] ?? '', 'whatsapp' => $person['whatsapp'] ?? '',
        'today' => date('Y-m-d'), 'now' => date('Y-m-d H:i:s'), 'guid' => guid(),
    ];
    $available = patient_columns();
    $row = [];
    foreach ($config['columns'] as $column => $template) {
        if (!isset($available[strtolower($column)])) { static $warned = []; if (empty($warned[$column])) { logline("  ! ข้ามคอลัมน์ $column (ไม่มีในตาราง {$config['patient_table']})"); $warned[$column] = true; } continue; }
        $value = preg_replace_callback('/\{(\w+)\}/', function ($m) use ($vars) { return (string) ($vars[$m[1]] ?? ''); }, (string) $template);
        if ($value === '' && $available[strtolower($column)]['Null'] === 'YES') $value = null;
        // Cut text to the column size so MySQL strict mode does not reject the row.
        if ($value !== null && preg_match('/char\((\d+)\)/i', $available[strtolower($column)]['Type'], $m)) $value = mb_substr($value, 0, (int) $m[1]);
        $row[$column] = $value;
    }
    return $row;
}

function find_existing($person) {
    global $config;
    $available = patient_columns();
    $table = ident($config['patient_table']);
    if (!empty($person['cid']) && !empty($config['lookup']['cid']) && isset($available[strtolower($config['lookup']['cid'])])) {
        $st = db()->prepare("SELECT hn FROM $table WHERE " . ident($config['lookup']['cid']) . ' = ? LIMIT 1');
        $st->execute([$person['cid']]);
        if ($hn = $st->fetchColumn()) return $hn;
    }
    if (!empty($person['passport_no']) && !empty($config['lookup']['passport']) && isset($available[strtolower($config['lookup']['passport'])])) {
        $st = db()->prepare("SELECT hn FROM $table WHERE " . ident($config['lookup']['passport']) . ' = ? LIMIT 1');
        $st->execute([$person['passport_no']]);
        if ($hn = $st->fetchColumn()) return $hn;
    }
    return null;
}

/** New HN inside the open transaction. */
function next_hn() {
    global $config;
    $h = $config['hn'];
    $table = ident($config['patient_table']);
    $length = (int) ($h['length'] ?? 9);
    for ($attempt = 0; $attempt < 50; $attempt++) {
        if (($h['method'] ?? 'serial') === 'serial') {
            $serial = ident($h['serial_table']); $name = ident($h['name_column']); $value = ident($h['value_column']);
            $st = db()->prepare("SELECT $value FROM $serial WHERE $name = ? FOR UPDATE");
            $st->execute([$h['serial_name']]);
            $current = $st->fetchColumn();
            if ($current === false) throw new RuntimeException("ไม่พบแถว {$h['serial_name']} ในตาราง {$h['serial_table']}");
            $number = (int) $current + 1;
            db()->prepare("UPDATE $serial SET $value = ? WHERE $name = ?")->execute([$number, $h['serial_name']]);
        } else {
            $number = (int) db()->query("SELECT MAX(CAST(hn AS UNSIGNED)) FROM $table FOR UPDATE")->fetchColumn() + 1;
        }
        $hn = str_pad((string) $number, $length, '0', STR_PAD_LEFT);
        $st = db()->prepare("SELECT COUNT(*) FROM $table WHERE hn = ?");
        $st->execute([$hn]);
        if (!(int) $st->fetchColumn()) return $hn;
    }
    throw new RuntimeException('ออก HN ไม่สำเร็จ (HN ซ้ำต่อเนื่อง) — ตรวจตาราง serial');
}

function insert_patient($person, $ref) {
    global $config;
    db()->beginTransaction();
    try {
        $hn = next_hn();
        $row = values_for($person, $ref, $hn);
        $columns = implode(',', array_map('ident', array_keys($row)));
        $marks = implode(',', array_fill(0, count($row), '?'));
        db()->prepare('INSERT INTO ' . ident($config['patient_table']) . " ($columns) VALUES ($marks)")->execute(array_values($row));
        db()->commit();
        return $hn;
    } catch (Throwable $e) {
        db()->rollBack();
        throw $e;
    }
}

function run_once() {
    global $config;
    $mode = $config['mode'];
    $queue = api('GET', 'queue');
    $items = $queue['items'] ?? [];
    if (!$items) return 0;
    logline(count($items) . " รายการรอบันทึก (โหมด $mode)");
    foreach ($items as $item) {
        $p = $item['person'];
        $label = "{$item['ref']} " . trim(($p['prefix'] ?? '') . ' ' . ($p['first_name'] ?? '') . ' ' . ($p['last_name'] ?? ''));
        try {
            $existing = find_existing($p);
            if ($existing) {
                logline("  = $label พบผู้ป่วยเดิม HN $existing");
                if ($mode !== 'dry-run') api('POST', 'result', ['id' => $item['id'], 'status' => 'existing', 'hn' => $existing]);
                continue;
            }
            if ($mode === 'dry-run') {
                $preview = values_for($p, $item['ref'], '(HN ใหม่)');
                logline("  + $label จะสร้างผู้ป่วยใหม่: " . json_encode($preview, JSON_UNESCAPED_UNICODE));
                continue;
            }
            if ($mode === 'lookup-only') {
                logline("  ? $label ไม่พบใน HOSxP (โหมดค้นหาอย่างเดียว)");
                api('POST', 'result', ['id' => $item['id'], 'status' => 'error', 'message' => 'ไม่พบผู้ป่วยใน HOSxP — กรุณาสร้างใน HOSxP แล้วใส่ HN ที่หลังบ้าน']);
                continue;
            }
            $hn = insert_patient($p, $item['ref']);
            logline("  + $label สร้างผู้ป่วยใหม่ HN $hn");
            api('POST', 'result', ['id' => $item['id'], 'status' => 'created', 'hn' => $hn]);
        } catch (Throwable $e) {
            logline("  ! $label ผิดพลาด: " . $e->getMessage());
            if ($mode !== 'dry-run') {
                try { api('POST', 'result', ['id' => $item['id'], 'status' => 'error', 'message' => 'HOSxP: ' . mb_substr($e->getMessage(), 0, 300)]); } catch (Throwable $ignored) {}
            }
        }
    }
    return count($items);
}

// One run at a time.
$lock = fopen(sys_get_temp_dir() . '/idev-hosxp-connector.lock', 'c');
if (!flock($lock, LOCK_EX | LOCK_NB)) { echo "กำลังทำงานอยู่แล้ว\n"; exit(0); }

try {
    if (in_array('--check', $args, true)) {
        $ping = api('GET', 'ping');
        logline('เว็บ: OK ' . ($ping['site'] ?? ''));
        $columns = patient_columns();
        logline('HOSxP: OK ตาราง ' . $config['patient_table'] . ' มี ' . count($columns) . ' คอลัมน์');
        foreach ($config['columns'] as $column => $template) logline('  ' . (isset($columns[strtolower($column)]) ? '✓' : '✗ ไม่มี') . " $column ← $template");
        if (($config['hn']['method'] ?? 'serial') === 'serial') {
            $h = $config['hn'];
            $st = db()->prepare('SELECT ' . ident($h['value_column']) . ' FROM ' . ident($h['serial_table']) . ' WHERE ' . ident($h['name_column']) . ' = ?');
            $st->execute([$h['serial_name']]);
            $v = $st->fetchColumn();
            logline($v === false ? "✗ ไม่พบ serial '{$h['serial_name']}'" : "✓ HN ล่าสุดใน serial: $v");
        }
        logline('โหมดปัจจุบัน: ' . $config['mode']);
        exit(0);
    }
    $loop = ($i = array_search('--loop', $args, true)) !== false ? max(15, (int) ($args[$i + 1] ?? 60)) : 0;
    do {
        try { run_once(); } catch (Throwable $e) { logline('ผิดพลาด: ' . $e->getMessage()); if (!$loop) exit(1); }
        if ($loop) sleep($loop);
    } while ($loop);
} finally {
    flock($lock, LOCK_UN);
}
