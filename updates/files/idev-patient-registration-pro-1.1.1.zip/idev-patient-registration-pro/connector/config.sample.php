<?php
/*
 * ตั้งค่าตัวเชื่อม HOSxP — คัดลอกไฟล์นี้เป็น config.php แล้วแก้ค่า
 * ให้ผู้ดูแลระบบ HOSxP ตรวจชื่อตาราง/คอลัมน์กับฐานข้อมูลจริงก่อนเปลี่ยน mode เป็น insert
 */
return [
    // เว็บไซต์ (WordPress) และรหัสตัวเชื่อม (หลังบ้าน → Registrations → Settings → HOSxP connector → Create new connector key)
    'site_url' => 'https://example.com/',
    'token'    => 'idmr_ใส่รหัสที่นี่',
    'api'      => 'idev-medreg/v1/connector',   // ไม่ต้องแก้

    // ฐานข้อมูล HOSxP (MySQL / MariaDB) — แนะนำสร้าง user แยกที่มีสิทธิ์เฉพาะ SELECT/INSERT patient และ SELECT/UPDATE serial
    'db' => [
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'name'    => 'hos',
        'user'    => 'web_register',
        'pass'    => '',
        'charset' => 'utf8',   // ถ้าฐานข้อมูลเป็น tis620 ให้ใส่ 'tis620'
    ],

    // dry-run     = อ่านอย่างเดียว แสดงว่าจะทำอะไร ไม่บันทึก ไม่ส่งผลกลับเว็บ (เริ่มต้นใช้โหมดนี้)
    // lookup-only = ค้นหาผู้ป่วยเดิมด้วยเลขบัตร/พาสปอร์ต ถ้าพบส่ง HN เดิมกลับ ถ้าไม่พบแจ้งเจ้าหน้าที่ให้สร้างเองใน HOSxP
    // insert      = ถ้าไม่พบ สร้างผู้ป่วยใหม่ใน HOSxP และออก HN ให้
    'mode' => 'dry-run',

    'patient_table' => 'patient',

    // วิธีออก HN ใหม่
    //   serial = ใช้ตาราง serial ของ HOSxP (name = 'hn') — แบบเดียวกับโปรแกรม HOSxP
    //   max    = MAX(hn) + 1
    'hn' => ['method' => 'serial', 'serial_table' => 'serial', 'serial_name' => 'hn', 'name_column' => 'name', 'value_column' => 'serial_no', 'length' => 9],

    // คอลัมน์ที่ใช้หาผู้ป่วยเดิม
    'lookup' => ['cid' => 'cid', 'passport' => 'passport_no'],

    // ค่าที่ใช้แปลง
    'sex' => ['male' => '1', 'female' => '2'],
    'nationality' => ['THA' => '99'],      // รหัสสัญชาติของ HOSxP (ตาราง nationality) เพิ่มได้ เช่น 'GBR' => '...'
    'nationality_default' => '',           // ใช้เมื่อไม่มีใน mapping (เว้นว่าง = ไม่บันทึก)

    // คอลัมน์ในตาราง patient => ค่าที่บันทึก ({...} คือข้อมูลจากฟอร์ม)
    // คอลัมน์ที่ไม่มีอยู่จริงในฐานข้อมูลจะถูกข้ามพร้อมแจ้งเตือน (ไม่ทำให้บันทึกล้ม)
    // ข้อมูลที่มี: {hn} {prefix} {first_name} {last_name} {first_name_en} {last_name_en} {sex} {birthdate} {cid}
    //   {passport_no} {nationality} {nationality_iso} {phone} {email} {address} {lat} {lng} {drug_allergy}
    //   {emergency_name} {emergency_phone} {line_id} {whatsapp} {ref} {today} {now} {guid}
    'columns' => [
        'hos_guid'     => '{guid}',
        'hn'           => '{hn}',
        'pname'        => '{prefix}',
        'fname'        => '{first_name}',
        'lname'        => '{last_name}',
        'sex'          => '{sex}',
        'birthday'     => '{birthdate}',
        'cid'          => '{cid}',
        'passport_no'  => '{passport_no}',
        'nationality'  => '{nationality}',
        'citizenship'  => '{nationality}',
        'hometel'      => '{phone}',
        'email'        => '{email}',
        'informaddr'   => '{address}',
        'drugallergy'  => '{drug_allergy}',
        'informname'   => '{emergency_name}',
        'informtel'    => '{emergency_phone}',
        'firstday'     => '{today}',
        'last_update'  => '{now}',
    ],

    'timezone' => 'Asia/Bangkok',
    'log_file' => __DIR__ . '/connector.log',
];
