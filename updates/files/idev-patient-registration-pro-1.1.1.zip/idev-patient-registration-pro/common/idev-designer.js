/* iDevApp designers: e-mail and printed documents — template gallery, live preview, test e-mail. */
(function ($) {
  $('.idev-designer').each(function () {
    var $f = $(this), kind = $f.data('kind'), timer = null, req = null;
    var st = { type: $f.find('.idev-seg [data-type].on').data('type') || '', lang: 'th', doc: $f.find('.idev-prev-doc .on').data('doc') || '', paper: $f.find('.idev-prev-paper').val() || '' };
    var $frame = $f.find('.idev-preview-frame iframe');

    function data(extra) {
      var fd = new FormData($f[0]);
      fd.delete('action'); fd.delete('_wpnonce');
      fd.append('action', extra || 'idev_designer_preview'); fd.append('kind', kind); fd.append('id', $f.data('id')); fd.append('nonce', $f.data('nonce'));
      fd.append('type', st.type); fd.append('lang', st.lang); fd.append('doc', st.doc); fd.append('paper', st.paper);
      return fd;
    }
    function refresh() {
      clearTimeout(timer);
      timer = setTimeout(function () {
        if (req) req.abort();
        $f.find('.idev-preview-frame').addClass('loading');
        req = $.ajax({ url: $f.data('ajax'), method: 'POST', data: data(), processData: false, contentType: false })
          .done(function (r) { if (r && r.success) { $frame[0].srcdoc = r.data.html; } })
          .always(function () { $f.find('.idev-preview-frame').removeClass('loading'); });
      }, 250);
    }
    $f.on('input change', 'input, select, textarea', function () {
      if (this.name === 'design[template]') { $f.find('.idev-tpl').removeClass('on'); $(this).closest('.idev-tpl').addClass('on'); }
      if (this.name === 'design[color]') $f.find('.idev-tpl-thumb').css('--c', this.value);
      refresh();
    });
    $f.on('click', '.idev-designer-side .idev-seg [data-type]', function () {
      st.type = $(this).data('type');
      $(this).addClass('on').siblings().removeClass('on');
      $f.find('.idev-type').attr('hidden', true).filter('[data-type="' + st.type + '"]').removeAttr('hidden');
      refresh();
    });
    $f.on('click', '.idev-lang-tabs button', function () {
      var l = $(this).data('lang'), $t = $(this).closest('.idev-type');
      $(this).addClass('on').siblings().removeClass('on');
      $t.find('.idev-lang').attr('hidden', true).filter('[data-lang="' + l + '"]').removeAttr('hidden');
      st.lang = l; $f.find('.idev-prev-lang button').removeClass('on').filter('[data-lang="' + l + '"]').addClass('on');
      refresh();
    });
    $f.on('click', '.idev-prev-lang button', function () {
      st.lang = $(this).data('lang'); $(this).addClass('on').siblings().removeClass('on');
      $f.find('.idev-type:not([hidden]) .idev-lang-tabs button[data-lang="' + st.lang + '"]').trigger('click');
      refresh();
    });
    $f.on('click', '.idev-prev-dev button', function () {
      $(this).addClass('on').siblings().removeClass('on');
      $frame.css('width', $(this).data('w'));
    });
    $f.on('click', '.idev-prev-doc button', function () { st.doc = $(this).data('doc'); $(this).addClass('on').siblings().removeClass('on'); refresh(); });
    $f.on('change', '.idev-prev-paper', function () { st.paper = $(this).val(); refresh(); });
    $f.on('click', '.idev-media', function (e) {
      e.preventDefault();
      var $in = $(this).siblings('input'), fr = wp.media({ multiple: false, library: { type: 'image' } });
      fr.on('select', function () { $in.val(fr.state().get('selection').first().toJSON().url).trigger('change'); });
      fr.open();
    });
    $f.on('click', '.idev-send-test', function () {
      var $m = $f.find('.idev-test-msg').text('…'), fd = data('idev_email_test');
      fd.append('to', $f.find('[name=test_to]').val());
      $.ajax({ url: $f.data('ajax'), method: 'POST', data: fd, processData: false, contentType: false })
        .done(function (r) { $m.text(r.data || '').toggleClass('err', !r.success); })
        .fail(function () { $m.text('Error').addClass('err'); });
    });
    refresh();
  });
})(jQuery);
