<?php
/**
 * Printed documents (receipts, tickets, reports) for iDevApp Pro plugins: three looks, logo, header and footer
 * notes, signature lines and text size. A plugin draws its document body; this file adds the header, the look
 * (CSS) and the print page, and a designer screen with a live preview.
 */
defined('ABSPATH') || exit;

function idev_doc_templates() {
    return [
        'classic' => ['name' => __('Classic', 'idev-common'), 'desc' => __('Centred header, dashed lines — like a shop receipt', 'idev-common')],
        'modern' => ['name' => __('Modern', 'idev-common'), 'desc' => __('Logo on the left, coloured title and table header', 'idev-common')],
        'formal' => ['name' => __('Formal', 'idev-common'), 'desc' => __('Letterhead, full table lines and signatures — for offices and hospitals', 'idev-common')],
    ];
}
function idev_doc_design_defaults() {
    return ['template' => 'classic', 'color' => '#0f766e', 'logo' => '', 'show_logo' => '1', 'header_note' => '', 'footer_note' => '', 'signatures' => '', 'size' => '100', 'font' => 'Tahoma'];
}
function idev_doc_design_fields() {
    return [
        ['color', __('Colour', 'idev-common'), 'color'],
        ['logo', __('Logo', 'idev-common'), 'image', __('Empty = the logo in the plugin settings', 'idev-common')],
        ['show_logo', __('Show logo', 'idev-common'), 'checkbox'],
        ['header_note', __('Line under the name', 'idev-common'), 'text', __('e.g. licence number, opening hours, LINE ID', 'idev-common')],
        ['footer_note', __('Footer', 'idev-common'), 'textarea', __('e.g. "Goods sold are not returnable", thank-you text (empty = from the plugin settings)', 'idev-common')],
        ['signatures', __('Signature lines', 'idev-common'), 'text', __('Names separated by | e.g. Receiver|Cashier (empty = none; ignored on 80 mm)', 'idev-common')],
        ['size', __('Text size', 'idev-common'), 'select', '', ['90' => '90%', '100' => '100%', '110' => '110%', '120' => '120%']],
        ['font', __('Font', 'idev-common'), 'select', '', ['Tahoma' => 'Tahoma', 'Sarabun' => 'Sarabun (TH Sarabun-like)', 'Noto Sans Thai' => 'Noto Sans Thai']],
    ];
}
function idev_doc_design($option) {
    $d = get_option($option, []);
    $d = array_merge(idev_doc_design_defaults(), is_array($d) ? $d : []);
    if (!isset(idev_doc_templates()[$d['template']])) $d['template'] = 'classic';
    return $d;
}
function idev_doc_design_clean($in) {
    $in = (array) $in;
    $out = idev_doc_design_defaults();
    foreach (idev_doc_design_fields() as $f) {
        [$k, , $type, , $opt] = array_pad($f, 5, '');
        $v = isset($in[$k]) ? wp_unslash($in[$k]) : '';
        if ($type === 'color') $out[$k] = sanitize_hex_color($v) ?: $out[$k];
        elseif ($type === 'image') $out[$k] = esc_url_raw(trim($v), ['http', 'https']);
        elseif ($type === 'checkbox') $out[$k] = $v ? '1' : '0';
        elseif ($type === 'select') $out[$k] = array_key_exists($v, $opt) ? $v : $out[$k];
        elseif ($type === 'textarea') $out[$k] = sanitize_textarea_field($v);
        else $out[$k] = sanitize_text_field($v);
    }
    $t = sanitize_key($in['template'] ?? '');
    $out['template'] = isset(idev_doc_templates()[$t]) ? $t : 'classic';
    return $out;
}

/**
 * Header: organisation + document title. $org: name, address, phone, tax_id, logo, line (extra line), meta (HTML on the right, modern look).
 */
function idev_doc_header($design, $org, $title) {
    $d = array_merge(idev_doc_design_defaults(), (array) $design);
    $logo_url = $d['logo'] ?: ($org['logo'] ?? '');
    $logo = $d['show_logo'] === '1' && $logo_url ? '<img class="doc-logo" src="' . esc_url($logo_url) . '" alt="">' : '';
    $lines = [];
    if (!empty($org['address'])) $lines[] = nl2br(esc_html($org['address']));
    $c = array_filter([!empty($org['phone']) ? __('Tel.', 'idev-common') . ' ' . $org['phone'] : '', !empty($org['tax_id']) ? __('Tax ID', 'idev-common') . ' ' . $org['tax_id'] : '']);
    if ($c) $lines[] = esc_html(implode(' · ', $c));
    if (!empty($org['line'])) $lines[] = esc_html($org['line']);
    if ($d['header_note'] !== '') $lines[] = esc_html($d['header_note']);
    $info = '<div class="doc-org"><b class="doc-name">' . esc_html($org['name'] ?? get_bloginfo('name')) . '</b>' . ($lines ? '<div class="doc-addr">' . implode('<br>', $lines) . '</div>' : '') . '</div>';
    $t = '<div class="doc-title">' . esc_html($title) . '</div>';
    if ($d['template'] === 'modern') return '<div class="doc-head">' . $logo . $info . '<div class="doc-side">' . $t . ($org['meta'] ?? '') . '</div></div>';
    return '<div class="doc-head">' . $logo . $info . '</div>' . $t . ($org['meta'] ?? '');
}
function idev_doc_signatures($design, $compact = false) {
    $names = array_filter(array_map('trim', explode('|', (string) ($design['signatures'] ?? ''))));
    if (!$names || $compact) return '';
    $o = '<div class="doc-sign" style="grid-template-columns:repeat(' . count($names) . ',1fr)">';
    foreach ($names as $n) $o .= '<div><span></span>' . esc_html($n) . '<small>' . esc_html__('Date', 'idev-common') . ' ........../........../..........</small></div>';
    return $o . '</div>';
}
function idev_doc_footer($design, $fallback = '') {
    $t = trim((string) ($design['footer_note'] ?? '')) !== '' ? $design['footer_note'] : $fallback;
    return $t !== '' ? '<div class="doc-foot">' . nl2br(esc_html($t)) . '</div>' : '';
}

/** CSS for the look. $mono: dot-matrix / thermal printers (black only). */
function idev_doc_css($design, $mono = false) {
    $d = array_merge(idev_doc_design_defaults(), (array) $design);
    $c = $mono ? '#000' : (sanitize_hex_color($d['color']) ?: '#0f766e');
    $font = ['Tahoma' => 'Tahoma,"Leelawadee UI",Arial,sans-serif', 'Sarabun' => '"Sarabun","TH Sarabun New","Leelawadee UI",Tahoma,sans-serif', 'Noto Sans Thai' => '"Noto Sans Thai","Leelawadee UI",Tahoma,sans-serif'][$d['font']] ?? 'Tahoma,sans-serif';
    $size = max(80, min(130, (int) $d['size'])) / 100;
    $css = ".sheet{font-family:$font;--dc:$c}.sheet{font-size:calc(1em * $size)}"
        . '.doc-logo{max-height:52px;max-width:55%;display:block}.doc-name{font-size:1.18em}.doc-addr{line-height:1.45;font-size:.92em}'
        . '.doc-sign{display:grid;gap:26px;margin-top:34px;text-align:center}.doc-sign span{display:block;border-top:1px dotted #000;margin-bottom:4px}.doc-sign small{display:block;color:#444;font-size:.85em;margin-top:2px}'
        . '.doc-foot{text-align:center;margin-top:10px;padding-top:6px;line-height:1.5}';
    if ($d['template'] === 'modern') {
        $css .= '.doc-head{display:flex;gap:14px;align-items:flex-start;padding-bottom:10px;border-bottom:3px solid var(--dc);margin-bottom:10px}.doc-head .doc-logo{max-width:28%}.doc-org{flex:1}.doc-side{text-align:right;min-width:36%}'
            . '.doc-title{color:var(--dc);font-size:1.45em;font-weight:bold;text-transform:none;margin:0 0 4px;border:0!important;padding:0!important;text-align:right}.f-80mm .doc-title{text-align:center}.doc-side .meta{display:inline-grid;text-align:left}'
            . 'th{background:var(--dc);color:#fff;border:0!important;padding:5px 6px!important}td{padding:4px 6px!important;border-bottom:1px solid #e3e7ea}tbody tr:nth-child(even) td{background:#f6f8f9}'
            . '.sum .big td{background:var(--dc);color:#fff;border:0!important}.doc-foot{border-top:1px solid #ccc;color:#333}'
            . '.f-80mm .doc-head{flex-direction:column;align-items:center;text-align:center}.f-80mm .doc-side{text-align:center}.f-80mm th{background:none;color:#000;border-bottom:1px solid #000!important}.f-80mm tbody tr td{background:none}.f-80mm .sum .big td{background:none;color:#000;border-top:1px solid #000!important}';
    } elseif ($d['template'] === 'formal') {
        $css .= '.doc-head{text-align:center;padding-bottom:8px;border-bottom:3px double #000;margin-bottom:10px}.doc-head .doc-logo{margin:0 auto 6px}'
            . '.doc-title{text-align:center;font-weight:bold;font-size:1.2em;border:1.5px solid #000;display:table;margin:8px auto 10px;padding:4px 22px;letter-spacing:.02em}'
            . 'table:not(.sum):not(.rx) th,table:not(.sum):not(.rx) td{border:1px solid #000!important;padding:4px 6px!important}table:not(.sum):not(.rx) th{background:#f1f1f1;text-align:center}'
            . '.sum{margin-left:auto;width:60%}.f-80mm .sum{width:100%}.sum .big td{border-top:1.5px solid #000;border-bottom:3px double #000}.doc-foot{border-top:0}';
    } else {
        $css .= '.doc-head{text-align:center;margin-bottom:6px}.doc-head .doc-logo{margin:0 auto 4px}.doc-title{text-align:center;font-weight:bold;font-size:1.12em;border-top:1px dashed #000;border-bottom:1px dashed #000;padding:4px 0;margin:6px 0}.doc-foot{border-top:1px dashed #000}';
    }
    if ($mono) $css .= '.sheet *{color:#000!important;background:none!important}';
    return $css;
}

/**
 * Whole print page for reports and A4 / A5 documents. $a: title, body (HTML), design, paper (a4|a4l|a5|80mm),
 * org, trial (bool), papers (links [label => url]), preview (bool: no toolbar).
 */
function idev_doc_page($a) {
    $a += ['title' => '', 'body' => '', 'design' => idev_doc_design_defaults(), 'paper' => 'a4', 'org' => [], 'trial' => false, 'papers' => [], 'preview' => false, 'head' => true];
    $page = ['a4' => 'size:A4;margin:12mm', 'a4l' => 'size:A4 landscape;margin:10mm', 'a5' => 'size:A5;margin:9mm', '80mm' => 'size:80mm auto;margin:3mm'][$a['paper']] ?? 'size:A4;margin:12mm';
    $w = ['a4' => '210mm', 'a4l' => '297mm', 'a5' => '148mm', '80mm' => '80mm'][$a['paper']] ?? '210mm';
    $bar = '';
    if (!$a['preview']) {
        foreach ($a['papers'] as $l => $u) $bar .= '<a href="' . esc_url($u) . '">' . esc_html($l) . '</a>';
        $bar = '<div class="bar">' . $bar . '<button onclick="window.print()">🖨 ' . esc_html__('Print', 'idev-common') . '</button></div>';
    }
    $trial = $a['trial'] ? '<div class="trial">' . esc_html__('TRIAL — not activated', 'idev-common') . '</div>' : '';
    $head = $a['head'] ? idev_doc_header($a['design'], $a['org'] + ['name' => get_bloginfo('name')], $a['title']) : '';
    return '<!doctype html><html lang="' . esc_attr(function_exists('idev_lang') ? idev_lang() : 'th') . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . esc_html($a['title']) . '</title><style>'
        . '@page{' . $page . '}*{box-sizing:border-box}body{margin:0;background:#e9edf0;color:#111}'
        . '.sheet{background:#fff;width:' . $w . ';max-width:100%;min-height:' . ($a['paper'] === '80mm' ? '0' : '120mm') . ';margin:16px auto;padding:' . ($a['paper'] === '80mm' ? '3mm' : '12mm') . ';box-shadow:0 2px 14px rgba(0,0,0,.15);position:relative;font-size:' . ($a['paper'] === '80mm' ? '12px' : '13px') . ';line-height:1.5}'
        . 'table{width:100%;border-collapse:collapse;margin:6px 0 12px}th,td{text-align:left;padding:4px 5px;vertical-align:top}th{border-bottom:1px solid #000}.r{text-align:right;white-space:nowrap}.c{text-align:center}'
        . '.meta{display:grid;grid-template-columns:auto 1fr;gap:1px 10px;margin:6px 0}.muted,.lot{color:#555;font-size:.88em}h2{font-size:1.1em;margin:14px 0 4px}h3{font-size:1em;margin:12px 0 4px}'
        . '.bar{position:sticky;top:0;z-index:2;display:flex;gap:6px;flex-wrap:wrap;justify-content:center;padding:10px;background:#1d2327}.bar a,.bar button{font:13px Tahoma,sans-serif;color:#fff;background:#3c434a;border:0;border-radius:6px;padding:7px 12px;text-decoration:none;cursor:pointer}.bar button{background:#00a32a;font-weight:bold}'
        . '.trial{border:2px solid #000;text-align:center;font-weight:bold;letter-spacing:.08em;padding:3px;margin-bottom:8px}.sheet:has(.trial)::after{content:"TRIAL";position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:bold 110px sans-serif;color:rgba(0,0,0,.07);transform:rotate(-28deg);pointer-events:none}'
        . '@media print{body{background:#fff}.bar{display:none}.sheet{margin:0;box-shadow:none;width:auto;min-height:0;padding:0}}'
        . idev_doc_css($a['design'], false) . '</style></head><body class="f-' . esc_attr($a['paper']) . '">' . $bar . '<div class="sheet">' . $trial . $head . $a['body'] . '</div>'
        . ($a['preview'] ? '' : '<script>if(location.hash==="#print")addEventListener("load",function(){setTimeout(print,300)})</script>') . '</body></html>';
}

/* ---------- Designer ---------- */

$GLOBALS['idev_doc_designers'] = $GLOBALS['idev_doc_designers'] ?? [];
/** $args: option, docs [doc => label], papers [paper => label], preview callable($doc, $design, $paper) → HTML page, locked callable. */
function idev_register_doc_designer($id, $args) { $GLOBALS['idev_doc_designers'][$id] = $args; }
function idev_doc_designer($id) { return $GLOBALS['idev_doc_designers'][$id] ?? null; }

function idev_doc_designer_ui($id, $page_url) {
    $dz = idev_doc_designer($id);
    if (!$dz) return;
    $design = idev_doc_design($dz['option']);
    wp_enqueue_media();
    wp_enqueue_script('idev-designer', plugins_url('idev-designer.js', IDEV_COMMON_DIR . '/idev-common.php'), ['jquery'], IDEV_COMMON_VERSION, true);
    $locked = isset($dz['locked']) ? (string) call_user_func($dz['locked']) : '';
    if ($locked !== '') echo '<div class="idev-upsell"><p>' . wp_kses_post($locked) . '</p></div>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="idev-designer" data-kind="doc" data-id="' . esc_attr($id) . '" data-nonce="' . esc_attr(wp_create_nonce('idev_designer_' . $id)) . '" data-ajax="' . esc_url(admin_url('admin-ajax.php')) . '">';
    wp_nonce_field('idev_doc_save_' . $id);
    echo '<input type="hidden" name="action" value="idev_doc_save"><input type="hidden" name="id" value="' . esc_attr($id) . '"><input type="hidden" name="back" value="' . esc_url($page_url) . '">';
    echo '<div class="idev-tpl-gallery">';
    foreach (idev_doc_templates() as $k => $t) echo '<label class="idev-tpl' . ($design['template'] === $k ? ' on' : '') . '"><input type="radio" name="design[template]" value="' . esc_attr($k) . '"' . checked($design['template'], $k, false) . '><span class="idev-tpl-thumb idev-tpl-doc-' . esc_attr($k) . '" style="--c:' . esc_attr($design['color']) . '"><i></i><i></i><i></i><b></b></span><strong>' . esc_html($t['name']) . '</strong><small>' . esc_html($t['desc']) . '</small></label>';
    echo '</div><div class="idev-designer-cols"><div class="idev-designer-side"><div class="idev-panel"><h3>' . esc_html__('Look', 'idev-common') . '</h3><div class="idev-fields">';
    foreach (idev_doc_design_fields() as $f) idev_designer_field('design', $f, $design[$f[0]] ?? '');
    echo '</div><p class="description">' . esc_html__('Applies to every document listed on the right. Name, address, phone and tax ID come from the plugin settings.', 'idev-common') . '</p></div><p class="idev-designer-actions"><button class="button button-primary button-hero">' . esc_html__('Save design', 'idev-common') . '</button></p></div>';
    echo '<div class="idev-designer-preview"><div class="idev-preview-bar"><div class="idev-seg idev-prev-doc">';
    $first = true;
    foreach ($dz['docs'] as $k => $l) { echo '<button type="button" data-doc="' . esc_attr($k) . '"' . ($first ? ' class="on"' : '') . '>' . esc_html($l) . '</button>'; $first = false; }
    echo '</div>';
    if (!empty($dz['papers'])) { echo '<select class="idev-prev-paper">'; foreach ($dz['papers'] as $k => $l) echo '<option value="' . esc_attr($k) . '">' . esc_html($l) . '</option>'; echo '</select>'; }
    echo '</div><div class="idev-preview-frame is-doc"><iframe title="' . esc_attr__('Preview', 'idev-common') . '"></iframe></div></div></div></form>';
}
add_action('admin_post_idev_doc_save', function () {
    $id = sanitize_key($_POST['id'] ?? '');
    $dz = idev_doc_designer($id);
    if (!$dz || !current_user_can('manage_options') || !check_admin_referer('idev_doc_save_' . $id)) wp_die('Forbidden', 403);
    update_option($dz['option'], idev_doc_design_clean($_POST['design'] ?? []), false);
    $back = esc_url_raw(wp_unslash($_POST['back'] ?? '')) ?: admin_url();
    wp_safe_redirect(add_query_arg('saved', '1', $back));
    exit;
});
