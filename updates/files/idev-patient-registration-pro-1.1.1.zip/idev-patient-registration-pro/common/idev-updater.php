<?php
/**
 * Updates for iDevApp plugins and themes that are not hosted on WordPress.org.
 * Plugins / themes opt in with the header "Update URI: https://idevapp.me/updates/". WordPress then asks this file
 * (filters update_plugins_idevapp.me / update_themes_idevapp.me) instead of WordPress.org. The list of versions is a
 * small JSON file on idevapp.me; the zip files are on GitHub Releases. Updates appear in Dashboard → Updates and
 * install automatically unless turned off (iDevApp → Dashboard).
 */
defined('ABSPATH') || exit;

if (!defined('IDEV_UPDATE_MANIFEST')) define('IDEV_UPDATE_MANIFEST', 'https://idevapp.me/updates/plugins.json');

/** Manifest: ['plugins' => [slug => info], 'themes' => [slug => info]]. Cached 6 hours (1 hour after an error). */
function idev_update_manifest($force = false) {
    $cached = get_site_transient('idev_update_manifest');
    if (!$force && is_array($cached)) return $cached;
    $res = wp_remote_get(IDEV_UPDATE_MANIFEST, ['timeout' => 10, 'headers' => ['Accept' => 'application/json'], 'user-agent' => 'iDevApp-Updater/' . IDEV_COMMON_VERSION . '; ' . home_url('/')]);
    $data = !is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200 ? json_decode(wp_remote_retrieve_body($res), true) : null;
    if (!is_array($data)) { $data = ['plugins' => [], 'themes' => [], 'error' => is_wp_error($res) ? $res->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code($res)]; set_site_transient('idev_update_manifest', $data, HOUR_IN_SECONDS); return $data; }
    $data += ['plugins' => [], 'themes' => []];
    $data['checked'] = time();
    set_site_transient('idev_update_manifest', $data, 6 * HOUR_IN_SECONDS);
    return $data;
}
function idev_update_info($kind, $slug) {
    $m = idev_update_manifest();
    $i = $m[$kind][$slug] ?? null;
    if (!is_array($i) || empty($i['version']) || empty($i['package'])) return null;
    // Only GitHub release files or idevapp.me may be installed.
    $host = wp_parse_url($i['package'], PHP_URL_HOST);
    if (!in_array($host, (array) apply_filters('idev_update_hosts', ['github.com', 'idevapp.me', 'www.idevapp.me']), true)) return null;
    return $i;
}

add_filter('update_plugins_idevapp.me', function ($update, $plugin_data, $plugin_file) {
    $slug = dirname($plugin_file);
    $i = idev_update_info('plugins', $slug);
    if (!$i) return $update;
    return [
        'id' => 'idevapp.me/' . $slug, 'slug' => $slug, 'plugin' => $plugin_file, 'version' => $i['version'], 'url' => $i['homepage'] ?? 'https://idevapp.me/plugins/',
        'package' => $i['package'], 'tested' => $i['tested'] ?? '', 'requires' => $i['requires'] ?? '', 'requires_php' => $i['requires_php'] ?? '',
        'icons' => ['svg' => 'https://idevapp.me/favicon.svg'], 'autoupdate' => idev_auto_update_on(),
    ];
}, 10, 3);

add_filter('update_themes_idevapp.me', function ($update, $theme_data, $stylesheet) {
    $i = idev_update_info('themes', $stylesheet);
    if (!$i) return $update;
    return ['id' => 'idevapp.me/' . $stylesheet, 'theme' => $stylesheet, 'version' => $i['version'], 'url' => $i['homepage'] ?? 'https://idevapp.me/', 'package' => $i['package'], 'tested' => $i['tested'] ?? '', 'requires' => $i['requires'] ?? '', 'requires_php' => $i['requires_php'] ?? '', 'autoupdate' => idev_auto_update_on()];
}, 10, 3);

/* "View details" on the Plugins and Updates screens. */
add_filter('plugins_api', function ($result, $action, $args) {
    if ($action !== 'plugin_information' || empty($args->slug)) return $result;
    $i = idev_update_info('plugins', $args->slug);
    if (!$i) return $result;
    return (object) [
        'name' => $i['name'] ?? $args->slug, 'slug' => $args->slug, 'version' => $i['version'], 'author' => '<a href="https://idevapp.me/">iDevApp</a>',
        'homepage' => $i['homepage'] ?? 'https://idevapp.me/plugins/', 'requires' => $i['requires'] ?? '', 'requires_php' => $i['requires_php'] ?? '', 'tested' => $i['tested'] ?? '',
        'last_updated' => $i['date'] ?? '', 'download_link' => $i['package'],
        'sections' => ['description' => wp_kses_post($i['description'] ?? ''), 'changelog' => wp_kses_post($i['changelog'] ?? '')],
        'banners' => [], 'icons' => [],
    ];
}, 20, 3);

/* Automatic updates: on by default for iDevApp plugins and themes. */
function idev_auto_update_on() { return get_site_option('idev_auto_update', '1') === '1'; }
function idev_is_idev_item($kind, $slug) { return (bool) idev_update_info($kind, $slug); }
add_filter('auto_update_plugin', function ($update, $item) {
    $slug = $item->slug ?? (isset($item->plugin) ? dirname($item->plugin) : '');
    return $slug && idev_is_idev_item('plugins', $slug) ? idev_auto_update_on() : $update;
}, 20, 2);
add_filter('auto_update_theme', function ($update, $item) {
    $slug = $item->theme ?? '';
    return $slug && idev_is_idev_item('themes', $slug) ? idev_auto_update_on() : $update;
}, 20, 2);

/* Dashboard box. */
function idev_update_box() {
    if (!current_user_can('update_plugins')) return;
    $m = idev_update_manifest();
    $rows = '';
    foreach (get_plugins() as $file => $p) {
        if (stripos($p['UpdateURI'] ?? '', 'idevapp.me') === false || !is_plugin_active($file)) continue;
        $i = idev_update_info('plugins', dirname($file));
        $new = $i && version_compare($i['version'], $p['Version'], '>');
        $rows .= '<tr><td>' . esc_html($p['Name']) . '</td><td>' . esc_html($p['Version']) . '</td><td>' . ($i ? ($new ? '<b class="idev-up-new">' . esc_html($i['version']) . '</b>' : '<span class="idev-up-ok">✓ ' . esc_html__('Latest', 'idev-common') . '</span>') : '—') . '</td></tr>';
    }
    foreach (wp_get_themes() as $slug => $t) {
        if (stripos((string) $t->get('UpdateURI'), 'idevapp.me') === false || ($slug !== get_stylesheet() && $slug !== get_template())) continue;
        $i = idev_update_info('themes', $slug);
        $new = $i && version_compare($i['version'], $t->get('Version'), '>');
        $rows .= '<tr><td>' . esc_html($t->get('Name')) . ' <small>(' . esc_html__('theme', 'idev-common') . ')</small></td><td>' . esc_html($t->get('Version')) . '</td><td>' . ($i ? ($new ? '<b class="idev-up-new">' . esc_html($i['version']) . '</b>' : '<span class="idev-up-ok">✓ ' . esc_html__('Latest', 'idev-common') . '</span>') : '—') . '</td></tr>';
    }
    if ($rows === '') return;
    $act = function ($do, $label, $cls = 'button') { return '<a class="' . $cls . '" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=idev_updates&do=' . $do), 'idev_updates')) . '">' . esc_html($label) . '</a>'; };
    echo '<div class="idev-card idev-updates"><h2>' . esc_html__('Updates', 'idev-common') . '</h2><table class="widefat striped"><thead><tr><th>' . esc_html__('Plugin', 'idev-common') . '</th><th>' . esc_html__('Installed', 'idev-common') . '</th><th>' . esc_html__('Available', 'idev-common') . '</th></tr></thead><tbody>' . $rows . '</tbody></table>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above
    echo '<p>' . (idev_auto_update_on() ? '<span class="idev-up-ok">● ' . esc_html__('Automatic updates are on', 'idev-common') . '</span> ' . $act('off', __('Turn off', 'idev-common')) : '<span>○ ' . esc_html__('Automatic updates are off', 'idev-common') . '</span> ' . $act('on', __('Turn on', 'idev-common'), 'button button-primary')) . ' ' . $act('check', __('Check now', 'idev-common')) . ' <a class="button" href="' . esc_url(admin_url('update-core.php')) . '">' . esc_html__('Dashboard → Updates', 'idev-common') . '</a></p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<p class="description">' . esc_html(!empty($m['error']) ? sprintf(__('Could not check for updates: %s', 'idev-common'), $m['error']) : (!empty($m['checked']) ? sprintf(__('Checked %s', 'idev-common'), wp_date('j M Y H:i', (int) $m['checked'])) : '')) . ' · ' . esc_html__('Updates come from idevapp.me. Your settings and data are kept.', 'idev-common') . '</p></div>';
}
add_action('admin_post_idev_updates', function () {
    if (!current_user_can('update_plugins') || !check_admin_referer('idev_updates')) wp_die('Forbidden', 403);
    $do = sanitize_key($_GET['do'] ?? '');
    if ($do === 'on' || $do === 'off') update_site_option('idev_auto_update', $do === 'on' ? '1' : '0');
    if ($do === 'check') { idev_update_manifest(true); delete_site_transient('update_plugins'); delete_site_transient('update_themes'); wp_update_plugins(); wp_update_themes(); }
    wp_safe_redirect(admin_url('admin.php?page=idevapp'));
    exit;
});

/* Also when the WordPress.org check fails (e.g. a hospital network that blocks it): add iDevApp updates to the list. */
add_filter('site_transient_update_plugins', function ($t) {
    if (!is_object($t)) return $t;
    if (!function_exists('get_plugins')) require_once ABSPATH . 'wp-admin/includes/plugin.php';
    foreach (get_plugins() as $file => $p) {
        if (stripos($p['UpdateURI'] ?? '', 'idevapp.me') === false || isset($t->response[$file])) continue;
        $i = idev_update_info('plugins', dirname($file));
        if (!$i || !version_compare($i['version'], $p['Version'], '>')) continue;
        if (!isset($t->response) || !is_array($t->response)) $t->response = [];
        $t->response[$file] = (object) ['id' => 'idevapp.me/' . dirname($file), 'slug' => dirname($file), 'plugin' => $file, 'new_version' => $i['version'], 'url' => $i['homepage'] ?? 'https://idevapp.me/plugins/', 'package' => $i['package'], 'tested' => $i['tested'] ?? '', 'requires' => $i['requires'] ?? '', 'requires_php' => $i['requires_php'] ?? '', 'icons' => [], 'banners' => []];
    }
    return $t;
}, 20);
