/* iDevApp blocks: live server preview + settings panel built from window.IDEV_BLOCKS. */
(function (wp) {
  const h = wp.element.createElement;
  const { InspectorControls, useBlockProps } = wp.blockEditor;
  const { PanelBody, TextControl, TextareaControl, ToggleControl, SelectControl, RangeControl, Disabled } = wp.components;
  const SSR = wp.serverSideRender;
  (window.IDEV_BLOCKS || []).forEach((def) => {
    if (wp.blocks.getBlockType(def.name) && wp.blocks.getBlockType(def.name).edit) return;
    wp.blocks.registerBlockType(def.name, {
      title: def.title, icon: def.icon, category: 'idevapp', description: def.description,
      edit: function (props) {
        const a = props.attributes;
        const set = (k) => (v) => props.setAttributes({ [k]: v });
        const controls = Object.keys(def.fields).map((k) => {
          const [control, label, , opts] = def.fields[k];
          if (control === 'toggle') return h(ToggleControl, { key: k, label, checked: !!a[k], onChange: set(k) });
          if (control === 'select') return h(SelectControl, { key: k, label, value: a[k], options: Object.keys(opts).map((v) => ({ value: v, label: opts[v] })), onChange: set(k) });
          if (control === 'number') return h(RangeControl, { key: k, label, value: Number(a[k]), min: opts[0], max: opts[1], onChange: (v) => props.setAttributes({ [k]: Number(v) }) });
          if (control === 'textarea') return h(TextareaControl, { key: k, label, value: a[k] || '', onChange: set(k) });
          return h(TextControl, { key: k, label, value: a[k] || '', onChange: set(k) });
        });
        return h(wp.element.Fragment, null,
          h(InspectorControls, null, h(PanelBody, { title: def.title, initialOpen: true }, controls)),
          h('div', useBlockProps(), h(Disabled, null, h(SSR, { block: def.name, attributes: a, httpMethod: 'POST' }))));
      },
      save: () => null,
    });
  });
})(window.wp);
