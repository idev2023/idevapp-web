<?php
/**
 * E-mail designs for iDevApp Pro plugins. A message is built from parts (title, text, details, button …) and drawn
 * with one of the templates below as e-mail-safe HTML (tables and inline styles, so it looks right in Gmail, Outlook
 * and phone mail apps). Plugins register a designer (idev_register_email_designer) and get a design screen with
 * a live preview, the texts of each message and a "send test" button.
 */
defined('ABSPATH') || exit;

function idev_email_templates() {
    return [
        'modern' => ['name' => __('Modern', 'idev-common'), 'desc' => __('Coloured header with logo, rounded card, big button', 'idev-common')],
        'letter' => ['name' => __('Official letter', 'idev-common'), 'desc' => __('White letterhead, thin colour line, bordered details — for hospitals and government offices', 'idev-common')],
        'minimal' => ['name' => __('Minimal', 'idev-common'), 'desc' => __('Clean white, accent line, reads like a personal e-mail', 'idev-common')],
    ];
}
function idev_email_design_defaults() {
    return ['template' => 'modern', 'color' => '#0f766e', 'button' => '#0f766e', 'bg' => '#eef3f6', 'logo' => '', 'logo_h' => '44', 'header' => '', 'footer' => '', 'radius' => '14', 'button_radius' => '999', 'font' => 'Tahoma, Arial, sans-serif'];
}
function idev_email_design_fields() {
    return [
        ['color', __('Main colour', 'idev-common'), 'color'], ['button', __('Button colour', 'idev-common'), 'color'], ['bg', __('Background', 'idev-common'), 'color'],
        ['logo', __('Logo', 'idev-common'), 'image', __('PNG or JPG, about 300 × 90 px. Empty = the name of the website.', 'idev-common')],
        ['logo_h', __('Logo height (px)', 'idev-common'), 'number', '', [24, 90]],
        ['header', __('Text under the name', 'idev-common'), 'text', __('e.g. a slogan or the department', 'idev-common')],
        ['footer', __('Footer', 'idev-common'), 'textarea', __('Address, phone, LINE, opening hours … (empty = from the plugin settings)', 'idev-common')],
        ['radius', __('Card corners', 'idev-common'), 'select', '', ['0' => __('Square', 'idev-common'), '8' => __('Slightly round', 'idev-common'), '14' => __('Round', 'idev-common'), '22' => __('Very round', 'idev-common')]],
        ['button_radius', __('Button shape', 'idev-common'), 'select', '', ['4' => __('Square', 'idev-common'), '10' => __('Rounded', 'idev-common'), '999' => __('Pill', 'idev-common')]],
        ['font', __('Font', 'idev-common'), 'select', '', ['Tahoma, Arial, sans-serif' => 'Tahoma', "'Sarabun', Tahoma, sans-serif" => 'Sarabun', "'Noto Sans Thai', 'Leelawadee UI', Tahoma, sans-serif" => 'Noto Sans Thai', "Georgia, 'Times New Roman', serif" => __('Serif', 'idev-common')]],
    ];
}
function idev_email_design($option) {
    $d = get_option($option, []);
    $d = array_merge(idev_email_design_defaults(), is_array($d) ? $d : []);
    if (!isset(idev_email_templates()[$d['template']])) $d['template'] = 'modern';
    return $d;
}
function idev_email_hex($v, $fallback) { $v = sanitize_hex_color((string) $v); return $v ?: $fallback; }
/** Lighter tint of a colour for boxes: mix with white. */
function idev_email_tint($hex, $amount = .9) {
    $hex = ltrim(idev_email_hex($hex, '#0f766e'), '#');
    if (strlen($hex) === 3) $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    $rgb = array_map('hexdec', str_split($hex, 2));
    return sprintf('#%02x%02x%02x', ...array_map(function ($c) use ($amount) { return (int) round($c + (255 - $c) * $amount); }, $rgb));
}

/** Plain text with blank lines between paragraphs → HTML paragraphs. **bold** is kept. */
function idev_email_text_html($text, $style = 'margin:0 0 14px') {
    $o = '';
    foreach (preg_split("/\n{2,}/", trim(str_replace("\r", '', (string) $text))) as $para) {
        if (trim($para) === '') continue;
        $h = nl2br(esc_html(trim($para)));
        $h = preg_replace('/\*\*(.+?)\*\*/u', '<strong>$1</strong>', $h);
        $o .= '<p style="' . $style . '">' . $h . '</p>';
    }
    return $o;
}

/**
 * Draws a message. $p: site, title, preheader, html (body HTML) or text, rows [[label, value]], button [label, url],
 * links [[label, url]], note, footer, lang, image (inline image URL, e.g. cid:card).
 */
function idev_email_render($design, $p) {
    $d = array_merge(idev_email_design_defaults(), (array) $design);
    $c = idev_email_hex($d['color'], '#0f766e');
    $btn = idev_email_hex($d['button'], $c);
    $bg = idev_email_hex($d['bg'], '#eef3f6');
    $r = (int) $d['radius'];
    $br = (int) $d['button_radius'];
    $font = esc_attr(wp_strip_all_tags($d['font']));
    $site = esc_html($p['site'] ?? get_bloginfo('name'));
    $title = esc_html($p['title'] ?? '');
    $body = ($p['html'] ?? '') !== '' ? $p['html'] : idev_email_text_html($p['text'] ?? '');
    $footer = trim((string) ($d['footer'] !== '' ? $d['footer'] : ($p['footer'] ?? '')));
    $logo = $d['logo'] ? '<img src="' . esc_url($d['logo']) . '" alt="' . $site . '" height="' . (int) $d['logo_h'] . '" style="height:' . (int) $d['logo_h'] . 'px;width:auto;border:0;display:block">' : '';
    $tpl = $d['template'];

    // Details table
    $rows = '';
    foreach ((array) ($p['rows'] ?? []) as $row) {
        if (($row[1] ?? '') === '') continue;
        if ($tpl === 'letter') $rows .= '<tr><td style="padding:8px 12px;border:1px solid #d7dde2;background:#f6f8fa;width:34%;color:#46535e;font-size:14px">' . esc_html($row[0]) . '</td><td style="padding:8px 12px;border:1px solid #d7dde2;font-size:15px;color:#13202b"><strong>' . esc_html($row[1]) . '</strong></td></tr>';
        else $rows .= '<tr><td style="padding:6px 0;color:#5d6b77;font-size:14px;width:38%;vertical-align:top">' . esc_html($row[0]) . '</td><td style="padding:6px 0;font-size:15px;color:#13202b;vertical-align:top"><strong>' . esc_html($row[1]) . '</strong></td></tr>';
    }
    if ($rows !== '') {
        if ($tpl === 'modern') $rows = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:' . idev_email_tint($c, .92) . ';border-radius:' . max(6, $r - 4) . 'px;margin:4px 0 18px"><tr><td style="padding:12px 16px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0">' . $rows . '</table></td></tr></table>';
        elseif ($tpl === 'letter') $rows = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin:4px 0 18px">' . $rows . '</table>';
        else $rows = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-top:1px solid #e6ebef;border-bottom:1px solid #e6ebef;margin:4px 0 18px">' . $rows . '</table>';
    }
    // Button and links
    $button = '';
    if (!empty($p['button'][1])) {
        $label = esc_html($p['button'][0]); $url = esc_url($p['button'][1]);
        $button = $tpl === 'minimal'
            ? '<p style="margin:18px 0 8px"><a href="' . $url . '" style="color:' . $btn . ';font-weight:bold;text-decoration:none;border-bottom:2px solid ' . $btn . ';padding-bottom:2px">' . $label . ' →</a></p>'
            : '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:18px 0 8px"><tr><td style="background:' . $btn . ';border-radius:' . $br . 'px"><a href="' . $url . '" style="display:inline-block;padding:13px 26px;color:#ffffff;font-weight:bold;text-decoration:none;font-size:15px;font-family:' . $font . '">' . $label . '</a></td></tr></table>';
    }
    $links = '';
    foreach ((array) ($p['links'] ?? []) as $l) if (!empty($l[1])) $links .= '<a href="' . esc_url($l[1]) . '" style="color:' . $c . ';font-size:14px;margin-right:16px">' . esc_html($l[0]) . '</a>';
    if ($links !== '') $links = '<p style="margin:8px 0 0">' . $links . '</p>';
    $image = !empty($p['image']) ? '<p style="margin:6px 0 18px"><img src="' . esc_attr($p['image']) . '" alt="" style="max-width:100%;height:auto;border-radius:12px;display:block"></p>' : '';
    $note = !empty($p['note']) ? '<p style="margin:14px 0 0;color:#6b7984;font-size:13px">' . esc_html($p['note']) . '</p>' : '';
    $foot = $footer !== '' ? nl2br(esc_html($footer)) : $site;
    $pre = !empty($p['preheader']) ? '<div style="display:none;max-height:0;overflow:hidden;opacity:0">' . esc_html($p['preheader']) . '</div>' : '';
    $content = $body . $rows . $image . $button . $links . $note;
    $sub = $d['header'] !== '' ? esc_html($d['header']) : '';

    if ($tpl === 'letter') {
        $head = '<tr><td style="padding:22px 28px 14px;border-bottom:3px solid ' . $c . '"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td style="vertical-align:middle">' . ($logo ?: '<span style="font-size:19px;font-weight:bold;color:' . $c . '">' . $site . '</span>') . '</td><td style="text-align:right;vertical-align:middle;font-size:13px;color:#46535e">' . ($logo ? '<strong style="color:#13202b;font-size:15px">' . $site . '</strong><br>' : '') . $sub . '</td></tr></table></td></tr>';
        $main = '<tr><td style="padding:24px 28px 8px"><h1 style="margin:0 0 16px;font-size:20px;color:#13202b;font-weight:bold">' . $title . '</h1><div style="color:#1f2d38;font-size:15px;line-height:1.75">' . $content . '</div></td></tr>';
        $tail = '<tr><td style="padding:18px 28px 24px"><div style="border-top:1px solid #d7dde2;padding-top:12px;color:#5d6b77;font-size:12.5px;line-height:1.6">' . $foot . '</div></td></tr>';
        $card = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:620px;background:#ffffff;border:1px solid #d7dde2;border-radius:' . min($r, 6) . 'px">' . $head . $main . $tail . '</table>';
    } elseif ($tpl === 'minimal') {
        $head = '<tr><td style="padding:26px 30px 6px">' . ($logo ?: '<span style="font-size:16px;font-weight:bold;color:#13202b">' . $site . '</span>') . '</td></tr>';
        $main = '<tr><td style="padding:12px 30px 6px"><h1 style="margin:0 0 16px;font-size:22px;color:#13202b;border-left:4px solid ' . $c . ';padding-left:12px;line-height:1.3">' . $title . '</h1><div style="color:#24323d;font-size:15.5px;line-height:1.8">' . $content . '</div></td></tr>';
        $tail = '<tr><td style="padding:22px 30px 28px;color:#7a8791;font-size:12.5px;line-height:1.6">' . $foot . '</td></tr>';
        $card = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:' . $r . 'px">' . $head . $main . $tail . '</table>';
    } else {
        $head = '<tr><td style="background:' . $c . ';padding:22px 26px;border-radius:' . $r . 'px ' . $r . 'px 0 0">' . ($logo ? '<table role="presentation" cellpadding="0" cellspacing="0"><tr><td style="background:#ffffff;border-radius:10px;padding:8px 10px">' . $logo . '</td></tr></table>' : '<span style="color:#ffffff;font-size:19px;font-weight:bold">' . $site . '</span>') . ($sub || $logo ? '<div style="color:#ffffff;opacity:.88;font-size:13px;margin-top:8px">' . ($logo ? $site . ($sub ? ' · ' : '') : '') . $sub . '</div>' : '') . '</td></tr>';
        $main = '<tr><td style="padding:26px 26px 10px"><h1 style="margin:0 0 14px;font-size:22px;color:#13202b;line-height:1.3">' . $title . '</h1><div style="color:#24323d;font-size:15px;line-height:1.75">' . $content . '</div></td></tr>';
        $tail = '<tr><td style="padding:16px 26px 22px;background:#f7f9fa;border-radius:0 0 ' . $r . 'px ' . $r . 'px;color:#6b7984;font-size:12.5px;line-height:1.6">' . $foot . '</td></tr>';
        $card = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:' . $r . 'px;box-shadow:0 2px 10px rgba(16,40,60,.08)">' . $head . $main . $tail . '</table>';
    }
    $lang = esc_attr($p['lang'] ?? 'th');
    return '<!doctype html><html lang="' . $lang . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . $title . '</title></head><body style="margin:0;padding:0;background:' . $bg . '">' . $pre
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:' . $bg . ';font-family:' . $font . '"><tr><td align="center" style="padding:26px 12px">' . $card
        . '<p style="margin:14px 0 0;color:#9aa6af;font-size:11.5px;font-family:' . $font . '">' . $site . '</p></td></tr></table></body></html>';
}

/* ---------- Designer screen ---------- */

$GLOBALS['idev_email_designers'] = $GLOBALS['idev_email_designers'] ?? [];
/**
 * $args: option (design option name), types [type => label], vars (placeholder help),
 * texts (callable($type) → [enabled, subject, body, subject_en, body_en]), save_texts (callable($type, $texts)),
 * preview (callable($type, $lang, $design, $texts) → HTML), send (callable($type, $lang, $to, $design) → bool),
 * locked (callable → message when Pro is not active, or '').
 */
function idev_register_email_designer($id, $args) { $GLOBALS['idev_email_designers'][$id] = $args; }
function idev_email_designer($id) { return $GLOBALS['idev_email_designers'][$id] ?? null; }

/** Prints the designer (inside the caller's page). */
function idev_email_designer_ui($id, $page_url) {
    $dz = idev_email_designer($id);
    if (!$dz) return;
    $design = idev_email_design($dz['option']);
    wp_enqueue_media();
    wp_enqueue_script('idev-designer', plugins_url('idev-designer.js', IDEV_COMMON_DIR . '/idev-common.php'), ['jquery'], IDEV_COMMON_VERSION, true);
    $types = $dz['types'];
    $cur = sanitize_key($_GET['type'] ?? '') ?: array_key_first($types); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (!isset($types[$cur])) $cur = array_key_first($types);
    $locked = isset($dz['locked']) ? (string) call_user_func($dz['locked']) : '';
    if ($locked !== '') echo '<div class="idev-upsell"><p>' . wp_kses_post($locked) . '</p></div>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="idev-designer" data-kind="email" data-id="' . esc_attr($id) . '" data-nonce="' . esc_attr(wp_create_nonce('idev_designer_' . $id)) . '" data-ajax="' . esc_url(admin_url('admin-ajax.php')) . '">';
    wp_nonce_field('idev_email_save_' . $id);
    echo '<input type="hidden" name="action" value="idev_email_save"><input type="hidden" name="id" value="' . esc_attr($id) . '"><input type="hidden" name="back" value="' . esc_url($page_url) . '">';
    // Templates
    echo '<div class="idev-tpl-gallery">';
    foreach (idev_email_templates() as $k => $t) {
        echo '<label class="idev-tpl' . ($design['template'] === $k ? ' on' : '') . '"><input type="radio" name="design[template]" value="' . esc_attr($k) . '"' . checked($design['template'], $k, false) . '><span class="idev-tpl-thumb idev-tpl-email-' . esc_attr($k) . '" style="--c:' . esc_attr($design['color']) . '"><i></i><i></i><i></i><b></b></span><strong>' . esc_html($t['name']) . '</strong><small>' . esc_html($t['desc']) . '</small></label>';
    }
    echo '</div><div class="idev-designer-cols"><div class="idev-designer-side">';
    // Messages
    echo '<div class="idev-panel"><h3>' . esc_html__('Messages', 'idev-common') . '</h3><div class="idev-seg" role="tablist">';
    foreach ($types as $k => $l) echo '<button type="button" class="' . ($k === $cur ? 'on' : '') . '" data-type="' . esc_attr($k) . '">' . esc_html($l) . '</button>';
    echo '</div>';
    foreach ($types as $k => $l) {
        $t = call_user_func($dz['texts'], $k) + ['enabled' => null, 'subject' => '', 'body' => '', 'subject_en' => '', 'body_en' => ''];
        echo '<div class="idev-type" data-type="' . esc_attr($k) . '"' . ($k === $cur ? '' : ' hidden') . '>';
        if ($t['enabled'] !== null) echo '<label class="idev-switch"><input type="checkbox" name="texts[' . esc_attr($k) . '][enabled]" value="1"' . checked($t['enabled'], true, false) . '> <span>' . esc_html__('Send this e-mail', 'idev-common') . '</span></label>';
        echo '<div class="idev-lang-tabs"><button type="button" class="on" data-lang="th">ไทย</button><button type="button" data-lang="en">English</button></div>';
        foreach (['th' => '', 'en' => '_en'] as $lang => $sfx) {
            echo '<div class="idev-lang" data-lang="' . esc_attr($lang) . '"' . ($lang === 'th' ? '' : ' hidden') . '><label>' . esc_html__('Subject', 'idev-common') . '<input type="text" name="texts[' . esc_attr($k) . '][subject' . $sfx . ']" value="' . esc_attr($t['subject' . $sfx]) . '"></label>';
            echo '<label>' . esc_html__('Message', 'idev-common') . '<textarea rows="8" name="texts[' . esc_attr($k) . '][body' . $sfx . ']">' . esc_textarea($t['body' . $sfx]) . '</textarea></label></div>';
        }
        echo '</div>';
    }
    if (!empty($dz['vars'])) echo '<p class="description idev-vars">' . esc_html__('Placeholders:', 'idev-common') . ' ' . esc_html($dz['vars']) . ' · ' . esc_html__('Blank line = new paragraph, **text** = bold.', 'idev-common') . '</p>';
    echo '</div><div class="idev-panel"><h3>' . esc_html__('Look', 'idev-common') . '</h3><div class="idev-fields">';
    foreach (idev_email_design_fields() as $f) idev_designer_field('design', $f, $design[$f[0]] ?? '');
    echo '</div></div><p class="idev-designer-actions"><button class="button button-primary button-hero">' . esc_html__('Save design', 'idev-common') . '</button></p></div>';
    // Preview
    echo '<div class="idev-designer-preview"><div class="idev-preview-bar"><div class="idev-seg idev-prev-lang"><button type="button" class="on" data-lang="th">ไทย</button><button type="button" data-lang="en">EN</button></div><div class="idev-seg idev-prev-dev"><button type="button" class="on" data-w="100%">' . esc_html__('Computer', 'idev-common') . '</button><button type="button" data-w="390px">' . esc_html__('Phone', 'idev-common') . '</button></div></div>';
    echo '<div class="idev-preview-frame"><iframe title="' . esc_attr__('Preview', 'idev-common') . '"></iframe></div>';
    echo '<div class="idev-test"><input type="email" name="test_to" placeholder="' . esc_attr(wp_get_current_user()->user_email) . '"> <button type="button" class="button idev-send-test">' . esc_html__('Send test e-mail', 'idev-common') . '</button> <span class="idev-test-msg"></span></div></div></div></form>';
}

/** One design field as a labelled control. */
function idev_designer_field($group, $f, $value) {
    [$key, $label, $type, $help, $options] = array_pad($f, 5, '');
    $name = $group . '[' . $key . ']';
    echo '<label class="idev-f idev-f-' . esc_attr($type) . '"><span>' . esc_html($label) . '</span>';
    if ($type === 'color') echo '<input type="color" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '">';
    elseif ($type === 'select') { echo '<select name="' . esc_attr($name) . '">'; foreach ($options as $v => $l) echo '<option value="' . esc_attr($v) . '"' . selected($value, (string) $v, false) . '>' . esc_html($l) . '</option>'; echo '</select>'; }
    elseif ($type === 'textarea') echo '<textarea rows="3" name="' . esc_attr($name) . '">' . esc_textarea($value) . '</textarea>';
    elseif ($type === 'number') echo '<input type="number" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '"' . ($options ? ' min="' . (int) $options[0] . '" max="' . (int) $options[1] . '"' : '') . '>';
    elseif ($type === 'checkbox') echo '<input type="checkbox" name="' . esc_attr($name) . '" value="1"' . checked($value, '1', false) . '>';
    elseif ($type === 'image') echo '<span class="idev-img-pick"><input type="url" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '" placeholder="https://"><button type="button" class="button idev-media">' . esc_html__('Choose', 'idev-common') . '</button></span>';
    else echo '<input type="text" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '">';
    if ($help) echo '<small>' . esc_html($help) . '</small>';
    echo '</label>';
}
function idev_email_design_clean($in) {
    $out = idev_email_design_defaults();
    $in = (array) $in;
    foreach (idev_email_design_fields() as $f) {
        [$k, , $type, , $opt] = array_pad($f, 5, '');
        $v = isset($in[$k]) ? wp_unslash($in[$k]) : '';
        if ($type === 'color') $out[$k] = sanitize_hex_color($v) ?: $out[$k];
        elseif ($type === 'image') $out[$k] = esc_url_raw(trim($v), ['http', 'https']);
        elseif ($type === 'number') $out[$k] = (string) max((int) $opt[0], min((int) $opt[1], (int) $v));
        elseif ($type === 'select') $out[$k] = array_key_exists($v, $opt) ? $v : $out[$k];
        elseif ($type === 'textarea') $out[$k] = sanitize_textarea_field($v);
        else $out[$k] = sanitize_text_field($v);
    }
    $t = sanitize_key($in['template'] ?? '');
    $out['template'] = isset(idev_email_templates()[$t]) ? $t : 'modern';
    return $out;
}
function idev_email_texts_clean($in) {
    $in = (array) $in;
    return ['enabled' => !empty($in['enabled']), 'subject' => sanitize_text_field(wp_unslash($in['subject'] ?? '')), 'body' => sanitize_textarea_field(wp_unslash($in['body'] ?? '')), 'subject_en' => sanitize_text_field(wp_unslash($in['subject_en'] ?? '')), 'body_en' => sanitize_textarea_field(wp_unslash($in['body_en'] ?? ''))];
}

add_action('admin_post_idev_email_save', function () {
    $id = sanitize_key($_POST['id'] ?? '');
    $dz = idev_email_designer($id);
    if (!$dz || !current_user_can('manage_options') || !check_admin_referer('idev_email_save_' . $id)) wp_die('Forbidden', 403);
    update_option($dz['option'], idev_email_design_clean($_POST['design'] ?? []), false);
    foreach ((array) ($_POST['texts'] ?? []) as $type => $t) if (isset($dz['types'][$type])) call_user_func($dz['save_texts'], $type, idev_email_texts_clean($t)); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- cleaned in idev_email_texts_clean
    $back = esc_url_raw(wp_unslash($_POST['back'] ?? '')) ?: admin_url();
    wp_safe_redirect(add_query_arg('saved', '1', $back));
    exit;
});
add_action('wp_ajax_idev_designer_preview', function () {
    $id = sanitize_key($_POST['id'] ?? '');
    $kind = sanitize_key($_POST['kind'] ?? 'email');
    if (!current_user_can('manage_options') || !check_ajax_referer('idev_designer_' . $id, 'nonce', false)) wp_send_json_error('forbidden', 403);
    $lang = ($_POST['lang'] ?? '') === 'en' ? 'en' : 'th';
    if ($kind === 'doc') {
        $dz = idev_doc_designer($id);
        if (!$dz) wp_send_json_error('unknown');
        $doc = sanitize_key($_POST['doc'] ?? '') ?: array_key_first($dz['docs']);
        wp_send_json_success(['html' => call_user_func($dz['preview'], $doc, idev_doc_design_clean($_POST['design'] ?? []), sanitize_key($_POST['paper'] ?? ''))]);
    }
    $dz = idev_email_designer($id);
    if (!$dz) wp_send_json_error('unknown');
    $type = sanitize_key($_POST['type'] ?? '');
    if (!isset($dz['types'][$type])) $type = array_key_first($dz['types']);
    $texts = idev_email_texts_clean($_POST['texts'][$type] ?? []); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
    wp_send_json_success(['html' => call_user_func($dz['preview'], $type, $lang, idev_email_design_clean($_POST['design'] ?? []), $texts)]);
});
add_action('wp_ajax_idev_email_test', function () {
    $id = sanitize_key($_POST['id'] ?? '');
    $dz = idev_email_designer($id);
    if (!$dz || !current_user_can('manage_options') || !check_ajax_referer('idev_designer_' . $id, 'nonce', false)) wp_send_json_error(__('Sorry, you are not allowed to do that.', 'idev-common'), 403);
    $to = sanitize_email(wp_unslash($_POST['to'] ?? '')) ?: wp_get_current_user()->user_email;
    if (!is_email($to)) wp_send_json_error(__('Please enter an e-mail address.', 'idev-common'));
    $type = sanitize_key($_POST['type'] ?? '');
    $lang = ($_POST['lang'] ?? '') === 'en' ? 'en' : 'th';
    $texts = idev_email_texts_clean($_POST['texts'][$type] ?? []); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
    $html = call_user_func($dz['preview'], $type, $lang, idev_email_design_clean($_POST['design'] ?? []), $texts);
    $subject = $texts['subject' . ($lang === 'en' ? '_en' : '')] ?: $dz['types'][$type];
    if (isset($dz['sample_vars'])) $subject = strtr($subject, (array) call_user_func($dz['sample_vars'], $lang));
    $subject = '[TEST] ' . $subject;
    $ok = wp_mail($to, $subject, $html, ['Content-Type: text/html; charset=UTF-8']);
    $ok ? wp_send_json_success(sprintf(__('Sent to %s', 'idev-common'), $to)) : wp_send_json_error(__('The website could not send e-mail. Check the mail (SMTP) settings of the website.', 'idev-common'));
});
