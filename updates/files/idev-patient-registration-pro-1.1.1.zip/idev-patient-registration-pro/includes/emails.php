<?php
/** Designed e-mails (iDevApp e-mail designer): "registration received" and "your patient card", editable texts. */
defined('ABSPATH') || exit;

const IDEV_MRP_EMAIL_OPTION = 'idev_medreg_email_design';

function idev_mrp_email_defaults() {
    return [
        'received' => ['subject' => 'ได้รับข้อมูลลงทะเบียนแล้ว {ref}', 'body' => "{salutation}\n\nได้รับข้อมูลลงทะเบียนผู้ป่วยใหม่ของท่านแล้ว\n\nเจ้าหน้าที่จะตรวจสอบข้อมูล เมื่อได้เลขประจำตัวผู้ป่วย (HN) แล้ว ระบบจะส่งบัตรคนไข้มาที่อีเมลนี้",
            'subject_en' => 'Registration received {ref}', 'body_en' => "{salutation}\n\nWe have received your registration.\n\nOur staff will check your details. When your hospital number (HN) is ready, we will e-mail your patient card to this address."],
        'card' => ['subject' => 'บัตรคนไข้ของท่าน HN {hn}', 'body' => "{salutation}\n\nการลงทะเบียนผู้ป่วยใหม่เสร็จสมบูรณ์ เลขประจำตัวผู้ป่วยของท่านคือ **{hn}**\n\nกรุณาเก็บบัตรนี้ไว้ และแสดงบนมือถือพร้อมบัตรประชาชนที่จุดลงทะเบียนเมื่อมารับบริการ",
            'subject_en' => 'Your patient card – HN {hn}', 'body_en' => "{salutation}\n\nYour registration is complete. Your hospital number (HN) is **{hn}**.\n\nPlease keep this card and show it on your phone at the registration desk, together with your passport or ID card."],
    ];
}
function idev_mrp_email_texts($type) {
    $all = get_option('idev_mrp_email_texts', []);
    $t = array_merge(idev_mrp_email_defaults()[$type], is_array($all[$type] ?? null) ? array_filter($all[$type], 'strlen') : []);
    return $t;
}

/** Parts for the designer. */
function idev_mrp_mail_parts($type, $en, $vars, $t, $image = '') {
    $s = idev_medreg_settings();
    $site = idev_medreg_site($en);
    $body = strtr($t['body' . ($en ? '_en' : '')] ?: $t['body'], $vars);
    $parts = ['lang' => $en ? 'en' : 'th', 'site' => $site['name'], 'text' => $body, 'footer' => trim($site['address'] . ($site['phone'] ? "\n" . ($en ? 'Tel. ' : 'โทร ') . $site['phone'] : ''))];
    if ($type === 'received') {
        $parts += ['title' => $en ? 'Registration received' : 'ได้รับข้อมูลลงทะเบียนแล้ว', 'preheader' => ($en ? 'Reference ' : 'เลขอ้างอิง ') . $vars['{ref}'],
            'rows' => [[$en ? 'Reference' : 'เลขอ้างอิง', $vars['{ref}']], [$en ? 'Status' : 'สถานะ', $en ? 'Being checked by our staff' : 'รอเจ้าหน้าที่ตรวจสอบ']]];
    } else {
        $note = idev_pick($s['card_email_note'], $s['card_email_note_en'], $en ? 'en' : 'th');
        $book = function_exists('idev_appt_booking_url') ? idev_appt_booking_url() : '';
        $parts += ['title' => $en ? 'Your patient card' : 'บัตรคนไข้ของท่าน', 'preheader' => 'HN ' . $vars['{hn}'], 'image' => $image,
            'rows' => [['HN', $vars['{hn}']], [$en ? 'Name' : 'ชื่อ', $vars['{name}']]],
            'button' => $book ? [$en ? 'Book an appointment' : 'จองนัดหมาย', $book] : null,
            'note' => trim($note . ($image ? ' ' . ($en ? 'The card is also attached as an image you can save to your phone.' : 'แนบรูปบัตรไว้ด้วย บันทึกลงมือถือได้') : ''))];
    }
    return $parts;
}

add_filter('idev_medreg_mail_custom', function ($custom, $type, $x) {
    if (!idev_mrp_licensed() || !in_array($type, ['received', 'card'], true)) return $custom;
    $p = $x['p']; $en = (bool) $x['en'];
    $vars = ['{salutation}' => idev_medreg_salutation($p, $en), '{name}' => $en ? (idev_medreg_name_en($p) ?: idev_medreg_name($p)) : idev_medreg_name($p), '{ref}' => $x['ref'] ?? ($x['row']['ref'] ?? ''), '{hn}' => $x['row']['hn'] ?? '', '{site}' => idev_medreg_site($en)['name']];
    $t = idev_mrp_email_texts($type);
    $subject = strtr($t['subject' . ($en ? '_en' : '')] ?: $t['subject'], $vars);
    return [$subject, idev_email_render(idev_email_design(IDEV_MRP_EMAIL_OPTION), idev_mrp_mail_parts($type, $en, $vars, $t, $x['image'] ?? ''))];
}, 10, 3);

/* Settings tab "E-mail design". */
add_filter('idev_medreg_settings_tabs', function ($tabs) {
    $out = [];
    foreach ($tabs as $k => $l) { $out[$k] = $l; if ($k === 'email') $out['emaildesign'] = __('E-mail design', 'idev-patient-registration-pro'); }
    return $out;
}, 20);
add_filter('idev_medreg_settings_icons', function ($i) { return $i + ['emaildesign' => 'palette', 'connector' => 'refresh']; });
add_action('idev_medreg_settings_page_emaildesign', function () {
    if (isset($_GET['saved'])) echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Saved.', 'idev-patient-registration-pro') . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    idev_email_designer_ui('medreg', admin_url('admin.php?page=idev-medreg-settings&tab=emaildesign'));
});

add_action('init', function () {
    if (!function_exists('idev_register_email_designer')) return;
    idev_register_email_designer('medreg', [
        'option' => IDEV_MRP_EMAIL_OPTION,
        'types' => ['received' => __('Registration received', 'idev-patient-registration-pro'), 'card' => __('Patient card (HN issued)', 'idev-patient-registration-pro')],
        'vars' => '{salutation} {name} {ref} {hn} {site}',
        'texts' => function ($type) {
            $t = idev_mrp_email_texts($type);
            if ($type === 'received') $t['enabled'] = idev_medreg_settings()['email_received'] === '1';
            return $t;
        },
        'save_texts' => function ($type, $t) {
            $all = get_option('idev_mrp_email_texts', []);
            $all = is_array($all) ? $all : [];
            $all[$type] = ['subject' => $t['subject'], 'body' => $t['body'], 'subject_en' => $t['subject_en'], 'body_en' => $t['body_en']];
            update_option('idev_mrp_email_texts', $all, false);
            if ($type === 'received') { $s = get_option('idev_medreg_settings', []); $s = is_array($s) ? $s : []; $s['email_received'] = $t['enabled'] ? '1' : '0'; update_option('idev_medreg_settings', $s, false); }
        },
        'sample_vars' => function ($lang) { $en = $lang === 'en'; return ['{salutation}' => $en ? 'Dear Somying Jaideemak,' : 'เรียน นางสาวสมหญิง ใจดีมาก', '{name}' => $en ? 'Somying Jaideemak' : 'นางสาวสมหญิง ใจดีมาก', '{ref}' => 'REG-' . wp_date('ymd') . '-K7Q2', '{hn}' => '000123456', '{site}' => idev_medreg_site($en)['name']]; },
        'preview' => function ($type, $lang, $design, $t) {
            $en = $lang === 'en';
            $vars = ['{salutation}' => $en ? 'Dear Somying Jaideemak,' : 'เรียน นางสาวสมหญิง ใจดีมาก', '{name}' => $en ? 'Somying Jaideemak' : 'นางสาวสมหญิง ใจดีมาก', '{ref}' => 'REG-' . wp_date('ymd') . '-K7Q2', '{hn}' => '000123456', '{site}' => idev_medreg_site($en)['name']];
            $img = $type === 'card' ? 'data:image/png;base64,' . base64_encode(idev_medreg_card_png(idev_medreg_card_sample(), $en)) : '';
            return idev_email_render($design, idev_mrp_mail_parts($type, $en, $vars, $t, $img));
        },
        'locked' => function () { return idev_mrp_licensed() ? '' : esc_html__('Designed e-mails need an iDev Patient Registration Pro licence. Until then the plain built-in e-mails are sent.', 'idev-patient-registration-pro'); },
    ]);
}, 30);
