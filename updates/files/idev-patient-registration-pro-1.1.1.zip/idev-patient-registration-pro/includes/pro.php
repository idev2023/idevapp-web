<?php
/**
 * Pro features for iDev Patient Registration:
 * - HOSxP connector: REST API for a small program inside the hospital (queue of approved registrations → HN back).
 * - Automatic reading of the ID card / passport photo (Tesseract.js in the patient's browser).
 * Licence product "medreg" (also opened by the I-Clinic / I-Drug packages and by keys issued before the split).
 */
defined('ABSPATH') || exit;

add_action('init', function () {
    load_plugin_textdomain('idev-patient-registration-pro', false, dirname(plugin_basename(IDEV_MRP_FILE)) . '/languages');
    idev_register_license('medreg', [
        'name' => 'iDev Patient Registration Pro', 'plugin' => 'idev-patient-registration-pro',
        'free' => __('Without a key: ID cards and passports are read automatically; the HOSxP connector is off (staff type the HN).', 'idev-patient-registration-pro'),
        'pro' => __('HOSxP connector: the HN is found or created automatically and the patient card is sent. Lifetime, one website.', 'idev-patient-registration-pro'),
        'price' => '2,900 ' . __('THB', 'idev-patient-registration-pro'),
        'note' => __('Permission to connect to the HOSxP database is given by BMS (the HOSxP developer); please arrange it with BMS yourself.', 'idev-patient-registration-pro'),
        'usage' => function () { return esc_html(idev_mrp_licensed() ? __('HOSxP connector on', 'idev-patient-registration-pro') : __('HOSxP connector off', 'idev-patient-registration-pro')); },
    ]);
    idev_register_plugin('idev-patient-registration-pro', ['name' => 'iDev Patient Registration Pro', 'version' => IDEV_MRP_VERSION, 'description' => __('HOSxP connector and automatic ID card / passport reading.', 'idev-patient-registration-pro'), 'settings' => admin_url('admin.php?page=idev-medreg-settings&tab=connector'), 'docs' => 'https://idevapp.me/plugins/idev-patient-registration/#pro']);
}, 5);
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_MRP_FILE, admin_url('admin.php?page=idev-medreg-settings&tab=connector'), 'https://idevapp.me/plugins/idev-patient-registration/#pro'); }, 25);

function idev_mrp_licensed() { return function_exists('idev_is_licensed') && idev_is_licensed('medreg'); }

/* ---------- Switches in the free plugin ---------- */

add_filter('idev_medreg_connector_enabled', 'idev_mrp_licensed');

/** Reading engine: the site's own copy if set in the free plugin, otherwise tesseract.js 5 from jsDelivr. */
add_filter('idev_medreg_ocr_engine', function ($engine) {
    return $engine ?: ['script' => 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js'];
});

/* ---------- Settings tab ---------- */

add_filter('idev_medreg_settings_tabs', function ($tabs) {
    $out = [];
    foreach ($tabs as $k => $l) { $out[$k] = $l; if ($k === 'email') $out['connector'] = __('HOSxP connector', 'idev-patient-registration-pro'); }
    if (!isset($out['connector'])) $out['connector'] = __('HOSxP connector', 'idev-patient-registration-pro');
    return $out;
});
add_filter('idev_medreg_fields', function ($fields, $tab) {
    if ($tab !== 'connector') return $fields;
    return [['connector_ips', __('Connector IP addresses (optional)', 'idev-patient-registration-pro'), 'text', __('Public IP addresses of the hospital, separated by commas. Empty = any address with the right connector key.', 'idev-patient-registration-pro')]];
}, 10, 2);
add_action('idev_medreg_settings_tab', function ($tab) { if ($tab === 'connector') idev_mrp_connector_box(); });

function idev_mrp_connector_box() {
    if (!idev_mrp_licensed()) {
        echo wp_kses_post(idev_license_upsell('medreg', esc_html__('The HOSxP connector needs a licence for iDev Patient Registration Pro (2,900 THB, lifetime) or an I-Clinic / I-Drug package. Until then, approve a registration by typing the HN after saving the patient in HOSxP. Permission to connect to the HOSxP database is given by BMS; please arrange it with BMS yourself.', 'idev-patient-registration-pro')));
        return;
    }
    $seen = (int) get_option('idev_medreg_connector_seen');
    $link = function ($do, $label, $confirm = '') { return '<a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=idev_medreg_connector&do=' . $do), 'idev_medreg_connector')) . '"' . ($confirm ? ' onclick="return confirm(\'' . esc_js($confirm) . '\')"' : '') . '>' . esc_html($label) . '</a>'; };
    $new = get_transient('idev_medreg_new_token_' . get_current_user_id());
    if ($new) { delete_transient('idev_medreg_new_token_' . get_current_user_id()); echo '<div class="notice notice-warning inline"><p><strong>' . esc_html__('Connector key (copy it now — it will not be shown again):', 'idev-patient-registration-pro') . '</strong></p><p><code style="font-size:15px;user-select:all">' . esc_html($new) . '</code></p></div>'; }
    echo '<div class="idev-card"><h2>' . esc_html__('HOSxP connector', 'idev-patient-registration-pro') . '</h2>';
    echo '<p>' . esc_html__('A small PHP program on a computer inside the hospital that can reach the HOSxP database. Every 1–5 minutes it takes approved registrations, finds the patient or creates a new HN, and sends the HN back. The website never connects to HOSxP.', 'idev-patient-registration-pro') . '</p>';
    echo '<p>' . esc_html__('Key:', 'idev-patient-registration-pro') . ' ' . (get_option('idev_medreg_token_hash') ? '✓' : '<strong>' . esc_html__('not created yet', 'idev-patient-registration-pro') . '</strong>') . ' · ' . esc_html__('Last contact:', 'idev-patient-registration-pro') . ' ' . ($seen ? esc_html(wp_date('j M Y H:i', $seen)) : esc_html__('never', 'idev-patient-registration-pro')) . '</p>';
    echo '<p>' . esc_html__('Website address for the connector:', 'idev-patient-registration-pro') . ' <code>' . esc_html(home_url('/')) . '</code> · API <code>idev-medreg/v1/connector</code>' . (get_option('idev_medreg_compat_andaman') ? ' ' . esc_html__('(the old Andaman Hub address andaman/v1/hosxp also works)', 'idev-patient-registration-pro') : '') . '</p>';
    echo '<p>' . $link('token', __('Create new connector key', 'idev-patient-registration-pro'), __('Create a new key? The old one stops working immediately.', 'idev-patient-registration-pro')) . ' ' . $link('zip', __('Download connector (zip)', 'idev-patient-registration-pro')) . '</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- links built with esc_url / esc_html above
}

add_action('admin_post_idev_medreg_connector', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idev_medreg_connector')) wp_die('Forbidden', 403);
    if (!idev_mrp_licensed()) wp_die(esc_html__('The HOSxP connector needs a licence (iDevApp → Licences).', 'idev-patient-registration-pro'), 402);
    if (($_GET['do'] ?? '') === 'token') {
        $token = 'idmr_' . bin2hex(random_bytes(24));
        update_option('idev_medreg_token_hash', hash('sha256', $token), false);
        set_transient('idev_medreg_new_token_' . get_current_user_id(), $token, 300);
        wp_safe_redirect(admin_url('admin.php?page=idev-medreg-settings&tab=connector'));
        exit;
    }
    $dir = IDEV_MRP_DIR . '/connector';
    $zip_path = wp_tempnam('hosxp-connector.zip');
    $zip = new ZipArchive();
    $zip->open($zip_path, ZipArchive::OVERWRITE);
    foreach (['hosxp-connector.php', 'config.sample.php', 'README-TH.md'] as $f) if (is_file("$dir/$f")) $zip->addFile("$dir/$f", "hosxp-connector/$f");
    $zip->close();
    nocache_headers();
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="hosxp-connector.zip"');
    header('Content-Length: ' . filesize($zip_path));
    readfile($zip_path); // phpcs:ignore WordPress.WP.AlternativeFunctions
    wp_delete_file($zip_path);
    exit;
});

/* ---------- Connector API ---------- */

add_action('rest_api_init', function () {
    $token = function ($r) {
        $ok = idev_mrp_check_token($r);
        if ($ok === true && !idev_mrp_licensed()) return new WP_Error('idev_licence_required', 'The HOSxP connector needs an iDev Patient Registration Pro licence for ' . idev_license_domain() . ' (iDevApp → Licences).', ['status' => 402]);
        return $ok;
    };
    $routes = [['idev-medreg/v1', '/connector']];
    if (get_option('idev_medreg_compat_andaman')) $routes[] = ['andaman/v1', '/hosxp']; // connectors set up for Andaman Hub keep working
    foreach ($routes as [$ns, $conn]) {
        register_rest_route($ns, $conn . '/ping', ['methods' => 'GET', 'permission_callback' => $token, 'callback' => function () { update_option('idev_medreg_connector_seen', time(), false); return ['ok' => true, 'site' => home_url('/'), 'plugin' => 'idev-patient-registration', 'version' => IDEV_MEDREG_VERSION, 'pro' => IDEV_MRP_VERSION]; }]);
        register_rest_route($ns, $conn . '/queue', ['methods' => 'GET', 'permission_callback' => $token, 'callback' => 'idev_mrp_queue']);
        register_rest_route($ns, $conn . '/result', ['methods' => 'POST', 'permission_callback' => $token, 'callback' => 'idev_mrp_result']);
    }
});

function idev_mrp_check_token(WP_REST_Request $request) {
    $hash = get_option('idev_medreg_token_hash');
    $header = (string) $request->get_header('authorization');
    if (!$hash || stripos($header, 'Bearer ') !== 0 || !hash_equals($hash, hash('sha256', trim(substr($header, 7))))) return new WP_Error('idev_forbidden', 'Invalid token', ['status' => 401]);
    $allow = trim((string) idev_medreg_settings()['connector_ips']);
    if ($allow !== '' && !in_array(idev_medreg_client_ip(), array_map('trim', preg_split('/[\s,]+/', $allow)), true)) return new WP_Error('idev_forbidden', 'IP not allowed', ['status' => 403]);
    return true;
}
function idev_mrp_queue() {
    global $wpdb;
    update_option('idev_medreg_connector_seen', time(), false);
    $items = [];
    foreach ($wpdb->get_col($wpdb->prepare("SELECT id FROM %i WHERE status='approved' ORDER BY id LIMIT 20", idev_medreg_table())) as $id) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $r = idev_medreg_get($id);
        if (!$r || !$r['readable']) continue;
        $p = $r['person'];
        unset($p['_log'], $p['consent']);
        $items[] = ['id' => (int) $r['id'], 'ref' => $r['ref'], 'person' => $p];
    }
    return ['items' => $items];
}
function idev_mrp_result(WP_REST_Request $request) {
    $id = (int) $request->get_param('id');
    $status = sanitize_key($request->get_param('status'));
    $row = idev_medreg_get($id);
    if (!$row || $row['status'] !== 'approved') return new WP_REST_Response(['ok' => false, 'error' => 'not in queue'], 404);
    $person = $row['person'];
    $message = mb_substr(sanitize_text_field((string) $request->get_param('message')), 0, 500);
    if (in_array($status, ['created', 'existing'], true)) {
        $hn = preg_replace('/[^0-9A-Za-z-]/', '', (string) $request->get_param('hn'));
        if ($hn === '') return new WP_REST_Response(['ok' => false, 'error' => 'hn required'], 400);
        idev_medreg_log($person, ($status === 'existing' ? 'HOSxP: พบผู้ป่วยเดิม HN ' : 'HOSxP: สร้างผู้ป่วยใหม่ HN ') . $hn);
        idev_medreg_save_person($id, $person, ['status' => 'synced', 'hn' => $hn, 'message' => $status === 'existing' ? __('Already in HOSxP (existing HN used)', 'idev-patient-registration-pro') : $message, 'synced_at' => current_time('mysql', true)]);
        idev_medreg_mail_card($id);
        do_action('idev_medreg_hn_issued', $id, $hn, $person);
        return ['ok' => true];
    }
    idev_medreg_log($person, 'HOSxP error: ' . $message);
    idev_medreg_save_person($id, $person, ['status' => 'error', 'message' => $message]);
    return ['ok' => true];
}
