<?php
/**
 * Patient card (Pro): four more card styles — side panel, minimal, official, premium — and a gallery of ready-made
 * designs that fill the designer with one click (colours, style, texts). Pictures are drawn with the same helpers
 * as the free plugin (1012 × 638 px).
 */
defined('ABSPATH') || exit;

add_filter('idev_medreg_card_layouts', function ($l) {
    return $l + ['sidebar' => __('Side panel (Pro)', 'idev-patient-registration-pro'), 'minimal' => __('Minimal white (Pro)', 'idev-patient-registration-pro'), 'official' => __('Official, centred header (Pro)', 'idev-patient-registration-pro'), 'premium' => __('Premium dark (Pro)', 'idev-patient-registration-pro')];
});

/** Ready-made designs. */
function idev_mrp_card_presets() {
    $t = ['title' => 'บัตรประจำตัวผู้ป่วย', 'title_en' => 'PATIENT CARD'];
    $show = ['show_org' => '1', 'show_name_en' => '1', 'show_dob' => '1', 'show_id' => '1', 'show_issued' => '1'];
    return array_map(function ($x) use ($show) { $x[1] += $show; return $x; }, [
        'teal' => [__('Hospital teal', 'idev-patient-registration-pro'), ['layout' => 'classic', 'bg_type' => 'gradient', 'bg1' => '#169c91', 'bg2' => '#0e3540', 'text' => '#ffffff', 'muted' => '#c8ece7', 'accent' => '#ffd166'] + $t],
        'navy' => [__('Official navy & gold', 'idev-patient-registration-pro'), ['layout' => 'official', 'bg_type' => 'solid', 'bg1' => '#1e3a8a', 'bg2' => '#172554', 'text' => '#ffffff', 'muted' => '#c7d2fe', 'accent' => '#d4a017'] + $t],
        'mint' => [__('Dental mint', 'idev-patient-registration-pro'), ['layout' => 'minimal', 'bg_type' => 'solid', 'bg1' => '#10b981', 'bg2' => '#065f46', 'text' => '#0f172a', 'muted' => '#64748b', 'accent' => '#10b981', 'title' => 'บัตรคนไข้ทันตกรรม', 'title_en' => 'DENTAL PATIENT CARD']],
        'eye' => [__('Eye clinic blue', 'idev-patient-registration-pro'), ['layout' => 'sidebar', 'bg_type' => 'gradient', 'bg1' => '#38bdf8', 'bg2' => '#1d4ed8', 'text' => '#0f172a', 'muted' => '#64748b', 'accent' => '#1d4ed8', 'title' => 'บัตรสมาชิก', 'title_en' => 'MEMBER CARD']],
        'women' => [__('Women & mother', 'idev-patient-registration-pro'), ['layout' => 'band', 'bg_type' => 'gradient', 'bg1' => '#f472b6', 'bg2' => '#be185d', 'text' => '#ffffff', 'muted' => '#fce7f3', 'accent' => '#be185d'] + $t],
        'kids' => [__('Kids clinic', 'idev-patient-registration-pro'), ['layout' => 'classic', 'bg_type' => 'gradient', 'bg1' => '#fb923c', 'bg2' => '#f59e0b', 'text' => '#ffffff', 'muted' => '#fff7ed', 'accent' => '#1e3a8a', 'title' => 'บัตรคนไข้เด็ก', 'title_en' => 'KIDS PATIENT CARD']],
        'pharmacy' => [__('Pharmacy green', 'idev-patient-registration-pro'), ['layout' => 'sidebar', 'bg_type' => 'gradient', 'bg1' => '#22c55e', 'bg2' => '#15803d', 'text' => '#0f172a', 'muted' => '#64748b', 'accent' => '#15803d', 'title' => 'บัตรสมาชิกร้านยา', 'title_en' => 'MEMBER CARD']],
        'premium' => [__('Premium black & gold', 'idev-patient-registration-pro'), ['layout' => 'premium', 'bg_type' => 'solid', 'bg1' => '#1f2937', 'bg2' => '#0b0f19', 'text' => '#f8fafc', 'muted' => '#9ca3af', 'accent' => '#e3b341', 'title' => 'บัตรสมาชิกพรีเมียม', 'title_en' => 'PREMIUM MEMBER']],
        'print' => [__('Light — prints on any printer', 'idev-patient-registration-pro'), ['layout' => 'light', 'bg_type' => 'solid', 'bg1' => '#0f766e', 'bg2' => '#0f766e', 'text' => '#111827', 'muted' => '#6b7280', 'accent' => '#0f766e'] + $t],
    ]);
}

/* Gallery above the designer. */
add_action('idev_medreg_card_designer_top', function () {
    $locked = !idev_mrp_licensed();
    $url = wp_nonce_url(admin_url('admin-post.php?action=idev_medreg_card_preview'), 'idev_medreg_card_preview');
    echo '<div class="idev-card idev-mrp-gallery"><h2>' . esc_html__('Ready-made designs', 'idev-patient-registration-pro') . '</h2><p class="description">' . esc_html__('Click a design to load it into the designer below, then change the logo, colours and texts and save. Your logo and background picture are kept.', 'idev-patient-registration-pro') . '</p>';
    if ($locked) echo wp_kses_post(idev_license_upsell('medreg', esc_html__('Pro card styles need an iDev Patient Registration Pro licence. You can try them here; without a licence, cards are drawn in the "Full colour" style.', 'idev-patient-registration-pro')));
    echo '<div class="idev-mrp-presets">';
    foreach (idev_mrp_card_presets() as $k => [$name, $p]) {
        $src = add_query_arg('d', rawurlencode(wp_json_encode($p)), $url);
        echo '<button type="button" class="idev-mrp-preset" data-preset="' . esc_attr(wp_json_encode($p)) . '"><img src="' . esc_url($src) . '" alt="" loading="lazy" width="253" height="160"><span>' . esc_html($name) . '</span></button>';
    }
    echo '</div></div>';
    echo '<style>.idev-mrp-presets{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;margin:10px 0 6px}.idev-mrp-preset{background:#fff;border:2px solid #e2e6ea;border-radius:14px;padding:8px;cursor:pointer;text-align:left;display:flex;flex-direction:column;gap:6px;transition:.15s}.idev-mrp-preset:hover{border-color:#0f766e;transform:translateY(-1px);box-shadow:0 6px 18px #0f2f3a1a}.idev-mrp-preset img{width:100%;height:auto;border-radius:9px;display:block;background:#eef1f3}.idev-mrp-preset span{font-weight:600}</style>';
    echo "<script>document.addEventListener('click',function(e){var b=e.target.closest('.idev-mrp-preset');if(!b)return;var p=JSON.parse(b.dataset.preset),f=document.getElementById('idev-mr-card');if(!f)return;Object.keys(p).forEach(function(k){var el=f.querySelector('[name=\"idev_medreg_card['+k+']\"]');if(!el)return;if(el.type==='checkbox')el.checked=p[k]==='1';else el.value=p[k];});f.dispatchEvent(new Event('change'));f.scrollIntoView({behavior:'smooth'});});</script>";
});

/* ---------- Drawing ---------- */

add_filter('idev_medreg_card_draw', function ($png, $row, $en, $d) {
    if (!in_array($d['layout'], ['sidebar', 'minimal', 'official', 'premium'], true)) return $png;
    // Unlicensed: the preview in the designer shows Pro styles; real cards use the free style.
    if (!idev_mrp_licensed() && !(is_admin() && doing_action('admin_post_idev_medreg_card_preview'))) return null;
    return idev_mrp_card_png($row, $en, $d);
}, 10, 4);

/** Facts under the name: date of birth, ID (masked), issued. */
function idev_mrp_card_facts($row, $en, $d) {
    $p = $row['person'] ?? [];
    $facts = [];
    if ($d['show_dob'] === '1' && !empty($p['birthdate'])) $facts[] = [$en ? 'Date of birth' : 'วันเกิด', idev_format_day($p['birthdate'], $en ? 'en' : 'th')];
    if ($d['show_id'] === '1') {
        $num = ($p['doc_type'] ?? '') === 'passport' ? ($p['passport_no'] ?? '') : ($p['cid'] ?? '');
        if ($num !== '') $facts[] = [($p['doc_type'] ?? '') === 'passport' ? ($en ? 'Passport' : 'หนังสือเดินทาง') : ($en ? 'ID card' : 'บัตรประชาชน'), idev_medreg_mask_id($num)];
    }
    if ($d['show_issued'] === '1') $facts[] = [$en ? 'Issued' : 'ออกบัตร', idev_format_day(substr((string) ($row['synced_at'] ?: current_time('mysql')), 0, 10), $en ? 'en' : 'th')];
    return array_slice($facts, 0, 3);
}
function idev_mrp_card_names($row, $en) {
    $p = $row['person'] ?? [];
    $name = idev_medreg_name($p); $nameEn = idev_medreg_name_en($p);
    if ($en && $nameEn !== '') { [$name, $nameEn] = [$nameEn, $name === $nameEn ? '' : $name]; }
    return [$name, $nameEn !== $name ? $nameEn : ''];
}
/** Splits text into lines of about $n characters at spaces (UTF-8 safe). */
function idev_mrp_wrap($text, $n) {
    $lines = []; $cur = '';
    foreach (preg_split('/\s+/u', trim((string) $text)) as $w) {
        if ($cur !== '' && mb_strlen($cur . ' ' . $w) > $n) { $lines[] = $cur; $cur = $w; } else $cur = trim($cur . ' ' . $w);
    }
    if ($cur !== '') $lines[] = $cur;
    return $lines;
}
function idev_mrp_gradient($im, $x, $y, $w, $h, $c1, $c2, $vertical = false) {
    $a = sscanf(ltrim($c1, '#'), '%2x%2x%2x'); $b = sscanf(ltrim($c2, '#'), '%2x%2x%2x');
    $n = $vertical ? $h : $w;
    for ($i = 0; $i < $n; $i++) {
        $t = $i / max(1, $n - 1);
        $col = imagecolorallocate($im, (int) ($a[0] + ($b[0] - $a[0]) * $t), (int) ($a[1] + ($b[1] - $a[1]) * $t), (int) ($a[2] + ($b[2] - $a[2]) * $t));
        $vertical ? imageline($im, $x, $y + $i, $x + $w, $y + $i, $col) : imageline($im, $x + $i, $y, $x + $i, $y + $h, $col);
    }
}
function idev_mrp_qr($im, $d, $row, $x, $y, $size, $white) {
    $qr = idev_qr_image(idev_medreg_qr_value($d, $row), 10, 2, 'M');
    idev_medreg_round($im, $x - 10, $y - 10, $x + $size + 10, $y + $size + 10, 16, $white);
    imagecopyresampled($im, $qr, $x, $y, 0, 0, $size, $size, imagesx($qr), imagesy($qr));
    imagedestroy($qr);
}
function idev_mrp_barcode($im, $hn, $x, $y, $w, $h, $white) {
    $bc = idev_code128_image($hn, 70, 3);
    idev_medreg_round($im, $x - 10, $y - 8, $x + $w + 10, $y + $h + 8, 10, $white);
    imagecopyresampled($im, $bc, $x, $y, 0, 0, $w, $h, imagesx($bc), imagesy($bc));
    imagedestroy($bc);
}

function idev_mrp_card_png($row, $en, $d) {
    if (!function_exists('imagettftext')) return '';
    idev_load_qr();
    $W = 1012; $H = 638; $pad = 52;
    $im = imagecreatetruecolor($W, $H);
    imagealphablending($im, true); imagesavealpha($im, true);
    $white = idev_medreg_rgb($im, '#ffffff');
    $bold = idev_medreg_font('Bold'); $semi = idev_medreg_font('SemiBold'); $reg = idev_medreg_font('Regular');
    $site = idev_medreg_site($en);
    $title = $en ? ($d['title_en'] ?: $d['title']) : trim($d['title'] . ($d['title_en'] ? '  ·  ' . $d['title_en'] : ''));
    [$name, $nameEn] = idev_mrp_card_names($row, $en);
    $facts = idev_mrp_card_facts($row, $en, $d);
    $note = idev_pick($d['note'], $d['note_en'], $en ? 'en' : 'th');
    $code = $d['code'];
    $logo = $d['logo'] ? idev_medreg_load_image($d['logo']) : null;
    $L = $d['layout'];

    if ($L === 'sidebar') {
        $sw = 300;
        imagefilledrectangle($im, 0, 0, $W, $H, $white);
        idev_mrp_gradient($im, 0, 0, $sw, $H, $d['bg1'], $d['bg2'], true);
        imagefilledellipse($im, -40, $H - 40, 300, 300, imagecolorallocatealpha($im, 255, 255, 255, 112));
        imagefilledellipse($im, $sw - 20, 60, 160, 160, imagecolorallocatealpha($im, 255, 255, 255, 118));
        if ($logo) { idev_medreg_round($im, 40, 46, $sw - 40, 186, 20, $white); idev_medreg_contain($im, $logo, 56, 58, $sw - 112, 116); }
        if ($d['show_org'] === '1') { $y = $logo ? 240 : 80; foreach (array_slice(idev_mrp_wrap($site['name'], 18), 0, 3) as $i => $ln) idev_medreg_text($im, 24, 40, $y + $i * 36, $white, $bold, $ln, $sw - 70); }
        idev_medreg_text($im, 15, 40, $H - 46, idev_medreg_rgb($im, '#ffffff', 30), $semi, $en ? ($d['title_en'] ?: $d['title']) : $d['title'], $sw - 70);
        $x = $sw + 46; $max = $W - $x - $pad;
        $dark = idev_medreg_rgb($im, $d['text']); $mut = idev_medreg_rgb($im, $d['muted']); $acc = idev_medreg_rgb($im, $d['accent']);
        idev_medreg_text($im, 16, $x, 78, $mut, $semi, $en ? 'Name' : 'ชื่อ-นามสกุล', $max);
        idev_medreg_text($im, 36, $x, 126, $dark, $bold, $name, $max);
        if ($d['show_name_en'] === '1' && $nameEn !== '') idev_medreg_text($im, 19, $x, 162, $mut, $reg, $nameEn, $max);
        idev_medreg_text($im, 16, $x, 222, $mut, $semi, 'HN', $max);
        idev_medreg_text($im, 64, $x, 296, $acc, $bold, $row['hn'], $max - ($code === 'qr' || $code === 'both' ? 0 : 0));
        $qs = 170;
        $fw = ($code === 'qr' || $code === 'both') ? $max - $qs - 30 : $max;
        $fy = 350;
        foreach ($facts as $i => [$l, $v]) { idev_medreg_text($im, 14, $x, $fy + $i * 56, $mut, $reg, $l, $fw); idev_medreg_text($im, 19, $x, $fy + 26 + $i * 56, $dark, $semi, $v, $fw); }
        if ($code === 'qr' || $code === 'both') idev_mrp_qr($im, $d, $row, $W - $pad - $qs, 340, $qs, $white);
        if ($code === 'barcode' || $code === 'both') idev_mrp_barcode($im, $row['hn'], $x, $H - 110, min(420, $max), 52, $white);
        if ($note !== '') idev_medreg_text($im, 13, $x, $H - 26, $mut, $reg, $note, $max);
        if ($code === 'qr' || $code === 'both') imagerectangle($im, $W - $pad - $qs - 11, 329, $W - $pad + 11, 340 + $qs + 11, idev_medreg_rgb($im, '#e5e7eb'));
    } elseif ($L === 'minimal') {
        imagefilledrectangle($im, 0, 0, $W, $H, $white);
        imagefilledrectangle($im, 0, 0, $W, 12, idev_medreg_rgb($im, $d['bg1']));
        $dark = idev_medreg_rgb($im, $d['text'] ?: '#0f172a'); $mut = idev_medreg_rgb($im, $d['muted'] ?: '#64748b'); $acc = idev_medreg_rgb($im, $d['accent']);
        $hx = $pad;
        if ($logo) { [$lw] = idev_medreg_contain($im, $logo, $pad, 44, 130, 70); $hx = $pad + $lw + 20; }
        if ($d['show_org'] === '1') idev_medreg_text($im, 23, $hx, 76, $dark, $bold, $site['name'], $W - $hx - $pad);
        idev_medreg_text($im, 15, $hx, 106, $mut, $semi, $title, $W - $hx - $pad);
        $qs = ($code === 'qr' || $code === 'both') ? 200 : 0;
        $max = $W - 2 * $pad - ($qs ? $qs + 40 : 0);
        idev_medreg_text($im, 40, $pad, 220, $dark, $bold, $name, $max);
        if ($d['show_name_en'] === '1' && $nameEn !== '') idev_medreg_text($im, 19, $pad, 256, $mut, $reg, $nameEn, $max);
        idev_medreg_round($im, $pad, 286, $pad + 6, 380, 3, $acc);
        idev_medreg_text($im, 15, $pad + 24, 306, $mut, $semi, 'HN', $max);
        idev_medreg_text($im, 58, $pad + 24, 374, $dark, $bold, $row['hn'], $max - 24);
        $fx = $pad; $cw = (int) ($max / max(1, count($facts)));
        foreach ($facts as [$l, $v]) { idev_medreg_text($im, 14, $fx, 430, $mut, $reg, $l, $cw - 10); idev_medreg_text($im, 19, $fx, 460, $dark, $semi, $v, $cw - 10); $fx += $cw; }
        if ($qs) idev_mrp_qr($im, $d, $row, $W - $pad - $qs, 190, $qs, $white);
        if ($code === 'barcode' || $code === 'both') idev_mrp_barcode($im, $row['hn'], $pad, $H - 120, min(460, $W - 2 * $pad), 52, $white);
        imageline($im, $pad, $H - 50, $W - $pad, $H - 50, idev_medreg_rgb($im, '#e5e7eb'));
        if ($note !== '') idev_medreg_text($im, 14, $pad, $H - 20, $mut, $reg, $note, $W - 2 * $pad);
        imagerectangle($im, 0, 0, $W - 1, $H - 1, idev_medreg_rgb($im, '#e5e7eb'));
    } elseif ($L === 'official') {
        imagefilledrectangle($im, 0, 0, $W, $H, $white);
        $hh = 176;
        idev_mrp_gradient($im, 0, 0, $W, $hh, $d['bg1'], $d['bg2'], true);
        imagefilledrectangle($im, 0, $hh, $W, $hh + 8, idev_medreg_rgb($im, $d['accent']));
        imagefilledrectangle($im, 0, $H - 14, $W, $H, idev_medreg_rgb($im, $d['bg2']));
        $cx = $W / 2;
        if ($logo) { [$lw, $lh] = idev_medreg_contain($im, $logo, (int) ($cx - 220), 18, 120, 76); }
        $tx = $logo ? (int) ($cx - 220 + 140) : $pad;
        if ($d['show_org'] === '1') idev_medreg_text($im, 27, $logo ? $tx : $cx, 70, $white, $bold, $site['name'], $logo ? $W - $tx - $pad : $W - 2 * $pad, $logo ? 'left' : 'center');
        idev_medreg_text($im, 17, $logo ? $tx : $cx, 112, idev_medreg_rgb($im, $d['muted']), $semi, $title, $logo ? $W - $tx - $pad : $W - 2 * $pad, $logo ? 'left' : 'center');
        if ($site['address'] !== '') idev_medreg_text($im, 13, $logo ? $tx : $cx, 146, idev_medreg_rgb($im, '#ffffff', 40), $reg, $site['address'], $logo ? $W - $tx - $pad : $W - 2 * $pad, $logo ? 'left' : 'center');
        $dark = idev_medreg_rgb($im, '#111827'); $mut = idev_medreg_rgb($im, '#6b7280'); $navy = idev_medreg_rgb($im, $d['bg2']);
        $qs = ($code === 'qr' || $code === 'both') ? 190 : 0;
        $max = $W - 2 * $pad - ($qs ? $qs + 40 : 0);
        $rows = [[$en ? 'Name' : 'ชื่อ-นามสกุล', $name], ['HN', $row['hn']]];
        if ($d['show_name_en'] === '1' && $nameEn !== '') array_splice($rows, 1, 0, [[$en ? 'Thai name' : 'ชื่อภาษาอังกฤษ', $nameEn]]);
        $y = 238;
        foreach ($rows as [$l, $v]) {
            idev_medreg_text($im, 15, $pad, $y, $mut, $semi, $l, 170);
            idev_medreg_text($im, $l === 'HN' ? 44 : 26, $pad + 190, $y + ($l === 'HN' ? 12 : 4), $l === 'HN' ? $navy : $dark, $bold, $v, $max - 190);
            imageline($im, $pad, $y + 22, $pad + $max, $y + 22, idev_medreg_rgb($im, '#e5e7eb'));
            $y += $l === 'HN' ? 76 : 58;
        }
        foreach ($facts as [$l, $v]) { idev_medreg_text($im, 15, $pad, $y, $mut, $semi, $l, 170); idev_medreg_text($im, 19, $pad + 190, $y, $dark, $semi, $v, $max - 190); $y += 40; }
        if ($qs) { idev_mrp_qr($im, $d, $row, $W - $pad - $qs, 228, $qs, $white); imagerectangle($im, $W - $pad - $qs - 11, 217, $W - $pad + 11, 228 + $qs + 11, idev_medreg_rgb($im, '#d1d5db')); }
        if ($code === 'barcode') idev_mrp_barcode($im, $row['hn'], $W - $pad - 380, $H - 110, 380, 50, $white);
        if ($note !== '') idev_medreg_text($im, 14, $cx, $H - 30, $mut, $reg, $note, $W - 2 * $pad, 'center');
    } else { // premium
        $bg = idev_medreg_rgb($im, $d['bg2']);
        imagefilledrectangle($im, 0, 0, $W, $H, $bg);
        idev_mrp_gradient($im, 0, 0, $W, $H, $d['bg1'], $d['bg2']);
        $line = imagecolorallocatealpha($im, 255, 255, 255, 122);
        for ($i = -$H; $i < $W; $i += 26) imageline($im, $i, $H, $i + $H, 0, $line);
        $gold = idev_medreg_rgb($im, $d['accent']); $txt = idev_medreg_rgb($im, $d['text']); $mut = idev_medreg_rgb($im, $d['muted']);
        // chip
        idev_medreg_round($im, $pad, 168, $pad + 92, 236, 12, $gold);
        $chipLine = imagecolorallocatealpha($im, 0, 0, 0, 90);
        imageline($im, $pad + 30, 168, $pad + 30, 236, $chipLine); imageline($im, $pad + 62, 168, $pad + 62, 236, $chipLine); imageline($im, $pad, 202, $pad + 92, 202, $chipLine);
        $hx = $pad;
        if ($logo) { [$lw] = idev_medreg_contain($im, $logo, $pad, 40, 130, 70); $hx = $pad + $lw + 20; }
        if ($d['show_org'] === '1') idev_medreg_text($im, 24, $hx, 74, $txt, $bold, $site['name'], $W - $hx - $pad - 200);
        idev_medreg_text($im, 15, $W - $pad, 74, $gold, $semi, $en ? ($d['title_en'] ?: $d['title']) : ($d['title_en'] ?: $d['title']), 360, 'right');
        $qs = ($code === 'qr' || $code === 'both') ? 170 : 0;
        $max = $W - 2 * $pad - ($qs ? $qs + 40 : 0);
        idev_medreg_text($im, 56, $pad, 330, $gold, $bold, trim(chunk_split($row['hn'], 3, ' ')), $max);
        idev_medreg_text($im, 30, $pad, 404, $txt, $semi, $name, $max);
        if ($d['show_name_en'] === '1' && $nameEn !== '') idev_medreg_text($im, 18, $pad, 440, $mut, $reg, $nameEn, $max);
        $fx = $pad; $cw = (int) ($max / max(1, count($facts)));
        foreach ($facts as [$l, $v]) { idev_medreg_text($im, 13, $fx, 500, $mut, $reg, mb_strtoupper($l), $cw - 10); idev_medreg_text($im, 18, $fx, 528, $txt, $semi, $v, $cw - 10); $fx += $cw; }
        if ($qs) idev_mrp_qr($im, $d, $row, $W - $pad - $qs, $H - $pad - $qs - 40, $qs, $white);
        if ($code === 'barcode') idev_mrp_barcode($im, $row['hn'], $W - $pad - 360, $H - 120, 360, 50, $white);
        if ($note !== '') idev_medreg_text($im, 13, $pad, $H - 26, $mut, $reg, $note, $W - 2 * $pad - ($qs ? $qs + 30 : 0));
    }
    if ($logo) imagedestroy($logo);
    ob_start(); imagepng($im, null, 6); $png = ob_get_clean();
    imagedestroy($im);
    return $png;
}
