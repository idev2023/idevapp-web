/* iDev Patient Registration — on-device OCR (Tesseract.js, loaded only when needed).
   Passport: several MRZ crops × thresholds, character whitelist, best result by check digits.
   Thai ID card: number band with digits only, then Thai + English text. Nothing is sent to a server. */
(function (root) {
  const P = root.IDevIdParse;

  /* ---------- image helpers (canvas) ---------- */
  const W = (s) => s.naturalWidth || s.videoWidth || s.width;
  const H = (s) => s.naturalHeight || s.videoHeight || s.height;
  function crop(src, x, y, w, h, targetW) {
    const sw = W(src), sh = H(src);
    const sx = Math.max(0, Math.round(x * sw)), sy = Math.max(0, Math.round(y * sh));
    const cw = Math.min(sw - sx, Math.round(w * sw)), ch = Math.min(sh - sy, Math.round(h * sh));
    const scale = targetW ? targetW / cw : 1;
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(cw * scale)); c.height = Math.max(1, Math.round(ch * scale));
    const ctx = c.getContext('2d');
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(src, sx, sy, cw, ch, 0, 0, c.width, c.height);
    return c;
  }
  function rotate180(src) {
    const c = document.createElement('canvas'); c.width = W(src); c.height = H(src);
    const ctx = c.getContext('2d'); ctx.translate(c.width, c.height); ctx.rotate(Math.PI); ctx.drawImage(src, 0, 0);
    return c;
  }
  function grayData(c) {
    const ctx = c.getContext('2d');
    const img = ctx.getImageData(0, 0, c.width, c.height);
    const g = new Uint8ClampedArray(c.width * c.height);
    for (let i = 0, j = 0; i < img.data.length; i += 4, j++) g[j] = 0.299 * img.data[i] + 0.587 * img.data[i + 1] + 0.114 * img.data[i + 2];
    return { ctx, img, g };
  }
  /** Contrast stretch (ignores 2% extremes) — good for Thai ID cards with a pattern background. */
  function contrast(c) {
    const { ctx, img, g } = grayData(c);
    const hist = new Uint32Array(256); g.forEach((v) => hist[v | 0]++);
    let lo = 0, hi = 255, acc = 0; const cut = g.length * 0.02;
    while (lo < 255 && (acc += hist[lo]) < cut) lo++;
    acc = 0; while (hi > 0 && (acc += hist[hi]) < cut) hi--;
    const k = 255 / Math.max(1, hi - lo);
    for (let j = 0, i = 0; j < g.length; j++, i += 4) { const v = Math.max(0, Math.min(255, (g[j] - lo) * k)); img.data[i] = img.data[i + 1] = img.data[i + 2] = v; }
    ctx.putImageData(img, 0, 0);
    return c;
  }
  /** Black & white with a local (adaptive) threshold: copes with shadows and glare on phone photos. */
  function binarize(c, bias = 12, radiusFactor = 0.02) {
    const { ctx, img, g } = grayData(c);
    const w = c.width, h = c.height;
    const r = Math.max(8, Math.round(Math.min(w, h) * radiusFactor * 2.5));
    const ii = new Float64Array((w + 1) * (h + 1)); // integral image
    for (let y = 1; y <= h; y++) { let row = 0; for (let x = 1; x <= w; x++) { row += g[(y - 1) * w + x - 1]; ii[y * (w + 1) + x] = ii[(y - 1) * (w + 1) + x] + row; } }
    for (let y = 0; y < h; y++) {
      const y0 = Math.max(0, y - r), y1 = Math.min(h, y + r + 1);
      for (let x = 0; x < w; x++) {
        const x0 = Math.max(0, x - r), x1 = Math.min(w, x + r + 1);
        const sum = ii[y1 * (w + 1) + x1] - ii[y0 * (w + 1) + x1] - ii[y1 * (w + 1) + x0] + ii[y0 * (w + 1) + x0];
        const mean = sum / ((x1 - x0) * (y1 - y0));
        const v = g[y * w + x] < mean - bias ? 0 : 255;
        const i = (y * w + x) * 4; img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
      }
    }
    ctx.putImageData(img, 0, 0);
    return c;
  }
  /** Variance of the Laplacian on a small grey copy: higher = sharper. Used by the camera to wait for focus. */
  function sharpness(src, x = 0.1, y = 0.1, w = 0.8, h = 0.8) {
    const c = crop(src, x, y, w, h, 320);
    const { g } = grayData(c);
    const cw = c.width, ch = c.height;
    let n = 0, mean = 0, m2 = 0;
    for (let yy = 1; yy < ch - 1; yy++) for (let xx = 1; xx < cw - 1; xx++) {
      const i = yy * cw + xx;
      const lap = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - cw] - g[i + cw];
      n++; const d = lap - mean; mean += d / n; m2 += d * (lap - mean);
    }
    return n ? m2 / n : 0;
  }

  const MRZ_BANDS = [[0.70, 0.30], [0.62, 0.38], [0.76, 0.24], [0.52, 0.48]];
  /** Image variants to read, most likely first: the usual band (normal, then upside down), then the others. */
  function* mrzSequence(src) {
    let flipped = null;
    const flip = () => flipped || (flipped = rotate180(src));
    const make = (img, [y, h], bw) => (bw ? binarize(crop(img, 0, y, 1, h, 1800)) : contrast(crop(img, 0, y, 1, h, 1800)));
    yield make(src, MRZ_BANDS[0], true); yield make(src, MRZ_BANDS[0], false);
    yield make(flip(), MRZ_BANDS[0], true);
    for (const band of MRZ_BANDS.slice(1)) { yield make(src, band, true); yield make(src, band, false); }
    yield make(flip(), MRZ_BANDS[0], false);
    for (const band of MRZ_BANDS.slice(1)) { yield make(flip(), band, true); yield make(flip(), band, false); }
  }
  function mrzVariants(src) { return Array.from(mrzSequence(src)); }

  /* ---------- engine ---------- */
  let loading = null;
  function loadEngine(cfg) {
    if (root.Tesseract) return Promise.resolve(root.Tesseract);
    if (!loading) loading = new Promise((resolve, reject) => {
      const s = document.createElement('script'); s.src = cfg.script; s.async = true;
      s.onload = () => resolve(root.Tesseract); s.onerror = reject; document.head.appendChild(s);
    });
    return loading;
  }
  async function worker(cfg, langs, logger) {
    const T = await loadEngine(cfg);
    const opts = { logger };
    if (cfg.workerPath) opts.workerPath = cfg.workerPath;
    if (cfg.corePath) opts.corePath = cfg.corePath;
    if (cfg.langPath) opts.langPath = cfg.langPath;
    return T.createWorker(langs, 1, opts);
  }

  /**
   * Reads a document. type: 'passport' | 'thai_id'. progress(0..1).
   * Returns parsed fields (see IDevIdParse) or null.
   */
  async function read(cfg, src, type, progress) {
    const step = (p) => progress && progress(Math.min(1, p));
    if (type === 'passport') {
      const w = await worker(cfg, 'eng', () => {});
      try {
        await w.setParameters({ tessedit_char_whitelist: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<', tessedit_pageseg_mode: '6', preserve_interword_spaces: '0' });
        const texts = [];
        const total = 16;
        let i = 0;
        for (const img of mrzSequence(src)) {
          step(++i / total);
          const { data } = await w.recognize(img);
          texts.push(data.text || '');
          const best = P.bestMrz(texts);
          // Good enough: line 2 passes its check digits and two readings agree on the name.
          if (best && best.score >= 4 && (best.name_votes >= 2 || (i >= 4 && best.name_votes >= 1))) return best;
          if (i >= 8 && best && best.score >= 3) return best;
        }
        return P.bestMrz(texts);
      } finally { await w.terminate(); }
    }
    // Thai ID card: 1) the big number near the top, digits only; 2) the whole card in Thai + English.
    const out = {};
    const wd = await worker(cfg, 'eng', () => {});
    try {
      await wd.setParameters({ tessedit_char_whitelist: '0123456789 ', tessedit_pageseg_mode: '6' });
      for (const [y, h] of [[0.08, 0.22], [0.04, 0.32]]) {
        step(y === 0.08 ? 0.15 : 0.3);
        const { data } = await wd.recognize(binarize(crop(src, 0.25, y, 0.75, h, 1600)));
        const cid = P.findCid(data.text);
        if (cid) { out.cid = cid; break; }
      }
    } finally { await wd.terminate(); }
    const wt = await worker(cfg, 'tha+eng', (m) => { if (m.status === 'recognizing text') step(0.35 + m.progress * 0.65); });
    try {
      const { data } = await wt.recognize(contrast(crop(src, 0, 0, 1, 1, 1600)));
      const r = P.parseThaiId(data.text || '');
      return Object.assign(r, out.cid ? { cid: out.cid } : {});
    } finally { await wt.terminate(); }
  }

  root.IDevOcr = { read, crop, binarize, contrast, sharpness, mrzVariants, rotate180 };
})(typeof self !== 'undefined' ? self : this);
