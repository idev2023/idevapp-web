/* iDev Patient Registration — back office: card designer live preview and media pickers. */
(function ($) {
  const form = document.getElementById('idev-mr-card');
  if (!form) return;
  const img = document.getElementById('idev-mr-card-img');
  let lang = 'th', timer = null;
  function design() {
    const d = {};
    form.querySelectorAll('[name^="idev_medreg_card["]').forEach((el) => {
      const k = el.name.slice(17, -1);
      if (el.type === 'checkbox') d[k] = el.checked ? '1' : '';
      else d[k] = el.value;
    });
    return d;
  }
  function refresh() {
    clearTimeout(timer);
    timer = setTimeout(() => {
      const url = new URL(form.dataset.preview, location.href);
      url.searchParams.set('d', JSON.stringify(design()));
      url.searchParams.set('lang', lang);
      url.searchParams.set('r', Date.now());
      img.classList.add('is-loading');
      img.onload = () => img.classList.remove('is-loading');
      img.src = url.toString();
    }, 250);
  }
  form.addEventListener('input', refresh);
  form.addEventListener('change', refresh);
  form.querySelectorAll('.idev-mr-preview-tabs button').forEach((b) => b.addEventListener('click', () => {
    lang = b.dataset.lang;
    form.querySelectorAll('.idev-mr-preview-tabs button').forEach((x) => x.classList.toggle('is-active', x === b));
    refresh();
  }));
  form.querySelectorAll('.idev-mr-media').forEach((box) => {
    const input = box.querySelector('input');
    const thumb = box.querySelector('.idev-mr-thumb');
    box.querySelector('[data-pick]').addEventListener('click', () => {
      const frame = wp.media({ title: (window.IDEV_MR || {}).pick, multiple: false, library: { type: 'image' } });
      frame.on('select', () => {
        const a = frame.state().get('selection').first().toJSON();
        input.value = a.id;
        thumb.innerHTML = '<img src="' + ((a.sizes && a.sizes.thumbnail) || a).url + '" alt="">';
        if (box.dataset.key === 'bg_image') { const s = form.querySelector('[name="idev_medreg_card[bg_type]"]'); if (s) s.value = 'image'; }
        refresh();
      });
      frame.open();
    });
    box.querySelector('[data-clear]').addEventListener('click', () => { input.value = '0'; thumb.innerHTML = ''; refresh(); });
  });
})(jQuery);
