/* iDev Patient Registration — form steps, live camera with autofocus + sharpness check, on-device OCR, GPS, submit. */
(function () {
  const root = document.querySelector('[data-idev-mr]');
  if (!root) return;
  const C = JSON.parse(root.dataset.idevMr);
  const t = C.t;
  const form = root.querySelector('form');
  const steps = Array.from(root.querySelectorAll('.idev-mr-step'));
  const marks = Array.from(root.querySelectorAll('.idev-mr-steps li'));
  const q = (s) => root.querySelector(s);
  const btn = (k) => root.querySelector(`[data-mr="${k}"]`);
  const el = (name) => form.elements[name];
  const val = (name) => { const e = el(name); if (!e) return ''; if (typeof RadioNodeList !== 'undefined' && e instanceof RadioNodeList) return e.value; return e.type === 'checkbox' ? (e.checked ? '1' : '') : String(e.value || '').trim(); };
  const setVal = (name, v) => { const e = el(name); if (e) e.value = v; };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let step = 0;
  let photo = null; // JPEG Blob
  let ocrRun = 0;
  const docType = () => val('doc_type') || 'thai_id';
  const method = () => val('method');

  /* ---------- errors and validation ---------- */
  function setError(name, msg) {
    const box = root.querySelector(`[data-field="${name}"] .idev-mr-error`) || root.querySelector(`[data-error="${name}"]`);
    if (box) { box.textContent = msg || ''; box.hidden = !msg; }
    const wrap = root.querySelector(`[data-field="${name}"]`);
    if (wrap) wrap.classList.toggle('has-error', !!msg);
  }
  function clearErrors() { root.querySelectorAll('.idev-mr-error').forEach((e) => { e.hidden = true; e.textContent = ''; }); root.querySelectorAll('.has-error').forEach((e) => e.classList.remove('has-error')); }
  function validate(i) {
    clearErrors();
    const bad = [];
    const need = (n) => { if (!val(n)) { setError(n, t.required); bad.push(n); } };
    if (i === 0 && !val('consent_pdpa')) { setError('consent', t.consentRequired); return false; }
    if (i === 1) {
      if (!val('method_choice')) { setError('method', t.chooseMethod); return false; }
      if (method() === 'photo' && !photo) { setError('photo', t.photoRequired); return false; }
    }
    if (i === 2) {
      if (docType() === 'thai_id') { const c = val('cid').replace(/\D/g, ''); if (!c) need('cid'); else if (!window.IDevIdParse.validThaiId(c)) { setError('cid', t.invalidCid); bad.push('cid'); } }
      else { need('passport_no'); need('nationality'); }
      ['first_name', 'last_name', 'sex', 'birthdate'].forEach(need);
    }
    if (i === 3) {
      need('phone');
      if (C.requireEmail) need('email');
      if (val('email') && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val('email'))) { setError('email', t.invalidEmail); bad.push('email'); }
      if (C.address === 'required' && el('address')) need('address');
    }
    if (bad.length) { const f = root.querySelector(`[data-field="${bad[0]}"] input, [data-field="${bad[0]}"] textarea`); if (f) f.focus(); }
    return !bad.length;
  }

  /* ---------- steps ---------- */
  function show(i, scroll = true) {
    if (i !== 1) stopCamera();
    step = i;
    steps.forEach((s, k) => { s.hidden = k !== i; s.classList.toggle('is-active', k === i); });
    marks.forEach((m, k) => { m.classList.toggle('active', k === i); m.classList.toggle('done', k < i); });
    btn('back').hidden = i === 0;
    btn('next').hidden = i === steps.length - 1;
    btn('submit').hidden = i !== steps.length - 1;
    root.querySelectorAll('.idev-mr-doc').forEach((d) => { d.hidden = d.dataset.doc !== docType(); });
    if (i === steps.length - 1) review();
    if (scroll) root.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  btn('next').addEventListener('click', () => { if (validate(step)) show(step + 1); });
  btn('back').addEventListener('click', () => show(step - 1));

  function chooseMethod(m) {
    const manual = m === 'manual';
    setVal('method', manual ? 'manual' : 'photo');
    setVal('doc_type', manual ? (val('manual_doc') || 'thai_id') : m);
    q('.idev-mr-manualdoc').hidden = !manual;
    q('.idev-mr-capture').hidden = manual;
    root.querySelectorAll('.idev-mr-method').forEach((l) => l.classList.toggle('is-on', l.querySelector('input').checked));
    q('.idev-mr-guide').classList.toggle('is-passport', m === 'passport');
    if (!manual && photo && lastSource) runOcr(lastSource);
    setError('method', '');
  }
  form.addEventListener('change', (e) => {
    if (e.target.name === 'method_choice') chooseMethod(e.target.value);
    if (e.target.name === 'manual_doc') setVal('doc_type', e.target.value);
    if (e.target.dataset.mr === 'wa-same' && e.target.checked) setVal('whatsapp', val('phone'));
  });
  form.addEventListener('input', (e) => {
    const n = e.target.name;
    if (n === 'cid') e.target.value = e.target.value.replace(/[^\d\s-]/g, '');
    if (n === 'passport_no' || n === 'nationality') e.target.value = e.target.value.toUpperCase();
    if (n === 'phone') { const same = root.querySelector('[data-mr="wa-same"]'); if (same && same.checked) setVal('whatsapp', e.target.value); }
  });

  function review() {
    const L = t.labels, rows = [];
    const add = (label, value) => { if (value) rows.push(`<dt>${esc(label)}</dt><dd>${esc(value)}</dd>`); };
    add(L.method, (docType() === 'thai_id' ? t.docThai : t.docPassport) + (method() === 'manual' ? ' · ' + t.typed : ''));
    if (docType() === 'thai_id') add(L.cid, val('cid')); else { add(L.passport_no, val('passport_no')); add(L.nationality, val('nationality')); }
    add(L.name, [val('prefix'), val('first_name'), val('last_name')].filter(Boolean).join(' '));
    add(L.name_en, [val('first_name_en'), val('last_name_en')].filter(Boolean).join(' '));
    add(L.sex, val('sex') === 'male' ? L.male : val('sex') === 'female' ? L.female : '');
    add(L.birthdate, val('birthdate') ? new Date(val('birthdate') + 'T00:00:00Z').toLocaleDateString(C.lang === 'en' ? 'en-GB' : 'th-TH', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }) : '');
    add(L.phone, val('phone')); add(L.email, val('email')); add(L.line_id, val('line_id')); add(L.whatsapp, val('whatsapp'));
    const pref = root.querySelector('input[name="contact_pref"]:checked');
    if (pref) add(L.contact_pref, pref.parentElement.textContent.trim());
    add(L.address, val('address'));
    if (val('lat')) add(L.location, `${val('lat')}, ${val('lng')}`);
    add(L.allergy, val('drug_allergy')); add(L.emergency, [val('emergency_name'), val('emergency_phone')].filter(Boolean).join(' · '));
    const prev = q('.idev-mr-preview');
    q('.idev-mr-review').innerHTML = rows.join('') + (photo && prev.src ? `<dt>${esc(L.photo)}</dt><dd><img src="${prev.src}" alt=""></dd>` : '');
  }

  /* ---------- camera ---------- */
  const cam = q('.idev-mr-cam'), video = cam.querySelector('video'), guide = q('.idev-mr-guide'), hint = q('.idev-mr-cam-hint'), meter = q('.idev-mr-meter b');
  let stream = null, track = null, loop = null, sharpRun = 0, peak = 0, started = 0, torchOn = false;
  const passport = () => docType() === 'passport';
  async function startCamera() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.isSecureContext) return cameraFallback();
    cam.hidden = false;
    hint.textContent = t.camStarting;
    document.documentElement.classList.add('idev-mr-camera-open');
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: { ideal: 'environment' }, width: { ideal: 2560 }, height: { ideal: 1440 } } });
    } catch (e) { stopCamera(); return cameraFallback(); }
    video.srcObject = stream;
    await video.play().catch(() => {});
    track = stream.getVideoTracks()[0];
    const caps = track.getCapabilities ? track.getCapabilities() : {};
    // Continuous autofocus where the browser lets us choose it (Android Chrome); iOS focuses continuously by itself.
    if (caps.focusMode && caps.focusMode.includes('continuous')) track.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(() => {});
    if (caps.torch) btn('torch').hidden = false;
    hint.textContent = passport() ? t.camHintPassport : t.camHintId;
    sharpRun = 0; peak = 0; started = Date.now();
    loop = setInterval(checkFocus, 180);
  }
  function stopCamera() {
    if (loop) { clearInterval(loop); loop = null; }
    if (stream) stream.getTracks().forEach((tr) => tr.stop());
    stream = null; track = null; torchOn = false;
    if (cam) cam.hidden = true;
    document.documentElement.classList.remove('idev-mr-camera-open');
  }
  function cameraFallback() {
    const fb = q('.idev-mr-fallback');
    fb.textContent = t.camBlocked; fb.hidden = false;
    const f = root.querySelector('[data-mr="file"]');
    f.setAttribute('capture', 'environment');
    f.click();
  }
  /** Part of the video frame inside the guide box (fractions of the video's own size; the video is shown with object-fit: cover). */
  function guideRect() {
    const vw = video.videoWidth, vh = video.videoHeight;
    const r = video.getBoundingClientRect(), g = guide.getBoundingClientRect();
    const scale = Math.max(r.width / vw, r.height / vh);
    const ox = (r.width - vw * scale) / 2, oy = (r.height - vh * scale) / 2;
    const x = (g.left - r.left - ox) / scale, y = (g.top - r.top - oy) / scale;
    return { x: Math.max(0, x / vw), y: Math.max(0, y / vh), w: Math.min(1, g.width / scale / vw), h: Math.min(1, g.height / scale / vh) };
  }
  function checkFocus() {
    if (!video.videoWidth) return;
    const g = guideRect();
    const s = window.IDevOcr.sharpness(video, g.x, g.y, g.w, g.h);
    peak = Math.max(s, peak * 0.97);
    const ok = peak > 25 && s >= peak * 0.8;
    sharpRun = ok ? sharpRun + 1 : 0;
    meter.style.width = Math.min(100, Math.round((s / Math.max(peak, 40)) * 100)) + '%';
    cam.classList.toggle('is-sharp', ok);
    if (Date.now() - started > 1200) hint.textContent = ok ? (C.auto ? t.camSharp : (passport() ? t.camHintPassport : t.camHintId)) : t.camFocus;
    if (C.auto && ok && sharpRun >= 4 && Date.now() - started > 1500) shoot();
  }
  async function shoot() {
    if (!video.videoWidth) return;
    clearInterval(loop); loop = null;
    const g = guideRect();
    // a little margin around the frame helps the reader
    const m = 0.03, x = Math.max(0, g.x - m), y = Math.max(0, g.y - m), w = Math.min(1 - x, g.w + 2 * m), h = Math.min(1 - y, g.h + 2 * m);
    const target = Math.min(2000, Math.round(video.videoWidth * w));
    const canvas = window.IDevOcr.crop(video, x, y, w, h, target);
    if (navigator.vibrate) navigator.vibrate(40);
    stopCamera();
    await usePhoto(canvas);
  }
  video && video.addEventListener('click', (e) => {
    // tap to focus where supported
    if (!track || !track.getCapabilities) return;
    const caps = track.getCapabilities();
    if (!caps.pointsOfInterest && !(caps.focusMode && caps.focusMode.includes('single-shot'))) return;
    const r = video.getBoundingClientRect();
    const pt = { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height };
    track.applyConstraints({ advanced: [Object.assign({ focusMode: 'single-shot' }, caps.pointsOfInterest ? { pointsOfInterest: [pt] } : {})] }).catch(() => {});
    setTimeout(() => { if (track && caps.focusMode && caps.focusMode.includes('continuous')) track.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(() => {}); }, 1500);
  });
  btn('camera').addEventListener('click', startCamera);
  btn('shoot').addEventListener('click', shoot);
  btn('close').addEventListener('click', stopCamera);
  btn('torch').addEventListener('click', () => { if (!track) return; torchOn = !torchOn; track.applyConstraints({ advanced: [{ torch: torchOn }] }).catch(() => {}); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && stream) stopCamera(); });

  /* ---------- photo from file ---------- */
  root.querySelector('[data-mr="file"]').addEventListener('change', async (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    try {
      const bmp = window.createImageBitmap ? await createImageBitmap(file, { imageOrientation: 'from-image' }).catch(() => loadImg(file)) : await loadImg(file);
      const scale = Math.min(1, 2000 / Math.max(bmp.width, bmp.height));
      const c = document.createElement('canvas');
      c.width = Math.round(bmp.width * scale); c.height = Math.round(bmp.height * scale);
      c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
      await usePhoto(c);
    } catch (err) { setError('photo', t.photoRequired); }
    e.target.value = '';
  });
  function loadImg(file) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = URL.createObjectURL(file); }); }

  let lastSource = null;
  async function usePhoto(canvas) {
    // re-drawn on a canvas: the uploaded JPEG has no EXIF / location data
    photo = await new Promise((res) => canvas.toBlob(res, 'image/jpeg', 0.88));
    lastSource = canvas;
    const prev = q('.idev-mr-preview');
    prev.src = canvas.toDataURL('image/jpeg', 0.6); prev.hidden = false;
    btn('camera').lastChild.textContent = ' ' + t.retake;
    setError('photo', '');
    runOcr(canvas);
  }

  /* ---------- reading the document ---------- */
  const ocrBox = q('.idev-mr-ocr'), ocrText = q('.idev-mr-ocr-text'), ocrBar = q('.idev-mr-bar i');
  function status(text, p) { ocrBox.hidden = false; ocrText.textContent = text; ocrBar.style.width = Math.round((p || 0) * 100) + '%'; ocrBox.classList.toggle('is-busy', p !== null && p < 1); }
  async function runOcr(src) {
    if (!C.ocr) return;
    const run = ++ocrRun;
    status(t.reading, 0.03);
    try {
      const data = await window.IDevOcr.read(C.engine, src, docType(), (p) => { if (run === ocrRun) status(t.reading, p); });
      if (run !== ocrRun) return;
      const n = fill(data || {});
      status(n >= 4 ? t.readOk : n > 0 ? t.readPartial : t.readFail, null);
      q('[data-ocr-note]').hidden = n === 0;
    } catch (e) { if (run === ocrRun) status(t.readFail, null); }
  }
  /** Puts what was read into empty fields only (never overwrites what the person typed). */
  function fill(d) {
    let n = 0;
    const set = (name, v) => {
      if (!v) return;
      const e = el(name);
      if (!e) return;
      if (typeof RadioNodeList !== 'undefined' && e instanceof RadioNodeList) { if (!e.value) { e.value = v; n++; } return; }
      if (!String(e.value).trim()) { e.value = v; n++; }
    };
    if (d.doc_type === 'passport') {
      set('passport_no', d.passport_no); set('nationality', d.nationality);
      set('first_name_en', d.first_name_en); set('last_name_en', d.last_name_en);
      // foreigners: the passport name is their name; Thai passport: keep Thai name fields for the person to type
      if (d.nationality !== 'THA') { set('first_name', d.first_name_en); set('last_name', d.last_name_en); }
      if (d.cid) set('cid', d.cid);
      if (d.sex) set('prefix', d.nationality === 'THA' ? (d.sex === 'male' ? 'นาย' : '') : (d.sex === 'male' ? 'Mr' : 'Ms'));
    } else {
      set('cid', d.cid); set('prefix', d.prefix || d.prefix_en);
      set('first_name', d.first_name); set('last_name', d.last_name);
      set('first_name_en', d.first_name_en); set('last_name_en', d.last_name_en);
      set('address', d.address);
    }
    set('birthdate', d.birthdate); set('sex', d.sex);
    return n;
  }

  /* ---------- GPS ---------- */
  const gpsBtn = btn('gps');
  if (gpsBtn) {
    const st = q('.idev-mr-gps-status');
    gpsBtn.addEventListener('click', () => {
      if (!navigator.geolocation) { st.textContent = t.gpsFail; return; }
      st.textContent = '…';
      navigator.geolocation.getCurrentPosition((pos) => {
        setVal('lat', pos.coords.latitude.toFixed(6)); setVal('lng', pos.coords.longitude.toFixed(6));
        st.innerHTML = `✓ ${esc(t.gpsOk)} <a href="https://www.google.com/maps?q=${val('lat')},${val('lng')}" target="_blank" rel="noopener">${val('lat')}, ${val('lng')} ↗</a> · <button type="button" class="idev-mr-link" data-mr="gps-clear">${esc(t.gpsClear)}</button>`;
      }, () => { st.textContent = t.gpsFail; }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 });
    });
    root.addEventListener('click', (e) => { if (e.target.closest('[data-mr="gps-clear"]')) { setVal('lat', ''); setVal('lng', ''); st.textContent = ''; } });
  }

  /* ---------- send ---------- */
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    for (let i = 0; i < steps.length - 1; i++) if (!validate(i)) { show(i); validate(i); return; }
    const body = new FormData(form);
    body.set('cid', val('cid').replace(/\D/g, ''));
    body.delete('method_choice'); body.delete('manual_doc');
    if (method() === 'photo' && photo) body.set('photo', photo, 'document.jpg');
    const sb = btn('submit');
    sb.disabled = true; sb.textContent = t.sending;
    try {
      const r = await fetch(C.rest, { method: 'POST', body, credentials: 'same-origin' });
      const j = await r.json().catch(() => ({}));
      if (r.ok && j.ok) {
        form.hidden = true; q('.idev-mr-steps').hidden = true;
        q('.idev-mr-done-text').textContent = (val('email') ? t.doneText : t.doneTextNoEmail).replace('{ref}', j.ref).replace('{email}', val('email'));
        const done = q('.idev-mr-done'); done.hidden = false; done.focus();
        if (j.next_url) { const a = document.createElement('a'); a.className = 'idev-mr-btn is-primary'; a.href = j.next_url; a.textContent = j.next_label || '→'; const pr = document.createElement('p'); pr.appendChild(a); done.appendChild(pr); }
        root.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      const errors = j.errors || { form: t.errorGeneric };
      const order = [['consent', 0], ['method', 1], ['photo', 1], ['cid', 2], ['passport_no', 2], ['nationality', 2], ['first_name', 2], ['last_name', 2], ['sex', 2], ['birthdate', 2], ['phone', 3], ['email', 3], ['whatsapp', 3], ['address', 3]];
      const first = order.find(([n]) => errors[n]);
      if (first) show(first[1]);
      Object.keys(errors).forEach((n) => setError(n, errors[n]));
      if (!first) setError('form', errors.form || t.errorGeneric);
    } catch (err) { setError('form', t.errorGeneric); }
    finally { sb.disabled = false; sb.textContent = sb.dataset.label || sb.textContent; }
  });
  btn('submit').dataset.label = btn('submit').textContent;

  // only one way enabled: choose it for the patient
  const only = root.querySelectorAll('input[name="method_choice"]');
  if (only.length === 1) { only[0].checked = true; chooseMethod(only[0].value); }
  show(0, false);
})();
