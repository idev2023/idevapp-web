<?php
/**
 * Encryption keys for patient data (libsodium secretbox, XSalsa20-Poly1305).
 *
 * Where the active key comes from, in this order:
 *  1. IDEV_MEDREG_KEY in wp-config.php (64 hex characters)
 *  2. a key file outside the web folder (created from the Encryption settings tab)
 *  3. derived from AUTH_KEY + SECURE_AUTH_KEY in wp-config.php (default, nothing to set up)
 * Older keys stay in the key ring so earlier records can still be read; "Re-encrypt" moves everything to the active key.
 * If AUTH_KEY / SECURE_AUTH_KEY were changed, put the old values in IDEV_MEDREG_OLD_AUTH_KEY / IDEV_MEDREG_OLD_SECURE_AUTH_KEY.
 */
defined('ABSPATH') || exit;

function idev_medreg_key_id($key) { return substr(hash('sha256', 'idev-medreg-id|' . $key), 0, 8); }

function idev_medreg_salt_key($auth, $secure) { return hash('sha256', 'idev-medreg|' . $auth . '|' . $secure, true); }

/** Default key-file path (outside the web folder). Override with IDEV_MEDREG_KEYFILE. */
function idev_medreg_keyfile_path() {
    if (defined('IDEV_MEDREG_KEYFILE') && IDEV_MEDREG_KEYFILE) return IDEV_MEDREG_KEYFILE;
    return dirname(untrailingslashit(ABSPATH)) . '/idev-private/medreg-keys.php';
}
function idev_medreg_keyfile_read() {
    $path = idev_medreg_keyfile_path();
    if (!is_file($path) || !is_readable($path)) return null;
    $data = include $path; // returns an array; a PHP file prints nothing even if a web server could reach it
    if (!is_array($data) || empty($data['keys']) || !is_array($data['keys'])) return null;
    $keys = [];
    foreach ($data['keys'] as $id => $hex) if (preg_match('/^[0-9a-f]{64}$/', (string) $hex)) $keys[(string) $id] = hex2bin($hex);
    $active = (string) ($data['active'] ?? '');
    return $keys && isset($keys[$active]) ? ['active' => $active, 'keys' => $keys] : null;
}
function idev_medreg_keyfile_write($ring) {
    $path = idev_medreg_keyfile_path();
    $dir = dirname($path);
    if (!is_dir($dir) && !wp_mkdir_p($dir)) return new WP_Error('dir', sprintf(__('Cannot create the folder %s. Ask your server administrator, or use the IDEV_MEDREG_KEY constant instead.', 'idev-patient-registration'), $dir));
    @file_put_contents($dir . '/.htaccess', "Require all denied\nDeny from all\n");
    @file_put_contents($dir . '/index.php', "<?php // Silence\n");
    $hex = [];
    foreach ($ring['keys'] as $id => $bin) $hex[$id] = bin2hex($bin);
    $php = "<?php\n// iDev Patient Registration encryption keys. KEEP A BACKUP. Losing this file = losing access to encrypted patient data.\n// Created " . gmdate('c') . "\nreturn " . var_export(['active' => $ring['active'], 'keys' => $hex], true) . ";\n";
    $tmp = $path . '.tmp';
    if (@file_put_contents($tmp, $php, LOCK_EX) === false || !@rename($tmp, $path)) return new WP_Error('write', sprintf(__('Cannot write %s.', 'idev-patient-registration'), $path));
    @chmod($path, 0600);
    if (function_exists('opcache_invalidate')) @opcache_invalidate($path, true);
    return true;
}

/** Key ring: ['active' => id, 'source' => constant|file|salts, 'keys' => [id => 32-byte key]]. */
function idev_medreg_keyring($refresh = false) {
    static $ring = null;
    if ($ring && !$refresh) return $ring;
    $keys = []; $active = ''; $source = 'salts';
    $salt = idev_medreg_salt_key(defined('AUTH_KEY') ? AUTH_KEY : '', defined('SECURE_AUTH_KEY') ? SECURE_AUTH_KEY : '');
    $keys[idev_medreg_key_id($salt)] = $salt;
    if (defined('IDEV_MEDREG_OLD_AUTH_KEY') || defined('IDEV_MEDREG_OLD_SECURE_AUTH_KEY')) {
        $old = idev_medreg_salt_key(defined('IDEV_MEDREG_OLD_AUTH_KEY') ? IDEV_MEDREG_OLD_AUTH_KEY : (defined('AUTH_KEY') ? AUTH_KEY : ''), defined('IDEV_MEDREG_OLD_SECURE_AUTH_KEY') ? IDEV_MEDREG_OLD_SECURE_AUTH_KEY : (defined('SECURE_AUTH_KEY') ? SECURE_AUTH_KEY : ''));
        $keys[idev_medreg_key_id($old)] = $old;
    }
    $active = idev_medreg_key_id($salt);
    $file = idev_medreg_keyfile_read();
    if ($file) { $keys = $file['keys'] + $keys; $active = $file['active']; $source = 'file'; }
    if (defined('IDEV_MEDREG_KEY') && preg_match('/^[0-9a-f]{64}$/i', IDEV_MEDREG_KEY)) {
        $k = hex2bin(strtolower(IDEV_MEDREG_KEY));
        $keys = [idev_medreg_key_id($k) => $k] + $keys; $active = idev_medreg_key_id($k); $source = 'constant';
    }
    $ring = ['active' => $active, 'source' => $source, 'keys' => $keys];
    return $ring;
}

/** Legacy Andaman Hub keys (only used to read data copied from Andaman Hub). */
function idev_medreg_legacy_keys() {
    $out = [];
    if (defined('AH_REG_KEY') && preg_match('/^[0-9a-f]{64}$/i', AH_REG_KEY)) $out[] = hex2bin(AH_REG_KEY);
    $out[] = hash('sha256', 'ah-registration|' . (defined('AUTH_KEY') ? AUTH_KEY : '') . '|' . (defined('SECURE_AUTH_KEY') ? SECURE_AUTH_KEY : ''), true);
    if (defined('IDEV_MEDREG_OLD_AUTH_KEY') || defined('IDEV_MEDREG_OLD_SECURE_AUTH_KEY')) $out[] = hash('sha256', 'ah-registration|' . (defined('IDEV_MEDREG_OLD_AUTH_KEY') ? IDEV_MEDREG_OLD_AUTH_KEY : '') . '|' . (defined('IDEV_MEDREG_OLD_SECURE_AUTH_KEY') ? IDEV_MEDREG_OLD_SECURE_AUTH_KEY : ''), true);
    return $out;
}

function idev_medreg_encrypt($plain) {
    $ring = idev_medreg_keyring();
    $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
    return 'k1:' . $ring['active'] . ':' . base64_encode($nonce . sodium_crypto_secretbox((string) $plain, $nonce, $ring['keys'][$ring['active']]));
}
function idev_medreg_open($b64, $key) {
    $raw = base64_decode((string) $b64, true);
    if ($raw === false || strlen($raw) < SODIUM_CRYPTO_SECRETBOX_NONCEBYTES + SODIUM_CRYPTO_SECRETBOX_MACBYTES) return null;
    $plain = sodium_crypto_secretbox_open(substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), $key);
    return $plain === false ? null : $plain;
}
/** Decrypts with whichever key it was made with; null if no key fits (wrong or lost key). */
function idev_medreg_decrypt($cipher) {
    $cipher = (string) $cipher;
    $ring = idev_medreg_keyring();
    if (preg_match('/^k1:([0-9a-f]{8}):(.+)$/s', $cipher, $m)) {
        if (isset($ring['keys'][$m[1]])) return idev_medreg_open($m[2], $ring['keys'][$m[1]]);
        return null;
    }
    foreach (array_merge(array_values($ring['keys']), idev_medreg_legacy_keys()) as $k) { $p = idev_medreg_open($cipher, $k); if ($p !== null) return $p; }
    return null;
}
/** Key id a ciphertext was made with ('' = legacy format). */
function idev_medreg_cipher_key($cipher) { return preg_match('/^k1:([0-9a-f]{8}):/', (string) $cipher, $m) ? $m[1] : ''; }

/** Keyed hash of an ID / passport number, to find duplicates without storing the number in clear. Uses a separate stable secret so key rotation does not break it. */
function idev_medreg_search_key($doc_type, $number) {
    $secret = get_option('idev_medreg_hash_secret');
    if (!$secret) { $secret = bin2hex(random_bytes(32)); update_option('idev_medreg_hash_secret', $secret, false); }
    return hash_hmac('sha256', $doc_type . '|' . strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string) $number)), $secret);
}

/** Moves the key ring to a new random key in the key file (keeps old keys for reading). */
function idev_medreg_new_file_key() {
    $ring = idev_medreg_keyfile_read() ?: ['active' => '', 'keys' => []];
    $current = idev_medreg_keyring(true);
    foreach ($current['keys'] as $id => $k) if (!isset($ring['keys'][$id])) $ring['keys'][$id] = $k; // keep everything readable
    $new = random_bytes(SODIUM_CRYPTO_SECRETBOX_KEYBYTES);
    $id = idev_medreg_key_id($new);
    $ring['keys'] = [$id => $new] + $ring['keys'];
    $ring['active'] = $id;
    $ok = idev_medreg_keyfile_write($ring);
    if (is_wp_error($ok)) return $ok;
    idev_medreg_keyring(true);
    return $id;
}
/** Removes keys from the key file that no record uses any more. */
function idev_medreg_prune_file_keys() {
    $ring = idev_medreg_keyfile_read();
    if (!$ring) return 0;
    $used = idev_medreg_key_usage();
    $removed = 0;
    foreach (array_keys($ring['keys']) as $id) if ($id !== $ring['active'] && empty($used[$id])) { unset($ring['keys'][$id]); $removed++; }
    if ($removed) idev_medreg_keyfile_write($ring);
    idev_medreg_keyring(true);
    return $removed;
}

/** How many records (and ID photos) use each key id; '' = old format; 'unreadable' = no key fits. */
function idev_medreg_key_usage() {
    global $wpdb;
    $usage = [];
    $last = 0;
    do {
        $rows = $wpdb->get_results($wpdb->prepare('SELECT id, data FROM ' . idev_medreg_table() . ' WHERE id > %d ORDER BY id LIMIT 500', $last), ARRAY_A);
        foreach ($rows as $r) {
            $last = (int) $r['id'];
            $id = idev_medreg_cipher_key($r['data']);
            $key = ($id === '' || isset(idev_medreg_keyring()['keys'][$id])) ? $id : 'unreadable';
            if ($key === '' && idev_medreg_decrypt($r['data']) === null) $key = 'unreadable';
            $usage[$key] = ($usage[$key] ?? 0) + 1;
        }
    } while ($rows);
    return $usage;
}

/** Re-encrypts records (and their ID photos) with the active key, $batch at a time. Returns [done, failed, next_id]. */
function idev_medreg_reencrypt($from_id = 0, $batch = 200) {
    global $wpdb;
    $ring = idev_medreg_keyring(true);
    $rows = $wpdb->get_results($wpdb->prepare('SELECT id, data, photo FROM ' . idev_medreg_table() . ' WHERE id > %d ORDER BY id LIMIT %d', $from_id, $batch), ARRAY_A);
    $done = 0; $failed = 0; $next = 0;
    foreach ($rows as $r) {
        $next = (int) $r['id'];
        if (idev_medreg_cipher_key($r['data']) === $ring['active'] && ($r['photo'] === '' || idev_medreg_photo_key($r['photo']) === $ring['active'])) continue;
        $plain = idev_medreg_decrypt($r['data']);
        if ($plain === null) { $failed++; continue; }
        $wpdb->update(idev_medreg_table(), ['data' => idev_medreg_encrypt($plain)], ['id' => $next]);
        if ($r['photo'] !== '') {
            $bytes = idev_medreg_photo_bytes($r['photo']);
            if ($bytes !== null) idev_medreg_photo_write($r['photo'], $bytes);
        }
        $done++;
    }
    return [$done, $failed, count($rows) < $batch ? 0 : $next];
}
