<?php
/** Back office: registrations list and record view. Needs the idev_medreg capability (role "Medical records staff"). */
defined('ABSPATH') || exit;

add_action('admin_menu', function () {
    global $wpdb;
    $pending = (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . idev_medreg_table() . " WHERE status IN ('pending','error')");
    $badge = $pending ? ' <span class="awaiting-mod">' . $pending . '</span>' : '';
    add_menu_page(__('Patient registrations', 'idev-patient-registration'), __('Registrations', 'idev-patient-registration') . $badge, 'idev_medreg', 'idev-medreg', 'idev_medreg_admin_page', 'dashicons-id-alt', 4);
    add_submenu_page('idev-medreg', __('Patient registrations', 'idev-patient-registration'), __('All registrations', 'idev-patient-registration'), 'idev_medreg', 'idev-medreg', 'idev_medreg_admin_page');
});
add_action('admin_enqueue_scripts', function ($hook) {
    if (strpos($hook, 'idev-medreg') === false) return;
    wp_enqueue_style('idev-medreg-admin', IDEV_MEDREG_URL . 'assets/admin.css', [], IDEV_MEDREG_VERSION);
    wp_enqueue_script('idev-medreg-admin', IDEV_MEDREG_URL . 'assets/admin.js', ['jquery'], IDEV_MEDREG_VERSION, true);
    wp_localize_script('idev-medreg-admin', 'IDEV_MR', ['pick' => __('Choose image', 'idev-patient-registration')]);
});

function idev_medreg_mask($v) { $v = (string) $v; return strlen($v) > 4 ? str_repeat('•', strlen($v) - 4) . substr($v, -4) : $v; }
function idev_medreg_badge($status) {
    $colors = ['pending' => '#b26a00', 'approved' => '#2271b1', 'synced' => '#0a7d55', 'error' => '#b32d2e', 'rejected' => '#646970'];
    return '<span class="idev-mr-badge" style="background:' . ($colors[$status] ?? '#646970') . '">' . esc_html(idev_medreg_statuses()[$status] ?? $status) . '</span>';
}
function idev_medreg_line_url($id) { return 'https://line.me/ti/p/~' . rawurlencode(ltrim((string) $id, '@~')); }
function idev_medreg_wa_url($num) { $d = preg_replace('/\D/', '', (string) $num); if (strpos((string) $num, '+') !== 0 && strpos($d, '0') === 0) $d = '66' . substr($d, 1); return 'https://wa.me/' . $d; }

function idev_medreg_admin_page() {
    if (!current_user_can('idev_medreg')) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-patient-registration'));
    if (isset($_GET['id'])) { idev_medreg_admin_view((int) $_GET['id']); return; }
    global $wpdb;
    $t = idev_medreg_table();
    $statuses = idev_medreg_statuses();
    $status = isset($_GET['status']) && isset($statuses[$_GET['status']]) ? sanitize_key($_GET['status']) : '';
    $search = trim(sanitize_text_field(wp_unslash($_GET['s'] ?? '')));
    $counts = [];
    foreach ($wpdb->get_results("SELECT status, COUNT(*) AS n FROM {$t} GROUP BY status", ARRAY_A) as $r) $counts[$r['status']] = (int) $r['n'];
    idev_admin_header(__('Patient registrations', 'idev-patient-registration'));
    foreach (['deleted' => __('Deleted.', 'idev-patient-registration')] as $k => $text) if (isset($_GET[$k])) echo '<div class="notice notice-success"><p>' . esc_html($text) . '</p></div>';
    echo '<ul class="subsubsub"><li><a href="' . esc_url(admin_url('admin.php?page=idev-medreg')) . '"' . ($status === '' ? ' class="current"' : '') . '>' . esc_html__('All', 'idev-patient-registration') . ' (' . array_sum($counts) . ')</a></li>';
    foreach ($statuses as $k => $label) echo '<li> | <a href="' . esc_url(admin_url('admin.php?page=idev-medreg&status=' . $k)) . '"' . ($status === $k ? ' class="current"' : '') . '>' . esc_html($label) . ' (' . ($counts[$k] ?? 0) . ')</a></li>';
    echo '</ul><form method="get" class="search-box" style="margin:8px 0"><input type="hidden" name="page" value="idev-medreg"><input type="search" name="s" value="' . esc_attr($search) . '" placeholder="' . esc_attr__('Reference, HN, name, phone, ID number', 'idev-patient-registration') . '"><button class="button">' . esc_html__('Search', 'idev-patient-registration') . '</button></form>';
    $where = $status ? $wpdb->prepare('WHERE status=%s', $status) : '';
    $rows = $wpdb->get_results("SELECT * FROM {$t} {$where} ORDER BY FIELD(status,'pending','error','approved','synced','rejected'), id DESC LIMIT 500", ARRAY_A);
    echo '<table class="widefat striped idev-mr-table"><thead><tr><th>' . esc_html__('Reference', 'idev-patient-registration') . '</th><th>' . esc_html__('Name', 'idev-patient-registration') . '</th><th>' . esc_html__('Document', 'idev-patient-registration') . '</th><th>' . esc_html__('Contact', 'idev-patient-registration') . '</th><th>' . esc_html__('Status', 'idev-patient-registration') . '</th><th>HN</th><th>' . esc_html__('Sent', 'idev-patient-registration') . '</th></tr></thead><tbody>';
    $shown = 0;
    foreach ($rows as $row) {
        $plain = idev_medreg_decrypt($row['data']);
        $p = $plain !== null ? (json_decode($plain, true) ?: []) : [];
        $number = $row['doc_type'] === 'passport' ? ($p['passport_no'] ?? '') : ($p['cid'] ?? '');
        if ($search !== '') {
            $hay = mb_strtolower(implode(' ', [$row['ref'], $row['hn'], idev_medreg_name($p), idev_medreg_name_en($p), $p['phone'] ?? '', $number, $p['email'] ?? '', $p['line_id'] ?? '', $p['whatsapp'] ?? '']));
            if (strpos($hay, mb_strtolower($search)) === false) continue;
        }
        $shown++;
        $url = admin_url('admin.php?page=idev-medreg&id=' . $row['id']);
        $contact = esc_html($p['phone'] ?? '');
        if (!empty($p['line_id'])) $contact .= ' <span class="idev-mr-chip is-line">LINE</span>';
        if (!empty($p['whatsapp'])) $contact .= ' <span class="idev-mr-chip is-wa">WhatsApp</span>';
        echo '<tr><td><a href="' . esc_url($url) . '"><strong>' . esc_html($row['ref']) . '</strong></a></td><td><a href="' . esc_url($url) . '">' . esc_html(idev_medreg_name($p) ?: __('(cannot read — check the encryption key)', 'idev-patient-registration')) . '</a></td>';
        echo '<td>' . ($row['doc_type'] === 'passport' ? 'Passport ' . esc_html(($p['nationality'] ?? '') . ' ' . idev_medreg_mask($number)) : esc_html__('ID card', 'idev-patient-registration') . ' ' . esc_html(idev_medreg_mask($number))) . ($row['method'] === 'manual' ? ' <span class="idev-mr-chip">' . esc_html__('typed', 'idev-patient-registration') . '</span>' : '') . '</td><td>' . $contact . '</td><td>' . idev_medreg_badge($row['status']) . '</td><td>' . esc_html($row['hn']) . '</td><td>' . esc_html(get_date_from_gmt($row['created_at'], 'j M Y H:i')) . '</td></tr>';
    }
    if (!$shown) echo '<tr><td colspan="7">' . esc_html__('No registrations.', 'idev-patient-registration') . '</td></tr>';
    echo '</tbody></table>';
    $seen = (int) get_option('idev_medreg_connector_seen');
    if (idev_medreg_connector_on()) echo '<p class="description">' . esc_html__('HOSxP connector last contact:', 'idev-patient-registration') . ' ' . ($seen ? esc_html(wp_date('j M Y H:i', $seen)) . ($seen < time() - 15 * MINUTE_IN_SECONDS ? ' <strong style="color:#b32d2e">' . esc_html__('(more than 15 minutes ago — check the computer running the connector)', 'idev-patient-registration') . '</strong>' : '') : esc_html__('never', 'idev-patient-registration')) . '</p>';
    echo '</div>';
}

function idev_medreg_admin_view($id) {
    $row = idev_medreg_get($id);
    if (!$row) { echo '<div class="wrap"><p>' . esc_html__('Not found.', 'idev-patient-registration') . '</p></div>'; return; }
    $p = $row['person'];
    $form = function ($do, $label, $class = 'button', $extra = '', $confirm = '') use ($id) {
        return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="idev-mr-inline"' . ($confirm ? ' onsubmit="return confirm(\'' . esc_js($confirm) . '\')"' : '') . '>' . wp_nonce_field('idev_medreg_' . $id, '_wpnonce', true, false) . '<input type="hidden" name="action" value="idev_medreg"><input type="hidden" name="id" value="' . (int) $id . '"><input type="hidden" name="do" value="' . esc_attr($do) . '">' . $extra . '<button class="' . esc_attr($class) . '">' . esc_html($label) . '</button></form>';
    };
    $v = function ($k) use ($p) { return esc_attr((string) ($p[$k] ?? '')); };
    $L = function ($text) { return esc_html($text); };
    echo '<div class="wrap idev-wrap idev-mr"><p><a href="' . esc_url(admin_url('admin.php?page=idev-medreg')) . '">← ' . esc_html__('All registrations', 'idev-patient-registration') . '</a></p>';
    echo '<h1>' . esc_html($row['ref']) . ' ' . idev_medreg_badge($row['status']) . ($row['hn'] ? ' <span class="idev-mr-hn">HN <strong>' . esc_html($row['hn']) . '</strong></span>' : '') . '</h1>';
    foreach (['done' => [__('Saved.', 'idev-patient-registration'), 'success'], 'mailed' => [__('Patient card e-mailed.', 'idev-patient-registration'), 'success'], 'mailfail' => [__('The e-mail could not be sent. Check the server e-mail settings (an SMTP plugin is recommended).', 'idev-patient-registration'), 'error']] as $k => [$t, $type]) if (isset($_GET[$k])) echo '<div class="notice notice-' . $type . '"><p>' . esc_html($t) . '</p></div>';
    if (!$row['readable']) { echo '<div class="notice notice-error"><p>' . esc_html__('This record cannot be decrypted with the current keys. See Settings → Encryption key.', 'idev-patient-registration') . '</p></div></div>'; return; }
    if ($row['message']) echo '<div class="notice notice-' . ($row['status'] === 'error' ? 'error' : 'info') . '"><p>' . esc_html($row['message']) . '</p></div>';
    echo '<div class="idev-mr-layout"><div class="idev-card">';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('idev_medreg_' . $id, '_wpnonce', true, false) . '<input type="hidden" name="action" value="idev_medreg"><input type="hidden" name="id" value="' . (int) $id . '"><input type="hidden" name="do" value="save"><input type="hidden" name="method" value="' . $v('method') . '">';
    echo '<h2>' . $L(__('Patient details', 'idev-patient-registration')) . '</h2><p class="description">' . ($row['method'] === 'manual' ? esc_html__('Typed in by the patient — check the document at the counter.', 'idev-patient-registration') : esc_html__('Compare with the document photo; correct anything the reader got wrong.', 'idev-patient-registration')) . '</p><div class="idev-form idev-grid2">';
    echo '<label>' . $L(__('Document', 'idev-patient-registration')) . '<select name="doc_type"><option value="thai_id"' . selected($p['doc_type'] ?? '', 'thai_id', false) . '>' . $L(__('Thai ID card', 'idev-patient-registration')) . '</option><option value="passport"' . selected($p['doc_type'] ?? '', 'passport', false) . '>Passport</option></select></label>';
    echo '<label>' . $L(__('Thai ID number', 'idev-patient-registration')) . '<input name="cid" value="' . $v('cid') . '" inputmode="numeric"></label>';
    echo '<label>' . $L(__('Passport number', 'idev-patient-registration')) . '<input name="passport_no" value="' . $v('passport_no') . '"></label><label>' . $L(__('Nationality (3 letters, e.g. THA, DEU)', 'idev-patient-registration')) . '<input name="nationality" value="' . $v('nationality') . '" maxlength="3"></label>';
    echo '<label>' . $L(__('Title', 'idev-patient-registration')) . '<input name="prefix" value="' . $v('prefix') . '"></label><label>' . $L(__('Sex', 'idev-patient-registration')) . '<select name="sex"><option value="male"' . selected($p['sex'] ?? '', 'male', false) . '>' . $L(__('Male', 'idev-patient-registration')) . '</option><option value="female"' . selected($p['sex'] ?? '', 'female', false) . '>' . $L(__('Female', 'idev-patient-registration')) . '</option></select></label>';
    echo '<label>' . $L(__('First name', 'idev-patient-registration')) . '<input name="first_name" value="' . $v('first_name') . '"></label><label>' . $L(__('Last name', 'idev-patient-registration')) . '<input name="last_name" value="' . $v('last_name') . '"></label>';
    echo '<label>' . $L(__('First name (English)', 'idev-patient-registration')) . '<input name="first_name_en" value="' . $v('first_name_en') . '"></label><label>' . $L(__('Last name (English)', 'idev-patient-registration')) . '<input name="last_name_en" value="' . $v('last_name_en') . '"></label>';
    echo '<label>' . $L(__('Date of birth', 'idev-patient-registration')) . '<input type="date" name="birthdate" value="' . $v('birthdate') . '"></label><label>' . $L(__('Phone', 'idev-patient-registration')) . '<input name="phone" value="' . $v('phone') . '"></label>';
    echo '<label>' . $L(__('E-mail', 'idev-patient-registration')) . '<input type="email" name="email" value="' . $v('email') . '"></label><label>' . $L(__('E-mail language', 'idev-patient-registration')) . '<select name="lang"><option value="th"' . selected($p['lang'] ?? 'th', 'th', false) . '>ไทย</option><option value="en"' . selected($p['lang'] ?? 'th', 'en', false) . '>English</option></select></label>';
    echo '<label>LINE ID' . (!empty($p['line_id']) ? ' <a href="' . esc_url(idev_medreg_line_url($p['line_id'])) . '" target="_blank" rel="noopener">↗</a>' : '') . '<input name="line_id" value="' . $v('line_id') . '"></label>';
    echo '<label>WhatsApp' . (!empty($p['whatsapp']) ? ' <a href="' . esc_url(idev_medreg_wa_url($p['whatsapp'])) . '" target="_blank" rel="noopener">↗</a>' : '') . '<input name="whatsapp" value="' . $v('whatsapp') . '"></label>';
    if (!empty($p['contact_pref'])) echo '<p class="idev-wide">' . $L(__('Prefers contact by:', 'idev-patient-registration')) . ' <strong>' . esc_html(['phone' => __('Phone', 'idev-patient-registration'), 'email' => __('E-mail', 'idev-patient-registration'), 'line' => 'LINE', 'whatsapp' => 'WhatsApp'][$p['contact_pref']] ?? '') . '</strong><input type="hidden" name="contact_pref" value="' . $v('contact_pref') . '"></p>';
    echo '</div><div class="idev-form"><label>' . $L(__('Current address', 'idev-patient-registration')) . '<textarea name="address" rows="3">' . esc_textarea($p['address'] ?? '') . '</textarea></label>';
    if (!empty($p['lat']) && !empty($p['lng'])) echo '<p>GPS: <a href="' . esc_url('https://www.google.com/maps?q=' . $p['lat'] . ',' . $p['lng']) . '" target="_blank" rel="noopener">' . esc_html($p['lat'] . ', ' . $p['lng']) . ' ↗</a></p>';
    echo '<input type="hidden" name="lat" value="' . $v('lat') . '"><input type="hidden" name="lng" value="' . $v('lng') . '"></div>';
    echo '<div class="idev-form idev-grid2"><label>' . $L(__('Drug allergies', 'idev-patient-registration')) . '<input name="drug_allergy" value="' . $v('drug_allergy') . '"></label><span></span><label>' . $L(__('Emergency contact', 'idev-patient-registration')) . '<input name="emergency_name" value="' . $v('emergency_name') . '"></label><label>' . $L(__('Emergency phone', 'idev-patient-registration')) . '<input name="emergency_phone" value="' . $v('emergency_phone') . '"></label></div>';
    echo '<p><button class="button button-primary">' . $L(__('Save changes', 'idev-patient-registration')) . '</button></p></form></div>';
    echo '<div class="idev-mr-side">';
    if ($row['hn'] !== '') {
        $card = wp_nonce_url(admin_url('admin-post.php?action=idev_medreg_card&id=' . $id), 'idev_medreg_card_' . $id);
        echo '<div class="idev-card"><h2>' . $L(__('Patient card', 'idev-patient-registration')) . '</h2><img src="' . esc_url($card) . '" alt="" class="idev-mr-cardimg"><p><a class="button" href="' . esc_url(add_query_arg('download', 1, $card)) . '">' . $L(__('Download', 'idev-patient-registration')) . '</a> <a class="button" href="' . esc_url(add_query_arg(['download' => 1, 'lang' => 'en'], $card)) . '">English</a> ' . $form('resend', __('E-mail the card again', 'idev-patient-registration')) . '</p>' . ($row['emailed_at'] ? '<p class="description">' . esc_html(sprintf(__('Last sent %s', 'idev-patient-registration'), get_date_from_gmt($row['emailed_at'], 'j M Y H:i'))) . '</p>' : '') . '</div>';
    }
    echo '<div class="idev-card"><h2>' . $L(__('Document photo', 'idev-patient-registration')) . '</h2>';
    if ($row['photo']) {
        $src = wp_nonce_url(admin_url('admin-post.php?action=idev_medreg_photo&id=' . $id), 'idev_medreg_photo_' . $id);
        echo '<a href="' . esc_url($src) . '" target="_blank" rel="noopener"><img src="' . esc_url($src) . '" alt="" class="idev-mr-photo"></a><p>' . $form('delete_photo', __('Delete the photo now', 'idev-patient-registration'), 'button-link-delete', '', __('Delete the document photo? This cannot be undone.', 'idev-patient-registration')) . '</p>';
    } else echo '<p class="description">' . ($row['method'] === 'manual' ? esc_html__('No photo: the patient typed the details in.', 'idev-patient-registration') : esc_html(sprintf(__('Deleted (photos are deleted automatically %d days after registration is finished).', 'idev-patient-registration'), (int) idev_medreg_settings()['photo_days']))) . '</p>';
    echo '</div><div class="idev-card"><h2>' . $L(__('Actions', 'idev-patient-registration')) . '</h2>';
    if (in_array($row['status'], ['pending', 'error', 'rejected'], true) && !idev_medreg_connector_on()) echo '<p class="description">' . esc_html__('Save the patient in your hospital system, then type the HN below. The patient card is e-mailed automatically.', 'idev-patient-registration') . '</p>';
    elseif (in_array($row['status'], ['pending', 'error', 'rejected'], true)) echo '<p>' . $form('approve', $row['status'] === 'error' ? __('↻ Send to HOSxP again', 'idev-patient-registration') : __('✓ Approve and send to HOSxP', 'idev-patient-registration'), 'button button-primary') . '</p><p class="description">' . esc_html__('The connector inside the hospital saves it in HOSxP (an existing patient keeps their HN) and the patient card is e-mailed automatically.', 'idev-patient-registration') . '</p>';
    if ($row['status'] === 'approved') echo '<p>' . $form('unapprove', __('Cancel approval (back to review)', 'idev-patient-registration')) . '</p>';
    if ($row['status'] !== 'synced') {
        echo '<hr><p><strong>' . esc_html__('Or enter the HN yourself', 'idev-patient-registration') . '</strong> (' . esc_html__('saved in HOSxP by hand', 'idev-patient-registration') . ')</p>' . $form('manual_hn', __('Save HN and send the card', 'idev-patient-registration'), 'button', '<input name="hn" placeholder="HN" required style="width:140px"> ');
        if ($row['status'] !== 'rejected') echo '<hr>' . $form('reject', __('Do not approve', 'idev-patient-registration'), 'button', '<input name="reason" placeholder="' . esc_attr__('Reason (not sent to the patient)', 'idev-patient-registration') . '" style="width:220px"> ');
    }
    echo '<hr>' . $form('delete', __('Delete this registration', 'idev-patient-registration'), 'button-link-delete', '', __('Delete this registration and its photo? This cannot be undone. Nothing in HOSxP is changed.', 'idev-patient-registration')) . '</div>';
    echo '<div class="idev-card"><h2>' . $L(__('History', 'idev-patient-registration')) . '</h2><ul class="idev-mr-log">';
    $consent = $p['consent'] ?? [];
    if ($consent) echo '<li>' . esc_html(sprintf(__('PDPA/GDPR consent version %1$s given %2$s', 'idev-patient-registration'), $consent['version'] ?? '', wp_date('j M Y H:i', strtotime($consent['at'] ?? 'now')))) . '</li>';
    foreach (array_reverse($p['_log'] ?? []) as $e) echo '<li>' . esc_html(wp_date('j M Y H:i', strtotime($e[0]))) . ' · ' . esc_html($e[1]) . ' · ' . esc_html($e[2]) . '</li>';
    echo '</ul></div></div></div></div>';
    $person = $p; // viewing personal data is logged
    idev_medreg_log($person, 'เปิดดูข้อมูล');
    idev_medreg_save_person($id, $person, [], false);
}

add_action('admin_post_idev_medreg_photo', function () {
    $id = (int) ($_GET['id'] ?? 0);
    if (!current_user_can('idev_medreg') || !wp_verify_nonce(sanitize_key($_GET['_wpnonce'] ?? ''), 'idev_medreg_photo_' . $id)) wp_die('Forbidden', 403);
    $row = idev_medreg_get($id);
    $bytes = $row ? idev_medreg_photo_bytes($row['photo']) : null;
    if (!$bytes) wp_die('Not found', 404);
    nocache_headers(); header('Content-Type: image/jpeg'); header('X-Content-Type-Options: nosniff'); header('Content-Length: ' . strlen($bytes));
    echo $bytes; // phpcs:ignore
    exit;
});

add_action('admin_post_idev_medreg', function () {
    $id = (int) ($_POST['id'] ?? 0);
    if (!current_user_can('idev_medreg') || !check_admin_referer('idev_medreg_' . $id)) wp_die('Forbidden', 403);
    global $wpdb;
    $row = idev_medreg_get($id);
    if (!$row || !$row['readable']) wp_die('Not found');
    $person = $row['person'];
    $do = sanitize_key($_POST['do'] ?? '');
    $back = ['page' => 'idev-medreg', 'id' => $id, 'done' => 1];
    switch ($do) {
        case 'save':
            $in = $_POST; $in['lang'] = $_POST['lang'] ?? 'th';
            [$clean] = idev_medreg_clean($in, true);
            foreach ($clean as $k => $val) if ($k !== 'method') $person[$k] = $val;
            idev_medreg_log($person, 'แก้ไขข้อมูล');
            $number = $person['doc_type'] === 'thai_id' ? $person['cid'] : $person['passport_no'];
            idev_medreg_save_person($id, $person, ['doc_type' => $person['doc_type'], 'search_key' => idev_medreg_search_key($person['doc_type'], $number)]);
            break;
        case 'approve': if (!idev_medreg_connector_on()) break; idev_medreg_log($person, 'อนุมัติ ส่งเข้า HOSxP'); idev_medreg_save_person($id, $person, ['status' => 'approved', 'message' => '']); break;
        case 'unapprove': idev_medreg_log($person, 'ยกเลิกการอนุมัติ'); idev_medreg_save_person($id, $person, ['status' => 'pending']); break;
        case 'reject':
            $reason = sanitize_text_field(wp_unslash($_POST['reason'] ?? ''));
            idev_medreg_log($person, 'ไม่อนุมัติ' . ($reason ? ': ' . $reason : ''));
            idev_medreg_save_person($id, $person, ['status' => 'rejected', 'message' => trim(__('Not approved', 'idev-patient-registration') . ($reason ? ': ' . $reason : ''))]);
            break;
        case 'manual_hn':
            $hn = preg_replace('/[^0-9A-Za-z-]/', '', wp_unslash($_POST['hn'] ?? ''));
            if ($hn === '') break;
            idev_medreg_log($person, 'ใส่ HN เอง ' . $hn);
            idev_medreg_save_person($id, $person, ['status' => 'synced', 'hn' => $hn, 'message' => __('HN entered by staff', 'idev-patient-registration'), 'synced_at' => current_time('mysql', true)]);
            do_action('idev_medreg_hn_issued', $id, $hn, $person);
            $back[idev_medreg_mail_card($id) ? 'mailed' : 'mailfail'] = 1;
            break;
        case 'resend': $back[idev_medreg_mail_card($id) ? 'mailed' : 'mailfail'] = 1; break;
        case 'delete_photo': idev_medreg_delete_photo($row); idev_medreg_log($person, 'ลบรูปเอกสาร'); idev_medreg_save_person($id, $person); break;
        case 'delete':
            idev_medreg_delete_photo($row);
            $wpdb->delete(idev_medreg_table(), ['id' => $id]);
            wp_safe_redirect(admin_url('admin.php?page=idev-medreg&deleted=1'));
            exit;
    }
    wp_safe_redirect(add_query_arg($back, admin_url('admin.php')));
    exit;
});
