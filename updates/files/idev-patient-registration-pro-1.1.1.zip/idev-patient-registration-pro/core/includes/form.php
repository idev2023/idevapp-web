<?php
/** Public registration form: block "Patient registration" and shortcode [idev_patient_registration]. */
defined('ABSPATH') || exit;

add_action('init', function () {
    wp_register_style('idev-medreg', IDEV_MEDREG_URL . 'assets/form.css', [], IDEV_MEDREG_VERSION);
    wp_register_script('idev-medreg-parse', IDEV_MEDREG_URL . 'assets/idparse.js', [], IDEV_MEDREG_VERSION, true);
    wp_register_script('idev-medreg-ocr', IDEV_MEDREG_URL . 'assets/ocr.js', ['idev-medreg-parse'], IDEV_MEDREG_VERSION, true);
    wp_register_script('idev-medreg', IDEV_MEDREG_URL . 'assets/form.js', ['idev-medreg-ocr'], IDEV_MEDREG_VERSION, true);
    idev_register_block('idev/patient-registration', __('Patient registration', 'idev-patient-registration'), 'id-alt', __('New patient registration form (consent, document photo, details, contact).', 'idev-patient-registration'), [], function () { return idev_patient_registration_form(); });
});
add_shortcode('idev_patient_registration', function () { return idev_patient_registration_form(); });
// Pages built for Andaman Hub keep working.
add_action('init', function () { if (!shortcode_exists('andaman_registration')) add_shortcode('andaman_registration', function () { return idev_patient_registration_form(); }); }, 20);

function idev_medreg_js_strings() {
    return [
        'required' => __('Please fill this in', 'idev-patient-registration'),
        'consentRequired' => __('Please read and accept to continue', 'idev-patient-registration'),
        'chooseMethod' => __('Please choose how you want to register', 'idev-patient-registration'),
        'photoRequired' => __('Please take a photo of your document', 'idev-patient-registration'),
        'invalidCid' => __('This Thai ID number is not valid', 'idev-patient-registration'),
        'invalidEmail' => __('Please check the e-mail address', 'idev-patient-registration'),
        'reading' => __('Reading the document on your phone…', 'idev-patient-registration'),
        'readOk' => __('Done — please check the details on the next step.', 'idev-patient-registration'),
        'readPartial' => __('Some details were read — please check and fill in the rest.', 'idev-patient-registration'),
        'readFail' => __('Could not read the document. You can take the photo again, or type the details in.', 'idev-patient-registration'),
        'camStarting' => __('Starting camera…', 'idev-patient-registration'),
        'camHintId' => __('Place the front of the ID card inside the frame', 'idev-patient-registration'),
        'camHintPassport' => __('Place the passport photo page inside the frame — the two lines of <<< must be visible', 'idev-patient-registration'),
        'camFocus' => __('Hold still… focusing', 'idev-patient-registration'),
        'camSharp' => __('Sharp — taking the photo', 'idev-patient-registration'),
        'camBlocked' => __('The camera is not available. Take a photo with your camera app instead:', 'idev-patient-registration'),
        'camTapFocus' => __('Tap the document to focus', 'idev-patient-registration'),
        'retake' => __('Take again', 'idev-patient-registration'),
        'gpsOk' => __('Location added', 'idev-patient-registration'),
        'gpsFail' => __('Could not get your location — please type the address', 'idev-patient-registration'),
        'gpsClear' => __('Remove', 'idev-patient-registration'),
        'sending' => __('Sending…', 'idev-patient-registration'),
        'errorGeneric' => __('Something went wrong. Please try again or call us.', 'idev-patient-registration'),
        'doneText' => __('Reference {ref}. We will check your details and e-mail your patient card to {email} when your hospital number (HN) is ready.', 'idev-patient-registration'),
        'doneTextNoEmail' => __('Reference {ref}. Please keep this number. Our staff will contact you when your hospital number (HN) is ready.', 'idev-patient-registration'),
        'docThai' => __('Thai ID card', 'idev-patient-registration'), 'docPassport' => __('Passport', 'idev-patient-registration'),
        'typed' => __('Typed in', 'idev-patient-registration'),
        'labels' => [
            'method' => __('How', 'idev-patient-registration'), 'cid' => __('Thai ID number', 'idev-patient-registration'), 'passport_no' => __('Passport number', 'idev-patient-registration'),
            'nationality' => __('Nationality', 'idev-patient-registration'), 'name' => __('Name', 'idev-patient-registration'), 'name_en' => __('Name in English', 'idev-patient-registration'),
            'sex' => __('Sex', 'idev-patient-registration'), 'male' => __('Male', 'idev-patient-registration'), 'female' => __('Female', 'idev-patient-registration'),
            'birthdate' => __('Date of birth', 'idev-patient-registration'), 'phone' => __('Phone', 'idev-patient-registration'), 'email' => __('E-mail', 'idev-patient-registration'),
            'line_id' => 'LINE', 'whatsapp' => 'WhatsApp', 'contact_pref' => __('Contact me by', 'idev-patient-registration'),
            'address' => __('Address', 'idev-patient-registration'), 'location' => __('Location', 'idev-patient-registration'), 'allergy' => __('Drug allergies', 'idev-patient-registration'),
            'emergency' => __('Emergency contact', 'idev-patient-registration'), 'photo' => __('Document photo', 'idev-patient-registration'),
        ],
    ];
}

function idev_patient_registration_form() {
    $s = idev_medreg_settings();
    $lang = idev_lang();
    $en = $lang === 'en';
    wp_enqueue_style('idev-medreg');
    if ($s['enabled'] !== '1') return '<div class="idev-mr-form"><p class="idev-mr-closed">' . esc_html__('Online registration is closed at the moment. Please register at the hospital.', 'idev-patient-registration') . '</p></div>';
    wp_enqueue_script('idev-medreg');
    $methods = idev_medreg_methods();
    $base = untrailingslashit((string) $s['ocr_base']);
    /** Filter: reading engine (tesseract.js 5) when the site does not host its own copy. */
    $ocr = apply_filters('idev_medreg_ocr_engine', $base ? ['script' => $base . '/tesseract.min.js', 'workerPath' => $base . '/worker.min.js', 'corePath' => $base, 'langPath' => $base] : []);
    $config = ['rest' => esc_url_raw(rest_url('idev-medreg/v1/register')), 'lang' => $lang, 'ocr' => $s['ocr'] === '1' && !empty($ocr['script']), 'auto' => $s['auto_capture'] === '1', 'engine' => $ocr, 'requireEmail' => $s['require_email'] === '1', 'address' => $s['field_address'], 't' => idev_medreg_js_strings()];
    $privacy = $s['privacy_url'] ?: (get_privacy_policy_url() ?: '');
    $field = function ($name, $label, $type = 'text', $attrs = '', $hint = '', $req = true) {
        return '<label class="idev-mr-field" data-field="' . esc_attr($name) . '"><span>' . esc_html($label) . ($req ? '' : ' <i>(' . esc_html__('optional', 'idev-patient-registration') . ')</i>') . '</span><input type="' . esc_attr($type) . '" name="' . esc_attr($name) . '" ' . $attrs . '>' . ($hint ? '<small>' . esc_html($hint) . '</small>' : '') . '<em class="idev-mr-error" hidden></em></label>';
    };
    $prefixes = $en ? ['Mr', 'Mrs', 'Ms', 'Miss', 'Master', 'นาย', 'นาง', 'นางสาว'] : ['นาย', 'นาง', 'นางสาว', 'เด็กชาย', 'เด็กหญิง', 'Mr', 'Mrs', 'Ms', 'Miss'];
    $countries = ['THA' => 'Thailand', 'GBR' => 'United Kingdom', 'DEU' => 'Germany', 'RUS' => 'Russia', 'CHN' => 'China', 'USA' => 'United States', 'FRA' => 'France', 'SWE' => 'Sweden', 'NLD' => 'Netherlands', 'AUS' => 'Australia', 'IND' => 'India', 'ITA' => 'Italy', 'CHE' => 'Switzerland', 'AUT' => 'Austria', 'DNK' => 'Denmark', 'NOR' => 'Norway', 'FIN' => 'Finland', 'BEL' => 'Belgium', 'ESP' => 'Spain', 'POL' => 'Poland', 'ISR' => 'Israel', 'JPN' => 'Japan', 'KOR' => 'South Korea', 'SGP' => 'Singapore', 'MYS' => 'Malaysia', 'MMR' => 'Myanmar', 'KHM' => 'Cambodia', 'LAO' => 'Laos', 'VNM' => 'Vietnam', 'CAN' => 'Canada', 'NZL' => 'New Zealand', 'IRL' => 'Ireland', 'CZE' => 'Czechia', 'KAZ' => 'Kazakhstan', 'UKR' => 'Ukraine', 'ARE' => 'United Arab Emirates', 'SAU' => 'Saudi Arabia', 'PHL' => 'Philippines', 'IDN' => 'Indonesia', 'TWN' => 'Taiwan', 'HKG' => 'Hong Kong', 'BRA' => 'Brazil', 'ZAF' => 'South Africa'];
    $steps = [__('Consent', 'idev-patient-registration'), __('Document', 'idev-patient-registration'), __('Your details', 'idev-patient-registration'), __('Contact', 'idev-patient-registration'), __('Check & send', 'idev-patient-registration')];
    $mcards = [
        'thai_id' => ['idcard', __('Photo of Thai ID card', 'idev-patient-registration'), __('For Thai citizens — details are read from the card', 'idev-patient-registration')],
        'passport' => ['passport', __('Photo of passport', 'idev-patient-registration'), __('Thai or foreign passport — read from the machine-readable lines', 'idev-patient-registration')],
        'manual' => ['keyboard', __('Type it in myself', 'idev-patient-registration'), __('No photo needed — bring your ID card or passport on your first visit', 'idev-patient-registration')],
    ];
    ob_start(); ?>
<div class="idev-mr-form" style="--idev-mr:<?php echo esc_attr($s['accent']); ?>" data-idev-mr="<?php echo esc_attr(wp_json_encode($config, JSON_UNESCAPED_UNICODE)); ?>">
  <ol class="idev-mr-steps" aria-hidden="true"><?php foreach ($steps as $i => $st) echo '<li' . ($i === 0 ? ' class="active"' : '') . '><b>' . ($i + 1) . '</b><span>' . esc_html($st) . '</span></li>'; ?></ol>
  <form novalidate>
    <input type="text" name="website" class="idev-mr-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
    <input type="hidden" name="lang" value="<?php echo esc_attr($lang); ?>">
    <input type="hidden" name="doc_type" value="<?php echo $en ? 'passport' : 'thai_id'; ?>">
    <input type="hidden" name="method" value="">
    <section class="idev-mr-step is-active" data-step="0">
      <h2><?php esc_html_e('Your personal data', 'idev-patient-registration'); ?></h2>
      <div class="idev-mr-consent" tabindex="0"><?php echo wpautop(esc_html(idev_medreg_consent_text($en))); ?>
        <?php if ($s['dpo_contact']) echo '<p><strong>' . esc_html__('Data Protection Officer', 'idev-patient-registration') . ':</strong> ' . nl2br(esc_html($s['dpo_contact'])) . '</p>'; ?>
        <?php if ($privacy) echo '<p><a href="' . esc_url($privacy) . '" target="_blank" rel="noopener">' . esc_html__('Privacy policy', 'idev-patient-registration') . ' ↗</a></p>'; ?>
      </div>
      <label class="idev-mr-check"><input type="checkbox" name="consent_pdpa" value="1"> <span><?php esc_html_e('I have read this and agree that my personal and health data is used as described (PDPA / GDPR).', 'idev-patient-registration'); ?></span></label>
      <em class="idev-mr-error" data-error="consent" hidden></em>
    </section>
    <section class="idev-mr-step" data-step="1" hidden>
      <h2><?php esc_html_e('How would you like to register?', 'idev-patient-registration'); ?></h2>
      <div class="idev-mr-methods" role="radiogroup">
        <?php foreach ($methods as $m) echo '<label class="idev-mr-method"><input type="radio" name="method_choice" value="' . esc_attr($m) . '"><span class="idev-mr-method-icon" aria-hidden="true">' . idev_icon($mcards[$m][0]) . '</span><span><strong>' . esc_html($mcards[$m][1]) . '</strong><small>' . esc_html($mcards[$m][2]) . '</small></span></label>'; ?>
      </div>
      <em class="idev-mr-error" data-error="method" hidden></em>
      <div class="idev-mr-manualdoc" hidden>
        <p><?php esc_html_e('Which document do you have?', 'idev-patient-registration'); ?></p>
        <div class="idev-mr-seg"><label><input type="radio" name="manual_doc" value="thai_id"<?php checked(!$en); ?>> <?php esc_html_e('Thai ID card', 'idev-patient-registration'); ?></label><label><input type="radio" name="manual_doc" value="passport"<?php checked($en); ?>> <?php esc_html_e('Passport', 'idev-patient-registration'); ?></label></div>
      </div>
      <div class="idev-mr-capture" hidden>
        <div class="idev-mr-cam" hidden>
          <video playsinline muted autoplay></video>
          <div class="idev-mr-guide" aria-hidden="true"><i></i><i></i><i></i><i></i><span class="idev-mr-mrz"></span></div>
          <p class="idev-mr-cam-hint" role="status" aria-live="polite"></p>
          <div class="idev-mr-meter" aria-hidden="true"><b></b></div>
          <div class="idev-mr-cam-bar">
            <button type="button" class="idev-mr-icon" data-mr="torch" hidden aria-label="<?php esc_attr_e('Light', 'idev-patient-registration'); ?>"><?php echo idev_icon('light'); ?></button>
            <button type="button" class="idev-mr-shutter" data-mr="shoot" aria-label="<?php esc_attr_e('Take photo', 'idev-patient-registration'); ?>"></button>
            <button type="button" class="idev-mr-icon" data-mr="close" aria-label="<?php esc_attr_e('Close camera', 'idev-patient-registration'); ?>">✕</button>
          </div>
        </div>
        <div class="idev-mr-photo">
          <button type="button" class="idev-mr-btn is-primary" data-mr="camera"><?php echo idev_icon('camera'); ?> <?php esc_html_e('Open camera', 'idev-patient-registration'); ?></button>
          <label class="idev-mr-btn is-ghost"><?php echo idev_icon('image'); ?> <?php esc_html_e('Choose a photo', 'idev-patient-registration'); ?><input type="file" accept="image/*" hidden data-mr="file"></label>
          <p class="idev-mr-tip"><?php esc_html_e('Tips: good light, no glare, the whole document inside the frame, hold the phone straight above it.', 'idev-patient-registration'); ?></p>
          <p class="idev-mr-fallback" hidden></p>
          <img class="idev-mr-preview" alt="" hidden>
          <div class="idev-mr-ocr" role="status" aria-live="polite" hidden><span class="idev-mr-bar"><i></i></span><span class="idev-mr-ocr-text"></span></div>
          <em class="idev-mr-error" data-error="photo" hidden></em>
        </div>
      </div>
    </section>
    <section class="idev-mr-step" data-step="2" hidden>
      <h2><?php esc_html_e('Your details', 'idev-patient-registration'); ?></h2>
      <p class="idev-mr-note" data-ocr-note hidden><?php esc_html_e('Filled in from your document. Please check every field.', 'idev-patient-registration'); ?></p>
      <div class="idev-mr-grid">
        <div class="idev-mr-doc" data-doc="thai_id"><?php echo $field('cid', __('Thai ID number (13 digits)', 'idev-patient-registration'), 'text', 'inputmode="numeric" autocomplete="off" maxlength="17"'); ?></div>
        <div class="idev-mr-doc" data-doc="passport"><?php echo $field('passport_no', __('Passport number', 'idev-patient-registration'), 'text', 'autocomplete="off" autocapitalize="characters" maxlength="20"'); ?></div>
        <div class="idev-mr-doc" data-doc="passport"><?php echo $field('nationality', __('Nationality (e.g. THA, GBR, DEU)', 'idev-patient-registration'), 'text', 'list="idev-mr-countries" maxlength="3" autocapitalize="characters"'); ?></div>
        <?php echo $field('prefix', __('Title', 'idev-patient-registration'), 'text', 'list="idev-mr-prefixes"', '', false); ?>
        <fieldset class="idev-mr-field idev-mr-sex" data-field="sex"><span><?php esc_html_e('Sex', 'idev-patient-registration'); ?></span><div class="idev-mr-seg"><label><input type="radio" name="sex" value="male"> <?php esc_html_e('Male', 'idev-patient-registration'); ?></label><label><input type="radio" name="sex" value="female"> <?php esc_html_e('Female', 'idev-patient-registration'); ?></label></div><em class="idev-mr-error" hidden></em></fieldset>
        <?php echo $field('first_name', __('First name', 'idev-patient-registration'), 'text', 'autocomplete="given-name"') . $field('last_name', __('Last name', 'idev-patient-registration'), 'text', 'autocomplete="family-name"'); ?>
        <?php if ($s['field_name_en'] !== 'hidden') echo $field('first_name_en', __('First name in English', 'idev-patient-registration'), 'text', '', '', false) . $field('last_name_en', __('Last name in English', 'idev-patient-registration'), 'text', '', '', false); ?>
        <?php echo $field('birthdate', __('Date of birth', 'idev-patient-registration'), 'date', 'max="' . esc_attr(idev_today()) . '" min="1900-01-01" autocomplete="bday"'); ?>
      </div>
      <datalist id="idev-mr-prefixes"><?php foreach ($prefixes as $p) echo '<option value="' . esc_attr($p) . '">'; ?></datalist>
      <datalist id="idev-mr-countries"><?php foreach ($countries as $code => $name) echo '<option value="' . esc_attr($code) . '">' . esc_html($name) . '</option>'; ?></datalist>
    </section>
    <section class="idev-mr-step" data-step="3" hidden>
      <h2><?php esc_html_e('How can we contact you?', 'idev-patient-registration'); ?></h2>
      <div class="idev-mr-grid">
        <?php echo $field('phone', __('Mobile phone', 'idev-patient-registration'), 'tel', 'autocomplete="tel" inputmode="tel"') . $field('email', __('E-mail (we send your patient card here)', 'idev-patient-registration'), 'email', 'autocomplete="email"', '', $s['require_email'] === '1'); ?>
        <?php if ($s['field_line'] !== 'hidden') echo $field('line_id', __('LINE ID', 'idev-patient-registration'), 'text', 'autocomplete="off" autocapitalize="none"', __('As shown in LINE → Settings → Profile → ID', 'idev-patient-registration'), false); ?>
        <?php if ($s['field_whatsapp'] !== 'hidden') echo '<div>' . $field('whatsapp', __('WhatsApp number', 'idev-patient-registration'), 'tel', 'inputmode="tel" placeholder="+66…"', __('With country code, e.g. +44 7700 900123', 'idev-patient-registration'), false) . '<label class="idev-mr-check is-small"><input type="checkbox" data-mr="wa-same"> ' . esc_html__('Same as my phone', 'idev-patient-registration') . '</label></div>'; ?>
      </div>
      <?php if ($s['field_contact_pref'] === '1') : ?>
      <fieldset class="idev-mr-field" data-field="contact_pref"><span><?php esc_html_e('Best way to contact you', 'idev-patient-registration'); ?></span><div class="idev-mr-seg is-wrap">
        <label><input type="radio" name="contact_pref" value="phone"> <?php echo idev_icon('phone'); ?> <?php esc_html_e('Phone', 'idev-patient-registration'); ?></label>
        <label><input type="radio" name="contact_pref" value="email"> <?php echo idev_icon('mail'); ?> <?php esc_html_e('E-mail', 'idev-patient-registration'); ?></label>
        <?php if ($s['field_line'] !== 'hidden') echo '<label><input type="radio" name="contact_pref" value="line"> ' . idev_icon('chat') . ' LINE</label>'; ?>
        <?php if ($s['field_whatsapp'] !== 'hidden') echo '<label><input type="radio" name="contact_pref" value="whatsapp"> ' . idev_icon('whatsapp') . ' WhatsApp</label>'; ?>
      </div></fieldset>
      <?php endif; ?>
      <?php if ($s['field_address'] !== 'hidden') : ?>
      <label class="idev-mr-field" data-field="address"><span><?php esc_html_e('Current address', 'idev-patient-registration'); ?><?php if ($s['field_address'] !== 'required') echo ' <i>(' . esc_html__('optional', 'idev-patient-registration') . ')</i>'; ?></span><textarea name="address" rows="3" autocomplete="street-address"></textarea><em class="idev-mr-error" hidden></em></label>
      <?php endif; ?>
      <?php if ($s['field_gps'] === '1') : ?>
      <div class="idev-mr-gps"><button type="button" class="idev-mr-btn is-ghost" data-mr="gps"><?php echo idev_icon('pin'); ?> <?php esc_html_e('Use my location', 'idev-patient-registration'); ?></button><span class="idev-mr-gps-status"></span><input type="hidden" name="lat"><input type="hidden" name="lng"><small><?php esc_html_e('Optional — helps the ambulance or home visit team find you.', 'idev-patient-registration'); ?></small></div>
      <?php endif; ?>
      <?php if ($s['field_allergy'] !== 'hidden') echo $field('drug_allergy', __('Drug allergies', 'idev-patient-registration'), 'text', '', __('e.g. penicillin — leave empty if none or not sure', 'idev-patient-registration'), false); ?>
      <?php if ($s['field_emergency'] !== 'hidden') echo '<div class="idev-mr-grid">' . $field('emergency_name', __('Emergency contact name', 'idev-patient-registration'), 'text', '', '', false) . $field('emergency_phone', __('Emergency contact phone', 'idev-patient-registration'), 'tel', 'inputmode="tel"', '', false) . '</div>'; ?>
    </section>
    <section class="idev-mr-step" data-step="4" hidden>
      <h2><?php esc_html_e('Please check before sending', 'idev-patient-registration'); ?></h2>
      <dl class="idev-mr-review"></dl>
      <em class="idev-mr-error" data-error="form" hidden></em>
    </section>
    <div class="idev-mr-nav">
      <button type="button" class="idev-mr-btn is-ghost" data-mr="back" hidden>← <?php esc_html_e('Back', 'idev-patient-registration'); ?></button>
      <button type="button" class="idev-mr-btn is-primary" data-mr="next"><?php esc_html_e('Next', 'idev-patient-registration'); ?> →</button>
      <button type="submit" class="idev-mr-btn is-primary" data-mr="submit" hidden><?php esc_html_e('Send registration', 'idev-patient-registration'); ?></button>
    </div>
  </form>
  <div class="idev-mr-done" hidden tabindex="-1"><div class="idev-mr-done-icon">✓</div><h2><?php esc_html_e('Registration sent', 'idev-patient-registration'); ?></h2><p class="idev-mr-done-text"></p></div>
</div>
<?php
    return ob_get_clean();
}
