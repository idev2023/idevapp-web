<?php
/**
 * Patient card: designed in Settings → Patient card, drawn as a PNG (1012 × 638 px, credit-card shape)
 * with a QR code and/or barcode, sent by e-mail and printable from the back office.
 */
defined('ABSPATH') || exit;

function idev_medreg_card_defaults() {
    return [
        'layout' => 'classic', 'bg_type' => 'gradient', 'bg1' => '#169c91', 'bg2' => '#0e3540', 'bg_image' => 0, 'overlay' => '45',
        'text' => '#ffffff', 'muted' => '#c8ece7', 'accent' => '#ffd166', 'logo' => 0,
        'title' => 'บัตรประจำตัวผู้ป่วย', 'title_en' => 'PATIENT CARD',
        'show_name_en' => '1', 'show_dob' => '1', 'show_id' => '1', 'show_issued' => '1', 'show_org' => '1',
        'code' => 'qr', 'qr_text' => '{hn}', 'note' => 'กรุณาแสดงบัตรนี้ทุกครั้งที่มารับบริการ', 'note_en' => 'Please show this card at every visit',
    ];
}
/** Card styles. Filter: add-ons add styles and draw them with idev_medreg_card_draw. */
function idev_medreg_card_layouts() {
    return apply_filters('idev_medreg_card_layouts', ['classic' => __('Full colour', 'idev-patient-registration'), 'band' => __('White with colour header', 'idev-patient-registration'), 'light' => __('Light (prints well)', 'idev-patient-registration')]);
}
function idev_medreg_card_design($override = null) {
    $d = get_option('idev_medreg_card', []);
    $d = array_merge(idev_medreg_card_defaults(), is_array($d) ? $d : []);
    if (is_array($override)) $d = array_merge($d, idev_medreg_card_sanitize($override, $d));
    return $d;
}
function idev_medreg_card_sanitize($in, $old) {
    $out = $old;
    foreach (['bg1', 'bg2', 'text', 'muted', 'accent'] as $k) if (isset($in[$k])) $out[$k] = sanitize_hex_color($in[$k]) ?: $old[$k];
    foreach (['bg_image', 'logo'] as $k) if (isset($in[$k])) $out[$k] = (int) $in[$k];
    if (isset($in['overlay'])) $out['overlay'] = (string) max(0, min(90, (int) $in['overlay']));
    if (isset($in['layout'])) $out['layout'] = array_key_exists($in['layout'], idev_medreg_card_layouts()) ? $in['layout'] : 'classic';
    if (isset($in['bg_type'])) $out['bg_type'] = in_array($in['bg_type'], ['gradient', 'solid', 'image'], true) ? $in['bg_type'] : 'gradient';
    if (isset($in['code'])) $out['code'] = in_array($in['code'], ['qr', 'barcode', 'both', 'none'], true) ? $in['code'] : 'qr';
    foreach (['title', 'title_en', 'note', 'note_en', 'qr_text'] as $k) if (isset($in[$k])) $out[$k] = mb_substr(sanitize_text_field(wp_unslash($in[$k])), 0, 160);
    foreach (['show_name_en', 'show_dob', 'show_id', 'show_issued', 'show_org'] as $k) $out[$k] = empty($in[$k]) ? '0' : '1';
    return $out;
}

/* ---------- drawing helpers ---------- */

function idev_medreg_font($weight = 'Regular') { return IDEV_MEDREG_DIR . 'fonts/Sarabun-' . $weight . '.ttf'; }
function idev_medreg_rgb($im, $hex, $alpha = 0) {
    $hex = ltrim((string) $hex, '#');
    if (strlen($hex) === 3) $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    $n = hexdec(str_pad(substr($hex, 0, 6), 6, '0'));
    return imagecolorallocatealpha($im, ($n >> 16) & 255, ($n >> 8) & 255, $n & 255, $alpha);
}
function idev_medreg_text_w($size, $font, $text) { $b = imagettfbbox($size, 0, $font, $text); return abs($b[2] - $b[0]); }
/** Draws text, shrinking it until it fits $maxw. Returns the size used. */
function idev_medreg_text($im, $size, $x, $y, $color, $font, $text, $maxw = 0, $align = 'left') {
    $text = (string) $text;
    if ($text === '') return $size;
    while ($maxw && $size > 9 && idev_medreg_text_w($size, $font, $text) > $maxw) $size -= 1;
    if ($align !== 'left') { $w = idev_medreg_text_w($size, $font, $text); $x = $align === 'right' ? $x - $w : $x - $w / 2; }
    idev_medreg_thai_text($im, $size, (int) $x, (int) $y, $color, $font, $text);
    return $size;
}
/**
 * GD draws fonts without OpenType mark positioning, so a Thai tone mark after an upper vowel (ที่, นี้, สั้น, น้ำ)
 * lands on top of the vowel. Draw those tone marks separately, raised above the vowel.
 */
function idev_medreg_thai_text($im, $size, $x, $y, $color, $font, $text) {
    $chars = preg_split('//u', (string) $text, -1, PREG_SPLIT_NO_EMPTY);
    $upper = ['ั', 'ิ', 'ี', 'ึ', 'ื', '็', 'ํ'];
    $tones = ['่', '้', '๊', '๋', '์'];
    $plain = ''; $raised = [];
    foreach ($chars as $i => $c) {
        $prev = $chars[$i - 1] ?? ''; $next = $chars[$i + 1] ?? '';
        if (in_array($c, $tones, true) && (in_array($prev, $upper, true) || $next === 'ำ')) { $raised[] = [$plain, $c]; continue; }
        $plain .= $c;
    }
    imagettftext($im, $size, 0, $x, $y, $color, $font, $plain);
    if (!$raised) return;
    $ref = imagettfbbox($size, 0, $font, 'H');
    foreach ($raised as [$prefix, $mark]) {
        $b = imagettfbbox($size, 0, $font, $prefix . 'H');
        $advance = $b[2] - $ref[2];
        imagettftext($im, $size, 0, (int) round($x + $advance), (int) round($y - $size * 0.30), $color, $font, $mark);
    }
}
function idev_medreg_load_image($attachment_id) {
    $path = $attachment_id ? get_attached_file((int) $attachment_id) : '';
    if (!$path || !is_file($path) || filesize($path) > 15 * 1048576) return null;
    $im = @imagecreatefromstring(file_get_contents($path));
    if ($im) imagealphablending($im, true);
    return $im ?: null;
}
function idev_medreg_cover($dst, $src, $x, $y, $w, $h) {
    $sw = imagesx($src); $sh = imagesy($src);
    $scale = max($w / $sw, $h / $sh);
    $cw = $w / $scale; $ch = $h / $scale;
    imagecopyresampled($dst, $src, $x, $y, (int) (($sw - $cw) / 2), (int) (($sh - $ch) / 2), $w, $h, (int) $cw, (int) $ch);
}
function idev_medreg_contain($dst, $src, $x, $y, $maxw, $maxh, $align = 'left') {
    $sw = imagesx($src); $sh = imagesy($src);
    $scale = min($maxw / $sw, $maxh / $sh);
    $w = (int) ($sw * $scale); $h = (int) ($sh * $scale);
    $dx = $align === 'right' ? $x + $maxw - $w : $x;
    imagecopyresampled($dst, $src, $dx, $y + (int) (($maxh - $h) / 2), 0, 0, $w, $h, $sw, $sh);
    return [$w, $h];
}
function idev_medreg_round($im, $x1, $y1, $x2, $y2, $r, $color) {
    imagefilledrectangle($im, $x1 + $r, $y1, $x2 - $r, $y2, $color);
    imagefilledrectangle($im, $x1, $y1 + $r, $x2, $y2 - $r, $color);
    foreach ([[$x1 + $r, $y1 + $r], [$x2 - $r, $y1 + $r], [$x1 + $r, $y2 - $r], [$x2 - $r, $y2 - $r]] as [$cx, $cy]) imagefilledellipse($im, $cx, $cy, $r * 2, $r * 2, $color);
}
function idev_medreg_mask_id($v) { $v = (string) $v; return strlen($v) > 4 ? str_repeat('•', min(9, strlen($v) - 4)) . substr($v, -4) : $v; }

/** Text placed in the QR code; never personal data unless the template asks for it. */
function idev_medreg_qr_value($d, $row) {
    $p = $row['person'] ?? [];
    $vars = ['{hn}' => $row['hn'], '{ref}' => $row['ref'] ?? '', '{name}' => idev_medreg_name($p), '{name_en}' => idev_medreg_name_en($p), '{dob}' => $p['birthdate'] ?? '', '{site}' => home_url('/')];
    $v = trim(strtr($d['qr_text'] ?: '{hn}', $vars));
    return $v !== '' ? $v : $row['hn'];
}

/**
 * PNG bytes of a patient card. $row = record (with person + hn); $design overrides the saved design (preview).
 */
function idev_medreg_card_png($row, $en = false, $design = null) {
    if (!function_exists('imagettftext')) return '';
    idev_load_qr();
    $d = idev_medreg_card_design($design);
    /** Filter: PNG of a card style drawn by an add-on (null = built-in styles). */
    $custom = apply_filters('idev_medreg_card_draw', null, $row, $en, $d);
    if (is_string($custom) && $custom !== '') return $custom;
    if (!in_array($d['layout'], ['classic', 'band', 'light'], true)) $d['layout'] = 'classic';
    $p = $row['person'] ?? [];
    $W = 1012; $H = 638; $pad = 54;
    $im = imagecreatetruecolor($W, $H);
    imagealphablending($im, true); imagesavealpha($im, true);
    $light = $d['layout'] === 'light';
    $band = $d['layout'] === 'band';
    $white = idev_medreg_rgb($im, '#ffffff');
    // background
    if ($light || $band) imagefilledrectangle($im, 0, 0, $W, $H, $white);
    $bgH = $band ? 196 : ($light ? 14 : $H);
    if ($d['bg_type'] === 'image' && ($bg = idev_medreg_load_image($d['bg_image']))) {
        idev_medreg_cover($im, $bg, 0, 0, $W, $bgH); imagedestroy($bg);
        $a = (int) round(127 - 127 * ((int) $d['overlay'] / 100));
        imagefilledrectangle($im, 0, 0, $W, $bgH, idev_medreg_rgb($im, $d['bg2'], max(0, min(127, $a))));
    } elseif ($d['bg_type'] === 'solid') {
        imagefilledrectangle($im, 0, 0, $W, $bgH, idev_medreg_rgb($im, $d['bg1']));
    } else {
        $c1 = sscanf(ltrim($d['bg1'], '#'), '%2x%2x%2x'); $c2 = sscanf(ltrim($d['bg2'], '#'), '%2x%2x%2x');
        for ($x = 0; $x < $W + $bgH; $x += 2) { // 45° gradient
            $t = $x / ($W + $bgH);
            $col = imagecolorallocate($im, (int) ($c1[0] + ($c2[0] - $c1[0]) * $t), (int) ($c1[1] + ($c2[1] - $c1[1]) * $t), (int) ($c1[2] + ($c2[2] - $c1[2]) * $t));
            imageline($im, $x, 0, $x - $bgH, $bgH, $col); imageline($im, $x + 1, 0, $x + 1 - $bgH, $bgH, $col);
        }
        if (!$band && !$light) { // soft decorative circles
            imagefilledellipse($im, $W - 120, 80, 420, 420, imagecolorallocatealpha($im, 255, 255, 255, 118));
            imagefilledellipse($im, $W - 40, $H - 30, 300, 300, imagecolorallocatealpha($im, 255, 255, 255, 120));
        }
    }
    $onBg = ($light || $band) ? null : true;
    $txt = idev_medreg_rgb($im, $light ? '#1f2937' : $d['text']);
    $muted = idev_medreg_rgb($im, $light ? '#6b7280' : $d['muted']);
    $dark = idev_medreg_rgb($im, '#1f2937'); $grey = idev_medreg_rgb($im, '#6b7280');
    $accent = idev_medreg_rgb($im, $d['accent']);
    $bold = idev_medreg_font('Bold'); $semi = idev_medreg_font('SemiBold'); $reg = idev_medreg_font('Regular');
    $site = idev_medreg_site($en);
    // header: logo + organisation + title
    $y = $pad;
    $hx = $pad;
    if ($d['logo'] && ($logo = idev_medreg_load_image($d['logo']))) {
        if ($band || !$light) { [$lw] = idev_medreg_contain($im, $logo, $pad, $y - 14, 150, 88); } else { [$lw] = idev_medreg_contain($im, $logo, $pad, $y - 14, 150, 88); }
        imagedestroy($logo);
        $hx = $pad + $lw + 22;
    }
    $headTxt = $band ? $white : $txt; $headMuted = $band ? idev_medreg_rgb($im, '#ffffff', 40) : $muted;
    if ($d['show_org'] === '1') idev_medreg_text($im, 26, $hx, $y + 20, $headTxt, $bold, $site['name'], $W - $hx - $pad);
    $title = $en ? ($d['title_en'] ?: $d['title']) : trim($d['title'] . ($d['title_en'] ? '  ·  ' . $d['title_en'] : ''));
    idev_medreg_text($im, 17, $hx, $y + ($d['show_org'] === '1' ? 58 : 24), $headMuted, $semi, $title, $W - $hx - $pad);
    // code area on the right
    $codeSize = 0; $code = $d['code'];
    $bodyTxt = $band ? $dark : $txt; $bodyMuted = $band ? $grey : $muted;
    $top = $band ? 236 : 200;
    if ($code === 'qr' || $code === 'both') {
        $qr = idev_qr_image(idev_medreg_qr_value($d, $row), 10, 2, 'M');
        $codeSize = $code === 'both' ? 210 : 250;
        $qx = $W - $pad - $codeSize; $qy = $code === 'both' ? $top - 6 : $H - $pad - $codeSize - 34;
        idev_medreg_round($im, $qx - 10, $qy - 10, $qx + $codeSize + 10, $qy + $codeSize + 10, 18, $white);
        imagecopyresampled($im, $qr, $qx, $qy, 0, 0, $codeSize, $codeSize, imagesx($qr), imagesy($qr));
        imagedestroy($qr);
    }
    $textMax = $W - 2 * $pad - ($codeSize ? $codeSize + 40 : 0);
    // name
    $name = idev_medreg_name($p);
    $nameEn = idev_medreg_name_en($p);
    if ($en && $nameEn !== '') { [$name, $nameEn] = [$nameEn, $name === $nameEn ? '' : $name]; }
    $y = $top + 20;
    idev_medreg_text($im, 40, $pad, $y + 26, $bodyTxt, $bold, $name, $textMax);
    $y += 44;
    if ($d['show_name_en'] === '1' && $nameEn !== '' && $nameEn !== $name) { idev_medreg_text($im, 21, $pad, $y + 22, $bodyMuted, $reg, $nameEn, $textMax); $y += 36; }
    // HN big
    $y += 22;
    idev_medreg_text($im, 16, $pad, $y + 14, $bodyMuted, $semi, 'HN');
    idev_medreg_text($im, 56, $pad, $y + 74, $band || $light ? idev_medreg_rgb($im, $d['bg2']) : $accent, $bold, $row['hn'], $textMax);
    $y += 92;
    // small facts row
    $facts = [];
    if ($d['show_dob'] === '1' && !empty($p['birthdate'])) $facts[] = [$en ? 'Date of birth' : 'วันเกิด', idev_format_day($p['birthdate'], $en ? 'en' : 'th')];
    if ($d['show_id'] === '1') {
        $num = ($p['doc_type'] ?? '') === 'passport' ? ($p['passport_no'] ?? '') : ($p['cid'] ?? '');
        if ($num !== '') $facts[] = [($p['doc_type'] ?? '') === 'passport' ? ($en ? 'Passport' : 'หนังสือเดินทาง') : ($en ? 'ID card' : 'บัตรประชาชน'), idev_medreg_mask_id($num)];
    }
    if ($d['show_issued'] === '1') $facts[] = [$en ? 'Issued' : 'ออกบัตร', idev_format_day(substr((string) ($row['synced_at'] ?: current_time('mysql')), 0, 10), $en ? 'en' : 'th')];
    $fx = $pad; $colW = (int) (($textMax) / max(1, min(3, count($facts))));
    foreach (array_slice($facts, 0, 3) as [$label, $value]) {
        idev_medreg_text($im, 14, $fx, $y + 12, $bodyMuted, $reg, $label, $colW - 12);
        idev_medreg_text($im, 19, $fx, $y + 42, $bodyTxt, $semi, $value, $colW - 12);
        $fx += $colW;
    }
    // barcode
    if ($code === 'barcode' || $code === 'both') {
        $bc = idev_code128_image($row['hn'], 70, 3);
        $bw = min($code === 'both' ? $textMax : $W - 2 * $pad, imagesx($bc));
        $by = max($y + 70, $H - $pad - 64 - 26); // below the details row
        $bh = max(36, min(64, $H - 46 - $by));
        $bx = $pad;
        if ($code === 'barcode') { $bw = min(560, $W - 2 * $pad); $bx = $W - $pad - $bw; }
        idev_medreg_round($im, $bx - 10, $by - 10, $bx + $bw + 10, $by + $bh + 10, 12, $white);
        imagecopyresampled($im, $bc, $bx, $by, 0, 0, $bw, $bh, imagesx($bc), imagesy($bc));
        imagedestroy($bc);
    }
    // footer note
    $note = idev_pick($d['note'], $d['note_en'], $en ? 'en' : 'th');
    if ($note !== '') idev_medreg_text($im, 15, $pad, $H - 26, $band || $light ? $grey : $muted, $reg, $note, $W - 2 * $pad);
    if ($light) imagerectangle($im, 0, 0, $W - 1, $H - 1, idev_medreg_rgb($im, '#d1d5db'));
    ob_start(); imagepng($im, null, 6); $png = ob_get_clean();
    imagedestroy($im);
    return $png;
}

/** Sample patient for previews. */
function idev_medreg_card_sample() {
    return ['id' => 0, 'ref' => 'REG-PREVIEW', 'hn' => '000123456', 'synced_at' => current_time('mysql', true), 'person' => ['prefix' => 'นางสาว', 'first_name' => 'สมหญิง', 'last_name' => 'ใจดีมาก', 'first_name_en' => 'Somying', 'last_name_en' => 'Jaideemak', 'birthdate' => '1990-04-13', 'doc_type' => 'thai_id', 'cid' => '1103700123458', 'lang' => 'th']];
}

/* Back office: preview with unsaved design (GET), and card image for a record. */
add_action('admin_post_idev_medreg_card_preview', function () {
    if (!current_user_can('manage_options') || !wp_verify_nonce(sanitize_key($_GET['_wpnonce'] ?? ''), 'idev_medreg_card_preview')) wp_die('Forbidden', 403);
    $override = isset($_GET['d']) ? json_decode(wp_unslash((string) $_GET['d']), true) : null;
    $png = idev_medreg_card_png(idev_medreg_card_sample(), ($_GET['lang'] ?? '') === 'en', is_array($override) ? $override : null);
    nocache_headers(); header('Content-Type: image/png'); header('X-Content-Type-Options: nosniff');
    echo $png; // phpcs:ignore
    exit;
});
add_action('admin_post_idev_medreg_card', function () {
    $id = (int) ($_GET['id'] ?? 0);
    if (!current_user_can('idev_medreg') || !wp_verify_nonce(sanitize_key($_GET['_wpnonce'] ?? ''), 'idev_medreg_card_' . $id)) wp_die('Forbidden', 403);
    $row = idev_medreg_get($id);
    if (!$row || $row['hn'] === '' || !$row['readable']) wp_die('Not found', 404);
    $png = idev_medreg_card_png($row, ($_GET['lang'] ?? '') === 'en');
    nocache_headers(); header('Content-Type: image/png'); header('X-Content-Type-Options: nosniff');
    if (!empty($_GET['download'])) header('Content-Disposition: attachment; filename="patient-card-HN' . preg_replace('/[^0-9A-Za-z-]/', '', $row['hn']) . '.png"');
    echo $png; // phpcs:ignore
    exit;
});
