<?php
defined('ABSPATH') || exit;

function idev_medreg_setting_defaults() {
    return [
        'enabled' => '1', 'm_thai_id' => '1', 'm_passport' => '1', 'm_manual' => '1',
        'ocr' => '1', 'auto_capture' => '1', 'ocr_base' => '',
        'require_email' => '1', 'field_address' => 'required', 'field_line' => 'optional', 'field_whatsapp' => 'optional', 'field_name_en' => 'optional',
        'field_allergy' => 'optional', 'field_emergency' => 'optional', 'field_gps' => '1', 'field_contact_pref' => '1',
        'accent' => '#0f766e', 'staff_email' => '', 'email_from' => '', 'email_color' => '#0e3540', 'email_received' => '1',
        'photo_days' => '30', 'rejected_days' => '90', 'synced_days' => '0', 'rate_limit' => '5', 'connector_ips' => '',
        'org_name' => '', 'org_name_en' => '', 'org_address' => '', 'org_address_en' => '', 'org_phone' => '',
        'consent_version' => '1', 'privacy_url' => '', 'dpo_contact' => '',
        'consent_text' => "{org} (ผู้ควบคุมข้อมูลส่วนบุคคล) จะเก็บรวบรวม ใช้ และเปิดเผยข้อมูลของท่าน ได้แก่ ชื่อ-นามสกุล เพศ วันเกิด เลขประจำตัวประชาชนหรือหนังสือเดินทาง รูปถ่ายเอกสาร (ถ้าท่านเลือกถ่าย) เบอร์โทร อีเมล LINE / WhatsApp ที่อยู่และพิกัด (ถ้าท่านเลือกแชร์) ประวัติแพ้ยา และผู้ติดต่อฉุกเฉิน เพื่อการลงทะเบียนเป็นผู้ป่วย การบันทึกเวชระเบียน การติดต่อ และการให้บริการทางการแพทย์ ตามพระราชบัญญัติคุ้มครองข้อมูลส่วนบุคคล พ.ศ. 2562 (PDPA)\n\nข้อมูลจะถูกเข้ารหัสและเข้าถึงได้เฉพาะเจ้าหน้าที่ที่เกี่ยวข้อง รูปถ่ายเอกสารจะถูกลบหลังลงทะเบียนเสร็จ เวชระเบียนจะถูกเก็บตามระยะเวลาที่กฎหมายกำหนด ท่านมีสิทธิขอเข้าถึง แก้ไข ลบ ระงับ หรือคัดค้านการประมวลผล ขอรับข้อมูล และถอนความยินยอม โดยติดต่อเจ้าหน้าที่คุ้มครองข้อมูลส่วนบุคคล",
        'consent_text_en' => "{org} (the data controller) collects, uses and discloses your personal data — name, sex, date of birth, national ID or passport number, a photo of your document (if you choose to take one), phone number, e-mail, LINE / WhatsApp, address and location (if you choose to share it), drug allergies and emergency contact — to register you as a patient, keep your medical record, contact you and provide medical care, under Thailand's Personal Data Protection Act B.E. 2562 (PDPA) and, where it applies, the EU General Data Protection Regulation (GDPR). Health data is processed on the basis of your explicit consent and for medical care.\n\nYour data is encrypted and only authorised staff can access it. The document photo is deleted after registration; medical records are kept for the period required by law. You have the right to access, correct, delete, restrict or object to the processing of your data, to data portability, to withdraw consent, and to complain to the supervisory authority. Contact our Data Protection Officer.",
        'card_email_note' => '', 'card_email_note_en' => '',
    ];
}
function idev_medreg_settings() {
    static $cache = null;
    if ($cache !== null && !did_action('idev_medreg_settings_saved')) return $cache;
    $s = get_option('idev_medreg_settings', []);
    return $cache = array_merge(idev_medreg_setting_defaults(), is_array($s) ? $s : []);
}
/** Ways a patient may register: thai_id (photo), passport (photo), manual. */
function idev_medreg_methods() {
    $s = idev_medreg_settings();
    $m = array_values(array_filter(['thai_id', 'passport', 'manual'], function ($k) use ($s) { return $s["m_{$k}"] === '1'; }));
    return $m ?: ['manual'];
}
function idev_medreg_consent_text($en) {
    $s = idev_medreg_settings();
    $org = idev_pick($s['org_name'] ?: get_bloginfo('name'), $s['org_name_en'], $en ? 'en' : 'th');
    return str_replace('{org}', $org, $en ? ($s['consent_text_en'] ?: $s['consent_text']) : $s['consent_text']);
}

add_action('admin_menu', function () {
    add_submenu_page('idev-medreg', __('Registration settings', 'idev-patient-registration'), __('Settings', 'idev-patient-registration'), 'manage_options', 'idev-medreg-settings', 'idev_medreg_settings_page');
}, 20);

function idev_medreg_settings_tabs() {
    /** Filter: add-ons add tabs (Pro: HOSxP connector). */
    return apply_filters('idev_medreg_settings_tabs', ['general' => __('General', 'idev-patient-registration'), 'form' => __('Form', 'idev-patient-registration'), 'consent' => __('Consent (PDPA / GDPR)', 'idev-patient-registration'), 'card' => __('Patient card', 'idev-patient-registration'), 'email' => __('E-mails', 'idev-patient-registration'), 'keys' => __('Encryption key', 'idev-patient-registration'), 'tools' => __('Tools', 'idev-patient-registration')]);
}
function idev_medreg_fields($tab) {
    $show3 = ['required' => __('Required', 'idev-patient-registration'), 'optional' => __('Optional', 'idev-patient-registration'), 'hidden' => __('Hidden', 'idev-patient-registration')];
    $show2 = ['optional' => __('Show', 'idev-patient-registration'), 'hidden' => __('Hidden', 'idev-patient-registration')];
    switch ($tab) {
        case 'general': return [
            ['enabled', __('Accept registrations', 'idev-patient-registration'), 'checkbox'],
            ['org_name', __('Hospital / clinic name (Thai)', 'idev-patient-registration'), 'text'], ['org_name_en', __('Hospital / clinic name (English)', 'idev-patient-registration'), 'text'],
            ['org_address', __('Address (Thai)', 'idev-patient-registration'), 'textarea'], ['org_address_en', __('Address (English)', 'idev-patient-registration'), 'textarea'],
            ['org_phone', __('Phone', 'idev-patient-registration'), 'text'],
            ['photo_days', __('Delete document photos after (days)', 'idev-patient-registration'), 'number', __('Counted from when the HN is issued or the registration is not approved. 0 = at the next daily clean-up.', 'idev-patient-registration'), [0, 3650]],
            ['rejected_days', __('Delete not-approved registrations after (days)', 'idev-patient-registration'), 'number', '', [1, 3650]],
            ['synced_days', __('Delete completed registrations after (days)', 'idev-patient-registration'), 'number', __('0 = keep. The patient is in HOSxP by then; this only removes the copy on the website.', 'idev-patient-registration'), [0, 3650]],
            ['rate_limit', __('Registrations per hour from one network', 'idev-patient-registration'), 'number', '', [1, 100]],
        ];
        case 'form': return [
            ['heading', __('Ways to register', 'idev-patient-registration'), 'heading', __('The patient chooses one of these.', 'idev-patient-registration')],
            ['m_thai_id', __('Photo of Thai ID card', 'idev-patient-registration'), 'checkbox'],
            ['m_passport', __('Photo of passport', 'idev-patient-registration'), 'checkbox'],
            ['m_manual', __('Type the details in', 'idev-patient-registration'), 'checkbox'],
            ['ocr', __('Read the document automatically', 'idev-patient-registration'), 'checkbox', __('Runs on the patient\'s phone; the photo is not sent to any reading service. Passport: MRZ with check digits (includes the Thai ID number on Thai passports). ID card: number, names and date of birth. The patient always checks the result.', 'idev-patient-registration')],
            ['auto_capture', __('Take the photo automatically when sharp', 'idev-patient-registration'), 'checkbox', __('The camera focuses continuously and takes the picture when the document is sharp and still.', 'idev-patient-registration')],
            ['ocr_base', __('Reading engine location', 'idev-patient-registration'), 'url', __('Reading needs tesseract.js 5: copy tesseract.min.js, worker.min.js, tesseract-core* and the eng / tha traineddata to one folder on your server and put its URL here. iDev Patient Registration Pro loads it for you.', 'idev-patient-registration')],
            ['heading2', __('Fields', 'idev-patient-registration'), 'heading'],
            ['require_email', __('E-mail required', 'idev-patient-registration'), 'checkbox', __('Needed to send the patient card by e-mail.', 'idev-patient-registration')],
            ['field_line', 'LINE ID', 'select', '', $show2], ['field_whatsapp', 'WhatsApp', 'select', '', $show2],
            ['field_contact_pref', __('Ask how they prefer to be contacted', 'idev-patient-registration'), 'checkbox'],
            ['field_name_en', __('Name in English', 'idev-patient-registration'), 'select', '', $show2],
            ['field_address', __('Current address', 'idev-patient-registration'), 'select', '', $show3],
            ['field_gps', __('"Use my location" button', 'idev-patient-registration'), 'checkbox'],
            ['field_allergy', __('Drug allergies', 'idev-patient-registration'), 'select', '', $show2],
            ['field_emergency', __('Emergency contact', 'idev-patient-registration'), 'select', '', $show2],
            ['accent', __('Form colour', 'idev-patient-registration'), 'color'],
        ];
        case 'consent': return [
            ['consent_text', __('Consent text (Thai)', 'idev-patient-registration'), 'textarea', __('{org} = hospital name. Changing the text starts a new consent version, saved with each registration. Have your DPO / legal team check it.', 'idev-patient-registration')],
            ['consent_text_en', __('Consent text (English, GDPR)', 'idev-patient-registration'), 'textarea'],
            ['dpo_contact', __('Data Protection Officer contact', 'idev-patient-registration'), 'textarea'],
            ['privacy_url', __('Privacy policy link', 'idev-patient-registration'), 'url', __('Empty = the WordPress privacy policy page.', 'idev-patient-registration')],
        ];
        case 'email': return [
            ['email_received', __('E-mail the patient when we receive the form', 'idev-patient-registration'), 'checkbox'],
            ['staff_email', __('Tell staff about new registrations', 'idev-patient-registration'), 'text', __('E-mail addresses, separated by commas. No patient data is put in this e-mail.', 'idev-patient-registration')],
            ['email_from', __('Reply-to address', 'idev-patient-registration'), 'email'],
            ['email_color', __('E-mail header colour', 'idev-patient-registration'), 'color'],
            ['card_email_note', __('Note under the card (Thai)', 'idev-patient-registration'), 'textarea'], ['card_email_note_en', __('Note under the card (English)', 'idev-patient-registration'), 'textarea'],
        ];
    }
    return apply_filters('idev_medreg_fields', [], $tab);
}

function idev_medreg_settings_page() {
    if (!current_user_can('manage_options')) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-patient-registration'));
    $tabs = idev_medreg_settings_tabs();
    $tab = sanitize_key($_GET['tab'] ?? 'general');
    if (!isset($tabs[$tab])) $tab = 'general';
    $s = idev_medreg_settings();
    $fields = idev_medreg_fields($tab);
    $notice = '';
    if ($fields && isset($_POST['idev_medreg_settings']) && check_admin_referer('idev_medreg_settings_' . $tab)) {
        $in = wp_unslash($_POST['idev_medreg_settings']);
        $old = $s;
        $s = idev_settings_sanitize($fields, $in, $s);
        if ($tab === 'consent' && ($old['consent_text'] !== $s['consent_text'] || $old['consent_text_en'] !== $s['consent_text_en'])) $s['consent_version'] = (string) ((int) $old['consent_version'] + 1);
        update_option('idev_medreg_settings', $s, false);
        do_action('idev_medreg_settings_saved');
        $notice = __('Saved.', 'idev-patient-registration');
    }
    if ($tab === 'card' && isset($_POST['idev_medreg_card']) && check_admin_referer('idev_medreg_settings_card')) {
        update_option('idev_medreg_card', idev_medreg_card_sanitize(wp_unslash($_POST['idev_medreg_card']), idev_medreg_card_design()), false);
        $notice = __('Saved.', 'idev-patient-registration');
    }
    idev_page_open(__('Patient registration settings', 'idev-patient-registration'), '', ['tabs' => $tabs, 'current' => $tab, 'url' => function ($k) { return admin_url('admin.php?page=idev-medreg-settings&tab=' . $k); },
        'icons' => apply_filters('idev_medreg_settings_icons', ['general' => 'gear', 'form' => 'list', 'consent' => 'shield', 'card' => 'idcard', 'email' => 'mail', 'keys' => 'shield', 'tools' => 'wrench'])]);
    if ($notice) echo '<div class="notice notice-success"><p>' . esc_html($notice) . '</p></div>';
    foreach (['key_ok' => __('Done.', 'idev-patient-registration')] as $k => $t) if (isset($_GET[$k])) echo '<div class="notice notice-success"><p>' . esc_html($t) . ' ' . esc_html(sanitize_text_field(wp_unslash($_GET['msg'] ?? ''))) . '</p></div>';
    if (isset($_GET['key_err'])) echo '<div class="notice notice-error"><p>' . esc_html(sanitize_text_field(wp_unslash($_GET['msg'] ?? ''))) . '</p></div>';
    /** Action: an add-on draws the whole tab (its own forms). */
    if (has_action('idev_medreg_settings_page_' . $tab)) { do_action('idev_medreg_settings_page_' . $tab); echo '</div>'; return; }
    if ($tab === 'card') { idev_medreg_card_designer(); echo '</div>'; return; }
    if ($tab === 'keys') { idev_medreg_keys_page(); echo '</div>'; return; }
    if ($tab === 'tools') { idev_medreg_tools_page(); echo '</div>'; return; }
    echo '<form method="post">';
    wp_nonce_field('idev_medreg_settings_' . $tab);
    if ($tab === 'general') echo '<div class="idev-card"><p>' . esc_html__('Put the form on any page with the block "Patient registration" or the shortcode', 'idev-patient-registration') . ' <code>[idev_patient_registration]</code></p></div>';
    if ($tab === 'consent') echo '<p class="description">' . esc_html(sprintf(__('Current consent version: %s', 'idev-patient-registration'), $s['consent_version'])) . '</p>';
    idev_settings_table('idev_medreg_settings', $fields, $s);
    do_action('idev_medreg_settings_tab', $tab);
    if ($fields) submit_button();
    echo '</form></div>';
}

/* ---------- Card designer ---------- */

function idev_medreg_card_designer() {
    $d = idev_medreg_card_design();
    wp_enqueue_media();
    $preview = wp_nonce_url(admin_url('admin-post.php?action=idev_medreg_card_preview'), 'idev_medreg_card_preview');
    $img = function ($k, $label) use ($d) {
        $url = $d[$k] ? wp_get_attachment_image_url((int) $d[$k], 'thumbnail') : '';
        return '<div class="idev-mr-media" data-key="' . esc_attr($k) . '"><input type="hidden" name="idev_medreg_card[' . esc_attr($k) . ']" value="' . (int) $d[$k] . '"><span class="idev-mr-thumb">' . ($url ? '<img src="' . esc_url($url) . '" alt="">' : '') . '</span><button type="button" class="button" data-pick>' . esc_html($label) . '</button> <button type="button" class="button-link-delete" data-clear>' . esc_html__('Remove', 'idev-patient-registration') . '</button></div>';
    };
    $sel = function ($k, $opts) use ($d) { $h = '<select name="idev_medreg_card[' . esc_attr($k) . ']">'; foreach ($opts as $v => $l) $h .= '<option value="' . esc_attr($v) . '"' . selected($d[$k], $v, false) . '>' . esc_html($l) . '</option>'; return $h . '</select>'; };
    $col = function ($k) use ($d) { return '<input type="color" name="idev_medreg_card[' . esc_attr($k) . ']" value="' . esc_attr($d[$k]) . '">'; };
    $txt = function ($k, $ph = '') use ($d) { return '<input class="regular-text" name="idev_medreg_card[' . esc_attr($k) . ']" value="' . esc_attr($d[$k]) . '" placeholder="' . esc_attr($ph) . '">'; };
    $chk = function ($k, $label) use ($d) { return '<label class="idev-check"><input type="checkbox" name="idev_medreg_card[' . esc_attr($k) . ']" value="1"' . checked($d[$k], '1', false) . '> ' . esc_html($label) . '</label>'; };
    echo '<form method="post" id="idev-mr-card" data-preview="' . esc_url($preview) . '">';
    wp_nonce_field('idev_medreg_settings_card');
    /** Action: above the card designer (add-ons: ready-made designs). */
    do_action('idev_medreg_card_designer_top', $d);
    echo '<div class="idev-mr-designer"><div class="idev-mr-controls idev-form">';
    echo '<h3>' . esc_html__('Layout', 'idev-patient-registration') . '</h3><label>' . esc_html__('Style', 'idev-patient-registration') . $sel('layout', idev_medreg_card_layouts()) . '</label>';
    echo '<label>' . esc_html__('Background', 'idev-patient-registration') . $sel('bg_type', ['gradient' => __('Gradient', 'idev-patient-registration'), 'solid' => __('One colour', 'idev-patient-registration'), 'image' => __('Picture', 'idev-patient-registration')]) . '</label>';
    echo '<div class="idev-grid2"><label>' . esc_html__('Colour 1', 'idev-patient-registration') . $col('bg1') . '</label><label>' . esc_html__('Colour 2', 'idev-patient-registration') . $col('bg2') . '</label></div>';
    echo '<label>' . esc_html__('Background picture', 'idev-patient-registration') . $img('bg_image', __('Choose picture', 'idev-patient-registration')) . '</label>';
    echo '<label>' . esc_html__('Darken picture (%)', 'idev-patient-registration') . '<input type="range" min="0" max="90" name="idev_medreg_card[overlay]" value="' . esc_attr($d['overlay']) . '"></label>';
    echo '<div class="idev-grid2"><label>' . esc_html__('Text', 'idev-patient-registration') . $col('text') . '</label><label>' . esc_html__('Small text', 'idev-patient-registration') . $col('muted') . '</label><label>' . esc_html__('HN colour', 'idev-patient-registration') . $col('accent') . '</label></div>';
    echo '<label>' . esc_html__('Logo', 'idev-patient-registration') . $img('logo', __('Choose logo', 'idev-patient-registration')) . '</label>';
    echo '<h3>' . esc_html__('Text', 'idev-patient-registration') . '</h3><label>' . esc_html__('Title (Thai)', 'idev-patient-registration') . $txt('title') . '</label><label>' . esc_html__('Title (English)', 'idev-patient-registration') . $txt('title_en') . '</label>';
    echo '<label>' . esc_html__('Note at the bottom (Thai)', 'idev-patient-registration') . $txt('note') . '</label><label>' . esc_html__('Note at the bottom (English)', 'idev-patient-registration') . $txt('note_en') . '</label>';
    echo '<h3>' . esc_html__('Show', 'idev-patient-registration') . '</h3>' . $chk('show_org', __('Hospital name', 'idev-patient-registration')) . $chk('show_name_en', __('Name in English', 'idev-patient-registration')) . $chk('show_dob', __('Date of birth', 'idev-patient-registration')) . $chk('show_id', __('ID / passport number (last 4 digits)', 'idev-patient-registration')) . $chk('show_issued', __('Date issued', 'idev-patient-registration'));
    echo '<h3>' . esc_html__('Code', 'idev-patient-registration') . '</h3><label>' . esc_html__('Code on the card', 'idev-patient-registration') . $sel('code', ['qr' => __('QR code', 'idev-patient-registration'), 'barcode' => __('Barcode (Code 128)', 'idev-patient-registration'), 'both' => __('QR code and barcode', 'idev-patient-registration'), 'none' => __('None', 'idev-patient-registration')]) . '</label>';
    echo '<label>' . esc_html__('QR code contains', 'idev-patient-registration') . $txt('qr_text', '{hn}') . '<small>' . esc_html__('{hn} {ref} {site} — e.g. just {hn} for the registration desk scanner. Avoid putting names or dates of birth in the code.', 'idev-patient-registration') . '</small></label>';
    echo '</div><div class="idev-mr-preview"><div class="idev-mr-preview-tabs"><button type="button" class="button is-active" data-lang="th">ไทย</button><button type="button" class="button" data-lang="en">English</button></div><img id="idev-mr-card-img" src="' . esc_url($preview) . '" alt="" width="506" height="319"><p class="description">' . esc_html__('Preview with a sample patient. The real card is 1012 × 638 px (credit-card shape), sent as an image in the e-mail and as an attachment.', 'idev-patient-registration') . '</p></div></div>';
    submit_button();
    echo '</form>';
}

/* ---------- Encryption key ---------- */

function idev_medreg_keys_page() {
    $ring = idev_medreg_keyring(true);
    $usage = idev_medreg_key_usage();
    $sources = ['constant' => __('IDEV_MEDREG_KEY in wp-config.php', 'idev-patient-registration'), 'file' => __('Key file outside the web folder', 'idev-patient-registration'), 'salts' => __('Made from AUTH_KEY and SECURE_AUTH_KEY in wp-config.php', 'idev-patient-registration')];
    $act = function ($do, $label, $class = 'button', $confirm = '') { return '<a class="' . esc_attr($class) . '" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=idev_medreg_keys&do=' . $do), 'idev_medreg_keys')) . '"' . ($confirm ? ' onclick="return confirm(\'' . esc_js($confirm) . '\')"' : '') . '>' . esc_html($label) . '</a>'; };
    echo '<div class="idev-card"><h2>' . esc_html__('Encryption key', 'idev-patient-registration') . '</h2>';
    echo '<p>' . esc_html__('Patient details and document photos are encrypted (XSalsa20-Poly1305). Without the key nobody — including you — can read them, so keep a backup of the key somewhere safe and separate from website backups.', 'idev-patient-registration') . '</p>';
    echo '<table class="widefat striped" style="max-width:820px"><tbody>';
    echo '<tr><th>' . esc_html__('Active key comes from', 'idev-patient-registration') . '</th><td><strong>' . esc_html($sources[$ring['source']]) . '</strong></td></tr>';
    echo '<tr><th>' . esc_html__('Active key fingerprint', 'idev-patient-registration') . '</th><td><code>' . esc_html($ring['active']) . '</code></td></tr>';
    echo '<tr><th>' . esc_html__('Records per key', 'idev-patient-registration') . '</th><td>';
    if (!$usage) echo esc_html__('No records yet.', 'idev-patient-registration');
    foreach ($usage as $k => $n) echo '<div><code>' . esc_html($k === '' ? __('older format', 'idev-patient-registration') : ($k === 'unreadable' ? __('NO KEY FITS', 'idev-patient-registration') : $k)) . '</code> · ' . (int) $n . ($k === $ring['active'] ? ' ✓' : '') . '</div>';
    echo '</td></tr>';
    if ($ring['source'] === 'file') echo '<tr><th>' . esc_html__('Key file', 'idev-patient-registration') . '</th><td><code>' . esc_html(idev_medreg_keyfile_path()) . '</code></td></tr>';
    echo '</tbody></table>';
    if (!empty($usage['unreadable'])) echo '<div class="notice notice-error inline"><p>' . esc_html__('Some records cannot be read with any key. If AUTH_KEY / SECURE_AUTH_KEY in wp-config.php were changed, add the OLD values to wp-config.php like this, then come back:', 'idev-patient-registration') . '</p><pre>define(\'IDEV_MEDREG_OLD_AUTH_KEY\', \'…old AUTH_KEY…\');' . "\n" . 'define(\'IDEV_MEDREG_OLD_SECURE_AUTH_KEY\', \'…old SECURE_AUTH_KEY…\');</pre></div>';
    if ($ring['source'] === 'salts') echo '<div class="notice notice-warning inline"><p>' . esc_html__('The key is made from AUTH_KEY / SECURE_AUTH_KEY. Changing those values (some security plugins do it automatically) would make the data unreadable. Recommended: move to a separate key file, or set your own key in wp-config.php.', 'idev-patient-registration') . '</p></div>';
    $others = array_diff(array_keys(array_filter($usage)), [$ring['active'], 'unreadable']);
    echo '<h3>' . esc_html__('Actions', 'idev-patient-registration') . '</h3><p>';
    if ($ring['source'] !== 'constant') echo $act('file', $ring['source'] === 'file' ? __('Change key (new key file key)', 'idev-patient-registration') : __('Use a separate key file (recommended)', 'idev-patient-registration'), 'button button-primary', __('Create a new key and re-encrypt all records with it? Download a key backup afterwards.', 'idev-patient-registration')) . ' ';
    if ($others) echo $act('reencrypt', __('Re-encrypt all records with the active key', 'idev-patient-registration')) . ' ';
    if ($ring['source'] === 'file') echo $act('prune', __('Remove old keys no record uses', 'idev-patient-registration'), 'button', __('Remove unused old keys from the key file? Database backups made before the last re-encryption would then be unreadable unless you have a key backup.', 'idev-patient-registration')) . ' ';
    if ($ring['source'] !== 'salts') echo $act('backup', __('Download key backup', 'idev-patient-registration'), 'button', __('The backup file can decrypt all patient data. Store it offline (e.g. an encrypted USB drive or password manager), never by e-mail.', 'idev-patient-registration'));
    echo '</p>';
    $suggest = bin2hex(random_bytes(32));
    echo '<details><summary>' . esc_html__('Set your own key in wp-config.php instead', 'idev-patient-registration') . '</summary><p>' . esc_html__('Add this line to wp-config.php (a new random key is shown each time you open this page), then press "Re-encrypt all records with the active key". Keep a copy of the line in a safe place.', 'idev-patient-registration') . '</p><pre style="user-select:all">define(\'IDEV_MEDREG_KEY\', \'' . esc_html($suggest) . '\');</pre><p class="description">' . esc_html__('Optional: IDEV_MEDREG_KEYFILE sets where the key file is kept.', 'idev-patient-registration') . '</p></details></div>';
}
add_action('admin_post_idev_medreg_keys', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idev_medreg_keys')) wp_die('Forbidden', 403);
    $back = admin_url('admin.php?page=idev-medreg-settings&tab=keys');
    $do = sanitize_key($_GET['do'] ?? '');
    if ($do === 'backup') {
        $ring = idev_medreg_keyring(true);
        $hex = []; foreach ($ring['keys'] as $id => $k) $hex[$id] = bin2hex($k);
        nocache_headers();
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="idev-medreg-keys-' . gmdate('Ymd') . '.json"');
        echo wp_json_encode(['site' => home_url('/'), 'created' => gmdate('c'), 'active' => $ring['active'], 'keys' => $hex, 'note' => 'iDev Patient Registration key backup. To restore, put it back as the key file (see Encryption key tab).'], JSON_PRETTY_PRINT);
        exit;
    }
    if ($do === 'file') {
        $r = idev_medreg_new_file_key();
        if (is_wp_error($r)) { wp_safe_redirect(add_query_arg(['key_err' => 1, 'msg' => rawurlencode($r->get_error_message())], $back)); exit; }
        $do = 'reencrypt';
    }
    if ($do === 'reencrypt') {
        $from = (int) ($_GET['from'] ?? 0); $done = (int) ($_GET['done'] ?? 0); $failed = (int) ($_GET['failed'] ?? 0);
        [$d, $f, $next] = idev_medreg_reencrypt($from, 300);
        $done += $d; $failed += $f;
        if ($next) { wp_safe_redirect(wp_nonce_url(admin_url("admin-post.php?action=idev_medreg_keys&do=reencrypt&from={$next}&done={$done}&failed={$failed}"), 'idev_medreg_keys')); exit; }
        wp_safe_redirect(add_query_arg(['key_ok' => 1, 'msg' => rawurlencode(sprintf(__('%1$d records re-encrypted, %2$d could not be read.', 'idev-patient-registration'), $done, $failed))], $back));
        exit;
    }
    if ($do === 'prune') { $n = idev_medreg_prune_file_keys(); wp_safe_redirect(add_query_arg(['key_ok' => 1, 'msg' => rawurlencode(sprintf(__('%d old keys removed.', 'idev-patient-registration'), $n))], $back)); exit; }
    wp_safe_redirect($back);
    exit;
});
