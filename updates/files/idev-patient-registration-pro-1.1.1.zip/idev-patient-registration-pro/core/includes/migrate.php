<?php
/** Copies registrations, settings, connector key and ID photos from Andaman Hub (wp_ah_registrations). The old table is left as it is. */
defined('ABSPATH') || exit;

function idev_medreg_andaman_table() { global $wpdb; return $wpdb->prefix . 'ah_registrations'; }
function idev_medreg_andaman_available() {
    global $wpdb;
    return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', idev_medreg_andaman_table())) === idev_medreg_andaman_table();
}

/** Returns [copied, skipped, unreadable]. Safe to run again: references already copied are skipped. */
function idev_medreg_migrate_andaman() {
    global $wpdb;
    if (!idev_medreg_andaman_available()) return [0, 0, 0];
    idev_medreg_install();
    // settings and connector key (first time only)
    if (!get_option('idev_medreg_settings') && ($old = get_option('ah_reg_settings')) && is_array($old)) {
        $map = ['staff_email' => 'staff_email', 'photo_days' => 'photo_days', 'rejected_days' => 'rejected_days', 'connector_ips' => 'connector_ips', 'consent_version' => 'consent_version', 'consent_text' => 'consent_text', 'consent_text_en' => 'consent_text_en', 'dpo_contact' => 'dpo_contact', 'card_note' => 'card_email_note', 'card_note_en' => 'card_email_note_en'];
        $new = [];
        foreach ($map as $a => $b) if (isset($old[$a])) $new[$b] = (string) $old[$a];
        if (isset($old['enabled'])) $new['enabled'] = $old['enabled'] === 'true' ? '1' : '0';
        if (isset($old['ocr'])) $new['ocr'] = $old['ocr'] === 'true' ? '1' : '0';
        $ah = get_option('ah_settings', []);
        if (is_array($ah)) foreach (['site_name' => 'org_name', 'site_name_en' => 'org_name_en', 'address' => 'org_address', 'address_en' => 'org_address_en', 'phone' => 'org_phone'] as $a => $b) if (!empty($ah[$a])) $new[$b] = $ah[$a];
        update_option('idev_medreg_settings', $new, false);
    }
    if (!get_option('idev_medreg_token_hash') && ($h = get_option('ah_reg_token_hash'))) update_option('idev_medreg_token_hash', $h, false);
    update_option('idev_medreg_compat_andaman', 1, false);
    $copied = $skipped = $bad = 0;
    $have = array_flip($wpdb->get_col('SELECT ref FROM ' . idev_medreg_table()));
    $old_dirs = [dirname(untrailingslashit(ABSPATH)) . '/andaman-private'];
    if ($secret = get_option('ah_reg_dir_secret')) $old_dirs[] = wp_get_upload_dir()['basedir'] . '/andaman-private-' . strtolower($secret);
    foreach ($wpdb->get_results('SELECT * FROM ' . idev_medreg_andaman_table() . ' ORDER BY id', ARRAY_A) as $r) {
        if (isset($have[$r['ref']])) { $skipped++; continue; }
        $plain = idev_medreg_decrypt($r['data']); // tries the Andaman Hub keys too
        if ($plain === null) { $bad++; continue; }
        $p = json_decode($plain, true) ?: [];
        $p['method'] = 'photo';
        $p += ['line_id' => '', 'whatsapp' => ''];
        $p['_log'][] = [gmdate('c'), 'system', 'คัดลอกจาก Andaman Hub'];
        $number = ($p['doc_type'] ?? '') === 'passport' ? ($p['passport_no'] ?? '') : ($p['cid'] ?? '');
        $photo = '';
        if (preg_match('/^[0-9a-f]{32}\.bin$/', (string) $r['photo'])) {
            foreach ($old_dirs as $dir) {
                if (!is_file("$dir/{$r['photo']}")) continue;
                $bytes = idev_medreg_decrypt(file_get_contents("$dir/{$r['photo']}"));
                if ($bytes !== null && idev_medreg_photo_write($r['photo'], $bytes)) $photo = $r['photo'];
                break;
            }
        }
        $wpdb->insert(idev_medreg_table(), [
            'ref' => $r['ref'], 'status' => $r['status'], 'doc_type' => $r['doc_type'], 'method' => 'photo',
            'search_key' => idev_medreg_search_key($r['doc_type'], $number), 'data' => idev_medreg_encrypt(wp_json_encode($p, JSON_UNESCAPED_UNICODE)),
            'photo' => $photo, 'hn' => $r['hn'], 'message' => $r['message'], 'created_at' => $r['created_at'], 'updated_at' => $r['updated_at'],
            'synced_at' => $r['synced_at'], 'emailed_at' => $r['emailed_at'],
        ]);
        $copied++;
    }
    update_option('idev_medreg_migrated', ['at' => time(), 'copied' => $copied, 'skipped' => $skipped, 'unreadable' => $bad], false);
    return [$copied, $skipped, $bad];
}

function idev_medreg_tools_page() {
    echo '<div class="idev-card"><h2>' . esc_html__('Copy from Andaman Hub', 'idev-patient-registration') . '</h2>';
    if (!idev_medreg_andaman_available()) { echo '<p>' . esc_html__('No Andaman Hub registrations on this site.', 'idev-patient-registration') . '</p></div>'; return; }
    $last = get_option('idev_medreg_migrated');
    echo '<p>' . esc_html__('Copies registrations, document photos, settings and the connector key. Registrations already copied are skipped. The Andaman Hub data is not changed.', 'idev-patient-registration') . '</p>';
    if (is_array($last)) echo '<p class="description">' . esc_html(sprintf(__('Last run %1$s: %2$d copied, %3$d already there, %4$d could not be read.', 'idev-patient-registration'), wp_date('j M Y H:i', $last['at']), $last['copied'], $last['skipped'], $last['unreadable'])) . '</p>';
    echo '<p><a class="button button-primary" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=idev_medreg_migrate'), 'idev_medreg_migrate')) . '">' . esc_html__('Copy now', 'idev-patient-registration') . '</a></p></div>';
}
add_action('admin_post_idev_medreg_migrate', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idev_medreg_migrate')) wp_die('Forbidden', 403);
    [$c, $s, $b] = idev_medreg_migrate_andaman();
    wp_safe_redirect(add_query_arg(['key_ok' => 1, 'msg' => rawurlencode(sprintf(__('%1$d copied, %2$d already there, %3$d could not be read.', 'idev-patient-registration'), $c, $s, $b))], admin_url('admin.php?page=idev-medreg-settings&tab=tools')));
    exit;
});
