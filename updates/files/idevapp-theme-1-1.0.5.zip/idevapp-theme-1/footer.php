<?php defined( 'ABSPATH' ) || exit; ?>
</main>
<footer class="hos-footer"><div class="container hos-footer-grid">
	<div>
		<a class="hos-brand light" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php if ( has_custom_logo() ) { echo wp_get_attachment_image( (int) get_theme_mod( 'custom_logo' ), 'thumbnail', false, array( 'class' => 'hos-logo-img' ) ); } else { echo '<img class="hos-logo-img" src="' . esc_url( get_template_directory_uri() . '/assets/logo.png' ) . '" alt="" width="56" height="56">'; } ?><span><strong><?php echo esc_html( hos_site_name() ); ?></strong><small><?php echo esc_html( hos_mod( 'hos_tagline' ) ); ?></small></span></a>
		<p><?php echo esc_html( hos_mod( 'hos_address' ) ); ?></p>
	</div>
	<div><h4>ติดต่อ</h4><p>โทร. <a href="<?php echo esc_attr( hos_tel( hos_mod( 'hos_phone' ) ) ); ?>" style="display:inline"><?php echo esc_html( hos_mod( 'hos_phone' ) ); ?></a><br>แฟกซ์ <?php echo esc_html( hos_mod( 'hos_fax' ) ); ?><br><?php echo esc_html( hos_mod( 'hos_email' ) ); ?></p></div>
	<div><h4>ลิงก์ด่วน</h4>
		<?php
		if ( has_nav_menu( 'footer' ) ) {
			wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'items_wrap' => '%3$s', 'depth' => 1, 'fallback_cb' => false ) );
		} else {
			echo '<a href="' . esc_url( hos_quick_url( hos_mod( 'hos_schedule_url' ) ) ) . '">ตารางแพทย์ออกตรวจ</a>';
			echo '<a href="' . esc_url( hos_source_url( 'procurement' ) ) . '">จัดซื้อจัดจ้าง</a>';
			echo '<a href="' . esc_url( hos_source_url( 'jobs' ) ) . '">รับสมัครงาน</a>';
			echo '<a href="' . esc_url( hos_template_url( 'tpl-ita.php', hos_source_url( 'ita' ) ) ) . '">ITA</a>';
		}
		?>
	</div>
	<div><h4>เกี่ยวกับเรา</h4>
		<a href="<?php echo esc_url( hos_template_url( 'tpl-history.php' ) ); ?>">ประวัติโรงพยาบาล</a>
		<a href="<?php echo esc_url( hos_template_url( 'tpl-vision.php' ) ); ?>">วิสัยทัศน์ / พันธกิจ</a>
		<a href="<?php echo esc_url( hos_template_url( 'tpl-departments.php' ) ); ?>">หน่วยงานภายใน</a>
		<a href="<?php echo esc_url( hos_template_url( 'tpl-contact.php' ) ); ?>">ติดต่อเรา</a>
	</div>
</div>
<div class="container hos-copy">© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( hos_site_name() ); ?> · กระทรวงสาธารณสุข<?php if ( hos_mod( 'hos_footer_note' ) ) { echo ' · ' . esc_html( hos_mod( 'hos_footer_note' ) ); } ?></div>
</footer>
<button type="button" class="hos-scrolltop" aria-label="กลับขึ้นด้านบน">↑</button>
<?php wp_footer(); ?>
</body>
</html>
