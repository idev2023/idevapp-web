<?php
/** ตั้งค่าธีม: ลักษณะ > ปรับแต่ง (Customizer) */
defined( 'ABSPATH' ) || exit;

/** แหล่งเนื้อหาแต่ละส่วน (เลือก post type / หมวดหมู่จากข้อมูลเดิม) */
function hos_sources() {
	return array(
		'news'        => array( 'label' => 'ข่าวประชาสัมพันธ์', 'kicker' => 'NEWS' ),
		'procurement' => array( 'label' => 'ประกาศประกวดราคาและจัดซื้อจัดจ้าง', 'kicker' => 'PROCUREMENT' ),
		'bidding'     => array( 'label' => 'ข่าวประกวดราคา', 'kicker' => 'BIDDING' ),
		'results'     => array( 'label' => 'สรุปผลดำเนินการจัดซื้อจัดจ้าง', 'kicker' => 'RESULTS' ),
		'midprice'    => array( 'label' => 'ประกาศราคากลาง', 'kicker' => 'REFERENCE PRICE' ),
		'others'      => array( 'label' => 'ข่าวอื่น ๆ', 'kicker' => 'OTHER NEWS' ),
		'jobs'        => array( 'label' => 'ข่าวรับสมัครงาน', 'kicker' => 'CAREERS' ),
		'downloads'   => array( 'label' => 'ดาวน์โหลดเอกสาร', 'kicker' => 'DOWNLOADS' ),
		'forms'       => array( 'label' => 'แบบฟอร์มเอกสาร', 'kicker' => 'FORMS' ),
		'ita'         => array( 'label' => 'ITA', 'kicker' => 'ITA' ),
		'schedule'    => array( 'label' => 'ไฟล์ตารางแพทย์', 'kicker' => 'SCHEDULE' ),
	);
}

function hos_defaults() {
	return array(
		'hos_style'        => 'green',
		'hos_menu_source'  => 'theme',
		'hos_front_hero'   => 'hub',
		'hos_auto_translate' => 'on',
		'hos_phone'        => '',
		'hos_fax'          => '',
		'hos_email'        => '',
		'hos_address'      => '',
		'hos_hours'        => 'จันทร์ - ศุกร์ 08:30 - 16:30 น. · ห้องฉุกเฉินเปิดตลอด 24 ชั่วโมง',
		'hos_tagline'      => 'กระทรวงสาธารณสุข',
		'hos_announcement' => '',
		'hos_facebook'     => '',
		'hos_line'         => '',
		'hos_youtube'      => '',
		'hos_stats_url'    => '',
		'hos_map_query'    => '',
		'hos_vision'       => 'ให้บริการสุขภาพที่มีคุณภาพ ปลอดภัย ประชาชนไว้วางใจ',
		'hos_hero_eyebrow' => 'โรงพยาบาล · กระทรวงสาธารณสุข',
		'hos_hero_image'   => '',
		'hos_welcome'      => 'โรงพยาบาลสังกัดกระทรวงสาธารณสุข ให้บริการตรวจรักษา ส่งเสริมสุขภาพ ป้องกันโรค และฟื้นฟูสุขภาพแก่ประชาชนในพื้นที่และใกล้เคียง',
		'hos_quick'        => "🩺|ตารางแพทย์ออกตรวจ|/doctor-schedule/\n📢|ข่าวประชาสัมพันธ์|#news\n🧾|จัดซื้อจัดจ้าง|#procurement\n💼|รับสมัครงาน|#jobs\n🛡️|ITA คุณธรรมและความโปร่งใส|/ita/\n📄|ดาวน์โหลดเอกสาร|#downloads",
		'hos_centers'      => "🚑|อุบัติเหตุและฉุกเฉิน 24 ชม.\n❤️|อายุรกรรม\n🦴|ศัลยกรรมกระดูก\n👶|สูติ-นรีเวช / กุมาร\n🦷|ทันตกรรม\n🌿|แพทย์แผนไทย\n🔬|ชันสูตร / รังสีวิทยา",
		'hos_stats'        => "120|เตียง\n24|ชม. ห้องฉุกเฉิน\n5|อำเภอที่รับผิดชอบ\n2520|ปีที่ก่อตั้ง (พ.ศ.)",
		'hos_footer_note'  => '',
		'hos_schedule_url' => '/doctor-schedule/',
		'hos_smc_note'     => '',
		'hos_links'        => "🏛️|กระทรวงสาธารณสุข|https://www.moph.go.th/\n💳|สปสช. (สิทธิบัตรทอง)|https://www.nhso.go.th/\n🧾|ระบบจัดซื้อจัดจ้างภาครัฐ (e-GP)|https://process3.gprocurement.go.th/\n⚖️|ศูนย์ดำรงธรรม (ร้องเรียน)|https://www.damrongdham.moi.go.th/",
	);
}

function hos_mod( $key ) {
	$d = hos_defaults();
	return get_theme_mod( $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
}

function hos_style() {
	return 'vachira' === get_theme_mod( 'hos_style', 'green' ) ? 'vachira' : 'green';
}

/** แปลงข้อความหลายบรรทัด "a|b|c" เป็น array */
function hos_lines( $key ) {
	$out = array();
	foreach ( preg_split( '/\r?\n/', (string) hos_mod( $key ) ) as $line ) {
		$line = trim( $line );
		if ( '' !== $line ) {
			$out[] = array_map( 'trim', explode( '|', $line ) );
		}
	}
	return $out;
}

add_action( 'customize_register', function ( WP_Customize_Manager $wp ) {
	$d = hos_defaults();
	$wp->add_panel( 'hos', array( 'title' => 'ธีมโรงพยาบาล', 'priority' => 20 ) );

	$add = function ( $section, $key, $label, $type = 'text', $choices = array(), $desc = '' ) use ( $wp, $d ) {
		$sanitize = 'textarea' === $type ? 'sanitize_textarea_field' : ( 'url' === $type ? 'esc_url_raw' : 'sanitize_text_field' );
		$wp->add_setting( $key, array( 'default' => isset( $d[ $key ] ) ? $d[ $key ] : '', 'sanitize_callback' => $sanitize ) );
		$args = array( 'section' => $section, 'label' => $label, 'type' => $type, 'description' => $desc );
		if ( $choices ) {
			$args['choices'] = $choices;
		}
		$wp->add_control( $key, $args );
	};

	$wp->add_section( 'hos_look', array( 'title' => 'รูปแบบหน้าเว็บ', 'panel' => 'hos' ) );
	$add( 'hos_look', 'hos_style', 'ธีม', 'radio', array( 'green' => 'โมเดิร์นเขียว (กระทรวงสาธารณสุข)', 'vachira' => 'น้ำเงิน-ทอง (แบบวชิระภูเก็ต)' ) );
	$add( 'hos_look', 'hos_menu_source', 'แหล่งเมนูหลัก', 'radio', array( 'theme' => 'เมนูจัดหมวดของธีม (แนะนำ)', 'wp' => 'เมนูจาก รูปลักษณ์ › เมนู (ตำแหน่ง เมนูหลัก)' ) );
	$add( 'hos_look', 'hos_auto_translate', 'ปุ่ม TH | EN แปลภาษาอังกฤษอัตโนมัติ (Google Translate)', 'radio', array( 'on' => 'เปิด', 'off' => 'ปิด' ) );
	$add( 'hos_look', 'hos_tagline', 'ชื่อรองใต้โลโก้' );
	$add( 'hos_look', 'hos_announcement', 'ข้อความประกาศ (แถบวิ่ง) เว้นว่างเพื่อซ่อน', 'textarea' );

	$wp->add_section( 'hos_contact', array( 'title' => 'ข้อมูลติดต่อ', 'panel' => 'hos' ) );
	$add( 'hos_contact', 'hos_phone', 'โทรศัพท์' );
	$add( 'hos_contact', 'hos_fax', 'แฟกซ์' );
	$add( 'hos_contact', 'hos_email', 'อีเมล' );
	$add( 'hos_contact', 'hos_address', 'ที่อยู่', 'textarea' );
	$add( 'hos_contact', 'hos_hours', 'เวลาทำการ' );
	$add( 'hos_contact', 'hos_map_query', 'คำค้นหาบน Google Maps (หรือพิกัด lat,lng)' );
	$add( 'hos_contact', 'hos_facebook', 'Facebook URL', 'url' );
	$add( 'hos_contact', 'hos_line', 'LINE OA URL', 'url' );
	$add( 'hos_contact', 'hos_youtube', 'YouTube URL', 'url' );
	$add( 'hos_contact', 'hos_stats_url', 'ลิงก์ข้อมูลสถิติ', 'url' );
	$add( 'hos_contact', 'hos_footer_note', 'ข้อความท้ายเว็บ (เช่น นโยบายเว็บไซต์)', 'textarea' );

	$wp->add_section( 'hos_home', array( 'title' => 'หน้าแรก', 'panel' => 'hos' ) );
	$add( 'hos_home', 'hos_front_hero', 'ส่วนบนหน้าแรก (เมื่อหน้าแรกสร้างด้วยบล็อก iDevApp Hub)', 'radio', array( 'hub' => 'บล็อก Hub จัดเป็นแบนเนอร์เขียว (แก้ไขได้ในหน้า) — แนะนำ', 'on' => 'แบนเนอร์ของธีม (แก้ที่ ปรับแต่ง)', 'off' => 'บล็อก Hub หน้าตาเดิม' ) );
	$wp->add_setting( 'hos_news_months', array( 'default' => 6, 'sanitize_callback' => 'absint' ) );
	$wp->add_control( 'hos_news_months', array( 'section' => 'hos_home', 'type' => 'number', 'label' => 'ซ่อนข่าวที่เก่ากว่า (เดือน) บนหน้าแรก/บล็อกข่าว', 'description' => '0 = แสดงทั้งหมด · หน้ารวมข่าวและรายการย้อนหลังยังแสดงครบ', 'input_attrs' => array( 'min' => 0, 'max' => 60 ) ) );
	$wp->add_setting( 'hos_slide_months', array( 'default' => 6, 'sanitize_callback' => 'absint' ) );
	$wp->add_control( 'hos_slide_months', array( 'section' => 'hos_home', 'type' => 'number', 'label' => 'ซ่อนภาพสไลด์ที่อัปโหลดเกิน (เดือน)', 'description' => '0 = แสดงทั้งหมด', 'input_attrs' => array( 'min' => 0, 'max' => 60 ) ) );
	$add( 'hos_home', 'hos_hero_eyebrow', 'ข้อความเล็กเหนือชื่อ (Hero)' );
	$add( 'hos_home', 'hos_vision', 'วิสัยทัศน์', 'textarea' );
	$wp->add_setting( 'hos_hero_image', array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp->add_control( new WP_Customize_Image_Control( $wp, 'hos_hero_image', array( 'section' => 'hos_home', 'label' => 'ภาพพื้นหลัง Hero (ใช้เมื่อไม่มีสไลด์)' ) ) );
	$add( 'hos_home', 'hos_quick', 'ปุ่มลัด (บรรทัดละ: ไอคอน|ชื่อ|ลิงก์) ลิงก์ #news #jobs ฯลฯ = ไปยังหน้ารวมของส่วนนั้น', 'textarea' );
	$add( 'hos_home', 'hos_welcome', 'ข้อความต้อนรับ (ธีมน้ำเงิน-ทอง)', 'textarea' );
	$add( 'hos_home', 'hos_centers', 'ศูนย์ความเป็นเลิศ/คลินิก (บรรทัดละ: ไอคอน|ชื่อ|ลิงก์)', 'textarea' );
	$add( 'hos_home', 'hos_links', 'ลิงก์หน่วยงาน/บริการออนไลน์ (บรรทัดละ: ไอคอน|ชื่อ|ลิงก์)', 'textarea' );
	$add( 'hos_home', 'hos_stats', 'ตัวเลขสถิติ (บรรทัดละ: ตัวเลข|คำอธิบาย) · 3 บรรทัดแรกแสดงในแบนเนอร์', 'textarea' );
	$add( 'hos_home', 'hos_schedule_url', 'ลิงก์หน้าตารางแพทย์ออกตรวจ (เช่น /doctor-schedule/)' );
	$add( 'hos_home', 'hos_smc_note', 'หมายเหตุคลินิกพิเศษนอกเวลา (แสดงในตารางออกตรวจ ใต้กลุ่มที่มีคำว่า SMC/นอกเวลา · ใส่ HTML ได้ · เว้นว่าง = ไม่แสดง)', 'textarea' );

	// แหล่งข้อมูล: เลือกจาก post type / หมวดหมู่ที่มีอยู่แล้ว
	$wp->add_section( 'hos_sources', array( 'title' => 'แหล่งข้อมูลแต่ละส่วน', 'panel' => 'hos', 'description' => 'เลือกประเภทเนื้อหา (post type) และหมวดหมู่เดิมที่ใช้เก็บข้อมูลแต่ละส่วน' ) );
	$types = array( 'post' => 'เรื่อง (Posts)' );
	foreach ( get_post_types( array( 'public' => true, '_builtin' => false ), 'objects' ) as $pt ) {
		if ( ! in_array( $pt->name, array( 'elementor_library', 'e-landing-page', 'hos_slide' ), true ) ) {
			$types[ $pt->name ] = $pt->label . ' (' . $pt->name . ')';
		}
	}
	$terms = array( '' => '— ค่าเริ่มต้นตามข้อมูลเดิม —' );
	foreach ( get_taxonomies( array( 'public' => true ), 'objects' ) as $tax ) {
		if ( in_array( $tax->name, array( 'post_format', 'elementor_library_type' ), true ) ) {
			continue;
		}
		$tlist = get_terms( array( 'taxonomy' => $tax->name, 'hide_empty' => false, 'number' => 300 ) );
		foreach ( is_wp_error( $tlist ) ? array() : $tlist as $t ) {
			$terms[ $tax->name . ':' . $t->term_id ] = $tax->label . ' › ' . $t->name . ' (' . $t->count . ')';
		}
	}
	foreach ( hos_sources() as $key => $s ) {
		$wp->add_setting( "hos_src_{$key}_type", array( 'default' => 'post', 'sanitize_callback' => 'sanitize_key' ) );
		$wp->add_control( "hos_src_{$key}_type", array( 'section' => 'hos_sources', 'label' => $s['label'] . ' — ประเภท', 'type' => 'select', 'choices' => $types ) );
		$wp->add_setting( "hos_src_{$key}_term", array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ) );
		$wp->add_control( "hos_src_{$key}_term", array( 'section' => 'hos_sources', 'label' => $s['label'] . ' — หมวดหมู่', 'type' => 'select', 'choices' => $terms ) );
	}
} );
