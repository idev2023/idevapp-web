<?php
/**
 * The checks. Each finding: [cat (A01–A10), sev (critical|high|medium|low|info|ok), title, detail, how, fix (setting / action key), link [label, url], refs [[label, url]]]
 */
defined('ABSPATH') || exit;

function idw_sec_item($cat, $sev, $title, $detail = '', $how = '', $fix = '', $link = null, $refs = []) {
    return compact('cat', 'sev', 'title', 'detail', 'how', 'fix', 'link', 'refs');
}

/** GET (or POST) one of our own URLs, as an outsider would. */
function idw_sec_probe($url, $method = 'GET') {
    $r = wp_remote_request($url, ['method' => $method, 'timeout' => 8, 'redirection' => 0, 'sslverify' => false, 'cookies' => [], 'user-agent' => 'Mozilla/5.0 (iDevApp security check)', 'limit_response_size' => 300000]);
    if (is_wp_error($r)) return null;
    return ['code' => (int) wp_remote_retrieve_response_code($r), 'body' => (string) wp_remote_retrieve_body($r), 'headers' => wp_remote_retrieve_headers($r)];
}

/* ---------- CVE lookups: WPVulnerability (free, aggregates CVE / Wordfence / Patchstack / WPScan / JVN) ---------- */

function idw_sec_vuln_api($path) {
    $key = 'idw_sec_v_' . md5($path);
    $c = get_site_transient($key);
    if (is_array($c)) return $c;
    $r = wp_remote_get('https://www.wpvulnerability.net/' . $path, ['timeout' => 12, 'user-agent' => 'iDevApp-Website/' . IDW_SEC_VERSION]);
    if (is_wp_error($r)) return new WP_Error('idw_cve', $r->get_error_message());
    $code = (int) wp_remote_retrieve_response_code($r);
    $j = json_decode((string) wp_remote_retrieve_body($r), true);
    if ($code !== 200 || !is_array($j)) return new WP_Error('idw_cve', 'HTTP ' . $code);
    $list = (array) ($j['data']['vulnerability'] ?? []);
    set_site_transient($key, $list, 6 * HOUR_IN_SECONDS);
    return $list;
}

/** Does the vulnerability apply to this version? */
function idw_sec_vuln_applies($v, $version) {
    $op = (array) ($v['operator'] ?? []);
    $cmp = function ($a, $op, $b) {
        $map = ['lt' => '<', 'le' => '<=', 'gt' => '>', 'ge' => '>=', 'eq' => '==', '<' => '<', '<=' => '<=', '>' => '>', '>=' => '>=', '=' => '=='];
        return isset($map[$op]) ? version_compare($a, $b, $map[$op]) : true;
    };
    if (!empty($op['min_version']) && !$cmp($version, $op['min_operator'] ?? 'ge', $op['min_version'])) return false;
    if (!empty($op['max_version']) && !$cmp($version, $op['max_operator'] ?? 'le', $op['max_version'])) return false;
    if (empty($op['min_version']) && empty($op['max_version']) && empty($op['unfixed'])) return false;
    return true;
}

/** Findings for one product. $kind core|plugin|theme|php */
function idw_sec_vulns($kind, $slug, $version, $name) {
    $path = $kind === 'core' ? 'core/' . rawurlencode($version) . '/' : ($kind === 'php' ? 'php/' . rawurlencode($version) . '/' : $kind . '/' . rawurlencode($slug) . '/');
    $list = idw_sec_vuln_api($path);
    if (is_wp_error($list)) return $list;
    $out = [];
    foreach ($list as $v) {
        if (!is_array($v) || ($kind !== 'core' && $kind !== 'php' && !idw_sec_vuln_applies($v, $version))) continue;
        $refs = [];
        $ids = [];
        foreach ((array) ($v['source'] ?? []) as $s) {
            $id = (string) ($s['id'] ?? $s['name'] ?? '');
            if ($id === '') continue;
            $ids[] = $id;
            $link = (string) ($s['link'] ?? '');
            if ($link === '' && preg_match('/^CVE-\d{4}-\d+$/', $id)) $link = 'https://www.cve.org/CVERecord?id=' . $id;
            if ($link) $refs[$id] = [$id, $link];
        }
        $score = (float) ($v['impact']['cvss']['score'] ?? 0);
        $sev = $score >= 9 ? 'critical' : ($score >= 7 ? 'high' : ($score >= 4 ? 'medium' : ($score > 0 ? 'low' : 'medium')));
        $op = (array) ($v['operator'] ?? []);
        $fixed_in = !empty($op['max_version']) && in_array($op['max_operator'] ?? '', ['lt', '<'], true) ? $op['max_version'] : '';
        $unfixed = !empty($op['unfixed']) && $op['unfixed'] !== '0';
        $cve = array_values(array_filter($ids, function ($i) { return strpos($i, 'CVE-') === 0; }));
        $out[] = idw_sec_item('A03', $sev,
            $name . ' ' . $version . ': ' . wp_strip_all_tags((string) ($v['name'] ?? 'ช่องโหว่')),
            ($cve ? '<b>' . esc_html(implode(', ', array_slice($cve, 0, 3))) . '</b> · ' : '') . ($score ? 'CVSS ' . esc_html(number_format($score, 1)) : 'ยังไม่มีคะแนน CVSS') . ($unfixed ? ' · <b>ยังไม่มีเวอร์ชันที่แก้ไข</b>' : ''),
            $unfixed ? 'ยังไม่มีการแก้ไขจากผู้พัฒนา — พิจารณาปิดหรือเปลี่ยนไปใช้ปลั๊กอิน / ธีมอื่นจนกว่าจะมีเวอร์ชันแก้ไข' : ($fixed_in ? 'อัปเดตเป็นเวอร์ชัน ' . esc_html($fixed_in) . ' ขึ้นไป' : 'อัปเดตเป็นเวอร์ชันล่าสุด'),
            '', $kind === 'php' ? null : ['ไปหน้าอัปเดต', admin_url('update-core.php')], array_values(array_slice($refs, 0, 4)));
    }
    return $out;
}

/* ---------- the scan ---------- */

function idw_sec_run_scan() {
    global $wpdb, $wp_version;
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    require_once ABSPATH . 'wp-admin/includes/update.php';
    $I = [];
    $home = home_url('/');
    $front = idw_sec_probe($home);
    $h = $front['headers'] ?? [];
    $hard = idw_sec_hard();

    /* A01 Broken Access Control */
    $u = idw_sec_probe(rest_url('wp/v2/users'));
    $users_open = $u && $u['code'] === 200 && is_array(json_decode($u['body'], true)) && json_decode($u['body'], true);
    $a = idw_sec_probe(add_query_arg('author', 1, $home));
    $author_open = $a && in_array($a['code'], [301, 302], true) && strpos((string) ($a['headers']['location'] ?? ''), '/author/') !== false;
    $I[] = ($users_open || $author_open)
        ? idw_sec_item('A01', 'medium', 'บุคคลภายนอกดูรายชื่อบัญชีผู้ใช้ได้', ($users_open ? 'เปิด <code>/wp-json/wp/v2/users</code> แล้วเห็นรายชื่อ' : '') . ($author_open ? ($users_open ? ' และ ' : '') . '<code>?author=1</code> พาไปหน้าผู้เขียน (รู้ชื่อบัญชี)' : ''), 'ซ่อนรายชื่อผู้ใช้จากคนที่ไม่ได้ล็อกอิน เพื่อไม่ให้รู้ชื่อบัญชีสำหรับเดารหัสผ่าน', 'users_api')
        : idw_sec_item('A01', 'ok', 'รายชื่อบัญชีผู้ใช้ไม่เปิดเผย');
    $editor = !(defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT) && $hard['file_edit'] !== '1';
    $I[] = $editor ? idw_sec_item('A01', 'medium', 'แก้ไขไฟล์ธีม / ปลั๊กอินจากหลังบ้านได้', 'ถ้ารหัสผ่านผู้ดูแลหลุด ผู้บุกรุกจะฝังโค้ดอันตรายผ่านหน้า “ตัวแก้ไขไฟล์” ได้ทันที', 'ปิดตัวแก้ไขไฟล์ (หรือเพิ่ม <code>define(\'DISALLOW_FILE_EDIT\', true);</code> ใน wp-config.php)', 'file_edit') : idw_sec_item('A01', 'ok', 'ปิดตัวแก้ไขไฟล์ในหลังบ้านแล้ว');
    $up = wp_get_upload_dir();
    $l = idw_sec_probe(trailingslashit($up['baseurl']));
    $listing = $l && $l['code'] === 200 && stripos($l['body'], 'Index of') !== false;
    $I[] = $listing ? idw_sec_item('A01', 'medium', 'เปิดดูรายชื่อไฟล์ในโฟลเดอร์อัปโหลดได้', 'เข้า <code>/wp-content/uploads/</code> แล้วเห็นรายการไฟล์ทั้งหมด รวมถึงเอกสารที่ไม่ได้ลิงก์ไว้', 'ปิดการแสดงรายชื่อไฟล์ (Options -Indexes) — Nginx: ตั้ง <code>autoindex off;</code>', 'uploads_htaccess') : idw_sec_item('A01', 'ok', 'ไม่แสดงรายชื่อไฟล์ในโฟลเดอร์อัปโหลด');
    if (get_option('users_can_register') && get_option('default_role') !== 'subscriber') {
        $I[] = idw_sec_item('A01', 'critical', 'ใครก็สมัครสมาชิกแล้วได้สิทธิ์ “' . esc_html(get_option('default_role')) . '”', 'การสมัครสมาชิกเปิดอยู่ และสิทธิ์เริ่มต้นสูงกว่าสมาชิกทั่วไป', 'ตั้งสิทธิ์เริ่มต้นเป็น Subscriber หรือปิดการสมัครสมาชิก (ตั้งค่า → ทั่วไป)', 'registration');
    }

    /* A02 Security Misconfiguration */
    $need = ['x-content-type-options' => 'X-Content-Type-Options', 'x-frame-options' => 'X-Frame-Options', 'referrer-policy' => 'Referrer-Policy'];
    $miss = [];
    foreach ($need as $k => $n) if (empty($h[$k]) && !($k === 'x-frame-options' && !empty($h['content-security-policy']) && stripos($h['content-security-policy'], 'frame-ancestors') !== false)) $miss[] = $n;
    $I[] = $front === null ? idw_sec_item('A02', 'info', 'ตรวจหน้าเว็บจากภายนอกไม่ได้', 'เซิร์ฟเวอร์เรียกหน้าเว็บของตัวเองไม่ได้ (loopback) — บางข้อจึงไม่ได้ตรวจ', 'ตรวจ DNS / ไฟร์วอลล์ของเซิร์ฟเวอร์ หรือใช้ securityheaders.com ตรวจเพิ่มเติม')
        : ($miss ? idw_sec_item('A02', 'medium', 'ขาดส่วนหัวความปลอดภัย: ' . implode(', ', $miss), 'ส่วนหัวเหล่านี้ช่วยกัน clickjacking การเดาชนิดไฟล์ และการรั่วของลิงก์', 'เปิด “ส่วนหัวความปลอดภัย”', 'headers') : idw_sec_item('A02', 'ok', 'มีส่วนหัวความปลอดภัยครบ'));
    $x = idw_sec_probe(site_url('xmlrpc.php'), 'POST');
    $xml_on = $x && $x['code'] === 200 && stripos($x['body'], 'methodResponse') !== false;
    $I[] = $xml_on ? idw_sec_item('A02', 'medium', 'XML-RPC เปิดอยู่', '<code>xmlrpc.php</code> ใช้เดารหัสผ่านได้ครั้งละหลายร้อยรหัส และใช้โจมตีแบบ pingback', 'ปิด XML-RPC (ถ้าไม่ได้ใช้แอปหรือระบบภายนอกที่ต้องพึ่ง)', 'xmlrpc') : idw_sec_item('A02', 'ok', 'XML-RPC ปิดหรือถูกจำกัดแล้ว');
    $gen = $front && preg_match('/<meta[^>]+generator[^>]+WordPress\s*[\d.]+/i', $front['body']);
    $I[] = $gen ? idw_sec_item('A02', 'low', 'หน้าเว็บบอกเวอร์ชัน WordPress', 'พบ meta generator ที่ระบุเวอร์ชัน', 'ซ่อนเวอร์ชัน', 'generator') : idw_sec_item('A02', 'ok', 'หน้าเว็บไม่บอกเวอร์ชัน WordPress');
    $exposed = [];
    foreach (['readme.html' => 'readme', 'license.txt' => 'readme'] as $f => $fix) { $p = idw_sec_probe(site_url($f)); if ($p && $p['code'] === 200) $exposed[$f] = $fix; }
    if ($exposed) $I[] = idw_sec_item('A02', 'low', 'เปิดไฟล์ที่บอกเวอร์ชันได้: ' . implode(', ', array_keys($exposed)), '', 'ลบไฟล์ readme.html / license.txt', 'readme');
    $secret = [];
    foreach (['wp-config.php.bak', 'wp-config.php~', 'wp-config.bak', 'wp-config.old', '.env', '.git/HEAD', 'backup.zip', 'backup.sql', 'db.sql', 'wp-content/debug.log'] as $f) {
        $p = idw_sec_probe(site_url($f));
        if ($p && $p['code'] === 200 && strlen($p['body']) > 0 && stripos($p['body'], '<html') === false) $secret[] = $f;
    }
    if ($secret) {
        $only_log = $secret === ['wp-content/debug.log'];
        $I[] = idw_sec_item('A02', in_array('wp-config.php.bak', $secret, true) || in_array('.env', $secret, true) || in_array('wp-config.bak', $secret, true) || in_array('wp-config.php~', $secret, true) ? 'critical' : 'high', 'ดาวน์โหลดไฟล์ลับจากเว็บได้: ' . implode(', ', $secret), 'ไฟล์เหล่านี้อาจมีรหัสผ่านฐานข้อมูล เส้นทางไฟล์ หรือข้อมูลส่วนบุคคล', $only_log ? 'ย้าย debug.log ออกจากโฟลเดอร์เว็บ และปิด WP_DEBUG_LOG' : 'ลบไฟล์สำรอง / ไฟล์ .env ออกจากโฟลเดอร์เว็บทันที และเปลี่ยนรหัสผ่านฐานข้อมูล', $only_log ? 'debug_log' : 'root_htaccess');
    } else {
        $I[] = idw_sec_item('A02', 'ok', 'ไม่พบไฟล์สำรอง / ไฟล์ตั้งค่าที่ดาวน์โหลดได้');
    }
    // PHP runs inside uploads?
    $test = trailingslashit($up['basedir']) . 'idw-sec-' . wp_generate_password(10, false) . '.php';
    $token = wp_generate_password(16, false);
    if (@file_put_contents($test, '<?php echo "' . $token . '";')) { // phpcs:ignore
        $p = idw_sec_probe(trailingslashit($up['baseurl']) . basename($test));
        @unlink($test); // phpcs:ignore
        $runs = $p && $p['code'] === 200 && strpos($p['body'], $token) !== false;
        $I[] = $runs ? idw_sec_item('A02', 'high', 'ไฟล์ PHP ในโฟลเดอร์อัปโหลดทำงานได้', 'ถ้ามีช่องโหว่ให้อัปโหลดไฟล์ ผู้โจมตีจะวาง web shell แล้วสั่งงานเซิร์ฟเวอร์ได้', 'ห้ามรันสคริปต์ในโฟลเดอร์อัปโหลด — Nginx: <code>location ~* /uploads/.*\.php$ { deny all; }</code>', 'uploads_htaccess') : idw_sec_item('A02', 'ok', 'ไฟล์ PHP ในโฟลเดอร์อัปโหลดไม่ทำงาน');
    }

    /* A03 Software Supply Chain Failures */
    wp_version_check([], true);
    wp_update_plugins();
    wp_update_themes();
    $core = get_preferred_from_update_core();
    $core_new = $core && isset($core->response) && $core->response === 'upgrade' ? $core->current : '';
    $I[] = $core_new ? idw_sec_item('A03', 'high', 'WordPress ' . $wp_version . ' ไม่ใช่เวอร์ชันล่าสุด (' . esc_html($core_new) . ')', 'เวอร์ชันใหม่มักมีการแก้ช่องโหว่ด้านความปลอดภัย', 'อัปเดต WordPress', '', ['อัปเดต WordPress', admin_url('update-core.php')]) : idw_sec_item('A03', 'ok', 'WordPress ' . $wp_version . ' เป็นเวอร์ชันล่าสุด');
    $pu = get_site_transient('update_plugins');
    $plugins = get_plugins();
    $old = [];
    foreach ((array) ($pu->response ?? []) as $file => $r) $old[] = ($plugins[$file]['Name'] ?? $file) . ' → ' . ($r->new_version ?? '');
    $I[] = $old ? idw_sec_item('A03', count($old) > 3 ? 'high' : 'medium', 'ปลั๊กอินมีเวอร์ชันใหม่ ' . count($old) . ' รายการ', esc_html(implode(' · ', array_slice($old, 0, 8))), 'อัปเดตปลั๊กอิน และเปิดอัปเดตอัตโนมัติสำหรับปลั๊กอินที่เชื่อถือได้', '', ['อัปเดตปลั๊กอิน', admin_url('plugins.php?plugin_status=upgrade')]) : idw_sec_item('A03', 'ok', 'ปลั๊กอินทุกตัวเป็นเวอร์ชันล่าสุด');
    $tu = get_site_transient('update_themes');
    if (!empty($tu->response)) $I[] = idw_sec_item('A03', 'medium', 'ธีมมีเวอร์ชันใหม่ ' . count($tu->response) . ' รายการ', esc_html(implode(', ', array_keys($tu->response))), 'อัปเดตธีม', '', ['อัปเดตธีม', admin_url('themes.php')]);
    $inactive = array_diff(array_keys($plugins), (array) get_option('active_plugins', []));
    if (count($inactive) > 0) $I[] = idw_sec_item('A03', 'low', 'มีปลั๊กอินที่ไม่ได้ใช้ ' . count($inactive) . ' ตัว', esc_html(implode(', ', array_slice(array_map(function ($f) use ($plugins) { return $plugins[$f]['Name']; }, $inactive), 0, 8))), 'ลบปลั๊กอินที่ไม่ใช้ — ไฟล์ของปลั๊กอินที่ปิดอยู่ยังถูกเรียกตรงได้ถ้ามีช่องโหว่', '', ['จัดการปลั๊กอิน', admin_url('plugins.php?plugin_status=inactive')]);
    $themes = wp_get_themes();
    $extra_themes = array_diff(array_keys($themes), [get_stylesheet(), get_template()]);
    if (count($extra_themes) > 1) $I[] = idw_sec_item('A03', 'low', 'มีธีมที่ไม่ได้ใช้ ' . count($extra_themes) . ' ธีม', esc_html(implode(', ', $extra_themes)), 'เก็บธีมสำรองไว้ 1 ธีม ลบที่เหลือ', '', ['จัดการธีม', admin_url('themes.php')]);
    // PHP version (support dates: php.net/supported-versions.php)
    $php = PHP_VERSION;
    $eol = ['7.4' => '2022-11-28', '8.0' => '2023-11-26', '8.1' => '2025-12-31', '8.2' => '2026-12-31', '8.3' => '2027-12-31', '8.4' => '2028-12-31'];
    $mm = PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION;
    $end = $eol[$mm] ?? (version_compare($mm, '7.4', '<') ? '2000-01-01' : '');
    if ($end && strtotime($end) < time()) $I[] = idw_sec_item('A03', 'high', 'PHP ' . $php . ' หมดระยะสนับสนุนแล้ว (' . esc_html(wp_date('j M Y', strtotime($end))) . ')', 'ช่องโหว่ที่พบใหม่ใน PHP เวอร์ชันนี้จะไม่ได้รับการแก้ไข', 'ให้ผู้ดูแลเซิร์ฟเวอร์ / โฮสติ้งอัปเกรดเป็น PHP 8.3 ขึ้นไป', '', null, [['PHP supported versions', 'https://www.php.net/supported-versions.php']]);
    elseif ($end && strtotime($end) < time() + 120 * DAY_IN_SECONDS) $I[] = idw_sec_item('A03', 'medium', 'PHP ' . $php . ' จะหมดระยะสนับสนุน ' . esc_html(wp_date('j M Y', strtotime($end))), '', 'วางแผนอัปเกรดเป็น PHP 8.3 ขึ้นไป', '', null, [['PHP supported versions', 'https://www.php.net/supported-versions.php']]);
    else $I[] = idw_sec_item('A03', 'ok', 'PHP ' . $php . ' ยังได้รับการสนับสนุน');
    // CVE
    $cve_error = '';
    $cves = [];
    $r = idw_sec_vulns('core', 'wordpress', $wp_version, 'WordPress');
    if (is_wp_error($r)) $cve_error = $r->get_error_message(); else $cves = array_merge($cves, $r);
    if (!$cve_error) {
        foreach ($plugins as $file => $p) {
            $slug = strpos($file, '/') !== false ? dirname($file) : basename($file, '.php');
            if ($slug === 'idevapp-website') continue;
            $r = idw_sec_vulns('plugin', $slug, $p['Version'], $p['Name']);
            if (!is_wp_error($r)) $cves = array_merge($cves, $r);
        }
        foreach ($themes as $slug => $t) {
            if (in_array($slug, IDW_THEMES, true)) continue;
            $r = idw_sec_vulns('theme', $slug, $t->get('Version'), $t->get('Name'));
            if (!is_wp_error($r)) $cves = array_merge($cves, $r);
        }
        $r = idw_sec_vulns('php', 'php', $php, 'PHP');
        if (!is_wp_error($r)) $cves = array_merge($cves, array_slice($r, 0, 5));
    }
    $I = array_merge($I, $cves);
    if (!$cve_error && !$cves) $I[] = idw_sec_item('A03', 'ok', 'ไม่พบช่องโหว่ที่ประกาศแล้ว (CVE) ของ WordPress ปลั๊กอิน ธีม และ PHP ที่ใช้อยู่', 'ตรวจ ' . (count($plugins) + count($themes) + 2) . ' รายการกับฐานข้อมูล WPVulnerability');

    /* A04 Cryptographic Failures */
    $https = strpos(home_url(), 'https://') === 0;
    $I[] = $https ? idw_sec_item('A04', 'ok', 'เว็บใช้ HTTPS') : idw_sec_item('A04', 'high', 'เว็บยังไม่ใช้ HTTPS', 'รหัสผ่านและข้อมูลในแบบฟอร์ม (เช่นการลงทะเบียนผู้ป่วย) ถูกส่งแบบไม่เข้ารหัส', 'ติดตั้งใบรับรอง SSL แล้วเปิดใช้ HTTPS ทั้งเว็บ', '', ['ไปหน้า SSL', admin_url('admin.php?page=idw-ssl')]);
    if ($https) {
        $cert = function_exists('idw_ssl_remote_cert') ? idw_ssl_remote_cert(wp_parse_url(home_url(), PHP_URL_HOST)) : null;
        if (is_array($cert)) {
            $days = (int) floor(($cert['to'] - time()) / DAY_IN_SECONDS);
            $I[] = $days < 0 ? idw_sec_item('A04', 'critical', 'ใบรับรอง SSL หมดอายุแล้ว', 'หมดอายุ ' . esc_html(wp_date('j M Y', $cert['to'])), 'ต่ออายุใบรับรองแล้วติดตั้งใหม่', '', ['ไปหน้า SSL', admin_url('admin.php?page=idw-ssl')])
                : ($days < 21 ? idw_sec_item('A04', 'high', 'ใบรับรอง SSL จะหมดอายุใน ' . $days . ' วัน', 'ออกโดย ' . esc_html($cert['issuer']), 'ต่ออายุใบรับรอง', '', ['ไปหน้า SSL', admin_url('admin.php?page=idw-ssl')]) : idw_sec_item('A04', 'ok', 'ใบรับรอง SSL ใช้ได้อีก ' . $days . ' วัน', 'ออกโดย ' . esc_html($cert['issuer'])));
        }
        $I[] = empty($h['strict-transport-security']) ? idw_sec_item('A04', 'low', 'ยังไม่มี HSTS', 'เบราว์เซอร์อาจถูกหลอกให้ใช้ HTTP ในการเข้าครั้งแรก', 'เปิด “ส่วนหัวความปลอดภัย” (ส่ง HSTS ให้อัตโนมัติเมื่อใช้ HTTPS)', 'headers') : idw_sec_item('A04', 'ok', 'มี HSTS');
        if ($front && preg_match_all('#(?:src|href)=["\']http://[^"\']+#i', $front['body'], $mx) && count($mx[0]) > 0) $I[] = idw_sec_item('A04', 'low', 'หน้าแรกเรียกไฟล์ผ่าน http:// (mixed content) ' . count($mx[0]) . ' จุด', esc_html(implode(' ', array_slice(array_map(function ($s) { return substr($s, 5, 70); }, $mx[0]), 0, 3))), 'เปลี่ยนลิงก์รูป / สคริปต์เป็น https:// (หน้า SSL มีปุ่มช่วยแก้)', '', ['ไปหน้า SSL', admin_url('admin.php?page=idw-ssl')]);
    }
    $weak = [];
    foreach (['AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT'] as $k) if (!defined($k) || strlen((string) constant($k)) < 32 || strpos((string) constant($k), 'put your unique phrase') !== false) $weak[] = $k;
    $I[] = $weak ? idw_sec_item('A04', 'high', 'คีย์เข้ารหัสคุกกี้ (salts) ไม่ปลอดภัย: ' . implode(', ', $weak), 'คีย์สั้นหรือเป็นค่าตัวอย่าง ทำให้ปลอมคุกกี้เข้าสู่ระบบได้ง่ายขึ้น', 'สร้างคีย์ใหม่ที่ <a href="https://api.wordpress.org/secret-key/1.1/salt/" target="_blank" rel="noopener">api.wordpress.org/secret-key</a> แล้ววางแทนใน wp-config.php (ทุกคนจะต้องล็อกอินใหม่)') : idw_sec_item('A04', 'ok', 'คีย์เข้ารหัสคุกกี้ (salts) ตั้งไว้ถูกต้อง');

    /* A05 Injection */
    $roles = [];
    foreach (wp_roles()->roles as $rk => $rv) if ($rk !== 'administrator' && !empty($rv['capabilities']['unfiltered_html'])) $roles[] = translate_user_role($rv['name']);
    $I[] = ($roles && $hard['unfiltered_html'] !== '1' && !(defined('DISALLOW_UNFILTERED_HTML') && DISALLOW_UNFILTERED_HTML)) ? idw_sec_item('A05', 'medium', 'ผู้ที่ไม่ใช่ผู้ดูแลใส่สคริปต์ในเนื้อหาได้: ' . esc_html(implode(', ', $roles)), 'บัญชีบรรณาธิการที่ถูกเจาะจะฝัง JavaScript ที่ขโมยคุกกี้ผู้ดูแลได้ (Stored XSS)', 'ห้ามคนที่ไม่ใช่ผู้ดูแลใส่สคริปต์', 'unfiltered_html') : idw_sec_item('A05', 'ok', 'เฉพาะผู้ดูแลระบบที่ใส่สคริปต์ในเนื้อหาได้');
    $mimes = get_allowed_mime_types();
    $risky = array_values(array_filter(array_keys($mimes), function ($k) { return preg_match('/(^|\|)(svg|svgz|html?|js|xml|php|phtml|exe)(\||$)/', $k); }));
    $I[] = $risky ? idw_sec_item('A05', 'medium', 'อนุญาตให้อัปโหลดไฟล์ที่ฝังสคริปต์ได้: ' . esc_html(implode(', ', $risky)), 'ไฟล์ SVG / HTML สามารถมี JavaScript ที่ทำงานเมื่อเปิดไฟล์', 'ปิดการอัปโหลดชนิดไฟล์นี้ หรือใช้ปลั๊กอินที่ทำความสะอาด SVG ก่อนบันทึก') : idw_sec_item('A05', 'ok', 'ชนิดไฟล์ที่อัปโหลดได้ไม่มีไฟล์ที่ฝังสคริปต์');
    if ($wpdb->prefix === 'wp_') $I[] = idw_sec_item('A05', 'info', 'ตารางฐานข้อมูลใช้ชื่อขึ้นต้นมาตรฐาน wp_', 'ไม่ใช่ช่องโหว่ แต่ทำให้การโจมตีแบบ SQL injection อัตโนมัติง่ายขึ้นเล็กน้อย', 'สำหรับเว็บใหม่ ตั้ง <code>$table_prefix</code> เป็นค่าอื่นตอนติดตั้ง');

    /* A06 Insecure Design */
    if (get_option('users_can_register') && get_option('default_role') === 'subscriber') $I[] = idw_sec_item('A06', 'low', 'เปิดให้สมัครสมาชิก', 'เว็บหน่วยงานส่วนใหญ่ไม่ต้องให้คนทั่วไปสมัคร — เปิดไว้จะมีบัญชีปลอมจำนวนมาก', 'ปิด “ใครก็สามารถสมัครสมาชิกได้” ที่ ตั้งค่า → ทั่วไป ถ้าไม่ได้ใช้', '', ['ตั้งค่าทั่วไป', admin_url('options-general.php')]);
    if (get_option('default_comment_status') === 'open' && !get_option('comment_moderation') && !get_option('comment_previously_approved')) $I[] = idw_sec_item('A06', 'low', 'ความคิดเห็นแสดงทันทีโดยไม่ตรวจ', 'เปิดช่องให้สแปมและลิงก์อันตรายปรากฏบนเว็บหน่วยงาน', 'เปิด “ความคิดเห็นต้องได้รับการอนุมัติ” หรือปิดความคิดเห็น', '', ['ตั้งค่าความคิดเห็น', admin_url('options-discussion.php')]);
    if (!array_filter($I, function ($i) { return $i['cat'] === 'A06'; })) $I[] = idw_sec_item('A06', 'ok', 'การสมัครสมาชิกและความคิดเห็นตั้งไว้อย่างปลอดภัย');

    /* A07 Authentication Failures */
    $admins = get_users(['role' => 'administrator', 'fields' => ['user_login']]);
    $named = array_filter($admins, function ($u) { return in_array(strtolower($u->user_login), ['admin', 'administrator', 'root', 'test', 'webmaster'], true); });
    $I[] = $named ? idw_sec_item('A07', 'medium', 'บัญชีผู้ดูแลใช้ชื่อที่เดาง่าย: ' . esc_html(implode(', ', wp_list_pluck($named, 'user_login'))), 'ชื่อ admin เป็นชื่อแรกที่บอตลองเดารหัส', 'สร้างผู้ดูแลชื่อใหม่ ย้ายเนื้อหาไปให้ แล้วลบบัญชีเดิม', '', ['จัดการผู้ใช้', admin_url('users.php?role=administrator')]) : idw_sec_item('A07', 'ok', 'ชื่อบัญชีผู้ดูแลไม่ใช่ชื่อที่เดาง่าย');
    if (count($admins) > 3) $I[] = idw_sec_item('A07', 'low', 'มีผู้ดูแลระบบ ' . count($admins) . ' บัญชี', 'ยิ่งมีบัญชีสิทธิ์สูงมาก โอกาสถูกเจาะยิ่งมาก', 'ลดสิทธิ์บัญชีที่ไม่จำเป็นเป็นบรรณาธิการ', '', ['จัดการผู้ใช้', admin_url('users.php?role=administrator')]);
    $limiter = $hard['login_limit'] === '1' || is_plugin_active('wordfence/wordfence.php') || is_plugin_active('limit-login-attempts-reloaded/limit-login-attempts-reloaded.php');
    $I[] = $limiter ? idw_sec_item('A07', 'ok', 'จำกัดการล็อกอินผิดแล้ว') : idw_sec_item('A07', 'high', 'ไม่จำกัดจำนวนครั้งที่ล็อกอินผิด', 'บอตเดารหัสผ่านได้ไม่จำกัด', 'เปิด “จำกัดการล็อกอินผิด”', 'login_limit');
    $tfa = is_plugin_active('two-factor/two-factor.php') || is_plugin_active('wp-2fa/wp-2fa.php') || is_plugin_active('wordfence/wordfence.php') || is_plugin_active('google-authenticator/google-authenticator.php');
    $I[] = $tfa ? idw_sec_item('A07', 'ok', 'มีระบบยืนยันตัวตนสองขั้น') : idw_sec_item('A07', 'medium', 'ยังไม่มีการยืนยันตัวตนสองขั้น (2FA)', 'ถ้ารหัสผ่านผู้ดูแลรั่ว (เช่นใช้รหัสซ้ำกับเว็บอื่น) จะเข้าระบบได้ทันที', 'ติดตั้งปลั๊กอิน “Two Factor” จาก WordPress.org แล้วเปิดให้บัญชีผู้ดูแลทุกคน', '', ['ติดตั้ง Two Factor', admin_url('plugin-install.php?s=two-factor&tab=search&type=term')]);
    if (wp_is_application_passwords_available() && $hard['app_passwords'] !== '1') $I[] = idw_sec_item('A07', 'info', 'Application Passwords เปิดอยู่', 'ใช้เมื่อเชื่อมแอปหรือระบบอื่นผ่าน REST API', 'ปิดถ้าไม่ได้เชื่อมระบบภายนอก', 'app_passwords');
    if (!$https) $I[] = idw_sec_item('A07', 'high', 'หน้าเข้าสู่ระบบไม่เข้ารหัส', 'รหัสผ่านถูกส่งผ่านเครือข่ายแบบอ่านได้', 'ใช้ HTTPS', '', ['ไปหน้า SSL', admin_url('admin.php?page=idw-ssl')]);

    /* A08 Software or Data Integrity Failures */
    $locale = get_locale();
    $sums = function_exists('get_core_checksums') ? get_core_checksums($wp_version, $locale) : false;
    if (!$sums && $locale !== 'en_US') $sums = get_core_checksums($wp_version, 'en_US');
    if (is_array($sums)) {
        $bad = [];
        foreach ($sums as $file => $md5) {
            if (strpos($file, 'wp-content/') === 0 || in_array($file, ['readme.html', 'license.txt', 'wp-config-sample.php'], true)) continue;
            $path = ABSPATH . $file;
            if (is_file($path) && md5_file($path) !== $md5) $bad[] = $file;
            if (count($bad) > 20) break;
        }
        $I[] = $bad ? idw_sec_item('A08', 'high', 'ไฟล์ของ WordPress ถูกแก้ไข ' . count($bad) . ' ไฟล์', esc_html(implode(', ', array_slice($bad, 0, 6))), 'ติดตั้ง WordPress เวอร์ชันเดิมซ้ำ (แผงควบคุม → อัปเดต → ติดตั้งใหม่) แล้วตรวจหาสาเหตุ', '', ['ติดตั้งใหม่', admin_url('update-core.php')]) : idw_sec_item('A08', 'ok', 'ไฟล์ของ WordPress ตรงกับต้นฉบับ');
    } else {
        $I[] = idw_sec_item('A08', 'info', 'ตรวจความถูกต้องของไฟล์ WordPress ไม่ได้', 'ดึงค่า checksum จาก api.wordpress.org ไม่ได้');
    }
    $php_in_up = [];
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($up['basedir'], FilesystemIterator::SKIP_DOTS));
    $n = 0;
    foreach ($it as $f) {
        if (++$n > 20000) break;
        if (preg_match('/\.(php[0-9]?|phtml|phar)$/i', $f->getFilename()) && $f->getFilename() !== 'index.php') $php_in_up[] = str_replace($up['basedir'], 'uploads', $f->getPathname());
    }
    $I[] = $php_in_up ? idw_sec_item('A08', 'critical', 'พบไฟล์ PHP ในโฟลเดอร์อัปโหลด ' . count($php_in_up) . ' ไฟล์', esc_html(implode(', ', array_slice($php_in_up, 0, 5))), 'ตรวจสอบไฟล์ทันที — ถ้าไม่ได้ตั้งใจวางไว้ อาจเป็น web shell ให้ลบ เปลี่ยนรหัสผ่านทั้งหมด และปิดการรันสคริปต์ในโฟลเดอร์อัปโหลด', 'uploads_htaccess') : idw_sec_item('A08', 'ok', 'ไม่พบไฟล์ PHP แปลกปลอมในโฟลเดอร์อัปโหลด');
    $auto = function_exists('idw_auto_update_on') && idw_auto_update_on();
    $I[] = $auto ? idw_sec_item('A08', 'ok', 'ปลั๊กอินและธีมของ iDevApp อัปเดตอัตโนมัติจากแหล่งที่ตรวจสอบแล้ว') : idw_sec_item('A08', 'low', 'ปิดอัปเดตอัตโนมัติของ iDevApp Website', '', 'เปิดอัปเดตอัตโนมัติ เพื่อรับการแก้ไขความปลอดภัยภายใน 12 ชั่วโมง', '', ['ไปหน้าอัปเดต', admin_url('admin.php?page=idw-updates')]);

    /* A09 Security Logging and Alerting Failures */
    $I[] = $hard['log'] === '1' ? idw_sec_item('A09', 'ok', 'บันทึกเหตุการณ์ความปลอดภัยอยู่') : idw_sec_item('A09', 'medium', 'ไม่ได้บันทึกเหตุการณ์ความปลอดภัย', 'ถ้าถูกเจาะจะไม่รู้ว่าเกิดอะไร เมื่อไร จากที่ไหน', 'เปิด “บันทึกเหตุการณ์ความปลอดภัย”', 'log');
    $email = get_option('admin_email');
    $I[] = (is_email($email) && !preg_match('/@(example\.(com|org|net)|localhost)$/i', $email)) ? idw_sec_item('A09', 'ok', 'อีเมลผู้ดูแลระบบใช้ได้', 'แจ้งเตือนสำคัญของ WordPress ส่งไปที่ ' . esc_html($email)) : idw_sec_item('A09', 'medium', 'อีเมลผู้ดูแลระบบใช้ไม่ได้', esc_html($email), 'ตั้งเป็นอีเมลที่มีคนอ่านจริง — WordPress ใช้แจ้งเตือนข้อผิดพลาดร้ายแรงและการกู้คืน', '', ['ตั้งค่าทั่วไป', admin_url('options-general.php')]);
    $fails = array_filter((array) get_option('idw_sec_log', []), function ($l) { return $l['type'] === 'login_failed' && $l['t'] > time() - DAY_IN_SECONDS; });
    if (count($fails) >= 20) $I[] = idw_sec_item('A09', 'medium', 'มีการล็อกอินผิด ' . count($fails) . ' ครั้งใน 24 ชั่วโมง', 'อาจกำลังถูกเดารหัสผ่าน', 'ตรวจบันทึกเหตุการณ์ ตั้งรหัสผ่านที่ยาว และเปิด 2FA', '', ['ดูบันทึก', admin_url('admin.php?page=idw-security&tab=log')]);

    /* A10 Mishandling of Exceptional Conditions */
    $show = defined('WP_DEBUG') && WP_DEBUG && (!defined('WP_DEBUG_DISPLAY') || WP_DEBUG_DISPLAY);
    $I[] = $show ? idw_sec_item('A10', 'high', 'แสดงข้อผิดพลาด PHP ให้ผู้เข้าชมเห็น (WP_DEBUG)', 'ข้อความผิดพลาดบอกเส้นทางไฟล์ ชื่อตาราง และโครงสร้างระบบ', 'ใน wp-config.php ตั้ง <code>define(\'WP_DEBUG\', false);</code> หรือ <code>define(\'WP_DEBUG_DISPLAY\', false);</code>') : idw_sec_item('A10', 'ok', 'ปิดการแสดง debug ให้ผู้เข้าชม');
    $disp = filter_var(ini_get('display_errors'), FILTER_VALIDATE_BOOLEAN) || ini_get('display_errors') === 'stderr';
    if ($disp && !$show) $I[] = idw_sec_item('A10', 'medium', 'PHP ตั้ง display_errors = On', 'ข้อผิดพลาดก่อน WordPress โหลดอาจแสดงบนหน้าเว็บ', 'ตั้ง display_errors = Off ใน php.ini / แผงควบคุมโฮสติ้ง');
    $leak = $front && preg_match('#<b>(Warning|Notice|Deprecated|Fatal error|Parse error)</b>:|(Warning|Fatal error): .+ in /.+ on line \d+#', $front['body']);
    $I[] = $leak ? idw_sec_item('A10', 'high', 'หน้าแรกแสดงข้อความผิดพลาดของ PHP', 'ผู้เข้าชมเห็นเส้นทางไฟล์บนเซิร์ฟเวอร์', 'ปิดการแสดงข้อผิดพลาด และแก้ปลั๊กอิน / ธีมที่ทำให้เกิดข้อผิดพลาด') : ($front ? idw_sec_item('A10', 'ok', 'หน้าเว็บไม่แสดงข้อผิดพลาดของ PHP') : null);
    if (defined('WP_DISABLE_FATAL_ERROR_HANDLER') && WP_DISABLE_FATAL_ERROR_HANDLER) $I[] = idw_sec_item('A10', 'low', 'ปิดระบบจัดการข้อผิดพลาดร้ายแรงของ WordPress', 'เมื่อปลั๊กอินพังจะเข้าโหมดกู้คืนไม่ได้', 'ลบ WP_DISABLE_FATAL_ERROR_HANDLER ออกจาก wp-config.php');
    $p404 = idw_sec_probe(home_url('/idw-not-found-' . wp_generate_password(6, false, false)));
    if ($p404 && $p404['code'] === 200) $I[] = idw_sec_item('A10', 'low', 'หน้าที่ไม่มีอยู่ตอบกลับเป็น 200 แทน 404', 'ทำให้เครื่องมือค้นหาและระบบตรวจสอบเข้าใจผิด', 'ตรวจธีม / ปลั๊กอินที่จัดการหน้า 404');

    $I = array_values(array_filter($I));
    // score: start at 100, minus weights of open findings (capped per category)
    $w = idw_sec_sev();
    $per = [];
    foreach ($I as $i) $per[$i['cat']] = min($i['sev'] === 'critical' ? 30 : 15, max($per[$i['cat']] ?? 0, 0) + $w[$i['sev']][2]);
    $score = max(0, 100 - array_sum($per));
    return ['time' => time(), 'score' => $score, 'items' => $I, 'cve_error' => $cve_error, 'wp' => $wp_version, 'php' => PHP_VERSION];
}
