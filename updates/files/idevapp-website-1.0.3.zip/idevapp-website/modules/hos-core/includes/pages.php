<?php
/**
 * หน้าเว็บสำหรับธีม iDevApp แบบที่ 1: สร้างด้วยบล็อกมาตรฐานของ WordPress (แก้ไขได้ตรงหน้า)
 * เนื้อหามาจากธีม (hos_page_content_home / hos_page_contents) โดยใช้ชื่อ ที่อยู่ และเบอร์โทรที่ตั้งไว้
 */
defined( 'ABSPATH' ) || exit;

function hos_wys_ready() {
	return function_exists( 'hos_page_content_home' ) && function_exists( 'hos_page_contents' );
}

/** เขียนเนื้อหาให้หน้า: หน้าที่มีอยู่แล้วจะไม่ถูกเขียนทับ เว้นแต่ $replace */
function hos_put_page( $post, $slug, $title, $content, $replace = false ) {
	if ( $post && 'page' === $post->post_type ) {
		if ( ! $replace ) {
			return $post->ID;
		}
		wp_update_post( wp_slash( array( 'ID' => $post->ID, 'post_content' => $content ) ) );
		$id = $post->ID;
	} else {
		$id = wp_insert_post( wp_slash( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug, 'post_content' => $content ) ) );
	}
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, '_wp_page_template', 'default' );
		update_post_meta( $id, '_hos_wysiwyg', 1 );
	}
	return $id;
}

/** สร้างหน้าแรกและหน้าอื่น ๆ ของธีมแบบที่ 1 · คืนรายชื่อหน้าที่สร้าง */
function hos_build_wysiwyg_pages( $replace = false ) {
	if ( ! hos_wys_ready() ) {
		return new WP_Error( 'no_theme', 'กรุณาเปิดใช้ธีม iDevApp แบบที่ 1 ก่อน' );
	}
	$done  = array();
	$front = get_post( (int) get_option( 'page_on_front' ) );
	$id    = hos_put_page( $front, 'home', 'หน้าแรก', hos_page_content_home( '' ), $replace );
	if ( $id && ! is_wp_error( $id ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $id );
	}
	$done[] = 'หน้าแรก';
	foreach ( hos_page_contents() as $slug => $pg ) {
		hos_put_page( get_page_by_path( $slug ), $slug, $pg[0], $pg[1], $replace );
		$done[] = $pg[0];
	}
	return $done;
}

/** หน้าแบบนี้เปิดด้วยตัวแก้ไขบล็อกเสมอ (แม้เปิด Classic Editor อยู่) */
add_filter( 'use_block_editor_for_post', function ( $use, $post ) {
	return ( $post && get_post_meta( $post->ID, '_hos_wysiwyg', true ) ) ? true : $use;
}, 999, 2 );

/** บริการทางการแพทย์ทั่วไปของโรงพยาบาล (แก้ได้ในแถบขวาของบล็อก “การ์ดบริการ”) */
function hos_service_card_items() {
	$sched = home_url( '/doctor-schedule/' );
	$c     = function ( $q ) use ( $sched ) {
		return add_query_arg( 'clinic', $q, $sched );
	};
	$t    = function ( $th, $en ) {
		return array( 'th' => $th, 'en' => $en );
	};
	$link = $t( 'ดูตารางออกตรวจ', 'Clinic schedule' );
	$rows = array(
		array( 'emergency', 'rose', 'อุบัติเหตุและฉุกเฉิน 24 ชม.', 'Emergency 24/7', 'ห้องฉุกเฉินพร้อมทีมแพทย์ พยาบาล และรถพยาบาลตลอด 24 ชั่วโมง โทร 1669', 'Emergency room, doctors, nurses and ambulance around the clock. Call 1669.', 'tel:1669', $t( 'โทร 1669', 'Call 1669' ) ),
		array( 'stethoscope', 'mint', 'ผู้ป่วยนอก / ตรวจโรคทั่วไป', 'Outpatient & general clinic', 'ตรวจรักษาโรคทั่วไป คัดกรอง และส่งต่อแพทย์เฉพาะทาง ในเวลาราชการ', 'General check-ups, screening and specialist referral during office hours.', $c( 'ทั่วไป' ), $link ),
		array( 'thermometer', 'sky', 'อายุรกรรม', 'Internal medicine', 'เบาหวาน ความดัน โรคหัวใจ โรคไต และโรคเรื้อรังอื่น ๆ', 'Diabetes, hypertension, heart, kidney and other chronic diseases.', $c( 'อายุรกรรม' ), $link ),
		array( 'bone', 'orange', 'ศัลยกรรม / ศัลยกรรมกระดูก', 'Surgery & orthopaedics', 'ผ่าตัดทั่วไป กระดูกและข้อ อุบัติเหตุ พร้อมห้องผ่าตัดและวิสัญญี', 'General surgery, bones and joints, trauma, with operating theatres and anaesthesia.', $c( 'ศัลยกรรม' ), $link ),
		array( 'pregnant', 'pink', 'สูติ-นรีเวชกรรม', 'Obstetrics & gynaecology', 'ฝากครรภ์ ห้องคลอด ตรวจภายใน และดูแลสุขภาพสตรี', 'Antenatal care, delivery room and women’s health.', $c( 'สูติ' ), $link ),
		array( 'baby', 'amber', 'กุมารเวชกรรม', 'Paediatrics', 'ดูแลเด็กป่วย วัคซีน ตรวจพัฒนาการ และทารกแรกเกิด', 'Sick children, vaccines, development checks and newborn care.', $c( 'กุมาร' ), $link ),
		array( 'eye', 'indigo', 'จักษุ / หู คอ จมูก', 'Eye & ENT', 'ตรวจรักษาโรคตา ต้อกระจก และโรคหู คอ จมูก', 'Eye diseases, cataract, and ear, nose and throat care.', $c( 'ตา' ), $link ),
		array( 'tooth', 'teal', 'ทันตกรรม', 'Dental care', 'ตรวจฟัน ขูดหินปูน อุดฟัน ถอนฟัน และทันตกรรมเฉพาะทาง', 'Check-ups, scaling, fillings, extractions and specialist dentistry.', $c( 'ทันต' ), $link ),
		array( 'leaf', 'green', 'แพทย์แผนไทย', 'Thai traditional medicine', 'นวด ประคบ อบสมุนไพร และยาสมุนไพร', 'Massage, herbal compress, herbal sauna and herbal medicine.', $c( 'แผนไทย' ), $link ),
		array( 'xray', 'blue', 'รังสีวิทยาและห้องปฏิบัติการ', 'Radiology & laboratory', 'เอกซเรย์ อัลตราซาวด์ และตรวจทางห้องปฏิบัติการ', 'X-ray, ultrasound and laboratory tests.', '', $t( '', '' ) ),
		array( 'wheelchair', 'lavender', 'เวชกรรมฟื้นฟู / กายภาพบำบัด', 'Rehabilitation', 'กายภาพบำบัด ฟื้นฟูผู้ป่วยหลังผ่าตัด และผู้ป่วยโรคหลอดเลือดสมอง', 'Physiotherapy and rehabilitation after surgery or stroke.', $c( 'กายภาพ' ), $link ),
		array( 'star', 'amber', 'คลินิกพิเศษนอกเวลาราชการ', 'After-hours special clinic', 'พบแพทย์เฉพาะทางนอกเวลาราชการ — แก้วันและเวลาให้ตรงกับของโรงพยาบาล', 'See a specialist after office hours — edit the days and times.', $c( 'นอกเวลา' ), $link ),
	);
	$items = array();
	foreach ( $rows as $r ) {
		$items[] = array( 'icon' => $r[0], 'tone' => $r[1], 'title' => $t( $r[2], $r[3] ), 'text' => $t( $r[4], $r[5] ), 'url' => $r[6], 'linkText' => $r[7], 'image' => '', 'imageMode' => 'cover' );
	}
	return $items;
}

/** ส่วน “บริการทางการแพทย์” เป็นบล็อกการ์ดบริการของ Hub (แก้ทุกการ์ดได้ในแถบขวา) หรือ '' ถ้าไม่ได้เปิดโมดูล Hub */
function hos_service_cards_block() {
	if ( ! function_exists( 'ihub_block_markup' ) ) {
		return '';
	}
	return ihub_block_markup( 'cards', array(
		'kicker'    => array( 'th' => 'OUR SERVICES', 'en' => 'OUR SERVICES' ),
		'title'     => array( 'th' => 'บริการทางการแพทย์', 'en' => 'Our services' ),
		'columns'   => 4,
		'iconStyle' => 'soft',
		'iconSize'  => 'large',
		'align'     => 'left',
		'items'     => hos_service_card_items(),
	), array( 'background' => 'light', 'spacing' => 'normal', 'anchor' => 'services', 'hidden' => false ) );
}

/** หน้าแรกที่สร้างไว้ก่อนมีส่วน "บริการของเรา": เพิ่มการ์ดบริการต่อจากปุ่มลัด (ครั้งเดียว) */
function hos_add_home_services( $force = false ) {
	if ( ! function_exists( 'hosp_services' ) ) {
		return 'notheme';
	}
	$pid = (int) get_option( 'page_on_front' );
	if ( ! $pid || ! get_post( $pid ) ) {
		return 'nopage';
	}
	$hub    = hos_service_cards_block();
	$blocks = parse_blocks( (string) get_post_field( 'post_content', $pid ) );
	$at     = -1;
	foreach ( $blocks as $i => $b ) {
		$cls = (string) ( $b['attrs']['className'] ?? '' );
		if ( 'idevapp/cards' === $b['blockName'] && ( 'services' === ( $b['attrs']['settings']['anchor'] ?? '' ) || 'บริการทางการแพทย์' === ( $b['attrs']['data']['title']['th'] ?? '' ) ) && ! $force ) {
			return 'exists';
		}
		if ( false !== strpos( $cls, 'hos-services' ) ) {
			if ( ! $hub ) {
				return 'exists';
			}
			array_splice( $blocks, $i, 1 ); // the plain version is replaced by the editable Hub cards
			$at = $i;
			break;
		}
		if ( false !== strpos( $cls, 'hos-quick-g' ) ) {
			$at = $i + 1;
		}
	}
	if ( $at < 0 ) {
		$at = min( 2, count( $blocks ) );
	}
	array_splice( $blocks, $at, 0, parse_blocks( $hub ? $hub : hosp_services() ) );
	kses_remove_filters();
	wp_update_post( array( 'ID' => $pid, 'post_content' => wp_slash( serialize_blocks( $blocks ) ) ) );
	kses_init_filters();
	return 'added';
}
add_action( 'admin_init', function () {
	if ( get_option( 'hos_home_services_v2' ) || ! current_user_can( 'edit_pages' ) || get_stylesheet() !== 'idevapp-theme-1' ) {
		return;
	}
	$r = hos_add_home_services();
	if ( in_array( $r, array( 'added', 'exists' ), true ) && function_exists( 'ihub_block_markup' ) ) {
		update_option( 'hos_home_services_v2', $r, false ); // checked again once the Hub module is switched on
	}
} );
