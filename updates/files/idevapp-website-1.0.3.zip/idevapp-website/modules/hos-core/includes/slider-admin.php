<?php
/**
 * หน้า “สไลด์หน้าแรก”: ดูตัวอย่างสด · เพิ่มหลายรูปพร้อมกัน · ลากเพื่อเรียง · เปิด / ปิด · ตั้งช่วงวันที่แสดง · ลิงก์ · ตั้งเวลาเปลี่ยนสไลด์
 * Slides stay posts of type hos_slide, so every theme / shortcode keeps working.
 */
defined( 'ABSPATH' ) || exit;

function hos_slides_interval() {
	return max( 2, min( 20, (float) get_option( 'hos_slide_interval', 5.5 ) ) );
}

add_action( 'admin_menu', function () {
	add_menu_page( 'สไลด์หน้าแรก', 'สไลด์หน้าแรก', 'edit_posts', 'hos-slides', 'hos_slides_page', 'dashicons-images-alt2', 21 );
} );

/* the old list / edit screens lead here */
add_action( 'load-edit.php', function () {
	if ( 'hos_slide' === ( $_GET['post_type'] ?? '' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		wp_safe_redirect( admin_url( 'admin.php?page=hos-slides' ) );
		exit;
	}
} );

add_action( 'admin_enqueue_scripts', function () {
	if ( 'hos-slides' !== ( $_GET['page'] ?? '' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	wp_enqueue_media();
	wp_enqueue_style( 'idw-admin' );
	wp_enqueue_style( 'hos-slides', HOS_CORE_URL . 'assets/slides.css', array( 'idw-admin' ), HOS_CORE_VER );
	wp_enqueue_script( 'hos-slides', HOS_CORE_URL . 'assets/slides.js', array( 'jquery', 'jquery-ui-sortable' ), HOS_CORE_VER, true );
} );

/** All slides for the editor (any status), in order. */
function hos_slides_for_editor() {
	$out    = array();
	$months = max( 0, (int) get_theme_mod( 'hos_slide_months', 6 ) );
	foreach ( get_posts( array( 'post_type' => 'hos_slide', 'post_status' => array( 'publish', 'draft', 'future', 'pending', 'private' ), 'numberposts' => 200, 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'DESC' ) ) ) as $s ) {
		$img_id = (int) get_post_thumbnail_id( $s );
		$url    = $img_id ? wp_get_attachment_image_url( $img_id, 'large' ) : (string) get_post_meta( $s->ID, '_hos_slide_image', true );
		$meta   = $img_id ? wp_get_attachment_metadata( $img_id ) : array();
		$up     = $img_id ? (int) get_post_time( 'U', true, $img_id ) : 0;
		$out[]  = array(
			'id'    => $s->ID,
			'img'   => $img_id,
			'url'   => (string) $url,
			'w'     => (int) ( $meta['width'] ?? 0 ),
			'h'     => (int) ( $meta['height'] ?? 0 ),
			'old'   => $months && $up && $up < strtotime( '-' . $months . ' months' ),
			'title' => $s->post_title,
			'sub'   => $s->post_excerpt,
			'link'  => (string) get_post_meta( $s->ID, '_hos_slide_link', true ),
			'on'    => 'publish' === $s->post_status,
			'from'  => (string) get_post_meta( $s->ID, '_hos_slide_from', true ),
			'until' => (string) get_post_meta( $s->ID, '_hos_slide_until', true ),
		);
	}
	return $out;
}

add_action( 'admin_post_hos_slides_save', function () {
	if ( ! current_user_can( 'edit_posts' ) || ! check_admin_referer( 'hos_slides_save' ) ) {
		wp_die( 'ไม่มีสิทธิ์', 403 );
	}
	$list = json_decode( wp_unslash( $_POST['slides'] ?? '[]' ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- every field is sanitised below
	$keep = array();
	$date = function ( $v ) {
		$v = sanitize_text_field( (string) $v );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '';
	};
	foreach ( is_array( $list ) ? $list : array() as $i => $s ) {
		$id  = (int) ( $s['id'] ?? 0 );
		$img = (int) ( $s['img'] ?? 0 );
		if ( $id && ( 'hos_slide' !== get_post_type( $id ) || ! current_user_can( 'edit_post', $id ) ) ) {
			continue;
		}
		if ( ! $id && ! $img ) {
			continue;
		}
		$arr = array(
			'post_type'    => 'hos_slide',
			'post_title'   => sanitize_text_field( $s['title'] ?? '' ),
			'post_excerpt' => sanitize_textarea_field( $s['sub'] ?? '' ),
			'post_status'  => ! empty( $s['on'] ) ? 'publish' : 'draft',
			'menu_order'   => (int) $i,
		);
		if ( $id ) {
			$arr['ID'] = $id;
			wp_update_post( wp_slash( $arr ) );
		} else {
			$id = wp_insert_post( wp_slash( $arr ) );
			if ( is_wp_error( $id ) || ! $id ) {
				continue;
			}
		}
		if ( $img && 'attachment' === get_post_type( $img ) ) {
			set_post_thumbnail( $id, $img );
		}
		update_post_meta( $id, '_hos_slide_link', esc_url_raw( (string) ( $s['link'] ?? '' ) ) );
		foreach ( array( 'from', 'until' ) as $k ) {
			$v = $date( $s[ $k ] ?? '' );
			if ( $v ) {
				update_post_meta( $id, '_hos_slide_' . $k, $v );
			} else {
				delete_post_meta( $id, '_hos_slide_' . $k );
			}
		}
		$keep[] = $id;
	}
	foreach ( get_posts( array( 'post_type' => 'hos_slide', 'post_status' => 'any', 'numberposts' => 200, 'fields' => 'ids' ) ) as $old ) {
		if ( ! in_array( (int) $old, $keep, true ) && current_user_can( 'delete_post', $old ) ) {
			wp_trash_post( $old );
		}
	}
	update_option( 'hos_slide_interval', max( 2, min( 20, (float) ( $_POST['interval'] ?? 5.5 ) ) ) );
	set_theme_mod( 'hos_slide_months', max( 0, min( 60, (int) ( $_POST['months'] ?? 6 ) ) ) );
	do_action( 'litespeed_purge_all' );
	wp_safe_redirect( admin_url( 'admin.php?page=hos-slides&saved=' . count( $keep ) ) );
	exit;
} );

function hos_slides_page() {
	$slides = hos_slides_for_editor();
	$pages  = get_pages( array( 'sort_column' => 'menu_order,post_title', 'number' => 200 ) );
	$own    = function_exists( 'idw_open' );
	if ( $own ) {
		idw_open( 'สไลด์หน้าแรก', 'ภาพแบนเนอร์ที่หมุนเวียนบนหน้าแรก — เพิ่มทีละหลายรูป ลากเพื่อเรียงลำดับ ตั้งวันที่แสดง และดูตัวอย่างได้ทันที' );
	} else {
		echo '<div class="wrap idw"><div class="idw-body"><h1>สไลด์หน้าแรก</h1>';
	}
	if ( isset( $_GET['saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		echo '<div class="idw-note">บันทึกแล้ว — หน้าแรกแสดงสไลด์ใหม่แล้ว <a href="' . esc_url( home_url( '/' ) ) . '" target="_blank" rel="noopener">ดูหน้าเว็บ ↗</a></div>';
	}
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" id="hs-form">';
	wp_nonce_field( 'hos_slides_save' );
	echo '<input type="hidden" name="action" value="hos_slides_save"><input type="hidden" name="slides" id="hs-data">';
	echo '<div class="hs-top"><div class="idw-card hs-preview"><div class="hs-stage" id="hs-stage"><div class="hs-empty"><span class="dashicons dashicons-format-gallery"></span><b>ยังไม่มีสไลด์ที่แสดง</b><span>กด “เพิ่มรูป” เพื่อเริ่ม</span></div></div><div class="hs-pv-bar"><span class="hs-pv-title" id="hs-pv-title"></span><span class="hs-dots" id="hs-dots"></span></div></div>';
	echo '<div class="idw-card hs-side"><h2>ตั้งค่า</h2>';
	echo '<label class="idw-field">เปลี่ยนสไลด์ทุก<span class="hs-unit"><input type="number" name="interval" min="2" max="20" step="0.5" value="' . esc_attr( hos_slides_interval() ) . '" class="idw-in" id="hs-interval"> วินาที</span></label>';
	echo '<label class="idw-field">ซ่อนรูปที่อัปโหลดนานกว่า<span class="hs-unit"><input type="number" name="months" min="0" max="60" value="' . esc_attr( (int) get_theme_mod( 'hos_slide_months', 6 ) ) . '" class="idw-in"> เดือน</span><small>0 = แสดงทุกรูป · กันแบนเนอร์งานที่ผ่านไปนานแล้วค้างบนเว็บ</small></label>';
	echo '<div class="hs-tip"><b>ขนาดที่แนะนำ</b> 1920 × 1080 px (16:9) ไฟล์ JPG ไม่เกิน 500 KB · ข้อความสำคัญอยู่กลางภาพ</div>';
	echo '<button type="button" class="idw-btn acc lg" id="hs-add" style="width:100%"><span class="dashicons dashicons-plus-alt2"></span>เพิ่มรูป (เลือกได้หลายรูป)</button></div></div>';
	echo '<div class="hs-head"><h2>สไลด์ทั้งหมด <small id="hs-count"></small></h2><span class="hs-hint"><span class="dashicons dashicons-move"></span>ลากการ์ดเพื่อเรียงลำดับ</span></div>';
	echo '<div class="hs-grid" id="hs-grid"></div>';
	echo '<datalist id="hs-pages"><option value="' . esc_url( home_url( '/' ) ) . '">หน้าแรก</option>';
	foreach ( $pages as $p ) {
		echo '<option value="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( $p->post_title ) . '</option>';
	}
	echo '</datalist>';
	echo '<div class="idw-savebar"><span class="msg" id="hs-msg">ยังไม่มีการแก้ไข</span><a class="idw-btn link" href="' . esc_url( home_url( '/' ) ) . '" target="_blank" rel="noopener">ดูหน้าเว็บ ↗</a><button class="idw-btn pri" id="hs-save"><span class="dashicons dashicons-yes"></span>บันทึก</button></div></form>';
	echo '<script>window.HOS_SLIDES=' . wp_json_encode( $slides, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ) . ';</script>';
	if ( $own ) {
		idw_close();
	} else {
		echo '</div></div>';
	}
}
add_action( 'load-toplevel_page_hos-slides', function () {
	global $title;
	$title = 'สไลด์หน้าแรก'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- the program-mode menu may hide this item
} );
