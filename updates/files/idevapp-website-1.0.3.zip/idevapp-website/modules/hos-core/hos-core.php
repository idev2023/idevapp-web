<?php
/**
 * Module: ระบบเว็บโรงพยาบาล — ประเภทข่าว/ประกาศ ฟิลด์เสริม ไฟล์แนบ ปีงบประมาณ (ITA) สไลด์หน้าแรก
 * หน้าเข้าสู่ระบบ (ซ่อน URL ได้) และ shortcode [hos_posts] [hos_slider] · ใช้ได้กับทุกธีม
 */
defined( 'ABSPATH' ) || exit;
if ( defined( 'HOS_CORE_VER' ) ) {
	return;
}

define( 'HOS_CORE_VER', IDW_VERSION );
define( 'HOS_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'HOS_CORE_URL', plugin_dir_url( __FILE__ ) );

require_once HOS_CORE_DIR . 'includes/post-types.php';   // ประเภทเนื้อหา
require_once HOS_CORE_DIR . 'includes/fields.php';       // ฟิลด์เสริม (get_field)
require_once HOS_CORE_DIR . 'includes/fields-compat.php';
require_once HOS_CORE_DIR . 'includes/attachments.php';  // ไฟล์แนบเอกสาร / ปีงบประมาณ
require_once HOS_CORE_DIR . 'includes/slider.php';       // สไลด์หน้าแรก
require_once HOS_CORE_DIR . 'includes/slider-admin.php'; // หน้าจัดการสไลด์
require_once HOS_CORE_DIR . 'includes/login.php';        // URL เข้าสู่ระบบ + หน้าเข้าสู่ระบบ
require_once HOS_CORE_DIR . 'includes/shortcodes.php';   // [hos_posts] [hos_slider]
require_once HOS_CORE_DIR . 'includes/pages.php';        // สร้างหน้าเว็บสำหรับธีมแบบที่ 1
require_once HOS_CORE_DIR . 'includes/admin-fixes.php';  // ตัวแก้ไขบล็อกหลังบ้าน

register_activation_hook( __FILE__, function () {
	hos_register_slide_type();
	flush_rewrite_rules();
} );

/* หน้าตาพื้นฐานของ [hos_posts] และ [hos_slider] เมื่อใช้กับธีมอื่น (ธีมแบบที่ 1 มีหน้าตาของตัวเอง) */
add_action( 'wp_enqueue_scripts', function () {
	if ( function_exists( 'hos_theme_slider' ) ) {
		return;
	}
	wp_register_style( 'hos-core-any-theme', false, array(), HOS_CORE_VER );
	wp_enqueue_style( 'hos-core-any-theme' );
	wp_add_inline_style( 'hos-core-any-theme', '.hos-sc-list{list-style:none;margin:0;padding:0}.hos-sc-list li{display:flex;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px solid rgba(0,0,0,.08)}.hos-sc-list small{opacity:.65;white-space:nowrap}.hos-sc-more{text-align:right;font-weight:600}.hos-sc-slider{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;gap:0;border-radius:14px;scrollbar-width:none}.hos-sc-slider::-webkit-scrollbar{display:none}.hos-sc-slider>a,.hos-sc-slider>img{flex:0 0 100%;scroll-snap-align:start}.hos-sc-slider img{display:block;width:100%;height:auto;aspect-ratio:1920/700;object-fit:cover}' );
} );

