<?php
/**
 * Look at the old website from its address: platform, site details, menu, pages and news.
 */
defined('ABSPATH') || exit;

function idw_imp_get($url, $args = []) {
    $r = wp_safe_remote_get($url, $args + ['timeout' => 20, 'redirection' => 5, 'limit_response_size' => 4 * MB_IN_BYTES, 'user-agent' => 'Mozilla/5.0 (compatible; iDevApp-Website-Import/' . IDW_IMP_VERSION . '; +https://idevapp.me/)']);
    if (is_wp_error($r)) return $r;
    $code = (int) wp_remote_retrieve_response_code($r);
    if ($code >= 400) return new WP_Error('idw_imp', 'HTTP ' . $code . ' — ' . $url);
    return $r;
}

function idw_imp_dom($html) {
    $d = new DOMDocument();
    libxml_use_internal_errors(true);
    $html = (string) $html;
    if (!preg_match('/<meta[^>]+charset/i', $html)) $html = '<meta charset="utf-8">' . $html;
    $d->loadHTML($html, LIBXML_NOWARNING | LIBXML_NOERROR);
    libxml_clear_errors();
    return $d;
}

/** Absolute URL from a link on page $base. */
function idw_imp_abs($href, $base) {
    $href = trim(html_entity_decode((string) $href));
    if ($href === '' || preg_match('#^(javascript|mailto|tel|data|\#)#i', $href)) return '';
    if (preg_match('#^https?://#i', $href)) return $href;
    $b = wp_parse_url($base);
    $root = $b['scheme'] . '://' . $b['host'] . (isset($b['port']) ? ':' . $b['port'] : '');
    if (strpos($href, '//') === 0) return $b['scheme'] . ':' . $href;
    if ($href[0] === '/') return $root . $href;
    $path = isset($b['path']) ? preg_replace('#/[^/]*$#', '/', $b['path']) : '/';
    $u = $root . $path . $href;
    while (preg_match('#/[^/]+/\.\./#', $u)) $u = preg_replace('#/[^/]+/\.\./#', '/', $u, 1);
    return str_replace('/./', '/', $u);
}
function idw_imp_same_site($url, $site) {
    $a = strtolower(preg_replace('/^www\./', '', (string) wp_parse_url($url, PHP_URL_HOST)));
    $b = strtolower(preg_replace('/^www\./', '', (string) wp_parse_url($site, PHP_URL_HOST)));
    return $a !== '' && $a === $b;
}
function idw_imp_text($node) { return trim(preg_replace('/\s+/u', ' ', (string) $node->textContent)); }

/** Phone, e-mail, address, social links from the text of a page. */
function idw_imp_contacts($html, $text) {
    $out = ['phone' => '', 'email' => '', 'address' => '', 'facebook' => '', 'line' => '', 'youtube' => ''];
    if (preg_match('/(?:โทร(?:ศัพท์)?\.?|Tel\.?|Phone)\s*:?\s*(0[\d\s-]{7,14}\d)/iu', $text, $m) || preg_match('/\b(0\d{1,2}[\s-]?\d{3}[\s-]?\d{3,4})\b/u', $text, $m)) $out['phone'] = trim(preg_replace('/\s+/', ' ', $m[1]));
    if (preg_match('/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/', $text, $m) && !preg_match('/\.(png|jpe?g|gif|webp)$/i', $m[0])) $out['email'] = $m[0];
    if (preg_match('/((?:เลขที่\s*)?\d{1,4}(?:\/\d+)?\s*(?:หมู่(?:ที่)?\s*\d+)?[^\n|]{0,80}?(?:ต\.|ตำบล|แขวง)\s*\S+\s*(?:อ\.|อำเภอ|เขต)\s*\S+\s*(?:จ\.|จังหวัด)\s*\S+\s*\d{5})/u', $text, $m)) $out['address'] = trim(preg_replace('/\s+/u', ' ', $m[1]));
    if (preg_match('#https?://(?:www\.|m\.)?facebook\.com/[^"\'\s<>]+#i', $html, $m)) $out['facebook'] = esc_url_raw($m[0]);
    if (preg_match('#https?://(?:lin\.ee|line\.me)/[^"\'\s<>]+#i', $html, $m)) $out['line'] = esc_url_raw($m[0]);
    if (preg_match('#https?://(?:www\.)?youtube\.com/(?:@|channel/|c/|user/)[^"\'\s<>]+#i', $html, $m)) $out['youtube'] = esc_url_raw($m[0]);
    return $out;
}

/** Most used brand colour: theme-color, then CSS custom properties / inline colours that are not grey. */
function idw_imp_color($html, $dom) {
    foreach ($dom->getElementsByTagName('meta') as $m) if (strtolower($m->getAttribute('name')) === 'theme-color' && preg_match('/^#[0-9a-f]{6}$/i', $m->getAttribute('content'))) return strtolower($m->getAttribute('content'));
    preg_match_all('/#([0-9a-f]{6})\b/i', $html, $mm);
    $n = [];
    foreach ($mm[1] as $h) {
        [$r, $g, $b] = sscanf(strtolower($h), '%02x%02x%02x');
        $max = max($r, $g, $b); $min = min($r, $g, $b);
        if ($max - $min < 40 || $max < 50 || $min > 215) continue; // grey, black, white, pastel
        $n['#' . strtolower($h)] = ($n['#' . strtolower($h)] ?? 0) + 1;
    }
    arsort($n);
    return (string) (array_key_first($n) ?? '');
}

/** Menu tree from the biggest navigation list: [['t','u','c'=>[...]]] */
function idw_imp_menu($dom, $base) {
    $xp = new DOMXPath($dom);
    $best = null; $bestN = 0;
    foreach ($xp->query('//nav//ul[not(ancestor::ul)] | //header//ul[not(ancestor::ul)] | //*[contains(@class,"menu") or contains(@id,"menu") or contains(@class,"nav")]/ul[not(ancestor::ul)] | //ul[contains(@class,"menu") and not(ancestor::ul)]') as $ul) {
        $links = $xp->query('.//a[@href]', $ul)->length;
        if ($links > $bestN && $links < 200 && !preg_match('/footer|social|lang/i', $ul->getAttribute('class') . ' ' . ($ul->parentNode instanceof DOMElement ? $ul->parentNode->getAttribute('class') : ''))) { $best = $ul; $bestN = $links; }
    }
    if (!$best) return [];
    $walk = function ($ul, $depth) use (&$walk, $xp, $base) {
        $out = [];
        foreach ($xp->query('./li', $ul) as $li) {
            $a = $xp->query('./a | ./*/a', $li)->item(0);
            if (!$a) continue;
            $t = idw_imp_text($a);
            if ($t === '' || mb_strlen($t) > 80) continue;
            $item = ['t' => $t, 'u' => idw_imp_abs($a->getAttribute('href'), $base), 'c' => []];
            $sub = $xp->query('./ul | ./*/ul', $li)->item(0);
            if ($sub && $depth < 3) $item['c'] = $walk($sub, $depth + 1);
            $out[] = $item;
        }
        return $out;
    };
    return $walk($best, 0);
}

/** URLs from sitemaps (up to $max). */
function idw_imp_sitemap_urls($site, $max = 600) {
    $cands = [];
    $robots = idw_imp_get(trailingslashit($site) . 'robots.txt', ['timeout' => 8]);
    if (!is_wp_error($robots) && preg_match_all('/^\s*Sitemap:\s*(\S+)/mi', wp_remote_retrieve_body($robots), $m)) $cands = $m[1];
    $cands = array_merge($cands, [trailingslashit($site) . 'wp-sitemap.xml', trailingslashit($site) . 'sitemap_index.xml', trailingslashit($site) . 'sitemap.xml']);
    $urls = []; $seen = [];
    $queue = array_values(array_unique($cands));
    while ($queue && count($urls) < $max && count($seen) < 30) {
        $sm = array_shift($queue);
        if (isset($seen[$sm])) continue;
        $seen[$sm] = 1;
        $r = idw_imp_get($sm, ['timeout' => 10]);
        if (is_wp_error($r)) continue;
        $xml = wp_remote_retrieve_body($r);
        if (stripos($xml, '<urlset') === false && stripos($xml, '<sitemapindex') === false) continue;
        preg_match_all('#<loc>\s*(?:<!\[CDATA\[)?\s*([^<\]]+?)\s*(?:\]\]>)?\s*</loc>#i', $xml, $m);
        foreach ($m[1] as $u) {
            $u = html_entity_decode(trim($u));
            if (stripos($xml, '<sitemapindex') !== false) { if (!preg_match('/(users|author|tag|attachment)/i', $u)) $queue[] = $u; }
            elseif (idw_imp_same_site($u, $site)) $urls[$u] = 1;
        }
    }
    return array_keys($urls);
}

/** Is this URL a news item / post rather than a page? */
function idw_imp_is_news($u) {
    $p = (string) wp_parse_url($u, PHP_URL_PATH) . '?' . (string) wp_parse_url($u, PHP_URL_QUERY);
    return (bool) preg_match('#/(news|post|posts|blog|article|articles|activity|activities|announce\w*|procurement|jobs?|ข่าว|ประกาศ|กิจกรรม)/|/20\d\d/\d\d/|/25\d\d/|[?&]p=\d+|view=article|node/\d+#iu', urldecode($p));
}

/** The whole analysis. */
function idw_imp_analyze($url) {
    $url = esc_url_raw(trim($url));
    if (!preg_match('#^https?://#i', $url)) $url = 'https://' . ltrim($url, '/');
    if (!wp_http_validate_url($url)) return new WP_Error('idw_imp', 'ที่อยู่เว็บไม่ถูกต้อง หรือเป็นที่อยู่ภายในเครือข่ายที่ไม่อนุญาต');
    $r = idw_imp_get($url);
    if (is_wp_error($r) && strpos($url, 'https://') === 0) { $url = 'http://' . substr($url, 8); $r = idw_imp_get($url); }
    if (is_wp_error($r)) return new WP_Error('idw_imp', 'เปิดเว็บเดิมไม่ได้: ' . $r->get_error_message());
    $html = (string) wp_remote_retrieve_body($r);
    $p = wp_parse_url($url);
    $site = $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '') . '/';
    $dom = idw_imp_dom($html);
    $xp = new DOMXPath($dom);
    $meta = function ($k) use ($xp) { $n = $xp->query('//meta[@property="' . $k . '" or @name="' . $k . '"]/@content')->item(0); return $n ? trim($n->nodeValue) : ''; };
    $gen = $meta('generator');
    $platform = 'html';
    $api = '';
    $link = $xp->query('//link[@rel="https://api.w.org/"]/@href')->item(0);
    if ($link || stripos($gen, 'WordPress') !== false || strpos($html, '/wp-content/') !== false) { $platform = 'wordpress'; $api = $link ? $link->nodeValue : $site . 'wp-json/'; }
    elseif (stripos($gen, 'Joomla') !== false || strpos($html, '/media/jui/') !== false || strpos($html, 'option=com_') !== false) $platform = 'joomla';
    elseif (stripos($gen, 'Drupal') !== false || strpos($html, 'Drupal.settings') !== false) $platform = 'drupal';
    elseif (stripos($html, 'wix.com') !== false) $platform = 'wix';
    elseif (stripos($html, 'sites.google.com') !== false) $platform = 'google-sites';
    $title_tag = $xp->query('//title')->item(0);
    $name = $meta('og:site_name');
    if ($name === '' && $title_tag) {
        $parts = array_values(array_filter(array_map('trim', preg_split('/\s+[|\-–—:]\s+/u', idw_imp_text($title_tag))), function ($x) { return $x !== '' && !preg_match('/^(หน้าแรก|หน้าหลัก|home|homepage|welcome|ยินดีต้อนรับ.*)$/iu', $x); }));
        usort($parts, function ($a, $b) { return mb_strlen($b) <=> mb_strlen($a); });
        $name = $parts[0] ?? '';
    }
    if ($name === '') $name = $p['host'];
    $logo = '';
    foreach ($xp->query('//header//img | //*[contains(@class,"logo") or contains(@id,"logo")]//img | //img[contains(@class,"logo") or contains(@src,"logo") or contains(@alt,"โลโก้") or contains(@alt,"logo")]') as $img) { $s = $img->getAttribute('src') ?: $img->getAttribute('data-src'); if ($s) { $logo = idw_imp_abs($s, $url); break; } }
    if (!$logo) { $ic = $xp->query('//link[contains(@rel,"apple-touch-icon") or contains(@rel,"icon")]/@href')->item(0); if ($ic) $logo = idw_imp_abs($ic->nodeValue, $url); }
    $body = $xp->query('//body')->item(0);
    $text = $body ? idw_imp_text($body) : '';
    $out = [
        'url' => $url, 'site' => $site, 'platform' => $platform, 'api' => $api, 'time' => time(),
        'info' => ['name' => wp_strip_all_tags($name), 'tagline' => wp_strip_all_tags($meta('description')), 'logo' => esc_url_raw($logo), 'color' => idw_imp_color($html, $dom)] + idw_imp_contacts($html, $text),
        'menu' => idw_imp_menu($dom, $url), 'pages' => [], 'news' => [], 'cats' => [], 'counts' => [],
    ];
    if ($platform === 'wordpress') {
        $wp = idw_imp_wp_inventory($api);
        if (!is_wp_error($wp)) { $out = array_merge($out, $wp); $out['source'] = 'rest'; return $out; }
        $out['rest_error'] = $wp->get_error_message();
    }
    // other platforms: sitemap, else links of the home page and the menu
    $urls = idw_imp_sitemap_urls($site);
    if (!$urls) {
        foreach ($xp->query('//a[@href]') as $a) { $u = idw_imp_abs($a->getAttribute('href'), $url); if ($u && idw_imp_same_site($u, $site)) $urls[] = strtok($u, '#'); }
        $urls = array_values(array_unique($urls));
    }
    $urls = array_values(array_filter($urls, function ($u) { return !preg_match('/\.(jpe?g|png|gif|webp|svg|pdf|docx?|xlsx?|pptx?|zip|rar|mp4|mp3|css|js)(\?|$)/i', $u) && !preg_match('#/(wp-admin|wp-login|feed|login|administrator|user/login|cart|search)\b#i', $u); }));
    $titles = [];
    foreach ($xp->query('//a[@href]') as $a) { $u = strtok(idw_imp_abs($a->getAttribute('href'), $url), '#'); $t = idw_imp_text($a); if ($u && $t !== '' && mb_strlen($t) < 150 && !isset($titles[$u])) $titles[$u] = $t; }
    foreach (array_slice($urls, 0, 600) as $u) {
        if (rtrim($u, '/') === rtrim($site, '/')) continue;
        $item = ['u' => $u, 't' => $titles[$u] ?? urldecode(trim((string) wp_parse_url($u, PHP_URL_PATH), '/'))];
        if (preg_match('#^/(news|blog|posts?|articles?|activit\w*|ข่าว\w*|category/[^/]+|tag/[^/]+|page/\d+)/?(index\.\w+)?$#iu', urldecode((string) wp_parse_url($u, PHP_URL_PATH)))) continue; // lists, not content
        if (idw_imp_is_news($u)) $out['news'][] = $item; else $out['pages'][] = $item;
    }
    $out['source'] = 'html';
    $out['counts'] = ['pages' => count($out['pages']), 'news' => count($out['news'])];
    return $out;
}

/** WordPress source: everything through its REST API. */
function idw_imp_wp_inventory($api) {
    $api = trailingslashit($api);
    $count = function ($type) use ($api) {
        $r = idw_imp_get($api . 'wp/v2/' . $type . '?per_page=1&_fields=id', ['timeout' => 12]);
        return is_wp_error($r) ? -1 : (int) wp_remote_retrieve_header($r, 'x-wp-total');
    };
    $posts = $count('posts');
    if ($posts < 0) return new WP_Error('idw_imp', 'REST API ของเว็บเดิมถูกปิด');
    $pages = [];
    for ($pg = 1; $pg <= 5; $pg++) {
        $r = idw_imp_get($api . 'wp/v2/pages?per_page=100&page=' . $pg . '&_fields=id,link,title,parent,menu_order', ['timeout' => 20]);
        if (is_wp_error($r)) break;
        $j = json_decode(wp_remote_retrieve_body($r), true);
        if (!is_array($j) || !$j) break;
        foreach ($j as $p) $pages[] = ['id' => (int) $p['id'], 'u' => $p['link'], 't' => wp_strip_all_tags(html_entity_decode($p['title']['rendered'] ?? '')), 'parent' => (int) ($p['parent'] ?? 0)];
        if (count($j) < 100) break;
    }
    $cats = [];
    $r = idw_imp_get($api . 'wp/v2/categories?per_page=100&_fields=id,name,slug,count,parent', ['timeout' => 15]);
    if (!is_wp_error($r)) foreach ((array) json_decode(wp_remote_retrieve_body($r), true) as $c) if (!empty($c['id'])) $cats[] = ['id' => (int) $c['id'], 'name' => html_entity_decode($c['name']), 'slug' => $c['slug'], 'count' => (int) $c['count']];
    return ['pages' => $pages, 'cats' => $cats, 'news' => [], 'counts' => ['pages' => count($pages), 'news' => $posts, 'media' => $count('media')]];
}
