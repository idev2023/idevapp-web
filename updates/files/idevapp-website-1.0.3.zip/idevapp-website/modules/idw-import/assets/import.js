/* ย้ายเว็บเดิม: run the import one item at a time */
jQuery(function ($) {
  var C = window.IDW_IMP || {}, stop = false;
  function count() { $('.imp-cnt').each(function () { var g = $(this).data('for'); $(this).text($('input[data-group="' + g + '"]:checked').length + ' / ' + $('input[data-group="' + g + '"]').length); }); }
  $(document).on('change', 'input[data-group]', count); count();
  $('[data-all]').on('click', function (e) { e.preventDefault(); $('input[data-group="' + $(this).data('all') + '"]').prop('checked', true); count(); });
  $('[data-none]').on('click', function (e) { e.preventDefault(); $('input[data-group="' + $(this).data('none') + '"]').prop('checked', false); count(); });

  function jobs() {
    var j = [];
    if ($('input[data-job=info]').prop('checked')) j.push({ kind: 'info', color: $('#imp-color').prop('checked') ? 1 : '', label: 'ข้อมูลเว็บไซต์' });
    $('input[data-group=page]:checked').each(function () { var k = $(this).data('kind'); j.push(k === 'wp-page' ? { kind: k, id: this.value } : { kind: k, url: this.value }); });
    if ($('input[data-job=wp-posts]').prop('checked')) j.push({ kind: 'wp-post', page: 1, paged: 1 });
    $('input[data-group=news]:checked').each(function () { j.push({ kind: 'news', url: this.value, cat: $('#imp-cat').val() }); });
    if ($('input[data-job=menu]').prop('checked')) j.push({ kind: 'menu' });
    return j;
  }
  function log(ok, text, link, extra) {
    var $li = $('<li>').addClass(ok ? 'ok' : 'bad').text(text + (extra || ''));
    if (link) $li.append(' ', $('<a target="_blank">').attr('href', link).text('แก้ไข'));
    $('.imp-log').prepend($li);
  }
  $('#imp-go').on('click', function () {
    var list = jobs();
    if (!list.length) { alert('เลือกอย่างน้อย 1 รายการ'); return; }
    var total = list.length, done = 0, okN = 0, badN = 0, postTotal = +$('input[data-job=wp-posts]').data('total') || 0, posts = 0;
    if (postTotal) total += Math.ceil(postTotal / 10) - 1;
    stop = false;
    $('#imp-go').prop('disabled', true); $('#imp-stop').prop('hidden', false); $('.imp-prog').prop('hidden', false); $('.imp-log').empty();
    var common = { action: 'idw_imp_item', _ajax_nonce: C.nonce, media: $('#imp-media').prop('checked') ? 1 : '', dates: $('#imp-dates').prop('checked') ? 1 : '', status: $('#imp-draft').prop('checked') ? 'draft' : 'publish' };
    function prog(t) { var p = Math.min(100, Math.round(done / total * 100)); $('.imp-prog .bar i').css('width', p + '%'); $('.imp-prog .st').text(t || ('นำเข้าแล้ว ' + okN + ' รายการ' + (badN ? ' · ไม่สำเร็จ ' + badN : '') + ' · ' + p + '%')); }
    function next() {
      if (stop || !list.length) {
        $('#imp-go').prop('disabled', false).html('นำเข้าอีกครั้ง'); $('#imp-stop').prop('hidden', true);
        prog(stop ? 'หยุดแล้ว — กดนำเข้าอีกครั้งเพื่อทำต่อ (รายการที่นำเข้าแล้วจะถูกอัปเดต)' : 'เสร็จแล้ว: นำเข้า ' + okN + ' รายการ' + (badN ? ' · ไม่สำเร็จ ' + badN : ''));
        if (!stop) $('.imp-prog .bar i').css('width', '100%');
        return;
      }
      var job = list.shift();
      prog('กำลังนำเข้า: ' + (job.label || job.url || (job.kind === 'wp-post' ? 'ข่าวชุดที่ ' + job.page : job.kind === 'menu' ? 'เมนู' : 'หน้า #' + job.id)) + ' …');
      $.post(C.ajax, $.extend({}, common, job)).done(function (r) {
        if (r && r.success) {
          (r.data.items || []).forEach(function (it) { if (it.ok) okN++; else badN++; log(it.ok, (it.up ? '↻ ' : '✓ ') + (it.t || '(ไม่มีชื่อ)'), it.edit, it.e ? ' — ' + it.e : (it.empty ? ' — ไม่พบเนื้อหา ตรวจหน้านี้เอง' : '')); });
          if (job.kind === 'wp-post' && r.data.more) list.unshift({ kind: 'wp-post', page: job.page + 1 });
        } else { badN++; log(false, '✕ ' + (job.url || job.kind) + ' — ' + ((r && r.data) || 'ผิดพลาด')); }
      }).fail(function (x) { badN++; log(false, '✕ ' + (job.url || job.kind) + ' — HTTP ' + x.status); })
        .always(function () { done++; next(); });
    }
    next();
  });
  $('#imp-stop').on('click', function () { stop = true; $(this).prop('hidden', true); });
});
