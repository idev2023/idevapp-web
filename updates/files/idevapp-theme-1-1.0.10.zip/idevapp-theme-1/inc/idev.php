<?php
/**
 * รองรับ plugin ของ iDev / iDevApp
 * - iDevApp Hub (idevapp-hub): บล็อกออกแบบหน้า (idevapp/*), ประกาศ, สลับภาษา TH/EN, โหมดไว้ทุกข์, ปุ่มนัดหมาย, โลโก้สำหรับ SEO
 * - iDev News Ticker, iDev Post Attachments: ธีมวางตำแหน่งให้เอง (add_theme_support)
 * - iDev Bilingual: ปุ่มสลับภาษา
 * - plugin อื่น (Appointments, Patient Registration, Clinic Schedule, Maps, Org Chart, Thai Holidays, Store, Cookie Consent,
 *   Popup Notice, i-Clinic, i-Drug): ใช้ shortcode ในหน้าได้ตามปกติ ธีมเพิ่มกรอบ/ความกว้างให้เหมาะ
 */
defined( 'ABSPATH' ) || exit;

function hos_hub_active() {
	return function_exists( 'ihub_t' ) && function_exists( 'ihub_setting' );
}

add_action( 'after_setup_theme', function () {
	add_theme_support( 'idev-news-ticker' );       // ธีมแสดง ticker ใต้หัวเว็บเอง
	add_theme_support( 'idev-post-attachments' );  // ธีมแสดงไฟล์แนบในหน้าข่าวเอง
}, 20 );

/** โลโก้สำหรับ iDevApp Hub (SEO / app mode เรียกฟังก์ชันนี้) */
if ( ! function_exists( 'idevapp_logo_url' ) ) {
	function idevapp_logo_url() {
		$id = (int) get_theme_mod( 'custom_logo' );
		$u  = $id ? wp_get_attachment_image_url( $id, 'full' ) : '';
		return $u ? $u : get_template_directory_uri() . '/assets/logo.png';
	}
}

add_action( 'wp_enqueue_scripts', function () {
	if ( hos_hub_active() ) {
		// สไตล์บล็อกของ Hub (โหลดก่อน theme.css ให้สีธีมเป็นหลัก)
		wp_enqueue_style( 'hos-hub-compat', get_template_directory_uri() . '/assets/hub-compat.css', array(), hos_asset_ver( 'hub-compat.css' ) );
		wp_deregister_style( 'hos-theme' );
		wp_enqueue_style( 'hos-theme', get_template_directory_uri() . '/assets/theme.css', array( 'hos-hub-compat' ), hos_asset_ver( 'theme.css' ) );
	}
}, 20 );

add_filter( 'body_class', function ( $c ) {
	if ( hos_hub_active() && 'true' === (string) ihub_setting( 'mourning_mode' ) ) {
		$c[] = 'mourning-mode';
	}
	if ( hos_hub_active() ) {
		$c[] = 'has-idev-hub';
	}
	return $c;
} );

/** ประกาศด่วนจาก Hub (แทนแถบวิ่งของธีมเมื่อมีประกาศ) */
function hos_idev_announcements() {
	if ( hos_hub_active() && function_exists( 'ihub_render_announcements' ) ) {
		return (string) ihub_render_announcements();
	}
	return '';
}

/** ปุ่มสลับภาษา TH | EN — แปลทุกหน้าอัตโนมัติด้วย Google Translate */
function hos_idev_lang_switch() {
	if ( function_exists( 'idw_tr_switcher' ) && function_exists( 'idw_tr_on' ) && idw_tr_on() ) {
		return idw_tr_switcher(); // the plugin's translation: languages chosen in iDevApp Website → แปลภาษาอัตโนมัติ
	}
	if ( function_exists( 'hos_translate_on' ) && ! hos_translate_on() ) {
		return '';
	}
	return '<span class="hos-lang notranslate" translate="no"><a href="#" data-lang="th" class="on" lang="th">TH</a><a href="#" data-lang="en" lang="en">EN</a></span>';
}

/** ปุ่มนัดหมายจาก Hub */
function hos_idev_appointment_url() {
	return hos_hub_active() ? (string) ihub_setting( 'appointment_url' ) : '';
}

/** ticker ใต้หัวเว็บ */
function hos_idev_ticker() {
	return function_exists( 'idev_ticker_render' ) ? (string) idev_ticker_render() : '';
}

/** ไฟล์แนบจาก iDev Post Attachments */
function hos_idev_attachments( $post_id ) {
	return function_exists( 'idev_attachments_render' ) ? (string) idev_attachments_render( $post_id ) : '';
}

/** หน้านี้ออกแบบด้วยบล็อกของ Hub หรือไม่ → แสดงเต็มความกว้าง ไม่ใส่กรอบของธีม */
function hos_has_hub_blocks( $post = null ) {
	$post = get_post( $post );
	return $post && false !== strpos( $post->post_content, '<!-- wp:idevapp/' );
}

/** หน้านี้ใช้ shortcode ของ iDev (ฟอร์ม/ตาราง) → ใช้ความกว้างเต็ม container */
function hos_has_idev_shortcode( $post = null ) {
	$post = get_post( $post );
	return $post && preg_match( '/\[(idev_|idevapp_|ihub_)/', $post->post_content );
}

/** ไฟล์แนบใน iDevApp Website: ถ้าไม่มีให้ใช้จาก iDev Post Attachments */
add_filter( 'hos_document_url_fallback', function ( $url, $post_id ) {
	if ( $url || ! function_exists( 'idev_attachments_get' ) ) {
		return $url;
	}
	$files = (array) idev_attachments_get( $post_id );
	$f     = reset( $files );
	if ( is_array( $f ) ) {
		if ( ! empty( $f['url'] ) ) {
			return $f['url'];
		}
		if ( ! empty( $f['id'] ) ) {
			return (string) wp_get_attachment_url( (int) $f['id'] );
		}
	} elseif ( is_numeric( $f ) ) {
		return (string) wp_get_attachment_url( (int) $f );
	}
	return $url;
}, 10, 2 );

/** มีข้อมูลใน iDev Clinic Schedule แล้วหรือยัง */
function hos_idev_has_providers() {
	if ( ! post_type_exists( 'idev_provider' ) ) {
		return false;
	}
	$c = wp_count_posts( 'idev_provider' );
	return $c && $c->publish > 0;
}

/**
 * คลินิกที่เปิดในวันที่กำหนด จาก iDev Clinic Schedule
 * @return array of [ชื่อ, 'HH:MM - HH:MM'] หรือ null ถ้าไม่ได้ใช้ปลั๊กอิน
 */
function hos_idev_clinics_on( $date ) {
	if ( ! hos_idev_has_providers() || ! function_exists( 'idev_cs_occurs_on' ) ) {
		return null;
	}
	$out = array();
	foreach ( get_posts( array( 'post_type' => 'idev_provider', 'post_status' => 'publish', 'numberposts' => 300, 'orderby' => 'menu_order title', 'order' => 'ASC' ) ) as $p ) {
		$slots = json_decode( (string) get_post_meta( $p->ID, '_idev_slots', true ), true );
		foreach ( is_array( $slots ) ? $slots : array() as $sl ) {
			if ( idev_cs_occurs_on( $sl, $date ) ) {
				$t       = str_replace( ':', '.', $sl['start_time'] ) . ' - ' . str_replace( ':', '.', $sl['end_time'] );
				$out[]   = array( get_the_title( $p ), $t, $sl['start_time'] );
			}
		}
	}
	usort( $out, function ( $a, $b ) { return strcmp( $a[2], $b[2] ); } );
	return $out;
}

/* ================= รายชื่อคลินิก: แท็บตามหมวด + ค้นหา ================= */

function hos_clinic_groups() {
	return function_exists( 'hos_cs_groups' ) ? hos_cs_groups() : array( 'คลินิกทั่วไป', 'คลินิกเฉพาะทาง', 'คลินิกนอกเวลา', 'คลินิกพิเศษนอกเวลา (SMC)' );
}

/** สรุปช่วงเวลาของคลินิกเป็นบรรทัดอ่านง่าย: "จ. พ. ศ. · 08.30–12.00 (สัปดาห์ที่ 2, 4)" */
function hos_clinic_time_lines( $slots ) {
	$dn  = array( 1 => 'จ.', 2 => 'อ.', 3 => 'พ.', 4 => 'พฤ.', 5 => 'ศ.', 6 => 'ส.', 7 => 'อา.' );
	$grp = array();
	foreach ( (array) $slots as $s ) {
		if ( empty( $s['start_time'] ) ) {
			continue;
		}
		$time = str_replace( ':', '.', $s['start_time'] ) . '–' . str_replace( ':', '.', $s['end_time'] );
		$rec  = isset( $s['recurrence'] ) ? $s['recurrence'] : 'weekly';
		if ( 'date' === $rec ) {
			if ( empty( $s['on_date'] ) || $s['on_date'] < wp_date( 'Y-m-01' ) ) {
				continue;
			}
			$wd = (int) wp_date( 'N', strtotime( $s['on_date'] . ' 12:00' ) );
			$k  = $time . '|date|' . $wd . '|' . ( isset( $s['note'] ) ? $s['note'] : '' );
			$grp[ $k ]['dday'] = $wd;
			$grp[ $k ]['label'][] = $s['on_date'];
		} elseif ( in_array( $rec, array( 'weekly', 'monthly_week' ), true ) && ! empty( $s['weekday'] ) ) {
			$k = $time . '|' . ( int ) $s['weekday'] . '|' . $rec;
			$grp[ $k ]['day']    = (int) $s['weekday'];
			$grp[ $k ]['weeks'][] = 'monthly_week' === $rec ? (int) $s['week_of_month'] : 0;
		} else {
			$k = $time . '|other';
			$grp[ $k ]['label'][] = 'ตามนัด';
		}
		$grp[ $k ]['time'] = $time;
		$grp[ $k ]['note'] = isset( $s['note'] ) ? $s['note'] : '';
	}
	// รวมวันที่เวลา/สัปดาห์เหมือนกัน
	$merged = array();
	foreach ( $grp as $g ) {
		if ( isset( $g['day'] ) ) {
			$weeks = array_values( array_unique( array_filter( $g['weeks'] ) ) );
			sort( $weeks );
			$wk = $weeks ? ' (สัปดาห์ที่ ' . implode( ', ', $weeks ) . ')' : '';
			$mk = $g['time'] . $wk . '|' . $g['note'];
			$merged[ $mk ]['days'][] = $g['day'];
			$merged[ $mk ]['text']   = $g['time'] . ' น.' . $wk . ( $g['note'] ? ' · ' . $g['note'] : '' );
		} elseif ( isset( $g['dday'] ) ) {
			sort( $g['label'] );
			$mk = 'date' . $g['dday'] . $g['time'] . $g['note'];
			$merged[ $mk ]['days'] = array( $g['dday'] );
			$merged[ $mk ]['text'] = 'วันที่ ' . hos_thai_dates( $g['label'] ) . ' · ' . $g['time'] . ' น.' . ( $g['note'] ? ' · ' . $g['note'] : '' );
		} else {
			$merged[ $g['time'] . 'x' ]['days'] = array();
			$merged[ $g['time'] . 'x' ]['text'] = implode( ', ', $g['label'] ) . ' · ' . $g['time'] . ' น.';
		}
	}
	$lines = array();
	foreach ( $merged as $m ) {
		sort( $m['days'] );
		$days    = implode( ' ', array_map( function ( $d ) use ( $dn ) { return $dn[ $d ]; }, array_unique( $m['days'] ) ) );
		$lines[] = array( $days, $m['text'], $m['days'] ? min( $m['days'] ) : 9 );
	}
	usort( $lines, function ( $a, $b ) { return $a[2] - $b[2]; } );
	return $lines;
}

/** รายการคลินิกจาก iDev Clinic Schedule จัดตามหมวด */
function hos_clinic_directory_data() {
	$groups = array_fill_keys( hos_clinic_groups(), array() );
	if ( ! post_type_exists( 'idev_provider' ) ) {
		return $groups;
	}
	foreach ( get_posts( array( 'post_type' => 'idev_provider', 'post_status' => 'publish', 'numberposts' => 500, 'orderby' => array( 'menu_order' => 'ASC', 'title' => 'ASC' ) ) ) as $p ) {
		$terms = taxonomy_exists( 'idev_specialty' ) ? get_the_terms( $p, 'idev_specialty' ) : false;
		$g     = $terms && ! is_wp_error( $terms ) ? $terms[0]->name : (string) get_post_meta( $p->ID, '_idev_specialty', true );
		if ( '' === $g ) {
			$g = 'คลินิกเฉพาะทาง';
		}
		$slots         = json_decode( (string) get_post_meta( $p->ID, '_idev_slots', true ), true );
		$groups[ $g ][] = array(
			'name'  => get_the_title( $p ),
			'kind'  => get_post_meta( $p->ID, '_idev_kind', true ),
			'lines' => hos_clinic_time_lines( $slots ),
			'note'  => (string) get_post_meta( $p->ID, '_idev_note', true ),
		);
	}
	return $groups;
}

/** แถวตารางรายวัน: [day][] = name, group, start, end, weeks, note */
function hos_clinic_day_rows() {
	$rows = array();
	if ( ! post_type_exists( 'idev_provider' ) ) {
		return $rows;
	}
	foreach ( get_posts( array( 'post_type' => 'idev_provider', 'post_status' => 'publish', 'numberposts' => 500, 'orderby' => array( 'menu_order' => 'ASC', 'title' => 'ASC' ) ) ) as $p ) {
		$terms = taxonomy_exists( 'idev_specialty' ) ? get_the_terms( $p, 'idev_specialty' ) : false;
		$g     = $terms && ! is_wp_error( $terms ) ? $terms[0]->name : 'คลินิกเฉพาะทาง';
		$slots = json_decode( (string) get_post_meta( $p->ID, '_idev_slots', true ), true );
		$tmp   = array();
		foreach ( is_array( $slots ) ? $slots : array() as $s ) {
			$rec = isset( $s['recurrence'] ) ? $s['recurrence'] : 'weekly';
			if ( 'date' === $rec && ! empty( $s['on_date'] ) ) {
				if ( $s['on_date'] < wp_date( 'Y-m-01' ) ) {
					continue; // เดือนที่ผ่านมาแล้ว
				}
				$wd = (int) wp_date( 'N', strtotime( $s['on_date'] . ' 12:00' ) );
				$k  = 'd|' . $wd . '|' . $s['start_time'] . '|' . ( isset( $s['note'] ) ? $s['note'] : '' );
				if ( ! isset( $tmp[ $k ] ) ) {
					$tmp[ $k ] = array( 'name' => get_the_title( $p ), 'group' => $g, 'day' => $wd, 'start' => $s['start_time'], 'end' => $s['end_time'], 'weeks' => array(), 'every' => false, 'dates' => array(), 'note' => isset( $s['note'] ) ? $s['note'] : '' );
				}
				$tmp[ $k ]['dates'][] = $s['on_date'];
				continue;
			}
			if ( ! in_array( $rec, array( 'weekly', 'monthly_week' ), true ) || empty( $s['weekday'] ) ) {
				continue;
			}
			$k = $s['weekday'] . '|' . $s['start_time'] . '|' . $s['end_time'] . '|' . ( isset( $s['note'] ) ? $s['note'] : '' );
			if ( ! isset( $tmp[ $k ] ) ) {
				$tmp[ $k ] = array( 'name' => get_the_title( $p ), 'group' => $g, 'day' => (int) $s['weekday'], 'start' => $s['start_time'], 'end' => $s['end_time'], 'weeks' => array(), 'every' => false, 'dates' => array(), 'note' => isset( $s['note'] ) ? $s['note'] : '' );
			}
			if ( 'weekly' === $rec ) {
				$tmp[ $k ]['every'] = true;
			} else {
				$tmp[ $k ]['weeks'][] = (int) $s['week_of_month'];
			}
		}
		foreach ( $tmp as $r ) {
			if ( $r['every'] ) {
				$r['weeks'] = array();
			}
			sort( $r['weeks'] );
			$rows[ $r['day'] ][] = $r;
		}
	}
	foreach ( $rows as &$list ) {
		usort( $list, function ( $a, $b ) { return strcmp( $a['start'] . $a['name'], $b['start'] . $b['name'] ); } );
	}
	return $rows;
}

/** ข้อมูลสำหรับปฏิทินรายเดือน (คำนวณวันในเบราว์เซอร์ ตามกฎเดียวกับ idev_cs_occurs_on) */
function hos_clinic_calendar_data( $gkey ) {
	$out = array( 'today' => wp_date( 'Y-m-d' ), 'items' => array() );
	if ( ! post_type_exists( 'idev_provider' ) ) {
		return $out;
	}
	foreach ( get_posts( array( 'post_type' => 'idev_provider', 'post_status' => 'publish', 'numberposts' => 500, 'orderby' => array( 'menu_order' => 'ASC', 'title' => 'ASC' ) ) ) as $p ) {
		$terms = taxonomy_exists( 'idev_specialty' ) ? get_the_terms( $p, 'idev_specialty' ) : false;
		$g     = $terms && ! is_wp_error( $terms ) ? $terms[0]->name : 'คลินิกเฉพาะทาง';
		$slots = json_decode( (string) get_post_meta( $p->ID, '_idev_slots', true ), true );
		$clean = array();
		foreach ( is_array( $slots ) ? $slots : array() as $sl ) {
			if ( empty( $sl['start_time'] ) ) {
				continue;
			}
			$clean[] = array_intersect_key( $sl, array_flip( array( 'recurrence', 'weekday', 'week_of_month', 'day_of_month', 'month_of_year', 'on_date', 'valid_from', 'valid_until', 'start_time', 'end_time', 'note' ) ) );
		}
		if ( $clean ) {
			$out['items'][] = array( 'n' => get_the_title( $p ), 'g' => $gkey( $g ), 'gl' => $g, 's' => $clean );
		}
	}
	return $out;
}

function hos_clinic_directory() {
	$groups = hos_clinic_directory_data();
	$days   = hos_clinic_day_rows();
	$total  = array_sum( array_map( 'count', $groups ) );
	$icons  = array( 'คลินิกทั่วไป' => '🩺', 'คลินิกเฉพาะทาง' => '🏥', 'คลินิกนอกเวลา' => '🌙', 'คลินิกพิเศษนอกเวลา (SMC)' => '⭐' );
	$dname  = array( 1 => 'จันทร์', 2 => 'อังคาร', 3 => 'พุธ', 4 => 'พฤหัสบดี', 5 => 'ศุกร์', 6 => 'เสาร์', 7 => 'อาทิตย์' );
	$today  = (int) wp_date( 'N' );
	$sel    = isset( $days[ $today ] ) ? $today : 1;
	$weekno = (int) ceil( (int) wp_date( 'j' ) / 7 );
	$gkey   = function ( $g ) { return substr( md5( $g ), 0, 8 ); };
	$t      = function ( $x ) { return str_replace( ':', '.', $x ); };
	ob_start();
	?>
	<div class="hos-clinics" data-hos-clinics data-today="<?php echo (int) $today; ?>">
		<div class="hos-clinic-tools">
			<label class="hos-clinic-search"><span aria-hidden="true">🔍</span><input type="search" placeholder="ค้นหาชื่อคลินิก เช่น เบาหวาน, กุมาร, ARI" aria-label="ค้นหาชื่อคลินิก" data-search></label>
			<div class="hos-clinic-bar">
				<div class="hos-seg" role="tablist" aria-label="มุมมอง"><button type="button" class="on" data-mode="day">📅 ดูตามวัน</button><button type="button" data-mode="month">🗓️ ดูทั้งเดือน</button><button type="button" data-mode="list">📋 รายชื่อคลินิก</button></div>
				<div class="hos-gchips"><button type="button" class="on" data-group="all">ทั้งหมด</button><?php foreach ( $groups as $g => $list ) : if ( ! $list ) { continue; } ?><button type="button" data-group="<?php echo esc_attr( $gkey( $g ) ); ?>"><?php echo esc_html( ( isset( $icons[ $g ] ) ? $icons[ $g ] . ' ' : '' ) . $g ); ?> <small><?php echo count( $list ); ?></small></button><?php endforeach; ?></div>
			</div>
		</div>

		<div class="hos-mode" data-mode-panel="day">
			<div class="hos-days" role="tablist">
				<?php for ( $d = 1; $d <= 5; $d++ ) : ?>
					<button type="button" data-day="<?php echo (int) $d; ?>" class="<?php echo $d === $sel ? 'on' : ''; ?>"><b><?php echo esc_html( $dname[ $d ] ); ?></b><?php echo $d === $today ? '<small>วันนี้</small>' : '<small>' . count( isset( $days[ $d ] ) ? $days[ $d ] : array() ) . ' คลินิก</small>'; ?></button>
				<?php endfor; ?>
			</div>
			<?php for ( $d = 1; $d <= 5; $d++ ) : $list = isset( $days[ $d ] ) ? $days[ $d ] : array(); ?>
				<div class="hos-day-panel" data-day-panel="<?php echo (int) $d; ?>"<?php echo $d === $sel ? '' : ' hidden'; ?>>
					<?php foreach ( array( 'am' => array( '🌤️ ช่วงเช้า', 'ก่อน 12.00 น.' ), 'pm' => array( '🌇 ช่วงบ่าย', 'ตั้งแต่ 12.00 น.' ), 'ev' => array( '🌙 นอกเวลา', 'ตั้งแต่ 16.30 น.' ) ) as $slot => $lab ) :
						$part = array_filter( $list, function ( $r ) use ( $slot ) {
							$h = $r['start'];
							return 'am' === $slot ? $h < '12:00' : ( 'pm' === $slot ? ( $h >= '12:00' && $h < '16:30' ) : $h >= '16:30' );
						} );
						if ( ! $part ) { continue; } ?>
						<section class="hos-dpart">
							<h3><?php echo esc_html( $lab[0] ); ?> <small><?php echo esc_html( $lab[1] ); ?></small></h3>
							<ul class="hos-rows">
							<?php foreach ( $part as $r ) :
								$wk   = $r['weeks'] ? 'สัปดาห์ที่ ' . implode( ', ', $r['weeks'] ) : '';
								$nowk = $r['weeks'] && $d === $today && ! in_array( $weekno, $r['weeks'], true );
								if ( ! empty( $r['dates'] ) ) {
									sort( $r['dates'] );
									$wk   = 'วันที่ ' . hos_thai_dates( $r['dates'] );
									$nowk = $d === $today && ! in_array( wp_date( 'Y-m-d' ), $r['dates'], true );
								} ?>
								<li data-group="<?php echo esc_attr( $gkey( $r['group'] ) ); ?>" data-name="<?php echo esc_attr( mb_strtolower( $r['name'] ) ); ?>" class="<?php echo $nowk ? 'off-week' : ''; ?>">
									<time><?php echo esc_html( $t( $r['start'] ) . '–' . $t( $r['end'] ) ); ?></time>
									<span class="n"><?php echo esc_html( $r['name'] ); ?><?php if ( $wk ) : ?> <em class="wk"><?php echo esc_html( $wk ); ?></em><?php endif; ?><?php if ( $r['note'] ) : ?> <em class="nt"><?php echo esc_html( $r['note'] ); ?></em><?php endif; ?></span>
									<span class="g"><?php echo esc_html( $r['group'] ); ?></span>
								</li>
							<?php endforeach; ?>
							</ul>
						</section>
					<?php endforeach; ?>
					<?php if ( ! $list ) : ?><div class="hos-empty">ไม่มีคลินิกในวันนี้</div><?php endif; ?>
					<?php if ( array_filter( $list, function ( $r ) { return false !== strpos( $r['group'], 'SMC' ); } ) ) : echo hos_smc_note(); endif; // phpcs:ignore ?>
				</div>
			<?php endfor; ?>
			<p class="hos-clinic-note">ห้องอุบัติเหตุและฉุกเฉินเปิดตลอด 24 ชั่วโมง · คลินิกที่ระบุ "สัปดาห์ที่" ให้บริการเฉพาะสัปดาห์นั้นของเดือน<?php echo $weekno <= 5 ? ' (สัปดาห์นี้คือสัปดาห์ที่ ' . (int) $weekno . ')' : ''; ?></p>
		</div>

		<div class="hos-mode" data-mode-panel="month" hidden>
			<div class="hos-month" data-hos-month></div>
			<script type="application/json" class="hos-cal-data"><?php echo wp_json_encode( hos_clinic_calendar_data( $gkey ), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ); ?></script>
		</div>

		<div class="hos-mode" data-mode-panel="list" hidden>
			<?php foreach ( $groups as $g => $list ) : if ( ! $list ) { continue; } ?>
				<section class="hos-clinic-group" data-group="<?php echo esc_attr( $gkey( $g ) ); ?>">
					<h3><?php echo esc_html( ( isset( $icons[ $g ] ) ? $icons[ $g ] . ' ' : '' ) . $g ); ?></h3>
					<?php if ( false !== strpos( $g, 'SMC' ) ) { echo hos_smc_note(); } // phpcs:ignore ?>
					<table class="hos-ctable"><thead><tr><th>คลินิก</th><th>วัน</th><th>เวลา</th></tr></thead><tbody>
					<?php foreach ( $list as $c ) : $n = max( 1, count( $c['lines'] ) ); foreach ( $c['lines'] ? $c['lines'] : array( array( '-', '-' ) ) as $i => $l ) : ?>
						<tr data-name="<?php echo esc_attr( mb_strtolower( $c['name'] ) ); ?>"<?php echo $i ? ' class="cont"' : ''; ?>>
							<?php if ( ! $i ) : ?><td rowspan="<?php echo (int) $n; ?>" class="cn"><?php echo esc_html( $c['name'] ); ?></td><?php endif; ?>
							<td class="cd"><?php echo esc_html( $l[0] ); ?></td><td><?php echo esc_html( $l[1] ); ?></td>
						</tr>
					<?php endforeach; endforeach; ?>
					</tbody></table>
				</section>
			<?php endforeach; ?>
		</div>
		<div class="hos-empty" data-noresult hidden>ไม่พบคลินิกที่ค้นหา ลองพิมพ์คำอื่น หรือดูแบบ "รายชื่อคลินิก"</div>
	</div>
	<?php
	return ob_get_clean();
}
add_shortcode( 'hos_clinics', 'hos_clinic_directory' );

/**
 * หน้าแรกจากบล็อก Hub: เอาบล็อกช่วงบนสุด (hero, buttons, slider) ไปจัดเป็นแบนเนอร์เขียว 2 คอลัมน์
 * และบล็อก cards ถัดมาเป็นแถบปุ่มลัดซ้อนขอบล่าง — ทุกส่วนยังแก้ไขได้ในตัวแก้ไขบล็อก
 */
function hos_render_hub_top( $content ) {
	$blocks = parse_blocks( $content );
	$text   = '';
	$media  = '';
	$quick  = '';
	$rest   = array();
	$phase  = 'top';
	foreach ( $blocks as $b ) {
		$name = (string) $b['blockName'];
		if ( '' === $name && '' === trim( $b['innerHTML'] ) ) {
			continue;
		}
		if ( 'top' === $phase && in_array( $name, array( 'idevapp/hero', 'idevapp/buttons' ), true ) ) {
			$text .= do_shortcode( render_block( $b ) );
			continue;
		}
		if ( 'top' === $phase && 'idevapp/slider' === $name && '' === $media ) {
			$media = render_block( $b );
			continue;
		}
		if ( 'top' === $phase && 'idevapp/cards' === $name && '' !== $text ) {
			$quick = render_block( $b );
			$phase = 'rest';
			continue;
		}
		$phase  = 'rest';
		$rest[] = $b;
	}
	$html = '';
	if ( '' !== $text || '' !== $media ) {
		if ( '' === $media ) {
			$media = '<div class="hos-hubtop-ph"><img src="' . esc_url( get_template_directory_uri() . '/assets/logo.png' ) . '" alt=""></div>';
		}
		$html .= '<section class="hos-hubtop"><div class="container hos-hubtop-grid"><div class="hos-hubtop-text">' . $text . '</div><div class="hos-hubtop-media">' . $media . '</div></div></section>';
	}
	if ( '' !== $quick ) {
		$html .= '<div class="hos-hubquick">' . $quick . '</div>';
	}
	$rest_html = apply_filters( 'the_content', serialize_blocks( $rest ) ); // ให้ shortcode/embed ทำงานครบ
	return $html . '<div class="hos-content hos-hub-page">' . $rest_html . '</div>';
}

/** หน้าเดียวกับรายชื่อคลินิก: พับปฏิทินรายสัปดาห์ของปลั๊กอินไว้ ไม่ให้หน้ายาว */
add_filter( 'do_shortcode_tag', function ( $out, $tag ) {
	if ( 'idev_schedule' === $tag && is_singular() && has_shortcode( (string) get_post_field( 'post_content', get_the_ID() ), 'hos_clinics' ) ) {
		return '<details class="hos-cal"><summary>📅 เปิดปฏิทินรายสัปดาห์ (ตารางเต็ม)</summary>' . $out . '</details>';
	}
	return $out;
}, 10, 2 );

/** "2, 9, 16 พ.ย. 69" จากรายการวันที่ Y-m-d */
function hos_thai_dates( $dates ) {
	$m   = array( '', 'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.' );
	$by  = array();
	foreach ( $dates as $d ) {
		$by[ substr( $d, 0, 7 ) ][] = (int) substr( $d, 8, 2 );
	}
	$out = array();
	foreach ( $by as $ym => $days ) {
		$out[] = implode( ', ', $days ) . ' ' . $m[ (int) substr( $ym, 5, 2 ) ] . ' ' . substr( (string) ( (int) substr( $ym, 0, 4 ) + 543 ), 2 );
	}
	return implode( ' · ', $out );
}

/** หมายเหตุคลินิกพิเศษนอกเวลา (SMC) */
function hos_smc_note() {
	$n = trim( (string) hos_mod( 'hos_smc_note' ) );
	return '' === $n ? '' : '<div class="hos-smc-note">' . wp_kses_post( wpautop( $n ) ) . '</div>';
}
