=== iDev Clinic ===
Contributors: idevapp
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

ธีมคลินิกและโรงพยาบาลเอกชน: หน้าแรกพร้อมปุ่มจองนัด บริการ ทีมแพทย์และตารางออกตรวจ ขั้นตอนจองนัด บทความสุขภาพ และแผนที่ ใช้คู่กับ iDev Appointments / Patient Registration / Clinic Schedule

== Copyright ==
iDev Clinic © iDevApp, GPLv2 or later.
Fonts: SIL Open Font License 1.1. Illustrations: by iDevApp, GPLv2 or later.
