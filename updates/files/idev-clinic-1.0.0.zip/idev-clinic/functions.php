<?php
/**
 * iDev Clinic — block theme by iDevApp. Everything is edited in Appearance → Editor (Site Editor):
 * colours and fonts (Styles), header and footer (Patterns → Template parts), the front page (Templates → Front page).
 */
defined('ABSPATH') || exit;

add_action('after_setup_theme', function () {
    add_theme_support('wp-block-styles');
    add_theme_support('editor-styles');
    add_editor_style('assets/theme.css');
    load_theme_textdomain('idev-clinic', get_template_directory() . '/languages');
});

add_action('wp_enqueue_scripts', function () {
    $v = wp_get_theme()->get('Version');
    wp_enqueue_style('idev-clinic', get_theme_file_uri('assets/theme.css'), [], $v);
    
});

add_action('init', function () {
    register_block_style('core/group', ['name' => 'idev-card', 'label' => 'การ์ด']);
    register_block_pattern_category('idev-clinic', ['label' => 'iDev Clinic · คลินิก']);
});

/* Updates from idevapp.me (also when no iDevApp plugin is active). */
add_action('init', function () {
    if (has_filter('update_themes_idevapp.me')) return; // the iDevApp plugins already handle it
    add_filter('update_themes_idevapp.me', function ($update, $data, $stylesheet) {
        if ($stylesheet !== get_stylesheet() && $stylesheet !== get_template()) return $update;
        $m = get_site_transient('idev_theme_manifest');
        if (!is_array($m)) {
            $r = wp_remote_get('https://idevapp.me/updates/plugins.json', ['timeout' => 10]);
            $m = !is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200 ? (json_decode(wp_remote_retrieve_body($r), true) ?: []) : [];
            set_site_transient('idev_theme_manifest', $m, 6 * HOUR_IN_SECONDS);
        }
        $i = $m['themes'][$stylesheet] ?? null;
        if (!$i || empty($i['package']) || !in_array(wp_parse_url($i['package'], PHP_URL_HOST), ['idevapp.me', 'www.idevapp.me', 'github.com'], true)) return $update;
        return ['theme' => $stylesheet, 'version' => $i['version'], 'url' => 'https://idevapp.me/', 'package' => $i['package']];
    }, 10, 3);
}, 20);
