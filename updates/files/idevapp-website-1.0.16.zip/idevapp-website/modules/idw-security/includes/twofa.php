<?php
/**
 * ยืนยันตัวตนสองขั้น (2FA) ด้วยแอป Google Authenticator / Microsoft Authenticator / Authy ฯลฯ (TOTP, RFC 6238)
 * ไม่ต้องติดตั้งปลั๊กอินเพิ่ม · ตั้งค่าที่หน้า “โปรไฟล์” ของแต่ละคน: สแกน QR → ใส่รหัส 6 หลัก → ได้รหัสสำรอง 10 ชุด
 * ล็อกอิน: รหัสผ่านถูก → ถามรหัส 6 หลักจากแอป (หรือรหัสสำรอง) ก่อนเข้าระบบ
 * กู้คืน: ผู้ดูแลคนอื่นรีเซ็ตให้ได้ที่หน้าแก้ไขผู้ใช้ หรือใส่ define( 'IDW_2FA_OFF', true ); ใน wp-config.php ชั่วคราว
 */
defined('ABSPATH') || exit;

const IDW_2FA_META = '_idw_2fa';

function idw_2fa_off() { return defined('IDW_2FA_OFF') && IDW_2FA_OFF; }
function idw_2fa_get($uid) { $d = get_user_meta($uid, IDW_2FA_META, true); return is_array($d) ? $d : []; }
function idw_2fa_enabled($uid) { $d = idw_2fa_get($uid); return !empty($d['on']) && !empty($d['secret']); }

/* ---------- TOTP ---------- */
function idw_2fa_b32_encode($bin) {
    $a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits = ''; $out = '';
    foreach (str_split($bin) as $c) $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
    foreach (str_split($bits, 5) as $ch) $out .= $a[bindec(str_pad($ch, 5, '0'))];
    return $out;
}
function idw_2fa_b32_decode($s) {
    $a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $s = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', (string) $s)); $bits = ''; $out = '';
    foreach (str_split($s) as $c) { $p = strpos($a, $c); if ($p === false) continue; $bits .= str_pad(decbin($p), 5, '0', STR_PAD_LEFT); }
    foreach (str_split($bits, 8) as $b) if (strlen($b) === 8) $out .= chr(bindec($b));
    return $out;
}
function idw_2fa_code($secret, $step) {
    $key = idw_2fa_b32_decode($secret);
    $h = hash_hmac('sha1', pack('N*', 0) . pack('N*', $step), $key, true);
    $o = ord($h[19]) & 0xf;
    $n = ((ord($h[$o]) & 0x7f) << 24) | (ord($h[$o + 1]) << 16) | (ord($h[$o + 2]) << 8) | ord($h[$o + 3]);
    return str_pad((string) ($n % 1000000), 6, '0', STR_PAD_LEFT);
}
/** Checks a 6-digit code (±30 s for a phone clock that is a little off) · returns the time step used, or false. */
function idw_2fa_check($secret, $code, $last = 0) {
    $code = preg_replace('/\D/', '', (string) $code);
    if (strlen($code) !== 6 || !$secret) return false;
    $now = (int) floor(time() / 30);
    foreach ([0, -1, 1] as $w) {
        $step = $now + $w;
        if ($step <= (int) $last) continue; // a code is used only once
        if (hash_equals(idw_2fa_code($secret, $step), $code)) return $step;
    }
    return false;
}
function idw_2fa_new_secret() { return idw_2fa_b32_encode(random_bytes(20)); }
function idw_2fa_backup_codes() {
    $plain = []; $hash = [];
    for ($i = 0; $i < 10; $i++) { $c = strtolower(wp_generate_password(8, false, false)); $plain[] = $c; $hash[] = wp_hash_password($c); }
    return [$plain, $hash];
}
function idw_2fa_use_backup($uid, $code) {
    $code = strtolower(preg_replace('/[^A-Za-z0-9]/', '', (string) $code));
    if (strlen($code) !== 8) return false;
    $d = idw_2fa_get($uid);
    foreach ((array) ($d['backup'] ?? []) as $i => $h) {
        if (wp_check_password($code, $h)) { unset($d['backup'][$i]); $d['backup'] = array_values($d['backup']); update_user_meta($uid, IDW_2FA_META, $d); return true; }
    }
    return false;
}
/** code from the app or a backup code */
function idw_2fa_verify_user($uid, $code) {
    $d = idw_2fa_get($uid);
    $step = idw_2fa_check($d['secret'] ?? '', $code, $d['last'] ?? 0);
    if ($step !== false) { $d['last'] = $step; update_user_meta($uid, IDW_2FA_META, $d); return 'app'; }
    return idw_2fa_use_backup($uid, $code) ? 'backup' : false;
}

/* ---------- login: after the password, ask for the code ---------- */
add_action('wp_login', function ($login, $user) {
    if (idw_2fa_off() || !empty($GLOBALS['idw_2fa_passed']) || !idw_2fa_enabled($user->ID)) return;
    wp_clear_auth_cookie(); // the password alone does not log in
    $tok = wp_generate_password(40, false, false);
    $to = isset($_REQUEST['redirect_to']) ? esc_url_raw(wp_unslash($_REQUEST['redirect_to'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification
    update_user_meta($user->ID, '_idw_2fa_login', ['h' => wp_hash($tok), 'exp' => time() + 10 * MINUTE_IN_SECONDS, 'n' => 0, 'remember' => !empty($_POST['rememberme']), 'to' => $to]); // phpcs:ignore WordPress.Security.NonceVerification
    wp_safe_redirect(add_query_arg(['action' => 'idw_2fa', 'u' => $user->ID, 't' => $tok], wp_login_url()));
    exit;
}, 1, 2);

/* password-only logins through XML-RPC would skip the code */
add_filter('authenticate', function ($user) {
    if (!idw_2fa_off() && defined('XMLRPC_REQUEST') && XMLRPC_REQUEST && $user instanceof WP_User && idw_2fa_enabled($user->ID)) return new WP_Error('idw_2fa', 'บัญชีนี้ใช้การยืนยันตัวตนสองขั้น — เข้าผ่าน XML-RPC ไม่ได้');
    return $user;
}, 99);

add_action('login_form_idw_2fa', function () {
    $uid = absint($_REQUEST['u'] ?? 0); $tok = sanitize_text_field(wp_unslash($_REQUEST['t'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification
    $p = $uid ? get_user_meta($uid, '_idw_2fa_login', true) : null;
    $back = function ($msg) { wp_safe_redirect(add_query_arg('idw2fa', rawurlencode($msg), wp_login_url())); exit; };
    if (!is_array($p) || !$tok || !hash_equals($p['h'], wp_hash($tok)) || $p['exp'] < time()) $back('expired');
    $err = '';
    if ('POST' === ($_SERVER['REQUEST_METHOD'] ?? '') && isset($_POST['idw_code'])) { // phpcs:ignore WordPress.Security.NonceVerification
        $how = idw_2fa_verify_user($uid, wp_unslash($_POST['idw_code'])); // phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput
        if ($how) {
            delete_user_meta($uid, '_idw_2fa_login');
            $GLOBALS['idw_2fa_passed'] = 1;
            wp_set_auth_cookie($uid, !empty($p['remember']), is_ssl());
            $u = get_userdata($uid);
            do_action('wp_login', $u->user_login, $u); // the usual login hooks, now that the code is right
            if (function_exists('idw_sec_log')) idw_sec_log('login', 'ยืนยันตัวตนสองขั้นผ่าน: ' . $u->user_login . ('backup' === $how ? ' (ใช้รหัสสำรอง)' : ''));
            $to = apply_filters('login_redirect', $p['to'] ?: admin_url(), $p['to'], $u);
            wp_safe_redirect($to ?: admin_url());
            exit;
        }
        $p['n']++;
        if ($p['n'] >= 5) { delete_user_meta($uid, '_idw_2fa_login'); if (function_exists('idw_sec_log')) idw_sec_log('login_failed', 'ใส่รหัส 2FA ผิด 5 ครั้ง: ผู้ใช้ #' . $uid); $back('locked'); }
        update_user_meta($uid, '_idw_2fa_login', $p);
        $err = 'รหัสไม่ถูกต้อง — ลองอีกครั้ง (เหลือ ' . (5 - $p['n']) . ' ครั้ง)';
    }
    login_header('ยืนยันตัวตนสองขั้น', '', $err ? new WP_Error('idw_2fa', $err) : null);
    $d = idw_2fa_get($uid);
    ?>
    <form method="post" action="<?php echo esc_url(add_query_arg(['action' => 'idw_2fa', 'u' => $uid, 't' => $tok], wp_login_url())); ?>" id="idw-2fa-form">
        <p style="margin-bottom:14px">เปิดแอป <b>Google Authenticator</b> (หรือแอปยืนยันตัวตนที่ใช้) แล้วใส่รหัส 6 หลักของเว็บนี้</p>
        <p><label for="idw_code">รหัส 6 หลัก</label>
        <input type="text" name="idw_code" id="idw_code" class="input" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9A-Za-z ]*" maxlength="10" autofocus required style="font-size:24px;letter-spacing:4px;text-align:center"></p>
        <p style="font-size:12px;color:#646970;margin:6px 0 14px">ไม่มีโทรศัพท์? ใส่ <b>รหัสสำรอง</b> 8 ตัว (ใช้ได้ครั้งเดียว · เหลือ <?php echo (int) count((array) ($d['backup'] ?? [])); ?> ชุด)</p>
        <p class="submit"><button type="submit" class="button button-primary button-large" style="width:100%">ยืนยัน</button></p>
    </form>
    <p id="nav"><a href="<?php echo esc_url(wp_login_url()); ?>">← กลับไปหน้าเข้าสู่ระบบ</a></p>
    <script>document.getElementById('idw_code').addEventListener('input',function(e){var v=e.target.value.replace(/\s/g,'');if(/^\d{6}$/.test(v))document.getElementById('idw-2fa-form').submit();});</script>
    <?php
    login_footer('idw_code');
    exit;
});
add_filter('wp_login_errors', function ($errors) {
    $m = sanitize_key($_GET['idw2fa'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification
    if ('expired' === $m) $errors->add('idw_2fa', 'หมดเวลายืนยันรหัส 2FA — กรุณาเข้าสู่ระบบใหม่');
    if ('locked' === $m) $errors->add('idw_2fa', 'ใส่รหัส 2FA ผิดหลายครั้ง — กรุณาเข้าสู่ระบบใหม่');
    return $errors;
});

/* ---------- enforce for administrators (setting “บังคับผู้ดูแลระบบใช้ 2FA”) ---------- */
add_action('admin_init', function () {
    if (idw_2fa_off() || !function_exists('idw_sec_on') || !idw_sec_on('2fa_force') || wp_doing_ajax() || !current_user_can('manage_options')) return;
    if (idw_2fa_enabled(get_current_user_id())) return;
    global $pagenow;
    if (in_array($pagenow, ['profile.php', 'admin-post.php', 'async-upload.php'], true)) return;
    wp_safe_redirect(admin_url('profile.php?idw2fa=need#idw-2fa'));
    exit;
});

/* ---------- profile: set up / reset ---------- */
function idw_2fa_profile($user) {
    $self = get_current_user_id() === $user->ID;
    if (!$self && !current_user_can('edit_users')) return;
    $on = idw_2fa_enabled($user->ID); $d = idw_2fa_get($user->ID);
    $need = isset($_GET['idw2fa']) && !$on; // phpcs:ignore WordPress.Security.NonceVerification
    wp_enqueue_script('idw-qr', plugin_dir_url(__DIR__) . 'assets/qr.js', [], IDW_SEC_VERSION, true);
    ?>
    <h2 id="idw-2fa">🔐 ยืนยันตัวตนสองขั้น (Google Authenticator)</h2>
    <div class="idw-2fa-box" data-uid="<?php echo (int) $user->ID; ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('idw_2fa_' . $user->ID)); ?>" style="max-width:720px;background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:16px 18px;margin-bottom:20px">
    <?php if ($need) : ?><div class="notice notice-warning inline" style="margin:0 0 12px"><p><b>เว็บนี้บังคับให้ผู้ดูแลระบบใช้การยืนยันตัวตนสองขั้น</b> — ตั้งค่าด้านล่างให้เสร็จก่อนจึงจะใช้หลังบ้านต่อได้</p></div><?php endif; ?>
    <?php if ($on) : ?>
        <p>✅ <b>เปิดใช้อยู่</b> — เข้าสู่ระบบต้องใช้รหัส 6 หลักจากแอปทุกครั้ง · รหัสสำรองเหลือ <b><?php echo (int) count((array) ($d['backup'] ?? [])); ?></b> ชุด</p>
        <?php if ($self) : ?><p><button type="button" class="button" data-2fa="codes">สร้างรหัสสำรองชุดใหม่</button> <button type="button" class="button" data-2fa="off">ปิดการยืนยันตัวตนสองขั้น</button></p>
        <?php else : ?><p><button type="button" class="button" data-2fa="reset">รีเซ็ต 2FA ของผู้ใช้นี้</button> <span class="description">ใช้เมื่อผู้ใช้ทำโทรศัพท์หายและไม่มีรหัสสำรอง — เขาจะต้องตั้งค่าใหม่</span></p><?php endif; ?>
    <?php elseif ($self) : ?>
        <p>เพิ่มความปลอดภัย: นอกจากรหัสผ่าน ต้องใส่รหัส 6 หลักจากแอปในโทรศัพท์ ถ้ารหัสผ่านรั่วก็เข้าระบบไม่ได้</p>
        <ol style="margin-left:18px"><li>ติดตั้งแอป <b>Google Authenticator</b> (หรือ Microsoft Authenticator / Authy) ในโทรศัพท์</li><li>กด “เริ่มตั้งค่า” แล้วสแกน QR ด้วยแอป</li><li>ใส่รหัส 6 หลักที่แอปแสดง แล้วเก็บรหัสสำรองไว้ในที่ปลอดภัย</li></ol>
        <p><button type="button" class="button button-primary" data-2fa="new">เริ่มตั้งค่า</button></p>
    <?php else : ?>
        <p>ผู้ใช้นี้ยังไม่ได้เปิดการยืนยันตัวตนสองขั้น (ต้องตั้งค่าเองที่หน้าโปรไฟล์ของตัวเอง)</p>
    <?php endif; ?>
        <div class="idw-2fa-step" hidden></div>
    </div>
    <script>
    (function () {
        var box = document.querySelector('.idw-2fa-box'), out = box.querySelector('.idw-2fa-step'), AJ = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;
        function call(op, extra) { var fd = new FormData(); fd.append('action', 'idw_2fa'); fd.append('op', op); fd.append('uid', box.dataset.uid); fd.append('_wpnonce', box.dataset.nonce); Object.keys(extra || {}).forEach(function (k) { fd.append(k, extra[k]); });
            return fetch(AJ, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }); }
        function qrSvg(text) { var q = window.HosQR(text), n = q.getModuleCount(), s = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-4 -4 ' + (n + 8) + ' ' + (n + 8) + '" width="220" height="220" style="background:#fff;border:1px solid #dcdcde;border-radius:8px" shape-rendering="crispEdges"><path d="';
            for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) if (q.isDark(r, c)) s += 'M' + c + ' ' + r + 'h1v1h-1z'; return s + '"/></svg>'; }
        function esc(t) { var i = document.createElement('i'); i.textContent = t; return i.innerHTML; }
        function codes(list) { return '<div style="background:#fcf9e8;border:1px solid #f0c33c;border-radius:8px;padding:12px;margin-top:12px"><b>รหัสสำรอง (แสดงครั้งเดียว)</b> — ใช้แทนรหัสจากแอปได้ครั้งละ 1 ชุด เมื่อไม่มีโทรศัพท์<pre style="font-size:16px;columns:2;margin:10px 0">' + list.map(esc).join('\n') + '</pre><button type="button" class="button" onclick="navigator.clipboard&&navigator.clipboard.writeText(this.previousElementSibling.textContent)">คัดลอก</button> <button type="button" class="button" onclick="window.print()">พิมพ์</button></div>'; }
        box.addEventListener('click', function (e) {
            var b = e.target.closest('[data-2fa]'); if (!b) return; var op = b.dataset['2fa']; if (op === 'confirm') return; // handled below
            if (op === 'off' && !confirm('ปิดการยืนยันตัวตนสองขั้น? บัญชีจะเข้าระบบได้ด้วยรหัสผ่านอย่างเดียว')) return;
            if (op === 'reset' && !confirm('รีเซ็ต 2FA ของผู้ใช้นี้?')) return;
            var code = '';
            if (op === 'off' || op === 'codes') { code = prompt('ใส่รหัส 6 หลักจากแอปเพื่อยืนยัน'); if (!code) return; }
            b.disabled = true;
            call(op, { code: code }).then(function (j) { b.disabled = false;
                if (!j.success) { alert(j.data || 'ไม่สำเร็จ'); return; }
                if (op === 'new') {
                    b.hidden = true; out.hidden = false;
                    out.innerHTML = '<hr><div style="display:flex;gap:18px;flex-wrap:wrap;align-items:flex-start"><div>' + qrSvg(j.data.uri) + '</div><div style="flex:1;min-width:220px"><p><b>1.</b> เปิดแอป → เพิ่มบัญชี (+) → <b>สแกนคิวอาร์โค้ด</b></p><p style="font-size:12px;color:#646970">สแกนไม่ได้? เลือก “ป้อนคีย์การตั้งค่า” แล้วพิมพ์:<br><code style="font-size:14px;word-break:break-all">' + esc(j.data.secret.replace(/(.{4})/g, '$1 ').trim()) + '</code></p><p><b>2.</b> ใส่รหัส 6 หลักจากแอป</p><p><input type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="7" class="idw-2fa-code" style="font-size:22px;width:150px;letter-spacing:3px;text-align:center"> <button type="button" class="button button-primary" data-2fa="confirm">ยืนยันและเปิดใช้</button></p></div></div>';
                    out.querySelector('.idw-2fa-code').focus();
                } else if (op === 'confirm' || op === 'codes') {
                    out.hidden = false; out.innerHTML = (op === 'confirm' ? '<p style="color:#0a7d55;font-weight:700">✅ เปิดใช้การยืนยันตัวตนสองขั้นแล้ว — ครั้งหน้าที่เข้าสู่ระบบจะถามรหัสจากแอป</p>' : '') + codes(j.data.codes);
                } else location.reload();
            });
        });
        out.addEventListener('click', function (e) {
            var b = e.target.closest('[data-2fa="confirm"]'); if (!b) return; var inp = out.querySelector('.idw-2fa-code'); b.disabled = true;
            call('confirm', { code: inp.value }).then(function (j) { b.disabled = false; if (!j.success) { alert(j.data || 'รหัสไม่ถูกต้อง'); inp.select(); return; }
                out.innerHTML = '<p style="color:#0a7d55;font-weight:700">✅ เปิดใช้การยืนยันตัวตนสองขั้นแล้ว — ครั้งหน้าที่เข้าสู่ระบบจะถามรหัสจากแอป</p>' + codes(j.data.codes); box.querySelectorAll('[data-2fa="new"]').forEach(function (x) { x.hidden = true; }); });
        });
        out.addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target.classList.contains('idw-2fa-code')) { e.preventDefault(); out.querySelector('[data-2fa="confirm"]').click(); } });
        if (location.hash === '#idw-2fa') box.scrollIntoView({ block: 'center' });
    })();
    </script>
    <?php
}
add_action('show_user_profile', 'idw_2fa_profile', 1);
add_action('edit_user_profile', 'idw_2fa_profile', 1);

add_action('wp_ajax_idw_2fa', function () {
    $uid = absint($_POST['uid'] ?? 0); $op = sanitize_key($_POST['op'] ?? '');
    if (!$uid || !check_ajax_referer('idw_2fa_' . $uid, '_wpnonce', false)) wp_send_json_error('หน้านี้เปิดไว้นานเกินไป — โหลดหน้าใหม่แล้วลองอีกครั้ง');
    $self = get_current_user_id() === $uid;
    if (!$self && !current_user_can('edit_user', $uid)) wp_send_json_error('ไม่มีสิทธิ์');
    $code = sanitize_text_field(wp_unslash($_POST['code'] ?? ''));
    $u = get_userdata($uid);
    if ('reset' === $op) { if ($self) wp_send_json_error('ใช้ปุ่มปิดที่หน้าโปรไฟล์ของตัวเอง'); delete_user_meta($uid, IDW_2FA_META); if (function_exists('idw_sec_log')) idw_sec_log('user', 'รีเซ็ต 2FA ของ ' . $u->user_login); wp_send_json_success(); }
    if (!$self) wp_send_json_error('ไม่มีสิทธิ์');
    if ('new' === $op) {
        if (idw_2fa_enabled($uid)) wp_send_json_error('เปิดใช้อยู่แล้ว');
        $secret = idw_2fa_new_secret();
        update_user_meta($uid, '_idw_2fa_pending', ['secret' => $secret, 'exp' => time() + HOUR_IN_SECONDS]);
        $issuer = trim(wp_strip_all_tags(get_bloginfo('name'))) ?: wp_parse_url(home_url(), PHP_URL_HOST);
        $label = rawurlencode($issuer) . ':' . rawurlencode($u->user_login);
        wp_send_json_success(['secret' => $secret, 'uri' => 'otpauth://totp/' . $label . '?secret=' . $secret . '&issuer=' . rawurlencode($issuer) . '&algorithm=SHA1&digits=6&period=30']);
    }
    if ('confirm' === $op) {
        $p = get_user_meta($uid, '_idw_2fa_pending', true);
        if (!is_array($p) || $p['exp'] < time()) wp_send_json_error('หมดเวลา — กด “เริ่มตั้งค่า” ใหม่');
        $step = idw_2fa_check($p['secret'], $code);
        if ($step === false) wp_send_json_error('รหัสไม่ถูกต้อง — ตรวจว่าเวลาในโทรศัพท์ตั้งเป็นอัตโนมัติ แล้วใส่รหัสล่าสุดจากแอป');
        list($plain, $hash) = idw_2fa_backup_codes();
        update_user_meta($uid, IDW_2FA_META, ['on' => 1, 'secret' => $p['secret'], 'last' => $step, 'backup' => $hash, 'since' => time()]);
        delete_user_meta($uid, '_idw_2fa_pending');
        if (function_exists('idw_sec_log')) idw_sec_log('user', 'เปิด 2FA: ' . $u->user_login);
        wp_send_json_success(['codes' => $plain]);
    }
    if ('codes' === $op || 'off' === $op) {
        if (!idw_2fa_verify_user($uid, $code)) wp_send_json_error('รหัสไม่ถูกต้อง');
        if ('off' === $op) { delete_user_meta($uid, IDW_2FA_META); if (function_exists('idw_sec_log')) idw_sec_log('user', 'ปิด 2FA: ' . $u->user_login); wp_send_json_success(); }
        list($plain, $hash) = idw_2fa_backup_codes(); $d = idw_2fa_get($uid); $d['backup'] = $hash; update_user_meta($uid, IDW_2FA_META, $d);
        wp_send_json_success(['codes' => $plain]);
    }
    wp_send_json_error('ไม่รู้จักคำสั่ง');
});

/* users list: who has 2FA */
add_filter('manage_users_columns', function ($c) { $c['idw_2fa'] = '2FA'; return $c; });
add_filter('manage_users_custom_column', function ($v, $col, $uid) { return 'idw_2fa' === $col ? (idw_2fa_enabled($uid) ? '✅' : '—') : $v; }, 10, 3);
