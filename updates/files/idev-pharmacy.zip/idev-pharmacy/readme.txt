=== iDev Pharmacy ===
Contributors: idevapp
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

ธีมร้านขายยา: ปุ่มปรึกษาเภสัชกรทาง LINE สถานะเปิด-ปิดร้าน หมวดสินค้า บริการ เวลาเภสัชกร โปรโมชั่น และแผนที่ ใช้คู่กับ I-Drug / iDev Store และ iDev Clinic Schedule

== Copyright ==
iDev Pharmacy © iDevApp, GPLv2 or later.
Fonts: SIL Open Font License 1.1. Illustrations: by iDevApp, GPLv2 or later.
