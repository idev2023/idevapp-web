<?php
/**
 * Title: ภาพหลัก (ร้านยา)
 * Slug: idev-pharmacy/hero
 * Categories: idev-pharmacy
 * Description: ภาพหลัก (ร้านยา) — แก้ข้อความ รูป และสีได้ในตัวแก้ไข
 */
?>
<!-- wp:group {"tagName":"section","align":"full","className":"idev-hero idev-hero-pharmacy","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"primary","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull idev-hero idev-hero-pharmacy has-primary-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"verticalAlignment":"center","align":"wide"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"55%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%"><!-- wp:paragraph {"className":"idev-kicker idev-kicker-light"} -->
<p class="idev-kicker idev-kicker-light">ร้านยาใกล้บ้าน</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"textColor":"base","fontSize":"xx-large"} -->
<h1 class="wp-block-heading has-base-color has-text-color has-xx-large-font-size">ปรึกษาเภสัชกรได้ทุกวัน ยาแท้ มีคุณภาพ ราคาเป็นมิตร</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"base","fontSize":"large"} -->
<p class="has-base-color has-text-color has-large-font-size">มีเภสัชกรประจำร้าน แนะนำการใช้ยาอย่างปลอดภัย พร้อมฉลากยาภาษาไทยทุกรายการ</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"accent","textColor":"ink"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-accent-background-color has-text-color has-background wp-element-button" href="https://line.me/R/ti/p/@yourpharmacy">ทักแชต LINE</a></div>
<!-- /wp:button -->

<!-- wp:button {"textColor":"base","className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-base-color has-text-color wp-element-button" href="tel:0000000000">โทรหาเรา</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:idev/open-status /--></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%"><!-- wp:image {"sizeSlug":"full","className":"idev-hero-art"} -->
<figure class="wp-block-image size-full idev-hero-art"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/hero-pharmacy.svg" alt="ภาพประกอบร้านยา"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
