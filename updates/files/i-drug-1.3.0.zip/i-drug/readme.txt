=== I-Drug ===
Contributors: idevapp
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.3.0
License: GPLv2 or later

Pharmacy system by iDevApp: point of sale with barcode, stock by lot and expiry, drug labels, ขย. 9–13 books, customer registration, appointments and receipts with PromptPay.

One plugin: install the zip from Plugins → Add New → Upload Plugin. A licence key from iDevApp removes "TRIAL" from printed documents.
