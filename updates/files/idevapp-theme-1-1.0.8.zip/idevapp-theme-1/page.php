<?php
/** หน้าทั่วไป (รวมหน้าที่สร้างด้วย Elementor เดิม) */
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	$crumbs = array();
	foreach ( array_reverse( get_post_ancestors( get_the_ID() ) ) as $aid ) {
		$crumbs[ get_the_title( $aid ) ] = get_permalink( $aid );
	}
	if ( get_post_meta( get_the_ID(), '_hos_wysiwyg', true ) ) { // หน้าแบบแก้ไขได้ตรงหน้า
		$section = hos_page_section( get_the_ID() );
		if ( $section ) {
			$crumbs = array( $section[0] => '' ) + $crumbs;
		}
		hos_page_top( get_the_title(), $section ? $section[0] : '', has_excerpt() ? get_the_excerpt() : '', $crumbs );
		if ( hos_page_is_wide() ) {
			echo '<div class="hos-wys hos-wys-page is-wide">';
			the_content();
			echo '</div>';
		} else {
			echo '<section class="hos-inner"><div class="container hos-inner-grid"><article class="hos-sheet hos-wys">';
			the_content();
			echo '</article>';
			hos_inner_sidebar( $section );
			echo '</div></section>';
		}
		continue;
	}
	if ( hos_has_hub_blocks() ) { // หน้าออกแบบด้วยบล็อก iDevApp Hub: บล็อกจัดเลย์เอาต์เอง
		echo '<div class="hos-hub-page">';
		the_content();
		echo '</div>';
		continue;
	}
	$src_key = hos_page_source_key( get_the_ID() );
	if ( $src_key ) {
		set_query_var( 'hos_list', $src_key );
		get_template_part( 'template-parts/list-body' );
		continue;
	}
	$section = hos_page_section( get_the_ID() );
	hos_page_top( get_the_title(), $section ? $section[0] : '', has_excerpt() ? get_the_excerpt() : '', $crumbs );
	$children = hos_has_idev_shortcode() ? array() : get_pages( array( 'parent' => get_the_ID(), 'sort_column' => 'menu_order,post_title' ) );
	?>
	<section class="hos-section"><div class="container<?php echo $children ? ' hos-layout' : ''; ?>">
		<article class="hos-content"><?php the_content(); ?></article>
		<?php if ( $children ) : ?>
			<aside class="hos-side"><div class="hos-panel"><h3>ในหมวดนี้</h3><ul><?php foreach ( $children as $c ) { echo '<li><a href="' . esc_url( get_permalink( $c ) ) . '">' . esc_html( get_the_title( $c ) ) . '</a></li>'; } ?></ul></div></aside>
		<?php endif; ?>
	</div></section>
	<?php
endwhile;
get_footer();
