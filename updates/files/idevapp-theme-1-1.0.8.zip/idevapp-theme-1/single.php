<?php
/** หน้าเรื่อง/ประกาศ/เอกสาร (ทุก post type) */
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	$pto    = get_post_type_object( get_post_type() );
	$cats   = get_the_terms( get_the_ID(), 'category' );
	$crumbs = array();
	if ( $cats && ! is_wp_error( $cats ) ) {
		$crumbs[ $cats[0]->name ] = get_term_link( $cats[0] );
	} elseif ( 'post' !== get_post_type() && $pto ) {
		$crumbs[ $pto->label ] = $pto->has_archive ? get_post_type_archive_link( get_post_type() ) : add_query_arg( 's', '', home_url( '/' ) );
	}
	hos_page_top( get_the_title(), $cats && ! is_wp_error( $cats ) ? $cats[0]->name : ( $pto ? $pto->labels->singular_name : '' ), '', $crumbs );
	$doc = hos_get_document_url( get_the_ID() );
	$ext = $doc ? hos_file_ext( $doc ) : '';
	?>
	<section class="hos-section"><div class="container hos-layout">
		<article <?php post_class( 'hos-panel' ); ?>>
			<div class="hos-meta">🗓 <?php echo esc_html( hos_thai_date() ); ?></div>
			<?php if ( $doc ) : ?>
				<div class="hos-docbox"><span class="hos-filetype t-<?php echo esc_attr( $ext ); ?>"><?php echo esc_html( strtoupper( $ext ? $ext : 'ไฟล์' ) ); ?></span><div><strong>เอกสารแนบ</strong><small><?php echo esc_html( rawurldecode( basename( (string) wp_parse_url( $doc, PHP_URL_PATH ) ) ) ); ?></small></div><a class="hos-btn" href="<?php echo esc_url( $doc ); ?>" target="_blank" rel="noopener">เปิด / ดาวน์โหลด</a></div>
			<?php endif; ?>
			<?php if ( has_post_thumbnail() ) : ?><div class="hos-figure"><?php the_post_thumbnail( 'large' ); ?></div><?php endif; ?>
			<div class="hos-content"><?php the_content(); ?></div>
			<?php echo hos_idev_attachments( get_the_ID() ); // phpcs:ignore ?>
			<?php if ( $doc && 'pdf' === $ext && false === strpos( (string) get_the_content(), $doc ) ) : ?>
				<iframe class="hos-pdf" src="<?php echo esc_url( $doc ); ?>#view=FitH" title="<?php the_title_attribute(); ?>" loading="lazy"></iframe>
			<?php endif; ?>
		</article>
		<aside class="hos-side"><div class="hos-panel"><h3>ล่าสุด</h3><?php
			$args = array( 'post_type' => get_post_type(), 'posts_per_page' => 8, 'post__not_in' => array( get_the_ID() ), 'no_found_rows' => true, 'ignore_sticky_posts' => true );
			if ( $cats && ! is_wp_error( $cats ) ) {
				$args['cat'] = $cats[0]->term_id;
			}
			echo '<ul>';
			foreach ( get_posts( $args ) as $p ) {
				echo '<li><a href="' . esc_url( hos_item_link( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a></li>';
			}
			echo '</ul>';
		?></div></aside>
	</div></section>
	<?php
endwhile;
get_footer();
