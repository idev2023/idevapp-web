<?php
/**
 * Template Name: โรงพยาบาล: ติดต่อเรา
 */
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	hos_page_top( get_the_title(), 'CONTACT', hos_site_name() . ' · กระทรวงสาธารณสุข' );
	$map = hos_mod( 'hos_map_query' );
	?>
	<section class="hos-section"><div class="container">
		<div class="hos-contact">
			<div class="hos-panel"><span class="hos-icon">📍</span><h3>ที่อยู่</h3><p><?php echo esc_html( hos_mod( 'hos_address' ) ); ?></p></div>
			<div class="hos-panel"><span class="hos-icon">☎</span><h3>โทรศัพท์</h3><p><a href="<?php echo esc_attr( hos_tel( hos_mod( 'hos_phone' ) ) ); ?>"><?php echo esc_html( hos_mod( 'hos_phone' ) ); ?></a><br>แฟกซ์ <?php echo esc_html( hos_mod( 'hos_fax' ) ); ?></p></div>
			<div class="hos-panel"><span class="hos-icon">✉</span><h3>อีเมล</h3><p><a href="mailto:<?php echo esc_attr( hos_mod( 'hos_email' ) ); ?>"><?php echo esc_html( hos_mod( 'hos_email' ) ); ?></a></p></div>
			<div class="hos-panel"><span class="hos-icon">🕘</span><h3>เวลาทำการ</h3><p><?php echo esc_html( hos_mod( 'hos_hours' ) ); ?></p></div>
		</div>
		<?php if ( trim( get_the_content() ) ) : ?><div class="hos-content" style="margin-top:24px"><?php the_content(); ?></div><?php endif; ?>
		<?php if ( $map ) : ?><div class="hos-map" id="map"><iframe title="แผนที่" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="https://www.google.com/maps?q=<?php echo rawurlencode( $map ); ?>&amp;output=embed"></iframe></div><?php endif; ?>
	</div></section>
	<?php
endwhile;
get_footer();
