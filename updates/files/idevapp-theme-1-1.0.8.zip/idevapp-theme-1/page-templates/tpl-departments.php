<?php
/**
 * Template Name: โรงพยาบาล: หน่วยงานภายใน
 */
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	hos_page_top( get_the_title(), 'ORGANIZATION' );
	?>
	<section class="hos-section"><div class="container">
		<?php if ( trim( get_the_content() ) ) : ?><div class="hos-content" style="margin-bottom:24px"><?php the_content(); ?></div><?php endif; ?>
		<div class="hos-grid2"><?php foreach ( hos_data_departments() as $t => $items ) { echo '<div class="hos-panel"><h2>' . esc_html( $t ) . '</h2><ul class="hos-taglist">'; foreach ( $items as $it ) { echo '<li>' . esc_html( $it ) . '</li>'; } echo '</ul></div>'; } ?></div>
	</div></section>
	<?php
endwhile;
get_footer();
