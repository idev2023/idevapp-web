<?php
/**
 * Template Name: โรงพยาบาล: ITA การประเมินคุณธรรมและความโปร่งใส
 */
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	hos_page_top( get_the_title(), 'INTEGRITY & TRANSPARENCY ASSESSMENT', 'การเปิดเผยข้อมูลสาธารณะของโรงพยาบาล' );
	// แยกตามปีงบประมาณ: จาก meta ปีงบ (iDevApp Website) หรือจากเลขปี พ.ศ. ในหัวข้อ
	$all   = get_posts( hos_source_args( 'ita', 500, array( 'no_found_rows' => true ) ) );
	$years = array();
	foreach ( $all as $p ) {
		$y = get_post_meta( $p->ID, '_hos_fiscal_year', true );
		if ( ! $y && preg_match( '/(25\d\d)/', $p->post_title, $m ) ) {
			$y = $m[1];
		}
		if ( ! $y ) {
			$y = (string) ( (int) get_the_date( 'Y', $p ) + 543 + ( (int) get_the_date( 'n', $p ) >= 10 ? 1 : 0 ) );
		}
		$years[ $y ][] = $p;
	}
	krsort( $years );
	$sel = isset( $_GET['year'] ) && isset( $years[ $_GET['year'] ] ) ? sanitize_text_field( wp_unslash( $_GET['year'] ) ) : (string) key( $years ); // phpcs:ignore
	?>
	<section class="hos-section"><div class="container">
		<?php if ( trim( get_the_content() ) ) : ?><div class="hos-content" style="margin-bottom:24px"><?php the_content(); ?></div><?php endif; ?>
		<?php if ( $years ) : ?>
			<div class="hos-tabs"><?php foreach ( array_keys( $years ) as $y ) { echo '<a class="' . ( (string) $y === $sel ? 'on' : '' ) . '" href="' . esc_url( add_query_arg( 'year', $y ) ) . '">ITA ' . esc_html( $y ) . '</a>'; } ?></div>
			<?php
			$list = $years[ $sel ];
			usort( $list, function ( $a, $b ) { return strnatcmp( $a->post_title, $b->post_title ); } );
			$groups = array();
			foreach ( $list as $p ) {
				$g = preg_match( '/^\s*(?:O|o)?(\d+)[\.\s]/u', $p->post_title, $m ) ? $m[1] : 'อื่น ๆ';
				$groups[ $g ][] = $p;
			}
			foreach ( $groups as $g => $ps ) {
				echo '<div class="hos-panel" style="margin-bottom:18px"><h2>' . esc_html( is_numeric( $g ) ? 'ตัวชี้วัดที่ ' . $g : $g ) . '</h2>';
				hos_doc_list( $ps );
				echo '</div>';
			}
		else :
			echo '<div class="hos-empty">ยังไม่มีข้อมูล ITA — ตั้งค่าแหล่งข้อมูลที่ ลักษณะ › ปรับแต่ง › ธีมโรงพยาบาล › แหล่งข้อมูลแต่ละส่วน</div>';
		endif;
		?>
	</div></section>
	<?php
endwhile;
get_footer();
