<?php
/**
 * Template Name: โรงพยาบาล: ประวัติโรงพยาบาล
 */
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	hos_page_top( get_the_title(), 'ABOUT' );
	?>
	<section class="hos-section"><div class="container hos-prose">
		<?php if ( trim( get_the_content() ) ) : ?><div class="hos-content"><?php the_content(); ?></div>
		<?php else : foreach ( hos_data_history() as $p ) { echo '<p>' . esc_html( $p ) . '</p>'; } endif; ?>
	</div></section>
	<section class="hos-section alt"><div class="container"><div class="hos-head"><h2>ทำเนียบผู้อำนวยการ</h2></div>
		<ol class="hos-timeline"><?php foreach ( array_reverse( hos_data_directors() ) as $i => $d ) { echo '<li' . ( 0 === $i ? ' class="current"' : '' ) . '><strong>' . esc_html( $d[0] ) . '</strong><span>' . esc_html( $d[1] ) . '</span></li>'; } ?></ol>
	</div></section>
	<?php
endwhile;
get_footer();
