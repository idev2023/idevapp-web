<?php
/**
 * Template Name: โรงพยาบาล: ตารางแพทย์ออกตรวจ
 */
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	hos_page_top( get_the_title(), 'PATIENT SERVICES', 'วันและเวลาให้บริการคลินิกพิเศษ แผนกผู้ป่วยนอก' );
	$files = hos_source_is_set( 'schedule' ) ? hos_source_posts( 'schedule', 6 ) : array();
	?>
	<section class="hos-section"><div class="container">
		<?php if ( trim( get_the_content() ) ) : ?><div class="hos-content" style="margin-bottom:24px"><?php the_content(); ?></div><?php endif; ?>
		<?php if ( $files ) : ?><div class="hos-panel" style="margin-bottom:24px"><h2>ตารางแพทย์ล่าสุด</h2><?php hos_doc_list( $files ); ?></div><?php endif; ?>
		<?php if ( shortcode_exists( 'idev_schedule' ) && hos_idev_has_providers() ) : // ใช้ตารางจาก iDev Clinic Schedule ?>
			<?php echo hos_clinic_directory(); // phpcs:ignore ?>
			<details class="hos-cal"><summary>📅 ดูแบบปฏิทินรายสัปดาห์</summary><div class="hos-idev-schedule"><?php echo do_shortcode( '[idev_schedule view="week"]' ); // phpcs:ignore ?></div></details>
		<?php else : ?>
		<div class="hos-schedule"><?php foreach ( hos_data_clinics() as $day => $list ) { echo '<div class="hos-day"><h3>' . esc_html( $day ) . '</h3><ul>'; foreach ( $list as $c ) { echo '<li><span>' . esc_html( $c[0] ) . '</span><time>' . esc_html( $c[1] ) . ' น.</time></li>'; } echo '</ul></div>'; } ?></div>
		<?php endif; ?>
	</div></section>
	<?php
endwhile;
get_footer();
