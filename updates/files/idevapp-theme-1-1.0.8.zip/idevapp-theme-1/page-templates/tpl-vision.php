<?php
/**
 * Template Name: โรงพยาบาล: วิสัยทัศน์ / พันธกิจ / ค่านิยม
 */
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	hos_page_top( get_the_title(), 'VISION & MISSION' );
	$acr = function ( $title, $rows ) {
		echo '<div class="hos-panel"><h2>' . esc_html( $title ) . '</h2><ul class="hos-acronym">';
		foreach ( $rows as $r ) {
			echo '<li><b>' . esc_html( $r[0] ) . '</b><span><strong>' . esc_html( $r[1] ) . '</strong>' . esc_html( $r[2] ) . '</span></li>';
		}
		echo '</ul></div>';
	};
	?>
	<section class="hos-section"><div class="container">
		<div class="hos-vision-hero"><span>วิสัยทัศน์</span><p>“<?php echo esc_html( hos_mod( 'hos_vision' ) ); ?>”</p></div>
		<?php if ( trim( get_the_content() ) ) : ?><div class="hos-content" style="margin-bottom:24px"><?php the_content(); ?></div><?php endif; ?>
		<div class="hos-grid2"><?php foreach ( hos_data_vision_sections() as $t => $items ) { echo '<div class="hos-panel"><h2>' . esc_html( $t ) . '</h2><ol class="hos-numbered">'; foreach ( $items as $it ) { echo '<li>' . esc_html( $it ) . '</li>'; } echo '</ol></div>'; } ?></div>
		<div class="hos-grid2" style="margin-top:22px"><?php $acr( 'เข็มมุ่ง', hos_data_focus() ); $acr( 'ค่านิยมองค์กร (TMOPH)', hos_data_values() ); ?></div>
	</div></section>
	<?php
endwhile;
get_footer();
