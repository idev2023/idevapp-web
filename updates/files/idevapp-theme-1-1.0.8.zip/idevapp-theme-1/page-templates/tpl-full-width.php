<?php
/**
 * Template Name: โรงพยาบาล: เต็มหน้า (สำหรับหน้า Elementor เดิม)
 */
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	?>
	<div class="hos-content hos-full"><?php the_content(); ?></div>
	<?php
endwhile;
get_footer();
