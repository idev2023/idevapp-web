<?php
/** หน้ารวม (archive / blog / หมวดหมู่ / post type) */
defined( 'ABSPATH' ) || exit;
get_header();

if ( is_search() ) {
	$title  = 'ผลการค้นหา: ' . get_search_query();
	$kicker = 'SEARCH';
} elseif ( is_archive() ) {
	$title  = wp_strip_all_tags( get_the_archive_title() );
	$title  = preg_replace( '/^[^:]+:\s*/u', '', $title );
	$kicker = 'ARCHIVE';
} else {
	$title  = is_home() && get_option( 'page_for_posts' ) ? get_the_title( get_option( 'page_for_posts' ) ) : 'ข่าวสาร';
	$kicker = 'NEWS';
}
hos_page_top( $title, $kicker, is_archive() ? wp_strip_all_tags( get_the_archive_description() ) : '' );
$grid = ! is_search() || is_home();
?>
<section class="hos-section"><div class="container">
	<form class="hos-search" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<input name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="ค้นหาหัวข้อ...">
		<?php if ( is_post_type_archive() ) : ?><input type="hidden" name="post_type" value="<?php echo esc_attr( get_query_var( 'post_type' ) ); ?>"><?php endif; ?>
		<?php if ( is_category() ) : ?><input type="hidden" name="cat" value="<?php echo (int) get_queried_object_id(); ?>"><?php endif; ?>
		<button class="hos-btn">ค้นหา</button><span><?php echo (int) $GLOBALS['wp_query']->found_posts; ?> รายการ</span>
	</form>
	<?php
	$posts = $GLOBALS['wp_query']->posts;
	if ( $grid ) {
		$posts ? hos_news_cards( $posts ) : print( '<div class="hos-empty">ยังไม่มีรายการ</div>' );
	} else {
		hos_doc_list( $posts, is_search() ? 'ไม่พบรายการที่ค้นหา' : 'ยังไม่มีรายการ' );
	}
	the_posts_pagination( array( 'mid_size' => 2, 'prev_text' => '←', 'next_text' => '→' ) );
	?>
</div></section>
<?php
get_footer();

