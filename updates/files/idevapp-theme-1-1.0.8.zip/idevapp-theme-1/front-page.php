<?php
/** หน้าแรก */
defined( 'ABSPATH' ) || exit;
get_header();

// หน้าแรกแบบแก้ไขได้ตรงหน้า (บล็อกมาตรฐาน) — แสดงเนื้อหาตรง ๆ หน้าแก้ไข = หน้าเว็บ
if ( 'page' === get_option( 'show_on_front' ) && is_page() && get_post_meta( get_the_ID(), '_hos_wysiwyg', true ) ) {
	while ( have_posts() ) {
		the_post();
		echo '<div class="hos-wys">';
		the_content();
		echo '</div>';
	}
	get_footer();
	return;
}

// หน้าแรกที่เลือกแม่แบบ "เต็มหน้า" หรือออกแบบด้วยบล็อก iDevApp Hub → แสดงหน้านั้นแทน
if ( 'page' === get_option( 'show_on_front' ) && is_page() && ( 'page-templates/tpl-full-width.php' === get_page_template_slug() || hos_has_hub_blocks() ) ) {
	$hos_mode = get_theme_mod( 'hos_front_hero', 'hub' ); // hub = บล็อก Hub จัดหน้าตาแบบธีม | on = ส่วนบนของธีม | off = Hub เดิม
	while ( have_posts() ) {
		the_post();
		$c = get_the_content();
		if ( 'on' === $hos_mode ) {
			hos_theme_slider();
			hos_quick_strip();
			$c = preg_replace( '#<!-- wp:idevapp/(hero|slider)\s.*?/-->#s', '', $c );
			echo '<div class="hos-content hos-hub-page has-theme-top">' . apply_filters( 'the_content', $c ) . '</div>'; // phpcs:ignore
		} elseif ( 'hub' === $hos_mode ) {
			echo hos_render_hub_top( $c ); // phpcs:ignore
		} else {
			echo '<div class="hos-content hos-hub-page">' . apply_filters( 'the_content', $c ) . '</div>'; // phpcs:ignore
		}
	}
	get_footer();
	return;
}

hos_theme_slider();
?>
<?php hos_quick_strip(); ?>

<section class="hos-section"><div class="container hos-svc no-aside">
	<div>
		<div class="hos-head"><div><span class="hos-kicker">OUR SERVICES</span><h2>บริการของเรา</h2></div><a class="hos-more" href="<?php echo esc_url( hos_quick_url( '/department/' ) ); ?>">หน่วยงานทั้งหมด →</a></div>
		<p class="hos-lead"><?php echo esc_html( hos_mod( 'hos_welcome' ) ); ?></p>
		<div class="hos-svc-grid"><?php foreach ( hos_lines( 'hos_centers' ) as $c ) : $tag = ! empty( $c[2] ) ? 'a' : 'div'; ?>
			<<?php echo $tag; // phpcs:ignore ?> class="hos-svc-item"<?php echo ! empty( $c[2] ) ? ' href="' . esc_url( hos_quick_url( $c[2] ) ) . '"' : ''; ?>><span><?php echo esc_html( $c[0] ); ?></span><strong><?php echo esc_html( isset( $c[1] ) ? $c[1] : '' ); ?></strong></<?php echo $tag; // phpcs:ignore ?>>
		<?php endforeach; ?></div>
	</div>
</div></section>

<?php hos_news_section(); ?>

<?php
$hos_ita = array();
foreach ( array( 'ita-2569', 'ita-2568', 'ita-2567', 'ita-2566', 'ita65', 'ita64' ) as $slug ) {
	$l = hos_page_link( $slug, '' );
	if ( $l ) {
		$hos_ita[ $slug ] = $l['href'];
	}
}
$hos_haid = hos_page_link( 'ha-it', 'HA-IT' );
?>
<section class="hos-trans"><div class="container hos-trans-grid">
	<div><span class="hos-kicker">INTEGRITY &amp; TRANSPARENCY</span><h2>คุณธรรมและความโปร่งใส</h2><p>เปิดเผยข้อมูลสาธารณะตามเกณฑ์การประเมินคุณธรรมและความโปร่งใสในการดำเนินงานของหน่วยงานภาครัฐ (ITA)</p>
		<div class="hos-chips"><?php foreach ( $hos_ita as $slug => $href ) { echo '<a href="' . esc_url( $href ) . '">ITA ' . esc_html( preg_match( '/(\d{4})/', $slug, $m ) ? $m[1] : '25' . preg_replace( '/\D/', '', $slug ) ) . '</a>'; } ?></div>
	</div>
	<div class="hos-trans-cards">
		<a href="<?php echo esc_url( hos_source_url( 'procurement' ) ); ?>"><span>🧾</span><strong>จัดซื้อจัดจ้าง</strong><small>ประกวดราคา ราคากลาง สรุปผล</small></a>
		<a href="<?php echo esc_url( hos_source_url( 'jobs' ) ); ?>"><span>💼</span><strong>รับสมัครงาน</strong><small>ประกาศและผลการคัดเลือก</small></a>
		<?php if ( $hos_haid ) : ?><a href="<?php echo esc_url( $hos_haid['href'] ); ?>"><span>💻</span><strong>HA-IT</strong><small>พัฒนาคุณภาพระบบสารสนเทศ</small></a><?php endif; ?>
		<?php $pp = hos_page_link( 'privacy-policy', '' ); if ( $pp ) : ?><a href="<?php echo esc_url( $pp['href'] ); ?>"><span>🔒</span><strong>คุ้มครองข้อมูลส่วนบุคคล</strong><small>นโยบาย PDPA</small></a><?php endif; ?>
	</div>
</div></section>

<section class="hos-section"><div class="container hos-vision-band">
	<div><span class="hos-kicker">VISION</span><h2>วิสัยทัศน์</h2><p class="hos-vision-text">“<?php echo esc_html( hos_mod( 'hos_vision' ) ); ?>”</p><a class="hos-btn" href="<?php echo esc_url( hos_quick_url( '/vision/' ) ); ?>">พันธกิจและค่านิยม</a></div>
	<div class="hos-stats"><?php foreach ( hos_lines( 'hos_stats' ) as $s ) : ?><div><strong><?php echo esc_html( $s[0] ); ?></strong><span><?php echo esc_html( isset( $s[1] ) ? $s[1] : '' ); ?></span></div><?php endforeach; ?></div>
</div></section>

<?php $hos_links = hos_lines( 'hos_links' ); if ( $hos_links ) : ?>
<section class="hos-links"><div class="container"><div class="hos-links-grid">
	<?php foreach ( $hos_links as $l ) : if ( count( $l ) < 3 ) { continue; } ?>
		<a href="<?php echo esc_url( $l[2] ); ?>" target="_blank" rel="noopener"><span><?php echo esc_html( $l[0] ); ?></span><?php echo esc_html( $l[1] ); ?> <em>↗</em></a>
	<?php endforeach; ?>
</div></div></section>
<?php endif; ?>

<section class="hos-visit"><div class="container hos-visit-grid">
	<div class="hos-visit-info"><span class="hos-kicker">VISIT US</span><h2>การเดินทางมาโรงพยาบาล</h2>
		<p>📍 <?php echo esc_html( hos_mod( 'hos_address' ) ); ?></p>
		<p>☎ <a href="<?php echo esc_attr( hos_tel( hos_mod( 'hos_phone' ) ) ); ?>"><?php echo esc_html( hos_mod( 'hos_phone' ) ); ?></a> · แฟกซ์ <?php echo esc_html( hos_mod( 'hos_fax' ) ); ?></p>
		<p>🕘 <?php echo esc_html( hos_mod( 'hos_hours' ) ); ?></p>
		<div class="hos-hero-actions"><a class="hos-btn" href="https://www.google.com/maps/dir/?api=1&amp;destination=<?php echo rawurlencode( hos_mod( 'hos_map_query' ) ); ?>" target="_blank" rel="noopener">🧭 นำทาง</a><?php $map = hos_page_link( 'map', '' ); if ( $map ) : ?><a class="hos-btn outline" href="<?php echo esc_url( $map['href'] ); ?>">แผนที่ภายใน รพ.</a><?php endif; ?></div>
	</div>
	<div class="hos-visit-map"><iframe title="แผนที่โรงพยาบาล" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="https://www.google.com/maps?q=<?php echo rawurlencode( hos_mod( 'hos_map_query' ) ); ?>&amp;output=embed"></iframe></div>
</div></section>
<?php
get_footer();
