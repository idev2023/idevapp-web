<form class="hos-search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="hos-s">ค้นหา</label>
	<input id="hos-s" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="ค้นหา...">
	<button class="hos-btn" type="submit">ค้นหา</button>
</form>
