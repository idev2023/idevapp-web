<?php defined( 'ABSPATH' ) || exit; ?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#content">ข้ามไปเนื้อหา</a>
<div class="hos-top"><div class="container hos-top-inner">
	<span>☎ <a href="<?php echo esc_attr( hos_tel( hos_mod( 'hos_phone' ) ) ); ?>"><?php echo esc_html( hos_mod( 'hos_phone' ) ); ?></a><span class="hos-sep">|</span>🕘 <?php echo esc_html( hos_mod( 'hos_hours' ) ); ?></span>
	<span class="hos-social"><?php echo hos_idev_lang_switch(); // phpcs:ignore ?>
		<?php $hos_staff = hos_staff_link(); if ( $hos_staff ) : ?><a class="hos-staff" href="<?php echo esc_url( $hos_staff['href'] ); ?>">🔐 สำหรับเจ้าหน้าที่</a><?php endif; ?>
		<?php if ( hos_mod( 'hos_facebook' ) ) : ?><a href="<?php echo esc_url( hos_mod( 'hos_facebook' ) ); ?>" target="_blank" rel="noopener">Facebook</a><?php endif; ?>
		<?php if ( hos_mod( 'hos_youtube' ) ) : ?><a href="<?php echo esc_url( hos_mod( 'hos_youtube' ) ); ?>" target="_blank" rel="noopener">YouTube</a><?php endif; ?>
		<?php if ( hos_mod( 'hos_line' ) ) : ?><a class="hos-line" href="<?php echo esc_url( hos_mod( 'hos_line' ) ); ?>" target="_blank" rel="noopener">LINE OA</a><?php endif; ?>
	</span>
</div></div>
<header class="hos-header"><div class="container hos-nav-row">
	<a class="hos-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
		<?php if ( has_custom_logo() ) : ?>
			<?php echo wp_get_attachment_image( (int) get_theme_mod( 'custom_logo' ), 'medium', false, array( 'class' => 'hos-logo-img', 'alt' => get_bloginfo( 'name' ) ) ); ?>
		<?php else : ?><img class="hos-logo-img" src="<?php echo esc_url( get_template_directory_uri() . '/assets/logo.png' ); ?>" alt="<?php echo esc_html( hos_site_name() ); ?>" width="72" height="72"><?php endif; ?>
		<span><strong><?php echo esc_html( hos_site_name() ); ?></strong><small><?php echo esc_html( hos_mod( 'hos_tagline' ) ); ?></small></span>
	</a>
	<input type="checkbox" id="hos-menu" class="hos-menu-toggle" aria-label="เปิดเมนู">
	<label for="hos-menu" class="hos-burger" aria-hidden="true"><span></span><span></span><span></span></label>
	<nav class="hos-nav" aria-label="เมนูหลัก"><?php hos_render_menu(); ?>
 		<?php if ( hos_idev_appointment_url() ) : ?><a class="hos-btn hos-nav-cta" href="<?php echo esc_url( hos_idev_appointment_url() ); ?>">นัดหมาย</a><?php endif; ?>
		<a class="hos-search-btn" href="<?php echo esc_url( home_url( '/?s=' ) ); ?>" aria-label="ค้นหา">🔍</a>
	</nav>
</div></header>
<?php $hos_ann = hos_idev_announcements(); echo $hos_ann; // phpcs:ignore -- HTML จาก iDevApp Hub ?>
<?php if ( ! hos_hub_active() ) { echo hos_idev_ticker(); } // phpcs:ignore -- Hub แสดง ticker ในประกาศเองแล้ว ?>
<?php if ( ! trim( wp_strip_all_tags( $hos_ann ) ) && hos_mod( 'hos_announcement' ) ) : ?>
<div class="hos-announce"><div class="container hos-announce-inner"><span class="hos-announce-tag">ประกาศ</span><div class="hos-marquee"><span><?php echo esc_html( hos_mod( 'hos_announcement' ) ); ?></span></div></div></div>
<?php endif; ?>
<main id="content">
