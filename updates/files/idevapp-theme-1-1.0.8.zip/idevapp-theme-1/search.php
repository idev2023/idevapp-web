<?php
/** หน้าผลการค้นหา */
defined( 'ABSPATH' ) || exit;
require get_template_directory() . '/index.php';
