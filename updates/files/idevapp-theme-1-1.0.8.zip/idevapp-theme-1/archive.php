<?php
/** หน้ารวม archive */
defined( 'ABSPATH' ) || exit;
require get_template_directory() . '/index.php';
