<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<section class="container hos-404"><b>404</b><h1>ไม่พบหน้าที่ต้องการ</h1><p>หน้านี้อาจถูกย้ายหรือลบไปแล้ว ลองค้นหาหรือกลับหน้าแรก</p>
	<form class="hos-search-form" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>" style="max-width:480px;margin:20px auto"><input name="s" placeholder="ค้นหา..."><button class="hos-btn">ค้นหา</button></form>
	<a class="hos-btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">กลับหน้าแรก</a></section>
<?php
get_footer();
