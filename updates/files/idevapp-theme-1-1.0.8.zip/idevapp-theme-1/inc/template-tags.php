<?php
/** ฟังก์ชันช่วยแสดงผลของธีม */
defined( 'ABSPATH' ) || exit;

/** คำค้นสำหรับเดาแหล่งข้อมูลอัตโนมัติจากชื่อหมวด/ประเภทเดิม (ใช้เมื่อยังไม่ได้ตั้งค่าใน Customizer) */
function hos_source_keywords() {
	return array(
		'news'        => array( 'ประชาสัมพันธ์', 'ข่าวสาร', 'news' ),
		'procurement' => array( 'จัดซื้อ', 'จัดจ้าง', 'ประกวดราคา', 'ราคากลาง', 'procure' ),
		'jobs'        => array( 'สมัครงาน', 'รับสมัคร', 'job', 'career' ),
		'downloads'   => array( 'ดาวน์โหลด', 'ดาน์โหลด', 'เอกสารเผยแพร่', 'download' ),
		'forms'       => array( 'แบบฟอร์ม', 'form' ),
		'ita'         => array( 'ita', 'คุณธรรม', 'โปร่งใส' ),
		'schedule'    => array( 'ตารางแพทย์', 'ตารางออกตรวจ', 'schedule' ),
	);
}

/**
 * ค่าเริ่มต้น: หาหมวดหมู่จากชื่อ (เลือกหมวดเองได้ที่ ปรับแต่ง › ธีมโรงพยาบาล › แหล่งข้อมูลแต่ละส่วน)
 * key => array( post_type, taxonomy, term ids, slug ของหน้ารวมเดิม )
 */
/** หาหมวดหมู่ข่าวจากชื่อ (ใช้เป็นค่าเริ่มต้นกับเว็บโรงพยาบาลใดก็ได้ · เลือกหมวดเองได้ที่ ปรับแต่ง) */
function hos_cats_like( $words ) {
	static $all = null;
	if ( null === $all ) {
		$all = get_terms( array( 'taxonomy' => 'category', 'hide_empty' => false ) );
		$all = is_wp_error( $all ) ? array() : $all;
	}
	$ids = array();
	foreach ( $all as $t ) {
		foreach ( (array) $words as $w ) {
			if ( false !== mb_stripos( $t->name, $w ) || false !== stripos( rawurldecode( $t->slug ), $w ) ) {
				$ids[] = (int) $t->term_id;
				break;
			}
		}
	}
	return array_values( array_unique( $ids ) );
}

function hos_source_defaults() {
	$bid = hos_cats_like( array( 'ประกวดราคา', 'bidding', 'e-bidding' ) );
	$res = hos_cats_like( array( 'สรุปผล', 'result' ) );
	$mid = hos_cats_like( array( 'ราคากลาง', 'midprice' ) );
	return array(
		'news'        => array( 'post', 'category', hos_cats_like( array( 'ประชาสัมพันธ์', 'news' ) ), 'ข่าวประชาสัมพันธ์' ),
		'procurement' => array( 'post', 'category', array_values( array_unique( array_merge( $bid, $res, $mid, hos_cats_like( array( 'จัดซื้อ', 'จัดจ้าง', 'procurement' ) ) ) ) ), '' ),
		'bidding'     => array( 'post', 'category', $bid, '' ),
		'results'     => array( 'post', 'category', $res, '' ),
		'midprice'    => array( 'post', 'category', $mid, '' ),
		'jobs'        => array( 'post', 'category', hos_cats_like( array( 'รับสมัคร', 'สมัครงาน', 'job' ) ), 'ข่าวรับสมัครงาน' ),
		'downloads'   => array( 'post', '', array(), '' ),
		'forms'       => array( 'post', '', array(), '' ),
		'ita'         => array( 'post', '', array(), '' ),
		'schedule'    => array( 'post', '', array(), '' ),
		'others'      => array( 'post', '', array(), '' ),   // ข่าวอื่น ๆ = ไม่อยู่ในหมวดข้างบน
		'all'         => array( 'post', '', array(), '' ),   // ทั้งหมด
	);
}

/** หมวดที่ถือว่า "มีกลุ่มแล้ว" (ข่าวอื่น ๆ = ไม่อยู่ในหมวดเหล่านี้) */
function hos_grouped_cat_ids() {
	$ids = array();
	foreach ( array( 'news', 'procurement', 'jobs' ) as $k ) {
		list( , $tax, $i ) = hos_source( $k );
		if ( 'category' === $tax ) {
			$ids = array_merge( $ids, $i );
		}
	}
	return array_values( array_unique( array_map( 'intval', $ids ) ) );
}

/** ซ่อนข่าวเก่ากว่า N เดือน (ปรับได้ที่ ประกาศข่าว › ตั้งค่า หรือ ปรับแต่ง › หน้าแรก เมื่อไม่มีปลั๊กอิน · 0 = ไม่ซ่อน) */
function hos_news_months() {
	if ( function_exists( 'idw_ann_months' ) ) {
		return idw_ann_months( 'news' ); // ตั้งที่ ประกาศข่าว › ตั้งค่า
	}
	return max( 0, (int) get_theme_mod( 'hos_news_months', 6 ) );
}
if ( ! function_exists( 'hos_slide_months' ) ) {
	function hos_slide_months() {
		if ( function_exists( 'idw_ann_months' ) ) {
			return idw_ann_months( 'slide' );
		}
		return max( 0, (int) get_theme_mod( 'hos_slide_months', 6 ) );
	}
}

/**
 * แหล่งข้อมูลของส่วน $key: array( post_type, taxonomy, term_ids[] )
 * Customizer เลือกได้ 1 หมวด ถ้าไม่ได้เลือกใช้ค่าเริ่มต้นด้านบน (หลายหมวด)
 */
function hos_source( $key ) {
	static $cache = array();
	if ( isset( $cache[ $key ] ) ) {
		return $cache[ $key ];
	}
	$d    = hos_source_defaults();
	$d    = isset( $d[ $key ] ) ? $d[ $key ] : array( 'post', '', array(), '' );
	$type = get_theme_mod( "hos_src_{$key}_type", '' );
	$term = (string) get_theme_mod( "hos_src_{$key}_term", '' );
	$tax  = $d[1];
	$ids  = $d[2];
	if ( $term && false !== strpos( $term, ':' ) ) {
		list( $tax, $tid ) = explode( ':', $term, 2 );
		$ids = array_filter( array_map( 'intval', explode( ',', $tid ) ) );
	}
	// ตรวจว่าหมวดยังมีอยู่จริง (กันกรณีย้ายไปฐานข้อมูลอื่น)
	if ( $tax && $ids ) {
		$ids = array_values( array_filter( $ids, function ( $id ) use ( $tax ) {
			return (bool) term_exists( (int) $id, $tax );
		} ) );
	}
	if ( ! $ids ) {
		$tax = '';
	}
	$cache[ $key ] = array( $type ? $type : $d[0], $tax, $ids );
	return $cache[ $key ];
}

/** ส่วนนี้มีแหล่งข้อมูลที่เจาะจงหรือไม่ (ถ้าไม่ จะซ่อนบนหน้าแรกเพื่อไม่ให้ซ้ำกับข่าว) */
function hos_source_is_set( $key ) {
	list( $type, $tax, $ids ) = hos_source( $key );
	return in_array( $key, array( 'news', 'others', 'all' ), true ) || 'post' !== $type || $ids;
}

function hos_source_args( $key, $limit = 6, $extra = array() ) {
	list( $type, $tax, $ids ) = hos_source( $key );
	$args = array( 'post_type' => $type, 'posts_per_page' => $limit, 'ignore_sticky_posts' => true, 'post_status' => 'publish' );
	if ( $tax && $ids ) {
		$args['tax_query'] = array( array( 'taxonomy' => $tax, 'field' => 'term_id', 'terms' => $ids, 'include_children' => true ) );
		// ข่าวจาก post type อื่นที่ใช้หมวดคนละชุด (ข่าวชุดเก่า) — ใช้เฉพาะเมื่อยังไม่ได้เลือกหมวดเองใน Customizer
		$d = hos_source_defaults();
		if ( ! get_theme_mod( "hos_src_{$key}_term", '' ) && ! empty( $d[ $key ][4] ) ) {
			list( $xtype, $xtax, $xids ) = $d[ $key ][4];
			if ( post_type_exists( $xtype ) && taxonomy_exists( $xtax ) ) {
				$args['post_type']   = array( $type, $xtype );
				$args['tax_query'][] = array( 'taxonomy' => $xtax, 'field' => 'term_id', 'terms' => $xids );
				$args['tax_query']['relation'] = 'OR';
			}
		}
	}
	if ( 'others' === $key && ! $ids ) {
		$args['category__not_in'] = hos_grouped_cat_ids();
	}
	return array_merge( $args, $extra );
}

/**
 * ข่าวของส่วน — $recent = true: เฉพาะข่าวไม่เกิน N เดือน (หน้าแรก/บล็อกข่าว)
 * หน้ารวม/รายการย้อนหลังใช้ $recent = false
 */
function hos_source_posts( $key, $limit = 6, $recent = true ) {
	$extra = array( 'no_found_rows' => true );
	$m     = hos_news_months();
	if ( $recent && $m ) {
		$extra['date_query'] = array( array( 'after' => $m . ' months ago', 'inclusive' => true ) );
	}
	return get_posts( array_merge( hos_source_args( $key, $limit ), $extra ) );
}

/** หน้ารวมเดิม (เช่น /ข่าวประชาสัมพันธ์/) ของส่วน — เก็บ URL เดิมไว้ */
function hos_source_page( $key ) {
	$d = hos_source_defaults();
	if ( empty( $d[ $key ][3] ) ) {
		return null;
	}
	$p = get_page_by_path( $d[ $key ][3] );
	return ( $p && 'publish' === $p->post_status ) ? $p : null;
}

/** ส่วนที่หน้านี้เป็นหน้ารวมอยู่ (ใช้ใน page.php) */
function hos_page_source_key( $page_id ) {
	foreach ( array_keys( hos_source_defaults() ) as $key ) {
		$p = hos_source_page( $key );
		if ( $p && (int) $p->ID === (int) $page_id && hos_source_is_set( $key ) ) {
			return $key;
		}
	}
	return '';
}

/** URL หน้ารวมของส่วน */
function hos_source_url( $key ) {
	$page = hos_source_page( $key );
	if ( $page ) {
		return get_permalink( $page );
	}
	list( $type, $tax, $ids ) = hos_source( $key );
	if ( $tax && 1 === count( $ids ) ) {
		$l = get_term_link( (int) $ids[0], $tax );
		if ( ! is_wp_error( $l ) ) {
			return $l;
		}
	}
	return add_query_arg( 'hos_list', $key, home_url( '/' ) );
}

/** หน้ารวมแบบ ?hos_list=key (สำหรับ post type ที่ไม่มี archive) */
add_filter( 'query_vars', function ( $v ) {
	$v[] = 'hos_list';
	return $v;
} );
add_filter( 'template_include', function ( $tpl ) {
	$key = get_query_var( 'hos_list' );
	if ( $key && array_key_exists( $key, hos_sources() ) ) {
		status_header( 200 );
		return get_template_directory() . '/template-parts/list-page.php';
	}
	return $tpl;
} );

/** ลิงก์ที่ผู้ใช้ควรไปเมื่อคลิกรายการ: ถ้ามีไฟล์แนบและเนื้อหาว่าง → เปิดไฟล์ */
function hos_item_link( $post ) {
	$doc  = hos_get_document_url( $post->ID );
	$body = trim( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ) );
	return ( $doc && mb_strlen( $body ) < 40 ) ? $doc : get_permalink( $post );
}

/** วันที่แบบไทย พ.ศ. เช่น 17 พ.ย. 2569 */
function hos_thai_date( $post = null ) {
	$ts = get_post_timestamp( $post );
	if ( ! $ts ) {
		return '';
	}
	$m = array( '', 'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.' );
	return wp_date( 'j', $ts ) . ' ' . $m[ (int) wp_date( 'n', $ts ) ] . ' ' . ( (int) wp_date( 'Y', $ts ) + 543 );
}

/** รายการเอกสาร */
function hos_doc_list( $posts, $empty = 'ยังไม่มีรายการ' ) {
	if ( ! $posts ) {
		echo '<div class="hos-empty">' . esc_html( $empty ) . '</div>';
		return;
	}
	echo '<ul class="hos-doclist">';
	foreach ( $posts as $p ) {
		$doc  = hos_get_document_url( $p->ID );
		$ext  = $doc ? hos_file_ext( $doc ) : '';
		$href = hos_item_link( $p );
		$ext_link = $href !== get_permalink( $p );
		printf(
			'<li><a href="%s"%s><span class="hos-filetype t-%s">%s</span><span class="hos-doc-title">%s</span><time>%s</time></a></li>',
			esc_url( $href ),
			$ext_link ? ' target="_blank" rel="noopener"' : '',
			esc_attr( $ext ? $ext : 'post' ),
			esc_html( $ext ? strtoupper( $ext ) : 'ข่าว' ),
			esc_html( get_the_title( $p ) ),
			esc_html( hos_thai_date( $p ) )
		);
	}
	echo '</ul>';
}

/** ชื่อหมวดที่แสดงบนการ์ด */
function hos_card_label( $p ) {
	foreach ( array( 'category', 'news-category' ) as $tx ) {
		$cats = taxonomy_exists( $tx ) ? get_the_terms( $p, $tx ) : false;
		if ( $cats && ! is_wp_error( $cats ) ) {
			return $cats[0]->name;
		}
	}
	$pto = get_post_type_object( $p->post_type );
	return $pto ? $pto->labels->singular_name : '';
}

/** การ์ดข่าว: รูป (ถ้ามี) + หมวด/วันที่ + หัวข้อ + คำโปรย + อ่านเพิ่มเติม */
function hos_news_card( $p ) {
	$href = hos_item_link( $p );
	$new  = $href !== get_permalink( $p ) ? ' target="_blank" rel="noopener"' : '';
	$ex   = has_excerpt( $p ) ? $p->post_excerpt : wp_trim_words( wp_strip_all_tags( strip_shortcodes( $p->post_content ) ), 22, '…' );
	$style = sanitize_html_class( (string) get_post_meta( $p->ID, 'ihub_display_style', true ) );
	echo '<article class="news-card' . ( $style && 'card' !== $style ? ' news-' . esc_attr( $style ) : '' ) . '">';
	if ( has_post_thumbnail( $p ) ) {
		echo '<a class="news-image" href="' . esc_url( $href ) . '"' . $new . '>' . get_the_post_thumbnail( $p, 'hos-card', array( 'loading' => 'lazy', 'alt' => '' ) ) . '</a>'; // phpcs:ignore
	}
	echo '<div class="news-card-content"><div class="news-meta"><span class="news-category">' . esc_html( hos_card_label( $p ) ) . '</span><time class="news-date" datetime="' . esc_attr( get_the_date( 'c', $p ) ) . '">' . esc_html( hos_thai_date( $p ) ) . '</time></div>';
	echo '<h3><a href="' . esc_url( $href ) . '"' . $new . '>' . esc_html( get_the_title( $p ) ) . '</a></h3>'; // phpcs:ignore
	echo '<p>' . esc_html( $ex ) . '</p>';
	echo '<a class="text-link" href="' . esc_url( $href ) . '"' . $new . '>' . ( $new ? 'เปิดเอกสาร' : 'อ่านเพิ่มเติม' ) . ' <span>→</span></a></div></article>'; // phpcs:ignore
}

function hos_news_cards( $posts ) {
	echo '<div class="news-grid">';
	foreach ( $posts as $p ) {
		hos_news_card( $p );
	}
	echo '</div>';
}

/** ส่วนข่าวหน้าแรก: แท็บ "ทั้งหมด" + แท็บตามแต่ละส่วน  */
function hos_news_section( $per_tab = 6, $with_head = true ) {
	$m    = hos_news_months();
	$tabs = array(
		'all'         => array( 'ทั้งหมด', array() ),
		'news'        => array( 'ข่าวประชาสัมพันธ์', array() ),
		'procurement' => array( 'ประกาศประกวดราคาและจัดซื้อจัดจ้าง', array( 'bidding' => 'ข่าวประกวดราคา', 'results' => 'สรุปผลดำเนินการจัดซื้อจัดจ้าง', 'midprice' => 'ประกาศราคากลาง' ) ),
		'jobs'        => array( 'ข่าวรับสมัครงาน', array() ),
		'others'      => array( 'ข่าวอื่น ๆ', array() ),
	);
	$empty = $m ? 'ไม่มีข่าวในช่วง ' . $m . ' เดือนที่ผ่านมา' : 'ยังไม่มีรายการ';
	echo $with_head ? '<section class="hos-news-section"><div class="container">' : '<div class="hos-news-inline">';
	if ( $with_head ) {
		echo '<div class="hos-head"><div><span class="hos-kicker">NEWS &amp; UPDATES</span><h2>ข่าวสารและประกาศ</h2></div><a class="hos-more" href="' . esc_url( hos_source_url( 'news' ) ) . '">ข่าวสารทั้งหมด →</a></div>';
	}
	echo '<div class="news-tabs" role="tablist" aria-label="เลือกหมวดข่าว" data-hos-tabs>';
	$first = true;
	foreach ( $tabs as $key => $t ) {
		echo '<button type="button" role="tab" aria-selected="' . ( $first ? 'true' : 'false' ) . '" class="' . ( $first ? 'active' : '' ) . '" data-tab="' . esc_attr( $key ) . '">' . esc_html( $t[0] ) . '</button>';
		$first = false;
	}
	echo '</div>';
	$first = true;
	foreach ( $tabs as $key => $t ) {
		echo '<div class="news-panel" data-panel="' . esc_attr( $key ) . '"' . ( $first ? '' : ' hidden' ) . '>';
		$first = false;
		if ( $t[1] ) { // หมวดย่อย
			echo '<div class="news-subtabs" data-hos-subtabs><button type="button" class="on" data-sub="' . esc_attr( $key ) . '">ทั้งหมด</button>';
			foreach ( $t[1] as $sk => $sl ) {
				echo '<button type="button" data-sub="' . esc_attr( $sk ) . '">' . esc_html( $sl ) . '</button>';
			}
			echo '</div>';
			foreach ( array_merge( array( $key => $t[0] ), $t[1] ) as $sk => $sl ) {
				$posts = hos_source_posts( $sk, $per_tab );
				echo '<div class="news-subpanel" data-subpanel="' . esc_attr( $sk ) . '"' . ( $sk === $key ? '' : ' hidden' ) . '>';
				$posts ? hos_news_cards( $posts ) : print( '<div class="hos-empty">' . esc_html( $empty ) . '</div>' );
				echo '<p class="news-panel-more"><a class="text-link" href="' . esc_url( hos_source_url( $sk ) ) . '">ดู' . esc_html( $sl ) . 'ทั้งหมด <span>→</span></a></p></div>';
			}
		} else {
			$posts = hos_source_posts( $key, $per_tab );
			$posts ? hos_news_cards( $posts ) : print( '<div class="hos-empty">' . esc_html( $empty ) . '</div>' );
			if ( 'all' !== $key ) {
				echo '<p class="news-panel-more"><a class="text-link" href="' . esc_url( hos_source_url( $key ) ) . '">ดู' . esc_html( $t[0] ) . 'ทั้งหมด <span>→</span></a></p>';
			}
		}
		echo '</div>';
	}
	echo $with_head ? '</div></section>' : '</div>';
}

/** ใช้โดย shortcode ของ iDevApp Website */
function hos_theme_post_list( $posts, $style = 'list' ) {
	'grid' === $style ? hos_news_cards( $posts ) : hos_doc_list( $posts );
}

/** หัวหน้าเพจ */
function hos_page_top( $title, $kicker = '', $intro = '', $crumbs = array() ) {
	echo '<section class="hos-pagetop"><div class="container"><nav class="hos-crumbs" aria-label="breadcrumb"><a href="' . esc_url( home_url( '/' ) ) . '">หน้าแรก</a>';
	foreach ( $crumbs as $label => $url ) {
		echo ' / ' . ( $url && ! is_wp_error( $url ) ? '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>' : '<span>' . esc_html( $label ) . '</span>' );
	}
	echo ' / <span>' . esc_html( wp_strip_all_tags( $title ) ) . '</span></nav>';
	if ( $kicker ) {
		echo '<span class="hos-kicker">' . esc_html( $kicker ) . '</span>';
	}
	echo '<h1>' . esc_html( wp_strip_all_tags( $title ) ) . '</h1>';
	if ( $intro ) {
		echo '<p>' . esc_html( $intro ) . '</p>';
	}
	echo '</div><svg class="hos-pagetop-wave" viewBox="0 0 1440 60" preserveAspectRatio="none" aria-hidden="true"><path d="M0 40 C 360 0 720 70 1080 30 S 1440 20 1440 20 V60 H0Z"/></svg></section>';
}

/** URL ภาพสไลด์ขนาดใหญ่สุดที่มี (ภาพที่นำเข้ามักเป็นไฟล์ย่อ -900x670 ฯลฯ) */
function hos_best_image_url( $url ) {
	if ( ! $url ) {
		return '';
	}
	$ck = 'hos_img_' . md5( $url );
	$c  = get_transient( $ck );
	if ( false !== $c ) {
		return $c;
	}
	$r = hos_best_image_url_raw( $url );
	set_transient( $ck, $r, DAY_IN_SECONDS );
	return $r;
}
function hos_best_image_url_raw( $url ) {
	$id = attachment_url_to_postid( $url );
	if ( ! $id ) {
		$orig = preg_replace( '/-\d{2,4}x\d{2,4}(?=\.(jpe?g|png|webp|gif)$)/i', '', $url );
		$id   = $orig !== $url ? attachment_url_to_postid( $orig ) : 0;
	}
	if ( $id ) {
		$full = wp_get_attachment_image_url( $id, 'full' );
		return $full ? $full : $url;
	}
	return $url;
}

/** ไฟล์ภาพสไลด์มีอยู่จริงหรือไม่ (กันภาพแตก) */
function hos_slide_image_ok( $s ) {
	if ( empty( $s['image'] ) ) {
		return false;
	}
	$m = function_exists( 'hos_slide_too_old' ) ? 0 : hos_slide_months(); // with the plugin the age is already checked (from the day the slide went up)
	if ( $m ) {
		$id = attachment_url_to_postid( $s['image'] );
		$ts = $id ? (int) get_post_time( 'U', true, $id ) : 0;
		if ( ! $ts && preg_match( '#/uploads/(\d{4})/(\d{2})/#', $s['image'], $mm ) ) {
			$ts = strtotime( $mm[1] . '-' . $mm[2] . '-28' ); // จากโฟลเดอร์ ปี/เดือน ที่อัปโหลด
		}
		if ( $ts && $ts < strtotime( '-' . $m . ' months' ) ) {
			return false; // ภาพเก่าเกินกำหนด
		}
	}
	if ( attachment_url_to_postid( $s['image'] ) ) {
		return true;
	}
	$up   = wp_get_upload_dir();
	$src  = strtok( $s['image'], '?' );
	$base = preg_replace( '#^https?:#', '', $up['baseurl'] ); // http / https and www do not matter
	$rel  = preg_replace( '#^https?:#', '', $src );
	if ( 0 === strpos( $rel, $base ) ) {
		return file_exists( $up['basedir'] . substr( $rel, strlen( $base ) ) );
	}
	return (bool) preg_match( '#^https?://#', $src ); // a picture on another site: let the browser load it
}

/**
 * Hero หน้าแรก: ซ้าย = ชื่อโรงพยาบาล/วิสัยทัศน์/ปุ่ม, ขวา = สไลด์แบนเนอร์
 * แสดงภาพเต็มใบ (ไม่ครอป ไม่ขยายจนแตก) บนพื้นหลังภาพเดียวกันแบบเบลอ
 */
function hos_theme_slider() {
	$slides = array_values( array_filter( hos_get_slides(), 'hos_slide_image_ok' ) );
	$phone  = hos_mod( 'hos_phone' );
	echo '<section class="hos-hero2"><div class="container hos-hero2-grid">';
	echo '<div class="hos-hero2-text"><span class="hos-eyebrow">' . esc_html( hos_mod( 'hos_hero_eyebrow' ) ) . '</span>';
	echo '<h1>' . esc_html( hos_site_name() ) . '</h1><p>' . esc_html( hos_mod( 'hos_vision' ) ) . '</p>';
	echo '<div class="hos-hero-actions"><a class="hos-btn light" href="' . esc_url( hos_quick_url( hos_mod( 'hos_schedule_url' ) ) ) . '">🩺 ตารางแพทย์ออกตรวจ</a>';
	echo '<a class="hos-btn ghost" href="' . esc_attr( hos_tel( $phone ) ) . '">☎ ' . esc_html( $phone ) . '</a></div>';
	echo '<ul class="hos-hero2-facts">';
	foreach ( array_slice( hos_stat_items(), 0, 3 ) as $it ) {
		echo '<li><b>' . esc_html( $it[0] ) . '</b> ' . esc_html( $it[1] ) . '</li>';
	}
	echo '</ul></div>';

	echo '<div class="hos-hero2-media">';
	if ( $slides ) {
		echo '<div class="hos-carousel" data-hos-carousel data-interval="' . esc_attr( (int) ( ( function_exists( 'hos_slides_interval' ) ? hos_slides_interval() : 5.5 ) * 1000 ) ) . '" aria-roledescription="carousel">';
		foreach ( $slides as $i => $s ) {
			$img  = hos_best_image_url( $s['image'] );
			$tag  = $s['link'] ? 'a' : 'div';
			$href = $s['link'] ? ' href="' . esc_url( $s['link'] ) . '"' : '';
			printf(
				'<%1$s class="hos-cslide%2$s"%3$s style="--bg:url(\'%4$s\')" aria-hidden="%5$s"><img src="%4$s" alt="%6$s" %7$s decoding="async"></%1$s>',
				$tag, 0 === $i ? ' on' : '', $href, esc_url( $img ), 0 === $i ? 'false' : 'true', esc_attr( $s['title'] ), 0 === $i ? 'fetchpriority="high"' : 'loading="lazy"' // phpcs:ignore
			);
		}
		if ( count( $slides ) > 1 ) {
			echo '<button type="button" class="hos-cnav prev" aria-label="ก่อนหน้า">‹</button><button type="button" class="hos-cnav next" aria-label="ถัดไป">›</button><div class="hos-cdots">';
			foreach ( $slides as $i => $s ) {
				echo '<button type="button" class="' . ( 0 === $i ? 'on' : '' ) . '" aria-label="สไลด์ ' . ( $i + 1 ) . '"></button>';
			}
			echo '</div>';
		}
		echo '</div>';
	} else {
		$hero = hos_mod( 'hos_hero_image' );
		echo '<div class="hos-carousel empty"' . ( $hero ? ' style="--bg:url(\'' . esc_url( $hero ) . '\')"' : '' ) . '>' . ( $hero ? '<img src="' . esc_url( $hero ) . '" alt="">' : '<img src="' . esc_url( get_template_directory_uri() . '/assets/logo.png' ) . '" alt="" class="logo-ph">' ) . '</div>';
	}
	echo '</div></div></section>';
}

/** แปลงลิงก์ปุ่มลัด: #news → หน้ารวมข่าว, /slug/ → หน้า slug ถ้ามี */
function hos_quick_url( $url ) {
	if ( 0 === strpos( $url, '#' ) && array_key_exists( substr( $url, 1 ), hos_sources() ) ) {
		return hos_source_url( substr( $url, 1 ) );
	}
	if ( 0 === strpos( $url, '/' ) ) {
		$page = get_page_by_path( trim( $url, '/' ) );
		if ( ! $page && hos_mod( 'hos_schedule_url' ) === $url ) {
			$found = get_pages( array( 'meta_key' => '_wp_page_template', 'meta_value' => 'page-templates/tpl-doctor-schedule.php', 'number' => 1 ) );
			$page  = $found ? $found[0] : null;
		}
		if ( ! $page && function_exists( 'idw_svc_resolve' ) ) {
			$r = idw_svc_resolve( $url ); // finds the real schedule / booking / contact page (no 404)
			if ( 'missing' !== $r[1] && $r[0] ) {
				return $r[0];
			}
		}
		return $page ? get_permalink( $page ) : home_url( $url );
	}
	return $url;
}

/** หน้าที่ใช้ page template ที่กำหนด (ใช้สร้างลิงก์อัตโนมัติ) */
function hos_template_url( $template, $fallback = '' ) {
	$found = get_pages( array( 'meta_key' => '_wp_page_template', 'meta_value' => 'page-templates/' . $template, 'number' => 1 ) );
	return $found ? get_permalink( $found[0] ) : ( $fallback ? $fallback : home_url( '/' ) );
}

function hos_tel( $phone ) {
	return 'tel:' . preg_replace( '/[^0-9+]/', '', $phone );
}

/** หมวดนี้เป็นหมวดข่าวประชาสัมพันธ์หรือไม่ (แสดงแบบการ์ด) */
function hos_is_news_term() {
	list( , , $ids ) = hos_source( 'news' );
	return in_array( (int) get_queried_object_id(), array_map( 'intval', $ids ), true );
}

/** คลินิกพิเศษที่เปิดวันนี้ (จากตารางเว็บเดิม) */
function hos_today_clinics() {
	$days = array( 1 => 'วันจันทร์', 2 => 'วันอังคาร', 3 => 'วันพุธ', 4 => 'วันพฤหัสบดี', 5 => 'วันศุกร์' );
	$n    = (int) wp_date( 'N' );
	// ใช้ข้อมูลจาก iDev Clinic Schedule ถ้ามี (นับสัปดาห์ที่/วันหยุดตามปลั๊กอิน)
	if ( function_exists( 'hos_idev_clinics_on' ) ) {
		$date = wp_date( 'Y-m-d' );
		$off  = 0;
		while ( $n + $off > 5 && $off < 3 ) { // เสาร์-อาทิตย์ → วันจันทร์ถัดไป
			$off++;
		}
		if ( $off ) {
			$date = wp_date( 'Y-m-d', time() + ( 8 - $n ) * DAY_IN_SECONDS );
		}
		$list = hos_idev_clinics_on( $date );
		if ( null !== $list ) {
			$dn = (int) wp_date( 'N', strtotime( $date . ' 12:00' ) );
			return array( $days[ $dn ] ?? 'วันจันทร์', array_slice( $list, 0, 8 ), ! $off );
		}
	}
	$all  = hos_data_clinics();
	if ( isset( $days[ $n ] ) ) {
		return array( $days[ $n ], $all[ $days[ $n ] ], true );
	}
	return array( 'วันจันทร์', $all['วันจันทร์'], false ); // เสาร์-อาทิตย์ แสดงของวันจันทร์
}

/** ชื่อโรงพยาบาล (กันกรณีชื่อเว็บว่าง หรือปลั๊กอินสองภาษาคืนค่าว่าง) */
function hos_site_name() {
	$n = trim( wp_strip_all_tags( (string) get_bloginfo( 'name' ) ) );
	if ( '' === $n ) {
		$n = trim( (string) get_option( 'blogname' ) );
	}
	return '' !== $n ? $n : 'โรงพยาบาล';
}

/** ปุ่มลัด 6 ปุ่มใต้แบนเนอร์ */
function hos_quick_strip() {
	echo '<section class="container hos-quick">';
	foreach ( hos_lines( 'hos_quick' ) as $q ) {
		if ( count( $q ) < 3 ) {
			continue;
		}
		echo '<a href="' . esc_url( hos_quick_url( $q[2] ) ) . '" class="hos-quick-item"><span>' . esc_html( $q[0] ) . '</span><strong>' . esc_html( $q[1] ) . '</strong></a>';
	}
	echo '</section>';
}

/** ตัวเลขสถิติจาก ปรับแต่ง (บรรทัดละ ตัวเลข|คำอธิบาย) */
function hos_stat_items() {
	$out = array();
	foreach ( preg_split( '/\r?\n/', (string) hos_mod( 'hos_stats' ) ) as $line ) {
		$p = array_map( 'trim', explode( '|', $line, 2 ) );
		if ( '' !== $p[0] ) {
			$out[] = array( $p[0], isset( $p[1] ) ? $p[1] : '' );
		}
	}
	return $out;
}
