<?php
/**
 * แปลภาษาอังกฤษอัตโนมัติทุกหน้า (Google Website Translate)
 * ปุ่ม TH | EN ที่แถบบนสุด · จำภาษาที่เลือกด้วยคุกกี้ googtrans · ซ่อนแถบของ Google
 * ปิดได้ที่ ปรับแต่ง › ธีมโรงพยาบาล › รูปแบบหน้าเว็บ
 */
defined( 'ABSPATH' ) || exit;

function hos_translate_on() {
	return 'off' !== get_theme_mod( 'hos_auto_translate', 'on' ) && ! is_admin();
}

add_action( 'wp_footer', function () {
	if ( ! hos_translate_on() ) {
		return;
	}
	?>
	<script>
	/* แปลไทย → อังกฤษอัตโนมัติ: แปลข้อความทุกส่วนของหน้าในเบราว์เซอร์ (Google Translate) และจำผลไว้ในเครื่อง */
	(function () {
		var TH = /[฀-๿]/, SKIP = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEXTAREA: 1, CODE: 1, PRE: 1, svg: 1 };
		function getLang() {
			var m = document.cookie.match(/(?:^|; )hos_lang=(\w+)/); if (m) return m[1];
			return /googtrans=\/[a-z]+\/en/.test(document.cookie) ? 'en' : 'th';
		}
		function setLang(l) {
			var host = location.hostname, old = ';expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/';
			[host, '.' + host.split('.').slice(-3).join('.'), ''].forEach(function (d) { document.cookie = 'googtrans=' + old + (d ? ';domain=' + d : ''); });
			document.cookie = 'hos_lang=' + l + ';path=/;max-age=31536000;SameSite=Lax';
		}
		function mark(l) { document.querySelectorAll('.hos-lang a').forEach(function (a) { a.classList.toggle('on', a.dataset.lang === l); }); }
		var lang = getLang(); mark(lang);
		document.addEventListener('click', function (e) {
			var a = e.target.closest('.hos-lang a'); if (!a) return; e.preventDefault();
			if (a.dataset.lang === getLang() && !/googtrans/.test(document.cookie)) return;
			setLang(a.dataset.lang); location.reload();
		});
		if (lang !== 'en') { if (/googtrans/.test(document.cookie)) setLang('th'); return; }
		if (/googtrans/.test(document.cookie)) setLang('en');
		document.documentElement.lang = 'en'; document.documentElement.classList.add('hos-en');

		var mem = {}, store = null; try { store = window.localStorage; } catch (e) {}
		function cached(t) { if (mem[t] !== undefined) return mem[t]; try { var v = store && store.getItem('hosT:' + t); if (v !== null && v !== undefined) return (mem[t] = v); } catch (e) {} return undefined; }
		function remember(t, v) { mem[t] = v; try { store && store.setItem('hosT:' + t, v); } catch (e) {} }
		function skip(el) { for (; el && el !== document.body; el = el.parentElement) { if (SKIP[el.nodeName] || (el.classList && el.classList.contains('notranslate')) || (el.getAttribute && el.getAttribute('translate') === 'no') || el.isContentEditable) return true; } return false; }
		function collect(root, jobs) {
			var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), n;
			while ((n = w.nextNode())) {
				if (n.__hos || !TH.test(n.nodeValue) || skip(n.parentElement)) continue;
				var raw = n.nodeValue, core = raw.replace(/\s+/g, ' ').trim(); if (!core) continue;
				jobs.push({ text: core, apply: (function (node, r) { return function (v) { var lead = r.match(/^\s*/)[0], tail = r.match(/\s*$/)[0]; node.__hos = 1; node.nodeValue = lead + v + tail; }; })(n, raw) });
			}
			(root.querySelectorAll ? root.querySelectorAll('[placeholder],[title],[aria-label],img[alt],input[type=submit],input[type=button]') : []).forEach(function (el) {
				if (skip(el)) return;
				['placeholder', 'title', 'aria-label', 'alt', 'value'].forEach(function (at) {
					var v = el.getAttribute(at); if (!v || !TH.test(v) || (at === 'value' && !/submit|button/.test(el.type))) return;
					jobs.push({ text: v.replace(/\s+/g, ' ').trim(), apply: function (x) { el.setAttribute(at, x); } });
				});
			});
		}
		function request(list) {
			var body = new URLSearchParams({ q: list.join('\n') });
			return fetch('https://translate.googleapis.com/translate_a/single?client=gtx&sl=th&tl=en&dt=t', { method: 'POST', body: body })
				.then(function (r) { return r.json(); })
				.then(function (j) { return (j && j[0] ? j[0].map(function (s) { return s[0] || ''; }).join('') : '').split('\n').map(function (s) { return s.trim(); }); });
		}
		function translateBatch(list) {
			return request(list).then(function (out) {
				if (out.length === list.length) { list.forEach(function (t, i) { remember(t, out[i]); }); return; }
				return Promise.all(list.map(function (t) { return request([t]).then(function (o) { remember(t, o.join(' ')); }); }));
			}).catch(function () {});
		}
		var badge = null, running = 0;
		function busy(on) {
			running += on ? 1 : -1;
			if (!badge) { badge = document.createElement('div'); badge.className = 'hos-tr-badge notranslate'; badge.textContent = 'Translating…'; document.body.appendChild(badge); }
			badge.classList.toggle('on', running > 0);
		}
		function run(root) {
			var jobs = []; collect(root, jobs); if (!jobs.length) return;
			var todo = [], seen = {};
			jobs.forEach(function (j) { var c = cached(j.text); if (c !== undefined) j.apply(c); else if (!seen[j.text]) { seen[j.text] = 1; todo.push(j.text); } });
			if (!todo.length) return;
			var batches = [], cur = [], len = 0;
			todo.forEach(function (t) { if (len + t.length > 1800 && cur.length) { batches.push(cur); cur = []; len = 0; } cur.push(t); len += t.length + 1; });
			if (cur.length) batches.push(cur);
			busy(true);
			var i = 0;
			function next() { if (i >= batches.length) return Promise.resolve(); return translateBatch(batches[i++]).then(next); }
			Promise.all([next(), next(), next()]).then(function () {
				jobs.forEach(function (j) { var c = cached(j.text); if (c !== undefined && c !== '') j.apply(c); });
				busy(false);
			});
		}
		function start() {
			run(document.body);
			var pending = [], t = null;
			new MutationObserver(function (ms) {
				ms.forEach(function (m) { m.addedNodes.forEach(function (n) { if (n.nodeType === 1 || n.nodeType === 3) pending.push(n.nodeType === 3 ? n.parentNode : n); }); if (m.type === 'characterData' && m.target.parentNode && !m.target.__hos) pending.push(m.target.parentNode); });
				clearTimeout(t); t = setTimeout(function () { var p = pending; pending = []; p.forEach(function (n) { if (n && n.isConnected && n !== badge) run(n); }); }, 120);
			}).observe(document.body, { childList: true, subtree: true });
		}
		document.title && TH.test(document.title) && (function () { var c = cached(document.title); if (c) document.title = c; else request([document.title]).then(function (o) { remember(document.title, o.join(' ')); document.title = o.join(' '); }).catch(function () {}); })();
		document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', start) : start();
	})();
	</script>
	<?php
}, 50 );

add_action( 'wp_head', function () {
	if ( ! hos_translate_on() ) {
		return;
	}
	echo '<style>.hos-tr-badge{position:fixed;left:16px;bottom:16px;z-index:9999;background:#075a3e;color:#fff;font:600 13px/1 sans-serif;padding:9px 14px;border-radius:999px;box-shadow:0 8px 24px rgba(0,0,0,.2);opacity:0;transform:translateY(10px);transition:.25s;pointer-events:none}.hos-tr-badge.on{opacity:1;transform:none}.hos-tr-badge:before{content:"";display:inline-block;width:10px;height:10px;margin-right:8px;border:2px solid #fff;border-right-color:transparent;border-radius:50%;animation:hosspin .7s linear infinite;vertical-align:-1px}@keyframes hosspin{to{transform:rotate(360deg)}}</style>' . "\n";
}, 1 );

/** ส่วนที่ไม่ควรแปล: ชื่อแพทย์ เบอร์โทร ตัวเลข */
add_filter( 'body_class', function ( $c ) {
	return $c;
} );
