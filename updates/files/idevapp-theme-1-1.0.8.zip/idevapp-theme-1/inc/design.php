<?php
/**
 * ปรับแต่ง › ธีมโรงพยาบาล › 🎨 สีและหน้าตา / 🔤 ตัวอักษร / 📐 รูปทรงและเลย์เอาต์
 * ค่าที่เว้นว่าง = ใช้สีตั้งต้นของธีม · ดูผลสดในหน้าปรับแต่ง
 */
defined( 'ABSPATH' ) || exit;

/** ชุดสีสำเร็จรูป */
function hosd_presets() {
	return array(
		'moph'   => array( 'เขียวกระทรวงสาธารณสุข', array( 'primary' => '#0a7d55', 'dark' => '#075a3e', 'accent' => '#3fbf8f', 'soft' => '#e8f5ef', 'highlight' => '#d9a521', 'bg' => '#f5f8f7', 'footer_bg' => '#062e20' ) ),
		'blue'   => array( 'น้ำเงินโรงพยาบาล', array( 'primary' => '#1f5fbf', 'dark' => '#123f86', 'accent' => '#3f8ef0', 'soft' => '#eaf1fc', 'highlight' => '#f2b705', 'bg' => '#f4f7fb', 'footer_bg' => '#0b2551' ) ),
		'navy'   => array( 'กรมท่า-ทอง (ทางการ)', array( 'primary' => '#163d8f', 'dark' => '#0d2a66', 'accent' => '#2f6fd6', 'soft' => '#eaf0fb', 'highlight' => '#c9a227', 'bg' => '#f4f6fa', 'footer_bg' => '#0a1f4d' ) ),
		'teal'   => array( 'ฟ้าอมเขียว', array( 'primary' => '#0e8a92', 'dark' => '#086169', 'accent' => '#2cc1b8', 'soft' => '#e6f6f6', 'highlight' => '#f29f05', 'bg' => '#f3f9f9', 'footer_bg' => '#053c41' ) ),
		'purple' => array( 'ม่วง', array( 'primary' => '#6a3fb5', 'dark' => '#4b2a86', 'accent' => '#9b6ae0', 'soft' => '#f1ebfb', 'highlight' => '#e0a100', 'bg' => '#f7f5fb', 'footer_bg' => '#2a1650' ) ),
		'pink'   => array( 'ชมพู (สตรีและเด็ก)', array( 'primary' => '#d6336c', 'dark' => '#a61e4d', 'accent' => '#f06595', 'soft' => '#fdecf2', 'highlight' => '#7048e8', 'bg' => '#fdf7f9', 'footer_bg' => '#5c1029' ) ),
		'orange' => array( 'ส้มอบอุ่น', array( 'primary' => '#e8590c', 'dark' => '#b8410a', 'accent' => '#fd7e14', 'soft' => '#fff1e6', 'highlight' => '#0b7285', 'bg' => '#fffaf6', 'footer_bg' => '#4a1d05' ) ),
		'red'    => array( 'แดง (ฉุกเฉิน/กาชาด)', array( 'primary' => '#c92a2a', 'dark' => '#962020', 'accent' => '#f03e3e', 'soft' => '#fdeaea', 'highlight' => '#f2b705', 'bg' => '#fbf7f7', 'footer_bg' => '#3d0b0b' ) ),
		'gray'   => array( 'เทาเรียบหรู', array( 'primary' => '#343a40', 'dark' => '#212529', 'accent' => '#0ca678', 'soft' => '#f1f3f5', 'highlight' => '#fab005', 'bg' => '#f8f9fa', 'footer_bg' => '#16191c' ) ),
	);
}

/** สีที่ปรับได้: key => [กลุ่ม, ชื่อ, CSS ที่ใช้ค่านี้ (%s = สี)] */
function hosd_colors() {
	return array(
		'primary'      => array( 'หลัก', 'สีหลัก (ปุ่ม ลิงก์ หัวข้อ)', ':root{--g:%1$s;--teal:%1$s}' ),
		'dark'         => array( 'หลัก', 'สีหลักเข้ม (แถบบน แบนเนอร์)', ':root{--g-dark:%1$s;--teal-dark:%1$s}' ),
		'accent'       => array( 'หลัก', 'สีรอง / ไล่สี', ':root{--g-mint:%1$s}' ),
		'soft'         => array( 'หลัก', 'สีพื้นอ่อน (กล่อง ป้าย)', ':root{--g-soft:%1$s}' ),
		'highlight'    => array( 'หลัก', 'สีเน้น (ป้ายประกาศ ไฮไลต์)', ':root{--gold:%1$s}' ),
		'bg'           => array( 'พื้นและตัวอักษร', 'พื้นหลังหน้าเว็บ', ':root{--bg:%1$s}body{background:%1$s}' ),
		'card'         => array( 'พื้นและตัวอักษร', 'พื้นการ์ด/กล่องเนื้อหา', ':root{--card:%1$s}.hos-sheet,.hos-panel,.hos-aside-card{background:%1$s}' ),
		'text'         => array( 'พื้นและตัวอักษร', 'ตัวอักษรหลัก', ':root{--ink:%1$s}body{color:%1$s}' ),
		'muted'        => array( 'พื้นและตัวอักษร', 'ตัวอักษรรอง (วันที่ คำอธิบาย)', ':root{--muted:%1$s}' ),
		'line'         => array( 'พื้นและตัวอักษร', 'เส้นขอบ', ':root{--line:%1$s}' ),
		'link'         => array( 'พื้นและตัวอักษร', 'สีลิงก์ในเนื้อหา', '.hos-sheet a:not(.wp-block-button__link),.hos-content a:not(.wp-block-button__link):not(.hos-btn){color:%1$s}' ),
		'topbar_bg'    => array( 'ส่วนหัว', 'แถบบนสุด — พื้น', '.hos-top{background:%1$s}' ),
		'topbar_text'  => array( 'ส่วนหัว', 'แถบบนสุด — ตัวอักษร', '.hos-top,.hos-top a{color:%1$s}' ),
		'header_bg'    => array( 'ส่วนหัว', 'แถบโลโก้/เมนู — พื้น', '.hos-header{background:%1$s;backdrop-filter:none}' ),
		'header_text'  => array( 'ส่วนหัว', 'แถบโลโก้/เมนู — ชื่อและเมนู', '.hos-brand strong,.hos-nav>a,.hos-dd>button,.hos-search-btn{color:%1$s}' ),
		'menu_hover'   => array( 'ส่วนหัว', 'เมนู — พื้นเมื่อชี้', '.hos-nav>a:hover,.hos-dd:hover>button,.hos-dd:focus-within>button{background:%1$s}' ),
		'announce_bg'  => array( 'ส่วนหัว', 'แถบประกาศวิ่ง — พื้น', '.hos-announce{background:%1$s}' ),
		'announce_text' => array( 'ส่วนหัว', 'แถบประกาศวิ่ง — ตัวอักษร', '.hos-announce,.hos-announce a{color:%1$s}' ),
		'btn_bg'       => array( 'ปุ่ม', 'ปุ่ม — พื้น', '.hos-btn:not(.light):not(.ghost),.hos-content .wp-block-button:not(.hos-btn-light):not(.hos-btn-ghost)>.wp-block-button__link:not(.has-background),.hos-sheet .wp-block-button:not(.hos-btn-light):not(.hos-btn-ghost)>.wp-block-button__link:not(.has-background){background:%1$s!important}' ),
		'btn_text'     => array( 'ปุ่ม', 'ปุ่ม — ตัวอักษร', '.hos-btn:not(.light):not(.ghost),.hos-content .wp-block-button:not(.hos-btn-light):not(.hos-btn-ghost)>.wp-block-button__link:not(.has-text-color),.hos-sheet .wp-block-button:not(.hos-btn-light):not(.hos-btn-ghost)>.wp-block-button__link:not(.has-text-color){color:%1$s!important}' ),
		'footer_bg'    => array( 'ส่วนท้าย', 'ส่วนท้าย — พื้น', '.hos-footer{background:%1$s}' ),
		'footer_text'  => array( 'ส่วนท้าย', 'ส่วนท้าย — ตัวอักษร', '.hos-footer,.hos-footer a{color:%1$s}' ),
		'footer_head'  => array( 'ส่วนท้าย', 'ส่วนท้าย — หัวข้อ', '.hos-footer h4,.hos-footer .hos-brand strong{color:%1$s}' ),
	);
}

/** ฟอนต์ไทยจาก Google Fonts */
function hosd_fonts() {
	return array(
		'IBM Plex Sans Thai' => 'IBM Plex Sans Thai (ค่าเริ่มต้น)',
		'Sarabun'            => 'Sarabun สารบรรณ (ราชการ)',
		'Noto Sans Thai'     => 'Noto Sans Thai',
		'Prompt'             => 'Prompt',
		'Kanit'              => 'Kanit',
		'Anuphan'            => 'Anuphan',
		'Bai Jamjuree'       => 'Bai Jamjuree',
		'Mitr'               => 'Mitr',
		'Chakra Petch'       => 'Chakra Petch',
		'Noto Serif Thai'    => 'Noto Serif Thai (มีหัว)',
	);
}

function hosd_get( $key, $default = '' ) {
	return get_theme_mod( 'hosd_' . $key, $default );
}

/** URL Google Fonts ตามฟอนต์ที่เลือก */
function hosd_fonts_url() {
	$fams = array_unique( array_filter( array( hosd_get( 'font', 'IBM Plex Sans Thai' ), hosd_get( 'font_head', '' ) ) ) );
	$q    = array();
	foreach ( $fams as $f ) {
		if ( isset( hosd_fonts()[ $f ] ) ) {
			$q[] = 'family=' . str_replace( ' ', '+', $f ) . ':wght@300;400;500;600;700';
		}
	}
	$q[] = 'family=Manrope:wght@400;500;600;700;800';
	return 'https://fonts.googleapis.com/css2?' . implode( '&', $q ) . '&display=swap';
}

/** ข้อมูลที่ JS หน้าปรับแต่งใช้สร้าง CSS ชุดเดียวกับ PHP */
function hosd_rules() {
	$r = array();
	foreach ( hosd_colors() as $k => $c ) {
		$r[ $k ] = $c[2];
	}
	return $r;
}

/** CSS ตามค่าที่ตั้ง */
function hosd_css() {
	$css = '';
	foreach ( hosd_colors() as $k => $c ) {
		$v = sanitize_hex_color( (string) hosd_get( $k ) );
		if ( $v ) {
			$css .= sprintf( $c[2], $v );
		}
	}
	$font = hosd_get( 'font', '' );
	if ( $font && isset( hosd_fonts()[ $font ] ) ) {
		$css .= ":root{--font:'" . $font . "',sans-serif}body,button,input,select,textarea{font-family:var(--font)}";
	}
	$fh = hosd_get( 'font_head', '' );
	if ( $fh && isset( hosd_fonts()[ $fh ] ) ) {
		$css .= "h1,h2,h3,h4,.hos-brand strong,.hos-pagetop h1{font-family:'" . $fh . "',var(--font)}";
	}
	$size = (int) hosd_get( 'size', 0 );
	if ( $size ) {
		$css .= 'body{font-size:' . $size . 'px}.hos-sheet,.hos-content{font-size:' . ( $size + 1 ) . 'px}';
	}
	$hw = (int) hosd_get( 'head_weight', 0 );
	if ( $hw ) {
		$css .= 'h1,h2,h3,.hos-pagetop h1{font-weight:' . $hw . '}';
	}
	$rad = hosd_get( 'radius', '' );
	if ( '' !== $rad ) {
		$rad  = (int) $rad;
		$css .= ':root{--r:' . $rad . 'px}.hos-btn,.wp-block-button__link{border-radius:' . min( $rad, 14 ) . 'px!important}.hos-sheet,.hos-panel,.hos-aside-card,.news-card,.hos-card{border-radius:' . $rad . 'px!important}';
	}
	$sh = hosd_get( 'shadow', '' );
	if ( 'none' === $sh ) {
		$css .= ':root{--shadow:none}.hos-sheet,.hos-aside-card,.hos-panel{box-shadow:none!important}';
	} elseif ( 'strong' === $sh ) {
		$css .= ':root{--shadow:0 18px 50px rgba(0,0,0,.16)}';
	}
	$w = (int) hosd_get( 'width', 0 );
	if ( $w ) {
		$css .= '.container{width:min(' . $w . 'px,calc(100% - 40px))}';
	}
	if ( 'off' === hosd_get( 'sticky', 'on' ) ) {
		$css .= '.hos-header{position:relative}';
	}
	if ( 'off' === hosd_get( 'topbar', 'on' ) ) {
		$css .= '.hos-top{display:none}';
	}
	if ( 'off' === hosd_get( 'announce', 'on' ) ) {
		$css .= '.hos-announce{display:none}';
	}
	if ( 'flat' === hosd_get( 'pagetop', '' ) ) {
		$css .= '.hos-pagetop{background:var(--g-dark)}.hos-pagetop:before,.hos-pagetop:after{display:none}';
	} elseif ( 'light' === hosd_get( 'pagetop', '' ) ) {
		$css .= '.hos-pagetop{background:var(--g-soft);color:var(--ink)}.hos-pagetop h1{color:var(--g-dark);text-shadow:none}.hos-pagetop p,.hos-pagetop .hos-crumbs,.hos-pagetop .hos-crumbs a{color:var(--muted)}.hos-pagetop .hos-crumbs{background:#fff}.hos-pagetop:after{color:rgba(0,0,0,.04)}';
	}
	$extra = (string) hosd_get( 'custom_css', '' );
	return $css . wp_strip_all_tags( $extra );
}

add_action( 'wp_head', function () {
	echo '<style id="hosd-css">' . hosd_css() . '</style>' . "\n"; // phpcs:ignore
}, 99 );
// ตัวแก้ไขบล็อกใช้สี/ฟอนต์เดียวกัน
add_action( 'enqueue_block_assets', function () {
	if ( is_admin() ) {
		wp_register_style( 'hosd-editor', false, array(), HOS_THEME_VER );
		wp_enqueue_style( 'hosd-editor' );
		wp_add_inline_style( 'hosd-editor', hosd_css() );
	}
} );

add_action( 'customize_register', function ( WP_Customize_Manager $wp ) {
	$wp->add_section( 'hosd_colors', array( 'title' => '🎨 สีและหน้าตา', 'panel' => 'hos', 'priority' => 1, 'description' => 'เลือกชุดสีสำเร็จรูป แล้วปรับทีละสีได้ · ช่องที่ล้างว่าง = ใช้สีตั้งต้นของธีม' ) );
	$wp->add_section( 'hosd_type', array( 'title' => '🔤 ตัวอักษร', 'panel' => 'hos', 'priority' => 2 ) );
	$wp->add_section( 'hosd_layout', array( 'title' => '📐 รูปทรงและเลย์เอาต์', 'panel' => 'hos', 'priority' => 3 ) );

	$choices = array( '' => '— เลือกชุดสี —' );
	foreach ( hosd_presets() as $k => $p ) {
		$choices[ $k ] = $p[0];
	}
	$wp->add_setting( 'hosd_preset', array( 'default' => '', 'sanitize_callback' => 'sanitize_key', 'transport' => 'postMessage' ) );
	$wp->add_control( 'hosd_preset', array( 'section' => 'hosd_colors', 'label' => 'ชุดสีสำเร็จรูป', 'type' => 'select', 'choices' => $choices, 'description' => 'เลือกแล้วสีหลักด้านล่างจะเปลี่ยนตาม (ปรับต่อได้)' ) );

	$group = '';
	foreach ( hosd_colors() as $k => $c ) {
		$wp->add_setting( 'hosd_' . $k, array( 'default' => '', 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'postMessage' ) );
		$wp->add_control( new WP_Customize_Color_Control( $wp, 'hosd_' . $k, array( 'section' => 'hosd_colors', 'label' => $c[1], 'description' => $group !== $c[0] ? '— ' . $c[0] . ' —' : '' ) ) );
		$group = $c[0];
	}

	$fonts = array( '' => 'ค่าเริ่มต้นของธีม' ) + hosd_fonts();
	$wp->add_setting( 'hosd_font', array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp->add_control( 'hosd_font', array( 'section' => 'hosd_type', 'label' => 'ฟอนต์เนื้อหา', 'type' => 'select', 'choices' => $fonts ) );
	$wp->add_setting( 'hosd_font_head', array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp->add_control( 'hosd_font_head', array( 'section' => 'hosd_type', 'label' => 'ฟอนต์หัวข้อ', 'type' => 'select', 'choices' => array( '' => 'เหมือนฟอนต์เนื้อหา' ) + hosd_fonts() ) );
	$wp->add_setting( 'hosd_size', array( 'default' => 0, 'sanitize_callback' => 'absint', 'transport' => 'postMessage' ) );
	$wp->add_control( 'hosd_size', array( 'section' => 'hosd_type', 'label' => 'ขนาดตัวอักษรพื้นฐาน (px) · 0 = ค่าเริ่มต้น', 'type' => 'number', 'input_attrs' => array( 'min' => 0, 'max' => 22, 'step' => 1 ) ) );
	$wp->add_setting( 'hosd_head_weight', array( 'default' => 0, 'sanitize_callback' => 'absint', 'transport' => 'postMessage' ) );
	$wp->add_control( 'hosd_head_weight', array( 'section' => 'hosd_type', 'label' => 'ความหนาหัวข้อ', 'type' => 'select', 'choices' => array( 0 => 'ค่าเริ่มต้น', 400 => 'ปกติ', 500 => 'กลาง', 600 => 'หนา', 700 => 'หนามาก' ) ) );

	$sel = function ( $key, $label, $ch, $def = '' ) use ( $wp ) {
		$wp->add_setting( 'hosd_' . $key, array( 'default' => $def, 'sanitize_callback' => 'sanitize_key', 'transport' => 'postMessage' ) );
		$wp->add_control( 'hosd_' . $key, array( 'section' => 'hosd_layout', 'label' => $label, 'type' => 'select', 'choices' => $ch ) );
	};
	$wp->add_setting( 'hosd_radius', array( 'default' => '', 'sanitize_callback' => function ( $v ) { return '' === $v ? '' : max( 0, min( 32, (int) $v ) ); }, 'transport' => 'postMessage' ) );
	$wp->add_control( 'hosd_radius', array( 'section' => 'hosd_layout', 'label' => 'ความมนของมุม (0 = เหลี่ยม · 32 = มนมาก · ว่าง = ค่าเริ่มต้น)', 'type' => 'range', 'input_attrs' => array( 'min' => 0, 'max' => 32, 'step' => 1 ) ) );
	$sel( 'shadow', 'เงาของการ์ด', array( '' => 'ปกติ', 'none' => 'ไม่มีเงา (เรียบ)', 'strong' => 'เงาชัด' ) );
	$wp->add_setting( 'hosd_width', array( 'default' => 0, 'sanitize_callback' => 'absint', 'transport' => 'postMessage' ) );
	$wp->add_control( 'hosd_width', array( 'section' => 'hosd_layout', 'label' => 'ความกว้างเนื้อหาสูงสุด (px) · 0 = ค่าเริ่มต้น 1240', 'type' => 'number', 'input_attrs' => array( 'min' => 0, 'max' => 1600, 'step' => 20 ) ) );
	$sel( 'pagetop', 'หัวหน้าภายใน', array( '' => 'ไล่สีพร้อมลวดลาย', 'flat' => 'สีพื้นเรียบ', 'light' => 'พื้นอ่อน ตัวอักษรเข้ม' ) );
	$sel( 'sticky', 'แถบเมนูติดด้านบนเมื่อเลื่อน', array( 'on' => 'เปิด', 'off' => 'ปิด' ), 'on' );
	$sel( 'topbar', 'แถบบนสุด (เบอร์โทร/เวลาทำการ)', array( 'on' => 'แสดง', 'off' => 'ซ่อน' ), 'on' );
	$sel( 'announce', 'แถบประกาศวิ่ง', array( 'on' => 'แสดง', 'off' => 'ซ่อน' ), 'on' );
	$wp->add_setting( 'hosd_custom_css', array( 'default' => '', 'sanitize_callback' => 'wp_strip_all_tags', 'transport' => 'postMessage' ) );
	$wp->add_control( 'hosd_custom_css', array( 'section' => 'hosd_layout', 'label' => 'CSS เพิ่มเติม (สำหรับผู้ดูแล)', 'type' => 'textarea' ) );
} );

/* หน้าปรับแต่ง: ชุดสี → ตั้งค่าสีให้, และพรีวิวสดโดยไม่ต้องรีเฟรช */
add_action( 'customize_controls_enqueue_scripts', function () {
	wp_register_script( 'hosd-controls', false, array( 'customize-controls' ), HOS_THEME_VER, true );
	wp_enqueue_script( 'hosd-controls' );
	$p = array();
	foreach ( hosd_presets() as $k => $v ) {
		$p[ $k ] = $v[1];
	}
	wp_add_inline_script( 'hosd-controls', 'wp.customize.bind("ready",function(){var P=' . wp_json_encode( $p ) . ';wp.customize("hosd_preset",function(s){s.bind(function(v){if(!P[v])return;Object.keys(P[v]).forEach(function(k){var c=wp.customize("hosd_"+k);if(c)c.set(P[v][k]);});});});});' );
} );
add_action( 'customize_preview_init', function () {
	wp_register_script( 'hosd-preview', false, array( 'customize-preview' ), HOS_THEME_VER, true );
	wp_enqueue_script( 'hosd-preview' );
	$keys = array_merge( array_map( function ( $k ) { return 'hosd_' . $k; }, array_keys( hosd_colors() ) ), array( 'hosd_size', 'hosd_head_weight', 'hosd_radius', 'hosd_shadow', 'hosd_width', 'hosd_pagetop', 'hosd_sticky', 'hosd_topbar', 'hosd_announce', 'hosd_custom_css' ) );
	$js   = '(function(api){var R=' . wp_json_encode( hosd_rules() ) . ',K=' . wp_json_encode( $keys ) . ';'
		. 'function v(k){var s=api(k);return s?s.get():"";}'
		. 'function css(){var o="";Object.keys(R).forEach(function(k){var c=v("hosd_"+k);if(c&&/^#[0-9a-f]{3,8}$/i.test(c))o+=R[k].replace(/%1\$s/g,c);});'
		. 'var z=+v("hosd_size");if(z)o+="body{font-size:"+z+"px}.hos-sheet,.hos-content{font-size:"+(z+1)+"px}";'
		. 'var hw=+v("hosd_head_weight");if(hw)o+="h1,h2,h3,.hos-pagetop h1{font-weight:"+hw+"}";'
		. 'var r=v("hosd_radius");if(r!==""&&r!==null){r=+r;o+=":root{--r:"+r+"px}.hos-btn,.wp-block-button__link{border-radius:"+Math.min(r,14)+"px!important}.hos-sheet,.hos-panel,.hos-aside-card,.news-card,.hos-card{border-radius:"+r+"px!important}";}'
		. 'var sh=v("hosd_shadow");if(sh==="none")o+=":root{--shadow:none}.hos-sheet,.hos-aside-card,.hos-panel{box-shadow:none!important}";else if(sh==="strong")o+=":root{--shadow:0 18px 50px rgba(0,0,0,.16)}";'
		. 'var w=+v("hosd_width");if(w)o+=".container{width:min("+w+"px,calc(100% - 40px))}";'
		. 'if(v("hosd_sticky")==="off")o+=".hos-header{position:relative}";if(v("hosd_topbar")==="off")o+=".hos-top{display:none}";if(v("hosd_announce")==="off")o+=".hos-announce{display:none}";'
		. 'var pt=v("hosd_pagetop");if(pt==="flat")o+=".hos-pagetop{background:var(--g-dark)}.hos-pagetop:before,.hos-pagetop:after{display:none}";else if(pt==="light")o+=".hos-pagetop{background:var(--g-soft);color:var(--ink)}.hos-pagetop h1{color:var(--g-dark);text-shadow:none}.hos-pagetop p,.hos-pagetop .hos-crumbs,.hos-pagetop .hos-crumbs a{color:var(--muted)}.hos-pagetop .hos-crumbs{background:#fff}";'
		. 'o+=v("hosd_custom_css")||"";var el=document.getElementById("hosd-css");if(!el){el=document.createElement("style");el.id="hosd-css";document.head.appendChild(el);}el.textContent=o;}'
		. 'K.forEach(function(k){api(k,function(s){s.bind(css);});});})(wp.customize);';
	wp_add_inline_script( 'hosd-preview', $js );
} );
