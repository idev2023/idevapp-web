<?php
/**
 * สไลด์หน้าแรกในตัวธีม: เมนู “สไลด์หน้าแรก” (ภาพเด่น = ภาพสไลด์, ข้อความสรุป = ข้อความรอง, ลิงก์, ลำดับ)
 * ถ้ามีปลั๊กอินที่ลงทะเบียนสไลด์ชนิดเดียวกัน (hos_slide) อยู่แล้ว ธีมจะใช้ของปลั๊กอิน
 */
defined( 'ABSPATH' ) || exit;

add_action( 'init', function () {
	if ( post_type_exists( 'hos_slide' ) ) {
		return;
	}
	register_post_type( 'hos_slide', array(
		'labels'        => array( 'name' => 'สไลด์หน้าแรก', 'singular_name' => 'สไลด์', 'add_new_item' => 'เพิ่มสไลด์', 'edit_item' => 'แก้ไขสไลด์', 'menu_name' => 'สไลด์หน้าแรก' ),
		'public'        => false,
		'show_ui'       => true,
		'menu_icon'     => 'dashicons-images-alt2',
		'menu_position' => 21,
		'supports'      => array( 'title', 'excerpt', 'thumbnail', 'page-attributes' ),
	) );
	add_action( 'add_meta_boxes_hos_slide', function () {
		add_meta_box( 'host-slide-link', 'ลิงก์เมื่อคลิก', function ( $post ) {
			wp_nonce_field( 'host_slide', 'host_slide_nonce' );
			echo '<input type="url" class="widefat" name="host_slide_link" value="' . esc_attr( get_post_meta( $post->ID, '_hos_slide_link', true ) ) . '" placeholder="https://">';
			echo '<p class="description">ภาพสไลด์ = “ภาพเด่น” (แนะนำ 1920×1080) · ข้อความรอง = “ข้อความสรุป” · ลำดับ = “ลำดับ” ในกล่องคุณสมบัติ</p>';
		}, 'hos_slide', 'normal', 'high' );
	} );
	add_action( 'save_post_hos_slide', function ( $post_id ) {
		if ( isset( $_POST['host_slide_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['host_slide_nonce'] ) ), 'host_slide' ) && current_user_can( 'edit_post', $post_id ) ) {
			update_post_meta( $post_id, '_hos_slide_link', esc_url_raw( wp_unslash( isset( $_POST['host_slide_link'] ) ? $_POST['host_slide_link'] : '' ) ) );
		}
	} );
}, 20 );

if ( ! function_exists( 'hos_get_slides' ) ) {
	/** สไลด์ที่เผยแพร่ เรียงตามลำดับ: array of [title, subtitle, image, link, date] */
	function hos_get_slides() {
		$out = array();
		foreach ( get_posts( array( 'post_type' => 'hos_slide', 'post_status' => 'publish', 'numberposts' => 20, 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'DESC' ) ) ) as $s ) {
			$img = get_the_post_thumbnail_url( $s, 'full' );
			if ( ! $img ) {
				$img = get_post_meta( $s->ID, '_hos_slide_image', true );
			}
			$out[] = array( 'title' => get_the_title( $s ), 'subtitle' => $s->post_excerpt, 'image' => $img, 'link' => get_post_meta( $s->ID, '_hos_slide_link', true ), 'date' => $s->post_date );
		}
		return $out;
	}
}
