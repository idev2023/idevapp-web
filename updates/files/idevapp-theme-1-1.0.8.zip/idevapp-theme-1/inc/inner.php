<?php
/**
 * หน้าภายใน (ทุกหน้าที่ไม่ใช่หน้าแรก): ชื่อหน้าภาษาไทย, แถบข้าง (เมนูในหมวด + ติดต่อ), กรอบเนื้อหา
 */
defined( 'ABSPATH' ) || exit;

/** ชื่อหน้าเดิมที่เป็นภาษาอังกฤษ/slug → ชื่อไทย */
function hos_title_map() {
	return apply_filters( 'hos_title_map', array(
		'history'     => 'ประวัติโรงพยาบาล',
		'vision'      => 'วิสัยทัศน์ พันธกิจ ค่านิยม',
		'mngteam'     => 'ทีมผู้บริหาร',
		'mng_policy'  => 'นโยบายผู้บริหาร',
		'department'  => 'หน่วยงานและกลุ่มงาน',
		'teamdetails' => 'รายละเอียดทีมแพทย์',
		'map'         => 'แผนที่การเดินทาง',
		'ita64'       => 'ITA 2564',
		'ita65'       => 'ITA 2565',
		'appointment' => 'นัดหมายออนไลน์',
		'cancel page' => 'ยกเลิกนัดหมาย',
	) );
}

function hos_thai_title( $title ) {
	$map = hos_title_map();
	$k   = strtolower( trim( wp_strip_all_tags( (string) $title ) ) );
	return isset( $map[ $k ] ) ? $map[ $k ] : $title;
}

add_filter( 'the_title', function ( $title, $id = 0 ) {
	if ( is_admin() || 'page' !== get_post_type( $id ) ) {
		return $title;
	}
	return hos_thai_title( $title );
}, 10, 2 );
add_filter( 'document_title_parts', function ( $p ) {
	if ( isset( $p['title'] ) ) {
		$p['title'] = hos_thai_title( $p['title'] );
	}
	return $p;
} );
add_filter( 'nav_menu_item_title', function ( $t ) {
	return hos_thai_title( $t );
} );

/** หมวดของหน้า (จากเมนูหลัก): [ชื่อหมวด, [ [label,url,current], ... ] ] */
function hos_page_section( $page_id ) {
	$locs = get_nav_menu_locations();
	if ( empty( $locs['primary'] ) ) {
		return null;
	}
	$items = wp_get_nav_menu_items( $locs['primary'] );
	if ( ! $items ) {
		return null;
	}
	$byid = array();
	foreach ( $items as $it ) {
		$byid[ $it->ID ] = $it;
	}
	$url = untrailingslashit( get_permalink( $page_id ) );
	foreach ( $items as $it ) {
		$hit = ( 'post_type' === $it->type && (int) $it->object_id === (int) $page_id ) || untrailingslashit( $it->url ) === $url;
		if ( ! $hit || ! $it->menu_item_parent || empty( $byid[ $it->menu_item_parent ] ) ) {
			continue;
		}
		$parent = $byid[ $it->menu_item_parent ];
		$list   = array();
		foreach ( $items as $s ) {
			if ( (int) $s->menu_item_parent === (int) $parent->ID ) {
				$list[] = array( hos_thai_title( $s->title ), $s->url, $s->ID === $it->ID );
			}
		}
		return array( hos_thai_title( $parent->title ), $list );
	}
	return null;
}

/** หน้าที่มีบล็อกกว้าง (ตาราง/แผนที่/บล็อก Hub) ให้แสดงเต็มความกว้าง ไม่มีแถบข้าง */
function hos_page_is_wide( $post = null ) {
	$c = (string) get_post_field( 'post_content', $post ? $post : get_the_ID() );
	return (bool) preg_match( '#<!-- wp:(idevapp/|hos/clinics|hos/map|hos/campus|hos/slider|idev)|\[(idev|ihub_)|alignfull#', $c );
}

/** แถบข้างหน้าภายใน */
function hos_inner_sidebar( $section = null ) {
	echo '<aside class="hos-aside">';
	if ( $section && $section[1] ) {
		echo '<nav class="hos-aside-card hos-aside-nav"><h3>' . esc_html( $section[0] ) . '</h3><ul>';
		foreach ( $section[1] as $l ) {
			echo '<li' . ( $l[2] ? ' class="is-current"' : '' ) . '><a href="' . esc_url( $l[1] ) . '"' . ( $l[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $l[0] ) . '</a></li>';
		}
		echo '</ul></nav>';
	}
	$phone = hos_mod( 'hos_phone' );
	echo '<div class="hos-aside-card hos-aside-contact"><h3>ติดต่อโรงพยาบาล</h3>';
	if ( $phone ) {
		echo '<a class="hos-aside-phone" href="' . esc_url( hos_tel( $phone ) ) . '"><span>☎</span><b>' . esc_html( $phone ) . '</b><small>โทรศัพท์</small></a>';
	}
	echo '<a class="hos-aside-phone is-red" href="tel:1669"><span>🚑</span><b>1669</b><small>เจ็บป่วยฉุกเฉิน 24 ชม.</small></a>';
	if ( hos_mod( 'hos_hours' ) ) {
		echo '<p class="hos-aside-note">🕘 ' . esc_html( hos_mod( 'hos_hours' ) ) . '</p>';
	}
	echo '</div>';
	$quick = array(
		array( '🩺', 'ตารางแพทย์ออกตรวจ', hos_quick_url( hos_mod( 'hos_schedule_url' ) ) ),
		array( '📢', 'ข่าวประชาสัมพันธ์', hos_source_url( 'news' ) ),
		array( '📍', 'แผนที่การเดินทาง', home_url( '/map/' ) ),
	);
	echo '<div class="hos-aside-card hos-aside-quick"><h3>ลิงก์ด่วน</h3>';
	foreach ( $quick as $q ) {
		echo '<a href="' . esc_url( $q[2] ) . '"><span>' . esc_html( $q[0] ) . '</span>' . esc_html( $q[1] ) . '<i>→</i></a>';
	}
	echo '</div></aside>';
}
