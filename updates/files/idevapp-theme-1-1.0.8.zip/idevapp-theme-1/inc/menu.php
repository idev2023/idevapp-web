<?php
/**
 * เมนูหลัก
 * ค่าเริ่มต้น: เมนูจัดหมวดของธีม (6 หมวด) สร้างจากหน้าเดิมในเว็บ — ไม่รก ลิงก์เดิมครบ
 * ถ้าต้องการใช้เมนูที่ตั้งใน รูปลักษณ์ › เมนู ให้เลือกที่ ปรับแต่ง › ธีมโรงพยาบาล › รูปแบบหน้าเว็บ › แหล่งเมนู
 */
defined( 'ABSPATH' ) || exit;

function hos_menu_tree( $location ) {
	$locations = get_nav_menu_locations();
	if ( empty( $locations[ $location ] ) ) {
		return null;
	}
	$items = wp_get_nav_menu_items( $locations[ $location ] );
	if ( ! $items ) {
		return null;
	}
	_wp_menu_item_classes_by_context( $items );
	$map = array();
	foreach ( $items as $it ) {
		$map[ $it->ID ] = array( 'label' => $it->title, 'href' => $it->url, 'target' => $it->target, 'children' => array(), 'parent' => (int) $it->menu_item_parent );
	}
	$tree = array();
	foreach ( $map as $id => $node ) {
		if ( $node['parent'] && isset( $map[ $node['parent'] ] ) ) {
			$map[ $node['parent'] ]['children'][] = $node;
		}
	}
	foreach ( $map as $node ) {
		if ( ! $node['parent'] || ! isset( $map[ $node['parent'] ] ) ) {
			$tree[] = $node;
		}
	}
	return $tree;
}

/** ลิงก์หน้าเดิมจาก slug (ไม่มีหน้า → ข้าม) */
function hos_page_link( $slug, $label, $desc = '', $icon = '' ) {
	$p = get_page_by_path( $slug );
	if ( ! $p || 'publish' !== $p->post_status ) {
		return null;
	}
	return array( 'label' => $label, 'href' => get_permalink( $p ), 'desc' => $desc, 'icon' => $icon );
}

/** เมนูจัดหมวดของธีม */
function hos_default_menu() {
	$f = function ( $items ) {
		return array_values( array_filter( $items ) );
	};
	$news = $f( array(
		array( 'label' => 'ข่าวประชาสัมพันธ์', 'href' => hos_source_url( 'news' ), 'icon' => '📢', 'desc' => 'ข่าวและกิจกรรมของโรงพยาบาล' ),
		array( 'label' => 'ประกาศประกวดราคาและจัดซื้อจัดจ้าง', 'href' => hos_source_url( 'procurement' ), 'icon' => '🧾', 'desc' => 'ประกวดราคา · สรุปผลจัดซื้อจัดจ้าง · ราคากลาง' ),
		array( 'label' => 'ข่าวรับสมัครงาน', 'href' => hos_source_url( 'jobs' ), 'icon' => '💼', 'desc' => 'ประกาศรับสมัครและผลการคัดเลือก' ),
		array( 'label' => 'ข่าวอื่น ๆ', 'href' => hos_source_url( 'others' ), 'icon' => '🗞️', 'desc' => 'กิจกรรม สาระน่ารู้ และข่าวทั่วไป' ),
		hos_page_link( 'ดาน์โหลดเอกสาร', 'ดาวน์โหลดเอกสาร', 'แบบฟอร์มและเอกสารเผยแพร่', '📄' ),
		hos_mod( 'hos_stats_url' ) ? array( 'label' => 'ข้อมูลสถิติ', 'href' => hos_mod( 'hos_stats_url' ), 'target' => '_blank', 'icon' => '📊', 'desc' => 'สถิติบริการ' ) : null,
	) );
	$about = $f( array(
		hos_page_link( 'history', 'ประวัติโรงพยาบาล', '', '🏥' ),
		hos_page_link( 'vision', 'วิสัยทัศน์ / พันธกิจ / ค่านิยม', '', '🎯' ),
		hos_page_link( 'mngteam', 'คณะผู้บริหาร', '', '👥' ),
		hos_page_link( 'mng_policy', 'นโยบายผู้บริหาร', '', '📜' ),
		hos_page_link( 'department', 'หน่วยงานภายใน', '', '🏢' ),
		hos_page_link( 'teamdetails', 'ข้อมูลบุคลากร', '', '🧑‍⚕️' ),
		hos_page_link( 'กวป', 'ประชุมกรรมการบริหาร (กวป.)', '', '🗂️' ),
	) );
	$patient = $f( array(
		hos_page_link( 'doctor-schedule', 'ตารางแพทย์ออกตรวจ', 'คลินิกพิเศษ วัน-เวลาให้บริการ', '🩺' ),
		hos_page_link( 'map', 'แผนที่ภายในโรงพยาบาล', 'อาคารและจุดบริการ', '🗺️' ),
		hos_page_link( '845-2', 'MOPH Service', 'บริการออนไลน์ กระทรวงสาธารณสุข', '📱' ),
		hos_page_link( 'fittofly', 'ใบรับรองแพทย์ Fit to Fly', '', '✈️' ),
		hos_idev_appointment_url() ? array( 'label' => 'นัดหมายออนไลน์', 'href' => hos_idev_appointment_url(), 'icon' => '📅' ) : null,
	) );
	$ita = array();
	foreach ( array( 'ita-2569' => '2569', 'ita-2568' => '2568', 'ita-2567' => '2567', 'ita-2566' => '2566', 'ita65' => '2565', 'ita64' => '2564' ) as $slug => $y ) {
		$ita[] = hos_page_link( $slug, 'ITA ' . $y, '', '🛡️' );
	}
	$trans = $f( array_merge( $ita, array(
		hos_page_link( 'ha-it', 'HA-IT พัฒนาคุณภาพระบบสารสนเทศ', '', '💻' ),
		hos_page_link( 'privacy-policy', 'นโยบายคุ้มครองข้อมูลส่วนบุคคล', '', '🔒' ),
	) ) );
	$contact = hos_page_link( 'ติดต่อเรา', 'ติดต่อเรา' );
	$menu    = array( array( 'label' => 'หน้าแรก', 'href' => home_url( '/' ) ) );
	if ( $about ) {
		$menu[] = array( 'label' => 'เกี่ยวกับเรา', 'href' => '#', 'children' => $about );
	}
	if ( $patient ) {
		$menu[] = array( 'label' => 'บริการผู้ป่วย', 'href' => '#', 'children' => $patient );
	}
	$menu[] = array( 'label' => 'ข่าวสาร', 'href' => '#', 'children' => $news, 'wide' => true );
	if ( $trans ) {
		$menu[] = array( 'label' => 'ITA / ความโปร่งใส', 'href' => '#', 'children' => $trans, 'wide' => true );
	}
	$menu[] = array( 'label' => 'ติดต่อเรา', 'href' => $contact ? $contact['href'] : hos_template_url( 'tpl-contact.php', home_url( '/contact/' ) ) );
	return $menu;
}

/** ลิงก์สำหรับเจ้าหน้าที่ (แสดงที่แถบบนสุด) */
function hos_staff_link() {
	$p = hos_page_link( 'ระบบงานภายใน', 'สำหรับเจ้าหน้าที่' );
	if ( ! $p ) {
		$p = hos_page_link( 'สำหรับเจ้าหน้าที่', 'สำหรับเจ้าหน้าที่' );
	}
	return $p;
}

function hos_render_menu() {
	$tree = 'wp' === get_theme_mod( 'hos_menu_source', 'theme' ) ? hos_menu_tree( 'primary' ) : null;
	if ( ! $tree ) {
		$tree = hos_default_menu();
	}
	$current = home_url( add_query_arg( array() ) );
	foreach ( $tree as $item ) {
		if ( ! empty( $item['children'] ) ) {
			$wide = ! empty( $item['wide'] ) || count( $item['children'] ) > 6;
			$on   = false;
			foreach ( $item['children'] as $c ) {
				$on = $on || ( untrailingslashit( $c['href'] ) === untrailingslashit( $current ) );
			}
			echo '<div class="hos-dd' . ( $on ? ' current-menu-ancestor' : '' ) . '"><button type="button" aria-haspopup="true">' . esc_html( $item['label'] ) . ' <span class="hos-caret" aria-hidden="true"></span></button><div class="hos-dd-menu' . ( $wide ? ' wide' : '' ) . '">';
			foreach ( $item['children'] as $c ) {
				$t = ! empty( $c['target'] ) ? ' target="' . esc_attr( $c['target'] ) . '" rel="noopener"' : '';
				echo '<a href="' . esc_url( $c['href'] ) . '"' . $t . '>'; // phpcs:ignore
				if ( ! empty( $c['icon'] ) ) {
					echo '<span class="hos-mi">' . esc_html( $c['icon'] ) . '</span>';
				}
				echo '<span><b>' . esc_html( $c['label'] ) . '</b>' . ( ! empty( $c['desc'] ) ? '<small>' . esc_html( $c['desc'] ) . '</small>' : '' ) . '</span></a>';
			}
			echo '</div></div>';
		} else {
			$t   = ! empty( $item['target'] ) ? ' target="' . esc_attr( $item['target'] ) . '" rel="noopener"' : '';
			$cls = untrailingslashit( $item['href'] ) === untrailingslashit( $current ) ? ' class="current-menu-item"' : '';
			echo '<a href="' . esc_url( $item['href'] ) . '"' . $t . $cls . '>' . esc_html( $item['label'] ) . '</a>'; // phpcs:ignore
		}
	}
}
