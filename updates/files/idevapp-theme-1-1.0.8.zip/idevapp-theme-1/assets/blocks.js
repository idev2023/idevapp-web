/* บล็อกของธีม: แสดงตัวอย่างจริงจากเซิร์ฟเวอร์ (ServerSideRender) + ตั้งค่าที่แถบขวา */
(function (wp) {
  var el = wp.element.createElement, reg = wp.blocks.registerBlockType;
  var SSR = wp.serverSideRender, IC = wp.blockEditor.InspectorControls, useBP = wp.blockEditor.useBlockProps;
  var C = wp.components, src = (window.HOS_BLOCKS && HOS_BLOCKS.sources) || {};
  var srcOpts = Object.keys(src).map(function (k) { return { value: k, label: src[k] }; });
  function make(name, title, icon, panel) {
    reg(name, {
      apiVersion: 3, title: title, icon: icon, category: 'hos',
      edit: function (p) {
        var bp = useBP({ className: 'hos-ssr' });
        return el('div', bp,
          panel ? el(IC, null, el(C.PanelBody, { title: 'ตั้งค่า', initialOpen: true }, panel(p))) : null,
          el(SSR, { block: name, attributes: p.attributes }));
      },
      save: function () { return null; }
    });
  }
  make('hos/slider', 'สไลด์ภาพ (จากเมนู สไลด์หน้าแรก)', 'images-alt2', function (p) {
    return [el(C.RangeControl, { key: 'm', label: 'จำนวนภาพสูงสุด', min: 1, max: 20, value: p.attributes.max, onChange: function (v) { p.setAttributes({ max: v }); } }),
      el('p', { key: 'n', style: { fontSize: 12, color: '#666' } }, 'เพิ่ม/ลบ/เรียงภาพได้ที่เมนู “สไลด์หน้าแรก”')];
  });
  make('hos/news', 'ข่าว/ประกาศ (การ์ด)', 'megaphone', function (p) {
    return [el(C.SelectControl, { key: 's', label: 'แหล่งข่าว', value: p.attributes.source, options: srcOpts, onChange: function (v) { p.setAttributes({ source: v }); } }),
      el(C.RangeControl, { key: 'c', label: 'จำนวน', min: 1, max: 24, value: p.attributes.count, onChange: function (v) { p.setAttributes({ count: v }); } }),
      el(C.ToggleControl, { key: 'm', label: 'แสดงลิงก์ “ดูทั้งหมด”', checked: p.attributes.more, onChange: function (v) { p.setAttributes({ more: v }); } })];
  });
  make('hos/doclist', 'รายการเอกสาร/ประกาศ (แบบรายการ)', 'media-document', function (p) {
    return [el(C.SelectControl, { key: 's', label: 'แหล่งข้อมูล', value: p.attributes.source, options: srcOpts.filter(function (o) { return o.value !== 'all'; }), onChange: function (v) { p.setAttributes({ source: v }); } }),
      el(C.RangeControl, { key: 'c', label: 'จำนวน', min: 1, max: 50, value: p.attributes.count, onChange: function (v) { p.setAttributes({ count: v }); } })];
  });
  make('hos/clinics', 'ตารางออกตรวจ (ค้นหาคลินิก)', 'calendar-alt', function () {
    return el('p', { style: { fontSize: 12, color: '#666' } }, 'ข้อมูลมาจากเมนู Clinic schedule (iDev Clinic Schedule)');
  });
  make('hos/map', 'แผนที่ Google', 'location-alt', function (p) {
    return [el(C.TextControl, { key: 'q', label: 'คำค้นหา/พิกัด (เว้นว่าง = ค่าจากธีม)', value: p.attributes.query, onChange: function (v) { p.setAttributes({ query: v }); } }),
      el(C.SelectControl, { key: 'v', label: 'รูปแบบแผนที่', value: p.attributes.view || 'both', options: [{ value: 'both', label: 'ดาวเทียม + แผนที่ถนน (สลับได้)' }, { value: 'sat', label: 'ภาพถ่ายดาวเทียมอย่างเดียว' }, { value: 'road', label: 'แผนที่ถนนอย่างเดียว' }], onChange: function (v) { p.setAttributes({ view: v }); } }),
      el(C.RangeControl, { key: 'h', label: 'ความสูง (px)', min: 200, max: 800, value: p.attributes.height, onChange: function (v) { p.setAttributes({ height: v }); } })];
  });
})(window.wp);
