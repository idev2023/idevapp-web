/* iDevApp แบบที่ 1 theme: สไลด์, ปุ่มกลับขึ้นบน, เมนูมือถือ */
(function () {
  // ---- slider ----
  document.querySelectorAll('[data-hos-slider]').forEach(function (hero) {
    var slides = hero.querySelectorAll('.hos-slide');
    var dots = hero.querySelectorAll('.hos-dots button');
    var text = hero.querySelector('.hos-slide-text');
    var orig = text ? text.innerHTML : '';
    var i = 0, timer;
    function show(n) {
      if (!slides.length) return;
      slides[i].classList.remove('on'); if (dots[i]) dots[i].classList.remove('on');
      i = (n + slides.length) % slides.length;
      slides[i].classList.add('on'); if (dots[i]) dots[i].classList.add('on');
      var s = slides[i].dataset;
      if (text) {
        if (s.title || s.sub) {
          var h = document.createElement('div');
          var t = document.createElement('h2'); t.textContent = s.title || ''; h.appendChild(t);
          if (s.sub) { var p = document.createElement('p'); p.textContent = s.sub; h.appendChild(p); }
          if (s.link) { var a = document.createElement('a'); a.className = 'hos-btn ghost'; a.href = s.link; a.textContent = 'ดูรายละเอียด →'; h.appendChild(a); }
          text.innerHTML = h.innerHTML;
        } else { text.innerHTML = orig; }
        text.style.animation = 'none'; void text.offsetWidth; text.style.animation = '';
      }
    }
    function start() { if (slides.length > 1) timer = setInterval(function () { show(i + 1); }, 6000); }
    dots.forEach(function (d, n) { d.addEventListener('click', function () { clearInterval(timer); show(n); start(); }); });
    slides.forEach(function (s) { if (s.dataset.link) { s.style.cursor = 'pointer'; s.addEventListener('click', function () { location.href = s.dataset.link; }); } });
    if (slides[0] && (slides[0].dataset.title || slides[0].dataset.sub)) show(0);
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) start();
  });
  // ---- scroll top ----
  var btn = document.querySelector('.hos-scrolltop');
  if (btn) {
    var y = function () { return window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0; };
    var onScroll = function () { btn.classList.toggle('show', y() > 500); };
    window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      try { window.scrollTo({ top: 0, behavior: 'smooth' }); } catch (err) { window.scrollTo(0, 0); }
      if (document.body.scrollTop) document.body.scrollTop = 0;
    });
  }
  // ---- dropdown: แตะเปิด/ปิดบนมือถือ, Esc ปิดเมนู ----
  document.querySelectorAll('.hos-dd > button').forEach(function (b) {
    b.addEventListener('click', function () { b.parentNode.classList.toggle('open'); });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { var t = document.getElementById('hos-menu'); if (t) t.checked = false; }
  });
})();

/* แท็บข่าว */
document.querySelectorAll('[data-hos-tabs]').forEach(function (bar) {
  var wrap = bar.parentNode;
  bar.querySelectorAll('button').forEach(function (b) {
    b.addEventListener('click', function () {
      bar.querySelectorAll('button').forEach(function (x) { x.classList.toggle('active', x === b); x.setAttribute('aria-selected', x === b); });
      wrap.querySelectorAll('.news-panel').forEach(function (p) { p.hidden = p.dataset.panel !== b.dataset.tab; });
    });
  });
});

/* carousel หน้าแรก */
document.querySelectorAll('[data-hos-carousel]').forEach(function (c) {
  var s = c.querySelectorAll('.hos-cslide'), d = c.querySelectorAll('.hos-cdots button'), i = 0, t;
  if (s.length < 2) return;
  function go(n) {
    s[i].classList.remove('on'); s[i].setAttribute('aria-hidden', 'true'); if (d[i]) d[i].classList.remove('on');
    i = (n + s.length) % s.length;
    s[i].classList.add('on'); s[i].setAttribute('aria-hidden', 'false'); if (d[i]) d[i].classList.add('on');
    var img = s[(i + 1) % s.length].querySelector('img'); if (img) img.loading = 'eager'; // โหลดภาพถัดไปล่วงหน้า
  }
  function play() { stop(); if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) t = setInterval(function () { go(i + 1); }, +c.dataset.interval || 5500); }
  function stop() { clearInterval(t); }
  c.querySelector('.prev').addEventListener('click', function (e) { e.preventDefault(); go(i - 1); play(); });
  c.querySelector('.next').addEventListener('click', function (e) { e.preventDefault(); go(i + 1); play(); });
  d.forEach(function (b, n) { b.addEventListener('click', function (e) { e.preventDefault(); go(n); play(); }); });
  c.addEventListener('mouseenter', stop); c.addEventListener('mouseleave', play);
  var x0 = null;
  c.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
  c.addEventListener('touchend', function (e) { if (x0 === null) return; var dx = e.changedTouches[0].clientX - x0; if (Math.abs(dx) > 40) { go(i + (dx < 0 ? 1 : -1)); play(); } x0 = null; });
  play();
});

/* ตารางออกตรวจ: มุมมอง วัน/รายชื่อ, หมวด, ค้นหา */
document.querySelectorAll('[data-hos-clinics]').forEach(function (box) {
  var input = box.querySelector('[data-search]'), mode = 'day', group = 'all', none = box.querySelector('[data-noresult]');
  var cal = hosMonth(box);
  function norm(s) { return (s || '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  function hl(el, q) {
    if (!el.dataset.raw) el.dataset.raw = el.textContent;
    var raw = el.dataset.raw, i = q ? norm(raw).indexOf(q) : -1;
    if (i < 0) { el.textContent = raw; return; }
    el.textContent = ''; var m = document.createElement('mark'); m.textContent = raw.slice(i, i + q.length);
    el.append(raw.slice(0, i), m, raw.slice(i + q.length));
  }
  function apply() {
    var q = norm(input.value), shown = 0;
    box.querySelectorAll('[data-mode-panel]').forEach(function (p) { p.hidden = p.dataset.modePanel !== mode; });
    if (mode === 'month') {
      shown = cal ? cal.render(q, group) : 0;
    } else if (mode === 'day') {
      // ค้นหา: ค้นทุกวัน แสดงวันที่มีผลลัพธ์ทั้งหมด
      box.querySelectorAll('.hos-day-panel').forEach(function (panel) {
        var n = 0;
        panel.querySelectorAll('.hos-rows li').forEach(function (li) {
          var ok = (group === 'all' || li.dataset.group === group) && (!q || norm(li.dataset.name).indexOf(q) > -1);
          li.hidden = !ok; if (ok) n++;
          var nm = li.querySelector('.n'); if (nm && nm.firstChild) { var t = nm.childNodes[0]; if (!li.dataset.raw) li.dataset.raw = t.textContent; t.textContent = li.dataset.raw; }
        });
        panel.querySelectorAll('.hos-dpart').forEach(function (sec) { sec.hidden = !sec.querySelector('li:not([hidden])'); });
        var active = box.querySelector('.hos-days button.on');
        panel.hidden = q ? n === 0 : panel.dataset.dayPanel !== (active && active.dataset.day);
        if (q && n) { if (!panel.querySelector('.hos-day-title')) { var h = document.createElement('h3'); h.className = 'hos-day-title'; h.textContent = 'วัน' + box.querySelector('.hos-days button[data-day="' + panel.dataset.dayPanel + '"] b').textContent; panel.prepend(h); } }
        var tt = panel.querySelector('.hos-day-title'); if (tt) tt.hidden = !q;
        if (!panel.hidden) shown += n;
      });
      box.querySelector('.hos-days').style.opacity = q ? .4 : 1;
    } else {
      box.querySelectorAll('.hos-clinic-group').forEach(function (g) {
        var n = 0;
        g.querySelectorAll('tbody tr').forEach(function (tr) {
          var ok = (group === 'all' || g.dataset.group === group) && (!q || norm(tr.dataset.name).indexOf(q) > -1);
          tr.hidden = !ok; if (ok && !tr.classList.contains('cont')) n++;
          var cn = tr.querySelector('.cn'); if (cn) hl(cn, ok ? q : '');
        });
        g.hidden = !n; shown += n;
      });
    }
    none.hidden = shown > 0;
  }
  input.addEventListener('input', apply);
  box.querySelectorAll('[data-mode]').forEach(function (b) { b.addEventListener('click', function () { mode = b.dataset.mode; box.querySelectorAll('[data-mode]').forEach(function (x) { x.classList.toggle('on', x === b); }); apply(); }); });
  box.querySelectorAll('.hos-gchips button').forEach(function (b) { b.addEventListener('click', function () { group = b.dataset.group; box.querySelectorAll('.hos-gchips button').forEach(function (x) { x.classList.toggle('on', x === b); }); apply(); }); });
  box.querySelectorAll('.hos-days button').forEach(function (b) { b.addEventListener('click', function () { box.querySelectorAll('.hos-days button').forEach(function (x) { x.classList.toggle('on', x === b); }); input.value = ''; apply(); }); });
  var qs = new URLSearchParams(location.search).get('clinic'); if (qs) input.value = qs;
  var vw = new URLSearchParams(location.search).get('view'); if (vw) { var vb = box.querySelector('[data-mode="' + vw + '"]'); if (vb) { mode = vw; box.querySelectorAll('[data-mode]').forEach(function (x) { x.classList.toggle('on', x === vb); }); } }
  apply();
});

/* หมวดย่อยในแท็บข่าว (ประกวดราคา / สรุปผล / ราคากลาง) */
document.querySelectorAll('[data-hos-subtabs]').forEach(function (bar) {
  var panel = bar.parentNode;
  bar.querySelectorAll('button').forEach(function (b) {
    b.addEventListener('click', function () {
      bar.querySelectorAll('button').forEach(function (x) { x.classList.toggle('on', x === b); });
      panel.querySelectorAll('.news-subpanel').forEach(function (p) { p.hidden = p.dataset.subpanel !== b.dataset.sub; });
    });
  });
});

/* ตารางออกตรวจ: มุมมองรายเดือน + เลื่อนเดือน */
function hosMonth(box) {
  var host = box.querySelector('[data-hos-month]'), src = box.querySelector('.hos-cal-data');
  if (!host || !src) return null;
  var data; try { data = JSON.parse(src.textContent); } catch (e) { return null; }
  var TH = ['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
  var DN = ['จ.','อ.','พ.','พฤ.','ศ.','ส.','อา.'];
  var today = data.today, ty = +today.slice(0, 4), tm = +today.slice(5, 7) - 1;
  var y = ty, m = tm, sel = today, lastQ = '', lastG = 'all';
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function ymd(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function iso(d) { return d.getDay() || 7; }
  function occurs(s, d) {
    var ds = ymd(d);
    if (s.valid_from && ds < s.valid_from) return false;
    if (s.valid_until && ds > s.valid_until) return false;
    var wd = iso(d), day = d.getDate();
    switch (s.recurrence || 'weekly') {
      case 'weekly': return wd === +s.weekday;
      case 'monthly_week':
        if (wd !== +s.weekday) return false;
        if (+s.week_of_month === 5) { var n = new Date(d); n.setDate(day + 7); return n.getMonth() !== d.getMonth(); }
        return Math.ceil(day / 7) === +s.week_of_month;
      case 'monthly_day': return day === +s.day_of_month;
      case 'yearly': return day === +s.day_of_month && d.getMonth() + 1 === +s.month_of_year;
      case 'date': return s.on_date === ds;
    }
    return false;
  }
  function t(x) { return String(x || '').slice(0, 5).replace(':', '.'); }
  function itemsOn(d, q, g) {
    var out = [];
    data.items.forEach(function (it) {
      if (g !== 'all' && it.g !== g) return;
      if (q && it.n.toLowerCase().indexOf(q) < 0) return;
      it.s.forEach(function (s) { if (occurs(s, d)) out.push({ n: it.n, g: it.g, gl: it.gl, a: s.start_time, b: s.end_time, note: s.note || '' }); });
    });
    return out.sort(function (a, b) { return a.a < b.a ? -1 : a.a > b.a ? 1 : a.n.localeCompare(b.n, 'th'); });
  }
  function cls(it) { return /SMC/.test(it.gl) ? 'is-smc' : /นอกเวลา/.test(it.gl) ? 'is-ev' : /ทั่วไป/.test(it.gl) ? 'is-gen' : 'is-sp'; }
  function esc(s) { var e = document.createElement('i'); e.textContent = s; return e.innerHTML; }
  function render(q, g) {
    lastQ = q || ''; lastG = g || 'all';
    var first = new Date(y, m, 1), days = new Date(y, m + 1, 0).getDate(), lead = iso(first) - 1, total = 0, h = '';
    h += '<div class="hos-mhead"><button type="button" class="hos-mnav" data-m="-1" aria-label="เดือนก่อนหน้า">‹</button>'
      + '<div class="hos-mtitle"><b>' + TH[m] + ' ' + (y + 543) + '</b>' + ((y !== ty || m !== tm) ? '<button type="button" data-m="0">กลับเดือนนี้</button>' : '<small>เดือนนี้</small>') + '</div>'
      + '<button type="button" class="hos-mnav" data-m="1" aria-label="เดือนถัดไป">›</button></div>';
    h += '<div class="hos-mlegend"><span class="is-gen">ทั่วไป</span><span class="is-sp">เฉพาะทาง</span><span class="is-ev">นอกเวลา</span><span class="is-smc">SMC</span></div>';
    h += '<div class="hos-mgrid">' + DN.map(function (d, i) { return '<div class="hos-mdn' + (i > 4 ? ' we' : '') + '">' + d + '</div>'; }).join('');
    for (var i = 0; i < lead; i++) h += '<div class="hos-mcell empty"></div>';
    var selIn = false;
    for (var dd = 1; dd <= days; dd++) {
      var d = new Date(y, m, dd), ds = ymd(d), list = itemsOn(d, lastQ, lastG), wd = iso(d);
      total += list.length; if (ds === sel) selIn = true;
      h += '<button type="button" class="hos-mcell' + (ds === today ? ' today' : '') + (ds === sel ? ' sel' : '') + (wd > 5 ? ' we' : '') + (list.length ? '' : ' none') + '" data-d="' + ds + '">'
        + '<span class="dn">' + dd + '<em>' + DN[wd - 1] + '</em></span>'
        + (list.length ? '<span class="cnt">' + list.length + ' คลินิก</span>' : '')
        + '<span class="its">' + list.map(function (it) { return '<i class="' + cls(it) + '" title="' + esc(it.n) + ' ' + t(it.a) + '–' + t(it.b) + '"><b>' + t(it.a) + '–' + t(it.b) + '</b>' + esc(it.n) + '</i>'; }).join('') + '</span></button>';
    }
    h += '</div>';
    if (!selIn) sel = (y === ty && m === tm) ? today : ymd(first);
    var sd = new Date(+sel.slice(0, 4), +sel.slice(5, 7) - 1, +sel.slice(8, 10)), sl = itemsOn(sd, lastQ, lastG);
    h += '<div class="hos-mday"><h3>📅 วัน' + ['จันทร์','อังคาร','พุธ','พฤหัสบดี','ศุกร์','เสาร์','อาทิตย์'][iso(sd) - 1] + 'ที่ ' + sd.getDate() + ' ' + TH[sd.getMonth()] + ' ' + (sd.getFullYear() + 543) + ' <small>' + sl.length + ' คลินิก</small></h3>'
      + (sl.length ? '<ul class="hos-rows">' + sl.map(function (it) { return '<li class="' + cls(it) + '"><time>' + t(it.a) + '–' + t(it.b) + '</time><span class="n">' + esc(it.n) + (it.note ? ' <em class="nt">' + esc(it.note) + '</em>' : '') + '</span><span class="g">' + esc(it.gl) + '</span></li>'; }).join('') + '</ul>' : '<div class="hos-empty">ไม่มีคลินิกออกตรวจในวันนี้</div>') + '</div>';
    host.innerHTML = h;
    host.querySelectorAll('.hos-mcell[data-d]').forEach(function (c) { c.classList.toggle('sel', c.dataset.d === sel); });
    return total;
  }
  host.addEventListener('click', function (e) {
    var b = e.target.closest('[data-m],[data-d]'); if (!b) return;
    if (b.dataset.d) { sel = b.dataset.d; render(lastQ, lastG); var md = host.querySelector('.hos-mday'); if (md && window.innerWidth < 900) md.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
    var k = +b.dataset.m;
    if (k === 0) { y = ty; m = tm; sel = today; } else { m += k; if (m < 0) { m = 11; y--; } if (m > 11) { m = 0; y++; } }
    render(lastQ, lastG);
  });
  return { render: render };
}

/* หน้าหน่วยงาน: ไอคอน/จำนวนกลุ่มงาน, พับ-ขยาย, ค้นหา */
(function () {
  var cards = document.querySelectorAll('.hos-sheet .hos-card-g');
  if (cards.length < 2) return;
  var map = [[/อำนวยการ/, '🏛️', 'd1'], [/ปฐมภูมิ/, '🏡', 'd2'], [/พัฒนาระบบ|สนับสนุน/, '💻', 'd3'], [/ทุติยภูมิ|ตติยภูมิ/, '🏥', 'd4'], [/พยาบาล/, '👩‍⚕️', 'd5']];
  var total = 0;
  cards.forEach(function (c, i) {
    var h = c.querySelector('h3'), lis = c.querySelectorAll('li'); if (!h) return;
    var m = map.filter(function (x) { return x[0].test(h.textContent); })[0] || ['', '📁', 'd' + (i % 5 + 1)];
    c.classList.add(m[2]); total += lis.length;
    var label = h.textContent;
    h.textContent = '';
    var ic = document.createElement('span'); ic.className = 'ic'; ic.textContent = m[1];
    var tx = document.createElement('span'); tx.textContent = label;
    var ct = document.createElement('span'); ct.className = 'ct'; ct.textContent = lis.length + ' กลุ่มงาน';
    var tg = document.createElement('span'); tg.className = 'tg'; tg.textContent = '▾';
    h.append(ic, tx, ct, tg); h.setAttribute('role', 'button'); h.tabIndex = 0;
    function tog() { c.classList.toggle('is-closed'); }
    h.addEventListener('click', tog); h.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); tog(); } });
    lis.forEach(function (li) { li.dataset.raw = li.textContent; });
  });
  var first = cards[0].closest('.wp-block-columns') || cards[0];
  var bar = document.createElement('div'); bar.className = 'hos-dept-tools';
  bar.innerHTML = '<label><span aria-hidden="true">🔍</span><input type="search" placeholder="ค้นหาหน่วยงาน เช่น เภสัช, ทันตกรรม, พยาบาล" aria-label="ค้นหาหน่วยงาน"></label><span class="hos-dept-sum"><b>' + cards.length + '</b> ภารกิจ · <b>' + total + '</b> กลุ่มงาน</span>';
  first.parentNode.insertBefore(bar, first);
  var inp = bar.querySelector('input');
  inp.addEventListener('input', function () {
    var q = inp.value.trim().toLowerCase();
    cards.forEach(function (c) {
      var n = 0;
      c.querySelectorAll('li').forEach(function (li) {
        var raw = li.dataset.raw, i = q ? raw.toLowerCase().indexOf(q) : -1, ok = !q || i > -1;
        li.hidden = !ok; if (ok) n++;
        li.textContent = '';
        if (i > -1) { var mk = document.createElement('mark'); mk.textContent = raw.slice(i, i + q.length); li.append(raw.slice(0, i), mk, raw.slice(i + q.length)); } else li.textContent = raw;
      });
      c.hidden = q && !n; if (q && n) c.classList.remove('is-closed');
    });
  });
})();

/* แผนที่: สลับดาวเทียม / ถนน */
document.querySelectorAll('[data-hos-map]').forEach(function (m) {
  m.querySelectorAll('[data-show]').forEach(function (b) {
    b.addEventListener('click', function () {
      m.querySelectorAll('[data-show]').forEach(function (x) { x.classList.toggle('on', x === b); });
      m.querySelectorAll('iframe[data-map]').forEach(function (f) { f.hidden = f.dataset.map !== b.dataset.show; });
    });
  });
});

