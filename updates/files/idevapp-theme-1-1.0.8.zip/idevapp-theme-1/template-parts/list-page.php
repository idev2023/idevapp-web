<?php
/** หน้ารวมของส่วน ?hos_list=key */
defined( 'ABSPATH' ) || exit;
get_header();
get_template_part( 'template-parts/list-body' );
get_footer();
