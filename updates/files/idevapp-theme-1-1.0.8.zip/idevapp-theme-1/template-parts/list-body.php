<?php
/** เนื้อหาหน้ารวมของส่วน (ใช้ทั้ง ?hos_list= และหน้ารวมเดิม) */
defined( 'ABSPATH' ) || exit;
$key     = get_query_var( 'hos_list' );
$sources = hos_sources();
$src     = $sources[ $key ];
$paged   = max( 1, (int) get_query_var( 'paged' ), isset( $_GET['pg'] ) ? (int) $_GET['pg'] : 1 ); // phpcs:ignore
$q       = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore
$query   = new WP_Query( hos_source_args( $key, 20, array( 'paged' => $paged, 's' => $q ) ) );
hos_page_top( $src['label'], $src['kicker'] );
?>
<section class="hos-section"><div class="container">
	<form class="hos-search" action="<?php echo esc_url( home_url( '/' ) ); ?>"><input type="hidden" name="hos_list" value="<?php echo esc_attr( $key ); ?>"><input name="q" value="<?php echo esc_attr( $q ); ?>" placeholder="ค้นหาหัวข้อ..."><button class="hos-btn">ค้นหา</button><span><?php echo (int) $query->found_posts; ?> รายการ</span></form>
	<?php
	$query->posts ? hos_news_cards( $query->posts ) : hos_doc_list( $query->posts, $q ? 'ไม่พบรายการที่ค้นหา' : 'ยังไม่มีรายการ' );
	if ( $query->max_num_pages > 1 ) {
		echo '<nav class="nav-links">';
		echo paginate_links( array( 'base' => add_query_arg( 'pg', '%#%' ), 'format' => '', 'current' => $paged, 'total' => $query->max_num_pages, 'prev_text' => '←', 'next_text' => '→' ) ); // phpcs:ignore
		echo '</nav>';
	}
	?>
</div></section>
