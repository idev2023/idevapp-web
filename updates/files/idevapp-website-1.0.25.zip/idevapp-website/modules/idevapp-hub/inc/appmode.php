<?php
/**
 * Back office in "program mode": looks and works like an app, not like WordPress.
 * - side menu shows only the iDev systems (appointments, registrations, schedule …), WordPress menus hidden
 * - app-style top bar and side menu, branded login screen, no WordPress footer
 * - staff always use program mode; administrators can switch to the normal WordPress back office (top bar)
 * Settings: ศูนย์บริการ → ตั้งค่าเว็บไซต์ → โหมดโปรแกรม. Skipped when an iDevApp package (I-Clinic) brings its own.
 */
defined('ABSPATH') || exit;

if (function_exists('idev_app_site_on')) return;

function ihub_app_site_on() { return ihub_setting('appmode') === 'true'; }
function ihub_app_mode() {
    if (!ihub_app_site_on()) return false;
    if (!is_user_logged_in()) return true;
    return ihub_app_mode_for(wp_get_current_user());
}
/** Program mode for a given person (an administrator may have switched to the WordPress view). */
function ihub_app_mode_for($user) {
    if (!ihub_app_site_on()) return false;
    if (!$user instanceof WP_User || !$user->ID || !user_can($user, 'manage_options')) return true;
    return get_user_meta($user->ID, 'ihub_app_mode', true) !== '0';
}
function ihub_app_name() { return ihub_pick(ihub_setting('site_name'), ihub_setting('site_name_en')) ?: get_bloginfo('name'); }
function ihub_app_logo() {
    $id = (int) get_theme_mod('custom_logo');
    $url = $id ? wp_get_attachment_image_url($id, 'medium') : '';
    return $url ?: (string) get_site_icon_url(128);
}
function ihub_app_t($th, $en) { return ihub_pick($th, $en, get_user_locale() === 'th' || strpos((string) get_user_locale(), 'th') === 0 ? 'th' : 'en'); }

/** Where each person starts. */
function ihub_app_home_url($user = null) {
    $user = $user ?: wp_get_current_user();
    if (!$user || !$user->ID || !ihub_app_mode_for($user)) return admin_url(); // the app home exists only in program mode
    return apply_filters('ihub_app_home_url', admin_url('admin.php?page=ihub-home'), $user);
}
add_filter('login_redirect', function ($to, $requested, $user) {
    if (!ihub_app_site_on() || is_wp_error($user) || !$user instanceof WP_User) return $to;
    $default = !$requested || strpos($requested, 'wp-admin/index.php') !== false || rtrim($requested, '/') === rtrim(admin_url(), '/');
    return $default ? ihub_app_home_url($user) : $to;
}, 20, 3);

/* Old links or bookmarks to the app home while in the WordPress view: go to the dashboard instead of "not allowed". */
add_action('admin_page_access_denied', function () {
    if (($_GET['page'] ?? '') !== 'ihub-home' || !is_user_logged_in() || ihub_app_mode()) return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    wp_safe_redirect(admin_url('index.php'));
    exit;
});

/* WordPress dashboard → the person's start page. */
add_action('admin_init', function () {
    global $pagenow;
    if (!ihub_app_mode() || wp_doing_ajax() || $pagenow !== 'index.php' || !empty($_GET['page'])) return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    wp_safe_redirect(ihub_app_home_url());
    exit;
}, 1);

/** Extra WordPress menus kept for staff in program mode (settings). */
function ihub_app_extra_menus() {
    $keep = ['profile.php', 'ihub-home', 'ihub-access', 'ihub-desk', 'ihub-room', 'ihub-news', 'idw-news', 'hos-slides', 'hos-campus', 'idw-services'];
    // Staff: the website menus follow their role's permissions (ผู้ใช้และสิทธิ์). Administrators: as set in the settings.
    $admin = current_user_can('manage_options');
    $show = function ($setting, $cap) use ($admin) { return $admin ? ihub_setting($setting) === 'true' : current_user_can($cap); };
    if ($show('appmode_posts', 'edit_posts')) $keep[] = 'edit.php';
    if ($show('appmode_pages', 'edit_pages')) $keep[] = 'edit.php?post_type=page';
    if ($show('appmode_media', 'upload_files')) $keep[] = 'upload.php';
    if (ihub_setting('appmode_hub') === 'true') $keep[] = 'idevapp-hub';
    return $keep;
}
/* Only the iDev systems. */
add_action('admin_menu', function () {
    if (!ihub_app_mode()) return;
    global $menu;
    $keep = ihub_app_extra_menus();
    foreach ((array) $menu as $item) {
        $slug = $item[2] ?? '';
        if ($slug === '' || stripos($slug, 'idev') !== false || in_array($slug, $keep, true)) continue;
        remove_menu_page($slug);
    }
}, 9999);
add_action('admin_menu', function () {
    if (!ihub_app_mode()) return;
    global $menu;
    foreach ((array) $menu as $k => $item) {
        if (($item[2] ?? '') === 'idevapp') { $menu[$k][0] = 'iDevApp Website'; }
        if (($item[2] ?? '') === 'profile.php') $menu[$k][0] = ihub_app_t('บัญชีของฉัน', 'My account');
    }
}, 10000);

/* App home: greeting and a tile for each system the person can use. */
add_action('admin_menu', function () {
    if (!ihub_app_mode()) return;
    add_menu_page(ihub_app_t('หน้าหลัก', 'Home'), ihub_app_t('หน้าหลัก', 'Home'), 'read', 'ihub-home', 'ihub_app_home_page', 'dashicons-admin-home', 1);
}, 5);
function ihub_app_menu_url($slug) {
    if (strpos($slug, '.php') !== false) return admin_url($slug);
    return admin_url('admin.php?page=' . $slug);
}
function ihub_app_home_page() {
    global $menu, $submenu;
    $u = wp_get_current_user();
    $h = (int) current_time('G');
    $hello = $h < 12 ? ihub_app_t('สวัสดีตอนเช้า', 'Good morning') : ($h < 17 ? ihub_app_t('สวัสดีตอนบ่าย', 'Good afternoon') : ihub_app_t('สวัสดีตอนเย็น', 'Good evening'));
    echo '<div class="wrap ihub-home"><div class="ihub-home-hero"><div><small>' . esc_html(ihub_format_day(current_time('Y-m-d'), ihub_app_t('th', 'en'), true)) . '</small><h1>' . esc_html($hello . ', ' . $u->display_name) . '</h1><p>' . esc_html(ihub_app_name()) . '</p></div>'
        . '<a class="ihub-home-web" href="' . esc_url(home_url('/')) . '" target="_blank" rel="noopener">' . esc_html(ihub_app_t('ดูหน้าเว็บไซต์', 'View website')) . ' ↗</a></div><div class="ihub-home-grid">';
    foreach ((array) $menu as $item) {
        $slug = $item[2] ?? '';
        if ($slug === '' || $slug === 'ihub-home' || strpos((string) ($item[4] ?? ''), 'wp-menu-separator') !== false || !current_user_can($item[1] ?? 'read')) continue;
        $badge = preg_match('/<span class="(?:awaiting-mod|update-plugins)[^"]*">\s*(?:<span[^>]*>)?(\d+)/', (string) $item[0], $m) ? (int) $m[1] : 0;
        $title = trim(wp_strip_all_tags(preg_replace('/<span class="(?:awaiting-mod|update-plugins).*$/s', '', (string) $item[0])));
        $icon = (string) ($item[6] ?? '');
        $ic = strpos($icon, 'dashicons-') === 0 ? '<span class="dashicons ' . esc_attr($icon) . '"></span>' : (strpos($icon, 'data:image') === 0 ? '<img src="' . esc_attr($icon) . '" alt="">' : '<span class="dashicons dashicons-admin-generic"></span>');
        echo '<div class="ihub-tile"><a class="ihub-tile-main" href="' . esc_url(ihub_app_menu_url($slug)) . '"><span class="ic">' . $ic . '</span><b>' . esc_html($title) . '</b>' . ($badge ? '<em>' . (int) $badge . '</em>' : '') . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $ic built from escaped parts
        $subs = array_slice(array_filter((array) ($submenu[$slug] ?? []), function ($sub) use ($slug) { return ($sub[2] ?? '') !== $slug && current_user_can($sub[1] ?? 'read'); }), 0, 4);
        if ($subs) {
            echo '<ul>';
            foreach ($subs as $sub) {
                $href = strpos($sub[2], '.php') !== false ? admin_url($sub[2]) : (strpos($slug, '.php') !== false ? add_query_arg('page', $sub[2], admin_url($slug)) : admin_url('admin.php?page=' . $sub[2]));
                echo '<li><a href="' . esc_url($href) . '">' . esc_html(trim(wp_strip_all_tags((string) $sub[0]))) . '</a></li>';
            }
            echo '</ul>';
        }
        echo '</div>';
    }
    echo '</div></div>';
}

/* Top bar: site name, the person, a switch for administrators. */
add_action('admin_bar_menu', function ($bar) {
    if (!ihub_app_mode()) {
        if (ihub_app_site_on() && current_user_can('manage_options') && is_admin()) $bar->add_node(['id' => 'ihub-app-switch', 'parent' => 'top-secondary', 'title' => '▣ ' . ihub_app_t('กลับไปโหมดโปรแกรม', 'Program mode'), 'href' => wp_nonce_url(admin_url('admin-post.php?action=ihub_app_switch&to=1'), 'ihub_app_switch'), 'meta' => ['class' => 'ihub-app-switch-on']]);
        return;
    }
    foreach (['wp-logo', 'comments', 'new-content', 'updates', 'customize', 'search', 'edit', 'site-editor', 'command-palette'] as $n) $bar->remove_node($n);
    $site = $bar->get_node('site-name');
    if ($site) { $site->title = esc_html(ihub_app_name()); $site->href = ihub_app_home_url(); $bar->add_node((array) $site); }
    $bar->add_node(['id' => 'ihub-app-web', 'title' => ihub_app_t('ดูหน้าเว็บ', 'View website') . ' ↗', 'href' => home_url('/'), 'meta' => ['target' => '_blank']]);
    if (current_user_can('manage_options')) $bar->add_node(['id' => 'ihub-app-switch', 'parent' => 'top-secondary', 'title' => ihub_app_t('หน้า WordPress', 'WordPress view'), 'href' => wp_nonce_url(admin_url('admin-post.php?action=ihub_app_switch&to=0'), 'ihub_app_switch')]);
}, 999);
add_action('admin_post_ihub_app_switch', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('ihub_app_switch')) wp_die('Forbidden', 403);
    $on = ($_GET['to'] ?? '1') === '1';
    update_user_meta(get_current_user_id(), 'ihub_app_mode', $on ? '1' : '0');
    wp_safe_redirect($on ? ihub_app_home_url() : admin_url('index.php'));
    exit;
});
/* Staff never see the WordPress bar on the public pages. */
add_filter('show_admin_bar', function ($show) { return ihub_app_site_on() && !current_user_can('manage_options') ? false : $show; }, 20);

add_filter('admin_title', function ($title, $plain) { return ihub_app_mode() ? $plain . ' · ' . ihub_app_name() : $title; }, 10, 2);
add_filter('admin_footer_text', function ($t) { return ihub_app_mode() ? '' : $t; }, 99);
add_filter('update_footer', function ($t) { return ihub_app_mode() ? '' : $t; }, 99);
add_filter('admin_body_class', function ($c) { return ihub_app_mode() ? $c . ' idev-appmode' : $c; });

add_action('admin_enqueue_scripts', function () {
    if (ihub_app_mode() || ihub_app_site_on()) wp_enqueue_style('ihub-appmode', IHUB_URL . 'assets/appmode.css', [], IHUB_VERSION);
});
/* Brand block and signed-in person in the side menu. */
add_action('adminmenu', function () {
    if (!ihub_app_mode()) return;
    $u = wp_get_current_user();
    $logo = ihub_app_logo();
    $names = wp_roles()->get_names();
    $role = current_user_can('manage_options') ? ihub_app_t('ผู้ดูแลระบบ', 'Administrator') : implode(', ', array_map(function ($r) use ($names) { return translate_user_role($names[$r] ?? $r); }, (array) $u->roles));
    echo '<li class="idev-app-brand"><a href="' . esc_url(ihub_app_home_url()) . '">' . ($logo ? '<img src="' . esc_url($logo) . '" alt="">' : '<span class="mk">' . esc_html(mb_substr(ihub_app_name(), 0, 1)) . '</span>') . '<span class="nm"><b>' . esc_html(ihub_app_name()) . '</b><small>' . esc_html(ihub_app_t('ระบบหลังบ้าน', 'Back office')) . '</small></span></a></li>';
    echo '<li class="idev-app-user"><span class="av">' . esc_html(mb_substr($u->display_name, 0, 1)) . '</span><span><b>' . esc_html($u->display_name) . '</b><small>' . esc_html($role) . '</small></span><a href="' . esc_url(wp_logout_url(wp_login_url())) . '" title="' . esc_attr(ihub_app_t('ออกจากระบบ', 'Log out')) . '">⏻</a></li>';
});
add_action('admin_footer', function () {
    if (ihub_app_mode()) echo '<script>(function(){var m=document.getElementById("adminmenu"),b=m&&m.querySelector(".idev-app-brand");if(b&&m.firstChild!==b)m.insertBefore(b,m.firstChild)})();</script>';
});

/* ---------- Login screen ---------- */

add_action('login_enqueue_scripts', function () {
    if (ihub_app_site_on()) wp_enqueue_style('ihub-applogin', IHUB_URL . 'assets/appmode.css', [], IHUB_VERSION);
});
add_filter('login_headerurl', function ($u) { return ihub_app_site_on() ? home_url('/') : $u; });
add_filter('login_headertext', function ($t) { return ihub_app_site_on() ? ihub_app_t('เข้าสู่ระบบ', 'Sign in') : $t; });
add_filter('login_body_class', function ($c) { if (ihub_app_site_on()) $c[] = 'idev-applogin'; return $c; });
add_action('login_header', function () {
    if (!ihub_app_site_on()) return;
    $logo = ihub_app_logo();
    $feats = [];
    if (function_exists('idev_appt_settings')) $feats[] = ihub_app_t('นัดหมายออนไลน์ และหน้าสำหรับแพทย์', 'Online appointments and the doctor portal');
    if (function_exists('idev_medreg_settings') || function_exists('ihub_reg_setting')) $feats[] = ihub_app_t('ลงทะเบียนผู้ป่วยใหม่ออนไลน์', 'Online new-patient registration');
    if (post_type_exists('idev_provider') || post_type_exists('ihub_provider')) $feats[] = ihub_app_t('ตารางออกตรวจแพทย์', 'Doctors\' clinic schedule');
    $feats[] = ihub_app_t('ประกาศ ข่าวสาร และหน้าเว็บไซต์', 'Announcements, news and website pages');
    echo '<aside class="idev-login-side"><div class="in">' . ($logo ? '<img class="lg" src="' . esc_url($logo) . '" alt="">' : '') . '<span class="pr">' . esc_html(ihub_app_t('ระบบหลังบ้าน', 'Back office')) . '</span><h1>' . esc_html(ihub_app_name()) . '</h1><p>' . esc_html(ihub_app_t('สำหรับแพทย์และเจ้าหน้าที่ เข้าสู่ระบบด้วยบัญชีที่ได้รับจากผู้ดูแลระบบ', 'For doctors and staff. Sign in with the account given by the administrator.')) . '</p><ul>';
    foreach ($feats as $f) echo '<li>' . esc_html($f) . '</li>';
    echo '</ul></div></aside>';
});
add_action('login_footer', function () {
    if (!ihub_app_site_on()) return;
    echo '<script>document.querySelectorAll("#backtoblog a").forEach(function(a){a.textContent="← ' . esc_js(ihub_app_t('กลับไปหน้าเว็บไซต์', 'Back to the website')) . '"});</script>';
});
