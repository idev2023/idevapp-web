/* ใช้ตำแหน่ง (GPS) ไม่ได้ → บอกสาเหตุจริงและวิธีแก้ตามเครื่อง / เบราว์เซอร์ที่ใช้อยู่
 * สาเหตุที่ตรวจได้: ไม่ใช่ https · เว็บส่ง Permissions-Policy ปิดตำแหน่ง · เปิดในแอป LINE / Facebook ·
 * เบราว์เซอร์จำว่า “บล็อก” เว็บนี้ไว้ (ไม่ถามอีก) · แอปเบราว์เซอร์ไม่มีสิทธิ์ตำแหน่งของโทรศัพท์ · GPS ปิด · สัญญาณอ่อน */
(function () {
  var ua = navigator.userAgent,
    ios = /iPhone|iPad|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1),
    android = /Android/i.test(ua), samsung = /SamsungBrowser/i.test(ua), crios = /CriOS/.test(ua), fxios = /FxiOS/.test(ua),
    firefox = /Firefox/.test(ua), edge = /Edg/.test(ua), inapp = /\bLine\/|FBAN|FBAV|FB_IAB|Instagram|MicroMessenger|; wv\)/i.test(ua),
    mac = /Macintosh/.test(ua) && !ios, win = /Windows/.test(ua);
  function policyBlocked() {
    try { var p = document.permissionsPolicy || document.featurePolicy; if (p && p.allowsFeature) return !p.allowsFeature('geolocation'); } catch (e) {}
    return false;
  }
  function state() {
    if (!navigator.permissions || !navigator.permissions.query) return Promise.resolve('unknown');
    return navigator.permissions.query({ name: 'geolocation' }).then(function (r) { return r.state; }).catch(function () { return 'unknown'; });
  }
  function browserName() { return inapp ? 'แอป (LINE / Facebook)' : samsung ? 'Samsung Internet' : edge ? 'Edge' : (crios || (/Chrome/.test(ua) && !edge)) ? 'Chrome' : (fxios || firefox) ? 'Firefox' : ios || mac ? 'Safari' : 'เบราว์เซอร์'; }
  /* steps when the browser / phone says “not allowed” */
  function deniedSteps() {
    if (ios) {
      var app = crios ? 'Chrome' : fxios ? 'Firefox' : 'Safari';
      return [
        'เปิดแอป <b>การตั้งค่า</b> ของ iPhone / iPad → <b>ความเป็นส่วนตัวและความปลอดภัย</b> → <b>บริการหาตำแหน่ง</b> → เปิดสวิตช์ด้านบน',
        app === 'Safari' ? 'ในหน้าเดียวกัน เลื่อนลงไปที่ <b>เว็บไซต์ Safari</b> → เลือก <b>ขณะใช้แอป</b> และเปิด <b>ตำแหน่งที่แม่นยำ</b>' : 'ในหน้าเดียวกัน เลื่อนหา <b>' + app + '</b> → เลือก <b>ขณะใช้แอป</b> และเปิด <b>ตำแหน่งที่แม่นยำ</b>',
        app === 'Safari' ? 'กลับมาที่ Safari แตะ <b>aA</b> (หรือ ⋯) ทางซ้ายของที่อยู่เว็บ → <b>การตั้งค่าเว็บไซต์</b> → <b>ตำแหน่ง</b> → <b>อนุญาต</b> (หรือ ถาม)' : 'กลับมาที่ ' + app + ' แล้วโหลดหน้านี้ใหม่',
        'โหลดหน้านี้ใหม่ แล้วกดใช้ GPS อีกครั้ง — ถ้าถามให้กด <b>อนุญาต</b>'];
    }
    if (android && samsung) return [
      'แตะ <b>≡</b> (เมนูด้านล่าง) → <b>การตั้งค่า</b> → <b>ไซต์และการดาวน์โหลด</b> → <b>สิทธิ์ของไซต์</b> → <b>ตำแหน่ง</b> → แตะเว็บนี้แล้วเลือก <b>อนุญาต</b> (หรือลบออก)',
      'ตรวจสิทธิ์ของแอป: <b>การตั้งค่า</b> ของโทรศัพท์ → <b>แอป</b> → <b>Samsung Internet</b> → <b>สิทธิ์</b> → <b>ตำแหน่ง</b> → <b>อนุญาตเฉพาะขณะใช้แอป</b> และเปิด <b>ใช้ตำแหน่งที่แม่นยำ</b>',
      'ปัดจากขอบบนของจอลง แล้วเปิด <b>ตำแหน่ง</b> (Location)',
      'โหลดหน้านี้ใหม่ แล้วกดใช้ GPS อีกครั้ง'];
    if (android) return [
      'แตะไอคอน <b>⚙ (ปรับแต่ง)</b> ทางซ้ายของที่อยู่เว็บ (Chrome รุ่นใหม่ไม่มีรูปแม่กุญแจแล้ว) → <b>สิทธิ์</b> หรือ <b>การตั้งค่าเว็บไซต์</b> → <b>ตำแหน่ง</b> → <b>อนุญาต</b>',
      'ถ้าไม่เห็นตัวเลือก: แตะ <b>⋮</b> มุมขวาบน → <b>การตั้งค่า</b> → <b>การตั้งค่าเว็บไซต์</b> → <b>ตำแหน่ง</b> → เปิด <b>ถามก่อนเข้าถึง</b> และแตะเว็บนี้ในรายการ <b>ถูกบล็อก</b> → <b>อนุญาต</b>',
      'ตรวจสิทธิ์ของแอป: <b>การตั้งค่า</b> ของโทรศัพท์ → <b>แอป</b> → <b>' + browserName() + '</b> → <b>สิทธิ์</b> → <b>ตำแหน่ง</b> → <b>อนุญาตเฉพาะขณะใช้แอป</b> และเปิด <b>ใช้ตำแหน่งที่แม่นยำ</b>',
      'ปัดจากขอบบนของจอลง แล้วเปิด <b>ตำแหน่ง</b> (Location / GPS)',
      'โหลดหน้านี้ใหม่ แล้วกดใช้ GPS อีกครั้ง'];
    var s = ['คลิกไอคอนทางซ้ายของที่อยู่เว็บ (⚙ หรือแม่กุญแจ) → <b>การตั้งค่าเว็บไซต์</b> / <b>สิทธิ์</b> → <b>ตำแหน่ง</b> → <b>อนุญาต</b>'];
    if (win) s.push('Windows: <b>การตั้งค่า</b> → <b>ความเป็นส่วนตัวและความปลอดภัย</b> → <b>ตำแหน่ง</b> → เปิด <b>บริการตำแหน่ง</b> และ <b>ให้แอปเข้าถึงตำแหน่ง</b>');
    if (mac) s.push('Mac: <b>System Settings</b> → <b>Privacy &amp; Security</b> → <b>Location Services</b> → เปิดให้ ' + browserName());
    s.push('โหลดหน้านี้ใหม่ — คอมพิวเตอร์มักไม่มี GPS ตำแหน่งจึงคลาดเคลื่อนมาก แนะนำใช้โทรศัพท์');
    return s;
  }
  function offSteps() {
    if (ios) return ['เปิด <b>การตั้งค่า</b> → <b>ความเป็นส่วนตัวและความปลอดภัย</b> → <b>บริการหาตำแหน่ง</b> → เปิด', 'ออกไปที่โล่ง ห่างจากหลังคา แล้วลองใหม่'];
    if (android) return ['ปัดจากขอบบนของจอลง แล้วเปิด <b>ตำแหน่ง</b> (Location / GPS)', 'ใน <b>การตั้งค่า</b> → <b>ตำแหน่ง</b> → เปิด <b>ความแม่นยำของตำแหน่ง Google</b> (ช่วยให้หาตำแหน่งได้เร็วขึ้น)', 'ออกไปที่โล่ง แล้วลองใหม่'];
    return ['เครื่องนี้หาตำแหน่งไม่ได้ (คอมพิวเตอร์มักไม่มี GPS) — แนะนำใช้โทรศัพท์'];
  }
  /** code: 0 = before asking, 1 = denied, 2 = unavailable, 3 = timeout → Promise<{title, steps, note, fixable}> */
  function explain(code) {
    if (!window.isSecureContext) return Promise.resolve({ title: 'เว็บต้องเปิดด้วย https:// จึงจะใช้ตำแหน่งได้', steps: ['เปิดหน้านี้ด้วยที่อยู่ที่ขึ้นต้นด้วย <b>https://</b>'], note: 'ผู้ดูแลเว็บ: เปิดใช้ HTTPS ที่ iDevApp Website → SSL / HTTPS', fixable: false });
    if (!navigator.geolocation) return Promise.resolve({ title: 'เบราว์เซอร์นี้ไม่รองรับการหาตำแหน่ง', steps: ['เปิดหน้านี้ด้วย Chrome หรือ Safari รุ่นล่าสุด'], fixable: false });
    if (policyBlocked()) {
      var tried = false; try { tried = !!sessionStorage.getItem('hosGeoFixed'); } catch (e) {}
      if (window.HosGeoFix && !tried) return Promise.resolve({ title: 'เว็บไซต์ปิดการใช้ตำแหน่งไว้ (ไม่ใช่ที่โทรศัพท์)', steps: ['ส่วนหัว <code>Permissions-Policy</code> จากเซิร์ฟเวอร์หรือปลั๊กอินอื่นสั่งปิดตำแหน่ง', 'คุณเป็นผู้ดูแลเว็บ กดปุ่มด้านล่างให้ระบบแก้ให้ — ระบบตรวจว่าเว็บยังเปิดได้หลังแก้ ถ้าเว็บพังจะย้อนกลับให้เอง'], fix: true, fixable: true });
      if (tried) { try { sessionStorage.removeItem('hosGeoFixed'); } catch (e) {} }
      return Promise.resolve({ title: tried ? 'แก้ที่ .htaccess แล้วแต่ยังถูกปิดอยู่ — ตั้งไว้ที่เซิร์ฟเวอร์' : 'เว็บไซต์ปิดการใช้ตำแหน่งไว้ (ไม่ใช่ที่โทรศัพท์)', steps: (tried ? ['ส่วนหัวนี้มาจาก Nginx / แผงควบคุมโฮสติ้ง (เช่น DirectAdmin, Plesk) หรือ Cloudflare ซึ่งปลั๊กอินแก้ไม่ได้ — ส่งข้อความด้านล่างให้ผู้ดูแลเซิร์ฟเวอร์'] : []).concat(['ผู้ใช้แก้เองไม่ได้ — ผู้ดูแลเว็บต้องแก้ส่วนหัว <code>Permissions-Policy</code> ที่ส่งมาจากเซิร์ฟเวอร์ ปลั๊กอินอื่น หรือ Cloudflare ให้เป็น <code>geolocation=(self)</code>', 'Apache / LiteSpeed (.htaccess): <code>Header always set Permissions-Policy "geolocation=(self), camera=(self), microphone=()"</code>', 'Nginx: <code>add_header Permissions-Policy "geolocation=(self), camera=(self), microphone=()" always;</code>']), note: 'Cloudflare: Rules → Transform Rules → Modify Response Header → ตั้ง Permissions-Policy เป็น geolocation=(self)', fixable: false });
    }
    if (inapp) return Promise.resolve({ title: 'เปิดในแอป LINE / Facebook ใช้ตำแหน่งไม่ได้', steps: ['แตะ <b>⋮</b> หรือ <b>⋯</b> มุมขวา → <b>เปิดในเบราว์เซอร์</b> (Chrome / Safari)', 'แล้วกดใช้ GPS อีกครั้ง'], fixable: true });
    return state().then(function (st) {
      if (code === 1 || st === 'denied') return { title: '⛔ ' + browserName() + ' ยังไม่อนุญาตให้เว็บนี้ใช้ตำแหน่ง', steps: deniedSteps(), note: st === 'denied' ? 'เบราว์เซอร์จำว่าเคย “บล็อก” เว็บนี้ไว้ จึงไม่ถามอีก ต้องเปลี่ยนในการตั้งค่าตามขั้นตอนนี้' : 'ถ้าเปลี่ยนแล้วยังไม่ได้ ให้ตรวจสิทธิ์ตำแหน่งของแอปเบราว์เซอร์ในการตั้งค่าโทรศัพท์', fixable: true };
      if (code === 3) return { title: '⏳ หาตำแหน่งนานเกินไป', steps: ['ออกไปที่โล่ง ห่างจากหลังคาและอาคารสูง', 'รอ 10–20 วินาที แล้วลองอีกครั้ง'].concat(android ? ['เปิด <b>ความแม่นยำของตำแหน่ง Google</b> ใน การตั้งค่า → ตำแหน่ง'] : []), fixable: true };
      return { title: '📡 หาตำแหน่งไม่ได้ — GPS อาจปิดอยู่', steps: offSteps(), fixable: true };
    });
  }
  function html(r) {
    return '<div class="hos-geo-help"><b class="t">' + r.title + '</b><ol>' + r.steps.map(function (s) { return '<li>' + s + '</li>'; }).join('') + '</ol>' + (r.note ? '<small>' + r.note + '</small>' : '')
      + (r.fix ? '<p class="fx"><button type="button" class="hos-geo-fixbtn" data-geo-fix>🔧 แก้ไขให้อัตโนมัติ</button> <span class="fxmsg"></span></p>' : '') + '</div>';
  }
  if (!document.getElementById('hos-geo-help-css')) {
    var st = document.createElement('style'); st.id = 'hos-geo-help-css';
    st.textContent = '.hos-geo-help{font-size:14px;line-height:1.55;text-align:left;color:#1d2327}.hos-geo-help .t{display:block;font-size:15px;margin-bottom:6px;color:#8a1f17}.hos-geo-help ol{margin:0 0 6px;padding-left:20px}.hos-geo-help li{margin:4px 0}.hos-geo-help small{display:block;color:#50575e}.hos-geo-help code{font-size:12px;word-break:break-all;background:#f0f0f1;padding:1px 4px;border-radius:3px}.hos-geo-help .fx{margin:10px 0 0}.hos-geo-fixbtn{font:inherit;font-weight:700;background:#0a7d55;color:#fff;border:0;border-radius:10px;padding:10px 16px;cursor:pointer;min-height:42px}.hos-geo-fixbtn:disabled{opacity:.6}.hos-geo-help .fxmsg{font-size:13px}';
    (document.head || document.documentElement).appendChild(st);
  }
  /* the admin's one-click fix (security module: writes the override at the end of .htaccess, checks the site, undoes it if the site breaks) */
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-geo-fix]'); if (!b || !window.HosGeoFix) return;
    e.preventDefault(); e.stopPropagation();
    var m = b.parentNode.querySelector('.fxmsg'); b.disabled = true; m.textContent = '⏳ กำลังแก้ไขและตรวจว่าเว็บยังเปิดได้…';
    var fd = new FormData(); fd.append('action', 'idw_sec_fix'); fd.append('fix', 'geo_policy'); fd.append('_wpnonce', window.HosGeoFix.nonce);
    fetch(window.HosGeoFix.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j.success) { b.disabled = false; m.textContent = '❌ ' + ((j.data && j.data.msg) || 'แก้ไขไม่สำเร็จ'); return; }
      m.textContent = '✅ แก้แล้ว — กำลังโหลดหน้าใหม่…';
      try { sessionStorage.setItem('hosGeoFixed', '1'); } catch (x) {}
      setTimeout(function () { location.reload(); }, 900);
    }).catch(function () { b.disabled = false; m.textContent = '❌ เชื่อมต่อไม่ได้ ลองอีกครั้ง'; });
  }, true);
  window.HosGeo = { explain: explain, html: function (code) { return explain(code).then(html); }, policyBlocked: policyBlocked, state: state };
})();
