<?php
/**
 * มาตรฐานเพิ่มเติม (แท็บแยก แบบเดียวกับ สกมช.):
 * - OWASP ASVS 5.0.0 — เลือกระดับเป้าหมาย L1 / L2 / L3 · ข้อที่ปลั๊กอินพิสูจน์ได้ตรวจอัตโนมัติ (พร้อมปุ่มแก้) · ที่เหลือผู้รับผิดชอบประเมินเอง (ผ่าน / ไม่ผ่าน / ไม่เกี่ยวข้อง)
 * - CTAM+ สำนักงานปลัดกระทรวงสาธารณสุข ปีงบประมาณ 2569 (17 ข้อ) — ระบบแสดงหลักฐานจากเว็บไซต์ ผู้รับผิดชอบยืนยันผลระดับหน่วยงาน
 * ผลทั้งสองชุดอยู่ในรายงาน “ก่อน / หลัง” ด้วย
 */
defined('ABSPATH') || exit;
require_once __DIR__ . '/asvs-data.php';

function idw_sec_fw_manual($fw) {
    $m = get_option('idw_sec_fw_' . $fw, []);
    return wp_parse_args(is_array($m) ? $m : [], ['level' => '2', 'items' => []]);
}

/** What the site shows from the outside (cached 6 h; “ตรวจใหม่” refreshes). */
function idw_sec_fw_auto($fresh = false) {
    $c = get_transient('idw_sec_fw_auto');
    if (!$fresh && is_array($c)) return $c;
    require_once __DIR__ . '/scan.php';
    $host = (string) wp_parse_url(home_url(), PHP_URL_HOST);
    $https = 0 === strpos(home_url(), 'https://');
    $home = idw_sec_probe(add_query_arg('idw_v', wp_rand(1000, 9999), home_url('/')));
    $hd = $home ? array_change_key_case((array) (is_object($home['headers']) ? $home['headers']->getAll() : $home['headers'])) : [];
    $h = function ($k) use ($hd) { $v = $hd[$k] ?? ''; return is_array($v) ? implode(', ', $v) : (string) $v; };
    $http = idw_sec_probe('http://' . $host . '/');
    $git = idw_sec_probe(home_url('/.git/HEAD'));
    $up = wp_get_upload_dir();
    $list = idw_sec_probe(trailingslashit($up['baseurl']));
    $trace = idw_sec_probe(home_url('/'), 'TRACE');
    $readme = idw_sec_probe(site_url('readme.html'));
    $cert = null;
    if ($https) { $r = wp_remote_head(home_url('/'), ['timeout' => 8, 'sslverify' => true, 'redirection' => 0]); $cert = !is_wp_error($r); }
    $waf = [];
    if ($h('cf-ray') || stripos($h('server'), 'cloudflare') !== false) $waf[] = 'Cloudflare';
    if ($h('x-sucuri-id')) $waf[] = 'Sucuri';
    if ($h('x-iinfo') || $h('x-cdn') === 'Incapsula') $waf[] = 'Imperva';
    if (stripos($h('server'), 'AkamaiGHost') !== false || $h('x-akamai-transformed')) $waf[] = 'Akamai';
    if (stripos($h('server'), 'BigIP') !== false || $h('x-wa-info')) $waf[] = 'F5';
    if ($h('x-fw-hash') || stripos($h('server'), 'FortiWeb') !== false) $waf[] = 'FortiWeb';
    $c = ['t' => time(), 'https' => $https, 'redirect' => $http ? (in_array($http['code'], [301, 302, 307, 308], true) && 0 === stripos($h2 = (string) (is_array($http['headers']['location'] ?? '') ? ($http['headers']['location'][0] ?? '') : ($http['headers']['location'] ?? '')), 'https://')) : null,
        'tls' => $https && function_exists('idw_sec_ncsa_tls') ? idw_sec_ncsa_tls($host) : null, 'home' => (bool) $home,
        'hsts' => $h('strict-transport-security'), 'csp' => $h('content-security-policy'), 'xcto' => $h('x-content-type-options'), 'ref' => $h('referrer-policy'), 'xfo' => $h('x-frame-options'), 'acao' => $h('access-control-allow-origin'), 'acac' => $h('access-control-allow-credentials'), 'server' => $h('server'),
        'git' => $git ? (200 === $git['code'] && false !== strpos($git['body'], 'ref:')) : null, 'listing' => $list ? (200 === $list['code'] && false !== stripos($list['body'], 'Index of')) : null,
        'trace' => $trace ? (200 === $trace['code']) : null, 'readme' => $readme ? (200 === $readme['code']) : null, 'cert' => $cert, 'waf' => $waf];
    set_transient('idw_sec_fw_auto', $c, 6 * HOUR_IN_SECONDS);
    return $c;
}

/** Facts from inside WordPress (cheap; not cached). */
function idw_sec_fw_ctx() {
    global $wp_version;
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    $admins = get_users(['role' => 'administrator']);
    $no2 = function_exists('idw_2fa_enabled') ? array_values(array_filter($admins, function ($u) { return !idw_2fa_enabled($u->ID); })) : $admins;
    $named = array_values(array_filter(get_users(['fields' => ['user_login']]), function ($u) { return in_array(strtolower($u->user_login), ['admin', 'administrator', 'root', 'test', 'webmaster', 'sa'], true); }));
    $upd = 0;
    if (function_exists('get_plugin_updates') || (require_once ABSPATH . 'wp-admin/includes/update.php')) { $upd = count((array) get_plugin_updates()) + count((array) get_theme_updates()); $core = get_core_updates(); if (is_array($core) && isset($core[0]->response) && 'upgrade' === $core[0]->response) $upd++; }
    $rep = get_option('idw_sec_report');
    $cves = is_array($rep) ? array_values(array_filter((array) $rep['items'], function ($i) { return !empty($i['cve']) && in_array($i['sev'], ['critical', 'high'], true) && empty($i['fixed']); })) : [];
    $up = wp_get_upload_dir();
    $uph = trailingslashit($up['basedir']) . '.htaccess';
    $plugins = get_plugins(); $active = (array) get_option('active_plugins', []);
    $inactive = array_values(array_map(function ($f) use ($plugins) { return $plugins[$f]['Name']; }, array_diff(array_keys($plugins), $active)));
    $themes = array_diff(array_keys(wp_get_themes()), [get_stylesheet(), get_template()]);
    $stale = get_users(['fields' => ['user_login'], 'meta_query' => [['key' => '_idw_last_login', 'value' => time() - 45 * DAY_IN_SECONDS, 'compare' => '<', 'type' => 'NUMERIC']]]); // phpcs:ignore
    $backup = array_values(array_map('dirname', array_filter(['updraftplus/updraftplus.php', 'backwpup/backwpup.php', 'all-in-one-wp-migration/all-in-one-wp-migration.php', 'duplicator/duplicator.php', 'blogvault-real-time-backup/blogvault.php', 'jetpack/jetpack.php', 'wpvivid-backuprestore/wpvivid-backuprestore.php'], 'is_plugin_active')));
    $wafp = array_values(array_map('dirname', array_filter(['wordfence/wordfence.php', 'ninjafirewall/ninjafirewall.php', 'sucuri-scanner/sucuri.php', 'all-in-one-wp-security-and-firewall/wp-security.php', 'bbq-firewall/block-bad-queries.php', 'shield-security/icwp-wpsf.php', 'malcare-security/malcare.php'], 'is_plugin_active')));
    $priv = (int) get_option('wp_page_for_privacy_policy');
    $cookie = (function_exists('ihub_setting') && 'true' === ihub_setting('cookie_banner')) || (function_exists('ihub_uses') && ihub_uses('cookie'));
    $php = function_exists('idw_sec_php_cve_check') ? idw_sec_php_cve_check() : ['bad' => 0, 'items' => []];
    $phpeol = ['7.4' => '2022-11-28', '8.0' => '2023-11-26', '8.1' => '2025-12-31', '8.2' => '2026-12-31', '8.3' => '2027-12-31', '8.4' => '2028-12-31'];
    $mm = PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION; $end = $phpeol[$mm] ?? (version_compare($mm, '7.4', '<') ? '2000-01-01' : '');
    return ['wp' => $wp_version, 'admins' => $admins, 'no2' => $no2, 'named' => $named, 'upd' => $upd, 'cves' => $cves, 'scan_t' => is_array($rep) ? (int) $rep['time'] : 0,
        'uploads_locked' => is_file($uph) && false !== strpos((string) file_get_contents($uph), 'Require all denied'), // phpcs:ignore
        'debug_display' => (defined('WP_DEBUG') && WP_DEBUG && (!defined('WP_DEBUG_DISPLAY') || WP_DEBUG_DISPLAY)) || in_array(strtolower((string) ini_get('display_errors')), ['1', 'on', 'stdout'], true),
        'inactive' => $inactive, 'themes' => $themes, 'stale' => wp_list_pluck($stale, 'user_login'), 'backup' => $backup, 'wafp' => $wafp,
        'privacy' => $priv && 'publish' === get_post_status($priv), 'cookie' => $cookie, 'php_bad' => (int) $php['bad'], 'php_items' => array_values(array_filter($php['items'], function ($i) { return 'ok' !== $i['sev']; })), 'php_eol' => $end && strtotime($end) < time()];
}

/* ===================================================== OWASP ASVS 5.0 ===================================================== */

/** id => [status ok|warn|bad|manual, detail, fix key, how, link] for the requirements the plugin can prove. */
function idw_sec_asvs_auto($a, $c) {
    $on = 'idw_sec_on';
    $hd = function ($key, $okText) use ($a) { return '' !== $a[$key] ? ['ok', $okText . ': ' . $a[$key], '', '', null] : ['bad', 'ไม่พบส่วนหัวนี้', 'headers', 'เปิด “ส่วนหัวความปลอดภัย”', null]; };
    $pf = function ($t) { return ['ok', 'WordPress ทำให้อยู่แล้ว: ' . $t, '', '', null]; };
    $setting = function ($k, $okText, $how) use ($on) { return $on($k) ? ['ok', $okText, '', '', null] : ['bad', 'ยังไม่เปิด', $k, $how, null]; };
    $tls = $a['tls'];
    $maxage = preg_match('/max-age=(\d+)/i', $a['hsts'], $m) ? (int) $m[1] : 0;
    $ssl = ['ไปหน้า SSL / HTTPS', admin_url('admin.php?page=idw-ssl')];
    $r = [
        'V1.3.1' => $setting('unfiltered_html', 'ผู้ที่ไม่ใช่ผู้ดูแลใส่สคริปต์ไม่ได้ · WordPress กรอง HTML ด้วย KSES', 'เปิด “ห้ามคนที่ไม่ใช่ผู้ดูแลใส่สคริปต์”'),
        'V1.3.4' => $setting('risky_uploads', 'ไม่รับไฟล์ SVG / HTML ที่ฝังสคริปต์ได้', 'เปิด “ปิดการอัปโหลดไฟล์ที่ฝังสคริปต์ได้”'),
        'V2.4.1' => $on('login_limit') && $on('login_captcha') ? ['ok', 'จำกัดการล็อกอินผิด + CAPTCHA', '', '', null] : ['warn', 'ยังเปิดไม่ครบ (จำกัดการล็อกอินผิด / CAPTCHA)', $on('login_limit') ? 'login_captcha' : 'login_limit', 'เปิดทั้ง “จำกัดการล็อกอินผิด” และ “CAPTCHA”', null],
        'V3.3.1' => $a['https'] ? ['warn', 'คุกกี้เข้าสู่ระบบมี Secure เมื่อใช้ HTTPS แต่ชื่อคุกกี้ของ WordPress ไม่มี __Secure- / __Host- (ข้อจำกัดของ WordPress — บันทึกเป็นข้อยกเว้นพร้อมเหตุผล)', '', '', null] : ['bad', 'เว็บยังไม่ใช้ HTTPS', '', 'เปลี่ยนเว็บเป็น HTTPS', $ssl],
        'V3.3.2' => ['warn', 'WordPress ไม่ได้ตั้ง SameSite ให้คุกกี้เข้าสู่ระบบ — เบราว์เซอร์ใช้ค่าเริ่มต้น Lax · มี nonce กัน CSRF ทุกฟอร์มหลังบ้าน', '', 'บันทึกเป็นข้อยกเว้น หรือให้ผู้ดูแลเซิร์ฟเวอร์เติม SameSite=Lax ที่เว็บเซิร์ฟเวอร์', null],
        'V3.3.3' => ['warn', 'ชื่อคุกกี้ของ WordPress ไม่มี __Host- (ข้อจำกัดของแพลตฟอร์ม)', '', 'บันทึกเป็นข้อยกเว้นพร้อมเหตุผล', null],
        'V3.3.4' => $pf('คุกกี้เข้าสู่ระบบตั้ง HttpOnly'),
        'V3.4.1' => '' === $a['hsts'] ? ['bad', 'ไม่พบ Strict-Transport-Security', 'headers', 'เปิด “ส่วนหัวความปลอดภัย” (ต้องใช้ HTTPS)', null] : ($maxage >= 31536000 ? ['ok', $a['hsts'], '', '', null] : ['warn', $a['hsts'] . ' — max-age ควรอย่างน้อย 1 ปี (31536000)', '', 'ตั้ง max-age=31536000', null]),
        'V3.4.2' => '' === $a['acao'] ? ['ok', 'ไม่ได้เปิด CORS ให้เว็บอื่น', '', '', null] : ('*' === trim($a['acao']) ? ['warn', 'Access-Control-Allow-Origin: *', '', 'ตั้งเฉพาะโดเมนที่ต้องใช้', null] : ['ok', 'Access-Control-Allow-Origin: ' . $a['acao'], '', '', null]),
        'V3.4.3' => (false !== stripos($a['csp'], "object-src 'none'") && false !== stripos($a['csp'], "base-uri 'none'") && false !== stripos($a['csp'], 'script-src')) ? ['ok', $a['csp'], '', '', null] : ['warn', $a['csp'] ? 'CSP ยังไม่ครบ: ' . $a['csp'] : 'ไม่พบ Content-Security-Policy', '', 'CSP เต็มรูปแบบ (script-src allowlist / nonce, object-src \'none\', base-uri \'none\') ต้องทดสอบกับธีม ปลั๊กอิน และเนื้อหา (เช่น ไฟล์ PDF ที่ฝังในหน้า) ก่อนใช้จริง — ตั้งที่เว็บเซิร์ฟเวอร์แบบ Report-Only ก่อน', null],
        'V3.4.4' => false !== stripos($a['xcto'], 'nosniff') ? ['ok', 'X-Content-Type-Options: nosniff', '', '', null] : ['bad', 'ไม่พบ', 'headers', 'เปิด “ส่วนหัวความปลอดภัย”', null],
        'V3.4.5' => $hd('ref', 'Referrer-Policy'),
        'V3.4.6' => false !== stripos($a['csp'], 'frame-ancestors') ? ['ok', 'CSP frame-ancestors', '', '', null] : ('' !== $a['xfo'] ? ['warn', 'มีแค่ X-Frame-Options (เลิกใช้แล้วตาม ASVS)', 'headers', 'เปิด “ส่วนหัวความปลอดภัย” อีกครั้ง (รุ่นนี้ส่ง frame-ancestors)', null] : ['bad', 'ไม่พบ', 'headers', 'เปิด “ส่วนหัวความปลอดภัย”', null]),
        'V4.1.2' => $a['https'] && false !== $a['redirect'] ? ['ok', 'http:// พาไป https:// อัตโนมัติ', '', '', null] : ['bad', $a['https'] ? 'http:// ยังไม่ redirect' : 'ยังไม่ใช้ HTTPS', '', 'เปิด “บังคับใช้ HTTPS”', $ssl],
        'V5.2.2' => $on('risky_uploads') ? ['ok', 'WordPress ตรวจนามสกุลกับชนิดไฟล์จริง + ไม่รับไฟล์ที่ฝังสคริปต์ได้', '', '', null] : ['warn', 'WordPress ตรวจนามสกุลกับชนิดไฟล์ แต่ยังรับ SVG / HTML ได้ถ้าปลั๊กอินอื่นเปิดไว้', 'risky_uploads', 'เปิด “ปิดการอัปโหลดไฟล์ที่ฝังสคริปต์ได้”', null],
        'V5.3.1' => $c['uploads_locked'] ? ['ok', 'โฟลเดอร์อัปโหลดห้ามรันสคริปต์ (.htaccess)', '', '', null] : (stripos($a['server'], 'nginx') !== false ? ['manual', 'Nginx ไม่อ่าน .htaccess', '', 'ผู้ดูแลเซิร์ฟเวอร์ตั้ง <code>location ~* /uploads/.*\.php$ { deny all; }</code>', null] : ['bad', 'ยังไม่ป้องกัน', 'uploads_htaccess', 'กด “ป้องกันโฟลเดอร์อัปโหลด”', null]),
        'V5.3.2' => $pf('ตั้งชื่อไฟล์อัปโหลดใหม่ด้วย sanitize_file_name และไม่ใช้ path จากผู้ใช้'),
        'V6.2.1' => $setting('pw_policy', 'ยาวอย่างน้อย 8 ตัว', 'เปิด “นโยบายรหัสผ่านตามมาตรฐาน”'),
        'V6.2.2' => $pf('ผู้ใช้เปลี่ยนรหัสผ่านเองได้ที่หน้าโปรไฟล์'),
        'V6.2.3' => $setting('pw_policy', 'ต้องใส่รหัสผ่านปัจจุบันเมื่อเปลี่ยนรหัสผ่าน', 'เปิด “นโยบายรหัสผ่านตามมาตรฐาน”'),
        'V6.2.4' => $setting('pw_policy', 'ตรวจกับรายการรหัสผ่านที่รั่วไหล (Have I Been Pwned · k-anonymity)', 'เปิด “นโยบายรหัสผ่านตามมาตรฐาน”'),
        'V6.2.5' => $pf('ไม่บังคับชนิดตัวอักษร'),
        'V6.2.6' => $pf('ช่องรหัสผ่านเป็น type=password และกดดูได้'),
        'V6.2.7' => $pf('วางรหัสผ่านและใช้ password manager ได้'),
        'V6.2.8' => $pf('ตรวจรหัสผ่านตามที่พิมพ์ ไม่ตัด ไม่แปลงตัวพิมพ์'),
        'V6.2.9' => $pf('รองรับรหัสผ่านยาว 64 ตัวขึ้นไป'),
        'V6.2.10' => ['ok', 'ไม่บังคับเปลี่ยนรหัสผ่านตามรอบเวลา', '', '', null],
        'V6.2.12' => $setting('pw_policy', 'ตรวจกับรายการรหัสผ่านที่รั่วไหล', 'เปิด “นโยบายรหัสผ่านตามมาตรฐาน”'),
        'V6.3.1' => $setting('login_limit', 'ล็อกอินผิด 5 ครั้ง พัก 15 นาที' . ($on('login_captcha') ? ' + CAPTCHA' : ''), 'เปิด “จำกัดการล็อกอินผิด”'),
        'V6.3.2' => $c['named'] ? ['bad', 'พบบัญชีชื่อมาตรฐาน: ' . implode(', ', wp_list_pluck($c['named'], 'user_login')), '', 'สร้างผู้ดูแลชื่อใหม่ โอนเนื้อหา แล้วลบบัญชีเดิม', ['ไปหน้าผู้ใช้', admin_url('users.php')]] : ['ok', 'ไม่มีบัญชีชื่อ admin / root / test', '', '', null],
        'V6.3.3' => $c['no2'] ? ['bad', 'ผู้ดูแลที่ยังไม่ใช้ 2FA: ' . implode(', ', wp_list_pluck($c['no2'], 'user_login')), $on('2fa_force') ? '' : '2fa_force', 'บังคับผู้ดูแลทุกคนใช้ 2FA (Google Authenticator)', ['ตั้งค่า 2FA ของฉัน', admin_url('profile.php#idw-2fa')]] : ['ok', 'ผู้ดูแลทุกคนใช้ 2FA' . ($on('2fa_force') ? ' · บังคับใช้' : '') . ' — บทบาทอื่นประเมินตามความเสี่ยง', '', '', null],
        'V6.4.2' => $pf('ไม่มีคำถามลับ / คำใบ้รหัสผ่าน'),
        'V6.4.3' => function_exists('idw_2fa_enabled') ? ['ok', 'รีเซ็ตรหัสผ่านทางอีเมล แล้วต้องผ่าน 2FA ตอนเข้าสู่ระบบ', '', '', null] : ['manual', '', '', '', null],
    ];
    if (function_exists('idw_2fa_enabled')) foreach (['V6.5.1' => 'รหัส TOTP และรหัสสำรองใช้ได้ครั้งเดียว', 'V6.5.2' => 'รหัสสำรองเก็บแบบ hash', 'V6.5.3' => 'secret สร้างด้วย random_bytes (CSPRNG)', 'V6.5.4' => 'รหัส 6 หลัก / รหัสสำรอง 8 ตัว', 'V6.5.5' => 'TOTP มีอายุ 30 วินาที (คลาดเคลื่อนได้ ±30 วินาที)'] as $k => $t) $r[$k] = ['ok', $t, '', '', null];
    $r += [
        'V7.2.1' => $pf('ตรวจ session token ที่เซิร์ฟเวอร์'), 'V7.2.2' => $pf('session token สร้างใหม่ทุกครั้ง'), 'V7.2.3' => $pf('token สุ่มด้วย CSPRNG และไม่ซ้ำ'), 'V7.2.4' => $pf('ออก token ใหม่ทุกครั้งที่เข้าสู่ระบบ'),
        'V7.3.1' => $setting('idle_logout', 'ออกจากระบบเมื่อไม่ใช้งาน 15 นาที', 'เปิด “ออกจากระบบอัตโนมัติเมื่อไม่ใช้งาน 15 นาที”'),
        'V7.3.2' => ['ok', 'เซสชันหมดอายุสูงสุด 2 วัน (14 วันเมื่อเลือก “จดจำฉัน”)', '', '', null],
        'V7.4.1' => $pf('ออกจากระบบแล้ว token ใช้ต่อไม่ได้'), 'V7.4.4' => $pf('ปุ่มออกจากระบบอยู่ที่แถบด้านบนทุกหน้า'), 'V7.4.5' => $pf('ผู้ดูแลกด “ออกจากระบบทุกที่” ของผู้ใช้แต่ละคนได้ (หน้าแก้ไขผู้ใช้)'),
        'V7.5.2' => ['warn', 'ผู้ใช้กด “ออกจากระบบที่อื่นทั้งหมด” ได้ แต่ดูรายการเซสชันไม่ได้ (ข้อจำกัดของ WordPress)', '', 'บันทึกเป็นข้อยกเว้น', null],
        'V11.4.2' => version_compare($c['wp'], '6.8', '>=') ? ['ok', 'WordPress ' . $c['wp'] . ' เก็บรหัสผ่านด้วย bcrypt', '', '', null] : ['warn', 'WordPress ' . $c['wp'] . ' ใช้ phpass (MD5 วนซ้ำ)', '', 'อัปเดต WordPress เป็น 6.8 ขึ้นไป (เปลี่ยนเป็น bcrypt ให้อัตโนมัติเมื่อผู้ใช้เข้าสู่ระบบ)', ['ไปหน้าอัปเดต', admin_url('update-core.php')]],
        'V12.1.1' => null === $tls ? ['manual', 'ตรวจจากเซิร์ฟเวอร์นี้ไม่ได้', '', 'ตรวจด้วย SSL Labs', null] : (($tls['1.0'] || $tls['1.1']) ? ['bad', 'ยังเปิด TLS 1.0 / 1.1', '', 'ผู้ดูแลเซิร์ฟเวอร์ตั้ง <code>ssl_protocols TLSv1.2 TLSv1.3;</code>', null] : ['ok', 'รองรับ: TLS ' . implode(', ', array_keys(array_filter($tls))), '', '', null]),
        'V12.2.1' => $a['https'] && false !== $a['redirect'] ? ['ok', 'ใช้ HTTPS ทั้งเว็บ', '', '', null] : ['bad', 'ยังไม่ใช้ HTTPS ทั้งเว็บ', '', 'เปิด “บังคับใช้ HTTPS”', $ssl],
        'V12.2.2' => null === $a['cert'] ? ['bad', 'ยังไม่ใช้ HTTPS', '', '', $ssl] : ($a['cert'] ? ['ok', 'ใบรับรองเชื่อถือได้ (ตรวจกับ CA สาธารณะ)', '', '', null] : ['bad', 'ใบรับรองตรวจไม่ผ่าน (self-signed / หมดอายุ / ชื่อไม่ตรง)', '', 'ติดตั้งใบรับรองจาก CA สาธารณะ เช่น Let\'s Encrypt', $ssl]),
        'V13.4.1' => null === $a['git'] ? ['manual', 'ตรวจไม่ได้', '', '', null] : ($a['git'] ? ['bad', 'เปิดอ่าน /.git/ ได้จากภายนอก', 'root_htaccess', 'ปิดการเข้าถึง .git และลบโฟลเดอร์ออกจากเซิร์ฟเวอร์', null] : ['ok', 'ไม่พบ .git ที่เปิดเผย', '', '', null]),
        'V13.4.2' => $c['debug_display'] ? ['bad', 'แสดงข้อผิดพลาด PHP บนหน้าเว็บ (WP_DEBUG_DISPLAY / display_errors)', '', 'ใน wp-config.php ตั้ง <code>define(\'WP_DEBUG\', false);</code> หรือ <code>define(\'WP_DEBUG_DISPLAY\', false);</code>', null] : ['ok', 'ไม่แสดงข้อผิดพลาดบนหน้าเว็บ', '', '', null],
        'V13.4.3' => null === $a['listing'] ? ['manual', 'ตรวจไม่ได้', '', '', null] : ($a['listing'] ? ['bad', 'เปิดดูรายชื่อไฟล์ในโฟลเดอร์อัปโหลดได้', 'uploads_htaccess', 'กด “ป้องกันโฟลเดอร์อัปโหลด”', null] : ['ok', 'ไม่แสดงรายชื่อไฟล์', '', '', null]),
        'V13.4.4' => null === $a['trace'] ? ['manual', 'ตรวจไม่ได้', '', '', null] : ($a['trace'] ? ['bad', 'เซิร์ฟเวอร์ตอบ HTTP TRACE', '', 'Apache <code>TraceEnable Off</code> · Nginx ไม่รองรับ TRACE อยู่แล้ว', null] : ['ok', 'ไม่รองรับ TRACE', '', '', null]),
        'V13.4.5' => $a['readme'] ? ['warn', 'readme.html บอกเวอร์ชัน WordPress', 'readme', 'กด “ลบไฟล์ที่บอกเวอร์ชัน”', null] : ($on('users_api') ? ['ok', 'ไม่มีเอกสาร / ข้อมูลภายในที่เปิดเผย', '', '', null] : ['warn', 'REST API เปิดรายชื่อผู้ใช้ (/wp-json/wp/v2/users)', 'users_api', 'เปิด “ซ่อนรายชื่อผู้ใช้”', null]),
        'V14.3.1' => $on('headers') ? ['ok', 'ส่ง Clear-Site-Data เมื่อออกจากระบบ', '', '', null] : ['warn', 'ยังไม่ล้างข้อมูลในเบราว์เซอร์เมื่อออกจากระบบ', 'headers', 'เปิด “ส่วนหัวความปลอดภัย”', null],
        'V15.2.1' => ($c['upd'] || $c['cves'] || $c['php_bad']) ? ['bad', trim(($c['upd'] ? 'รออัปเดต ' . $c['upd'] . ' รายการ · ' : '') . ($c['cves'] ? 'ช่องโหว่ CVE ระดับสูง ' . count($c['cves']) . ' รายการ · ' : '') . ($c['php_bad'] ? 'ช่องโหว่ PHP ' . $c['php_bad'] . ' รายการ' : ''), ' ·'), '', 'อัปเดตและแก้ตามผลการตรวจ (OWASP)', ['ผลการตรวจ', admin_url('admin.php?page=idw-security')]] : ['ok', 'ส่วนประกอบเป็นรุ่นล่าสุด ไม่พบ CVE ระดับสูง' . ($c['scan_t'] ? ' (ตรวจ ' . idw_dt($c['scan_t']) . ')' : ''), '', '', null],
        'V15.2.3' => $on('xmlrpc') && $on('file_edit') ? ['ok', 'ปิด XML-RPC และตัวแก้ไขไฟล์แล้ว', '', '', null] : ['warn', 'ยังเปิด ' . implode(' / ', array_filter([$on('xmlrpc') ? '' : 'XML-RPC', $on('file_edit') ? '' : 'ตัวแก้ไขไฟล์หลังบ้าน'])), 'ncsa_cms', 'กด “เปิดการป้องกัน CMS ที่เหลือทั้งหมด”', null],
        'V16.3.1' => $setting('log', 'บันทึกการเข้าสู่ระบบสำเร็จ / ไม่สำเร็จ และ 2FA', 'เปิด “บันทึกเหตุการณ์ความปลอดภัย”'),
        'V16.3.2' => $on('log') ? ['warn', 'บันทึกการเปลี่ยนสิทธิ์และการตั้งค่า แต่ไม่ได้บันทึกการเข้าหน้าที่ไม่มีสิทธิ์ทุกครั้ง', '', 'ถ้าต้องการครบ ใช้ log ของเว็บเซิร์ฟเวอร์ (403) ร่วมด้วย', null] : ['bad', 'ยังไม่บันทึก', 'log', 'เปิด “บันทึกเหตุการณ์ความปลอดภัย”', null],
        'V16.5.1' => $c['debug_display'] ? ['bad', 'แสดงข้อผิดพลาด PHP บนหน้าเว็บ', '', 'ปิด WP_DEBUG_DISPLAY / display_errors', null] : ['ok', 'แสดงข้อความทั่วไปเมื่อเกิดข้อผิดพลาด', '', '', null],
    ];
    return $r;
}

/** Requirements that usually do not apply to a WordPress website (suggested “ไม่เกี่ยวข้อง” until the assessor decides). */
function idw_sec_asvs_na($id) {
    $na = ['V1.2.6' => 'ไม่ใช้ LDAP', 'V1.2.7' => 'ไม่ใช้ XPath', 'V1.2.8' => 'ไม่ใช้ LaTeX', 'V1.3.8' => 'ไม่ใช้ JNDI (Java)', 'V1.3.9' => 'ไม่ส่งข้อมูลผู้ใช้เข้า memcache โดยตรง', 'V1.4.' => 'PHP จัดการหน่วยความจำให้ (memory-safe)', 'V4.3.' => 'ไม่ใช้ GraphQL', 'V4.4.' => 'ไม่ใช้ WebSocket',
        'V6.6.' => 'ไม่ใช้ OTP ทาง SMS / out-of-band', 'V6.8.' => 'ไม่ใช้ Identity Provider ภายนอก (SSO)', 'V7.6.' => 'ไม่ใช้ Identity Provider ภายนอก', 'V7.1.3' => 'ไม่ใช้ SSO', 'V8.4.1' => 'ไม่ใช่ระบบหลายผู้เช่า (multi-tenant)', 'V9.' => 'ไม่ใช้ JWT / self-contained token', 'V10.' => 'ไม่ใช้ OAuth / OIDC', 'V12.1.3' => 'ไม่ใช้ mTLS', 'V17.' => 'ไม่ใช้ WebRTC'];
    foreach ($na as $p => $why) if (0 === strpos($id . '.', $p) || $id === $p) return $why;
    return '';
}
/** short Thai pointer for manual requirements */
function idw_sec_asvs_hint($id, $desc) {
    $h = ['V1.2.4' => 'WordPress ใช้ $wpdb->prepare — ตรวจโค้ดของปลั๊กอิน / ธีมที่เขียนเพิ่ม', 'V1.2.1' => 'WordPress ใช้ esc_html / esc_attr — ตรวจธีมและปลั๊กอินที่เขียนเพิ่ม', 'V1.3.2' => 'ตรวจว่าไม่มี eval() ในปลั๊กอิน / ธีมที่เขียนเพิ่ม', 'V3.5.3' => 'WordPress ใช้ POST + nonce สำหรับการเปลี่ยนแปลงข้อมูล',
        'V5.4.3' => 'สแกนไฟล์อัปโหลดด้วย antivirus ที่เซิร์ฟเวอร์ (เช่น ClamAV) หรือบริการของโฮสติ้ง', 'V8.2.1' => 'WordPress ตรวจสิทธิ์ด้วย current_user_can — ทบทวนบทบาทผู้ใช้', 'V8.3.1' => 'WordPress ตรวจสิทธิ์ที่เซิร์ฟเวอร์ — ทบทวนปลั๊กอินที่เขียนเพิ่ม', 'V11.5.1' => 'WordPress ใช้ random_int / wp_generate_password',
        'V12.1.2' => 'ตรวจ cipher suite ด้วย SSL Labs (ssllabs.com/ssltest)', 'V14.2.1' => 'ตรวจว่าแบบฟอร์ม (เช่น ลงทะเบียนผู้ป่วย) ส่งข้อมูลด้วย POST ไม่ใส่ใน URL', 'V15.1.2' => 'ใช้รายการปลั๊กอิน / ธีม / เวอร์ชันจากหน้า เครื่องมือ › สุขภาพเว็บไซต์ › ข้อมูล เป็น SBOM', 'V16.2.2' => 'ตั้ง NTP ที่เซิร์ฟเวอร์ · WordPress ใช้เขตเวลา ' . wp_timezone_string(),
        'V16.4.2' => 'บันทึกเหตุการณ์อยู่ในฐานข้อมูล ดูได้เฉพาะผู้ดูแล — ถ้าต้องการกันแก้ไข ส่งไปเก็บที่ระบบแยก (SIEM / syslog)', 'V16.4.3' => 'ส่ง log ไปยังระบบแยก (SIEM / syslog) ของหน่วยงาน', 'V7.4.2' => 'เมื่อลบผู้ใช้ WordPress ลบเซสชันทั้งหมด · การระงับบัญชีตามมาตรฐาน สกมช. กันไม่ให้เข้าสู่ระบบ'];
    if (isset($h[$id])) return $h[$id];
    if (preg_match('/\bdocument(ation|ed)\b/i', $desc)) return 'ข้อกำหนดด้านเอกสาร — ระบุชื่อเอกสาร / นโยบายที่ใช้เป็นหลักฐานในหมายเหตุ';
    return '';
}

/** [chapter => [title, [rows]]] — row: [id, text, st, detail, fix, link, how, manual?, level] */
function idw_sec_asvs_items($fresh = false, $level = null) {
    $data = idw_sec_asvs_data(); $man = idw_sec_fw_manual('asvs'); $level = (int) ($level ?: $man['level']);
    $auto = idw_sec_asvs_auto(idw_sec_fw_auto($fresh), idw_sec_fw_ctx());
    $map = ['pass' => 'ok', 'fail' => 'bad', 'na' => 'na'];
    $out = [];
    foreach ($data['req'] as $id => $r) {
        if ($r[0] > $level) continue;
        $ch = strtok($id, '.');
        if (!isset($out[$ch])) $out[$ch] = [$ch . ' ' . $data['chapters'][$ch][1] . ' (' . $data['chapters'][$ch][0] . ')', []];
        $d = $man['items'][$id] ?? [];
        if (isset($auto[$id]) && 'manual' !== $auto[$id][0]) { [$st, $detail, $fix, $how, $link] = $auto[$id]; $out[$ch][1][] = [$id, $r[1], $st, $detail, $fix, $link, $how, false, $r[0]]; continue; }
        if (isset($auto[$id])) { // the check could not run from here: the assessor decides
            $st = isset($map[$d['st'] ?? '']) ? $map[$d['st']] : 'manual';
            $out[$ch][1][] = [$id, $r[1], $st, trim($auto[$id][1] . (!empty($d['note']) ? ' · ' . $d['note'] : ''), ' ·'), '', $auto[$id][4], $auto[$id][3], true, $r[0]];
            continue;
        }
        $na = idw_sec_asvs_na($id);
        $st = isset($map[$d['st'] ?? '']) ? $map[$d['st']] : ($na ? 'na' : 'manual');
        $detail = !empty($d['st']) ? trim(('pass' === $d['st'] ? 'ผ่าน' : ('fail' === $d['st'] ? 'ไม่ผ่าน' : 'ไม่เกี่ยวข้อง')) . (!empty($d['date']) ? ' · ' . $d['date'] : '') . (!empty($d['note']) ? ' · ' . $d['note'] : '')) : ($na ? 'แนะนำ: ไม่เกี่ยวข้อง — ' . $na : '');
        $out[$ch][1][] = [$id, $r[1], $st, $detail, '', null, idw_sec_asvs_hint($id, $r[1]), true, $r[0]];
    }
    return $out;
}

/* ===================================================== CTAM+ (สป.สธ. 2569) ===================================================== */

function idw_sec_ctam_items($fresh = false) {
    $a = idw_sec_fw_auto($fresh); $c = idw_sec_fw_ctx(); $on = 'idw_sec_on'; $man = idw_sec_fw_manual('ctam');
    $last = $c['scan_t'];
    // [no, title, auto [st, evidence] | null, fix, link, what the assessor should keep as evidence]
    $L = [
        [1, 'การสำรองข้อมูล (Backup)', $c['backup'] ? ['ok', 'พบปลั๊กอินสำรองข้อมูล: ' . implode(', ', $c['backup'])] : ['warn', 'ไม่พบปลั๊กอินสำรองข้อมูลในเว็บ — ถ้าโฮสติ้ง / ศูนย์คอมพิวเตอร์สำรองให้ แนบหลักฐานในหมายเหตุ'], '', $c['backup'] ? null : ['ติดตั้ง UpdraftPlus', admin_url('plugin-install.php?s=updraftplus&tab=search&type=term')], 'ผลทดสอบกู้คืนฐานข้อมูลตัวอย่าง เวลาที่ใช้กู้คืน และการตรวจความครบถ้วน · สำรองแยกนอกเครื่อง (3-2-1)'],
        [2, 'โปรแกรมป้องกันไวรัส (Antivirus / EDR)', $c['wafp'] ? ['ok', 'เว็บมีปลั๊กอินสแกนมัลแวร์: ' . implode(', ', $c['wafp'])] : null, '', null, 'รายชื่อเครื่องเทียบทะเบียนทรัพย์สิน วันที่อัปเดต signature และเครื่องที่ต้องแก้ไข (รวมเครื่องเซิร์ฟเวอร์เว็บ)'],
        [3, 'การควบคุมการเข้าถึง (Access Control)', ($on('inactive_lock') && !$c['named']) ? ['ok', 'ผู้ดูแลระบบ ' . count($c['admins']) . ' คน · ระงับบัญชีไม่ใช้งาน 45 วัน · ไม่มีบัญชีชื่อมาตรฐาน'] : ['warn', 'ผู้ดูแลระบบ ' . count($c['admins']) . ' คน (' . implode(', ', array_slice(wp_list_pluck($c['admins'], 'user_login'), 0, 6)) . ')' . ($c['named'] ? ' · พบบัญชีชื่อ ' . implode(', ', wp_list_pluck($c['named'], 'user_login')) : '') . ($on('inactive_lock') ? '' : ' · ยังไม่ระงับบัญชีที่ไม่ใช้งาน')], $on('inactive_lock') ? '' : 'inactive_lock', ['ไปหน้าผู้ใช้', admin_url('users.php')], 'ตารางสิทธิ์ตามบทบาท (Public / Private) การอนุมัติสิทธิ์ และตัวอย่างการถอนสิทธิ์เมื่อย้าย / ลาออก'],
        [4, 'บัญชีสิทธิ์สูง (PAM)', (!$c['no2'] && $on('log')) ? ['ok', 'ผู้ดูแลทุกคนใช้ 2FA · บันทึกการเข้าใช้และการเปลี่ยนสิทธิ์ 90 วัน'] : ['bad', trim(($c['no2'] ? 'ผู้ดูแลยังไม่ใช้ 2FA: ' . implode(', ', wp_list_pluck($c['no2'], 'user_login')) . ' · ' : '') . ($on('log') ? '' : 'ยังไม่บันทึกเหตุการณ์'), ' ·')], $c['no2'] && !$on('2fa_force') ? '2fa_force' : ($on('log') ? '' : 'log'), ['ดูบันทึก', admin_url('admin.php?page=idw-security&tab=log')], 'ทะเบียนบัญชีสิทธิ์สูง การอนุมัติ log การใช้งาน และการทบทวนบัญชีฉุกเฉิน'],
        [5, 'แผนความต่อเนื่อง (BCP) และกู้คืนระบบ (DRP)', null, '', null, 'แผนที่ผู้บริหารอนุมัติ ผลการซ้อม เวลากู้คืนจริง (RTO / RPO) และการปรับปรุงหลังซ้อม'],
        [6, 'แพตช์ระบบปฏิบัติการ (OS Patching)', ($c['php_eol'] || $c['php_bad']) ? ['bad', 'PHP ' . PHP_VERSION . ($c['php_eol'] ? ' หมดระยะสนับสนุน' : '') . ($c['php_bad'] ? ' · ช่องโหว่ PHP ' . $c['php_bad'] . ' รายการ (' . implode(', ', array_map(function ($i) { return preg_match_all('/CVE-\d{4}-\d+/', $i['title'], $m) ? implode(', ', $m[0]) : ''; }, $c['php_items'])) . ')' : '')] : ['ok', 'PHP ' . PHP_VERSION . ' ยังได้รับการสนับสนุน และไม่พบช่องโหว่ PHP ที่ทราบ · OS: ' . php_uname('s') . ' ' . php_uname('r')], '', ['ผลการตรวจ', admin_url('admin.php?page=idw-security')], 'รายงานสถานะแพตช์ของเซิร์ฟเวอร์ รายการยกเว้น และผู้อนุมัติ'],
        [7, 'การยืนยันตัวตนหลายปัจจัย (MFA / 2FA)', $c['no2'] ? ['bad', 'ผู้ดูแลยังไม่ใช้ 2FA: ' . implode(', ', wp_list_pluck($c['no2'], 'user_login'))] : ['ok', 'ผู้ดูแลเว็บทุกคนใช้ Google Authenticator' . ($on('2fa_force') ? ' · บังคับใช้' : '')], $c['no2'] && !$on('2fa_force') ? '2fa_force' : '', ['ตั้งค่า 2FA ของฉัน', admin_url('profile.php#idw-2fa')], 'นโยบายการยืนยันตัวตน ผลทดสอบ และรายชื่อบัญชีที่ได้รับยกเว้น (ทุกระบบที่เข้าจากภายนอก)'],
        [8, 'Web Application Firewall (WAF)', $a['waf'] || $c['wafp'] ? ['ok', 'พบ: ' . implode(', ', array_merge($a['waf'], $c['wafp'])) . (!$a['waf'] ? ' (ปลั๊กอิน — ควรมี WAF หน้าเว็บด้วย)' : '')] : ['warn', 'ไม่พบ WAF หน้าเว็บ (ตรวจจากส่วนหัว HTTP) — ถ้ามี WAF / Firewall ของหน่วยงานอยู่หน้าเว็บ ระบุในหมายเหตุ'], '', null, 'รายชื่อโดเมน / API ที่อยู่หลัง WAF โหมดบังคับใช้ กฎที่เปิด บันทึกเหตุการณ์ และประวัติการทบทวน'],
        [9, 'การจัดการบันทึกเหตุการณ์ (Log Management)', $on('log') ? ['ok', 'บันทึกเหตุการณ์ความปลอดภัยของเว็บ 90 วัน · เวลาเซิร์ฟเวอร์ ' . wp_date('Y-m-d H:i') . ' (' . wp_timezone_string() . ')'] : ['bad', 'ยังไม่บันทึกเหตุการณ์'], $on('log') ? '' : 'log', ['ดูบันทึก', admin_url('admin.php?page=idw-security&tab=log')], 'ทะเบียนแหล่ง log การตั้งเวลา (NTP) ระยะเวลาเก็บ (≥ 90 วัน ตาม พ.ร.บ.คอมพิวเตอร์) ผู้มีสิทธิ์ค้น และตัวอย่างการค้น'],
        [10, 'SIEM (Security Information & Event Management)', null, '', null, 'การแจ้งเตือนที่ผูกกับ ticket ผู้รับผิดชอบ และผลการปิดเหตุ · ส่ง log เว็บเซิร์ฟเวอร์เข้า SIEM ของหน่วยงาน'],
        [11, 'การประเมินช่องโหว่ (VA Scan)', $last && $last > time() - 90 * DAY_IN_SECONDS ? ['ok', 'ตรวจล่าสุด ' . idw_dt($last) . ($on('auto_scan') ? ' · ตรวจอัตโนมัติทุก 30 วัน' : '')] : ['bad', $last ? 'ตรวจล่าสุด ' . idw_dt($last) . ' (เกิน 90 วัน)' : 'ยังไม่เคยตรวจ'], $on('auto_scan') ? '' : 'auto_scan', ['ผลการตรวจ', admin_url('admin.php?page=idw-security')], 'รายงาน VA ระบุระบบที่สแกน ระดับความสำคัญ และผลสแกนซ้ำหลังแก้ (ส่งออกได้จากแท็บ “ส่งออกรายงาน”)'],
        [12, 'สำรวจและปิดระบบที่ไม่ได้ใช้งาน', ($c['inactive'] || count($c['themes']) > 1 || $c['stale']) ? ['warn', trim(($c['inactive'] ? 'ปลั๊กอินที่ปิดอยู่ ' . count($c['inactive']) . ' ตัว · ' : '') . (count($c['themes']) > 1 ? 'ธีมที่ไม่ใช้ ' . count($c['themes']) . ' ธีม · ' : '') . ($c['stale'] ? 'บัญชีไม่ได้เข้าใช้เกิน 45 วัน ' . count($c['stale']) . ' บัญชี' : ''), ' ·')] : ['ok', 'ไม่มีปลั๊กอิน / ธีม / บัญชีที่ไม่ได้ใช้'], $c['stale'] && !$on('inactive_lock') ? 'inactive_lock' : '', $c['inactive'] ? ['จัดการปลั๊กอิน', admin_url('plugins.php?plugin_status=inactive')] : null, 'ทะเบียนระบบ บันทึกการปลดระวางที่เจ้าของระบบอนุมัติ และการตรวจหลังปิด'],
        [13, 'อัปเดตซอฟต์แวร์และแพตช์ความปลอดภัย', ($c['upd'] || $c['cves']) ? ['bad', trim(($c['upd'] ? 'รออัปเดต ' . $c['upd'] . ' รายการ · ' : '') . ($c['cves'] ? 'ช่องโหว่ CVE ระดับสูง ' . count($c['cves']) . ' รายการ' : ''), ' ·')] : ['ok', 'WordPress ปลั๊กอิน และธีมเป็นรุ่นล่าสุด ไม่พบ CVE ระดับสูง'], '', ['ไปหน้าอัปเดต', admin_url('update-core.php')], 'ทะเบียนเวอร์ชันซอฟต์แวร์ แผนอัปเกรดรุ่นที่หมดการสนับสนุน และผลทดสอบหลังอัปเดต'],
        [14, 'การแบ่งส่วนเครือข่าย (Network Segmentation)', null, '', null, 'ผังเครือข่าย กฎระหว่างโซน (เว็บ / DMZ แยกจาก HIS และฐานข้อมูล) และการตรวจตามขอบเขตที่อนุมัติ'],
        [15, 'ใช้ซอฟต์แวร์ถูกลิขสิทธิ์', null, '', ['รายการปลั๊กอิน', admin_url('plugins.php')], 'ทะเบียนซอฟต์แวร์ที่ติดตั้งเทียบใบอนุญาตและสัญญา · ปลั๊กอิน / ธีมแบบเสียเงินต้องซื้อจากผู้พัฒนา (ไม่ใช้ฉบับ nulled)'],
        [16, 'การทดสอบเจาะระบบ (Penetration Testing)', null, '', null, 'ขอบเขตที่อนุมัติ รายงานผลกระทบ รายการแก้ไข และรายงานทดสอบซ้ำ'],
        [17, 'นโยบายไซเบอร์ การคุ้มครองข้อมูลส่วนบุคคล และการพัฒนาบุคลากร', ($c['privacy'] && $c['cookie']) ? ['ok', 'มีหน้านโยบายความเป็นส่วนตัว และแบนเนอร์คุกกี้ (PDPA)'] : ['warn', trim(($c['privacy'] ? '' : 'ยังไม่ได้กำหนดหน้านโยบายความเป็นส่วนตัว · ') . ($c['cookie'] ? '' : 'ยังไม่เปิดแบนเนอร์คุกกี้'), ' ·')], '', ['ตั้งหน้านโยบายความเป็นส่วนตัว', admin_url('options-privacy.php')], 'นโยบายที่อนุมัติ (รวม PDPA) ประกาศเว็บไซต์ บันทึกการอบรม ผลประเมิน และช่องว่างการพัฒนาบุคลากร'],
    ];
    $rows = [];
    foreach ($L as $x) {
        [$no, $title, $auto, $fix, $link, $ev] = $x;
        $d = $man['items']['ctam-' . $no] ?? [];
        $st = 'pass' === ($d['st'] ?? '') ? 'ok' : ('fail' === ($d['st'] ?? '') ? 'bad' : ($auto && 'bad' === $auto[0] ? 'bad' : 'manual'));
        $detail = trim(($auto ? 'เว็บไซต์: ' . $auto[1] : '') . (!empty($d['st']) ? ' · ผลประเมินหน่วยงาน: ' . ('pass' === $d['st'] ? 'ผ่าน' : 'ไม่ผ่าน') . (!empty($d['date']) ? ' (' . $d['date'] . ')' : '') . (!empty($d['note']) ? ' — ' . $d['note'] : '') : ''), ' ·');
        $rows[] = ['ctam-' . $no, $no . '. ' . $title, $st, $detail, $fix, $link, $ev, true, 0, $auto ? $auto[0] : ''];
    }
    return ['ctam' => ['CTAM+ ปีงบประมาณ 2569 — 17 ข้อ', $rows]];
}

/* ===================================================== shared: tab, save, flat ===================================================== */

add_action('admin_post_idw_sec_fw', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_sec_fw')) wp_die('ไม่มีสิทธิ์', 403);
    $fw = in_array($_POST['fw'] ?? '', ['asvs', 'ctam'], true) ? $_POST['fw'] : 'asvs'; // phpcs:ignore
    $m = idw_sec_fw_manual($fw);
    if (isset($_POST['level']) && in_array($_POST['level'], ['1', '2', '3'], true)) $m['level'] = $_POST['level']; // phpcs:ignore
    foreach ((array) ($_POST['m'] ?? []) as $id => $v) { // phpcs:ignore — only the rows the assessor changed are sent (max_input_vars)
        $id = preg_replace('/[^A-Za-z0-9.\-]/', '', (string) $id); $v = (array) wp_unslash($v);
        if ('' === $id) continue;
        $st = in_array($v['st'] ?? '', ['pass', 'fail', 'na'], true) ? $v['st'] : '';
        $m['items'][$id] = ['st' => $st, 'date' => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($v['date'] ?? '')) ? $v['date'] : ($st ? wp_date('Y-m-d') : ''), 'note' => sanitize_text_field($v['note'] ?? ''), 'by' => get_current_user_id()];
        if (!$st && !$m['items'][$id]['note']) unset($m['items'][$id]);
    }
    update_option('idw_sec_fw_' . $fw, $m, false);
    if (isset($_POST['refresh'])) delete_transient('idw_sec_fw_auto');
    idw_sec_log('setting', 'บันทึกการประเมินตาม ' . ('ctam' === $fw ? 'CTAM+' : 'OWASP ASVS'));
    wp_safe_redirect(admin_url('admin.php?page=idw-security&tab=' . $fw . '&saved=1')); exit;
});

function idw_sec_fw_count($secs) {
    $n = ['ok' => 0, 'bad' => 0, 'warn' => 0, 'manual' => 0, 'na' => 0, 'all' => 0];
    foreach ($secs as $s) foreach ($s[1] as $i) { $n['all']++; $n[isset($n[$i[2]]) ? $i[2] : 'manual']++; }
    $n['applicable'] = $n['all'] - $n['na'];
    $n['pct'] = $n['applicable'] ? (int) round($n['ok'] / $n['applicable'] * 100) : 0;
    return $n;
}

/** flat list for snapshots / the report */
function idw_sec_fw_flat($fw, $fresh = false) {
    $secs = 'ctam' === $fw ? idw_sec_ctam_items($fresh) : idw_sec_asvs_items($fresh);
    $out = [];
    foreach ($secs as $sec) foreach ($sec[1] as $i) $out[] = ['sec' => $sec[0], 'id' => $i[0], 'title' => 'asvs' === $fw ? wp_html_excerpt($i[1], 160, '…') : $i[1], 'st' => $i[2], 'detail' => wp_strip_all_tags((string) $i[3]), 'how' => wp_strip_all_tags((string) $i[6]), 'lv' => (int) $i[8]];
    return $out;
}

function idw_sec_tab_fw($fw) {
    if (isset($_GET['fresh'])) delete_transient('idw_sec_fw_auto'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    @set_time_limit(120); // phpcs:ignore
    $man = idw_sec_fw_manual($fw);
    $secs = 'ctam' === $fw ? idw_sec_ctam_items() : idw_sec_asvs_items();
    $n = idw_sec_fw_count($secs);
    if (isset($_GET['saved'])) idw_note('บันทึกแล้ว'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $print = 'ctam' === $fw ? 'แบบประเมิน CTAM+ (ส่วนเว็บไซต์)' : 'แบบประเมิน OWASP ASVS 5.0 ระดับ L' . (int) $man['level'];
    if ('ctam' === $fw) {
        $head = '<h2 style="margin:0 0 4px">CTAM+ สำนักงานปลัดกระทรวงสาธารณสุข ปีงบประมาณ 2569</h2><p class="d" style="margin:0">ผ่าน ' . (int) $n['ok'] . ' จาก 17 ข้อ · ไม่ผ่าน ' . (int) $n['bad'] . ' · รอยืนยัน ' . (int) $n['manual'] . ' — เกณฑ์ “ระดับสูง” ต้องผ่านครบทุกข้อ (ค = ข้อที่ผ่าน ÷ 17 × 100)</p>'
            . '<p class="d" style="margin:6px 0 0">CTAM+ ประเมินทั้งหน่วยงาน (ทุกระบบ ไม่ใช่เฉพาะเว็บไซต์) — ระบบแสดง <b>หลักฐานจากเว็บไซต์นี้</b> ให้อัตโนมัติ ผู้รับผิดชอบเลือกผลระดับหน่วยงาน ใส่วันที่และหลักฐาน · ข้อที่เว็บไซต์ไม่ผ่านจะนับเป็นไม่ผ่าน จนกว่าจะแก้ หรือผู้รับผิดชอบยืนยันพร้อมหลักฐาน (เช่น แพ็กเกจ PHP ของระบบปฏิบัติการที่แก้แล้ว) · <a href="https://healthkpi.moph.go.th/kpi/kpi_template/2569/027.pdf" target="_blank" rel="noopener">ตัวชี้วัดและเกณฑ์ (สป.สธ.)</a></p>';
    } else {
        $head = '<h2 style="margin:0 0 4px">OWASP Application Security Verification Standard 5.0 — ระดับ L' . (int) $man['level'] . '</h2><p class="d" style="margin:0">ผ่าน ' . (int) $n['ok'] . ' จาก ' . (int) $n['applicable'] . ' ข้อที่เกี่ยวข้อง · ต้องแก้ไข ' . (int) $n['bad'] . ' · ควรปรับปรุง / ข้อยกเว้น ' . (int) $n['warn'] . ' · รอประเมิน ' . (int) $n['manual'] . ' · ไม่เกี่ยวข้อง ' . (int) $n['na'] . '</p>'
            . '<p class="d" style="margin:6px 0 0">ข้อที่ปลั๊กอินพิสูจน์ได้ตรวจให้อัตโนมัติพร้อมปุ่มแก้ · ข้อที่เป็นโค้ด / เอกสาร / เซิร์ฟเวอร์ ผู้ประเมินเลือก ผ่าน / ไม่ผ่าน / ไม่เกี่ยวข้อง · ข้อความข้อกำหนดเป็นต้นฉบับภาษาอังกฤษของ OWASP (CC BY-SA 4.0) · <a href="https://github.com/OWASP/ASVS/tree/master/5.0" target="_blank" rel="noopener">อ่านมาตรฐานฉบับเต็ม</a></p>';
    }
    echo '<div class="idw-card ncsa-head"><div class="ring" style="--p:' . (int) $n['pct'] . '"><b>' . (int) $n['pct'] . '%</b></div><div>' . $head . '</div><div class="ncsa-acts"><a class="idw-btn sm" href="' . esc_url(admin_url('admin.php?page=idw-security&tab=' . $fw . '&fresh=1')) . '">' . idw_icon('refresh') . 'ตรวจใหม่</a><button type="button" class="idw-btn sm" onclick="window.print()">' . idw_icon('book') . 'พิมพ์แบบประเมิน</button></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="ncsa fw" id="fwf">' . wp_nonce_field('idw_sec_fw', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_sec_fw"><input type="hidden" name="fw" value="' . esc_attr($fw) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if ('asvs' === $fw) {
        echo '<div class="idw-card fw-bar"><label><b>ระดับเป้าหมาย</b> <select name="level" class="idw-in" style="width:auto" onchange="this.form.submit()">';
        foreach (['1' => 'L1 — ขั้นต่ำสำหรับทุกเว็บ', '2' => 'L2 — เว็บที่มีข้อมูลสำคัญ (แนะนำสำหรับโรงพยาบาล)', '3' => 'L3 — ระบบวิกฤต'] as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($man['level'], $k, false) . '>' . esc_html($l) . '</option>';
        echo '</select></label><span class="fw-filter"><button type="button" class="idw-btn sm on" data-f="all">ทั้งหมด</button><button type="button" class="idw-btn sm" data-f="todo">ต้องแก้ / รอประเมิน</button><button type="button" class="idw-btn sm" data-f="auto">ตรวจอัตโนมัติ</button></span></div>';
    }
    $label = ['ok' => ['ผ่าน', 'ok'], 'warn' => ['ควรปรับปรุง', 'warn'], 'bad' => ['ต้องแก้ไข', 'bad'], 'manual' => ['ctam' === $fw ? 'รอยืนยัน' : 'รอประเมิน', 'info'], 'na' => ['ไม่เกี่ยวข้อง', '']];
    $opts = 'ctam' === $fw ? ['' => '— ผลระดับหน่วยงาน —', 'pass' => 'ผ่าน', 'fail' => 'ไม่ผ่าน'] : ['' => '— ยังไม่ประเมิน —', 'pass' => 'ผ่าน', 'fail' => 'ไม่ผ่าน', 'na' => 'ไม่เกี่ยวข้อง'];
    foreach ($secs as $sk => $s) {
        $c = idw_sec_fw_count([$s]);
        $open = 'ctam' === $fw || $c['bad'] || $c['manual'];
        echo '<details class="idw-card ncsa-sec"' . ($open ? ' open' : '') . '><summary><h3>' . esc_html($s[0]) . '</h3><span class="d">ผ่าน ' . (int) $c['ok'] . '/' . (int) $c['applicable'] . ($c['bad'] ? ' · ต้องแก้ ' . (int) $c['bad'] : '') . ($c['manual'] ? ' · รอ ' . (int) $c['manual'] : '') . '</span></summary>';
        foreach ($s[1] as $i) {
            [$id, $title, $st, $detail, $fix, $link, $how, $isManual, $lv] = $i;
            $autoSt = $i[9] ?? '';
            $d = $man['items'][$id] ?? [];
            echo '<div class="ncsa-row" data-st="' . esc_attr($st) . '" data-auto="' . ($isManual ? '0' : '1') . '"><span class="idw-chip ' . esc_attr($label[$st][1]) . '">' . esc_html($label[$st][0]) . '</span><div class="t">';
            echo 'asvs' === $fw ? '<b><code>' . esc_html($id) . '</code> <span class="lv">L' . (int) $lv . '</span></b><span class="req">' . esc_html($title) . '</span>' : '<b>' . esc_html($title) . '</b>';
            if ('ctam' === $fw && $autoSt) echo '<small>ผลตรวจในเว็บไซต์: <span class="idw-chip ' . esc_attr($label[$autoSt][1]) . '">' . esc_html($label[$autoSt][0]) . '</span></small>';
            if ($detail) echo '<small>' . esc_html($detail) . '</small>';
            if ($how && ('ok' !== $st || 'ctam' === $fw)) echo '<small class="how">' . ('ctam' === $fw ? 'หลักฐานที่ควรเก็บ: ' : '') . wp_kses($how, ['code' => []]) . '</small>';
            if ($isManual) {
                echo '<div class="mi"><select data-n="m[' . esc_attr($id) . '][st]" class="idw-in" style="width:auto">';
                foreach ($opts as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($d['st'] ?? '', $k, false) . '>' . esc_html($l) . '</option>';
                echo '</select> <input type="date" data-n="m[' . esc_attr($id) . '][date]" value="' . esc_attr($d['date'] ?? '') . '"> <input type="text" data-n="m[' . esc_attr($id) . '][note]" value="' . esc_attr($d['note'] ?? '') . '" placeholder="' . esc_attr('ctam' === $fw ? 'หลักฐาน / เลขที่เอกสาร / ผู้รับผิดชอบ' : 'เหตุผล / หลักฐาน / ข้อยกเว้น') . '" class="idw-in"></div>';
            }
            echo '</div><div class="a">';
            if ($fix) echo '<button type="button" class="idw-btn pri sm" data-ncsa-fix="' . esc_attr($fix) . '">' . idw_icon('wand') . 'แก้ไขให้</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            if ($link) echo '<a class="idw-btn sm" href="' . esc_url($link[1]) . '">' . esc_html($link[0]) . '</a>';
            echo '</div></div>';
        }
        echo '</details>';
    }
    echo '<p class="fw-save"><button class="idw-btn pri">' . idw_icon('check') . 'บันทึกการประเมิน</button> <span class="d" id="fw-dirty"></span></p></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<form id="ncsa-fix" method="post" action="' . esc_url(admin_url('admin-post.php')) . '" hidden>' . wp_nonce_field('idw_sec_fix', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_sec_fix"><input type="hidden" name="fix" value=""><input type="hidden" name="back" value="' . esc_attr($fw) . '"></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    // inputs get their name only when changed, so a long list never exceeds max_input_vars
    echo '<script>(function(){var f=document.getElementById("fwf"),n=0,dirty=document.getElementById("fw-dirty");f.addEventListener("change",function(e){var r=e.target.closest(".ncsa-row");if(!r)return;r.querySelectorAll("[data-n]").forEach(function(x){if(!x.name){x.name=x.dataset.n;}});n=f.querySelectorAll(".ncsa-row [name]").length/3;dirty.textContent="แก้ไข "+Math.round(n)+" ข้อ — กดบันทึก";if(e.target.matches("select[data-n]")&&e.target.value&&!r.querySelector("input[type=date]").value){r.querySelector("input[type=date]").value=new Date().toISOString().slice(0,10);}});'
        . 'document.addEventListener("click",function(e){var b=e.target.closest("[data-ncsa-fix]");if(b){var x=document.getElementById("ncsa-fix");x.fix.value=b.dataset.ncsaFix;b.disabled=true;x.submit();return;}var t=e.target.closest(".fw-filter [data-f]");if(!t)return;document.querySelectorAll(".fw-filter [data-f]").forEach(function(y){y.classList.toggle("on",y===t);});var m=t.dataset.f;document.querySelectorAll(".fw .ncsa-row").forEach(function(r){var s=r.dataset.st,show=m==="all"||(m==="todo"&&(s==="bad"||s==="manual"||s==="warn"))||(m==="auto"&&r.dataset.auto==="1");r.style.display=show?"":"none";});if(m!=="all")document.querySelectorAll(".fw details").forEach(function(d){d.open=true;});});window.addEventListener("beforeunload",function(e){if(n&&!f.dataset.sub){e.preventDefault();e.returnValue="";}});f.addEventListener("submit",function(){f.dataset.sub=1;});})();</script>';
    echo '<style>.ncsa-head{display:flex;gap:18px;align-items:center;flex-wrap:wrap}.ncsa-head .ring{width:86px;height:86px;border-radius:50%;display:grid;place-items:center;background:conic-gradient(#0a7d55 calc(var(--p)*1%),#e3e8ef 0);flex:none}.ncsa-head .ring b{background:#fff;width:66px;height:66px;border-radius:50%;display:grid;place-items:center;font-size:18px}.ncsa-head>div:nth-child(2){flex:1;min-width:260px}.ncsa-acts{display:flex;gap:8px;flex-wrap:wrap}'
        . '.fw details>summary{cursor:pointer;display:flex;gap:12px;align-items:baseline;flex-wrap:wrap;list-style:none}.fw details>summary::-webkit-details-marker{display:none}.fw details>summary h3{margin:0}.fw details>summary:before{content:"▸";color:#646970}.fw details[open]>summary:before{content:"▾"}.fw details>summary+.ncsa-row{margin-top:8px}'
        . '.ncsa-row{display:grid;grid-template-columns:110px 1fr auto;gap:12px;align-items:start;padding:10px 0;border-top:1px solid #eef1f5}.ncsa-row .t b{display:block}.ncsa-row .t .req{display:block;font-size:13px;line-height:1.5;margin-top:2px}.ncsa-row .t .lv{font:600 11px/1 system-ui;background:#eef3f8;color:#2b4c8c;border-radius:4px;padding:2px 5px;margin-left:4px}.ncsa-row .t small{display:block;color:#646970;margin-top:3px}.ncsa-row .t small.how{color:#2271b1}.ncsa-row .a{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}.ncsa-row .mi{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:6px}.ncsa-row .mi .idw-in[type=text]{flex:1;min-width:200px}.ncsa-row .idw-chip{justify-self:start}'
        . '.fw-bar{display:flex;gap:12px;align-items:center;flex-wrap:wrap;justify-content:space-between}.fw-filter{display:flex;gap:6px;flex-wrap:wrap}.fw-filter .on{background:#1d2327;color:#fff;border-color:#1d2327}.fw-save{position:sticky;bottom:0;background:#f0f0f1;padding:10px 0;margin:0;z-index:5}'
        . '@media(max-width:782px){.ncsa-row{grid-template-columns:1fr}.ncsa-row .a{justify-content:flex-start}}'
        . '@media print{#adminmenumain,#wpadminbar,.idw-subtabs,.idw-head,.ncsa-acts,.ncsa-row .a,.idw-btn,#wpfooter,.notice,.fw-bar,.fw-save{display:none!important}#wpcontent{margin:0!important}.idw-card{box-shadow:none!important;border:1px solid #ccc!important}.ncsa-row{grid-template-columns:90px 1fr;break-inside:avoid}.fw details>summary:before{content:""}body:before{content:"' . esc_js($print . ' — ' . wp_parse_url(home_url(), PHP_URL_HOST) . ' — ' . wp_date('j M Y')) . '";display:block;font:700 16px sans-serif;margin:0 0 10px}}</style>';
    // print: open every section
    echo '<script>window.addEventListener("beforeprint",function(){document.querySelectorAll(".fw details").forEach(function(d){d.open=true;});});</script>';
}
