<?php
/**
 * ช่องโหว่ร้ายแรงของ PHP เอง (ไม่ใช่ WordPress / ปลั๊กอิน) — ตรวจกับเซิร์ฟเวอร์จริง:
 * - เทียบ PHP_VERSION กับรุ่นที่แก้แล้วของแต่ละสาย (8.2 / 8.3 / ...)
 * - ช่องโหว่ที่ขึ้นกับการตั้งค่า (เช่น session.upload_progress) อ่านค่าจริงด้วย ini_get และค้นโค้ดในปลั๊กอิน / ธีม
 * รายการในตัว + รายการเพิ่มจากไฟล์อัปเดต (updates/website.json → php_cves) จึงเพิ่ม CVE ใหม่ได้โดยไม่ต้องออกปลั๊กอินรุ่นใหม่
 */
defined('ABSPATH') || exit;

function idw_sec_php_cve_db() {
    $db = [
        'php2shell' => ['cves' => ['CVE-2026-109618', 'CVE-2026-109619'], 'name' => 'PHP2Shell — รันคำสั่งบนเซิร์ฟเวอร์จากระยะไกล (RCE)', 'cvss' => '9.2', 'sev' => 'critical', 'date' => '2026-10-21', 'exploited' => 1,
            'fixed' => ['8.2' => '8.2.35', '8.3' => '8.3.36', '8.4' => '8.4.27', '8.5' => '8.5.12'], 'cond' => ''],
        'sess-upload' => ['cves' => ['CVE-2026-115560'], 'name' => 'RCE ผ่าน session upload progress ร่วมกับการเปลี่ยน session.serialize_handler', 'cvss' => '', 'sev' => 'high', 'date' => '2026-10-23', 'exploited' => 0,
            'fixed' => [], 'cond' => 'session_upload'],
    ];
    // more entries (or corrections) from the update feed
    $feed = function_exists('idw_manifest') ? (array) (idw_manifest()['php_cves'] ?? []) : [];
    foreach ($feed as $k => $v) {
        if (!is_array($v) || !preg_match('/^[a-z0-9-]{2,40}$/', (string) $k)) continue;
        $cves = array_values(array_filter((array) ($v['cves'] ?? []), function ($c) { return preg_match('/^CVE-\d{4}-\d{4,7}$/', (string) $c); }));
        if (!$cves) continue;
        $fixed = [];
        foreach ((array) ($v['fixed'] ?? []) as $br => $ver) if (preg_match('/^\d+\.\d+$/', (string) $br) && preg_match('/^\d+\.\d+\.\d+$/', (string) $ver)) $fixed[$br] = $ver;
        $db[$k] = ['cves' => $cves, 'name' => sanitize_text_field($v['name'] ?? $cves[0]), 'cvss' => preg_replace('/[^0-9.]/', '', (string) ($v['cvss'] ?? '')), 'sev' => in_array($v['sev'] ?? '', ['critical', 'high', 'medium', 'low'], true) ? $v['sev'] : 'high',
            'date' => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($v['date'] ?? '')) ? $v['date'] : '', 'exploited' => !empty($v['exploited']) ? 1 : 0, 'fixed' => $fixed, 'cond' => in_array($v['cond'] ?? '', ['', 'session_upload'], true) ? (string) ($v['cond'] ?? '') : ''];
    }
    return $db;
}

/**
 * PHP from a Linux distribution (Ubuntu / Debian / RHEL…) gets security fixes without changing the version number
 * (Ubuntu 24.04 reports "8.3.6" for every patched build). Returns ['name' => distro, 'build' => build timestamp] or [].
 */
function idw_sec_php_distro() {
    $ini = (string) php_ini_loaded_file() . ' ' . (string) php_ini_scanned_files();
    $is = preg_match('#/etc/php/\d+\.\d+/#', $ini) || preg_match('#/etc/php\.(ini|d/)#', $ini) || preg_match('/ubuntu|deb\d|debian|\.el\d/i', PHP_VERSION . PHP_EXTRA_VERSION);
    if (!$is) return [];
    $name = 'Linux distribution';
    if (@is_readable('/etc/os-release') && preg_match('/^PRETTY_NAME="?([^"\n]+)/m', (string) @file_get_contents('/etc/os-release'), $m)) $name = $m[1]; // phpcs:ignore
    ob_start(); phpinfo(INFO_GENERAL); $info = (string) ob_get_clean(); // phpcs:ignore
    $build = preg_match('/Build Date\s*(?:=>|<\/td><td class="v">)\s*([A-Za-z]{3}\s+\d+\s+\d{4}(?:\s+[\d:]+)?)/', $info, $b) ? (int) strtotime($b[1]) : 0;
    return ['name' => $name, 'build' => $build];
}

/** Find code in plugins / themes that changes session.serialize_handler at run time (cached 12 h). */
function idw_sec_php_serialize_code($fresh = false) {
    $c = get_transient('idw_sec_ser_code');
    if (!$fresh && is_array($c)) return $c;
    $found = []; $n = 0; $t0 = microtime(true);
    foreach ([WP_PLUGIN_DIR, get_theme_root(), WPMU_PLUGIN_DIR] as $root) {
        if (!is_dir($root)) continue;
        try {
            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
            foreach ($it as $f) {
                if (++$n > 40000 || microtime(true) - $t0 > 20) break 2;
                if (!$f->isFile() || strtolower($f->getExtension()) !== 'php' || $f->getSize() > 2000000) continue;
                $s = @file_get_contents($f->getPathname()); // phpcs:ignore
                if ($s !== false && stripos($s, 'serialize_handler') !== false && preg_match('/ini_set\s*\(\s*[\'"]session\.serialize_handler/i', $s)) $found[] = str_replace(WP_CONTENT_DIR, 'wp-content', $f->getPathname());
            }
        } catch (Exception $e) { continue; } // phpcs:ignore
    }
    $c = ['files' => array_slice($found, 0, 20), 'partial' => $n > 40000 || microtime(true) - $t0 > 20];
    set_transient('idw_sec_ser_code', $c, 12 * HOUR_IN_SECONDS);
    return $c;
}

function idw_sec_php_upload_progress_on() { return in_array(strtolower((string) ini_get('session.upload_progress.enabled')), ['1', 'on', 'true', 'yes'], true); }

/**
 * Findings as scan items (category A03). Each: idw_sec_item + 'cve' => 1, 'vid' => ...
 * $out['state'] summary for other tabs: ['php' => ..., 'patched' => bool|null, 'upload' => bool, 'handler' => ..., 'code' => [...]]
 */
function idw_sec_php_cve_check($fresh = false) {
    $php = PHP_VERSION; $br = PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION; $distro = idw_sec_php_distro();
    $items = []; $bad = 0; $ok = 0;
    foreach (idw_sec_php_cve_db() as $k => $v) {
        $refs = array_map(function ($c) { return [$c . ' (cve.org)', 'https://www.cve.org/CVERecord?id=' . $c]; }, $v['cves']);
        $refs[] = ['PHP security advisories', 'https://github.com/php/php-src/security/advisories'];
        $ids = implode(', ', $v['cves']);
        $title = $ids . ' · ' . $v['name'] . ($v['cvss'] ? ' (CVSS ' . $v['cvss'] . ')' : '');
        $sev = $v['sev'];
        if ('session_upload' === $v['cond']) {
            $up = idw_sec_php_upload_progress_on(); $h = (string) ini_get('session.serialize_handler');
            $code = $up ? idw_sec_php_serialize_code($fresh) : ['files' => [], 'partial' => false];
            $fixed = $v['fixed'][$br] ?? '';
            if ($fixed && version_compare($php, $fixed, '>=')) { $items[] = ['cve' => 1, 'vid' => $k] + idw_sec_item('A03', 'ok', $title . ': PHP ' . $php . ' แก้แล้ว'); $ok++; continue; }
            if (!$up) { $items[] = ['cve' => 1, 'vid' => $k] + idw_sec_item('A03', 'ok', $title . ': ป้องกันแล้ว', 'session.upload_progress.enabled ปิดอยู่ — เงื่อนไขของช่องโหว่ไม่ครบ (ยังไม่มีแพตช์ ให้คงไว้จนกว่าจะอัปเกรด PHP)'); $ok++; continue; }
            $risky = in_array($h, ['php_binary', 'php_serialize'], true);
            $s = ($code['files'] && $risky) ? 'critical' : ($code['files'] || $risky ? 'high' : 'medium');
            $detail = 'ยังไม่มีแพตช์ · session.upload_progress.enabled = เปิด · session.serialize_handler = ' . ($h ?: '-') . ($code['files'] ? ' · พบโค้ดเปลี่ยน serialize_handler: ' . implode(', ', array_slice($code['files'], 0, 4)) : ' · ไม่พบโค้ดในปลั๊กอิน / ธีมที่เปลี่ยน serialize_handler' . ($code['partial'] ? ' (ตรวจได้บางส่วน)' : ''));
            $items[] = ['cve' => 1, 'vid' => $k] + idw_sec_item('A03', $s, $title, esc_html($detail), 'ปิด session.upload_progress.enabled จนกว่าจะมีแพตช์ (WordPress ไม่ได้ใช้ฟีเจอร์นี้) — กด “ปิด session upload progress” ระบบเลือกวิธีให้ตามเซิร์ฟเวอร์ (.htaccess สำหรับ Apache mod_php / LiteSpeed หรือ .user.ini สำหรับ PHP-FPM) · ถ้าใช้ไม่ได้ ให้ผู้ดูแลเซิร์ฟเวอร์ใส่ <code>php_admin_flag[session.upload_progress.enabled] = off</code> ใน pool ของ PHP-FPM แล้ว restart', 'php_upload_progress', null, $refs);
            $bad++;
            continue;
        }
        $fixed = $v['fixed'][$br] ?? '';
        $known = array_keys($v['fixed']);
        $oldest = $known ? min(array_map(function ($b) { return (float) $b; }, $known)) : 0;
        if ($fixed && version_compare($php, $fixed, '>=')) { $items[] = ['cve' => 1, 'vid' => $k] + idw_sec_item('A03', 'ok', $title . ': PHP ' . $php . ' แก้แล้ว'); $ok++; continue; }
        if (!$fixed && $known && (float) $br > max(array_map(function ($b) { return (float) $b; }, $known))) { $items[] = ['cve' => 1, 'vid' => $k] + idw_sec_item('A03', 'ok', $title . ': PHP ' . $php . ' ใหม่กว่ารุ่นที่ได้รับผลกระทบ'); $ok++; continue; }
        if ($fixed && $distro) {
            // distro builds keep the old number after back-porting the fix: the build date is the best hint
            $after = $v['date'] && $distro['build'] && $distro['build'] >= strtotime($v['date']);
            $bd = $distro['build'] ? ' · สร้างเมื่อ ' . wp_date('j M Y', $distro['build']) : '';
            $how = 'ให้ผู้ดูแลเซิร์ฟเวอร์อัปเดตแพ็กเกจ PHP (เช่น <code>sudo apt update && sudo apt upgrade</code>) แล้วตรวจประกาศความปลอดภัยของ ' . esc_html($distro['name']) . ' (เช่น ubuntu.com/security/cves) ว่าแก้ ' . esc_html($ids) . ' แล้ว จากนั้น restart PHP-FPM / Apache · เมื่อยืนยันแล้วติ๊ก “ผ่าน” ในแท็บ CTAM+ ข้อ 6 พร้อมเลขแพ็กเกจ';
            $items[] = ['cve' => 1, 'vid' => $k] + idw_sec_item('A03', $after ? 'medium' : ($v['exploited'] ? 'critical' : $sev), $title . ($after ? ': ตรวจว่าแพ็กเกจของระบบแก้แล้ว' : ''), esc_html('PHP ' . $php . ' จากแพ็กเกจของ ' . $distro['name'] . $bd . ' — แพ็กเกจของระบบปฏิบัติการแก้ช่องโหว่โดยไม่เปลี่ยนเลขเวอร์ชัน (รุ่นที่แก้แล้วของ php.net คือ ' . $fixed . ')' . ($after ? ' · แพ็กเกจสร้างหลังวันประกาศ อาจแก้แล้ว' : ' · แพ็กเกจสร้างก่อนวันประกาศ ' . $v['date'] . ' — ยังไม่ได้แก้') . ($v['exploited'] ? ' · มีการโจมตีจริงแล้ว' : '')), $how, '', null, $refs);
            $bad++; continue;
        }
        $how = $fixed ? 'อัปเกรด PHP เป็น ' . $fixed . ' ขึ้นไป (สาย ' . $br . ') หรือรุ่นใหม่กว่า — ติดต่อผู้ดูแลเซิร์ฟเวอร์ / โฮสติ้ง' : ($oldest && (float) $br < $oldest ? 'PHP ' . $br . ' หมดระยะสนับสนุนและไม่ได้รับแพตช์นี้ — อัปเกรดเป็น PHP 8.3 ขึ้นไปเป็นรุ่นล่าสุดของสาย' : 'ติดตามประกาศของ php.net และอัปเกรดเมื่อมีรุ่นแก้ไข');
        $detail = 'PHP ที่ใช้อยู่: ' . $php . ($fixed ? ' · แก้แล้วใน ' . $fixed : ($oldest && (float) $br < $oldest ? ' · สายนี้ไม่มีรุ่นแก้ไข' : '')) . ($v['exploited'] ? ' · มีการโจมตีจริงแล้ว' : '') . ($v['date'] ? ' · ประกาศ ' . $v['date'] : '');
        $items[] = ['cve' => 1, 'vid' => $k] + idw_sec_item('A03', $v['exploited'] ? 'critical' : $sev, $title, esc_html($detail), esc_html($how), '', null, $refs);
        $bad++;
    }
    return ['items' => $items, 'bad' => $bad, 'ok' => $ok];
}

/* ---------- fix: switch off session.upload_progress for this site ---------- */
function idw_sec_fix_php_upload_progress($sapi = '') {
    $sapi = $sapi ?: PHP_SAPI;
    if (in_array($sapi, ['apache2handler', 'litespeed'], true)) {
        $file = ABSPATH . '.htaccess';
        if (!wp_is_writable(is_file($file) ? $file : ABSPATH)) return new WP_Error('idw_sec', 'เขียน .htaccess ไม่ได้ — ให้ผู้ดูแลเซิร์ฟเวอร์ตั้ง session.upload_progress.enabled = Off');
        $old = is_file($file) ? (string) file_get_contents($file) : ''; // phpcs:ignore
        $old = preg_replace('/\n?# BEGIN iDevApp PHP.*?# END iDevApp PHP\n?/s', "\n", $old);
        $rule = "# BEGIN iDevApp PHP\n<IfModule mod_php.c>\n  php_flag session.upload_progress.enabled off\n</IfModule>\n<IfModule mod_php7.c>\n  php_flag session.upload_progress.enabled off\n</IfModule>\n<IfModule php_module>\n  php_flag session.upload_progress.enabled off\n</IfModule>\n<IfModule LiteSpeed>\n  php_flag session.upload_progress.enabled off\n</IfModule>\n# END iDevApp PHP\n";
        if (file_put_contents($file, rtrim($old) . "\n\n" . $rule) === false) return new WP_Error('idw_sec', 'เขียนไฟล์ไม่สำเร็จ'); // phpcs:ignore
        update_option('idw_sec_php_fix', ['t' => time(), 'how' => 'htaccess'], false);
        return 'ปิด session upload progress แล้ว (.htaccess) — มีผลตั้งแต่คำขอถัดไป กดตรวจใหม่เพื่อยืนยัน';
    }
    if (in_array($sapi, ['fpm-fcgi', 'cgi-fcgi', 'cgi'], true) && ini_get('user_ini.filename')) {
        $file = ABSPATH . ini_get('user_ini.filename');
        if (!wp_is_writable(is_file($file) ? $file : ABSPATH)) return new WP_Error('idw_sec', 'เขียน ' . basename($file) . ' ไม่ได้ — ให้ผู้ดูแลเซิร์ฟเวอร์ตั้ง php_admin_flag[session.upload_progress.enabled] = off');
        $old = is_file($file) ? (string) file_get_contents($file) : ''; // phpcs:ignore
        $old = preg_replace('/\n?; BEGIN iDevApp PHP.*?; END iDevApp PHP\n?/s', "\n", $old);
        if (file_put_contents($file, rtrim($old) . "\n; BEGIN iDevApp PHP\nsession.upload_progress.enabled = 0\n; END iDevApp PHP\n") === false) return new WP_Error('idw_sec', 'เขียนไฟล์ไม่สำเร็จ'); // phpcs:ignore
        update_option('idw_sec_php_fix', ['t' => time(), 'how' => 'user_ini'], false);
        $ttl = (int) ini_get('user_ini.cache_ttl');
        return 'ปิด session upload progress แล้ว (' . basename($file) . ') — PHP อ่านไฟล์นี้ใหม่ภายใน ' . max(1, (int) ceil($ttl / 60)) . ' นาที แล้วกดตรวจใหม่เพื่อยืนยัน';
    }
    return new WP_Error('idw_sec', 'เซิร์ฟเวอร์นี้ (' . $sapi . ') ตั้งจากปลั๊กอินไม่ได้ — ให้ผู้ดูแลเซิร์ฟเวอร์ใส่ php_admin_flag[session.upload_progress.enabled] = off (PHP-FPM pool) หรือ session.upload_progress.enabled = Off ใน php.ini แล้ว restart');
}
