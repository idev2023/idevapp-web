<?php
/**
 * มาตรฐานการรักษาความมั่นคงปลอดภัยสำหรับเว็บไซต์ พ.ศ. 2568 (สกมช. / กมช.) — มีผลบังคับ 16 ก.ย. 2569
 * ส่วนที่ทำได้ในเว็บ: ตรวจอัตโนมัติ + ปุ่มแก้ไข (ออกจากระบบเมื่อไม่ใช้งาน 15 นาที, ระงับบัญชีไม่ใช้ 45 วัน,
 * นโยบายรหัสผ่าน, CAPTCHA, ซ่อนหน้าเข้าสู่ระบบ, ซ่อนข้อมูลเซิร์ฟเวอร์, ตรวจช่องโหว่อัตโนมัติทุก 30 วัน)
 * ส่วนที่เป็นการกำกับดูแล / เอกสาร: รายการตรวจแบบติ๊กว่าทำแล้ว พร้อมวันที่และหมายเหตุ และแบบประเมินตนเอง (ค1) พิมพ์ได้
 */
defined('ABSPATH') || exit;

/* ---------- 6.2 session lock: log out after 15 minutes without use ---------- */
function idw_sec_idle_limit() { return 15 * MINUTE_IN_SECONDS; }
add_action('wp_login', function ($login, $user) { update_user_meta($user->ID, '_idw_last_active', time()); update_user_meta($user->ID, '_idw_last_login', time()); }, 5, 2);
add_action('init', function () {
    if (!idw_sec_on('idle_logout') || !is_user_logged_in()) return;
    $uid = get_current_user_id(); $last = (int) get_user_meta($uid, '_idw_last_active', true); $now = time();
    $hb = wp_doing_ajax() && ($_POST['action'] ?? '') === 'heartbeat'; // phpcs:ignore WordPress.Security.NonceVerification
    if ($last && $now - $last > idw_sec_idle_limit()) {
        idw_sec_log('login', 'ออกจากระบบอัตโนมัติ (ไม่ใช้งานเกิน 15 นาที): ' . wp_get_current_user()->user_login);
        wp_logout();
        if (wp_doing_ajax()) return; // the heartbeat then shows WordPress's own “log in again” box
        wp_safe_redirect(add_query_arg(['idw_idle' => 1, 'redirect_to' => rawurlencode(home_url(add_query_arg([])))], wp_login_url())); exit;
    }
    if (!$hb && $now - $last > 30) update_user_meta($uid, '_idw_last_active', $now);
}, 1);
add_action('wp_ajax_idw_alive', function () { update_user_meta(get_current_user_id(), '_idw_last_active', time()); wp_send_json_success(); });
function idw_sec_idle_script() {
    if (!idw_sec_on('idle_logout') || !is_user_logged_in()) return;
    ?>
    <script>(function(){var act=Date.now(),sent=Date.now(),LIM=<?php echo (int) idw_sec_idle_limit(); ?>*1000,AJ=<?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;
    ['mousemove','keydown','scroll','touchstart','click'].forEach(function(e){addEventListener(e,function(){act=Date.now();},{passive:true});});
    setInterval(function(){var now=Date.now();if(act>sent&&now-sent>60000){sent=now;var f=new FormData();f.append('action','idw_alive');fetch(AJ,{method:'POST',body:f,credentials:'same-origin'});}
    if(now-act>LIM){location.href=<?php echo wp_json_encode(add_query_arg('idw_idle', 1, wp_login_url())); ?>;}},20000);})();</script>
    <?php
}
add_action('admin_footer', 'idw_sec_idle_script');
add_action('wp_footer', 'idw_sec_idle_script');

/* ---------- 6.2 suspend accounts not used for 45 days ---------- */
function idw_sec_inactive_days() { return 45; }
function idw_sec_inactive($uid) {
    $l = (int) get_user_meta($uid, '_idw_last_login', true);
    return $l && time() - $l > idw_sec_inactive_days() * DAY_IN_SECONDS ? (int) floor((time() - $l) / DAY_IN_SECONDS) : 0;
}
add_filter('authenticate', function ($user) {
    if (!idw_sec_on('inactive_lock') || !($user instanceof WP_User)) return $user;
    if (!get_user_meta($user->ID, '_idw_last_login', true)) { update_user_meta($user->ID, '_idw_last_login', time()); return $user; } // counted from when the setting was switched on
    $days = idw_sec_inactive($user->ID);
    if (!$days) return $user;
    if (user_can($user, 'manage_options')) { // never lock out the last administrator who can unlock the others
        $others = array_filter(get_users(['role' => 'administrator', 'exclude' => [$user->ID], 'fields' => 'ID']), function ($id) { return !idw_sec_inactive($id); });
        if (!$others) { idw_sec_log('login', 'ผู้ดูแลระบบคนเดียวที่เหลือ ไม่ได้ใช้งาน ' . $days . ' วัน — อนุญาตให้เข้า: ' . $user->user_login); return $user; }
    }
    idw_sec_log('login_failed', 'บัญชีถูกระงับ (ไม่ได้ใช้งาน ' . $days . ' วัน): ' . $user->user_login);
    return new WP_Error('idw_inactive', 'บัญชีนี้ถูกระงับเพราะไม่ได้เข้าสู่ระบบเกิน ' . idw_sec_inactive_days() . ' วัน (มาตรฐานความปลอดภัยเว็บไซต์) — ติดต่อผู้ดูแลระบบเพื่อเปิดใช้อีกครั้ง');
}, 40);
add_filter('manage_users_columns', function ($c) { if (idw_sec_on('inactive_lock')) $c['idw_active'] = 'ใช้งานล่าสุด'; return $c; });
add_filter('manage_users_custom_column', function ($v, $col, $uid) {
    if ('idw_active' !== $col) return $v;
    $l = (int) get_user_meta($uid, '_idw_last_login', true);
    if (!$l) return '—';
    $d = idw_sec_inactive($uid);
    if (!$d) return esc_html(human_time_diff($l) . 'ที่แล้ว');
    return '<b style="color:#b32d2e">ระงับ</b> (ไม่ใช้ ' . (int) $d . ' วัน) · <a href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=idw_sec_unlock&u=' . (int) $uid), 'idw_sec_unlock_' . $uid)) . '">ปลดระงับ</a>';
}, 10, 3);
add_action('admin_post_idw_sec_unlock', function () {
    $uid = absint($_GET['u'] ?? 0);
    if (!current_user_can('edit_users') || !check_admin_referer('idw_sec_unlock_' . $uid)) wp_die('ไม่มีสิทธิ์', 403);
    update_user_meta($uid, '_idw_last_login', time());
    $u = get_userdata($uid); idw_sec_log('user', 'ปลดระงับบัญชี: ' . ($u ? $u->user_login : '#' . $uid));
    wp_safe_redirect(admin_url('users.php')); exit;
});

/* ---------- 6.2 passwords (NIST SP 800-63B): at least 8, long ones allowed, not one of the last 5, not a leaked password ---------- */
function idw_sec_pw_problem($pass, $uid = 0) {
    if (!idw_sec_on('pw_policy') || '' === (string) $pass) return '';
    if (mb_strlen($pass) < 8) return 'รหัสผ่านต้องยาวอย่างน้อย 8 ตัวอักษร (ยาวได้ถึง 64 ตัวขึ้นไป แนะนำเป็นวลีที่จำง่าย)';
    if ($uid) {
        $hist = (array) get_user_meta($uid, '_idw_pw_hist', true);
        $u = get_userdata($uid); if ($u) array_unshift($hist, $u->user_pass);
        foreach (array_slice(array_filter($hist), 0, 5) as $h) if (wp_check_password($pass, $h, $uid)) return 'ห้ามใช้รหัสผ่านซ้ำกับ 5 ครั้งล่าสุด';
    }
    $sha = strtoupper(sha1($pass));
    $r = wp_remote_get('https://api.pwnedpasswords.com/range/' . substr($sha, 0, 5), ['timeout' => 4, 'headers' => ['Add-Padding' => 'true']]);
    if (!is_wp_error($r) && 200 === wp_remote_retrieve_response_code($r) && preg_match('/^' . substr($sha, 5) . ':(\d+)/m', wp_remote_retrieve_body($r), $m) && (int) $m[1] > 0) return 'รหัสผ่านนี้อยู่ในรายการรหัสผ่านที่รั่วไหลบนอินเทอร์เน็ต — เลือกรหัสผ่านอื่น';
    return '';
}
add_action('user_profile_update_errors', function ($errors, $update, $user) {
    if (empty($user->user_pass)) return;
    $p = idw_sec_pw_problem($user->user_pass, $update ? (int) $user->ID : 0);
    if ($p) $errors->add('idw_pw', $p);
}, 10, 3);
/* ASVS V6.2.3: changing your own password asks for the current one (the e-mailed reset link is unchanged) */
add_action('show_user_profile', function ($user) {
    if (!idw_sec_on('pw_policy')) return;
    echo '<table class="form-table" role="presentation" id="idw-curpass"><tr><th><label for="idw_cur_pass">รหัสผ่านปัจจุบัน</label></th><td><input type="password" name="idw_cur_pass" id="idw_cur_pass" class="regular-text" autocomplete="current-password"><p class="description">ต้องใส่เมื่อเปลี่ยนรหัสผ่านใหม่ (นโยบายรหัสผ่านตามมาตรฐาน) — ถ้าลืม ใช้ “ลืมรหัสผ่าน” ที่หน้าเข้าสู่ระบบ</p></td></tr></table>'
        . '<script>(function(){var t=document.getElementById("idw-curpass"),r=document.querySelector("tr.user-pass1-wrap, #password");if(t&&r&&r.closest("table")){r.closest("table").after(t);}})();</script>';
}, 1);
add_action('user_profile_update_errors', function ($errors, $update, $user) {
    if (!idw_sec_on('pw_policy') || !$update || !defined('IS_PROFILE_PAGE') || !IS_PROFILE_PAGE || empty($_POST['pass1'])) return; // phpcs:ignore
    $me = get_userdata((int) $user->ID);
    if (!$me || !wp_check_password(wp_unslash((string) ($_POST['idw_cur_pass'] ?? '')), $me->user_pass, $me->ID)) $errors->add('idw_curpass', 'ใส่รหัสผ่านปัจจุบันให้ถูกต้องก่อนเปลี่ยนรหัสผ่านใหม่'); // phpcs:ignore
}, 5, 3);
add_action('validate_password_reset', function ($errors, $user) {
    if (!empty($_POST['pass1']) && $user instanceof WP_User) { $p = idw_sec_pw_problem(wp_unslash($_POST['pass1']), $user->ID); if ($p) $errors->add('idw_pw', $p); } // phpcs:ignore
}, 10, 2);
function idw_sec_pw_remember($uid, $old_hash) {
    if (!$old_hash) return;
    $hist = array_filter((array) get_user_meta($uid, '_idw_pw_hist', true));
    array_unshift($hist, $old_hash);
    update_user_meta($uid, '_idw_pw_hist', array_slice(array_values(array_unique($hist)), 0, 5));
}
add_action('profile_update', function ($uid, $old) { $u = get_userdata($uid); if ($u && $old && $old->user_pass !== $u->user_pass) idw_sec_pw_remember($uid, $old->user_pass); }, 10, 2);
add_action('password_reset', function ($user) { idw_sec_pw_remember($user->ID, $user->user_pass); });

/* ---------- 6.2 CAPTCHA after 2 failed logins from the same address ---------- */
function idw_sec_cap_key() { return 'idw_sec_c_' . md5(idw_sec_ip() . wp_salt('auth')); }
function idw_sec_cap_needed() { return idw_sec_on('login_captcha') && (int) get_transient(idw_sec_cap_key()) >= 2; }
add_action('wp_login_failed', function () { if (idw_sec_on('login_captcha')) set_transient(idw_sec_cap_key(), (int) get_transient(idw_sec_cap_key()) + 1, HOUR_IN_SECONDS); });
add_action('wp_login', function () { delete_transient(idw_sec_cap_key()); });
add_action('login_form', function () {
    if (!idw_sec_cap_needed()) return;
    $a = wp_rand(2, 9); $b = wp_rand(1, 9); $tok = wp_generate_password(20, false);
    set_transient('idw_sec_q_' . $tok, wp_hash((string) ($a + $b)), 15 * MINUTE_IN_SECONDS);
    echo '<p><label for="idw_cap">ยืนยันว่าไม่ใช่โปรแกรมอัตโนมัติ: <b>' . (int) $a . ' + ' . (int) $b . ' = ?</b></label><input type="text" name="idw_cap" id="idw_cap" class="input" inputmode="numeric" autocomplete="off" required><input type="hidden" name="idw_cap_t" value="' . esc_attr($tok) . '"></p>';
});
add_filter('authenticate', function ($user, $username) {
    if (empty($username) || !idw_sec_cap_needed() || 'POST' !== ($_SERVER['REQUEST_METHOD'] ?? '') || (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST)) return $user;
    $tok = sanitize_key($_POST['idw_cap_t'] ?? ''); $h = $tok ? get_transient('idw_sec_q_' . $tok) : ''; // phpcs:ignore WordPress.Security.NonceVerification
    if ($tok) delete_transient('idw_sec_q_' . $tok);
    if (!$h || !hash_equals($h, wp_hash(trim((string) ($_POST['idw_cap'] ?? ''))))) return new WP_Error('idw_cap', 'คำตอบยืนยันว่าไม่ใช่โปรแกรมอัตโนมัติไม่ถูกต้อง'); // phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput
    return $user;
}, 25, 2);
add_filter('wp_login_errors', function ($e) { if (isset($_GET['idw_idle'])) $e->add('idw_idle', 'ออกจากระบบอัตโนมัติแล้ว เพราะไม่ได้ใช้งานเกิน 15 นาที — กรุณาเข้าสู่ระบบอีกครั้ง', 'message'); return $e; }); // phpcs:ignore WordPress.Security.NonceVerification

/* ---------- 6.2 hide the login page: only <site>/<slug> opens it ---------- */
function idw_sec_login_slug() { $s = sanitize_title((string) get_option('idw_sec_login_slug', '')); return $s ?: 'staff-login'; }
function idw_sec_hide_login() { return idw_sec_on('hide_login') && !(defined('IDW_LOGIN_SLUG_OFF') && IDW_LOGIN_SLUG_OFF); }
function idw_sec_lg_token() { return substr(wp_hash('idw_lg|' . idw_sec_login_slug()), 0, 24); }
function idw_sec_lg_ok() { return isset($_COOKIE['idw_lg']) && hash_equals(idw_sec_lg_token(), (string) $_COOKIE['idw_lg']); }
add_action('init', function () {
    if (!idw_sec_hide_login()) return;
    $path = trim((string) wp_parse_url(rawurldecode((string) ($_SERVER['REQUEST_URI'] ?? '')), PHP_URL_PATH), '/');
    $home = trim((string) wp_parse_url(home_url(), PHP_URL_PATH), '/');
    if ($home && strpos($path, $home) === 0) $path = trim(substr($path, strlen($home)), '/');
    if ($path !== idw_sec_login_slug()) return;
    setcookie('idw_lg', idw_sec_lg_token(), ['expires' => time() + 30 * DAY_IN_SECONDS, 'path' => COOKIEPATH ?: '/', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax']);
    $q = (string) wp_parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_QUERY);
    wp_safe_redirect(site_url('wp-login.php' . ($q ? '?' . $q : ''), 'login')); exit;
}, 0);
function idw_sec_404() { status_header(404); nocache_headers(); $t = get_404_template(); if ($t) { global $wp_query; $wp_query->set_404(); include $t; } else echo '<h1>404</h1>'; exit; }
add_action('login_init', function () {
    if (!idw_sec_hide_login() || is_user_logged_in() || idw_sec_lg_ok()) return;
    $a = sanitize_key($_REQUEST['action'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification
    if (in_array($a, ['logout', 'postpass', 'rp', 'resetpass', 'confirmaction', 'idw_2fa'], true)) return; // links sent by e-mail and the 2FA step keep working
    idw_sec_404();
}, 0);
add_filter('login_url', function ($url, $redirect) {
    if (!idw_sec_hide_login()) return $url;
    if (is_admin() && !is_user_logged_in() && !wp_doing_ajax() && !idw_sec_lg_ok()) idw_sec_404(); // /wp-admin does not point to the login page
    return add_query_arg($redirect ? ['redirect_to' => rawurlencode($redirect)] : [], home_url('/' . idw_sec_login_slug() . '/'));
}, 99, 2);
add_filter('logout_redirect', function ($to) { return idw_sec_hide_login() ? home_url('/') : $to; }, 99);

/* ---------- 6.2 hide server details ---------- */
add_action('send_headers', function () { if (idw_sec_on('hide_server') && function_exists('header_remove')) { header_remove('X-Powered-By'); header_remove('X-Pingback'); } }, 99);
add_action('init', function () { if (idw_sec_on('hide_server') && function_exists('header_remove')) header_remove('X-Powered-By'); }, 1);
add_filter('x_redirect_by', function ($v) { return idw_sec_on('hide_server') ? false : $v; });

/* ---------- 6.1 vulnerability scan at least every 90 days: automatic every 30 days ---------- */
add_filter('cron_schedules', function ($s) { $s['idw_30d'] = ['interval' => 30 * DAY_IN_SECONDS, 'display' => 'ทุก 30 วัน']; return $s; });
add_action('init', function () {
    $next = wp_next_scheduled('idw_sec_auto_scan');
    if (idw_sec_on('auto_scan') && !$next) wp_schedule_event(time() + HOUR_IN_SECONDS, 'idw_30d', 'idw_sec_auto_scan');
    if (!idw_sec_on('auto_scan') && $next) wp_unschedule_event($next, 'idw_sec_auto_scan');
});
add_action('idw_sec_auto_scan', function () {
    require_once dirname(__DIR__) . '/includes/scan.php';
    $rep = idw_sec_run_scan();
    update_option('idw_sec_report', $rep, false);
    idw_sec_log('scan', 'ตรวจช่องโหว่อัตโนมัติ (ทุก 30 วัน) คะแนน ' . $rep['score']);
    $bad = array_filter($rep['items'], function ($i) { return in_array($i['sev'], ['critical', 'high'], true); });
    if ($bad) wp_mail(get_option('admin_email'), '[' . wp_specialchars_decode(get_bloginfo('name')) . '] ผลตรวจความปลอดภัยรายเดือน: พบ ' . count($bad) . ' รายการความเสี่ยงสูง', "คะแนน " . $rep['score'] . "/100\n\n" . implode("\n", array_map(function ($i) { return '- ' . wp_strip_all_tags($i['title']); }, $bad)) . "\n\nดูรายละเอียดและปุ่มแก้ไข: " . admin_url('admin.php?page=idw-security'));
});

/* ---------- checks for the standard ---------- */
function idw_sec_ncsa_manual() { $m = get_option('idw_sec_ncsa', []); return wp_parse_args(is_array($m) ? $m : [], ['impact' => 'medium', 'items' => []]); }

/** HTTPS probes: does http:// send visitors to https://, and which TLS versions does the server accept? */
function idw_sec_ncsa_tls($host) {
    if (!function_exists('stream_socket_client') || !defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) return null;
    $try = function ($m) use ($host) {
        $ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'SNI_enabled' => true, 'peer_name' => $host, 'crypto_method' => $m]]);
        $s = @stream_socket_client('ssl://' . $host . ':443', $no, $er, 5, STREAM_CLIENT_CONNECT, $ctx); // phpcs:ignore
        if ($s) { fclose($s); return true; } return false;
    };
    return ['1.3' => defined('STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT') ? $try(STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT) : null, '1.2' => $try(STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT), '1.1' => $try(STREAM_CRYPTO_METHOD_TLSv1_1_CLIENT), '1.0' => $try(STREAM_CRYPTO_METHOD_TLSv1_0_CLIENT)];
}
function idw_sec_ncsa_dnssec($host) {
    $labels = explode('.', $host);
    for ($i = 0; $i < count($labels) - 1; $i++) {
        $name = implode('.', array_slice($labels, $i));
        $r = wp_remote_get('https://dns.google/resolve?name=' . rawurlencode($name) . '&type=DS', ['timeout' => 5]);
        if (is_wp_error($r)) return null;
        $j = json_decode(wp_remote_retrieve_body($r), true);
        if (!empty($j['Answer'])) return true;
        if (!empty($j['Authority']) && ($j['Authority'][0]['type'] ?? 0) === 6 && ($j['Authority'][0]['name'] ?? '') === $name . '.') return false; // reached the zone: no DS
    }
    return false;
}

/** [section => [title, [ [id, title, status ok|warn|bad|manual, detail, fix-key, link, how] ]]] */
function idw_sec_ncsa_items($fresh = false) {
    $cache = get_transient('idw_sec_ncsa_auto');
    if (!$fresh && is_array($cache)) $auto = $cache;
    else {
        require_once dirname(__DIR__) . '/includes/scan.php';
        $host = (string) wp_parse_url(home_url(), PHP_URL_HOST);
        $http = idw_sec_probe('http://' . $host . '/');
        $home = idw_sec_probe(add_query_arg('idw_v', wp_rand(1000, 9999), home_url('/')));
        $hd = $home ? array_change_key_case((array) (is_object($home['headers']) ? $home['headers']->getAll() : $home['headers'])) : [];
        $auto = ['https' => 0 === strpos(home_url(), 'https://'), 'redirect' => $http ? (in_array($http['code'], [301, 302, 307, 308], true) && 0 === stripos((string) ($http['headers']['location'] ?? ''), 'https://')) : null,
            'tls' => 0 === strpos(home_url(), 'https://') ? idw_sec_ncsa_tls($host) : null, 'dnssec' => idw_sec_ncsa_dnssec($host),
            'powered' => $home ? (isset($hd['x-powered-by']) ? (string) (is_array($hd['x-powered-by']) ? $hd['x-powered-by'][0] : $hd['x-powered-by']) : '') : null,
            'server' => $home ? (string) (is_array($hd['server'] ?? '') ? $hd['server'][0] : ($hd['server'] ?? '')) : '',
            'hsts' => $home ? isset($hd['strict-transport-security']) : null, 'keepalive' => $home ? (string) (is_array($hd['keep-alive'] ?? '') ? $hd['keep-alive'][0] : ($hd['keep-alive'] ?? '')) : '', 't' => time()];
        set_transient('idw_sec_ncsa_auto', $auto, 6 * HOUR_IN_SECONDS);
    }
    $m = idw_sec_ncsa_manual()['items'];
    $manual = function ($id, $title, $how) use ($m) {
        $d = $m[$id] ?? []; $done = !empty($d['done']); $old = $done && !empty($d['date']) && strtotime($d['date']) < strtotime('-1 year');
        return [$id, $title, $done ? ($old ? 'warn' : 'ok') : 'manual', $done ? ('ทำแล้วเมื่อ ' . ($d['date'] ?? '') . ($old ? ' — เกิน 1 ปี ควรทบทวนใหม่' : '') . (!empty($d['note']) ? ' · ' . $d['note'] : '')) : '', '', null, $how, 'manual'];
    };
    $set = function ($id, $title, $key, $how, $okText = '') { $on = idw_sec_on($key); return [$id, $title, $on ? 'ok' : 'bad', $on ? ($okText ?: 'เปิดใช้อยู่') : '', $on ? '' : $key, null, $how]; };
    $rep = get_option('idw_sec_report'); $last = is_array($rep) ? (int) $rep['time'] : 0;
    $no2 = function_exists('idw_2fa_enabled') ? array_filter(get_users(['role' => 'administrator']), function ($u) { return !idw_2fa_enabled($u->ID); }) : [];
    $cms = array_filter(['file_edit' => 'ปิดตัวแก้ไขไฟล์', 'xmlrpc' => 'ปิด XML-RPC', 'users_api' => 'ซ่อนรายชื่อผู้ใช้', 'unfiltered_html' => 'ห้ามใส่สคริปต์', 'risky_uploads' => 'ปิดอัปโหลดไฟล์สคริปต์', 'generator' => 'ซ่อนเวอร์ชัน'], function ($k) { return !idw_sec_on($k); }, ARRAY_FILTER_USE_KEY);
    $upd = 0;
    if (function_exists('get_plugin_updates') || (require_once ABSPATH . 'wp-admin/includes/update.php')) { $upd = count((array) get_plugin_updates()) + count((array) get_theme_updates()); $core = get_core_updates(); if (is_array($core) && isset($core[0]->response) && 'upgrade' === $core[0]->response) $upd++; }
    $backup = array_filter(['updraftplus/updraftplus.php', 'backwpup/backwpup.php', 'all-in-one-wp-migration/all-in-one-wp-migration.php', 'duplicator/duplicator.php', 'blogvault-real-time-backup/blogvault.php', 'jetpack/jetpack.php', 'wpvivid-backuprestore/wpvivid-backuprestore.php'], 'is_plugin_active');
    $tls = $auto['tls'];
    $tlsSt = null === $tls ? 'manual' : (($tls['1.0'] || $tls['1.1']) ? 'warn' : ($tls['1.3'] || null === $tls['1.3'] ? 'ok' : 'warn'));
    $tlsTx = null === $tls ? 'ตรวจจากเซิร์ฟเวอร์นี้ไม่ได้' : 'รองรับ: ' . implode(', ', array_keys(array_filter($tls))) . (($tls['1.0'] || $tls['1.1']) ? ' — ยังเปิด TLS 1.0 / 1.1 ที่เลิกใช้แล้ว' : '') . (false === $tls['1.3'] ? ' — ยังไม่รองรับ TLS 1.3' : '');
    $ka = preg_match('/timeout=(\d+)/', $auto['keepalive'], $mm) ? (int) $mm[1] : null;
    return [
        '6.1' => ['Identify — ระบุความเสี่ยง', [
            ['6.1-va', 'ประเมินช่องโหว่ (VA) อย่างน้อยทุก 90 วัน', $last && $last > time() - 90 * DAY_IN_SECONDS ? 'ok' : 'bad', $last ? 'ตรวจล่าสุด ' . idw_dt($last) . (idw_sec_on('auto_scan') ? ' · ตรวจอัตโนมัติทุก 30 วัน' : '') : 'ยังไม่เคยตรวจ', idw_sec_on('auto_scan') ? '' : 'auto_scan', ['ผลการตรวจ', admin_url('admin.php?page=idw-security')], 'เปิดการตรวจอัตโนมัติทุก 30 วัน (มาตรฐานแนะนำทุก 30 วัน ไม่เกิน 90 วัน) — ส่งอีเมลเมื่อพบความเสี่ยงสูง'],
            $manual('6.1-pt', 'ทดสอบเจาะระบบ (Penetration Test) โดยผู้ทดสอบที่มีใบรับรอง (เช่น OSCP, OSWE, GPEN, GWAPT)', 'จ้างผู้ให้บริการ VA/PT ที่ได้รับการรับรอง (5.6.6) อย่างน้อยปีละครั้ง หรือเมื่อเปลี่ยนแปลงระบบสำคัญ'),
            $manual('6.1-asset', 'ทะเบียนทรัพย์สิน (เว็บไซต์ เซิร์ฟเวอร์ ฐานข้อมูล โดเมน ใบรับรอง) พร้อมเจ้าของและระดับความสำคัญ', 'จัดทำรายการทรัพย์สินทั้งหมดของเว็บไซต์ ผู้รับผิดชอบ และความสัมพันธ์ระหว่างกัน'),
            $manual('6.1-risk', 'ประเมินความเสี่ยงอย่างน้อยปีละ 1 ครั้ง และบันทึกในทะเบียนความเสี่ยง (Risk Register)', 'ทำเมื่อครบปี หรือเมื่อมีการเปลี่ยนแปลงสำคัญ (5.3, 6.1)'),
            $manual('6.1-vendor', 'บริหารความเสี่ยงผู้ให้บริการภายนอก (ผู้พัฒนา โฮสติ้ง)', 'มีสัญญา / ข้อตกลงด้านความปลอดภัย และทบทวนผู้ให้บริการ'),
        ]],
        '6.2a' => ['Protect — การเข้ารหัสและเซิร์ฟเวอร์', [
            ['6.2-https', 'ใช้ HTTPS ทั้งเว็บ และพาผู้เข้า http:// ไป https:// อัตโนมัติ', $auto['https'] && false !== $auto['redirect'] ? 'ok' : 'bad', $auto['https'] ? (false === $auto['redirect'] ? 'เว็บใช้ HTTPS แต่ http:// ยังไม่ redirect' : 'ใช้ HTTPS และ redirect แล้ว') : 'เว็บยังใช้ http://', '', ['ไปหน้า SSL / HTTPS', admin_url('admin.php?page=idw-ssl')], 'ติดตั้งใบรับรองและกด “เปลี่ยนเว็บเป็น HTTPS” (เลือก “บังคับใช้ HTTPS”)'],
            ['6.2-tls', 'TLS 1.2 / 1.3 เท่านั้น (ปิด SSL, TLS 1.0 / 1.1) เข้ารหัส AES / ChaCha20 และ Forward Secrecy', $tlsSt, $tlsTx, '', null, 'ตั้งค่าที่เว็บเซิร์ฟเวอร์ / โฮสติ้ง: Apache <code>SSLProtocol -all +TLSv1.2 +TLSv1.3</code> · Nginx <code>ssl_protocols TLSv1.2 TLSv1.3;</code>'],
            ['6.2-hsts', 'HSTS และส่วนหัวความปลอดภัย (HTTP Security Headers)', idw_sec_on('headers') || $auto['hsts'] ? 'ok' : 'bad', $auto['hsts'] ? 'พบ HSTS' : (idw_sec_on('headers') ? 'เปิดแล้ว (HSTS ส่งเมื่อใช้ HTTPS)' : ''), idw_sec_on('headers') ? '' : 'headers', null, 'เปิด “ส่วนหัวความปลอดภัย”'],
            ['6.2-ver', 'ปกปิดเวอร์ชันซอฟต์แวร์ (WordPress, PHP, เว็บเซิร์ฟเวอร์)', (idw_sec_on('generator') && idw_sec_on('hide_server') && !$auto['powered']) ? (preg_match('/\d/', $auto['server']) ? 'warn' : 'ok') : 'bad', trim(($auto['powered'] ? 'X-Powered-By: ' . $auto['powered'] . ' · ' : '') . ($auto['server'] ? 'Server: ' . $auto['server'] : ''), ' ·') ?: 'ไม่พบข้อมูลเวอร์ชันในส่วนหัว', !idw_sec_on('hide_server') ? 'hide_server' : (!idw_sec_on('generator') ? 'generator' : ''), null, 'เปิด “ซ่อนข้อมูลเซิร์ฟเวอร์” และ “ซ่อนเวอร์ชัน WordPress” · เวอร์ชันใน Server: ปิดที่เว็บเซิร์ฟเวอร์ (Apache <code>ServerTokens Prod</code>, Nginx <code>server_tokens off;</code>)'],
            ['6.2-ka', 'Keep-Alive timeout ต่ำกว่า 10 วินาที (ลดผลกระทบ DoS)', null === $ka ? 'manual' : ($ka < 10 ? 'ok' : 'warn'), null === $ka ? 'เซิร์ฟเวอร์ไม่บอกค่า — ตรวจที่การตั้งค่าเว็บเซิร์ฟเวอร์' : 'timeout=' . $ka . ' วินาที', '', null, 'Apache <code>KeepAliveTimeout 5</code> · Nginx <code>keepalive_timeout 5;</code>'],
            ['6.2-dnssec', 'โดเมนใช้ DNSSEC', null === $auto['dnssec'] ? 'manual' : ($auto['dnssec'] ? 'ok' : 'warn'), null === $auto['dnssec'] ? 'ตรวจจากเซิร์ฟเวอร์นี้ไม่ได้' : ($auto['dnssec'] ? 'พบ DNSSEC' : 'ยังไม่พบ DNSSEC'), '', null, 'เปิด DNSSEC ที่ผู้ให้บริการโดเมน / DNS (โดเมน .go.th ติดต่อ THNIC) และตั้งรหัสผ่านบัญชีโดเมนให้รัดกุม + MFA'],
            ['6.2-upd', 'อัปเดต WordPress ปลั๊กอิน และธีมเป็นเวอร์ชันล่าสุด', $upd ? 'bad' : 'ok', $upd ? 'มีรายการรออัปเดต ' . $upd . ' รายการ' : 'เป็นเวอร์ชันล่าสุดแล้ว', '', ['ไปหน้าอัปเดต', admin_url('update-core.php')], 'อัปเดตสม่ำเสมอ (ปลั๊กอินนี้สำรองและย้อนกลับให้อัตโนมัติถ้าอัปเดตแล้วเว็บพัง)'],
            $manual('6.2-arch', 'สถาปัตยกรรม: Firewall (Deny by default, เปิดเฉพาะ 443) → IDS/IPS → WAF → Web Server · แยกเว็บกับฐานข้อมูล', 'ตรวจกับผู้ดูแลเครือข่าย / โฮสติ้ง · ฐานข้อมูลเปิดเฉพาะ IP ที่จำเป็น ใช้บัญชีสิทธิ์น้อยที่สุด'),
            $manual('6.2-host', 'ผู้ให้บริการโฮสติ้ง: uptime ≥ 99.9% สำรองข้อมูลอัตโนมัติวันละ 1 ครั้ง ISO/IEC 27001 มี WAF / Anti-DDoS / SFTP', 'ตรวจสัญญาและคุณสมบัติของผู้ให้บริการ'),
            $manual('6.2-os', 'Hardening ระบบปฏิบัติการและฐานข้อมูล (NIST SP 800-123 / CIS Benchmark)', 'ผู้ดูแลเซิร์ฟเวอร์ตั้งค่าตาม CIS Benchmark ปิดบริการ / พอร์ตที่ไม่ใช้'),
        ]],
        '6.2b' => ['Protect — การเข้าถึงและบัญชีผู้ใช้', [
            ['6.2-hash', 'เก็บรหัสผ่านแบบเข้ารหัสทางเดียว (Hash)', 'ok', 'WordPress เก็บรหัสผ่านแบบ hash เสมอ', '', null, ''],
            ['6.2-mfa', 'ยืนยันตัวตนหลายปัจจัย (MFA) สำหรับผู้ดูแลระบบ', $no2 ? 'bad' : 'ok', $no2 ? 'ยังไม่ใช้: ' . implode(', ', wp_list_pluck($no2, 'user_login')) : 'ผู้ดูแลทุกคนใช้ 2FA (Google Authenticator)' . (idw_sec_on('2fa_force') ? ' · บังคับใช้' : ''), $no2 && !idw_sec_on('2fa_force') ? '2fa_force' : '', ['ตั้งค่า 2FA ของฉัน', admin_url('profile.php#idw-2fa')], 'แต่ละคนตั้งค่าที่ โปรไฟล์ → ยืนยันตัวตนสองขั้น · หรือบังคับผู้ดูแลทุกคน'],
            $set('6.2-idle', 'ล็อกเซสชัน / ออกจากระบบเมื่อไม่ใช้งานเกิน 15 นาที', 'idle_logout', 'เปิด “ออกจากระบบอัตโนมัติเมื่อไม่ใช้งาน 15 นาที”'),
            ['6.2-lock', 'ล็อกบัญชีเมื่อเดารหัสผ่าน (≥ 15 นาที)', idw_sec_on('login_limit') ? 'ok' : 'bad', idw_sec_on('login_limit') ? 'ผิด 5 ครั้ง พัก 15 นาที' : '', idw_sec_on('login_limit') ? '' : 'login_limit', null, 'เปิด “จำกัดการล็อกอินผิด”'],
            $set('6.2-45d', 'ระงับบัญชีที่ไม่ได้เข้าสู่ระบบเกิน 45 วัน', 'inactive_lock', 'เปิด “ระงับบัญชีที่ไม่ได้ใช้งานเกิน 45 วัน” — ผู้ดูแลปลดระงับได้ที่หน้าผู้ใช้', 'เปิดใช้อยู่ · ปลดระงับได้ที่ ผู้ใช้ → คอลัมน์ “ใช้งานล่าสุด”'),
            $set('6.2-pw', 'รหัสผ่าน: ยาว ≥ 8 (รองรับ ≥ 64) ห้ามซ้ำ 5 ครั้งล่าสุด ตรวจกับรายการรหัสผ่านที่รั่วไหล', 'pw_policy', 'เปิด “นโยบายรหัสผ่านตามมาตรฐาน”'),
            $set('6.2-captcha', 'CAPTCHA กันโปรแกรมเดารหัสผ่าน', 'login_captcha', 'เปิด “ถามยืนยันว่าไม่ใช่โปรแกรมอัตโนมัติ”'),
            ['6.2-login', 'ซ่อนหน้าเข้าสู่ระบบของ CMS', idw_sec_hide_login() ? 'ok' : 'bad', idw_sec_hide_login() ? 'เข้าระบบที่ ' . home_url('/' . idw_sec_login_slug() . '/') : '', idw_sec_hide_login() ? '' : 'hide_login', null, 'เปิด “ซ่อนหน้าเข้าสู่ระบบ” — หน้าเข้าระบบใหม่คือ ' . home_url('/' . idw_sec_login_slug() . '/') . ' (เปลี่ยนชื่อได้ที่แท็บตั้งค่า)'],
            ['6.2-cms', 'CMS Hardening (ไฟล์ สิทธิ์ อัปโหลด XML-RPC รายชื่อผู้ใช้)', $cms ? 'bad' : 'ok', $cms ? 'ยังไม่เปิด: ' . implode(', ', $cms) : 'เปิดครบแล้ว', $cms ? 'ncsa_cms' : '', null, 'กดปุ่มเพื่อเปิดการป้องกัน CMS ที่เหลือทั้งหมดในครั้งเดียว'],
        ]],
        '6.3' => ['Detect — เฝ้าระวังและบันทึก', [
            ['6.3-log', 'บันทึกเหตุการณ์ (Log) เข้าระบบ ล็อกอินผิด เปลี่ยนสิทธิ์ เก็บ 90 วัน (5.6.9)', idw_sec_on('log') ? 'ok' : 'bad', idw_sec_on('log') ? 'บันทึกอยู่ · เก็บ 90 วันล่าสุด' : '', idw_sec_on('log') ? '' : 'log', ['ดูบันทึก', admin_url('admin.php?page=idw-security&tab=log')], 'เปิด “บันทึกเหตุการณ์ความปลอดภัย” · log ของเว็บเซิร์ฟเวอร์ให้โฮสติ้งเก็บตาม พ.ร.บ.คอมพิวเตอร์ (90 วัน)'],
            ['6.3-alert', 'แจ้งเตือนเมื่อพบช่องโหว่ใหม่', idw_sec_cve_opts()['auto'] === '1' && idw_sec_cve_opts()['mail'] === '1' ? 'ok' : 'warn', 'ตรวจ CVE อัตโนมัติ: ' . (idw_sec_cve_opts()['auto'] === '1' ? 'เปิด' : 'ปิด') . ' · อีเมล: ' . (idw_sec_cve_opts()['mail'] === '1' ? 'เปิด' : 'ปิด'), '', ['ตั้งค่า', admin_url('admin.php?page=idw-security&tab=settings')], 'เปิด “ตรวจ CVE ใหม่อัตโนมัติ” และ “อีเมลแจ้ง”'],
            $manual('6.3-review', 'ทบทวนกลไกเฝ้าระวังอย่างน้อยปีละ 1 ครั้ง', 'ทบทวนว่าแจ้งเตือนถึงผู้รับผิดชอบ และมีผู้ตรวจ log สม่ำเสมอ'),
        ]],
        '6.4' => ['Respond — การรับมือเหตุ', [
            $manual('6.4-ir', 'แผนรับมือเหตุการณ์ (Incident Response Plan) และช่องทางแจ้ง สกมช. / ThaiCERT', 'ระบุผู้ติดต่อ ขั้นตอน และช่องทางแจ้งเหตุ'),
            $manual('6.4-crisis', 'แผนการสื่อสารในภาวะวิกฤต (Crisis Communication)', 'ข้อความแจ้งผู้ใช้ / สื่อ เมื่อเว็บถูกโจมตีหรือข้อมูลรั่ว'),
            $manual('6.4-drill', 'ฝึกซ้อมรับมือเหตุอย่างน้อยปีละ 1 ครั้ง', 'เช่น ร่วมการฝึกซ้อมกับ สกมช.'),
        ]],
        '6.5' => ['Recover — การกู้คืน', [
            ['6.5-backup', 'สำรองข้อมูลอัตโนมัติอย่างน้อยวันละ 1 ครั้ง (5.6.8)', $backup ? 'ok' : 'manual', $backup ? 'พบปลั๊กอินสำรองข้อมูล: ' . implode(', ', array_map('dirname', $backup)) : 'ไม่พบปลั๊กอินสำรองข้อมูล — ถ้าโฮสติ้งสำรองให้ ติ๊กว่าทำแล้ว', '', $backup ? null : ['ติดตั้ง UpdraftPlus', admin_url('plugin-install.php?s=updraftplus&tab=search&type=term')], 'ใช้การสำรองของโฮสติ้ง หรือปลั๊กอิน เช่น UpdraftPlus ตั้งให้สำรองทุกวันไปเก็บนอกเซิร์ฟเวอร์ (เช่น Google Drive)'],
            $manual('6.5-bcp', 'แผนความต่อเนื่อง (BCP) กำหนด RTO / RPO', 'กำหนดว่าเว็บต้องกลับมาภายในกี่ชั่วโมง และยอมเสียข้อมูลได้ไม่เกินเท่าไร'),
            $manual('6.5-restore', 'ทดสอบกู้คืนข้อมูลจริงอย่างน้อยปีละ 1 ครั้ง', 'ลองกู้คืนจากไฟล์สำรองบนเว็บทดสอบ'),
        ]],
        '5' => ['Governance — การกำกับดูแล', [
            $manual('5.1', 'ระบุบริบท ภารกิจ ผู้มีส่วนได้ส่วนเสีย กฎหมายที่เกี่ยวข้อง และ RTO', '5.1.1'),
            $manual('5.2', 'นโยบายความมั่นคงปลอดภัยของเว็บไซต์ ประกาศและทบทวนสม่ำเสมอ', '5.2'),
            $manual('5.4', 'มอบหมายผู้รับผิดชอบเว็บไซต์ (ไม่ขาดช่วง) และบทบาทชัดเจน', '5.4 — ระบุชื่อผู้รับผิดชอบในหมายเหตุ'),
            $manual('5.5', 'จัดระดับความละเอียดอ่อนของข้อมูล (PDPA) และการควบคุมการเข้าถึง', '5.5 / 5.6.2'),
            $manual('5.6.4', 'ปฏิบัติตามมาตรฐานเว็บไซต์ภาครัฐ (สพร.) — สำหรับหน่วยงานรัฐ', '5.6.4'),
            $manual('5.6.10', 'แนวทางเลิกใช้เว็บไซต์อย่างปลอดภัย (ลบข้อมูลตาม NIST SP 800-88)', '5.6.10'),
            $manual('c1', 'ทำแบบประเมินตนเอง (ค1) อย่างน้อยปีละ 1 ครั้ง (ผลกระทบสูง: ส่งผู้บริหารสูงสุด หน่วยงานกำกับ และสำเนาถึง สกมช.)', 'พิมพ์แบบประเมินจากหน้านี้'),
        ]],
    ];
}

add_action('admin_post_idw_sec_ncsa', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_sec_ncsa')) wp_die('ไม่มีสิทธิ์', 403);
    $m = idw_sec_ncsa_manual();
    $m['impact'] = in_array($_POST['impact'] ?? '', ['low', 'medium', 'high'], true) ? $_POST['impact'] : 'medium'; // phpcs:ignore
    $items = [];
    foreach ((array) ($_POST['m'] ?? []) as $id => $v) { // phpcs:ignore
        $id = sanitize_text_field($id); $v = (array) wp_unslash($v);
        $items[$id] = ['done' => !empty($v['done']) ? 1 : 0, 'date' => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($v['date'] ?? '')) ? $v['date'] : (!empty($v['done']) ? wp_date('Y-m-d') : ''), 'note' => sanitize_text_field($v['note'] ?? ''), 'by' => get_current_user_id()];
    }
    $m['items'] = $items;
    update_option('idw_sec_ncsa', $m, false);
    if (isset($_POST['refresh'])) delete_transient('idw_sec_ncsa_auto');
    idw_sec_log('setting', 'บันทึกการประเมินตามมาตรฐาน สกมช. 2568');
    wp_safe_redirect(admin_url('admin.php?page=idw-security&tab=ncsa&saved=1')); exit;
});

function idw_sec_tab_ncsa() {
    if (isset($_GET['fresh'])) delete_transient('idw_sec_ncsa_auto'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $secs = idw_sec_ncsa_items(); $man = idw_sec_ncsa_manual();
    $n = ['ok' => 0, 'all' => 0, 'bad' => 0, 'manual' => 0];
    foreach ($secs as $s) foreach ($s[1] as $i) { $n['all']++; if ('ok' === $i[2]) $n['ok']++; elseif ('manual' === $i[2]) $n['manual']++; else $n['bad']++; }
    $pct = $n['all'] ? (int) round($n['ok'] / $n['all'] * 100) : 0;
    $imp = ['low' => 'ต่ำ', 'medium' => 'ปานกลาง', 'high' => 'สูง'];
    if (isset($_GET['saved'])) idw_note('บันทึกแล้ว'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    echo '<div class="idw-card ncsa-head"><div class="ring" style="--p:' . (int) $pct . '"><b>' . (int) $pct . '%</b></div><div><h2 style="margin:0 0 4px">มาตรฐานการรักษาความมั่นคงปลอดภัยสำหรับเว็บไซต์ พ.ศ. 2568</h2><p class="d" style="margin:0">ประกาศ กมช. · มีผลบังคับใช้ 16 กันยายน 2569 · ผ่าน ' . (int) $n['ok'] . ' จาก ' . (int) $n['all'] . ' ข้อ · ต้องแก้ไข ' . (int) $n['bad'] . ' · รอยืนยันโดยผู้รับผิดชอบ ' . (int) $n['manual'] . '</p><p class="d" style="margin:6px 0 0">ข้อที่ตรวจได้ในเว็บ ระบบตรวจให้อัตโนมัติพร้อมปุ่มแก้ไข · ข้อที่เป็นเอกสาร / การกำกับดูแล ติ๊กว่าทำแล้ว ใส่วันที่และหมายเหตุ · <a href="https://websitesecurity.ncsa.or.th/" target="_blank" rel="noopener">อ่านมาตรฐานฉบับเต็ม</a></p></div>'
        . '<div class="ncsa-acts"><a class="idw-btn sm" href="' . esc_url(admin_url('admin.php?page=idw-security&tab=ncsa&fresh=1')) . '">' . idw_icon('refresh') . 'ตรวจใหม่</a><button type="button" class="idw-btn sm" onclick="window.print()">' . idw_icon('book') . 'พิมพ์แบบประเมินตนเอง (ค1)</button></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="ncsa">' . wp_nonce_field('idw_sec_ncsa', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_sec_ncsa">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div class="idw-card"><b>ระดับผลกระทบของเว็บไซต์นี้</b> <select name="impact" class="idw-in" style="width:auto">';
    foreach ($imp as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($man['impact'], $k, false) . '>' . esc_html($l) . '</option>';
    echo '</select> <span class="d">ประเมินจากผลกระทบต่อการเงิน / ชีวิต / ภารกิจ / ความมั่นคง (ใช้ระดับสูงสุด) — ระดับสูงต้องทำครบทุกข้อ ระดับต่ำ–ปานกลางยกเว้นบางข้อได้ตามตาราง ค6</span></div>';
    $label = ['ok' => ['ผ่าน', 'ok'], 'warn' => ['ควรปรับปรุง', 'warn'], 'bad' => ['ต้องแก้ไข', 'bad'], 'manual' => ['รอยืนยัน', 'info']];
    $fixes = [];
    foreach ($secs as $sk => $s) {
        echo '<div class="idw-card ncsa-sec"><h3>' . esc_html($s[0]) . '</h3>';
        foreach ($s[1] as $i) {
            [$id, $title, $st, $detail, $fix, $link, $how] = $i; $isManual = !empty($i[7]);
            echo '<div class="ncsa-row"><span class="idw-chip ' . esc_attr($label[$st][1]) . '">' . esc_html($label[$st][0]) . '</span><div class="t"><b>' . esc_html($title) . '</b>' . ($detail ? '<small>' . esc_html($detail) . '</small>' : '') . ($how && 'ok' !== $st ? '<small class="how">' . wp_kses($how, ['code' => []]) . '</small>' : '');
            if ($isManual) { $d = $man['items'][$id] ?? []; echo '<div class="mi"><label><input type="checkbox" name="m[' . esc_attr($id) . '][done]" value="1"' . checked(!empty($d['done']), true, false) . '> ทำแล้ว</label> <input type="date" name="m[' . esc_attr($id) . '][date]" value="' . esc_attr($d['date'] ?? '') . '"> <input type="text" name="m[' . esc_attr($id) . '][note]" value="' . esc_attr($d['note'] ?? '') . '" placeholder="หมายเหตุ / เอกสารอ้างอิง / ผู้รับผิดชอบ" class="idw-in"></div>'; }
            echo '</div><div class="a">';
            if ($fix) $fixes[] = $fix;
            if ($fix) echo '<button type="button" class="idw-btn pri sm" data-ncsa-fix="' . esc_attr($fix) . '">' . idw_icon('wand') . 'แก้ไขให้</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            if ($link) echo '<a class="idw-btn sm" href="' . esc_url($link[1]) . '">' . esc_html($link[0]) . '</a>';
            echo '</div></div>';
        }
        echo '</div>';
    }
    echo '<p><button class="idw-btn pri">' . idw_icon('check') . 'บันทึกการประเมิน</button></p></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    // the fix buttons run the same one-click fixes as the report (each is checked after the change and undone if the site breaks)
    echo '<form id="ncsa-fix" method="post" action="' . esc_url(admin_url('admin-post.php')) . '" hidden>' . wp_nonce_field('idw_sec_fix', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_sec_fix"><input type="hidden" name="fix" value=""><input type="hidden" name="back" value="ncsa"></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<script>document.addEventListener("click",function(e){var b=e.target.closest("[data-ncsa-fix]");if(!b)return;var f=document.getElementById("ncsa-fix");f.fix.value=b.dataset.ncsaFix;if(b.dataset.ncsaFix==="hide_login"&&!confirm("หลังเปิด หน้าเข้าสู่ระบบจะเปลี่ยนเป็น ' . esc_js(home_url('/' . idw_sec_login_slug() . '/')) . ' — จดที่อยู่นี้ไว้ก่อน\\n\\nดำเนินการต่อ?"))return;b.disabled=true;f.submit();});</script>';
    echo '<style>.ncsa-head{display:flex;gap:18px;align-items:center;flex-wrap:wrap}.ncsa-head .ring{width:86px;height:86px;border-radius:50%;display:grid;place-items:center;background:conic-gradient(#0a7d55 calc(var(--p)*1%),#e3e8ef 0);flex:none}.ncsa-head .ring b{background:#fff;width:66px;height:66px;border-radius:50%;display:grid;place-items:center;font-size:18px}.ncsa-head>div:nth-child(2){flex:1;min-width:260px}.ncsa-acts{display:flex;gap:8px;flex-wrap:wrap}.ncsa-sec h3{margin:0 0 8px}.ncsa-row{display:grid;grid-template-columns:110px 1fr auto;gap:12px;align-items:start;padding:10px 0;border-top:1px solid #eef1f5}.ncsa-row .t b{display:block}.ncsa-row .t small{display:block;color:#646970;margin-top:2px}.ncsa-row .t small.how{color:#2271b1}.ncsa-row .a{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}.ncsa-row .mi{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:6px}.ncsa-row .mi .idw-in{flex:1;min-width:200px}.ncsa-row .idw-chip{justify-self:start}@media(max-width:782px){.ncsa-row{grid-template-columns:1fr}.ncsa-row .a{justify-content:flex-start}}'
        . '@media print{#adminmenumain,#wpadminbar,.idw-subtabs,.idw-head,.ncsa-acts,.ncsa-row .a,.idw-btn,#wpfooter,.notice{display:none!important}#wpcontent{margin:0!important}.idw-card{box-shadow:none!important;border:1px solid #ccc!important;break-inside:avoid}.ncsa-row{grid-template-columns:90px 1fr}body:before{content:"แบบประเมินตนเอง (ค1) มาตรฐานความมั่นคงปลอดภัยเว็บไซต์ พ.ศ. 2568 — ' . esc_js(wp_parse_url(home_url(), PHP_URL_HOST)) . ' — ' . esc_js(wp_date('j M Y')) . '";display:block;font:700 16px sans-serif;margin:0 0 10px}}</style>';
}

/** one click: the CMS protections that are still off */
function idw_sec_fix_ncsa_cms() {
    $on = [];
    foreach (['file_edit', 'xmlrpc', 'users_api', 'unfiltered_html', 'risky_uploads', 'generator'] as $k) if (!idw_sec_on($k)) { idw_sec_set($k, true); $on[] = idw_sec_hardening_list()[$k][0]; }
    return $on ? 'เปิดแล้ว: ' . implode(' · ', $on) : 'เปิดครบอยู่แล้ว';
}
