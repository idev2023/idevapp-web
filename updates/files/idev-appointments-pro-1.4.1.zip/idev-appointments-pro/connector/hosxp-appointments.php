<?php
/**
 * ตัวเชื่อมนัดหมายออนไลน์ → HOSxP (ปลั๊กอิน iDev Appointments Pro — https://idevapp.me/)
 * เป็นเครื่องมือทางเลือก โรงพยาบาลตัดสินใจใช้เอง ตรวจสอบเอง และรับผิดชอบข้อมูลที่บันทึกลง HOSxP เอง (ดู README-TH.md)
 *
 * รันบนเครื่องใน รพ. ที่เข้าถึงฐานข้อมูล HOSxP ได้:  php hosxp-appointments.php            (รันครั้งเดียว — ใช้กับ cron / Task Scheduler)
 *                                                    php hosxp-appointments.php --loop 60  (วนทุก 60 วินาที)
 *                                                    php hosxp-appointments.php --check    (ตรวจการเชื่อมต่อและคอลัมน์)
 * ต้องใช้ PHP 7.4+ ที่มี pdo_mysql และ curl (หรือ openssl)
 */

if (PHP_SAPI !== 'cli') { http_response_code(403); exit('CLI only'); }
$config_file = __DIR__ . '/config.php';
if (!file_exists($config_file)) { fwrite(STDERR, "ไม่พบ config.php — คัดลอก config.sample.php เป็น config.php แล้วแก้ค่า\n"); exit(1); }
$config = require $config_file;
date_default_timezone_set($config['timezone'] ?? 'Asia/Bangkok');
$args = array_slice($argv, 1);

function logline($message) {
    global $config;
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $message;
    echo $line . PHP_EOL;
    if (!empty($config['log_file'])) @file_put_contents($config['log_file'], $line . PHP_EOL, FILE_APPEND);
}

function api($method, $path, $data = null) {
    global $config;
    $url = rtrim($config['site_url'], '/') . '/wp-json/' . trim($config['api'] ?? 'idev-appt/v1/connector', '/') . '/' . ltrim($path, '/');
    $headers = ['Authorization: Bearer ' . $config['token'], 'Accept: application/json', 'User-Agent: iDev-HOSxP-Appointments/1.0'];
    $body = $data === null ? null : json_encode($data, JSON_UNESCAPED_UNICODE);
    if ($body !== null) $headers[] = 'Content-Type: application/json';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => $headers, CURLOPT_TIMEOUT => 30, CURLOPT_CONNECTTIMEOUT => 10]);
        if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        $response = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        if ($response === false) throw new RuntimeException("เชื่อมต่อเว็บไม่ได้: $error");
    } else {
        $context = stream_context_create(['http' => ['method' => $method, 'header' => implode("\r\n", $headers), 'content' => $body ?? '', 'timeout' => 30, 'ignore_errors' => true]]);
        $response = @file_get_contents($url, false, $context);
        if ($response === false) throw new RuntimeException('เชื่อมต่อเว็บไม่ได้');
        preg_match('#HTTP/\S+ (\d+)#', $http_response_header[0] ?? '', $m);
        $code = (int) ($m[1] ?? 0);
    }
    $json = json_decode($response, true);
    if ($code === 401 || $code === 403) throw new RuntimeException("เว็บปฏิเสธรหัสตัวเชื่อม (HTTP $code) — ตรวจ token ใน config.php / IP ที่อนุญาต / Cloudflare");
    if ($code === 402 || $code === 409) throw new RuntimeException('เว็บปิดตัวเชื่อมอยู่: ' . ($json['message'] ?? "HTTP $code"));
    if ($code >= 400 || !is_array($json)) throw new RuntimeException("เว็บตอบกลับผิดปกติ (HTTP $code): " . substr((string) $response, 0, 200));
    return $json;
}

function db() {
    global $config;
    static $pdo = null;
    if ($pdo) return $pdo;
    $c = $config['db'];
    $pdo = new PDO("mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset={$c['charset']}", $c['user'], $c['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
    return $pdo;
}

function ident($name) {
    if (!preg_match('/^[A-Za-z0-9_]+$/', $name)) throw new RuntimeException("ชื่อตาราง/คอลัมน์ไม่ถูกต้อง: $name");
    return '`' . $name . '`';
}

function oapp_columns() {
    global $config;
    static $columns = null;
    if ($columns === null) {
        $columns = [];
        foreach (db()->query('SHOW COLUMNS FROM ' . ident($config['oapp_table'])) as $row) $columns[strtolower($row['Field'])] = $row;
    }
    return $columns;
}

function guid() {
    $b = random_bytes(16);
    $b[6] = chr(ord($b[6]) & 0x0f | 0x40);
    $b[8] = chr(ord($b[8]) & 0x3f | 0x80);
    return '{' . strtoupper(vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($b), 4))) . '}';
}

/** Row for one of the templates in config ('insert', 'update', 'cancel'); columns not in the table are skipped. */
function row_for($template_name, $item, $oapp_id) {
    global $config;
    $vars = [
        'oapp_id' => $oapp_id, 'hn' => $item['hn'], 'name' => $item['name'], 'phone' => $item['phone'], 'date' => $item['date'],
        'start' => $item['start'] . ':00', 'end' => $item['end'] . ':00', 'clinic' => $item['clinic'] !== '' ? $item['clinic'] : ($config['default_clinic'] ?? ''),
        'doctor' => $item['doctor'] !== '' ? $item['doctor'] : ($config['default_doctor'] ?? ''), 'provider' => $item['provider'], 'branch' => $item['branch'],
        'reason' => $item['reason'], 'ref' => $item['ref'], 'source' => $item['source'], 'cancel_reason' => $item['cancel_reason'],
        'today' => date('Y-m-d'), 'now' => date('Y-m-d H:i:s'), 'time_now' => date('H:i:s'), 'guid' => guid(),
    ];
    $available = oapp_columns();
    $row = [];
    foreach ($config[$template_name] ?? [] as $column => $template) {
        $info = $available[strtolower($column)] ?? null;
        if (!$info) { static $warned = []; if (empty($warned[$column])) { logline("  ! ข้ามคอลัมน์ $column (ไม่มีในตาราง {$config['oapp_table']})"); $warned[$column] = true; } continue; }
        $value = trim(preg_replace_callback('/\{(\w+)\}/', function ($m) use ($vars) { return (string) ($vars[$m[1]] ?? ''); }, (string) $template));
        if ($value === '' && $info['Null'] === 'YES') $value = null;
        if ($value !== null && preg_match('/char\((\d+)\)/i', $info['Type'], $m)) $value = mb_substr($value, 0, (int) $m[1]);
        $row[$column] = $value;
    }
    return $row;
}

function find_existing($item) {
    global $config;
    $col = $config['match_column'] ?? '';
    if ($col === '' || !isset(oapp_columns()[strtolower($col)])) return null;
    $st = db()->prepare('SELECT ' . ident($config['id_column']) . ' FROM ' . ident($config['oapp_table']) . ' WHERE hn = ? AND ' . ident($col) . ' LIKE ? ORDER BY ' . ident($config['id_column']) . ' DESC LIMIT 1');
    $st->execute([$item['hn'], '%' . $item['ref'] . '%']);
    $id = $st->fetchColumn();
    return $id === false ? null : (string) $id;
}

function exists_id($oapp_id) {
    global $config;
    $st = db()->prepare('SELECT COUNT(*) FROM ' . ident($config['oapp_table']) . ' WHERE ' . ident($config['id_column']) . ' = ?');
    $st->execute([$oapp_id]);
    return (bool) $st->fetchColumn();
}

/** New oapp_id inside the open transaction (null = AUTO_INCREMENT). */
function next_id() {
    global $config;
    $h = $config['id'];
    $method = $h['method'] ?? 'serial';
    if ($method === 'auto') return null;
    for ($attempt = 0; $attempt < 50; $attempt++) {
        if ($method === 'serial') {
            $serial = ident($h['serial_table']); $name = ident($h['name_column']); $value = ident($h['value_column']);
            $st = db()->prepare("SELECT $value FROM $serial WHERE $name = ? FOR UPDATE");
            $st->execute([$h['serial_name']]);
            $current = $st->fetchColumn();
            if ($current === false) throw new RuntimeException("ไม่พบแถว {$h['serial_name']} ในตาราง {$h['serial_table']}");
            $id = (int) $current + 1;
            db()->prepare("UPDATE $serial SET $value = ? WHERE $name = ?")->execute([$id, $h['serial_name']]);
        } else {
            $id = (int) db()->query('SELECT MAX(' . ident($config['id_column']) . ') FROM ' . ident($config['oapp_table']) . ' FOR UPDATE')->fetchColumn() + 1;
        }
        if (!exists_id($id)) return (string) $id;
    }
    throw new RuntimeException('ออกเลข oapp_id ไม่สำเร็จ (ซ้ำต่อเนื่อง) — ตรวจตาราง serial');
}

function update_row($oapp_id, $row) {
    global $config;
    if (!$row) return;
    $set = implode(',', array_map(function ($c) { return ident($c) . ' = ?'; }, array_keys($row)));
    db()->prepare('UPDATE ' . ident($config['oapp_table']) . " SET $set WHERE " . ident($config['id_column']) . ' = ?')->execute(array_merge(array_values($row), [$oapp_id]));
}

function insert_oapp($item) {
    global $config;
    db()->beginTransaction();
    try {
        $id = next_id();
        $row = row_for('insert', $item, (string) $id);
        if ($id === null) unset($row[$config['id_column']]);
        $columns = implode(',', array_map('ident', array_keys($row)));
        $marks = implode(',', array_fill(0, count($row), '?'));
        db()->prepare('INSERT INTO ' . ident($config['oapp_table']) . " ($columns) VALUES ($marks)")->execute(array_values($row));
        if ($id === null) $id = (string) db()->lastInsertId();
        db()->commit();
        return $id;
    } catch (Throwable $e) {
        db()->rollBack();
        throw $e;
    }
}

/** Counts of patients waiting for each doctor today (no names, no HN) → website, for the doctor's room. */
function send_waiting() {
    global $config;
    $w = $config['waiting'] ?? [];
    if (empty($w['on']) || empty($w['sql'])) return;
    $rows = [];
    foreach (db()->query($w['sql'])->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $r = array_change_key_case($r, CASE_LOWER);
        if (!isset($r['doctor']) || $r['doctor'] === '') continue;
        $rows[] = ['doctor' => (string) $r['doctor'], 'waiting' => (int) ($r['waiting'] ?? 0), 'done' => (int) ($r['done'] ?? 0)];
    }
    if ($config['mode'] === 'dry-run') { logline('รอตรวจ (dry-run): ' . json_encode($rows, JSON_UNESCAPED_UNICODE)); return; }
    api('POST', 'waiting', ['rows' => $rows]);
}

function run_once() {
    global $config;
    try { send_waiting(); } catch (Throwable $e) { logline('รอตรวจ: ' . $e->getMessage()); }
    $mode = $config['mode'];
    $queue = api('GET', 'queue');
    $items = $queue['items'] ?? [];
    if (!empty($queue['waiting_for_hn'])) logline($queue['waiting_for_hn'] . ' นัดรอ HN (ยังไม่ส่ง)');
    if (!$items) return 0;
    logline(count($items) . " รายการ (โหมด $mode)");
    foreach ($items as $item) {
        $label = "{$item['ref']} HN {$item['hn']} {$item['date']} {$item['start']} {$item['provider']}";
        try {
            $oapp = $item['oapp_id'] !== '' ? $item['oapp_id'] : find_existing($item);
            if ($oapp !== null && !exists_id($oapp)) $oapp = null;
            if ($item['action'] === 'cancel') {
                if ($oapp === null) { logline("  - $label ยกเลิก: ไม่พบนัดใน HOSxP"); if ($mode !== 'dry-run') api('POST', 'result', ['id' => $item['id'], 'status' => 'cancelled', 'message' => 'not found in HOSxP']); continue; }
                $row = row_for('cancel', $item, $oapp);
                if ($mode === 'dry-run') { logline("  x $label จะยกเลิก oapp $oapp: " . json_encode($row, JSON_UNESCAPED_UNICODE)); continue; }
                update_row($oapp, $row);
                logline("  x $label ยกเลิก oapp $oapp");
                api('POST', 'result', ['id' => $item['id'], 'status' => 'cancelled', 'oapp_id' => $oapp]);
                continue;
            }
            if ($oapp !== null) {
                $row = row_for('update', $item, $oapp);
                if ($mode === 'dry-run') { logline("  ~ $label จะแก้ oapp $oapp: " . json_encode($row, JSON_UNESCAPED_UNICODE)); continue; }
                update_row($oapp, $row);
                logline("  ~ $label แก้ oapp $oapp");
            } else {
                if ($mode === 'dry-run') { logline("  + $label จะสร้างนัดใหม่: " . json_encode(row_for('insert', $item, '(ใหม่)'), JSON_UNESCAPED_UNICODE)); continue; }
                $oapp = insert_oapp($item);
                logline("  + $label สร้าง oapp $oapp");
            }
            api('POST', 'result', ['id' => $item['id'], 'status' => 'synced', 'oapp_id' => $oapp]);
        } catch (Throwable $e) {
            logline("  ! $label ผิดพลาด: " . $e->getMessage());
            if ($mode !== 'dry-run') {
                try { api('POST', 'result', ['id' => $item['id'], 'status' => 'error', 'message' => 'HOSxP: ' . mb_substr($e->getMessage(), 0, 280)]); } catch (Throwable $ignored) {}
            }
        }
    }
    return count($items);
}

$lock = fopen(sys_get_temp_dir() . '/idev-hosxp-appointments.lock', 'c');
if (!flock($lock, LOCK_EX | LOCK_NB)) { echo "กำลังทำงานอยู่แล้ว\n"; exit(0); }

try {
    if (in_array('--check', $args, true)) {
        $ping = api('GET', 'ping');
        logline('เว็บ: OK ' . ($ping['site'] ?? '') . ' (รอส่ง ' . ($ping['waiting'] ?? 0) . ')');
        $columns = oapp_columns();
        logline('HOSxP: OK ตาราง ' . $config['oapp_table'] . ' มี ' . count($columns) . ' คอลัมน์');
        foreach (['insert', 'update', 'cancel'] as $t) foreach ($config[$t] ?? [] as $column => $template) logline("  [$t] " . (isset($columns[strtolower($column)]) ? '✓' : '✗ ไม่มี') . " $column ← $template");
        if (($config['id']['method'] ?? 'serial') === 'serial') {
            $h = $config['id'];
            $st = db()->prepare('SELECT ' . ident($h['value_column']) . ' FROM ' . ident($h['serial_table']) . ' WHERE ' . ident($h['name_column']) . ' = ?');
            $st->execute([$h['serial_name']]);
            $v = $st->fetchColumn();
            logline($v === false ? "✗ ไม่พบ serial '{$h['serial_name']}'" : "✓ เลขล่าสุดใน serial: $v");
        }
        logline('โหมดปัจจุบัน: ' . $config['mode']);
        exit(0);
    }
    $loop = ($i = array_search('--loop', $args, true)) !== false ? max(15, (int) ($args[$i + 1] ?? 60)) : 0;
    do {
        try { run_once(); } catch (Throwable $e) { logline('ผิดพลาด: ' . $e->getMessage()); if (!$loop) exit(1); }
        if ($loop) sleep($loop);
    } while ($loop);
} finally {
    flock($lock, LOCK_UN);
}
