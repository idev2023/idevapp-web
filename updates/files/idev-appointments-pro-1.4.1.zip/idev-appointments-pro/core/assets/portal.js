/* iDev Appointments — doctor portal / back-office appointment list. */
(function () {
  const root = document.querySelector('[data-idev-portal]');
  if (!root || !window.wp || !wp.apiFetch) return;
  const C = JSON.parse(root.dataset.idevPortal);
  const t = C.t;
  wp.apiFetch.use(wp.apiFetch.createNonceMiddleware(window.wpApiSettings.nonce));
  wp.apiFetch.use(wp.apiFetch.createRootURLMiddleware(window.wpApiSettings.root));
  const api = (path, data) => wp.apiFetch(data ? { path: 'idev-appt/v1/' + path, method: 'POST', data } : { path: 'idev-appt/v1/' + path });
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const addDays = (d, n) => { const x = new Date(d + 'T00:00:00Z'); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); };
  const monday = (d) => { const x = new Date(d + 'T00:00:00Z'); return addDays(d, -((x.getUTCDay() + 6) % 7)); };
  const monthStart = (d) => d.slice(0, 8) + '01';
  const monthEnd = (d) => { const [y, m] = d.split('-').map(Number); return new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10); };
  const addMonths = (d, n) => { const [y, m] = d.split('-').map(Number); return new Date(Date.UTC(y, m - 1 + n, 1)).toISOString().slice(0, 10); };
  /* visible range of each view: day, Monday–Sunday, or the full weeks around a month */
  const range = () => {
    if (S.view === 'week') { const f = monday(S.date); return [f, addDays(f, 6)]; }
    if (S.view === 'month') { const f = monday(monthStart(S.date)); return [f, addDays(monday(monthEnd(S.date)), 6)]; }
    return [S.date, S.date];
  };
  const fmt = (d, long) => { const [y, m, dd] = d.split('-').map(Number); const wd = (new Date(Date.UTC(y, m - 1, dd)).getUTCDay() + 6) % 7; return `${C.weekdays[wd]} ${dd} ${C.months[m - 1]}${long ? ' ' + (C.lang === 'en' ? y : y + 543) : ''}`; };
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem('idev-portal') || '{}'); } catch (e) { saved = {}; }
  const S = { view: saved.view || 'day', date: C.today, provider: saved.provider || 0, tab: 'list', q: '', data: null, open: 0, st: '' };
  const remember = () => { try { localStorage.setItem('idev-portal', JSON.stringify({ view: S.view, provider: S.provider })); } catch (e) {} };

  async function load() {
    const [from, to] = range();
    root.classList.add('is-busy');
    try {
      S.data = await api(`portal/list?from=${from}&to=${to}&provider=${S.provider || ''}&q=${encodeURIComponent(S.q)}${S.view === 'month' ? '&clinic=1' : ''}`);
      if (S.provider && !S.data.providers.some((p) => p.id === S.provider)) S.provider = 0;
    } catch (e) { root.innerHTML = `<p class="ip-err">${esc(e.message || t.error)}</p>`; return; }
    finally { root.classList.remove('is-busy'); }
    render();
  }
  const pname = (id) => { const p = (S.data.providers || []).find((x) => x.id === id); return p ? p.name : ''; };
  const chip = (s) => `<span class="ip-chip s-${esc(s)}">${esc(t.statuses[s] || s)}</span>`;

  function row(a) {
    const open = S.open === a.id;
    const acts = [];
    if (a.status === 'pending') acts.push(['confirmed', t.confirm, 'primary']);
    if (a.status === 'pending' || a.status === 'confirmed') acts.push(['move', t.move, ''], ['cancelled', t.cancel, 'danger']);
    if (a.status === 'confirmed' && a.date <= C.today) acts.push(['completed', t.done, ''], ['no_show', t.noShow, '']);
    if (a.status === 'completed' || a.status === 'no_show') acts.push(['confirmed', t.undo, '']);
    return `<li class="ip-item s-${esc(a.status)}${open ? ' open' : ''}" data-id="${a.id}">
      <button type="button" class="ip-sum" data-toggle aria-expanded="${open}"><span class="ip-time">${esc(a.start)}<small>${esc(a.end)}</small></span>
      <span class="ip-who"><strong>${esc(a.name || '—')}</strong><small>${a.hn ? 'HN ' + esc(a.hn) : a.reg ? esc(t.newReg) + ' · ' + esc(a.reg) : ''}${!a.verified ? ' · <b class="ip-warn">' + esc(t.unverified) + '</b>' : ''}${(S.data.providers || []).length > 1 && !S.provider ? ' · ' + esc(pname(a.provider)) : ''}</small></span>${chip(a.status)}</button>
      ${open ? `<div class="ip-detail"><dl>
        ${a.phone ? `<dt>${esc(t.phone)}</dt><dd><a href="tel:${esc(a.phone)}">${esc(a.phone)}</a></dd>` : ''}${a.email ? `<dt>${esc(t.email)}</dt><dd><a href="mailto:${esc(a.email)}">${esc(a.email)}</a></dd>` : ''}
        ${a.dob ? `<dt>${esc(t.dob)}</dt><dd>${esc(a.dob)}</dd>` : ''}${a.cid ? `<dt>${esc(t.cid)}</dt><dd>${esc(a.cid)}</dd>` : ''}${a.reason ? `<dt>${esc(t.reasonVisit)}</dt><dd>${esc(a.reason)}</dd>` : ''}<dt>Ref</dt><dd>${esc(a.ref)}${a.source === 'staff' ? ' · ' + esc(t.byStaff) : ''}</dd>
        ${a.cancel_reason ? `<dt>${esc(t.cancel)}</dt><dd>${esc(a.cancel_reason)}</dd>` : ''}</dl>
        <div class="ip-actions">${acts.map(([k, l, c]) => `<button type="button" class="ip-btn ${c}" data-do="${k}">${esc(l)}</button>`).join('')}<button type="button" class="ip-btn" data-do="note">${esc(t.note)}</button>${(a.links || []).map((l) => `<a class="ip-btn ip-link" href="${esc(l[1])}" target="_blank" rel="noopener">${esc(l[0])}</a>`).join('')}</div>
        <div class="ip-panel"></div>
        <details class="ip-log"><summary>${esc(t.history)}</summary><ul>${a.log.map((l) => `<li>${esc(l[0].slice(0, 16).replace('T', ' '))} · ${esc(l[1])} · ${esc(l[2])}</li>`).join('')}</ul></details></div>` : ''}</li>`;
  }

  /* Month calendar for doctors: each day lists the patients with their status. Tap a patient to open the
     appointment, tap the day to see the whole day. Days with clinic hours are tinted. Chips filter by status. */
  const stKey = (a) => (a.moved && (a.status === 'pending' || a.status === 'confirmed') ? 'moved' : a.status);
  function month(items) {
    const [from, to] = range();
    const days = S.data.days || {};
    const cur = S.date.slice(0, 7);
    const inMonth = items.filter((a) => a.date.slice(0, 7) === cur);
    const count = (k) => inMonth.filter((a) => stKey(a) === k).length;
    const keys = ['pending', 'confirmed', 'moved', 'cancelled', 'completed', 'no_show'].filter((k) => k === 'pending' || k === 'confirmed' || count(k));
    const shown = S.st ? items.filter((a) => stKey(a) === S.st) : items;
    const byDay = {};
    shown.forEach((a) => { (byDay[a.date] = byDay[a.date] || []).push(a); });
    const sum = `<div class="ip-msum"><span class="ip-msum-t">${esc(t.monthSum)}</span><button type="button" data-st="" class="${!S.st ? 'on' : ''}">${esc(t.all)} <b>${inMonth.length}</b></button>${keys.map((k) => `<button type="button" data-st="${k}" class="st-${k}${S.st === k ? ' on' : ''}"><i></i>${esc(t.short[k])} <b>${count(k)}</b></button>`).join('')}</div>`;
    let cells = '';
    for (let d = from; d <= to; d = addDays(d, 1)) {
      const info = days[d] || { hours: [], off: false };
      const list = byDay[d] || [];
      const active = list.filter((a) => a.status !== 'cancelled').length;
      const max = 5;
      const rows = list.slice(0, max).map((a) => `<button type="button" class="ip-mp st-${stKey(a)}" data-open="${a.id}" data-day="${a.date}" title="${esc(a.start + ' ' + (a.name || '') + ' · ' + t.short[stKey(a)])}"><b>${esc(a.start)}</b><span>${esc(a.name || '—')}</span><em>${esc(t.short[stKey(a)])}</em></button>`).join('');
      const dots = list.map((a) => `<i class="st-${stKey(a)}"></i>`).join('');
      cells += `<div class="ip-mday${d.slice(0, 7) !== cur ? ' other' : ''}${d === C.today ? ' today' : ''}${info.off ? ' off' : ''}${info.hours.length ? ' clinic' : ''}${d < C.today ? ' past' : ''}" data-goto="${d}" role="button" tabindex="0">
        <span class="ip-mnum">${Number(d.slice(8))}${active ? `<em>${active}</em>` : ''}</span>
        ${info.off ? `<span class="ip-moff">${esc(t.closed)}</span>` : ''}${rows}${list.length > max ? `<span class="ip-mmore">${esc(t.more.replace('%d', list.length - max))}</span>` : ''}<span class="ip-mdots">${dots}</span></div>`;
    }
    return `<div class="ip-month">${sum}<div class="ip-mhead">${C.weekdays.map((w) => `<span>${esc(w)}</span>`).join('')}</div><div class="ip-mgrid">${cells}</div></div>`;
  }

  function render() {
    const d = S.data;
    const items = S.tab === 'pending' ? d.pending_items : d.items;
    const [from] = range();
    let body = '';
    if (S.tab === 'list' && S.view === 'month') body = month(items);
    else if (!items.length) body = `<p class="ip-empty">${esc(t.empty)}</p>`;
    else {
      const groups = {};
      items.forEach((a) => { (groups[a.date] = groups[a.date] || []).push(a); });
      body = Object.keys(groups).sort().map((day) => `<h3 class="ip-day${day === C.today ? ' today' : ''}">${esc(fmt(day, true))} <span>${groups[day].filter((a) => a.status !== 'cancelled').length}</span></h3><ul class="ip-list">${groups[day].map(row).join('')}</ul>`).join('');
    }
    const [y, m] = S.date.split('-').map(Number);
    const title = S.tab === 'pending' ? t.pending : S.view === 'month' ? `${C.monthsLong[m - 1]} ${C.lang === 'en' ? y : y + 543}` : S.view === 'week' ? `${fmt(from)} – ${fmt(addDays(from, 6), true)}` : fmt(S.date, true);
    root.innerHTML = `<div class="ip-top"><div class="ip-tabs"><button type="button" data-tab="list" class="${S.tab === 'list' ? 'on' : ''}">${esc(t[S.view] || t.day)}</button><button type="button" data-tab="pending" class="${S.tab === 'pending' ? 'on' : ''}">${esc(t.pending)}${d.pending ? ` <b>${d.pending}</b>` : ''}</button></div>
      <button type="button" class="ip-btn primary" data-new>＋ ${esc(t.newAppt)}</button></div>
      <div class="ip-bar">${S.tab === 'list' ? `<div class="ip-nav"><button type="button" data-step="-1" aria-label="‹">‹</button><button type="button" data-today>${esc(t.today)}</button><button type="button" data-step="1" aria-label="›">›</button><input type="date" value="${esc(S.date)}" data-date></div>
        <div class="ip-seg"><button type="button" data-view="day" class="${S.view === 'day' ? 'on' : ''}">${esc(t.day)}</button><button type="button" data-view="week" class="${S.view === 'week' ? 'on' : ''}">${esc(t.week)}</button><button type="button" data-view="month" class="${S.view === 'month' ? 'on' : ''}">${esc(t.month)}</button></div>` : ''}
        ${d.providers.length > 1 ? `<select data-provider><option value="0">${esc(t.allProviders)}</option>${d.providers.map((p) => `<option value="${p.id}"${S.provider === p.id ? ' selected' : ''}>${esc(p.name)}</option>`).join('')}</select>` : ''}
        <input type="search" placeholder="${esc(t.search)}" value="${esc(S.q)}" data-q><button type="button" class="ip-btn" data-print>${esc(t.print)}</button></div>
      <h2 class="ip-title">${esc(title)}</h2>${S.tab === 'pending' && items.length > 1 ? `<p><button type="button" class="ip-btn" data-confirm-all>${esc(t.confirmAll)}</button></p>` : ''}<div class="ip-body">${body}</div><div class="ip-modal" hidden></div>`;
    bind();
  }

  function bind() {
    const on = (sel, ev, fn) => root.querySelectorAll(sel).forEach((el) => el.addEventListener(ev, fn));
    on('[data-tab]', 'click', (e) => { S.tab = e.currentTarget.dataset.tab; render(); });
    on('[data-step]', 'click', (e) => { const n = Number(e.currentTarget.dataset.step); S.date = S.view === 'month' ? addMonths(S.date, n) : addDays(S.date, n * (S.view === 'week' ? 7 : 1)); load(); });
    const goto = (d, open) => { S.date = d; S.view = 'day'; S.open = open || 0; S.st = ''; remember(); load(); };
    on('[data-goto]', 'click', (e) => goto(e.currentTarget.dataset.goto));
    on('[data-goto]', 'keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); goto(e.currentTarget.dataset.goto); } });
    on('[data-open]', 'click', (e) => { e.stopPropagation(); goto(e.currentTarget.dataset.day, Number(e.currentTarget.dataset.open)); });
    on('[data-st]', 'click', (e) => { S.st = e.currentTarget.dataset.st; render(); });
    if (S.open && S.view !== 'month') { const it = root.querySelector('.ip-item.open'); if (it && !it.dataset.seen) { it.dataset.seen = 1; it.scrollIntoView({ block: 'center', behavior: 'smooth' }); } }
    on('[data-today]', 'click', () => { S.date = C.today; load(); });
    on('[data-date]', 'change', (e) => { if (e.target.value) { S.date = e.target.value; load(); } });
    on('[data-view]', 'click', (e) => { S.view = e.currentTarget.dataset.view; remember(); load(); });
    on('[data-provider]', 'change', (e) => { S.provider = Number(e.target.value); remember(); load(); });
    let tq; on('[data-q]', 'input', (e) => { clearTimeout(tq); tq = setTimeout(() => { S.q = e.target.value; load().then(() => { const q = root.querySelector('[data-q]'); q.focus(); q.setSelectionRange(q.value.length, q.value.length); }); }, 350); });
    on('[data-print]', 'click', () => window.print());
    on('[data-toggle]', 'click', (e) => { const id = Number(e.currentTarget.closest('[data-id]').dataset.id); S.open = S.open === id ? 0 : id; render(); });
    on('[data-new]', 'click', () => newDialog());
    on('[data-confirm-all]', 'click', async () => { if (!confirm(t.sure)) return; for (const a of S.data.pending_items) await api('portal/action', { id: a.id, do: 'confirmed' }); load(); });
    on('[data-do]', 'click', (e) => action(Number(e.currentTarget.closest('[data-id]').dataset.id), e.currentTarget.dataset.do, e.currentTarget.closest('.ip-detail').querySelector('.ip-panel')));
  }

  async function action(id, what, panel) {
    const all = S.data.items.concat(S.data.pending_items);
    const a = all.find((x) => x.id === id);
    if (what === 'cancelled' || what === 'note') {
      panel.innerHTML = `<label class="ip-f"><span>${esc(what === 'note' ? t.note : t.reason)}</span><input data-reason></label><button type="button" class="ip-btn ${what === 'cancelled' ? 'danger' : 'primary'}" data-go>${esc(what === 'note' ? t.save : t.cancel)}</button>`;
      panel.querySelector('[data-go]').addEventListener('click', () => send({ id, do: what, reason: panel.querySelector('[data-reason]').value }));
      panel.querySelector('[data-reason]').focus();
      return;
    }
    if (what === 'move') { picker(panel, a.provider, a.date, id, (date, start) => send({ id, do: 'move', date, start })); return; }
    send({ id, do: what });
  }
  async function send(data) {
    try { const r = await api('portal/action', data); if (!r.ok) { alert(r.error || t.error); return; } }
    catch (e) { alert(e.message || t.error); return; }
    load();
  }
  /** Date + time chooser for staff (full slots allowed). */
  function picker(panel, provider, date, exclude, done) {
    panel.innerHTML = `<div class="ip-picker"><label class="ip-f"><span>${esc(t.date)}</span><input type="date" value="${esc(date)}" data-pd></label><div class="ip-slots"></div><p class="ip-hint">${esc(t.overbook)}</p></div>`;
    const load2 = async () => {
      const d = panel.querySelector('[data-pd]').value;
      const box = panel.querySelector('.ip-slots');
      box.innerHTML = '…';
      const r = await api(`portal/slots?provider=${provider}&date=${d}&exclude=${exclude || 0}`);
      box.innerHTML = r.slots.length ? r.slots.map((s) => `<button type="button" class="ip-slot${s.left ? '' : ' full'}" data-s="${s.start}"><b>${s.start}</b><small>${s.left ? esc(t.left.replace('%d', s.left)) : esc(t.full)}</small></button>`).join('') : `<p class="ip-empty">${esc(t.noTimes)}</p>`;
      box.querySelectorAll('[data-s]').forEach((b) => b.addEventListener('click', () => done(d, b.dataset.s)));
    };
    panel.querySelector('[data-pd]').addEventListener('change', load2);
    load2();
  }
  function newDialog() {
    const m = root.querySelector('.ip-modal');
    const provs = S.data.providers;
    m.hidden = false;
    m.innerHTML = `<div class="ip-dialog" role="dialog" aria-modal="true"><h2>${esc(t.newAppt)}</h2>
      <label class="ip-f"><span>${esc(t.provider)}</span><select data-np>${provs.map((p) => `<option value="${p.id}"${(S.provider || provs[0].id) === p.id ? ' selected' : ''}>${esc(p.name)}</option>`).join('')}</select></label>
      <div class="ip-grid"><label class="ip-f"><span>${esc(t.hn)}</span><input data-nf="hn"></label><label class="ip-f"><span>${esc(t.name)}</span><input data-nf="name"></label>
      <label class="ip-f"><span>${esc(t.phone)}</span><input data-nf="phone" type="tel"></label><label class="ip-f"><span>${esc(t.email)}</span><input data-nf="email" type="email"></label>
      <label class="ip-f"><span>${esc(t.dob)}</span><input data-nf="dob" type="date"></label><label class="ip-f"><span>${esc(t.reasonVisit)}</span><input data-nf="reason"></label></div>
      <div class="ip-panel"></div><p class="ip-err"></p><div class="ip-actions"><button type="button" class="ip-btn" data-close>${esc(t.close)}</button></div></div>`;
    const panel = m.querySelector('.ip-panel');
    const pick = () => picker(panel, Number(m.querySelector('[data-np]').value), S.date, 0, async (date, start) => {
      const v = (k) => m.querySelector(`[data-nf="${k}"]`).value.trim();
      if (!v('name') && !v('hn')) { m.querySelector('.ip-err').textContent = t.name; return; }
      try {
        const r = await api('portal/create', { provider: Number(m.querySelector('[data-np]').value), date, start, hn: v('hn'), name: v('name'), phone: v('phone'), email: v('email'), dob: v('dob'), reason: v('reason'), lang: C.lang });
        if (!r.ok) { m.querySelector('.ip-err').textContent = r.error || t.error; return; }
        m.hidden = true; S.date = date; load();
      } catch (e) { m.querySelector('.ip-err').textContent = e.message || t.error; }
    });
    m.querySelector('[data-np]').addEventListener('change', pick);
    m.querySelector('[data-close]').addEventListener('click', () => { m.hidden = true; });
    m.addEventListener('click', (e) => { if (e.target === m) m.hidden = true; });
    pick();
  }
  load();
})();
