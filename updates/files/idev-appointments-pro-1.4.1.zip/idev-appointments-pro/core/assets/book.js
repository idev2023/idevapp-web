/* iDev Appointments — public booking: clinic / service → doctor / staff / sub-service → day → time → patient (HN / registration, ID number) → agreement → done; and the manage page. */
(function () {
  const root = document.querySelector('[data-idev-appt]');
  if (!root) return;
  const C = JSON.parse(root.dataset.idevAppt);
  const t = C.t;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const api = async (path, opts = {}) => {
    const r = await fetch(C.rest + path, Object.assign({ credentials: 'same-origin', headers: { 'Content-Type': 'application/json' } }, opts));
    const j = await r.json().catch(() => ({}));
    if (!r.ok && !('ok' in j)) throw new Error(j.message || t.error);
    return j;
  };
  const post = (path, body) => api(path, { method: 'POST', body: JSON.stringify(Object.assign({ lang: C.lang }, body)) });
  const fmtDay = (d) => { const [y, m, dd] = d.split('-').map(Number); const wd = (new Date(Date.UTC(y, m - 1, dd)).getUTCDay() + 6) % 7; return `${C.weekdays[wd]} ${dd} ${C.months[m - 1]} ${C.lang === 'en' ? y : y + 543}`; };
  const S = { step: 0, service: null, provider: C.provider, providers: null, month: (C.date || '').slice(0, 7), date: C.date || '', slot: null, days: {}, idType: C.reg ? 'reg' : 'hn', id: null, filter: C.kind || '', q: '' };
  const view = (html) => { root.innerHTML = html; };
  // Two orders (setting): who first, or day and time first and then who is free at that time.
  const TF = C.flow === 'time_first';
  const ORDER = TF ? ['svc', 'day', 'time', 'who', 'patient', 'agree'] : ['svc', 'who', 'day', 'time', 'patient', 'agree'];
  const LABEL = { svc: t.stepService, who: TF ? t.stepSub : t.stepWho, day: t.stepDay, time: t.stepTime, patient: TF ? t.stepDetails : t.stepPatient, agree: t.stepAgree };
  const go = (name) => { S.cur = name; S.step = ORDER.indexOf(name); };
  const bar = () => '<ol class="idev-appt-bar">' + ORDER.map((k, i) => `<li class="${i < S.step ? 'done' : i === S.step ? 'on' : ''}"><b>${i + 1}</b><span>${esc(LABEL[k])}</span></li>`).join('') + '</ol>';
  const group = () => TF && S.service && !S.provider && kids(S.service).length > 0; // choosing the time for the whole clinic / service
  const shown = () => S.provider || S.service;
  const provCard = (p, btn, extra) => `<div class="idev-appt-prov">${p.photo ? `<img src="${esc(p.photo)}" alt="">` : `<span class="idev-appt-avatar">${esc((p.name || '?').replace(/^(นพ\.|พญ\.|ทพ\.|ทพญ\.|Dr\.?)\s*/, '').slice(0, 1))}</span>`}<span><strong>${esc(p.name)}</strong>${p.specialty ? `<small>${esc(p.specialty)}</small>` : ''}${extra ? `<small class="idev-appt-sub">${esc(extra)}</small>` : ''}</span>${btn || ''}</div>`;
  const kids = (p) => (S.providers || []).filter((x) => x.parent === p.id);
  const byId = (id) => (S.providers || []).find((x) => x.id === id);
  const loadProviders = async () => { if (!S.providers) S.providers = await api('providers' + (C.branch ? '?branch=' + encodeURIComponent(C.branch) : '')); return S.providers; };
  const chosenTop = (withDate) => `<div class="idev-appt-chosen${withDate ? ' small' : ''}">${provCard(shown(), C.fixed ? '' : `<button type="button" class="idev-appt-link" data-change>${esc(t.change)}</button>`, S.service && S.provider && S.service.id !== S.provider.id ? S.service.name : '')}${withDate ? `<span class="idev-appt-when-chip">${esc(fmtDay(S.date))}${S.slot ? ' · ' + esc(S.slot.start) : ''}</span>` : ''}</div>`;
  const bindChange = () => { const ch = root.querySelector('[data-change]'); if (ch) ch.addEventListener('click', () => { S.date = ''; S.slot = null; if (!TF && S.service && S.provider && S.service.id !== S.provider.id) { S.provider = null; stepChild(); } else { S.provider = null; S.service = null; stepProvider(); } }); };

  /* ---------- step 1: clinic / service (top level: everything without a parent) ---------- */
  async function stepProvider() {
    go('svc');
    if (!S.providers) { view(bar() + '<div class="idev-appt-loading"></div>'); await loadProviders(); }
    const top = S.providers.filter((p) => !p.parent || !byId(p.parent));
    const hay = (p) => [p.name, p.specialty, p.groups.join(' ')].concat(kids(p).map((k) => k.name + ' ' + k.specialty)).join(' ').toLowerCase();
    const list = top.filter((p) => (!S.filter || p.kind === S.filter) && (!S.q || hay(p).includes(S.q.toLowerCase())));
    const kinds = new Set(top.map((p) => p.kind));
    view(bar() + `<section class="idev-appt-card"><h2>${esc(t.chooseService)}</h2>
      <div class="idev-appt-tools"><input type="search" class="idev-appt-search" placeholder="${esc(t.search)}" value="${esc(S.q)}">
      ${kinds.size > 1 && !C.kind ? `<div class="idev-appt-seg">${[['', t.all], ['clinic', t.clinics], ['doctor', t.doctors]].map(([k, l]) => `<button type="button" data-kind="${k}" class="${S.filter === k ? 'on' : ''}">${esc(l)}</button>`).join('')}</div>` : ''}</div>
      <div class="idev-appt-provs">${list.map((p) => { const n = kids(p).length; return `<button type="button" class="idev-appt-pick" data-p="${p.id}">${provCard(p, '', n ? t.options.replace('%d', n) + ' · ' + kids(p).slice(0, 3).map((k) => k.name).join(', ') + (n > 3 ? ' …' : '') : '')}<span class="idev-appt-go">›</span></button>`; }).join('') || `<p class="idev-appt-empty">—</p>`}</div></section>`);
    const box = root.querySelector('.idev-appt-search');
    box.addEventListener('input', () => { S.q = box.value; const pos = box.selectionStart; stepProvider().then(() => { const b = root.querySelector('.idev-appt-search'); b.focus(); b.setSelectionRange(pos, pos); }); });
    root.querySelectorAll('[data-kind]').forEach((b) => b.addEventListener('click', () => { S.filter = b.dataset.kind; stepProvider(); }));
    root.querySelectorAll('[data-p]').forEach((b) => b.addEventListener('click', () => { const p = byId(Number(b.dataset.p)); S.service = p; S.provider = null; S.date = ''; S.slot = null; if (!kids(p).length) { S.provider = p; stepDay(); } else if (TF) stepDay(); else stepChild(); }));
  }

  /* ---------- step 2: doctor / staff / sub-service of the clinic / service ---------- */
  function stepChild() {
    go('who');
    const svc = S.service;
    const list = kids(svc);
    const any = svc.own ? `<button type="button" class="idev-appt-pick any" data-c="${svc.id}">${provCard({ name: t.anyone, specialty: t.anyoneText, photo: '' })}<span class="idev-appt-go">›</span></button>` : '';
    view(bar() + `<section class="idev-appt-card"><div class="idev-appt-chosen">${provCard(svc, `<button type="button" class="idev-appt-link" data-back-svc>${esc(t.change)}</button>`)}</div>
      <h2>${esc(t.chooseChild)}</h2><div class="idev-appt-provs">${list.map((p) => `<button type="button" class="idev-appt-pick" data-c="${p.id}">${provCard(p, '', t['role_' + p.role] || '')}<span class="idev-appt-go">›</span></button>`).join('')}${any}</div>
      <div class="idev-appt-nav"><button type="button" class="idev-appt-btn ghost" data-back-svc>← ${esc(t.back)}</button></div></section>`);
    root.querySelectorAll('[data-back-svc]').forEach((b) => b.addEventListener('click', () => { S.service = null; S.provider = null; stepProvider(); }));
    root.querySelectorAll('[data-c]').forEach((b) => b.addEventListener('click', () => { S.provider = byId(Number(b.dataset.c)); S.date = ''; S.slot = null; stepDay(); }));
    root.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ---------- step 1: day and time (also used to move an appointment) ---------- */
  async function calendar(container, provider, onPick, opts = {}) {
    const month = S.month || new Date().toISOString().slice(0, 7);
    container.innerHTML = '<div class="idev-appt-loading"></div>';
    const res = await api(opts.group ? `group/month?service=${provider.id}&month=${month}` : `month?provider=${provider.id}&month=${month}`);
    S.days = res.days || {};
    const [y, m] = month.split('-').map(Number);
    const first = new Date(Date.UTC(y, m - 1, 1));
    const lead = (first.getUTCDay() + 6) % 7;
    const n = new Date(Date.UTC(y, m, 0)).getUTCDate();
    const minMonth = res.today.slice(0, 7), maxMonth = res.last.slice(0, 7);
    let cells = '';
    for (let i = 0; i < lead; i++) cells += '<span></span>';
    for (let d = 1; d <= n; d++) {
      const iso = `${month}-${String(d).padStart(2, '0')}`;
      const free = S.days[iso];
      const cls = free === undefined ? 'off' : free > 0 ? 'free' : 'full';
      cells += `<button type="button" class="idev-appt-day ${cls}${S.date === iso ? ' sel' : ''}${iso === res.today ? ' today' : ''}" data-d="${iso}"${free > 0 ? '' : ' disabled'} aria-label="${esc(fmtDay(iso))}${free > 0 ? ', ' + esc(t.left.replace('%d', free)) : ''}">${d}${free > 0 ? '<i></i>' : ''}</button>`;
    }
    const any = Object.values(S.days).some((v) => v > 0);
    container.innerHTML = `<div class="idev-appt-cal"><div class="idev-appt-cal-head"><button type="button" data-m="-1" aria-label="${esc(t.prev)}"${month <= minMonth ? ' disabled' : ''}>‹</button><strong>${esc(C.months[m - 1])} ${C.lang === 'en' ? y : y + 543}</strong><button type="button" data-m="1" aria-label="${esc(t.nextMonth)}"${month >= maxMonth ? ' disabled' : ''}>›</button></div>
      <div class="idev-appt-grid">${C.weekdays.map((w) => `<b>${esc(w)}</b>`).join('')}${cells}</div>${any ? `<p class="idev-appt-hint">${esc(t.pickDay)}</p>` : `<p class="idev-appt-empty">${esc(t.noDays)}</p>`}</div><div class="idev-appt-slots"></div>`;
    container.querySelectorAll('[data-m]').forEach((b) => b.addEventListener('click', () => { const dt = new Date(Date.UTC(y, m - 1 + Number(b.dataset.m), 1)); S.month = dt.toISOString().slice(0, 7); calendar(container, provider, onPick, opts); }));
    const slotsBox = container.querySelector('.idev-appt-slots');
    const showSlots = async (iso) => {
      S.date = iso;
      container.querySelectorAll('.idev-appt-day').forEach((b) => b.classList.toggle('sel', b.dataset.d === iso));
      slotsBox.innerHTML = '<div class="idev-appt-loading"></div>';
      const r = await api(`slots?provider=${provider.id}&date=${iso}`);
      const list = r.slots || [];
      slotsBox.innerHTML = `<h3>${esc(fmtDay(iso))}</h3>` + (list.length ? '<div class="idev-appt-times">' + list.map((s) => `<button type="button" data-s="${s.start}" ${s.open ? '' : 'disabled'} class="${S.slot && S.slot.start === s.start && S.date === iso ? 'sel' : ''}"><strong>${s.start}</strong><small>${s.open ? esc(t.left.replace('%d', s.left)) : esc(t.full)}</small></button>`).join('') + '</div>' : `<p class="idev-appt-empty">${esc(t.noSlots)}</p>`);
      slotsBox.querySelectorAll('[data-s]').forEach((b) => b.addEventListener('click', () => { const s = list.find((x) => x.start === b.dataset.s); onPick(iso, s); }));
      if (opts.scroll !== false) slotsBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    };
    if (opts.onDay) { container.querySelectorAll('.idev-appt-day.free').forEach((b) => b.addEventListener('click', () => opts.onDay(b.dataset.d))); return; }
    container.querySelectorAll('.idev-appt-day.free').forEach((b) => b.addEventListener('click', () => showSlots(b.dataset.d)));
    if (S.date && S.days[S.date] > 0) showSlots(S.date);
  }
  /* ---------- step 3: day ---------- */
  function stepDay() {
    go('day');
    if (!S.month) S.month = (S.date || new Date().toISOString()).slice(0, 7);
    const p = shown();
    view(bar() + `<section class="idev-appt-card">${chosenTop(false)}
      ${p.note ? `<p class="idev-appt-note">${esc(p.note)}</p>` : ''}<p class="idev-appt-meta">${esc(t.minutes.replace('%d', p.minutes))} · ${esc(p.confirm === 'auto' ? t.autoNote : t.manualNote)}</p>
      <h2>${esc(t.chooseDay)}</h2><div class="idev-appt-when"></div>${C.fixed ? '' : `<div class="idev-appt-nav"><button type="button" class="idev-appt-btn ghost" data-back-day>← ${esc(t.back)}</button></div>`}</section>`);
    bindChange();
    const bk = root.querySelector('[data-back-day]');
    if (bk) bk.addEventListener('click', () => { S.date = ''; S.slot = null; if (!TF && S.service && kids(S.service).length) { S.provider = null; stepChild(); } else { S.provider = null; S.service = null; stepProvider(); } });
    calendar(root.querySelector('.idev-appt-when'), p, null, { group: group(), onDay: (iso) => { S.date = iso; S.slot = null; stepTime(); } });
  }

  /* ---------- step 4: time ---------- */
  async function stepTime() {
    go('time');
    view(bar() + `<section class="idev-appt-card">${chosenTop(true)}<h2>${esc(t.chooseSlot)}</h2><div class="idev-appt-slots"><div class="idev-appt-loading"></div></div>
      <div class="idev-appt-nav"><button type="button" class="idev-appt-btn ghost" data-back-time>← ${esc(t.chooseDay)}</button></div></section>`);
    bindChange();
    root.querySelector('[data-back-time]').addEventListener('click', stepDay);
    const box = root.querySelector('.idev-appt-slots');
    const g = group();
    const r = await api(g ? `group/slots?service=${S.service.id}&date=${S.date}` : `slots?provider=${S.provider.id}&date=${S.date}`);
    const list = r.slots || [];
    box.innerHTML = list.length ? '<div class="idev-appt-times">' + list.map((x) => `<button type="button" data-s="${x.start}" ${x.open ? '' : 'disabled'} class="${S.slot && S.slot.start === x.start ? 'sel' : ''}"><strong>${x.start}</strong><small>${x.open ? esc(t.left.replace('%d', x.left)) : esc(t.full)}</small></button>`).join('') + '</div>' : `<p class="idev-appt-empty">${esc(t.noSlots)}</p>`;
    box.querySelectorAll('[data-s]').forEach((b) => b.addEventListener('click', () => { S.slot = list.find((x) => x.start === b.dataset.s); if (g) stepWhoAt(); else stepPatient(); }));
    root.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ---------- (service → day → time) → who is free at that time ---------- */
  async function stepWhoAt() {
    go('who');
    view(bar() + `<section class="idev-appt-card">${chosenTop(true)}<h2>${esc(t.chooseAt)}</h2><div class="idev-appt-provs"><div class="idev-appt-loading"></div></div>
      <div class="idev-appt-nav"><button type="button" class="idev-appt-btn ghost" data-back-who>← ${esc(t.chooseSlot)}</button></div></section>`);
    root.querySelector('[data-back-who]').addEventListener('click', () => { S.provider = null; stepTime(); });
    bindChange();
    const r = await api(`group/who?service=${S.service.id}&date=${S.date}&start=${encodeURIComponent(S.slot.start)}`);
    const items = r.items || [];
    const box = root.querySelector('.idev-appt-provs');
    box.innerHTML = items.length ? items.map((p) => `<button type="button" class="idev-appt-pick" data-w="${p.id}">${provCard(p, '', (p.id === S.service.id ? t.anyone : (t['role_' + p.role] || '')) + ' · ' + t.left.replace('%d', p.slot.left))}<span class="idev-appt-go">›</span></button>`).join('') : `<p class="idev-appt-empty">${esc(t.noSlots)}</p>`;
    box.querySelectorAll('[data-w]').forEach((b) => b.addEventListener('click', () => { const it = items.find((x) => String(x.id) === b.dataset.w); S.provider = byId(it.id) || it; S.slot = it.slot; stepPatient(); }));
    root.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ---------- step 5: patient ---------- */
  function stepPatient() {
    go('patient');
    const reg = S.idType === 'reg';
    const opts = [['hn', t.haveHn]];
    if (C.hasRegistration) opts.push(['reg', t.haveReg]);
    opts.push(['new', t.newPatient]);
    view(bar() + `<section class="idev-appt-card">${chosenTop(true)}
      <h2>${esc(t.who)}</h2><div class="idev-appt-choices">${opts.map(([k, l]) => `<label class="${S.idType === k ? 'on' : ''}"><input type="radio" name="idt" value="${k}" ${S.idType === k ? 'checked' : ''}> ${esc(l)}</label>`).join('')}</div>
      <div class="idev-appt-idbox"></div></section>`);
    root.querySelectorAll('input[name="idt"]').forEach((r) => r.addEventListener('change', () => { S.idType = r.value; S.id = null; stepPatient(); }));
    const box = root.querySelector('.idev-appt-idbox');
    if (S.idType === 'new') {
      box.innerHTML = `<div class="idev-appt-new"><p>${esc(t.newPatientText)}</p>${C.register ? `<a class="idev-appt-btn" href="${esc(C.register)}">${esc(t.register)} →</a>` : (C.phone ? `<a class="idev-appt-btn" href="tel:${esc(C.phone.replace(/[^\d+]/g, ''))}">${esc(t.call)} ${esc(C.phone)}</a>` : '')}</div>${navBtns(false)}`;
      bindNav(null);
      return;
    }
    const v = S.form || {};
    box.innerHTML = `<div class="idev-appt-grid2"><label class="idev-appt-f" data-f="number"><span>${esc(reg ? t.reg : t.hn)}</span><input name="number" value="${esc(v.number || (reg ? C.reg : ''))}" autocomplete="off" autocapitalize="characters" ${reg ? 'placeholder="REG-261026-ABCDE"' : 'inputmode="text"'}><em></em></label>
      <label class="idev-appt-f" data-f="dob"><span>${esc(t.dob)}</span><input type="date" name="dob" value="${esc(v.dob || '')}" max="${new Date().toISOString().slice(0, 10)}"><em></em></label></div>
      <p><button type="button" class="idev-appt-btn ghost" data-check>${esc(t.check)}</button> <span class="idev-appt-idres" role="status">${S.id ? idText(S.id) : ''}</span></p>
      <div class="idev-appt-contact"${S.id ? '' : ' hidden'}>
        <label class="idev-appt-f" data-f="name"><span>${esc(t.name)}</span><input name="name" value="${esc(v.name || '')}" autocomplete="name"><small>${S.id && S.id.name ? esc(t.nameHint) : ''}</small><em></em></label>
        <div class="idev-appt-grid2"><label class="idev-appt-f" data-f="phone"><span>${esc(t.phone)}</span><input type="tel" name="phone" value="${esc(v.phone || '')}" autocomplete="tel" inputmode="tel"><em></em></label>
        <label class="idev-appt-f" data-f="email"><span>${esc(t.email)}</span><input type="email" name="email" value="${esc(v.email || '')}" autocomplete="email"><small>${S.id && S.id.has_email ? esc(t.emailHint) : ''}</small><em></em></label></div>
        ${C.askCid !== 'off' ? `<label class="idev-appt-f" data-f="cid"><span>${esc(t.cid)}${C.askCid === 'optional' ? '' : ' *'}</span><input name="cid" value="${esc(v.cid || '')}" autocomplete="off" inputmode="text" maxlength="20" placeholder="1 2345 67890 12 3"><small>${esc(t.cidHint)}</small><em></em></label>` : ''}
        ${C.askReason ? `<label class="idev-appt-f" data-f="reason"><span>${esc(t.reason)}</span><textarea name="reason" rows="2">${esc(v.reason || '')}</textarea></label>` : ''}
      </div>${navBtns(true)}`;
    const check = async () => {
      const number = box.querySelector('[name="number"]').value.trim(), dob = box.querySelector('[name="dob"]').value;
      setErr('number', number ? '' : t.required); setErr('dob', dob ? '' : t.required);
      if (!number || !dob) return false;
      const res = box.querySelector('.idev-appt-idres');
      res.textContent = '…';
      try {
        const r = await post('identify', { type: S.idType, number, dob });
        if (!r.ok) { S.id = null; res.textContent = ''; setErr('number', r.error); box.querySelector('.idev-appt-contact').hidden = true; return false; }
        S.id = r; res.innerHTML = idText(r);
        box.querySelector('.idev-appt-contact').hidden = false;
        const nh = box.querySelector('[data-f="name"] small'); if (nh) nh.textContent = r.name ? t.nameHint : '';
        const eh = box.querySelector('[data-f="email"] small'); if (eh) eh.textContent = r.has_email ? t.emailHint : '';
        return true;
      } catch (e) { res.textContent = t.error; return false; }
    };
    box.querySelector('[data-check]').addEventListener('click', check);
    bindNav(async () => {
      if (!S.id && !(await check())) return false;
      const f = (n) => { const el = box.querySelector(`[name="${n}"]`); return el ? el.value.trim() : ''; };
      S.form = { number: f('number'), dob: f('dob'), name: f('name'), phone: f('phone'), email: f('email'), reason: f('reason'), cid: f('cid').replace(/[\s-]/g, '').toUpperCase() };
      let ok = true;
      if (C.askCid !== 'off') {
        const c = S.form.cid;
        const thai = (x) => { if (!/^\d{13}$/.test(x)) return false; let sum = 0; for (let i = 0; i < 12; i++) sum += Number(x[i]) * (13 - i); return (11 - (sum % 11)) % 10 === Number(x[12]); };
        if (!c && C.askCid === 'required') { setErr('cid', t.required); ok = false; } else if (c && !(thai(c) || (/^[0-9A-Z]{5,20}$/.test(c) && /[A-Z]/.test(c)))) { setErr('cid', t.cidBad); ok = false; } else setErr('cid', '');
      }
      if (!S.form.name && !(S.id && S.id.name)) { setErr('name', t.required); ok = false; } else setErr('name', '');
      if (S.form.phone.replace(/\D/g, '').length < 9) { setErr('phone', t.required); ok = false; } else setErr('phone', '');
      if (C.requireEmail && !S.form.email && !(S.id && S.id.has_email)) { setErr('email', t.required); ok = false; } else setErr('email', '');
      return ok;
    }, stepConfirm);
  }
  const idText = (r) => (r.name ? `<span class="ok">✓ ${esc(t.found.replace('%s', r.name))}</span> ` : '') + (r.verified ? '' : `<span class="warn">${esc(r.name ? t.manualNote : t.unverified)}</span>`);
  function setErr(f, msg) { const el = root.querySelector(`[data-f="${f}"]`); if (!el) return; el.classList.toggle('err', !!msg); const em = el.querySelector('em'); if (em) em.textContent = msg || ''; }
  const navBtns = (next) => `<div class="idev-appt-nav"><button type="button" class="idev-appt-btn ghost" data-back>← ${esc(t.back)}</button>${next ? `<button type="button" class="idev-appt-btn" data-next>${esc(t.next)} →</button>` : ''}</div>`;
  function bindNav(validate, nextFn) {
    root.querySelector('[data-back]').addEventListener('click', () => { if (S.cur === 'agree') stepPatient(); else if (TF && S.service && S.provider && kids(S.service).length) { S.provider = null; stepWhoAt(); } else stepTime(); });
    const n = root.querySelector('[data-next]');
    if (n) n.addEventListener('click', async () => { if (await validate()) nextFn(); });
    root.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ---------- step 6: service agreement and send ---------- */
  function stepConfirm() {
    go('agree');
    const f = S.form;
    view(bar() + `<section class="idev-appt-card"><h2>${esc(t.summary)}</h2><div class="idev-appt-summary">${S.service && S.service.id !== S.provider.id ? `<p class="idev-appt-crumb">${esc(S.service.name)}</p>` : ''}${provCard(S.provider)}
      <dl><dt>${esc(t.chooseTime)}</dt><dd>${esc(fmtDay(S.date))} · ${esc(S.slot.start)}–${esc(S.slot.end)}</dd><dt>${esc(S.idType === 'reg' ? t.reg : t.hn)}</dt><dd>${esc(f.number)}</dd>
      <dt>${esc(t.name)}</dt><dd>${esc(f.name || (S.id && S.id.name) || '')}</dd>${f.cid ? `<dt>${esc(t.cid)}</dt><dd>${esc(f.cid.replace(/^(\d)(\d{4})(\d{5})(\d{2})(\d)$/, '$1 $2 $3 $4 $5'))}</dd>` : ''}<dt>${esc(t.phone)}</dt><dd>${esc(f.phone)}</dd>${f.email ? `<dt>E-mail</dt><dd>${esc(f.email)}</dd>` : ''}${f.reason ? `<dt>${esc(t.reason)}</dt><dd>${esc(f.reason)}</dd>` : ''}</dl></div>
      <h3>${esc(t.agreeTitle)}</h3><div class="idev-appt-consent">${esc(C.consent).replace(/\n/g, '<br>')}${C.privacy ? ` <a href="${esc(C.privacy)}" target="_blank" rel="noopener">${esc(t.privacy)} ↗</a>` : ''}</div>
      <label class="idev-appt-check" data-f="consent"><input type="checkbox" name="consent"> <span>${esc(t.consentCheck)}</span><em></em></label>
      <input type="text" name="website" class="idev-appt-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
      <p class="idev-appt-err" role="alert"></p>
      <div class="idev-appt-nav"><button type="button" class="idev-appt-btn ghost" data-back>← ${esc(t.back)}</button><button type="button" class="idev-appt-btn" data-book>${esc(t.book)}</button></div></section>`);
    root.querySelector('[data-back]').addEventListener('click', stepPatient);
    root.querySelector('[name="consent"]').addEventListener('change', (e) => { if (e.target.checked) setErr('consent', ''); });
    root.querySelector('[data-book]').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      if (!root.querySelector('[name="consent"]').checked) { setErr('consent', t.required); return; }
      btn.disabled = true; btn.textContent = t.sending;
      try {
        const r = await post('book', { provider: S.provider.id, date: S.date, start: S.slot.start, type: S.idType, number: f.number, dob: f.dob, name: f.name, phone: f.phone, email: f.email, cid: f.cid, reason: f.reason, consent: 1, website: root.querySelector('[name="website"]').value });
        if (!r.ok) {
          btn.disabled = false; btn.textContent = t.book;
          if (r.field === 'slot' || r.field === 'duplicate') { root.querySelector('.idev-appt-err').textContent = r.error; S.slot = null; setTimeout(stepTime, 2200); return; }
          if (r.field === 'cid' || r.field === 'name' || r.field === 'phone' || r.field === 'email') { stepPatient(); setErr(r.field, r.error); return; }
          root.querySelector('.idev-appt-err').textContent = r.error || t.error; return;
        }
        done(r);
      } catch (err) { btn.disabled = false; btn.textContent = t.book; root.querySelector('.idev-appt-err').textContent = t.error; }
    });
    root.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function apptCard(a) {
    return `<div class="idev-appt-ticket status-${esc(a.status)}"><div class="idev-appt-ticket-head"><span class="idev-appt-status">${esc(a.status_label)}</span><span>${esc(t.ref)} <strong>${esc(a.ref)}</strong></span></div>
      ${a.provider ? provCard(a.provider) : ''}<div class="idev-appt-ticket-when"><strong>${esc(a.date_label)}</strong><span>${esc(a.start)}–${esc(a.end)}</span></div></div>`;
  }
  function done(r) {
    const a = r.appt;
    const ok = a.status === 'confirmed';
    view(`<section class="idev-appt-card idev-appt-done"><div class="idev-appt-done-icon ${ok ? '' : 'wait'}">${ok ? '✓' : '⏳'}</div><h2>${esc(ok ? t.doneConfirmed : t.donePending)}</h2>${ok ? '' : `<p>${esc(t.donePendingText)}</p>`}${r.emailed ? `<p>${esc(t.emailed)}</p>` : ''}
      ${apptCard(a)}<p class="idev-appt-save">${esc(t.saveLink)}</p><div class="idev-appt-linkrow"><input readonly value="${esc(r.manage_url)}"><button type="button" class="idev-appt-btn ghost" data-copy>${esc(t.copy)}</button></div>
      <div class="idev-appt-nav center"><a class="idev-appt-btn ghost" href="${esc(a.ics)}">${esc(t.calendar)}</a><a class="idev-appt-btn ghost" href="${esc(r.manage_url)}">${esc(t.manage)}</a><button type="button" class="idev-appt-btn" data-again>${esc(t.another)}</button></div></section>`);
    root.querySelector('[data-copy]').addEventListener('click', (e) => { const i = root.querySelector('.idev-appt-linkrow input'); i.select(); (navigator.clipboard ? navigator.clipboard.writeText(i.value) : Promise.resolve(document.execCommand('copy'))).then(() => { e.target.textContent = t.copied; }); });
    root.querySelector('[data-again]').addEventListener('click', () => { S.slot = null; S.date = ''; S.form = null; S.id = null; if (C.fixed) { if (group() || (TF && S.service && kids(S.service).length)) S.provider = null; stepDay(); } else { S.provider = null; S.service = null; stepProvider(); } });
    root.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ---------- manage (link from the e-mail) ---------- */
  async function manage() {
    view('<div class="idev-appt-loading"></div>');
    let a;
    try { a = await api('manage?t=' + C.manage); } catch (e) { view(`<section class="idev-appt-card"><p>${esc(t.notFound)}</p></section>`); return; }
    if (!a || !a.ref) { view(`<section class="idev-appt-card"><p>${esc(t.notFound)}</p></section>`); return; }
    view(`<section class="idev-appt-card">${apptCard(a)}
      <div class="idev-appt-nav center">${a.status === 'confirmed' || a.status === 'pending' ? `<a class="idev-appt-btn ghost" href="${esc(a.ics)}">${esc(t.calendar)}</a>` : ''}${a.can_move ? `<button type="button" class="idev-appt-btn ghost" data-move>${esc(t.move)}</button>` : ''}${a.can_change ? `<button type="button" class="idev-appt-btn danger" data-cancel>${esc(t.cancel)}</button>` : ''}</div>
      ${!a.can_change && (a.status === 'confirmed' || a.status === 'pending') ? `<p class="idev-appt-hint">${esc(t.noChange)}${C.phone ? ` <a href="tel:${esc(C.phone.replace(/[^\d+]/g, ''))}">${esc(C.phone)}</a>` : ''}</p>` : ''}<div class="idev-appt-manage"></div></section>`);
    const box = root.querySelector('.idev-appt-manage');
    const c = root.querySelector('[data-cancel]');
    if (c) c.addEventListener('click', () => {
      box.innerHTML = `<div class="idev-appt-confirmbox"><strong>${esc(t.cancelAsk)}</strong><label class="idev-appt-f"><span>${esc(t.cancelReason)}</span><input name="reason"></label><div class="idev-appt-nav"><button type="button" class="idev-appt-btn ghost" data-keep>${esc(t.keep)}</button><button type="button" class="idev-appt-btn danger" data-yes>${esc(t.yesCancel)}</button></div></div>`;
      box.querySelector('[data-keep]').addEventListener('click', () => { box.innerHTML = ''; });
      box.querySelector('[data-yes]').addEventListener('click', async () => { const r = await post('manage/cancel', { t: C.manage, reason: box.querySelector('[name="reason"]').value }); if (r.ok) manage(); else box.insertAdjacentHTML('beforeend', `<p class="idev-appt-err">${esc(r.error || t.error)}</p>`); });
    });
    const mv = root.querySelector('[data-move]');
    if (mv) mv.addEventListener('click', async () => {
      const provs = await api('providers' + (C.branch ? '?branch=' + encodeURIComponent(C.branch) : ''));
      const p = provs.find((x) => a.provider && x.id === a.provider.id);
      if (!p) { box.innerHTML = `<p class="idev-appt-hint">${esc(t.noChange)}</p>`; return; }
      S.month = a.date.slice(0, 7); S.date = ''; S.slot = null;
      box.innerHTML = `<h3>${esc(t.moveTitle)}</h3><div class="idev-appt-when"></div><div class="idev-appt-movego"></div>`;
      calendar(box.querySelector('.idev-appt-when'), p, (date, slot) => {
        S.date = date; S.slot = slot;
        box.querySelectorAll('.idev-appt-times button').forEach((b) => b.classList.toggle('sel', b.dataset.s === slot.start));
        box.querySelector('.idev-appt-movego').innerHTML = `<div class="idev-appt-nav center"><button type="button" class="idev-appt-btn" data-go>${esc(t.confirmMove)}: ${esc(fmtDay(date))} ${esc(slot.start)}</button></div>`;
        box.querySelector('[data-go]').addEventListener('click', async () => { const r = await post('manage/move', { t: C.manage, date, start: slot.start }); if (r.ok) manage(); else box.querySelector('.idev-appt-movego').insertAdjacentHTML('beforeend', `<p class="idev-appt-err">${esc(r.error || t.error)}</p>`); });
      });
    });
  }

  /* A link to one doctor / clinic opens at the right step. */
  async function start() {
    if (C.manage) return manage();
    if (!S.provider) return stepProvider();
    view(bar() + '<div class="idev-appt-loading"></div>');
    await loadProviders();
    const p = byId(S.provider.id) || S.provider;
    if (!p.parent && kids(p).length) { S.service = p; S.provider = null; return TF ? (S.date ? stepTime() : stepDay()) : stepChild(); }
    S.provider = p; S.service = p.parent ? byId(p.parent) || null : p;
    if (S.date) return stepTime();
    return stepDay();
  }
  start();
})();
