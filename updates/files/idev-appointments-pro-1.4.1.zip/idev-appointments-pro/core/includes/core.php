<?php
/**
 * Appointments: data, booking rules, time slots and capacity, patient identification.
 */
defined('ABSPATH') || exit;

function idev_appt_table() { global $wpdb; return $wpdb->prefix . 'idev_appointments'; }

function idev_appt_statuses() {
    return [
        'pending' => __('Waiting for confirmation', 'idev-appointments'),
        'confirmed' => __('Confirmed', 'idev-appointments'),
        'cancelled' => __('Cancelled', 'idev-appointments'),
        'completed' => __('Done', 'idev-appointments'),
        'no_show' => __('Did not come', 'idev-appointments'),
    ];
}
function idev_appt_active_statuses() { return ['pending', 'confirmed']; }

function idev_appt_install() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta('CREATE TABLE ' . idev_appt_table() . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  ref varchar(24) NOT NULL,
  provider_id bigint(20) unsigned NOT NULL,
  appt_date date NOT NULL,
  start_time char(5) NOT NULL,
  end_time char(5) NOT NULL,
  status varchar(16) NOT NULL DEFAULT 'pending',
  patient_key char(64) NOT NULL DEFAULT '',
  reg_ref varchar(24) NOT NULL DEFAULT '',
  verified tinyint(1) NOT NULL DEFAULT 0,
  data longtext NOT NULL,
  manage_hash char(64) NOT NULL DEFAULT '',
  reminders varchar(60) NOT NULL DEFAULT '',
  reschedules tinyint(3) unsigned NOT NULL DEFAULT 0,
  source varchar(12) NOT NULL DEFAULT 'web',
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY ref (ref),
  KEY slot (provider_id, appt_date, start_time),
  KEY appt_date (appt_date, status),
  KEY patient_key (patient_key),
  KEY manage_hash (manage_hash)
) " . $wpdb->get_charset_collate() . ';');
    if (!get_role('idev_doctor')) add_role('idev_doctor', __('Doctor (appointments)', 'idev-appointments'), ['read' => true, 'idev_appt_doctor' => true]);
    if (!get_role('idev_appt_staff')) add_role('idev_appt_staff', __('Appointment staff', 'idev-appointments'), ['read' => true, 'idev_appt_manage' => true]);
    foreach (['administrator', 'editor'] as $r) { $role = get_role($r); if ($role && !$role->has_cap('idev_appt_manage')) $role->add_cap('idev_appt_manage'); }
    if (!wp_next_scheduled('idev_appt_cron')) wp_schedule_event(time() + 300, 'hourly', 'idev_appt_cron');
    update_option('idev_appt_db', IDEV_APPT_VERSION, false);
}
add_action('plugins_loaded', function () { if (get_option('idev_appt_db') !== IDEV_APPT_VERSION) idev_appt_install(); });

add_action('init', function () {
    load_plugin_textdomain('idev-appointments', false, dirname(plugin_basename(IDEV_APPT_FILE)) . '/languages');
    idev_register_plugin('idev-appointments', ['name' => 'iDev Appointments', 'version' => IDEV_APPT_VERSION, 'description' => __('Online appointments with doctors and clinics.', 'idev-appointments'), 'settings' => admin_url('admin.php?page=idev-appt-settings'), 'docs' => 'https://idevapp.me/plugins/idev-appointments']);
});
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_APPT_FILE, admin_url('admin.php?page=idev-appt-settings'), 'https://idevapp.me/plugins/idev-appointments'); });
add_action('admin_notices', function () {
    if (function_exists('idev_cs_providers') || !current_user_can('activate_plugins')) return;
    echo '<div class="notice notice-error"><p>' . esc_html__('iDev Appointments needs the iDev Clinic Schedule plugin (doctors, clinics and their times). Please install and activate it.', 'idev-appointments') . '</p></div>';
});

/* ---------- Encryption (patient details and reasons for the visit are health data) ---------- */

function idev_appt_key() { return hash('sha256', 'idev-medreg|' . (defined('AUTH_KEY') ? AUTH_KEY : '') . '|' . (defined('SECURE_AUTH_KEY') ? SECURE_AUTH_KEY : ''), true); }
/** Uses the key ring of iDev Patient Registration when it is active, so both plugins share one key. */
function idev_appt_encrypt($plain) {
    if (function_exists('idev_medreg_encrypt')) return idev_medreg_encrypt($plain);
    $k = idev_appt_key();
    $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
    return 'k1:' . substr(hash('sha256', 'idev-medreg-id|' . $k), 0, 8) . ':' . base64_encode($nonce . sodium_crypto_secretbox((string) $plain, $nonce, $k));
}
function idev_appt_decrypt($cipher) {
    if (function_exists('idev_medreg_decrypt')) return idev_medreg_decrypt($cipher);
    if (!preg_match('/^k1:[0-9a-f]{8}:(.+)$/s', (string) $cipher, $m)) return null;
    $raw = base64_decode($m[1], true);
    if ($raw === false || strlen($raw) < 40) return null;
    $p = sodium_crypto_secretbox_open(substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), idev_appt_key());
    return $p === false ? null : $p;
}
function idev_appt_hash($text) {
    $secret = get_option('idev_appt_hash_secret');
    if (!$secret) { $secret = bin2hex(random_bytes(32)); update_option('idev_appt_hash_secret', $secret, false); }
    return hash_hmac('sha256', strtoupper(preg_replace('/\s+/', '', (string) $text)), $secret);
}

/* ---------- Records ---------- */

function idev_appt_get($id) {
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_appt_table() . ' WHERE id=%d', $id), ARRAY_A);
    return $row ? idev_appt_hydrate($row) : null;
}
function idev_appt_get_by_token($token) {
    global $wpdb;
    if (!preg_match('/^[0-9a-f]{40}$/', (string) $token)) return null;
    $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_appt_table() . ' WHERE manage_hash=%s', hash('sha256', $token)), ARRAY_A);
    return $row ? idev_appt_hydrate($row) : null;
}
function idev_appt_hydrate($row) {
    $plain = idev_appt_decrypt($row['data']);
    $row['p'] = $plain !== null ? (json_decode($plain, true) ?: []) : [];
    $row['readable'] = $plain !== null;
    return $row;
}
function idev_appt_save($id, $p, $fields = []) {
    global $wpdb;
    $wpdb->update(idev_appt_table(), ['data' => idev_appt_encrypt(wp_json_encode($p, JSON_UNESCAPED_UNICODE)), 'updated_at' => current_time('mysql', true)] + $fields, ['id' => (int) $id]);
}
function idev_appt_log(&$p, $text, $who = null) {
    if ($who === null) { $u = wp_get_current_user(); $who = $u && $u->ID ? $u->user_login : 'patient'; }
    $p['_log'][] = [gmdate('c'), $who, $text];
}

/* ---------- HN check by the medical records desk ---------- */

/** Who may check HNs: appointment staff or medical records staff. */
function idev_appt_can_check_hn() { return current_user_can('idev_appt_manage') || current_user_can('idev_medreg'); }
/**
 * The records desk confirms (or corrects) the HN a patient gave when booking. Marks the appointment as checked;
 * add-ons (HOSxP connector) send it on via the idev_appt_hn_checked action.
 */
function idev_appt_set_hn($id, $hn) {
    $a = idev_appt_get($id);
    if (!$a || !$a['readable']) return new WP_Error('missing', __('Appointment not found.', 'idev-appointments'));
    $hn = strtoupper(preg_replace('/[^0-9A-Za-z-]/', '', (string) $hn));
    if ($hn === '' || strlen($hn) > 20) return new WP_Error('hn', __('Please enter the HN.', 'idev-appointments'));
    $p = $a['p'];
    $old = (string) ($p['hn'] ?? '');
    $p['hn'] = $hn;
    idev_appt_log($p, $old !== '' && $old !== $hn ? 'แก้ HN จาก ' . $old . ' เป็น ' . $hn . ' (ตรวจสอบแล้ว)' : 'ตรวจสอบ HN ' . $hn . ' แล้ว');
    idev_appt_save($a['id'], $p, ['verified' => 1, 'patient_key' => idev_appt_hash('HN|' . $hn)]);
    do_action('idev_appt_hn_checked', (int) $a['id'], $hn);
    return true;
}
/** Appointments whose HN was checked (from $days ago on), newest first, to correct an HN. $q filters by name / HN / ID / ref. */
function idev_appt_checked($days = 30, $q = '', $limit = 200) {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . idev_appt_table() . " WHERE verified=1 AND appt_date >= %s ORDER BY appt_date DESC, start_time DESC LIMIT %d", idev_add_days(idev_today(), -(int) $days), $q !== '' ? 2000 : $limit), ARRAY_A);
    return idev_appt_filter_rows(array_map('idev_appt_hydrate', $rows), $q, $limit);
}
/** Appointments booked with an online registration (REG-…), any status, from $days ago on — for the records desk to recheck. */
function idev_appt_with_registration($days = 30, $q = '', $limit = 200) {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . idev_appt_table() . " WHERE reg_ref<>'' AND appt_date >= %s ORDER BY appt_date, start_time LIMIT 2000", idev_add_days(idev_today(), -(int) $days)), ARRAY_A);
    return idev_appt_filter_rows(array_map('idev_appt_hydrate', $rows), $q, $limit);
}
function idev_appt_filter_rows($items, $q, $limit) {
    $q = mb_strtolower(trim((string) $q));
    if ($q !== '') $items = array_values(array_filter($items, function ($a) use ($q) { $p = $a['p']; return strpos(mb_strtolower(($p['name'] ?? '') . ' ' . ($p['hn'] ?? '') . ' ' . ($p['cid'] ?? '') . ' ' . ($p['phone'] ?? '') . ' ' . $a['ref'] . ' ' . $a['reg_ref']), $q) !== false; }));
    return array_slice($items, 0, $limit);
}
/** The records desk rechecked the data of a patient who registered online and booked. */
function idev_appt_mark_rechecked($id) {
    $a = idev_appt_get($id);
    if (!$a || !$a['readable']) return new WP_Error('missing', __('Appointment not found.', 'idev-appointments'));
    $p = $a['p'];
    $u = wp_get_current_user();
    $p['rechecked'] = ['by' => $u->display_name, 'at' => current_time('mysql')];
    idev_appt_log($p, 'ห้องบัตรตรวจข้อมูลผู้ลงทะเบียนแล้ว');
    idev_appt_save($a['id'], $p);
    return true;
}
/** Appointments from today on whose HN has not been checked yet (not cancelled). */
function idev_appt_unchecked($limit = 300) {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . idev_appt_table() . " WHERE verified=0 AND status IN ('pending','confirmed') AND appt_date >= %s ORDER BY appt_date, start_time LIMIT %d", idev_today(), $limit), ARRAY_A);
    return array_map('idev_appt_hydrate', $rows);
}

/* ---------- Providers ---------- */

function idev_appt_pmeta($id, $k, $default = '') { $v = get_post_meta($id, "_idev_appt_{$k}", true); return $v === '' ? $default : $v; }
function idev_appt_provider_cfg($id) {
    $s = idev_appt_settings();
    $users = get_post_meta($id, '_idev_appt_users', true);
    $parent = (int) idev_appt_pmeta($id, 'parent', '0');
    if ($parent === (int) $id) $parent = 0;
    // A doctor / staff / sub-service with an empty field uses the value of its clinic / service, then the settings.
    $pm = function ($k, $default) use ($id, $parent) {
        $v = idev_appt_pmeta($id, $k);
        if ($v === '' && $parent) $v = idev_appt_pmeta($parent, $k);
        return $v === '' ? $default : $v;
    };
    return [
        'on' => idev_appt_pmeta($id, 'on', $s['default_on']) === '1',
        'minutes' => max(5, (int) $pm('minutes', $s['slot_minutes'])),
        'capacity' => max(1, (int) $pm('capacity', $s['capacity'])),
        'confirm' => in_array($pm('confirm', ''), ['auto', 'manual'], true) ? $pm('confirm', '') : $s['confirm'],
        'users' => is_array($users) ? array_map('intval', $users) : [],
        'off' => array_values(array_filter((array) json_decode((string) idev_appt_pmeta($id, 'off', '[]'), true), 'idev_is_valid_date')),
        'note' => idev_appt_pmeta($id, 'note'), 'note_en' => idev_appt_pmeta($id, 'note_en'),
        // 1.4: clinic / service → doctor / staff / sub-service
        'parent' => $parent,
        'role' => in_array(idev_appt_pmeta($id, 'role'), ['doctor', 'staff', 'service'], true) ? idev_appt_pmeta($id, 'role') : '',
        'break' => max(0, min(120, (int) $pm('break', $s['break_minutes']))),
        'cap_mode' => idev_appt_pmeta($id, 'cap_mode') === 'shared' ? 'shared' : 'own',
    ];
}
/** Valid Thai ID number (13 digits, check digit) — also in iDev Patient Registration. */
function idev_appt_valid_cid($cid) {
    if (function_exists('idev_valid_thai_id')) return idev_valid_thai_id($cid);
    if (!preg_match('/^\d{13}$/', $cid)) return false;
    $sum = 0;
    for ($i = 0; $i < 12; $i++) $sum += (int) $cid[$i] * (13 - $i);
    return (11 - $sum % 11) % 10 === (int) $cid[12];
}
/** Thai ID or passport number given when booking: [clean value, error or '']. */
function idev_appt_clean_cid($raw, $lang = 'th') {
    $v = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string) $raw));
    if ($v === '') return ['', ''];
    if (preg_match('/^\d{13}$/', $v)) return idev_appt_valid_cid($v) ? [$v, ''] : ['', $lang === 'en' ? 'Invalid Thai ID number' : 'เลขบัตรประชาชนไม่ถูกต้อง'];
    if (preg_match('/^[0-9A-Z]{5,20}$/', $v) && preg_match('/[A-Z]/', $v)) return [$v, '']; // passport
    return ['', $lang === 'en' ? 'Please enter a 13-digit Thai ID or a passport number' : 'กรุณากรอกเลขบัตรประชาชน 13 หลัก หรือเลขหนังสือเดินทาง'];
}
/** Bookable doctors / clinics (iDev Clinic Schedule) with their booking settings. */
function idev_appt_providers() { return idev_appt_providers_all(); }
/** Doctors/clinics with booking switched on. */
function idev_appt_providers_all() {
    if (!function_exists('idev_cs_providers')) return [];
    $out = [];
    static $cache = null;
    if ($cache !== null) return $cache;
    $all = [];
    foreach (idev_cs_providers() as $p) $all[(int) $p['id']] = $p;
    foreach ($all as $id => $p) {
        $cfg = idev_appt_provider_cfg($id);
        if ($cfg['parent'] && (!isset($all[$cfg['parent']]) || $cfg['parent'] === $id)) $cfg['parent'] = 0;
        // a doctor / staff / sub-service without its own clinic times uses the times of its clinic / service
        if (!$p['slots'] && $cfg['parent']) { $p['slots'] = $all[$cfg['parent']]['slots']; $p['inherit_slots'] = true; }
        if ($cfg['on'] && $p['slots']) $out[] = $p + ['appt' => $cfg, 'slug' => idev_appt_slug($p)];
    }
    return $cache = $out;
}
/** Short address name: the post slug, or the English name when the slug is in Thai (nicer, shareable links). */
function idev_appt_slug($p) {
    $slug = urldecode((string) get_post_field('post_name', $p['id']));
    if (preg_match('/[^\x00-\x7F]/', $slug) && !empty($p['name_en'])) $slug = sanitize_title($p['name_en']);
    return $slug;
}
function idev_appt_provider($id_or_slug) {
    $key = mb_strtolower(urldecode(trim((string) $id_or_slug, '/')));
    if ($key === '') return null;
    foreach (idev_appt_providers() as $p) {
        if ((string) $p['id'] === $key || mb_strtolower($p['slug']) === $key || mb_strtolower(urldecode((string) get_post_field('post_name', $p['id']))) === $key) return $p;
    }
    return null;
}
function idev_appt_provider_name($p, $lang = null) { return idev_pick($p['name'], $p['name_en'], $lang); }
/** Doctors linked to the logged-in user (portal). */
function idev_appt_user_providers($user_id = null) {
    $user_id = $user_id ?: get_current_user_id();
    if (!$user_id) return [];
    /** Filter: the doctors/clinics a user may see in the portal (add-ons limit staff to their branches). */
    if (user_can($user_id, 'idev_appt_manage')) return apply_filters('idev_appt_user_providers', array_column(function_exists('idev_cs_providers') ? idev_cs_providers(true) : [], 'id'), $user_id);
    $ids = [];
    foreach (get_posts(['post_type' => 'idev_provider', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => '_idev_appt_users', 'meta_compare' => 'EXISTS']) as $pid) {
        if (in_array((int) $user_id, idev_appt_provider_cfg($pid)['users'], true)) $ids[] = (int) $pid;
    }
    // Doctors may also see the appointments of their whole clinic / service (setting, or per doctor).
    $global = idev_appt_settings()['doctor_scope'];
    foreach ($ids as $pid) {
        $scope = idev_appt_pmeta($pid, 'scope') ?: $global;
        if ($scope !== 'clinic') continue;
        $parent = idev_appt_provider_cfg($pid)['parent'] ?: $pid;
        $ids[] = (int) $parent;
        foreach (get_posts(['post_type' => 'idev_provider', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => '_idev_appt_parent', 'meta_value' => (string) $parent]) as $sib) $ids[] = (int) $sib;
    }
    return apply_filters('idev_appt_user_providers', array_values(array_unique($ids)), $user_id);
}

/* ---------- Time slots ---------- */

function idev_appt_now() { return new DateTimeImmutable('now', wp_timezone()); }
function idev_appt_slot_ts($date, $time) { return (new DateTimeImmutable($date . ' ' . $time, wp_timezone()))->getTimestamp(); }

/** Taken places per start time for one provider and date. */
function idev_appt_taken($provider_ids, $date, $exclude_id = 0) {
    global $wpdb;
    $in = implode(',', array_map('intval', (array) $provider_ids)) ?: '0';
    $rows = $wpdb->get_results($wpdb->prepare('SELECT start_time, COUNT(*) n FROM ' . idev_appt_table() . " WHERE provider_id IN ({$in}) AND appt_date=%s AND status IN ('pending','confirmed') AND id<>%d GROUP BY start_time", $date, $exclude_id), ARRAY_A);
    return array_column($rows, 'n', 'start_time');
}
/** Doctors / staff / sub-services under a clinic or service. */
function idev_appt_children($parent_id) {
    $out = [];
    foreach (idev_appt_providers_all() as $p) if ((int) $p['appt']['parent'] === (int) $parent_id) $out[] = $p;
    return $out;
}
/** Bookable members of a clinic / service: the ones under it, and the clinic / service itself when it has its own times. */
function idev_appt_group_members($service_id) {
    $out = idev_appt_children($service_id);
    foreach (idev_appt_providers_all() as $p) if ((int) $p['id'] === (int) $service_id && empty($p['inherit_slots'])) array_unshift($out, $p);
    if (!$out) { $p = idev_appt_provider($service_id); if ($p) $out[] = $p; }
    return $out;
}
/** [capacity per slot, provider ids that share it]. */
function idev_appt_capacity_scope($provider, $cfg) {
    $pid = (int) ($cfg['parent'] ?? 0);
    if ($pid) {
        $pcfg = idev_appt_provider_cfg($pid);
        if ($pcfg['cap_mode'] === 'shared') return [$pcfg['capacity'], array_merge([$pid], array_map('intval', array_column(idev_appt_children($pid), 'id')))];
    } elseif (($cfg['cap_mode'] ?? 'own') === 'shared') {
        return [$cfg['capacity'], array_merge([(int) $provider['id']], array_map('intval', array_column(idev_appt_children($provider['id']), 'id')))];
    }
    return [$cfg['capacity'], [(int) $provider['id']]];
}
/** Days off of the clinic / service also close its doctors / staff / sub-services. */
function idev_appt_parent_off($cfg) {
    return !empty($cfg['parent']) ? idev_appt_provider_cfg((int) $cfg['parent'])['off'] : [];
}

/**
 * Time slots of a provider on a date: [start, end, capacity, left, open].
 * $staff = true ignores lead time and the booking window (staff may also overbook).
 */
function idev_appt_slots($provider, $date, $staff = false, $exclude_id = 0) {
    if (!$provider || !idev_is_valid_date($date)) return [];
    $s = idev_appt_settings();
    $cfg = $provider['appt'] ?? idev_appt_provider_cfg($provider['id']);
    if (in_array($date, $cfg['off'], true)) return [];
    if (function_exists('idev_holiday_closed') && idev_holiday_closed($date)) return [];
    $today = idev_today();
    if (!$staff && ($date < $today || $date > idev_add_days($today, (int) $s['max_days']))) return [];
    $earliest = idev_appt_now()->getTimestamp() + ($staff ? 0 : (int) $s['lead_hours'] * HOUR_IN_SECONDS);
    // Places per slot: this doctor / staff / sub-service, or shared by the whole clinic / service (its setting).
    [$capacity, $ids] = idev_appt_capacity_scope($provider, $cfg);
    if (in_array($date, idev_appt_parent_off($cfg), true)) return [];
    $taken = idev_appt_taken($ids, $date, $exclude_id);
    $step = ($cfg['minutes'] + $cfg['break']) * 60;
    $out = [];
    foreach ($provider['slots'] as $session) {
        if (!function_exists('idev_cs_occurs_on') || !idev_cs_occurs_on($session, $date)) continue;
        $t = idev_appt_slot_ts($date, $session['start_time']);
        $end = idev_appt_slot_ts($date, $session['end_time']);
        for (; $t + $cfg['minutes'] * 60 <= $end; $t += $step) {
            $start = wp_date('H:i', $t);
            $left = $capacity - (int) ($taken[$start] ?? 0);
            $out[$start] = ['start' => $start, 'end' => wp_date('H:i', $t + $cfg['minutes'] * 60), 'capacity' => $capacity, 'left' => max(0, $left), 'open' => $t >= $earliest && $left > 0, 'past' => $t < idev_appt_now()->getTimestamp()];
        }
    }
    ksort($out);
    return array_values($out);
}
/** Days of a month with free places: [date => free places]. */
function idev_appt_month($provider, $month, $staff = false) {
    if (!preg_match('/^\d{4}-\d{2}$/', $month)) return [];
    $out = [];
    $d = $month . '-01';
    while (substr($d, 0, 7) === $month) {
        $slots = idev_appt_slots($provider, $d, $staff);
        if ($slots) $out[$d] = array_sum(array_map(function ($x) { return $x['open'] ? $x['left'] : 0; }, $slots));
        $d = idev_add_days($d, 1);
    }
    return $out;
}
function idev_appt_slot_open($provider, $date, $start, $staff = false, $exclude_id = 0) {
    foreach (idev_appt_slots($provider, $date, $staff, $exclude_id) as $sl) if ($sl['start'] === $start) return $staff ? $sl : ($sl['open'] ? $sl : null);
    return null;
}

/* ---------- Patients: HN or online registration (iDev Patient Registration) ---------- */

/**
 * Checks who is booking. $type: hn | reg. Returns [ok, data] where data has: verified, hn, reg_ref, name, email, phone, patient_key, or an error message.
 */
function idev_appt_identify($type, $number, $dob, $lang = 'th') {
    $s = idev_appt_settings();
    $en = $lang === 'en';
    $m = function ($th, $en_text) use ($en) { return $en ? $en_text : $th; };
    $number = strtoupper(trim(preg_replace('/\s+/', '', (string) $number)));
    if (!idev_is_valid_date($dob)) return [false, $m('กรุณาระบุวันเกิด', 'Please enter your date of birth')];
    $rate = 'idev_appt_id_' . md5(sanitize_text_field(wp_unslash($_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? '')));
    $n = (int) get_transient($rate);
    if ($n >= 20) return [false, $m('ตรวจสอบบ่อยเกินไป กรุณาลองใหม่ภายหลัง', 'Too many attempts. Please try again later.')];
    set_transient($rate, $n + 1, HOUR_IN_SECONDS);
    $found = idev_appt_find_registration($type, $number);
    if ($type === 'reg') {
        if (!$found) return [false, $m('ไม่พบเลขอ้างอิงการลงทะเบียนนี้', 'We could not find this registration reference')];
        if (($found['person']['birthdate'] ?? '') !== $dob) return [false, $m('เลขอ้างอิงและวันเกิดไม่ตรงกัน', 'The reference and date of birth do not match')];
        // Any registration status may book (the records desk rechecks the data). Only an HN that was issued counts as checked.
        return [true, idev_appt_identity_from($found, $found['status'] === 'synced' && $found['hn'] !== '')];
    }
    if (!preg_match('/^[0-9A-Z-]{3,20}$/', $number)) return [false, $m('กรุณาระบุ HN ให้ถูกต้อง', 'Please enter a valid HN')];
    if ($found) {
        if (($found['person']['birthdate'] ?? '') !== $dob) return [false, $m('HN และวันเกิดไม่ตรงกัน', 'The HN and date of birth do not match')];
        return [true, idev_appt_identity_from($found, true)];
    }
    if ($s['identity'] === 'registered') return [false, $m('ไม่พบ HN นี้ในระบบออนไลน์ กรุณาลงทะเบียนก่อน หรือโทรนัดหมาย', 'This HN is not in our online system. Please register first or call us to book.')];
    // Existing hospital patient not registered online: accepted, checked by staff (always manual confirmation).
    return [true, ['verified' => false, 'hn' => $number, 'reg_ref' => '', 'name' => '', 'email' => '', 'phone' => '', 'dob' => $dob, 'patient_key' => idev_appt_hash('HN|' . $number)]];
}
function idev_appt_find_registration($type, $number) {
    if (!function_exists('idev_medreg_table') || $number === '') return null;
    global $wpdb;
    $col = $type === 'reg' ? 'ref' : 'hn';
    $row = $wpdb->get_row($wpdb->prepare('SELECT id FROM ' . idev_medreg_table() . " WHERE {$col}=%s ORDER BY id DESC LIMIT 1", $number), ARRAY_A);
    if (!$row) return null;
    $r = idev_medreg_get((int) $row['id']);
    return $r && $r['readable'] ? $r : null;
}
function idev_appt_identity_from($r, $verified) {
    $p = $r['person'];
    $key = $r['hn'] !== '' ? 'HN|' . strtoupper($r['hn']) : 'REG|' . $r['ref'];
    return ['verified' => $verified, 'hn' => $r['hn'], 'reg_ref' => $r['ref'], 'name' => function_exists('idev_medreg_name') ? idev_medreg_name($p) : '', 'email' => $p['email'] ?? '', 'phone' => $p['phone'] ?? '', 'dob' => $p['birthdate'] ?? '', 'cid' => (string) ($p['cid'] ?? '') ?: (string) ($p['passport_no'] ?? ''), 'patient_key' => idev_appt_hash($key)];
}
/** "นาย สมชาย ใจดี" → "นาย สมชาย ใ•••" — enough for the patient to recognise, not enough to learn a stranger's name. */
function idev_appt_mask_name($name) {
    $parts = array_values(array_filter(preg_split('/\s+/u', trim((string) $name))));
    if (!$parts) return '';
    $titles = ['นาย', 'นาง', 'นางสาว', 'น.ส.', 'เด็กชาย', 'เด็กหญิง', 'ด.ช.', 'ด.ญ.', 'mr', 'mrs', 'ms', 'miss', 'master', 'dr', 'mr.', 'mrs.', 'ms.', 'dr.'];
    $out = [];
    if (in_array(mb_strtolower($parts[0]), $titles, true)) $out[] = array_shift($parts);
    if ($parts) { $first = array_shift($parts); $out[] = mb_strlen($first) <= 3 ? $first : mb_substr($first, 0, 3) . str_repeat('•', min(4, mb_strlen($first) - 3)); }
    foreach ($parts as $w) $out[] = mb_substr($w, 0, 1) . '•••';
    return implode(' ', $out);
}

/* When a registration gets its HN, appointments booked with the registration reference get it too. */
add_action('idev_medreg_hn_issued', function ($reg_id, $hn) {
    global $wpdb;
    $r = function_exists('idev_medreg_get') ? idev_medreg_get($reg_id) : null;
    if (!$r) return;
    foreach ($wpdb->get_col($wpdb->prepare('SELECT id FROM ' . idev_appt_table() . ' WHERE reg_ref=%s', $r['ref'])) as $id) {
        $a = idev_appt_get($id);
        if (!$a || !$a['readable']) continue;
        $a['p']['hn'] = $hn;
        idev_appt_log($a['p'], 'HN ' . $hn, 'system');
        idev_appt_save($id, $a['p'], ['patient_key' => idev_appt_hash('HN|' . strtoupper($hn))]);
    }
}, 10, 2);

/* ---------- Booking ---------- */

function idev_appt_new_ref() { return 'APT-' . wp_date('ymd') . '-' . strtoupper(wp_generate_password(5, false)); }

/**
 * Creates an appointment. $in: provider, date, start, patient (identity array), name, phone, email, reason, lang, consent, source.
 * Returns [id, token] or WP_Error.
 */
function idev_appt_create($in, $staff = false) {
    global $wpdb;
    $s = idev_appt_settings();
    $en = ($in['lang'] ?? 'th') === 'en';
    $m = function ($th, $en_text) use ($en) { return $en ? $en_text : $th; };
    $provider = idev_appt_provider($in['provider'] ?? 0);
    if (!$provider && $staff && function_exists('idev_cs_provider') && ($post = get_post((int) ($in['provider'] ?? 0))) && $post->post_type === 'idev_provider') $provider = idev_cs_provider($post) + ['appt' => idev_appt_provider_cfg($post->ID)];
    if (!$provider) return new WP_Error('provider', $m('ไม่พบแพทย์หรือคลินิกนี้', 'Doctor or clinic not found'));
    $id_data = $in['patient'];
    // one active appointment per patient per doctor per day, and a limit of upcoming appointments
    if (!$staff && $id_data['patient_key']) {
        $same = $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . idev_appt_table() . " WHERE patient_key=%s AND provider_id=%d AND appt_date=%s AND status IN ('pending','confirmed')", $id_data['patient_key'], $provider['id'], $in['date']));
        if ($same) return new WP_Error('duplicate', $m('คุณมีนัดกับแพทย์/คลินิกนี้ในวันนี้แล้ว', 'You already have an appointment with this doctor or clinic on this day'));
        $upcoming = $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . idev_appt_table() . " WHERE patient_key=%s AND appt_date>=%s AND status IN ('pending','confirmed')", $id_data['patient_key'], idev_today()));
        if ($upcoming >= (int) $s['max_upcoming']) return new WP_Error('limit', sprintf($m('มีนัดที่ยังไม่ถึงกำหนดครบ %d นัดแล้ว กรุณายกเลิกนัดเดิมก่อน หรือโทรติดต่อ', 'You already have %d upcoming appointments. Please cancel one first or call us.'), (int) $s['max_upcoming']));
    }
    $lock = 'idev_appt_lock_' . md5($provider['id'] . $in['date'] . $in['start']);
    for ($i = 0; $i < 20 && get_transient($lock); $i++) usleep(100000);
    set_transient($lock, 1, 10);
    try {
        $slot = idev_appt_slot_open($provider, $in['date'], $in['start'], $staff);
        if (!$slot) return new WP_Error('slot', $m('ช่วงเวลานี้เต็มหรือปิดรับแล้ว กรุณาเลือกเวลาอื่น', 'This time is full or no longer available. Please choose another time.'));
        $mode = $provider['appt']['confirm'];
        $status = ($staff || ($mode === 'auto' && $id_data['verified'])) ? 'confirmed' : 'pending';
        $token = bin2hex(random_bytes(20));
        $p = [
            'name' => mb_substr(sanitize_text_field($in['name'] ?: $id_data['name']), 0, 120), 'phone' => preg_replace('/[^\d+]/', '', (string) ($in['phone'] ?? '')), 'email' => sanitize_email($in['email'] ?? ''),
            'contact_email' => sanitize_email(($in['email'] ?? '') ?: $id_data['email']), 'dob' => $id_data['dob'], 'hn' => $id_data['hn'], 'reg_ref' => $id_data['reg_ref'],
            'reason' => mb_substr(sanitize_textarea_field($in['reason'] ?? ''), 0, 500), 'lang' => $en ? 'en' : 'th', 'verified' => (bool) $id_data['verified'],
            'cid' => idev_appt_clean_cid($in['cid'] ?? '')[0] ?: (string) ($id_data['cid'] ?? ''),
            'consent' => $staff ? null : ['version' => $s['consent_version'], 'at' => gmdate('c')],
        ];
        idev_appt_log($p, $staff ? 'จองโดยเจ้าหน้าที่' : 'จองออนไลน์', $staff ? null : 'patient');
        $now = current_time('mysql', true);
        $wpdb->insert(idev_appt_table(), [
            'ref' => idev_appt_new_ref(), 'provider_id' => $provider['id'], 'appt_date' => $in['date'], 'start_time' => $slot['start'], 'end_time' => $slot['end'], 'status' => $status,
            'patient_key' => $id_data['patient_key'], 'reg_ref' => $id_data['reg_ref'], 'verified' => $id_data['verified'] ? 1 : 0, 'data' => idev_appt_encrypt(wp_json_encode($p, JSON_UNESCAPED_UNICODE)),
            'manage_hash' => hash('sha256', $token), 'source' => $staff ? 'staff' : 'web', 'created_at' => $now, 'updated_at' => $now,
        ]);
        $id = (int) $wpdb->insert_id;
    } finally { delete_transient($lock); }
    if (!$id) return new WP_Error('db', $m('บันทึกไม่สำเร็จ กรุณาลองใหม่', 'Could not save. Please try again.'));
    idev_appt_set_token($id, $token);
    idev_appt_notify($id, $status === 'confirmed' ? 'confirmed' : 'received');
    idev_appt_notify_staff($id, 'new');
    do_action('idev_appt_created', $id, $status);
    return [$id, $token];
}
/** The manage link token is kept (encrypted) so later e-mails can include the link. */
function idev_appt_set_token($id, $token) { $a = idev_appt_get($id); if ($a) { $a['p']['_t'] = $token; idev_appt_save($id, $a['p']); } }
function idev_appt_token($a) { return (string) ($a['p']['_t'] ?? ''); }

/** Status changes: confirm, cancel, complete, no_show. $by = patient|staff. */
function idev_appt_set_status($id, $status, $by = 'staff', $reason = '') {
    $a = idev_appt_get($id);
    if (!$a || !isset(idev_appt_statuses()[$status])) return new WP_Error('bad', 'Not found');
    if ($a['status'] === $status) return true;
    $labels = ['confirmed' => 'ยืนยันนัด', 'cancelled' => 'ยกเลิก', 'completed' => 'มาตามนัด', 'no_show' => 'ไม่มาตามนัด', 'pending' => 'รอยืนยัน'];
    idev_appt_log($a['p'], ($labels[$status] ?? $status) . ($reason !== '' ? ': ' . $reason : ''), $by === 'patient' ? 'patient' : null);
    if ($status === 'cancelled') { $a['p']['cancel_reason'] = mb_substr($reason, 0, 300); $a['p']['cancelled_by'] = $by; }
    idev_appt_save($id, $a['p'], ['status' => $status]);
    if ($status === 'confirmed') idev_appt_notify($id, 'confirmed');
    if ($status === 'cancelled') { idev_appt_notify($id, 'cancelled'); if ($by === 'patient') idev_appt_notify_staff($id, 'cancelled'); }
    do_action('idev_appt_status', $id, $status, $by);
    return true;
}

/** Moves an appointment. Patients: within the rules; after a patient move, manual-confirm doctors must confirm again. */
function idev_appt_reschedule($id, $date, $start, $by = 'staff') {
    $a = idev_appt_get($id);
    if (!$a) return new WP_Error('bad', 'Not found');
    $staff = $by !== 'patient';
    $en = ($a['p']['lang'] ?? 'th') === 'en';
    $provider = idev_appt_provider($a['provider_id']);
    if (!$provider && $staff && function_exists('idev_cs_provider') && ($post = get_post($a['provider_id']))) $provider = idev_cs_provider($post) + ['appt' => idev_appt_provider_cfg($post->ID)];
    if (!$provider) return new WP_Error('provider', $en ? 'Doctor or clinic not available' : 'ไม่พบแพทย์หรือคลินิก');
    $slot = idev_appt_slot_open($provider, $date, $start, $staff, (int) $id);
    if (!$slot) return new WP_Error('slot', $en ? 'This time is full or not available.' : 'ช่วงเวลานี้เต็มหรือไม่เปิดรับ');
    $old = $a['appt_date'] . ' ' . $a['start_time'];
    $a['p']['previous'][] = $old;
    idev_appt_log($a['p'], 'เลื่อนนัดจาก ' . $old . ' เป็น ' . $date . ' ' . $slot['start'], $staff ? null : 'patient');
    $status = $staff ? 'confirmed' : ($provider['appt']['confirm'] === 'auto' && $a['verified'] ? 'confirmed' : 'pending');
    idev_appt_save($id, $a['p'], ['appt_date' => $date, 'start_time' => $slot['start'], 'end_time' => $slot['end'], 'status' => $status, 'reminders' => '', 'reschedules' => (int) $a['reschedules'] + ($staff ? 0 : 1)]);
    idev_appt_notify($id, 'rescheduled');
    if (!$staff) idev_appt_notify_staff($id, 'rescheduled');
    do_action('idev_appt_rescheduled', $id, $by);
    return true;
}

/** Can the patient still change this appointment? */
function idev_appt_patient_can_change($a) {
    if (!in_array($a['status'], idev_appt_active_statuses(), true)) return false;
    $cut = (int) idev_appt_settings()['change_hours'] * HOUR_IN_SECONDS;
    return idev_appt_slot_ts($a['appt_date'], $a['start_time']) - $cut > time();
}
