<?php
/** REST API: idev-appt/v1 — public booking, manage link, calendar file, doctor/staff portal. */
defined('ABSPATH') || exit;

function idev_appt_public_provider($p) {
    $lang = idev_lang();
    return ['id' => $p['id'], 'slug' => $p['slug'], 'kind' => $p['kind'], 'name' => idev_appt_provider_name($p, $lang), 'specialty' => idev_pick($p['specialty'], $p['specialty_en'], $lang),
        'photo' => $p['photo'], 'note' => idev_pick($p['appt']['note'], $p['appt']['note_en'], $lang), 'confirm' => $p['appt']['confirm'], 'minutes' => $p['appt']['minutes'],
        'groups' => array_map(function ($t) use ($lang) { return idev_pick($t['name'], $t['name_en'], $lang); }, $p['specialties']), 'url' => idev_appt_provider_url($p),
        'parent' => (int) $p['appt']['parent'], 'role' => $p['appt']['role'] ?: ($p['kind'] === 'clinic' ? 'service' : 'doctor'), 'own' => empty($p['inherit_slots'])];
}
function idev_appt_public_appt($a) {
    $lang = ($a['p']['lang'] ?? '') === 'en' ? 'en' : (($a['p']['lang'] ?? '') === 'th' ? 'th' : idev_lang());
    $post = get_post($a['provider_id']);
    $p = $post && function_exists('idev_cs_provider') ? idev_cs_provider($post) : null;
    return ['ref' => $a['ref'], 'status' => $a['status'], 'status_label' => idev_appt_status_label($a['status'], $lang), 'date' => $a['appt_date'], 'date_label' => idev_format_day($a['appt_date'], $lang, true),
        'start' => $a['start_time'], 'end' => $a['end_time'], 'provider' => $p ? ['id' => $p['id'], 'name' => idev_pick($p['name'], $p['name_en'], $lang), 'specialty' => idev_pick($p['specialty'], $p['specialty_en'], $lang), 'photo' => $p['photo']] : null,
        'name' => idev_appt_mask_name($a['p']['name'] ?? ''), 'can_change' => idev_appt_patient_can_change($a), 'can_move' => idev_appt_patient_can_change($a) && (int) $a['reschedules'] < (int) idev_appt_settings()['max_reschedules'],
        'ics' => add_query_arg('t', idev_appt_token($a), rest_url('idev-appt/v1/ics'))];
}

add_action('rest_api_init', function () {
    $ns = 'idev-appt/v1';
    $pub = '__return_true';
    register_rest_route($ns, '/providers', ['methods' => 'GET', 'permission_callback' => $pub, 'callback' => function (WP_REST_Request $r) {
        /** Filter: doctors/clinics listed on the booking page (add-ons: ?branch=). */
        $list = array_map('idev_appt_public_provider', apply_filters('idev_appt_public_providers', idev_appt_providers(), $r));
        // A clinic / service with no clinic times of its own is still listed to group its doctors / staff / sub-services.
        $have = array_column($list, 'id');
        foreach (array_unique(array_filter(array_column($list, 'parent'))) as $pid) {
            if (in_array($pid, $have, true) || !($post = get_post($pid)) || $post->post_status !== 'publish' || !function_exists('idev_cs_provider')) continue;
            $p = idev_cs_provider($post);
            $list[] = idev_appt_public_provider($p + ['appt' => array_merge(idev_appt_provider_cfg($pid), ['parent' => 0]), 'slug' => idev_appt_slug($p), 'inherit_slots' => true]) + ['group_only' => true];
        }
        return $list;
    }]);
    register_rest_route($ns, '/month', ['methods' => 'GET', 'permission_callback' => $pub, 'callback' => function (WP_REST_Request $r) {
        $p = idev_appt_provider($r->get_param('provider'));
        if (!$p) return new WP_Error('not_found', 'Not found', ['status' => 404]);
        return ['days' => idev_appt_month($p, (string) $r->get_param('month')), 'today' => idev_today(), 'last' => idev_add_days(idev_today(), (int) idev_appt_settings()['max_days'])];
    }]);
    register_rest_route($ns, '/slots', ['methods' => 'GET', 'permission_callback' => $pub, 'callback' => function (WP_REST_Request $r) {
        $p = idev_appt_provider($r->get_param('provider'));
        if (!$p) return new WP_Error('not_found', 'Not found', ['status' => 404]);
        $slots = idev_appt_slots($p, (string) $r->get_param('date'));
        return ['slots' => array_values(array_map(function ($s) { return ['start' => $s['start'], 'end' => $s['end'], 'left' => $s['left'], 'open' => $s['open']]; }, array_filter($slots, function ($s) { return !$s['past']; })))];
    }]);
    // 1.5: "service → day → time → sub-service": free times of a clinic / service and everyone under it together.
    register_rest_route($ns, '/group/month', ['methods' => 'GET', 'permission_callback' => $pub, 'callback' => function (WP_REST_Request $r) {
        $members = idev_appt_group_members((int) $r->get_param('service'));
        if (!$members) return new WP_Error('not_found', 'Not found', ['status' => 404]);
        $days = [];
        foreach ($members as $m) foreach (idev_appt_month($m, (string) $r->get_param('month')) as $d => $n) $days[$d] = ($days[$d] ?? 0) + $n;
        return ['days' => $days, 'today' => idev_today(), 'last' => idev_add_days(idev_today(), (int) idev_appt_settings()['max_days'])];
    }]);
    register_rest_route($ns, '/group/slots', ['methods' => 'GET', 'permission_callback' => $pub, 'callback' => function (WP_REST_Request $r) {
        $out = [];
        foreach (idev_appt_group_members((int) $r->get_param('service')) as $m) {
            foreach (idev_appt_slots($m, (string) $r->get_param('date')) as $sl) {
                if ($sl['past']) continue;
                $k = $sl['start'];
                if (!isset($out[$k])) $out[$k] = ['start' => $k, 'end' => $sl['end'], 'left' => 0, 'open' => false];
                if ($sl['open']) { $out[$k]['left'] += $sl['left']; $out[$k]['open'] = true; }
            }
        }
        ksort($out);
        return ['slots' => array_values($out)];
    }]);
    register_rest_route($ns, '/group/who', ['methods' => 'GET', 'permission_callback' => $pub, 'callback' => function (WP_REST_Request $r) {
        $date = (string) $r->get_param('date');
        $start = (string) $r->get_param('start');
        $out = [];
        foreach (idev_appt_group_members((int) $r->get_param('service')) as $m) {
            foreach (idev_appt_slots($m, $date) as $sl) if ($sl['start'] === $start && $sl['open']) $out[] = idev_appt_public_provider($m) + ['slot' => ['start' => $sl['start'], 'end' => $sl['end'], 'left' => $sl['left'], 'open' => true]];
        }
        return ['items' => $out];
    }]);
    register_rest_route($ns, '/identify', ['methods' => 'POST', 'permission_callback' => $pub, 'callback' => function (WP_REST_Request $r) {
        [$ok, $d] = idev_appt_identify($r->get_param('type') === 'reg' ? 'reg' : 'hn', (string) $r->get_param('number'), (string) $r->get_param('dob'), $r->get_param('lang') === 'en' ? 'en' : 'th');
        if (!$ok) return new WP_REST_Response(['ok' => false, 'error' => $d], 400);
        return ['ok' => true, 'verified' => $d['verified'], 'name' => idev_appt_mask_name($d['name']), 'has_email' => $d['email'] !== '', 'hn' => $d['hn'] !== '' ? $d['hn'] : null];
    }]);
    register_rest_route($ns, '/book', ['methods' => 'POST', 'permission_callback' => $pub, 'callback' => 'idev_appt_rest_book']);
    register_rest_route($ns, '/manage', ['methods' => 'GET', 'permission_callback' => $pub, 'callback' => function (WP_REST_Request $r) {
        $a = idev_appt_get_by_token((string) $r->get_param('t'));
        return $a ? idev_appt_public_appt($a) : new WP_Error('not_found', 'Not found', ['status' => 404]);
    }]);
    register_rest_route($ns, '/manage/cancel', ['methods' => 'POST', 'permission_callback' => $pub, 'callback' => function (WP_REST_Request $r) {
        $a = idev_appt_get_by_token((string) $r->get_param('t'));
        if (!$a) return new WP_Error('not_found', 'Not found', ['status' => 404]);
        if (!idev_appt_patient_can_change($a)) return new WP_REST_Response(['ok' => false, 'error' => __('This appointment can no longer be changed online. Please call us.', 'idev-appointments')], 400);
        idev_appt_set_status($a['id'], 'cancelled', 'patient', mb_substr(sanitize_text_field((string) $r->get_param('reason')), 0, 200));
        return ['ok' => true, 'appt' => idev_appt_public_appt(idev_appt_get($a['id']))];
    }]);
    register_rest_route($ns, '/manage/move', ['methods' => 'POST', 'permission_callback' => $pub, 'callback' => function (WP_REST_Request $r) {
        $a = idev_appt_get_by_token((string) $r->get_param('t'));
        if (!$a) return new WP_Error('not_found', 'Not found', ['status' => 404]);
        if (!idev_appt_patient_can_change($a) || (int) $a['reschedules'] >= (int) idev_appt_settings()['max_reschedules']) return new WP_REST_Response(['ok' => false, 'error' => __('This appointment can no longer be moved online. Please call us.', 'idev-appointments')], 400);
        $res = idev_appt_reschedule($a['id'], (string) $r->get_param('date'), (string) $r->get_param('start'), 'patient');
        if (is_wp_error($res)) return new WP_REST_Response(['ok' => false, 'error' => $res->get_error_message()], 400);
        return ['ok' => true, 'appt' => idev_appt_public_appt(idev_appt_get($a['id']))];
    }]);
    register_rest_route($ns, '/ics', ['methods' => 'GET', 'permission_callback' => $pub, 'callback' => function (WP_REST_Request $r) {
        $a = idev_appt_get_by_token((string) $r->get_param('t'));
        if (!$a) return new WP_Error('not_found', 'Not found', ['status' => 404]);
        header('Content-Type: text/calendar; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $a['ref'] . '.ics"');
        echo idev_appt_ics($a); // phpcs:ignore
        exit;
    }]);

    /* ---- portal (doctors: their own; staff: all) ---- */
    $can = function () { return current_user_can('idev_appt_manage') || current_user_can('idev_appt_doctor'); };
    register_rest_route($ns, '/portal/list', ['methods' => 'GET', 'permission_callback' => $can, 'callback' => 'idev_appt_rest_portal_list']);
    register_rest_route($ns, '/portal/slots', ['methods' => 'GET', 'permission_callback' => $can, 'callback' => function (WP_REST_Request $r) {
        $pid = (int) $r->get_param('provider');
        if (!in_array($pid, idev_appt_user_providers(), true)) return new WP_Error('forbidden', 'Forbidden', ['status' => 403]);
        $post = get_post($pid);
        $p = idev_cs_provider($post) + ['appt' => idev_appt_provider_cfg($pid)];
        return ['slots' => idev_appt_slots($p, (string) $r->get_param('date'), true, (int) $r->get_param('exclude'))];
    }]);
    register_rest_route($ns, '/hn/unchecked', ['methods' => 'GET', 'permission_callback' => 'idev_appt_can_check_hn', 'callback' => function () {
        return ['items' => array_map('idev_appt_portal_row', idev_appt_unchecked())];
    }]);
    register_rest_route($ns, '/hn/check', ['methods' => 'POST', 'permission_callback' => 'idev_appt_can_check_hn', 'callback' => function (WP_REST_Request $r) {
        $res = idev_appt_set_hn((int) $r->get_param('id'), (string) $r->get_param('hn'));
        return is_wp_error($res) ? new WP_REST_Response(['ok' => false, 'error' => $res->get_error_message()], 400) : ['ok' => true];
    }]);
    register_rest_route($ns, '/portal/action', ['methods' => 'POST', 'permission_callback' => $can, 'callback' => 'idev_appt_rest_portal_action']);
    register_rest_route($ns, '/portal/create', ['methods' => 'POST', 'permission_callback' => $can, 'callback' => function (WP_REST_Request $r) {
        $pid = (int) $r->get_param('provider');
        if (!in_array($pid, idev_appt_user_providers(), true)) return new WP_Error('forbidden', 'Forbidden', ['status' => 403]);
        $hn = strtoupper(preg_replace('/[^0-9A-Za-z-]/', '', (string) $r->get_param('hn')));
        $dob = (string) $r->get_param('dob');
        $found = $hn !== '' ? idev_appt_find_registration('hn', $hn) : null;
        $patient = $found ? idev_appt_identity_from($found, true) : ['verified' => $hn !== '', 'hn' => $hn, 'reg_ref' => '', 'name' => '', 'email' => '', 'phone' => '', 'dob' => idev_is_valid_date($dob) ? $dob : '', 'patient_key' => $hn !== '' ? idev_appt_hash('HN|' . $hn) : ''];
        $res = idev_appt_create(['provider' => $pid, 'date' => (string) $r->get_param('date'), 'start' => (string) $r->get_param('start'), 'patient' => $patient, 'name' => (string) $r->get_param('name'), 'phone' => (string) $r->get_param('phone'), 'email' => (string) $r->get_param('email'), 'cid' => (string) $r->get_param('cid'), 'reason' => (string) $r->get_param('reason'), 'lang' => $r->get_param('lang') === 'en' ? 'en' : 'th'], true);
        if (is_wp_error($res)) return new WP_REST_Response(['ok' => false, 'error' => $res->get_error_message()], 400);
        return ['ok' => true, 'id' => $res[0]];
    }]);
});

function idev_appt_rest_book(WP_REST_Request $r) {
    $s = idev_appt_settings();
    $lang = $r->get_param('lang') === 'en' ? 'en' : 'th';
    $en = $lang === 'en';
    $err = function ($field, $msg, $code = 400) { return new WP_REST_Response(['ok' => false, 'field' => $field, 'error' => $msg], $code); };
    if ($r->get_param('website')) return ['ok' => true, 'ref' => 'APT-0']; // honeypot
    if (!$r->get_param('consent')) return $err('consent', $en ? 'Please accept the privacy notice' : 'กรุณายอมรับนโยบายความเป็นส่วนตัว');
    [$ok, $patient] = idev_appt_identify($r->get_param('type') === 'reg' ? 'reg' : 'hn', (string) $r->get_param('number'), (string) $r->get_param('dob'), $lang);
    if (!$ok) return $err('number', $patient);
    $name = trim(sanitize_text_field((string) $r->get_param('name')));
    $phone = preg_replace('/[^\d+]/', '', (string) $r->get_param('phone'));
    $email = sanitize_email((string) $r->get_param('email'));
    if ($name === '' && $patient['name'] === '') return $err('name', $en ? 'Please enter your name' : 'กรุณากรอกชื่อ-นามสกุล');
    if (strlen(preg_replace('/\D/', '', $phone)) < 9) return $err('phone', $en ? 'Please enter your phone number' : 'กรุณากรอกเบอร์โทร');
    if ($email !== '' && !is_email($email)) return $err('email', $en ? 'Please check the e-mail address' : 'อีเมลไม่ถูกต้อง');
    if ($email === '' && $s['require_email'] === '1' && $patient['email'] === '') return $err('email', $en ? 'Please enter your e-mail (for the confirmation)' : 'กรุณากรอกอีเมล (สำหรับยืนยันนัด)');
    $cid = '';
    if ($s['ask_cid'] !== 'off') {
        [$cid, $cid_err] = idev_appt_clean_cid((string) $r->get_param('cid'), $lang);
        if ($cid_err) return $err('cid', $cid_err);
        if ($cid === '' && $s['ask_cid'] === 'required') return $err('cid', $en ? 'Please enter your Thai ID or passport number' : 'กรุณากรอกเลขบัตรประชาชนหรือเลขหนังสือเดินทาง');
    }
    $res = idev_appt_create(['provider' => $r->get_param('provider'), 'date' => (string) $r->get_param('date'), 'start' => (string) $r->get_param('start'), 'patient' => $patient, 'name' => $name, 'phone' => $phone, 'email' => $email, 'cid' => $cid, 'reason' => $s['ask_reason'] === '1' ? (string) $r->get_param('reason') : '', 'lang' => $lang]);
    if (is_wp_error($res)) return $err($res->get_error_code(), $res->get_error_message(), $res->get_error_code() === 'slot' ? 409 : 400);
    [$id, $token] = $res;
    $a = idev_appt_get($id);
    return ['ok' => true, 'token' => $token, 'manage_url' => idev_appt_manage_url($a), 'appt' => idev_appt_public_appt($a), 'emailed' => is_email($a['p']['contact_email'] ?? '')];
}

/* ---------- portal ---------- */

function idev_appt_portal_row($a) {
    $p = $a['p'];
    $row = ['id' => (int) $a['id'], 'ref' => $a['ref'], 'provider' => (int) $a['provider_id'], 'date' => $a['appt_date'], 'start' => $a['start_time'], 'end' => $a['end_time'], 'status' => $a['status'],
        'name' => $p['name'] ?? '', 'hn' => $p['hn'] ?? '', 'reg' => $p['reg_ref'] ?? '', 'phone' => $p['phone'] ?? '', 'email' => $p['contact_email'] ?? '', 'reason' => $p['reason'] ?? '', 'dob' => $p['dob'] ?? '', 'cid' => $p['cid'] ?? '',
        'verified' => (bool) $a['verified'], 'source' => $a['source'], 'lang' => $p['lang'] ?? 'th', 'cancel_reason' => $p['cancel_reason'] ?? '', 'moved' => (int) $a['reschedules'] > 0 || (bool) array_filter((array) ($p['_log'] ?? []), function ($l) { return is_array($l) && strpos(implode(' ', array_map('strval', $l)), 'เลื่อนนัด') !== false; }), 'log' => array_slice(array_reverse($p['_log'] ?? []), 0, 12), 'links' => []];
    /** Filter: appointment in the staff / doctor screen. Add-ons may add 'links' => [[label, url]] (e.g. WhatsApp). */
    return apply_filters('idev_appt_portal_row', $row, $a);
}
function idev_appt_rest_portal_list(WP_REST_Request $r) {
    global $wpdb;
    $mine = idev_appt_user_providers();
    $from = idev_is_valid_date($r->get_param('from')) ? $r->get_param('from') : idev_today();
    $to = idev_is_valid_date($r->get_param('to')) ? $r->get_param('to') : idev_add_days($from, 6);
    $pid = (int) $r->get_param('provider');
    $ids = $pid ? array_intersect([$pid], $mine) : $mine;
    $providers = [];
    foreach ($mine as $id) { $post = get_post($id); if ($post) { $p = idev_cs_provider($post); $providers[] = ['id' => $id, 'name' => idev_pick($p['name'], $p['name_en']), 'kind' => $p['kind']]; } }
    if (!$ids) return ['providers' => $providers, 'items' => [], 'pending' => 0];
    $in = implode(',', array_map('intval', $ids));
    $t = idev_appt_table();
    $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t} WHERE provider_id IN ({$in}) AND appt_date BETWEEN %s AND %s ORDER BY appt_date, start_time, id", $from, $to), ARRAY_A);
    $pending = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t} WHERE provider_id IN ({$in}) AND status='pending' AND appt_date >= %s ORDER BY appt_date, start_time LIMIT 200", idev_today()), ARRAY_A);
    $q = mb_strtolower(trim((string) $r->get_param('q')));
    $map = function ($rows) use ($q) {
        $out = [];
        foreach ($rows as $row) {
            $item = idev_appt_portal_row(idev_appt_hydrate($row));
            if ($q !== '' && strpos(mb_strtolower($item['name'] . ' ' . $item['hn'] . ' ' . $item['phone'] . ' ' . $item['ref']), $q) === false) continue;
            $out[] = $item;
        }
        return $out;
    };
    $out = ['providers' => $providers, 'items' => $map($rows), 'pending_items' => $map($pending), 'pending' => count($pending), 'from' => $from, 'to' => $to, 'today' => idev_today()];
    if ($r->get_param('clinic')) $out['days'] = idev_appt_portal_clinic_days($ids, $from, $to);
    return $out;
}
/** Clinic hours of the chosen doctors / clinics per day, for the month calendar: [date => ['hours' => [[id, start, end]], 'off' => bool]]. */
function idev_appt_portal_clinic_days($ids, $from, $to) {
    $days = [];
    $providers = [];
    foreach ($ids as $id) { $post = get_post($id); if ($post) $providers[] = idev_cs_provider($post) + ['appt' => idev_appt_provider_cfg($id)]; }
    for ($d = $from, $n = 0; $d <= $to && $n < 62; $d = idev_add_days($d, 1), $n++) {
        $holiday = function_exists('idev_holiday_closed') && idev_holiday_closed($d);
        $day = ['hours' => [], 'off' => $holiday];
        foreach ($providers as $p) {
            if ($holiday || in_array($d, $p['appt']['off'], true)) continue;
            foreach ((array) $p['slots'] as $session) {
                if (function_exists('idev_cs_occurs_on') && idev_cs_occurs_on($session, $d)) $day['hours'][] = [(int) $p['id'], substr((string) $session['start_time'], 0, 5), substr((string) $session['end_time'], 0, 5)];
            }
        }
        usort($day['hours'], function ($a, $b) { return strcmp($a[1], $b[1]); });
        $days[$d] = $day;
    }
    return $days;
}
function idev_appt_rest_portal_action(WP_REST_Request $r) {
    $a = idev_appt_get((int) $r->get_param('id'));
    if (!$a || !in_array((int) $a['provider_id'], idev_appt_user_providers(), true)) return new WP_Error('forbidden', 'Forbidden', ['status' => 403]);
    $do = sanitize_key($r->get_param('do'));
    if ($do === 'move') $res = idev_appt_reschedule($a['id'], (string) $r->get_param('date'), (string) $r->get_param('start'), 'staff');
    elseif (in_array($do, ['confirmed', 'cancelled', 'completed', 'no_show', 'pending'], true)) $res = idev_appt_set_status($a['id'], $do, 'staff', mb_substr(sanitize_text_field((string) $r->get_param('reason')), 0, 300));
    elseif ($do === 'note') { $p = $a['p']; idev_appt_log($p, 'บันทึก: ' . mb_substr(sanitize_text_field((string) $r->get_param('reason')), 0, 300)); idev_appt_save($a['id'], $p); $res = true; }
    else return new WP_Error('bad', 'Unknown action', ['status' => 400]);
    if (is_wp_error($res)) return new WP_REST_Response(['ok' => false, 'error' => $res->get_error_message()], 400);
    return ['ok' => true, 'item' => idev_appt_portal_row(idev_appt_get($a['id']))];
}
