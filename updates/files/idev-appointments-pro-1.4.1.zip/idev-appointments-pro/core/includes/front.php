<?php
/** Booking page (one address per doctor/clinic), manage page, provider booking settings, links from other iDev plugins. */
defined('ABSPATH') || exit;

/* ---------- Addresses ---------- */

function idev_appt_booking_page() { $id = (int) idev_appt_settings()['page']; return $id && get_post_status($id) === 'publish' ? $id : 0; }
function idev_appt_booking_url() { $id = idev_appt_booking_page(); return $id ? get_permalink($id) : ''; }
function idev_appt_provider_url($p) {
    $base = idev_appt_booking_url();
    if (!$base) return '';
    if (!is_array($p)) { $post = get_post((int) $p); $p = $post && function_exists('idev_cs_provider') ? idev_cs_provider($post) : ['id' => (int) $p, 'name_en' => '']; }
    $slug = $p['slug'] ?? idev_appt_slug($p);
    return get_option('permalink_structure') && $slug ? trailingslashit($base) . rawurlencode($slug) . '/' : add_query_arg('provider', $p['id'], $base);
}
function idev_appt_portal_url() { $id = (int) idev_appt_settings()['portal_page']; return $id && get_post_status($id) === 'publish' ? get_permalink($id) : admin_url('admin.php?page=idev-appt'); }
function idev_appt_register_url() {
    $id = (int) idev_appt_settings()['register_page'];
    return $id && get_post_status($id) === 'publish' ? get_permalink($id) : '';
}

add_action('init', function () {
    add_rewrite_tag('%idev_provider%', '([^/&]+)');
    $page = idev_appt_booking_page();
    if ($page) add_rewrite_rule('^' . preg_quote(get_page_uri($page), '#') . '/([^/]+)/?$', 'index.php?page_id=' . $page . '&idev_provider=$matches[1]', 'top');
    if (get_option('idev_appt_flush')) { flush_rewrite_rules(false); delete_option('idev_appt_flush'); }
}, 30);
add_filter('query_vars', function ($v) { $v[] = 'idev_provider'; return $v; });

/* ---------- Booking form ---------- */

add_action('init', function () {
    wp_register_style('idev-appt', IDEV_APPT_URL . 'assets/book.css', [], IDEV_APPT_VERSION);
    wp_register_script('idev-appt', IDEV_APPT_URL . 'assets/book.js', [], IDEV_APPT_VERSION, true);
    $opts = ['' => __('Visitor chooses', 'idev-appointments')];
    foreach (function_exists('idev_cs_providers') ? idev_cs_providers() : [] as $p) $opts[(string) $p['id']] = $p['name'];
    idev_register_block('idev/booking', __('Book an appointment', 'idev-appointments'), 'calendar-alt', __('Online booking: doctor or clinic, date and time, patient, consent.', 'idev-appointments'), [
        'provider' => ['select', __('Doctor / clinic', 'idev-appointments'), '', $opts],
        'kind' => ['select', __('Show', 'idev-appointments'), '', ['' => __('Doctors and clinics', 'idev-appointments'), 'doctor' => __('Doctors', 'idev-appointments'), 'clinic' => __('Clinics', 'idev-appointments')]],
        'branch' => ['text', __('Branch code (optional)', 'idev-appointments'), ''],
    ], function ($a) { return idev_appt_booking_form(['provider' => $a['provider'] ?? '', 'kind' => $a['kind'] ?? '', 'branch' => $a['branch'] ?? '']); });
});
add_shortcode('idev_booking', function ($a) { return idev_appt_booking_form(shortcode_atts(['provider' => '', 'kind' => '', 'branch' => ''], $a)); });

function idev_appt_strings() {
    return [
        'chooseProvider' => __('Who would you like to see?', 'idev-appointments'), 'search' => __('Search doctor, clinic or specialty', 'idev-appointments'),
        'all' => __('All', 'idev-appointments'), 'doctors' => __('Doctors', 'idev-appointments'), 'clinics' => __('Clinics', 'idev-appointments'), 'change' => __('Change', 'idev-appointments'),
        'chooseTime' => __('Choose a day and time', 'idev-appointments'), 'noDays' => __('No free times this month.', 'idev-appointments'), 'pickDay' => __('Choose a day with free times (marked in colour).', 'idev-appointments'),
        'left' => __('%d left', 'idev-appointments'), 'full' => __('Full', 'idev-appointments'), 'noSlots' => __('No free times on this day.', 'idev-appointments'),
        'who' => __('Who is the patient?', 'idev-appointments'), 'haveHn' => __('I have a hospital number (HN)', 'idev-appointments'), 'haveReg' => __('I registered online and have a reference (REG-…)', 'idev-appointments'),
        'newPatient' => __('New patient — I have not registered yet', 'idev-appointments'), 'newPatientText' => __('Please register first. It takes about 3 minutes; you can book right after.', 'idev-appointments'), 'register' => __('Register as a new patient', 'idev-appointments'),
        'hn' => __('HN', 'idev-appointments'), 'reg' => __('Registration reference', 'idev-appointments'), 'dob' => __('Date of birth', 'idev-appointments'), 'check' => __('Check', 'idev-appointments'),
        'found' => __('Found: %s', 'idev-appointments'), 'unverified' => __('We will check this HN when we confirm your appointment.', 'idev-appointments'),
        'name' => __('Patient name', 'idev-appointments'), 'nameHint' => __('Leave empty to use the name we have on file', 'idev-appointments'), 'phone' => __('Mobile phone', 'idev-appointments'),
        'email' => __('E-mail (for the confirmation and reminders)', 'idev-appointments'), 'emailHint' => __('Leave empty to use the e-mail you registered with', 'idev-appointments'),
        'reason' => __('Reason for the visit / symptoms (optional)', 'idev-appointments'), 'consentTitle' => __('Your personal data', 'idev-appointments'), 'privacy' => __('Privacy policy', 'idev-appointments'),
        'consentCheck' => __('I agree (PDPA / GDPR)', 'idev-appointments'), 'summary' => __('Your appointment', 'idev-appointments'), 'book' => __('Book appointment', 'idev-appointments'), 'sending' => __('Booking…', 'idev-appointments'),
        'next' => __('Next', 'idev-appointments'), 'back' => __('Back', 'idev-appointments'), 'required' => __('Please fill this in', 'idev-appointments'), 'checkFirst' => __('Please press "Check" first', 'idev-appointments'),
        'doneConfirmed' => __('Your appointment is confirmed', 'idev-appointments'), 'donePending' => __('Request sent — waiting for confirmation', 'idev-appointments'),
        'donePendingText' => __('We will confirm it by e-mail. You can see the status any time with the link below.', 'idev-appointments'), 'emailed' => __('We have sent the details to your e-mail.', 'idev-appointments'),
        'ref' => __('Reference', 'idev-appointments'), 'manage' => __('View, move or cancel', 'idev-appointments'), 'calendar' => __('Add to calendar', 'idev-appointments'), 'another' => __('Book another appointment', 'idev-appointments'),
        'saveLink' => __('Keep this link to change your appointment:', 'idev-appointments'), 'copy' => __('Copy', 'idev-appointments'), 'copied' => __('Copied', 'idev-appointments'),
        'status' => __('Status', 'idev-appointments'), 'cancel' => __('Cancel appointment', 'idev-appointments'), 'move' => __('Move to another time', 'idev-appointments'),
        'cancelAsk' => __('Cancel this appointment?', 'idev-appointments'), 'cancelReason' => __('Reason (optional)', 'idev-appointments'), 'yesCancel' => __('Yes, cancel', 'idev-appointments'), 'keep' => __('Keep it', 'idev-appointments'),
        'moveTitle' => __('Choose a new time', 'idev-appointments'), 'confirmMove' => __('Move here', 'idev-appointments'), 'noChange' => __('To change this appointment please call us.', 'idev-appointments'),
        'notFound' => __('Appointment not found. Please check the link.', 'idev-appointments'), 'error' => __('Something went wrong. Please try again.', 'idev-appointments'),
        'prev' => __('Previous month', 'idev-appointments'), 'nextMonth' => __('Next month', 'idev-appointments'), 'call' => __('Call', 'idev-appointments'),
        'stepSub' => __('Sub-service / doctor', 'idev-appointments'), 'chooseAt' => __('Who is free at this time', 'idev-appointments'), 'stepDetails' => __('Details and patient', 'idev-appointments'),
        'stepService' => __('Clinic / service', 'idev-appointments'), 'stepWho' => __('Doctor / staff / service', 'idev-appointments'), 'stepDay' => __('Day', 'idev-appointments'), 'stepTime' => __('Time', 'idev-appointments'), 'stepPatient' => __('Patient', 'idev-appointments'), 'stepAgree' => __('Agreement', 'idev-appointments'),
        'chooseService' => __('Choose a clinic or service', 'idev-appointments'), 'chooseChild' => __('Choose a doctor, staff member or service', 'idev-appointments'), 'anyone' => __('Any available', 'idev-appointments'), 'anyoneText' => __('First free time at this clinic / service', 'idev-appointments'),
        'chooseDay' => __('Choose a day', 'idev-appointments'), 'chooseSlot' => __('Choose a time', 'idev-appointments'), 'options' => __('%d choices', 'idev-appointments'),
        'role_doctor' => __('Doctor', 'idev-appointments'), 'role_staff' => __('Staff', 'idev-appointments'), 'role_service' => __('Service', 'idev-appointments'),
        'cid' => __('Thai ID number or passport number', 'idev-appointments'), 'cidHint' => __('Used to find your record at the counter', 'idev-appointments'), 'cidBad' => __('Please check the number (13-digit Thai ID or passport)', 'idev-appointments'), 'agreeTitle' => __('Service agreement', 'idev-appointments'),
        'autoNote' => __('Confirmed straight away', 'idev-appointments'), 'manualNote' => __('Confirmed by our staff', 'idev-appointments'), 'minutes' => __('%d min', 'idev-appointments'),
    ];
}

function idev_appt_booking_form($atts = []) {
    $s = idev_appt_settings();
    $lang = idev_lang();
    wp_enqueue_style('idev-appt');
    wp_enqueue_script('idev-appt');
    $pre = $atts['provider'] ?: (get_query_var('idev_provider') ?: sanitize_text_field(wp_unslash($_GET['provider'] ?? '')));
    $provider = $pre !== '' ? idev_appt_provider($pre) : null;
    $org = get_bloginfo('name');
    $cfg = [
        'rest' => esc_url_raw(rest_url('idev-appt/v1/')), 'lang' => $lang, 'fixed' => $atts['provider'] !== '', 'kind' => $atts['kind'] ?? '',
        'branch' => sanitize_key(($atts['branch'] ?? '') ?: wp_unslash($_GET['branch'] ?? '')),
        'provider' => $provider ? idev_appt_public_provider($provider) : null, 'date' => idev_is_valid_date($_GET['date'] ?? '') ? sanitize_text_field(wp_unslash($_GET['date'])) : '',
        'reg' => preg_match('/^REG-[0-9]{6}-[A-Z0-9]{5}$/', strtoupper((string) ($_GET['reg'] ?? ''))) ? strtoupper(sanitize_text_field(wp_unslash($_GET['reg']))) : '',
        'manage' => preg_match('/^[0-9a-f]{40}$/', (string) ($_GET['appt'] ?? '')) ? sanitize_text_field(wp_unslash($_GET['appt'])) : '',
        'register' => idev_appt_register_url(), 'registerOnly' => $s['identity'] === 'registered', 'hasRegistration' => function_exists('idev_medreg_table'),
        'requireEmail' => $s['require_email'] === '1', 'askReason' => $s['ask_reason'] === '1', 'askCid' => $s['ask_cid'], 'flow' => $s['flow'], 'phone' => $s['phone'],
        'consent' => str_replace('{org}', $org, idev_pick($s['consent'], $s['consent_en'], $lang)), 'privacy' => $s['privacy_url'] ?: (get_privacy_policy_url() ?: ''),
        'months' => idev_months($lang), 'weekdays' => idev_weekdays_short($lang), 't' => idev_appt_strings(),
    ];
    return '<div class="idev-appt" style="--idev-appt:' . esc_attr($s['accent']) . '" data-idev-appt="' . esc_attr(wp_json_encode($cfg, JSON_UNESCAPED_UNICODE)) . '"><noscript>' . esc_html__('Please turn on JavaScript to book online, or call us.', 'idev-appointments') . '</noscript><div class="idev-appt-loading" aria-hidden="true"></div></div>' . apply_filters('idev_appt_booking_after', '', $cfg);
}
function idev_weekdays_short($lang) {
    return $lang === 'en' ? ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] : ['จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.', 'อา.'];
}

/* ---------- Doctor / clinic edit screen: online booking ---------- */

add_action('add_meta_boxes_idev_provider', function () { add_meta_box('idev_appt_box', __('Online booking', 'idev-appointments'), 'idev_appt_provider_box', 'idev_provider', 'side', 'default'); });
function idev_appt_provider_box($post) {
    $s = idev_appt_settings();
    $c = idev_appt_provider_cfg($post->ID);
    wp_nonce_field('idev_appt_pbox', 'idev_appt_pbox');
    $raw = function ($k) use ($post) { return get_post_meta($post->ID, "_idev_appt_{$k}", true); };
    echo '<div class="idev-form">';
    echo '<label>' . esc_html__('Online booking', 'idev-appointments') . '<select name="idev_appt[on]"><option value="">' . esc_html(sprintf(__('As in settings (%s)', 'idev-appointments'), $s['default_on'] === '1' ? __('on', 'idev-appointments') : __('off', 'idev-appointments'))) . '</option><option value="1"' . selected($raw('on'), '1', false) . '>' . esc_html__('On', 'idev-appointments') . '</option><option value="0"' . selected($raw('on'), '0', false) . '>' . esc_html__('Off', 'idev-appointments') . '</option></select></label>';
    echo '<label>' . esc_html__('Minutes per slot', 'idev-appointments') . '<input type="number" min="5" max="240" name="idev_appt[minutes]" value="' . esc_attr($raw('minutes')) . '" placeholder="' . esc_attr($s['slot_minutes']) . '"></label>';
    echo '<label>' . esc_html__('Patients per slot', 'idev-appointments') . '<input type="number" min="1" max="200" name="idev_appt[capacity]" value="' . esc_attr($raw('capacity')) . '" placeholder="' . esc_attr($s['capacity']) . '"></label>';
    // 1.4: clinic / service → doctor / staff / sub-service
    $others = get_posts(['post_type' => 'idev_provider', 'post_status' => ['publish', 'private'], 'numberposts' => 300, 'orderby' => 'title', 'order' => 'ASC', 'exclude' => [$post->ID]]);
    echo '<label>' . esc_html__('Belongs to clinic / service', 'idev-appointments') . '<select name="idev_appt[parent]"><option value="0">' . esc_html__('— None (shown as a clinic / service) —', 'idev-appointments') . '</option>';
    foreach ($others as $o) if (!(int) get_post_meta($o->ID, '_idev_appt_parent', true)) echo '<option value="' . (int) $o->ID . '"' . selected($c['parent'], $o->ID, false) . '>' . esc_html($o->post_title) . '</option>';
    echo '</select><small>' . esc_html__('Patients first choose the clinic / service, then this doctor, staff member or sub-service. Without its own clinic times it uses the times of the clinic / service.', 'idev-appointments') . '</small></label>';
    echo '<label>' . esc_html__('Shown as', 'idev-appointments') . '<select name="idev_appt[role]"><option value="">' . esc_html__('Automatic', 'idev-appointments') . '</option>';
    foreach (['doctor' => __('Doctor', 'idev-appointments'), 'staff' => __('Staff (nurse, therapist …)', 'idev-appointments'), 'service' => __('Service / sub-service', 'idev-appointments')] as $k => $lab) echo '<option value="' . esc_attr($k) . '"' . selected($raw('role'), $k, false) . '>' . esc_html($lab) . '</option>';
    echo '</select></label>';
    echo '<label>' . esc_html__('Break between slots (minutes)', 'idev-appointments') . '<input type="number" min="0" max="120" name="idev_appt[break]" value="' . esc_attr($raw('break')) . '" placeholder="' . esc_attr($s['break_minutes']) . '"></label>';
    echo '<label>' . esc_html__('The doctor\'s login sees the appointments of', 'idev-appointments') . '<select name="idev_appt[scope]"><option value="">' . esc_html__('As in settings', 'idev-appointments') . '</option><option value="own"' . selected($raw('scope'), 'own', false) . '>' . esc_html__('Only this doctor / service', 'idev-appointments') . '</option><option value="clinic"' . selected($raw('scope'), 'clinic', false) . '>' . esc_html__('The whole clinic / service', 'idev-appointments') . '</option></select></label>';
    echo '<label>' . esc_html__('Appointments per slot are counted', 'idev-appointments') . '<select name="idev_appt[cap_mode]"><option value="own"' . selected($c['cap_mode'], 'own', false) . '>' . esc_html__('For each doctor / staff / sub-service', 'idev-appointments') . '</option><option value="shared"' . selected($c['cap_mode'], 'shared', false) . '>' . esc_html__('For the whole clinic / service together', 'idev-appointments') . '</option></select><small>' . esc_html__('Used when this is a clinic / service: "together" = "Patients per slot" of the clinic is shared by everyone under it.', 'idev-appointments') . '</small></label>';
    echo '<label>' . esc_html__('Confirmation', 'idev-appointments') . '<select name="idev_appt[confirm]"><option value="">' . esc_html__('As in settings', 'idev-appointments') . '</option><option value="auto"' . selected($raw('confirm'), 'auto', false) . '>' . esc_html__('Automatic', 'idev-appointments') . '</option><option value="manual"' . selected($raw('confirm'), 'manual', false) . '>' . esc_html__('Staff / doctor confirms', 'idev-appointments') . '</option></select></label>';
    $users = get_users(['role__in' => ['idev_doctor', 'administrator', 'editor', 'idev_appt_staff'], 'orderby' => 'display_name', 'number' => 500]);
    echo '<label>' . esc_html__('Doctor\'s login (sees and confirms these appointments)', 'idev-appointments') . '<select name="idev_appt[users][]" multiple size="4">';
    foreach ($users as $u) echo '<option value="' . (int) $u->ID . '"' . (in_array((int) $u->ID, $c['users'], true) ? ' selected' : '') . '>' . esc_html($u->display_name . ' (' . $u->user_login . ')') . '</option>';
    echo '</select><small>' . esc_html__('Create a user with the role "Doctor (appointments)". Ctrl/⌘-click to choose more than one.', 'idev-appointments') . '</small></label>';
    echo '<label>' . esc_html__('Days off (no booking), one per line', 'idev-appointments') . '<textarea name="idev_appt[off]" rows="3" placeholder="2026-12-31">' . esc_textarea(implode("\n", $c['off'])) . '</textarea></label>';
    echo '<label>' . esc_html__('Note for patients (Thai)', 'idev-appointments') . '<textarea name="idev_appt[note]" rows="2">' . esc_textarea($c['note']) . '</textarea></label>';
    echo '<label>' . esc_html__('Note for patients (English)', 'idev-appointments') . '<textarea name="idev_appt[note_en]" rows="2">' . esc_textarea($c['note_en']) . '</textarea></label>';
    $url = $post->post_status === 'publish' ? idev_appt_provider_url($post->ID) : '';
    if ($url) echo '<p><strong>' . esc_html__('Booking link', 'idev-appointments') . '</strong><br><input type="text" readonly value="' . esc_attr($url) . '" onclick="this.select()" style="width:100%"></p>';
    elseif (!idev_appt_booking_page()) echo '<p class="description">' . esc_html__('Choose the booking page in Appointments → Settings to get a link.', 'idev-appointments') . '</p>';
    do_action('idev_appt_provider_box_after', $post);
    echo '</div>';
}
add_action('save_post_idev_provider', function ($id) {
    if (!isset($_POST['idev_appt_pbox']) || !wp_verify_nonce(sanitize_key($_POST['idev_appt_pbox']), 'idev_appt_pbox') || !current_user_can('edit_post', $id)) return;
    $in = wp_unslash($_POST['idev_appt'] ?? []);
    update_post_meta($id, '_idev_appt_on', in_array($in['on'] ?? '', ['0', '1'], true) ? $in['on'] : '');
    foreach (['minutes' => [5, 240], 'capacity' => [1, 200]] as $k => [$lo, $hi]) update_post_meta($id, "_idev_appt_{$k}", ($in[$k] ?? '') === '' ? '' : (string) max($lo, min($hi, (int) $in[$k])));
    update_post_meta($id, '_idev_appt_confirm', in_array($in['confirm'] ?? '', ['auto', 'manual'], true) ? $in['confirm'] : '');
    $parent = (int) ($in['parent'] ?? 0);
    update_post_meta($id, '_idev_appt_parent', $parent && $parent !== $id && get_post_type($parent) === 'idev_provider' ? (string) $parent : '0');
    update_post_meta($id, '_idev_appt_role', in_array($in['role'] ?? '', ['doctor', 'staff', 'service'], true) ? $in['role'] : '');
    update_post_meta($id, '_idev_appt_break', ($in['break'] ?? '') === '' ? '' : (string) max(0, min(120, (int) $in['break'])));
    update_post_meta($id, '_idev_appt_cap_mode', ($in['cap_mode'] ?? '') === 'shared' ? 'shared' : 'own');
    update_post_meta($id, '_idev_appt_scope', in_array($in['scope'] ?? '', ['own', 'clinic'], true) ? $in['scope'] : '');
    update_post_meta($id, '_idev_appt_users', array_values(array_filter(array_map('intval', (array) ($in['users'] ?? [])))));
    $off = array_values(array_unique(array_filter(array_map('trim', preg_split('/[\s,]+/', (string) ($in['off'] ?? ''))), 'idev_is_valid_date')));
    sort($off);
    update_post_meta($id, '_idev_appt_off', wp_json_encode($off));
    foreach (['note', 'note_en'] as $k) update_post_meta($id, "_idev_appt_{$k}", sanitize_textarea_field($in[$k] ?? ''));
    do_action('idev_appt_provider_saved', $id, $in);
});

/* ---------- Links from other iDev plugins ---------- */

// Clinic schedule: "Book" on each clinic time opens this doctor's booking page on that day.
add_filter('idev_cs_booking_url', function ($url, $p, $date) {
    if (!idev_appt_booking_page() || !idev_appt_provider_cfg($p['id'])['on']) return $url;
    $u = idev_appt_provider_url($p);
    return $u ? ($date ? add_query_arg('date', $date, $u) : $u) : $url;
}, 10, 3);
// Patient registration: after sending, offer to book straight away with the registration reference.
add_filter('idev_medreg_submit_response', function ($data) {
    $url = idev_appt_booking_url();
    if ($url && !empty($data['ref'])) { $data['next_url'] = add_query_arg('reg', $data['ref'], $url); $data['next_label'] = __('Book an appointment now', 'idev-appointments'); }
    return $data;
});
