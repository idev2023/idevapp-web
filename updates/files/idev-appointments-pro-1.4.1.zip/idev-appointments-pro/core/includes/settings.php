<?php
defined('ABSPATH') || exit;

function idev_appt_setting_defaults() {
    return [
        'page' => '0', 'portal_page' => '0', 'register_page' => '0', 'identity' => 'hn_any', 'default_on' => '1', 'slot_minutes' => '15', 'capacity' => '1', 'break_minutes' => '0', 'ask_cid' => 'required', 'flow' => 'who_first', 'doctor_scope' => 'own', 'confirm' => 'manual',
        'lead_hours' => '2', 'max_days' => '60', 'change_hours' => '24', 'max_reschedules' => '2', 'max_upcoming' => '3', 'require_email' => '1', 'ask_reason' => '1',
        'location' => '', 'location_en' => '', 'phone' => '', 'accent' => '#0f766e',
        'consent_version' => '1',
        'consent' => "ข้าพเจ้ายินยอมให้ {org} เก็บรวบรวมและใช้ข้อมูลส่วนบุคคลและข้อมูลสุขภาพ (ชื่อ HN วันเกิด เบอร์โทร อีเมล และอาการ/เหตุผลที่มาพบแพทย์) เพื่อการนัดหมาย การติดต่อแจ้งเตือน และการให้บริการทางการแพทย์ ตามพระราชบัญญัติคุ้มครองข้อมูลส่วนบุคคล พ.ศ. 2562 (PDPA) ข้อมูลถูกเข้ารหัสและเข้าถึงได้เฉพาะผู้เกี่ยวข้อง ท่านถอนความยินยอม หรือขอเข้าถึง/แก้ไข/ลบข้อมูลได้โดยติดต่อเจ้าหน้าที่คุ้มครองข้อมูลส่วนบุคคล",
        'consent_en' => "I agree that {org} collects and uses my personal and health data (name, HN, date of birth, phone, e-mail and the reason for my visit) to manage this appointment, send me notices and reminders, and provide medical care, under Thailand's PDPA and, where it applies, the EU GDPR (explicit consent for health data). The data is encrypted and only the people involved can see it. I can withdraw consent or ask to access, correct or delete my data by contacting the Data Protection Officer.",
        'privacy_url' => '',
        'staff_email' => '', 'notify_doctors' => '1',
        'remind_days' => '1', 'remind_hour' => '9', 'day_hour' => '7',
        'mail_received' => '1', 'mail_confirmed' => '1', 'mail_reminder' => '1', 'mail_day' => '1', 'mail_cancelled' => '1', 'mail_rescheduled' => '1',
    ] + idev_appt_template_defaults();
}
function idev_appt_settings() {
    $s = get_option('idev_appt_settings', []);
    return array_merge(idev_appt_setting_defaults(), is_array($s) ? $s : []);
}

/** E-mail texts. Placeholders: {name} {ref} {date} {time} {provider} {location} {status} {reason} {site} {phone} — the manage button is added automatically. */
function idev_appt_template_defaults() {
    return [
        'tpl_received_subject' => 'ได้รับคำขอนัดหมาย {ref}', 'tpl_received_subject_en' => 'Appointment request received {ref}',
        'tpl_received_body' => "เรียน {name}\n\nเราได้รับคำขอนัดหมายของท่านแล้ว เจ้าหน้าที่จะยืนยันนัดและแจ้งทางอีเมลอีกครั้ง\n\n{provider}\n{date} เวลา {time}", 'tpl_received_body_en' => "Dear {name},\n\nWe have received your appointment request. We will confirm it by e-mail.\n\n{provider}\n{date}, {time}",
        'tpl_confirmed_subject' => 'ยืนยันนัดหมาย {date} {time}', 'tpl_confirmed_subject_en' => 'Appointment confirmed: {date} {time}',
        'tpl_confirmed_body' => "เรียน {name}\n\nนัดหมายของท่านได้รับการยืนยันแล้ว\n\n{provider}\n{date} เวลา {time}\n{location}\n\nกรุณามาก่อนเวลานัด 15 นาที พร้อมบัตรประชาชนหรือหนังสือเดินทาง", 'tpl_confirmed_body_en' => "Dear {name},\n\nYour appointment is confirmed.\n\n{provider}\n{date}, {time}\n{location}\n\nPlease arrive 15 minutes early and bring your ID card or passport.",
        'tpl_reminder_subject' => 'แจ้งเตือนนัดหมาย {date} {time}', 'tpl_reminder_subject_en' => 'Reminder: appointment on {date} {time}',
        'tpl_reminder_body' => "เรียน {name}\n\nขอเตือนนัดหมายของท่าน\n\n{provider}\n{date} เวลา {time}\n{location}\n\nหากมาไม่ได้ กรุณาเลื่อนหรือยกเลิกนัดล่วงหน้า", 'tpl_reminder_body_en' => "Dear {name},\n\nThis is a reminder of your appointment.\n\n{provider}\n{date}, {time}\n{location}\n\nIf you cannot come, please reschedule or cancel in advance.",
        'tpl_day_subject' => 'วันนี้ท่านมีนัด เวลา {time}', 'tpl_day_subject_en' => 'Today: your appointment at {time}',
        'tpl_day_body' => "เรียน {name}\n\nวันนี้ท่านมีนัดหมาย\n\n{provider}\nเวลา {time}\n{location}", 'tpl_day_body_en' => "Dear {name},\n\nYou have an appointment today.\n\n{provider}\n{time}\n{location}",
        'tpl_cancelled_subject' => 'ยกเลิกนัดหมาย {ref}', 'tpl_cancelled_subject_en' => 'Appointment cancelled {ref}',
        'tpl_cancelled_body' => "เรียน {name}\n\nนัดหมายวันที่ {date} เวลา {time} กับ {provider} ถูกยกเลิกแล้ว {reason}\n\nหากต้องการนัดใหม่ กรุณาจองผ่านเว็บไซต์หรือโทร {phone}", 'tpl_cancelled_body_en' => "Dear {name},\n\nYour appointment on {date}, {time} with {provider} has been cancelled. {reason}\n\nTo book again, please use our website or call {phone}.",
        'tpl_rescheduled_subject' => 'เปลี่ยนเวลานัดหมายเป็น {date} {time}', 'tpl_rescheduled_subject_en' => 'Appointment moved to {date} {time}',
        'tpl_rescheduled_body' => "เรียน {name}\n\nนัดหมายของท่านถูกเปลี่ยนเป็น\n\n{provider}\n{date} เวลา {time}\n{location}\n\nสถานะ: {status}", 'tpl_rescheduled_body_en' => "Dear {name},\n\nYour appointment has been moved to\n\n{provider}\n{date}, {time}\n{location}\n\nStatus: {status}",
    ];
}

add_action('admin_menu', function () {
    add_submenu_page('idev-appt', __('Appointment settings', 'idev-appointments'), __('Settings', 'idev-appointments'), 'manage_options', 'idev-appt-settings', 'idev_appt_settings_page');
}, 20);

function idev_appt_settings_fields($tab) {
    $pages = ['0' => __('— choose —', 'idev-appointments')];
    foreach (get_pages(['post_status' => 'publish']) as $pg) $pages[(string) $pg->ID] = $pg->post_title;
    $hours = []; for ($h = 0; $h < 24; $h++) $hours[(string) $h] = sprintf('%02d:00', $h);
    switch ($tab) {
        case 'general': return [
            ['page', __('Booking page', 'idev-appointments'), 'select', __('The page with the "Book an appointment" block. Each doctor or clinic gets its own address under it, e.g. /booking/dr-somchai/.', 'idev-appointments'), $pages],
            ['portal_page', __('Doctor portal page', 'idev-appointments'), 'select', __('The page with the "Doctor portal" block, linked from staff e-mails. Empty = the back office.', 'idev-appointments'), $pages],
            ['register_page', __('New patient registration page', 'idev-appointments'), 'select', __('Patients without an HN are sent here to register first.', 'idev-appointments'), $pages],
            ['identity', __('Who can book', 'idev-appointments'), 'select', __('HN + date of birth are checked against online registrations. An HN the website does not know (patients registered at the counter) is accepted but always needs staff confirmation.', 'idev-appointments'), [
                'hn_any' => __('Any patient with an HN, and new patients who registered online (recommended)', 'idev-appointments'),
                'registered' => __('Only patients registered online (HN or registration reference)', 'idev-appointments')]],
            ['default_on', __('Online booking for every doctor and clinic', 'idev-appointments'), 'checkbox', __('Can be turned off for each one on its edit page.', 'idev-appointments')],
            ['slot_minutes', __('Length of one time slot (minutes)', 'idev-appointments'), 'number', __('Can be changed for each doctor or clinic.', 'idev-appointments'), [5, 240]],
            ['capacity', __('Appointments per time slot', 'idev-appointments'), 'number', '', [1, 200]],
            ['break_minutes', __('Break between time slots (minutes)', 'idev-appointments'), 'number', __('Time left free after each slot (e.g. slot 15 + break 5 = slots at 09:00, 09:20, 09:40). Can be changed for each doctor, clinic or service.', 'idev-appointments'), [0, 120]],
            ['ask_cid', __('Thai ID / passport number when booking', 'idev-appointments'), 'select', '', ['required' => __('Required', 'idev-appointments'), 'optional' => __('Optional', 'idev-appointments'), 'off' => __('Do not ask', 'idev-appointments')]],
            ['flow', __('Booking steps', 'idev-appointments'), 'select', __('For clinics / services that have doctors, staff or sub-services under them.', 'idev-appointments'), ['who_first' => __('Service → doctor / staff / sub-service → day → time → patient → agreement', 'idev-appointments'), 'time_first' => __('Service → day → time → sub-service / doctor free at that time → patient → agreement', 'idev-appointments')]],
            ['doctor_scope', __('Doctors see the appointments of', 'idev-appointments'), 'select', __('Can be changed for each doctor on its edit page.', 'idev-appointments'), ['own' => __('Only themselves', 'idev-appointments'), 'clinic' => __('Their whole clinic / service', 'idev-appointments')]],
            ['confirm', __('Confirmation', 'idev-appointments'), 'select', __('Automatic: confirmed at once when the patient is known. Staff: the doctor or staff confirm each request.', 'idev-appointments'), ['manual' => __('Staff confirm each appointment', 'idev-appointments'), 'auto' => __('Automatic', 'idev-appointments')]],
            ['lead_hours', __('Book at least (hours ahead)', 'idev-appointments'), 'number', '', [0, 720]],
            ['max_days', __('Book up to (days ahead)', 'idev-appointments'), 'number', '', [1, 365]],
            ['change_hours', __('Patients can cancel or move until (hours before)', 'idev-appointments'), 'number', '', [0, 720]],
            ['max_reschedules', __('Times a patient may move one appointment', 'idev-appointments'), 'number', '', [0, 10]],
            ['max_upcoming', __('Upcoming appointments per patient', 'idev-appointments'), 'number', '', [1, 20]],
            ['require_email', __('E-mail required', 'idev-appointments'), 'checkbox', __('Needed for confirmations and reminders.', 'idev-appointments')],
            ['ask_reason', __('Ask for the reason for the visit', 'idev-appointments'), 'checkbox'],
            ['location', __('Where to come (Thai)', 'idev-appointments'), 'textarea'], ['location_en', __('Where to come (English)', 'idev-appointments'), 'textarea'],
            ['phone', __('Phone for appointments', 'idev-appointments'), 'text'],
            ['accent', __('Colour', 'idev-appointments'), 'color'],
        ];
        case 'consent': return [
            ['consent', __('Consent text (Thai)', 'idev-appointments'), 'textarea', __('{org} = site name. Changing the text starts a new version, saved with each appointment.', 'idev-appointments')],
            ['consent_en', __('Consent text (English, GDPR)', 'idev-appointments'), 'textarea'],
            ['privacy_url', __('Privacy policy link', 'idev-appointments'), 'url'],
        ];
        case 'emails':
            $f = [
                ['staff_email', __('E-mail staff about new, moved and cancelled appointments', 'idev-appointments'), 'text', __('Addresses separated by commas.', 'idev-appointments')],
                ['notify_doctors', __('Also e-mail the doctor\'s login', 'idev-appointments'), 'checkbox'],
                ['h_rem', __('Reminders', 'idev-appointments'), 'heading'],
                ['remind_days', __('Reminder before the day (days before)', 'idev-appointments'), 'number', __('0 = no reminder before the day.', 'idev-appointments'), [0, 14]],
                ['remind_hour', __('Send it at', 'idev-appointments'), 'select', '', $hours],
                ['day_hour', __('Reminder on the day, at', 'idev-appointments'), 'select', __('Only for appointments later than this time.', 'idev-appointments'), $hours],
            ];
            foreach (idev_appt_mail_types() as $k => $label) {
                $f[] = ['h_' . $k, $label, 'heading'];
                $f[] = ['mail_' . $k, __('Send', 'idev-appointments'), 'checkbox'];
                $f[] = ['tpl_' . $k . '_subject', __('Subject (Thai)', 'idev-appointments'), 'text'];
                $f[] = ['tpl_' . $k . '_body', __('Text (Thai)', 'idev-appointments'), 'textarea'];
                $f[] = ['tpl_' . $k . '_subject_en', __('Subject (English)', 'idev-appointments'), 'text'];
                $f[] = ['tpl_' . $k . '_body_en', __('Text (English)', 'idev-appointments'), 'textarea'];
            }
            return $f;
    }
    return [];
}
function idev_appt_mail_types() {
    return ['received' => __('Request received (waiting for confirmation)', 'idev-appointments'), 'confirmed' => __('Appointment confirmed', 'idev-appointments'), 'reminder' => __('Reminder before the day', 'idev-appointments'), 'day' => __('Reminder on the day', 'idev-appointments'), 'cancelled' => __('Cancelled', 'idev-appointments'), 'rescheduled' => __('Moved', 'idev-appointments')];
}

function idev_appt_settings_page() {
    if (!current_user_can('manage_options')) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-appointments'));
    $tabs = ['general' => __('Booking', 'idev-appointments'), 'consent' => __('Consent (PDPA / GDPR)', 'idev-appointments'), 'emails' => __('E-mails & reminders', 'idev-appointments')];
    $tab = sanitize_key($_GET['tab'] ?? 'general');
    if (!isset($tabs[$tab])) $tab = 'general';
    $s = idev_appt_settings();
    $fields = idev_appt_settings_fields($tab);
    if (isset($_POST['idev_appt_settings']) && check_admin_referer('idev_appt_settings_' . $tab)) {
        $old = $s;
        $s = idev_settings_sanitize($fields, wp_unslash($_POST['idev_appt_settings']), $s);
        if ($tab === 'consent' && ($old['consent'] !== $s['consent'] || $old['consent_en'] !== $s['consent_en'])) $s['consent_version'] = (string) ((int) $old['consent_version'] + 1);
        update_option('idev_appt_settings', $s, false);
        if ($tab === 'general' && $old['page'] !== $s['page']) update_option('idev_appt_flush', 1, false);
        echo '<div class="notice notice-success"><p>' . esc_html__('Saved.', 'idev-appointments') . '</p></div>';
    }
    idev_admin_header(__('Appointment settings', 'idev-appointments'));
    echo '<nav class="nav-tab-wrapper">';
    foreach ($tabs as $k => $l) echo '<a class="nav-tab' . ($k === $tab ? ' nav-tab-active' : '') . '" href="' . esc_url(admin_url('admin.php?page=idev-appt-settings&tab=' . $k)) . '">' . esc_html($l) . '</a>';
    echo '</nav><form method="post">';
    wp_nonce_field('idev_appt_settings_' . $tab);
    if ($tab === 'general') {
        $url = idev_appt_booking_url();
        echo '<div class="idev-card"><p>' . esc_html__('1. Create a page and add the block "Book an appointment" (or the shortcode [idev_booking]). 2. Choose it below. 3. Create a page with the block "Doctor portal" ([idev_doctor_portal]) for doctors, and link each doctor\'s WordPress login on the doctor\'s edit page.', 'idev-appointments') . '</p>' . ($url ? '<p>' . esc_html__('Booking page:', 'idev-appointments') . ' <a href="' . esc_url($url) . '" target="_blank">' . esc_html($url) . '</a></p>' : '') . '</div>';
    }
    if ($tab === 'emails') echo '<p class="description">' . esc_html__('Placeholders: {name} {ref} {date} {time} {provider} {location} {status} {reason} {phone} {site}. A button to view, move or cancel the appointment is added under the text.', 'idev-appointments') . '</p>';
    idev_settings_table('idev_appt_settings', $fields, $s);
    submit_button();
    echo '</form></div>';
}
