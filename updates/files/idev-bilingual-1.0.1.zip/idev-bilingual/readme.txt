=== iDev Bilingual TH/EN ===
Contributors: idevapp2023
Donate link: https://idevapp.me/
Tags: bilingual, thai, english, language switcher
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Two languages (Thai / English) without duplicating pages: English title, excerpt and content per post, English menu labels and category names, a

== Description ==

Two languages (Thai / English) without duplicating pages: English title, excerpt and content per post, English menu labels and category names, a TH/EN switcher, and the language follows the visitor for every iDev plugin.

= Features =

* English fields on posts and pages
* English menu labels and category names
* Switcher (buttons or links) and shortcode [idev_lang_switch]
* ?lang=en / ?lang=th links, remembered in a cookie
* Plugin strings follow the visitor language

Thai and English interface. Works with any theme. Part of the iDevApp plugin suite for hospitals and clinics — all iDev plugins appear under the **iDevApp** menu.

== Installation ==

1. Plugins → Add New → Upload Plugin, choose the zip, Install, Activate.
2. Open **iDevApp** in the admin menu for settings.

== Changelog ==

= 1.0.0 =
* First release.
