<?php
// Removes the plugin settings. English texts (post meta) are kept so they are not lost by mistake.
defined('WP_UNINSTALL_PLUGIN') || exit;
delete_option('idev_bilingual');
