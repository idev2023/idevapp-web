<?php
defined('ABSPATH') || exit;

add_action('init', function () {
    load_plugin_textdomain('idev-bilingual', false, dirname(plugin_basename(IDEV_BL_FILE)) . '/languages');
    idev_register_plugin('idev-bilingual', ['name' => 'iDev Bilingual', 'version' => IDEV_BL_VERSION, 'description' => __('Thai / English for the whole site.', 'idev-bilingual'), 'settings' => admin_url('admin.php?page=idev-bilingual'), 'docs' => 'https://idevapp.me/plugins/idev-bilingual']);
});
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_BL_FILE, admin_url('admin.php?page=idev-bilingual'), 'https://idevapp.me/plugins/idev-bilingual'); });

add_action('admin_menu', function () {
    add_submenu_page('idevapp', __('Bilingual TH/EN', 'idev-bilingual'), __('Bilingual TH/EN', 'idev-bilingual'), 'manage_options', 'idev-bilingual', 'idev_bl_settings_page');
});

function idev_bl_settings_page() {
    if (!current_user_can('manage_options')) return;
    $fields = [
        ['default_lang', __('Default language', 'idev-bilingual'), 'select', __('Shown to visitors who have not chosen a language yet.', 'idev-bilingual'), ['th' => 'ไทย', 'en' => 'English']],
        ['site_name_en', __('Site name in English', 'idev-bilingual'), 'text'],
        ['tagline_en', __('Tagline in English', 'idev-bilingual'), 'text'],
        ['menu_location', __('Add the TH/EN switcher to this menu', 'idev-bilingual'), 'select', __('Or place the shortcode [idev_lang_switch] anywhere.', 'idev-bilingual'), ['' => __('— none —', 'idev-bilingual')] + get_registered_nav_menus()],
        ['switch_style', __('Switcher style', 'idev-bilingual'), 'select', '', ['buttons' => 'TH | EN', 'links' => 'ไทย | English', 'dropdown' => __('Drop-down', 'idev-bilingual')]],
        ['nocache', __('Do not let browsers cache pages', 'idev-bilingual'), 'checkbox', __('Keeps each visitor on the language they chose. If you use a page cache (Varnish, WP Rocket…), exclude the "lang" cookie from it.', 'idev-bilingual')],
    ];
    $s = idev_bl_settings();
    if (isset($_POST['idev_bilingual']) && check_admin_referer('idev_bl_save')) {
        $s = idev_settings_sanitize($fields, $_POST['idev_bilingual'], $s);
        $types = isset($_POST['post_types']) ? array_map('sanitize_key', (array) $_POST['post_types']) : [];
        $s['post_types'] = array_values(array_intersect($types, array_keys(get_post_types(['public' => true]))));
        update_option('idev_bilingual', $s);
        echo '<div class="notice notice-success"><p>' . esc_html__('Saved.', 'idev-bilingual') . '</p></div>';
    }
    idev_admin_header(__('Bilingual TH/EN', 'idev-bilingual'), __('Each post and page gets an "English version" box. Empty English fields fall back to Thai.', 'idev-bilingual'));
    echo '<form method="post">';
    wp_nonce_field('idev_bl_save');
    idev_settings_table('idev_bilingual', $fields, $s);
    echo '<table class="form-table"><tr><th>' . esc_html__('Content types with an English version', 'idev-bilingual') . '</th><td>';
    foreach (get_post_types(['public' => true], 'objects') as $type) {
        if ($type->name === 'attachment') continue;
        echo '<label style="display:block"><input type="checkbox" name="post_types[]" value="' . esc_attr($type->name) . '"' . checked(in_array($type->name, $s['post_types'], true), true, false) . '> ' . esc_html($type->labels->name) . '</label>';
    }
    echo '</td></tr></table>';
    submit_button();
    echo '</form><div class="idev-box"><h2>' . esc_html__('How to use', 'idev-bilingual') . '</h2><ul style="list-style:disc;padding-left:20px">';
    echo '<li>' . esc_html__('Posts and pages: fill in the "English version" box under the editor.', 'idev-bilingual') . '</li>';
    echo '<li>' . esc_html__('Menus: Appearance → Menus → open an item → "English label".', 'idev-bilingual') . '</li>';
    echo '<li>' . esc_html__('Categories: Posts → Categories → edit → "Name in English".', 'idev-bilingual') . '</li>';
    echo '<li>' . esc_html__('Switcher: shortcode [idev_lang_switch] or [idev_lang_switch style="dropdown"], or links ?lang=en / ?lang=th.', 'idev-bilingual') . '</li>';
    echo '<li>' . esc_html__('Developers: idev_lang() returns "th" or "en"; idev_pick($thai, $english) picks the right text.', 'idev-bilingual') . '</li></ul></div></div>';
}

/* ---------- English version box ---------- */

add_action('add_meta_boxes', function ($post_type) {
    if (!in_array($post_type, idev_bl_settings()['post_types'], true)) return;
    add_meta_box('idev_bl_english', __('English version', 'idev-bilingual'), 'idev_bl_box', $post_type, 'normal', 'high');
});

function idev_bl_box($post) {
    wp_nonce_field('idev_bl_box', 'idev_bl_nonce');
    echo '<div class="idev-form"><p class="description">' . esc_html__('Leave empty to show the Thai text to English visitors.', 'idev-bilingual') . '</p>';
    echo '<label>' . esc_html__('Title (English)', 'idev-bilingual') . '<input name="idev_bl[title]" value="' . esc_attr(idev_bl_en($post->ID, 'title')) . '"></label>';
    echo '<label>' . esc_html__('Excerpt / summary (English)', 'idev-bilingual') . '<textarea name="idev_bl[excerpt]" rows="2">' . esc_textarea(idev_bl_en($post->ID, 'excerpt')) . '</textarea></label>';
    echo '<p><strong>' . esc_html__('Content (English)', 'idev-bilingual') . '</strong> — ' . esc_html__('replaces the whole content for English visitors.', 'idev-bilingual') . '</p>';
    wp_editor(idev_bl_en($post->ID, 'content'), 'idev_bl_content', ['textarea_name' => 'idev_bl[content]', 'textarea_rows' => 10]);
    echo '</div>';
}

add_action('save_post', function ($post_id) {
    if (!isset($_POST['idev_bl_nonce']) || !wp_verify_nonce(sanitize_key($_POST['idev_bl_nonce']), 'idev_bl_box')) return;
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $post_id)) return;
    $in = wp_unslash($_POST['idev_bl'] ?? []);
    update_post_meta($post_id, '_idev_title_en', sanitize_text_field($in['title'] ?? ''));
    update_post_meta($post_id, '_idev_excerpt_en', sanitize_textarea_field($in['excerpt'] ?? ''));
    update_post_meta($post_id, '_idev_content_en', wp_slash(wp_kses_post($in['content'] ?? '')));
});

/* ---------- Menus and categories ---------- */

add_action('wp_nav_menu_item_custom_fields', function ($item_id) {
    echo '<p class="description description-wide"><label>' . esc_html__('English label', 'idev-bilingual') . '<br><input type="text" class="widefat" name="idev_label_en[' . (int) $item_id . ']" value="' . esc_attr(get_post_meta($item_id, '_idev_label_en', true)) . '"></label></p>';
});
add_action('wp_update_nav_menu_item', function ($menu_id, $item_id) {
    if (isset($_POST['idev_label_en'][$item_id])) update_post_meta($item_id, '_idev_label_en', sanitize_text_field(wp_unslash($_POST['idev_label_en'][$item_id])));
}, 10, 2);

foreach (['category', 'post_tag'] as $idev_tax) {
    add_action("{$idev_tax}_edit_form_fields", function ($term) {
        echo '<tr class="form-field"><th><label for="idev-name-en">' . esc_html__('Name in English', 'idev-bilingual') . '</label></th><td><input id="idev-name-en" name="idev_name_en" value="' . esc_attr(get_term_meta($term->term_id, 'idev_name_en', true)) . '"></td></tr>';
    });
    add_action("{$idev_tax}_add_form_fields", function () {
        echo '<div class="form-field"><label for="idev-name-en">' . esc_html__('Name in English', 'idev-bilingual') . '</label><input id="idev-name-en" name="idev_name_en"></div>';
    });
    add_action("edited_{$idev_tax}", 'idev_bl_save_term');
    add_action("created_{$idev_tax}", 'idev_bl_save_term');
}
function idev_bl_save_term($term_id) {
    if (isset($_POST['idev_name_en'])) update_term_meta($term_id, 'idev_name_en', sanitize_text_field(wp_unslash($_POST['idev_name_en'])));
}
