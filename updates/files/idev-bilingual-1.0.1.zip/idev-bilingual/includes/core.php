<?php
defined('ABSPATH') || exit;

function idev_bl_defaults() {
    return ['default_lang' => (strpos((string) get_option('WPLANG'), 'th') === 0 ? 'th' : 'en'), 'cookie' => 'lang', 'post_types' => ['post', 'page'], 'site_name_en' => '', 'tagline_en' => '', 'menu_location' => '', 'switch_style' => 'buttons', 'nocache' => '1'];
}
function idev_bl_settings() {
    $saved = get_option('idev_bilingual', []);
    return array_merge(idev_bl_defaults(), is_array($saved) ? $saved : []);
}

/** Visitor language: ?lang → cookie → default. Admin screens follow the user's own WordPress language. */
function idev_bilingual_lang() {
    global $idev_bl_forced;
    if ($idev_bl_forced) return $idev_bl_forced;
    $s = idev_bl_settings();
    if (is_admin() && !wp_doing_ajax()) return strpos(get_user_locale(), 'th') === 0 ? 'th' : 'en';
    $cookie = $_COOKIE[$s['cookie']] ?? '';
    if (in_array($cookie, ['th', 'en'], true)) return $cookie;
    return $s['default_lang'] === 'en' ? 'en' : 'th';
}
/** Forces a language for the rest of the request (e.g. an editor preview). */
function idev_bilingual_force($lang) {
    global $idev_bl_forced;
    $idev_bl_forced = in_array($lang, ['th', 'en'], true) ? $lang : null;
}
function idev_bilingual_url($lang) { return add_query_arg('lang', $lang); }

// WordPress and every plugin's translations follow the visitor's language on the front end.
function idev_bl_locale($locale) {
    if (is_admin() && !wp_doing_ajax()) return $locale;
    // Block editor requests come from the admin: keep the editor's own language.
    if (strpos((string) ($_SERVER['HTTP_REFERER'] ?? ''), '/wp-admin/') !== false && strpos((string) ($_SERVER['REQUEST_URI'] ?? ''), 'idev_preview_lang') === false) return $locale;
    return idev_bilingual_lang() === 'th' ? 'th' : 'en_US';
}
add_filter('locale', 'idev_bl_locale', 99);
add_filter('determine_locale', 'idev_bl_locale', 99);

// ?lang=en sets the cookie and reloads the page without the parameter.
add_action('template_redirect', function () {
    if (!isset($_GET['lang']) || !in_array($_GET['lang'], ['th', 'en'], true)) return;
    $s = idev_bl_settings();
    $lang = sanitize_key($_GET['lang']);
    setcookie($s['cookie'], $lang, ['expires' => time() + YEAR_IN_SECONDS, 'path' => COOKIEPATH ?: '/', 'samesite' => 'Lax', 'secure' => is_ssl()]);
    $_COOKIE[$s['cookie']] = $lang;
    nocache_headers();
    wp_safe_redirect(remove_query_arg('lang'));
    exit;
}, 1);

add_action('send_headers', function () {
    if (is_admin()) return;
    header('Vary: Cookie', false);
    if (idev_bl_settings()['nocache'] === '1' && !is_user_logged_in()) header('Cache-Control: private, max-age=0');
});

add_filter('language_attributes', function ($output) {
    if (is_admin()) return $output;
    return preg_replace('/lang="[^"]*"/', 'lang="' . idev_bilingual_lang() . '"', $output);
});

/* ---------- Site name, posts, menus, categories ---------- */

add_filter('option_blogname', function ($v) { $en = idev_bl_settings()['site_name_en']; return (!is_admin() && idev_bilingual_lang() === 'en' && $en !== '') ? $en : $v; });
add_filter('option_blogdescription', function ($v) { $en = idev_bl_settings()['tagline_en']; return (!is_admin() && idev_bilingual_lang() === 'en' && $en !== '') ? $en : $v; });

function idev_bl_en($post_id, $key) { return (string) get_post_meta($post_id, "_idev_{$key}_en", true); }
function idev_bl_front_en() { return !is_admin() && idev_bilingual_lang() === 'en'; }

add_filter('the_title', function ($title, $post_id = 0) {
    if (!$post_id || !idev_bl_front_en()) return $title;
    $en = idev_bl_en($post_id, 'title');
    return $en !== '' ? esc_html($en) : $title;
}, 10, 2);
add_filter('single_post_title', function ($title, $post) {
    if (!$post || !idev_bl_front_en()) return $title;
    $en = idev_bl_en($post->ID, 'title');
    return $en !== '' ? $en : $title;
}, 10, 2);
add_filter('document_title_parts', function ($parts) {
    if (idev_bl_front_en() && is_singular()) { $en = idev_bl_en(get_queried_object_id(), 'title'); if ($en !== '') $parts['title'] = $en; }
    return $parts;
});
add_filter('get_the_excerpt', function ($excerpt, $post) {
    if (!$post || !idev_bl_front_en()) return $excerpt;
    $en = idev_bl_en($post->ID, 'excerpt');
    return $en !== '' ? $en : $excerpt;
}, 10, 2);
/** Excerpt written by hand in the current language (no automatic excerpt from the content). */
function idev_bilingual_excerpt($post) {
    $post = get_post($post);
    return $post ? idev_pick($post->post_excerpt, idev_bl_en($post->ID, 'excerpt')) : '';
}
add_filter('the_content', function ($content) {
    if (!idev_bl_front_en()) return $content;
    $post = get_post();
    if (!$post || !in_the_loop()) return $content;
    $en = idev_bl_en($post->ID, 'content');
    return trim($en) !== '' ? $en : $content;
}, 1);

add_filter('wp_nav_menu_objects', function ($items) {
    if (!idev_bl_front_en()) return $items;
    foreach ($items as $item) { $en = get_post_meta($item->ID, '_idev_label_en', true); if ($en !== '') $item->title = $en; }
    return $items;
});

function idev_bl_term_en($term) {
    if ($term instanceof WP_Term && idev_bl_front_en()) { $en = get_term_meta($term->term_id, 'idev_name_en', true); if ($en !== '') { $term = clone $term; $term->name = $en; } }
    return $term;
}
add_filter('get_term', 'idev_bl_term_en');
add_filter('get_terms', function ($terms) { return is_array($terms) ? array_map(function ($t) { return idev_bl_term_en($t); }, $terms) : $terms; });
add_filter('get_the_terms', function ($terms) { return is_array($terms) ? array_map('idev_bl_term_en', $terms) : $terms; });

/* ---------- Switcher ---------- */

function idev_bilingual_switcher($style = null) {
    $style = $style ?: idev_bl_settings()['switch_style'];
    $lang = idev_bilingual_lang();
    $label = esc_attr__('Choose language', 'idev-bilingual');
    if ($style === 'dropdown') {
        return '<select class="idev-lang-select" aria-label="' . $label . '" onchange="location.href=this.value"><option value="' . esc_url(idev_bilingual_url('th')) . '"' . selected($lang, 'th', false) . '>ไทย</option><option value="' . esc_url(idev_bilingual_url('en')) . '"' . selected($lang, 'en', false) . '>English</option></select>';
    }
    $html = '<span class="idev-lang-switch idev-lang-' . esc_attr($style) . '" role="group" aria-label="' . $label . '">';
    foreach (['th' => $style === 'links' ? 'ไทย' : 'TH', 'en' => $style === 'links' ? 'English' : 'EN'] as $code => $text) {
        $html .= '<a href="' . esc_url(idev_bilingual_url($code)) . '" rel="nofollow" hreflang="' . $code . '"' . ($lang === $code ? ' class="is-active" aria-current="true"' : '') . '>' . $text . '</a>';
    }
    return $html . '</span>';
}
add_shortcode('idev_lang_switch', function ($atts) { $atts = shortcode_atts(['style' => ''], $atts); return idev_bilingual_switcher($atts['style'] ?: null); });

add_filter('wp_nav_menu_items', function ($items, $args) {
    $loc = idev_bl_settings()['menu_location'];
    if ($loc && isset($args->theme_location) && $args->theme_location === $loc) $items .= '<li class="menu-item idev-lang-menu-item">' . idev_bilingual_switcher() . '</li>';
    return $items;
}, 10, 2);

add_action('wp_enqueue_scripts', function () {
    wp_register_style('idev-bilingual', false, [], IDEV_BL_VERSION);
    wp_enqueue_style('idev-bilingual');
    wp_add_inline_style('idev-bilingual', '.idev-lang-switch{display:inline-flex;gap:2px;padding:3px;border:1px solid rgba(0,0,0,.12);border-radius:10px;background:rgba(255,255,255,.6)}.idev-lang-switch a{display:inline-flex;align-items:center;justify-content:center;min-width:40px;min-height:36px;padding:4px 10px;border-radius:8px;font-weight:700;text-decoration:none;color:inherit}.idev-lang-switch a.is-active{background:var(--idev-primary,#169c91);color:#fff}.idev-lang-links{border:0;background:none}.idev-lang-links a{min-width:0}');
});

/* ---------- Activation: bring English texts over from the Andaman Hub plugin (if present) ---------- */

function idev_bl_activate() {
    global $wpdb;
    foreach (['title', 'excerpt', 'content'] as $key) {
        $wpdb->query($wpdb->prepare("INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) SELECT pm.post_id, %s, pm.meta_value FROM {$wpdb->postmeta} pm WHERE pm.meta_key=%s AND pm.meta_value<>'' AND NOT EXISTS (SELECT 1 FROM {$wpdb->postmeta} x WHERE x.post_id=pm.post_id AND x.meta_key=%s)", "_idev_{$key}_en", "ah_{$key}_en", "_idev_{$key}_en"));
    }
    $wpdb->query("INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) SELECT pm.post_id, '_idev_label_en', pm.meta_value FROM {$wpdb->postmeta} pm WHERE pm.meta_key='_ah_label_en' AND pm.meta_value<>'' AND NOT EXISTS (SELECT 1 FROM {$wpdb->postmeta} x WHERE x.post_id=pm.post_id AND x.meta_key='_idev_label_en')");
    $wpdb->query("INSERT INTO {$wpdb->termmeta} (term_id, meta_key, meta_value) SELECT tm.term_id, 'idev_name_en', tm.meta_value FROM {$wpdb->termmeta} tm WHERE tm.meta_key='ah_name_en' AND tm.meta_value<>'' AND NOT EXISTS (SELECT 1 FROM {$wpdb->termmeta} x WHERE x.term_id=tm.term_id AND x.meta_key='idev_name_en')");
    if (!get_option('idev_bilingual')) {
        $old = get_option('ah_settings', []);
        $s = idev_bl_defaults();
        if (is_array($old)) { $s['site_name_en'] = $old['site_name_en'] ?? ''; $s['tagline_en'] = $old['site_tagline_en'] ?? ''; }
        add_option('idev_bilingual', $s);
    }
}
