<?php
/** Removes Pro tables and settings. Appointments (iDev Appointments) are not touched. */
defined('WP_UNINSTALL_PLUGIN') || exit;
global $wpdb;
foreach (['messages', 'waitlist', 'line'] as $t) $wpdb->query($wpdb->prepare('DROP TABLE IF EXISTS %i', $wpdb->prefix . 'idev_apro_' . $t)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
foreach (['idev_apro_settings', 'idev_apro_branches', 'idev_apro_db', 'idev_apro_hx_token_hash', 'idev_apro_hx_seen', 'idev_apro_hx_dirty'] as $o) delete_option($o);
delete_metadata('post', 0, '_idev_apro_branch', '', true);
delete_metadata('post', 0, '_idev_apro_hx_clinic', '', true);
delete_metadata('post', 0, '_idev_apro_hx_doctor', '', true);
delete_metadata('user', 0, 'idev_apro_branches', '', true);
