<?php
/**
 * Modules: every part of the website is a module inside this plugin (modules/<folder>/<file>.php).
 * Each one can be switched on or off (iDevApp Website → โมดูล). Switched-off modules are not loaded at all.
 */
defined('ABSPATH') || exit;

/** [key => [file, name, description, group, icon, needs, settings URL (relative to wp-admin)]] in load order. */
function idw_module_list() {
    static $list = null;
    if ($list !== null) return $list;
    $list = [
        // general website tools
        'holidays' => ['idev-thai-holidays/idev-thai-holidays.php', 'วันหยุดประจำปี', 'วันหยุดราชการไทยและวันหยุดของหน่วยงาน แสดงบนเว็บและใช้กับตารางออกตรวจ / นัดหมาย', 'web', 'calendar', [], 'admin.php?page=idev-holidays'],
        'schedule' => ['idev-clinic-schedule/idev-clinic-schedule.php', 'ตารางออกตรวจ', 'ทีมแพทย์ / เจ้าหน้าที่ เวลาออกตรวจ เวลาทำการ และหน้าตารางแพทย์', 'care', 'clock', [], 'edit.php?post_type=idev_provider'],
        'registration' => ['idev-patient-registration/idev-patient-registration.php', 'ลงทะเบียนผู้ป่วยใหม่', 'ฟอร์มลงทะเบียนออนไลน์ ถ่ายบัตรประชาชน / หนังสือเดินทาง บัตรผู้ป่วยทางอีเมล และลงทะเบียน walk-in', 'care', 'idcard', [], 'admin.php?page=idev-medreg'],
        'registration-pro' => ['idev-patient-registration-pro/idev-patient-registration-pro.php', 'ลงทะเบียนผู้ป่วย Pro', 'อ่านบัตรอัตโนมัติ (OCR) และตัวเชื่อม HOSxP — ต้องมี license', 'care', 'star', ['registration'], 'admin.php?page=idev-medreg'],
        'appointments' => ['idev-appointments/idev-appointments.php', 'นัดหมายออนไลน์', 'จองคิวเป็นขั้น เลือกแพทย์ / บริการ วัน เวลา แจ้งเตือน และหน้าจัดการนัดของเจ้าหน้าที่', 'care', 'calendar', [], 'admin.php?page=idev-appt'],
        'appointments-pro' => ['idev-appointments-pro/idev-appointments-pro.php', 'นัดหมาย Pro', 'รายงาน แจ้งเตือน LINE / SMS และเครื่องมือเพิ่มเติม — ต้องมี license', 'care', 'star', ['appointments'], 'admin.php?page=idev-apro'],
        'bilingual' => ['idev-bilingual/idev-bilingual.php', 'สองภาษา ไทย / อังกฤษ', 'ปุ่มสลับภาษา ชื่อเรื่องและเนื้อหาภาษาอังกฤษในทุกหน้าและข่าว', 'web', 'globe', [], 'admin.php?page=idev-bilingual'],
        'cookie' => ['idev-cookie-consent/idev-cookie-consent.php', 'คุกกี้ PDPA', 'แบนเนอร์ขอความยินยอมใช้คุกกี้ตาม พ.ร.บ.คุ้มครองข้อมูลส่วนบุคคล', 'web', 'shield', [], 'admin.php?page=idev-cookie-consent'],
        'cookie-pro' => ['idev-cookie-consent-pro/idev-cookie-consent-pro.php', 'คุกกี้ PDPA Pro', 'บันทึกความยินยอม รายงาน และนโยบายความเป็นส่วนตัวสำเร็จรูป — ต้องมี license', 'web', 'star', ['cookie'], 'admin.php?page=idev-ccp'],
        'maps' => ['idev-maps/idev-maps.php', 'แผนที่และปุ่มนำทาง', 'แผนที่ Google / OpenStreetMap ปุ่มนำทาง และที่อยู่ของหน่วยงาน', 'web', 'pin', [], 'admin.php?page=idev-maps'],
        'ticker' => ['idev-news-ticker/idev-news-ticker.php', 'ประกาศวิ่ง', 'แถบข้อความประกาศด่วนด้านบนของเว็บ ตั้งวันเริ่ม / สิ้นสุดได้', 'web', 'megaphone', [], 'admin.php?page=idev-nt-settings'],
        'popup' => ['idev-popup-notice/idev-popup-notice.php', 'Popup ประกาศ', 'ป๊อปอัปแจ้งข่าวเมื่อเข้าเว็บ ออกแบบเองได้แบบ Word พร้อมเลย์เอาต์สำเร็จรูป', 'web', 'bell', [], 'edit.php?post_type=idev_popup'],
        'org-chart' => ['idev-org-chart/idev-org-chart.php', 'แผนผังองค์กร', 'โครงสร้างหน่วยงานและผู้บริหารแบบแผนผัง แก้ไขได้ในหลังบ้าน', 'web', 'users', [], 'edit.php?post_type=idev_orgchart'],
        'attachments' => ['idev-post-attachments/idev-post-attachments.php', 'ไฟล์แนบข่าว', 'แนบ PDF / Word / Excel ในข่าวและหน้าเว็บ แสดงเป็นรายการดาวน์โหลด', 'web', 'clip', [], 'admin.php?page=idev-pa-settings'],
        // hospital website
        'hospital' => ['hos-core/hos-core.php', 'ระบบเว็บโรงพยาบาล', 'ฟิลด์เอกสาร ปีงบประมาณ (ITA) สไลด์ [hos_slider] รายการข่าว [hos_posts] และหน้าเข้าสู่ระบบ — ใช้ได้กับทุกธีม (ธีมแบบที่ 1 สร้างหน้าเว็บสำเร็จรูปให้ด้วย)', 'hospital', 'building', [], ''],
        'campus-map' => ['hos-campus-map/hos-campus-map.php', 'ผังโรงพยาบาล 3 มิติ', 'แผนผังอาคารแบบโต้ตอบ ค้นหาจุดบริการ และ QR นำทางในโรงพยาบาล', 'hospital', 'map', [], 'admin.php?page=hos-campus'],
        'announcements' => ['idw-announcements/idw-announcements.php', 'ประกาศข่าว', 'เขียนประกาศแบบฟอร์มเดียว ตั้งวัน-เวลาเผยแพร่ / ซ่อนอัตโนมัติ อ่านไฟล์ PDF มาเติมหัวข้อ และระบบอนุมัติ', 'web', 'news', [], 'admin.php?page=idw-news'],
        'services' => ['idw-services/idw-services.php', 'การ์ดบริการ', 'ชุดการ์ดหลายชุด เช่น บริการทางการแพทย์ ลิงก์ด่วน ช่องทางติดต่อ — ไอคอนหรือรูป สี ข้อความไทย / อังกฤษ ลิงก์ และรูปแบบการ์ด แสดงด้วยบล็อกหรือ [idw_services set="…"] — ใช้ได้กับทุกธีม ไม่ต้องเปิด Hub', 'web', 'grid', [], 'admin.php?page=idw-services'],
        'hub' => ['idevapp-hub/idevapp-hub.php', 'ศูนย์บริการ (Hub)', 'บล็อกออกแบบหน้า ห้องบัตร ห้องตรวจ ผู้ใช้และสิทธิ์ แม่แบบเว็บราชการ และ SEO — บล็อกใช้ได้กับทุกธีม', 'hospital', 'grid', [], 'admin.php?page=idevapp-hub'],
        // tools for the site admin
        'security' => ['idw-security/idw-security.php', 'ตรวจความปลอดภัย', 'ตรวจตาม OWASP Top 10:2025 และช่องโหว่ CVE ของ WordPress ปลั๊กอิน ธีม และ PHP เมื่อกดปุ่ม พร้อมคำแนะนำ ปุ่มแก้ไข จำกัดการล็อกอินผิด และบันทึกเหตุการณ์', 'tools', 'shield', [], 'admin.php?page=idw-security'],
        'ssl' => ['idw-ssl/idw-ssl.php', 'ติดตั้ง SSL / HTTPS', 'นำเข้าไฟล์ใบรับรอง (.crt .key .ca-bundle หรือ .pfx) ตรวจความถูกต้อง ติดตั้งผ่าน cPanel และเปลี่ยนเว็บเป็น HTTPS', 'tools', 'lock', [], 'admin.php?page=idw-ssl'],
        'import' => ['idw-import/idw-import.php', 'ย้ายเว็บเดิม', 'วิเคราะห์โครงสร้างเว็บเดิมจากลิงก์ แล้วนำเข้าหน้า ข่าว รูป เมนู และข้อมูลติดต่อ เป็นบล็อกที่แก้ไขได้ทันที', 'tools', 'upload', [], 'admin.php?page=idw-import'],
    ];
    return $list;
}

function idw_module_groups() {
    return [
        'web' => ['เครื่องมือเว็บไซต์', 'ใช้ได้กับทุกหน่วยงาน'],
        'hospital' => ['เว็บโรงพยาบาล', 'ใช้ได้กับทุกธีม — ธีมแบบที่ 1 และแบบที่ 2 ใช้ส่วนนี้ด้วย'],
        'care' => ['บริการผู้ป่วย', 'ลงทะเบียน นัดหมาย และตารางออกตรวจ'],
        'tools' => ['เครื่องมือผู้ดูแลระบบ', 'ความปลอดภัย SSL และการย้ายเว็บเดิม'],
    ];
}

/** Modules switched on for a new site (before the setup wizard). */
function idw_default_modules() {
    return ['holidays', 'bilingual', 'cookie', 'maps', 'ticker', 'popup', 'attachments', 'announcements', 'services', 'security', 'ssl', 'import'];
}

/** After an update: modules that are new in this version and on by default get switched on once. */
function idw_new_default_modules() {
    $known = get_option('idw_known_modules', null);
    $all = array_keys(idw_module_list());
    if ($known === null) { update_option('idw_known_modules', $all, false); return; }
    $new = array_diff($all, (array) $known);
    if (!$new) return;
    update_option('idw_known_modules', $all, false);
    $on = get_option('idw_modules', null);
    if (!is_array($on)) return;
    $add = array_values(array_intersect($new, idw_default_modules()));
    if ($add) { update_option('idw_modules', array_values(array_unique(array_merge($on, $add)))); update_option('idw_activate_queue', array_values(array_unique(array_merge((array) get_option('idw_activate_queue', []), $add))), false); }
}

function idw_enabled_modules() {
    $on = get_option('idw_modules', null);
    if (!is_array($on)) $on = idw_default_modules();
    $all = idw_module_list();
    $on = array_values(array_intersect(array_keys($all), $on));
    // a Pro module needs its free module
    return array_values(array_filter($on, function ($k) use ($on, $all) { return !array_diff($all[$k][5], $on); }));
}

function idw_module_on($key) { return in_array($key, $GLOBALS['idw_loaded'] ?? [], true); }

function idw_module_file($key) {
    $m = idw_module_list()[$key] ?? null;
    return $m ? IDW_DIR . 'modules/' . $m[0] : '';
}

/** Why a module cannot load here (the same code is already running from another plugin), or ''. */
function idw_module_blocked($key) {
    $m = idw_module_list()[$key];
    $active = (array) get_option('active_plugins', []);
    if (is_multisite()) $active = array_merge($active, array_keys((array) get_site_option('active_sitewide_plugins', [])));
    if (in_array($m[0], $active, true)) return 'plugin';
    if (defined('IDEV_PACKAGE') && strpos($m[0], 'idev-') === 0) {
        foreach (['i-clinic', 'i-clinic-pro', 'i-drug'] as $pkg) if (is_dir(WP_PLUGIN_DIR . '/' . $pkg . '/modules/' . dirname($m[0]))) return 'package';
    }
    return '';
}

/** Hub features that a module of this plugin now does. */
function idw_hub_features() {
    return ['bilingual' => 'bilingual', 'schedule' => 'schedule', 'holidays' => 'holidays', 'popup' => 'popup', 'ticker' => 'ticker', 'attachments' => 'attachments', 'maps' => 'maps', 'cookie' => 'cookie', 'registration' => 'registration', 'announcements' => 'announcements'];
}

function idw_load_modules() {
    idw_new_default_modules();
    $GLOBALS['idw_loaded'] = [];
    $GLOBALS['idw_blocked'] = [];
    $on = idw_enabled_modules();
    // The hub hands over the jobs that our modules do (decided when the hub loads, so add this first).
    add_filter('ihub_uses_idev', function ($active, $feature) {
        $map = array_flip(idw_hub_features());
        return $active || (isset($map[$feature]) && idw_module_on($map[$feature]));
    }, 10, 2);
    foreach (array_keys(idw_module_list()) as $key) {
        if (!in_array($key, $on, true)) continue;
        $file = idw_module_file($key);
        if (!is_file($file)) continue;
        if ($why = idw_module_blocked($key)) { $GLOBALS['idw_blocked'][$key] = $why; continue; }
        $GLOBALS['idw_loaded'][] = $key;
        require_once $file;
    }
}

/** Run a module's own activation code (tables, default settings, roles). */
function idw_module_activate($key) {
    if (!idw_module_on($key)) return;
    do_action('activate_' . plugin_basename(idw_module_file($key)), false);
}
function idw_module_deactivate($key) {
    if (!idw_module_on($key)) return;
    do_action('deactivate_' . plugin_basename(idw_module_file($key)), false);
}

/** Save a new set of modules. Modules switched off run their deactivation now; new ones activate on the next page load. */
function idw_set_modules($keys) {
    $all = idw_module_list();
    $keys = array_values(array_intersect(array_keys($all), (array) $keys));
    foreach ($keys as $k) foreach ($all[$k][5] as $need) if (!in_array($need, $keys, true)) $keys[] = $need;
    $old = idw_enabled_modules();
    foreach (array_diff($old, $keys) as $k) idw_module_deactivate($k);
    $new = array_values(array_diff($keys, $old));
    update_option('idw_modules', array_values(array_intersect(array_keys($all), $keys)));
    if ($new) update_option('idw_activate_queue', array_values(array_unique(array_merge((array) get_option('idw_activate_queue', []), $new))), false);
    return $new;
}
function idw_enable_modules($keys) { return idw_set_modules(array_merge(idw_enabled_modules(), (array) $keys)); }

/* Modules switched on in the last request: run their activation now that their code is loaded. */
add_action('admin_init', function () {
    $q = get_option('idw_activate_queue');
    if (!$q) return;
    delete_option('idw_activate_queue');
    foreach ((array) $q as $k) idw_module_activate($k);
    flush_rewrite_rules(false);
}, 1);

function idw_activate() {
    if (get_option('idw_modules', null) === null) update_option('idw_modules', idw_default_modules());
    foreach ($GLOBALS['idw_loaded'] ?? [] as $k) idw_module_activate($k);
    if (!get_option('idw_installed')) { update_option('idw_installed', time(), false); set_transient('idw_go_setup', 1, 300); }
    idw_updater_schedule();
    flush_rewrite_rules(false);
}
function idw_deactivate() {
    foreach ($GLOBALS['idw_loaded'] ?? [] as $k) idw_module_deactivate($k);
    wp_clear_scheduled_hook('idw_update_check');
    wp_clear_scheduled_hook('idw_ann_expire');
}

/* A module that is also installed as its own plugin: offer to switch the separate plugin off. */
add_action('admin_notices', function () {
    if (empty($GLOBALS['idw_blocked']) || !current_user_can('activate_plugins')) return;
    $all = idw_module_list();
    $names = [];
    foreach ($GLOBALS['idw_blocked'] as $k => $why) $names[] = $all[$k][1] . ($why === 'package' ? ' (มีในแพ็กเกจ I-Clinic / I-Drug)' : '');
    $url = wp_nonce_url(admin_url('admin-post.php?action=idw_take_over'), 'idw_take_over');
    echo '<div class="notice notice-warning"><p><b>iDevApp Website:</b> ' . esc_html(implode(' · ', $names)) . ' ยังทำงานจากปลั๊กอินแยก ตอนนี้จึงใช้ของปลั๊กอินนั้นอยู่ (ข้อมูลเดียวกัน) ';
    if (in_array('plugin', $GLOBALS['idw_blocked'], true)) echo '<a class="button button-small" href="' . esc_url($url) . '">ปิดปลั๊กอินแยก ใช้ในปลั๊กอินนี้แทน</a>';
    echo '</p></div>';
});
add_action('admin_post_idw_take_over', function () {
    if (!current_user_can('activate_plugins') || !check_admin_referer('idw_take_over')) wp_die('ไม่มีสิทธิ์', 403);
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    $all = idw_module_list();
    $off = [];
    foreach ($GLOBALS['idw_blocked'] ?? [] as $k => $why) if ($why === 'plugin') $off[] = $all[$k][0];
    if ($off) { deactivate_plugins($off, true); update_option('idw_activate_queue', array_keys(array_filter($GLOBALS['idw_blocked'], function ($w) { return $w === 'plugin'; })), false); }
    wp_safe_redirect(admin_url('admin.php?page=idw-modules&done=takeover'));
    exit;
});
