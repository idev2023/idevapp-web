<?php
/**
 * หลังบ้าน › ผังโรงพยาบาล: เพิ่ม/ลบ/แก้ไขอาคาร บริการรายชั้น และจุดสังเกต
 * ลากกรอบบนภาพเพื่อย้ายตำแหน่ง ลากมุมขวาล่างเพื่อปรับขนาด
 */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_menu_page( 'ผังโรงพยาบาล', 'ผังโรงพยาบาล', 'edit_pages', 'hos-campus', 'hos_campus_admin_page', 'dashicons-building', 21 );
	add_submenu_page( 'hos-campus', 'แก้ไขผัง', 'แก้ไขผัง', 'edit_pages', 'hos-campus', 'hos_campus_admin_page' );
	add_submenu_page( 'hos-campus', 'เดินสำรวจพิกัด (มือถือ)', '📱 เดินสำรวจพิกัด', 'edit_pages', 'hos-campus-survey', 'hos_campus_survey_page' );
	add_submenu_page( 'hos-campus', 'QR คุณอยู่ที่นี่', '📌 QR คุณอยู่ที่นี่', 'edit_pages', 'hos-campus-qr', 'hos_campus_qr_page' );
} );

/** ทำความสะอาดข้อมูลที่ส่งมาจากหน้าแก้ไข */
function hos_campus_sanitize( $raw ) {
	$cats = array_keys( hos_campus_cats() );
	$out  = array( 'buildings' => array(), 'marks' => array() );
	$ids  = array();
	foreach ( (array) ( $raw['buildings'] ?? array() ) as $b ) {
		$name = sanitize_text_field( $b['name'] ?? '' );
		if ( '' === $name ) {
			continue;
		}
		$id = sanitize_key( $b['id'] ?? '' );
		if ( '' === $id || isset( $ids[ $id ] ) ) {
			$id = 'b' . substr( md5( $name . wp_rand() ), 0, 6 );
		}
		$ids[ $id ] = 1;
		$r          = array_map( 'intval', array_pad( (array) ( $b['r'] ?? array() ), 4, 0 ) );
		$r          = array( max( 0, min( 950, $r[0] ) ), max( 0, min( 2390, $r[1] ) ), max( 12, min( 400, $r[2] ) ), max( 12, min( 400, $r[3] ) ) );
		$floors     = array();
		foreach ( (array) ( $b['floors'] ?? array() ) as $f ) {
			$label = sanitize_text_field( $f[0] ?? '' );
			$items = array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $f[1] ?? array() ) ), 'strlen' ) );
			if ( '' !== $label ) {
				$floors[] = array( $label, $items );
			}
		}
		$out['buildings'][] = array(
			'id'     => $id,
			'name'   => $name,
			'short'  => sanitize_text_field( ( $b['short'] ?? '' ) ?: $name ),
			'icon'   => mb_substr( sanitize_text_field( $b['icon'] ?? '' ), 0, 4 ),
			'cat'    => in_array( $b['cat'] ?? '', $cats, true ) ? $b['cat'] : 'sup',
			'r'      => $r,
			'roof'   => 'flat' === ( $b['roof'] ?? '' ) ? 'flat' : 'gable',
			'door'   => in_array( $b['door'] ?? '', array( 'n', 's', 'e', 'w' ), true ) ? $b['door'] : 's',
			'sign'   => mb_substr( sanitize_text_field( $b['sign'] ?? '' ), 0, 8 ),
			'roofc'  => (string) sanitize_hex_color( $b['roofc'] ?? '' ),
			'wallc'  => (string) sanitize_hex_color( $b['wallc'] ?? '' ),
			'floors' => $floors,
		);
	}
	foreach ( (array) ( $raw['marks'] ?? array() ) as $m ) {
		$t = sanitize_text_field( $m['t'] ?? '' );
		if ( '' === $t ) {
			continue;
		}
		$out['marks'][] = array(
			't'   => $t,
			'ic'  => mb_substr( sanitize_text_field( $m['ic'] ?? '' ), 0, 4 ),
			'x'   => max( 0, min( 960, (int) ( $m['x'] ?? 0 ) ) ),
			'y'   => max( 0, min( 2400, (int) ( $m['y'] ?? 0 ) ) ),
			'k'   => array_key_exists( (string) ( $m['k'] ?? '' ), hos_campus_mark_kinds() ) ? (string) $m['k'] : 'spot', // kind: junction, door, stairs …
			'img' => esc_url_raw( (string) ( $m['img'] ?? '' ) ),                                                       // photo from the survey walk
			'b'   => sanitize_key( (string) ( $m['b'] ?? '' ) ),                                                        // building it is at / next to
		);
	}
	$ids2 = wp_list_pluck( $out['buildings'], 'id' );
	$out['doors'] = array();
	foreach ( (array) ( $raw['doors'] ?? array() ) as $o ) {
		if ( in_array( $o['b'] ?? '', $ids2, true ) && is_numeric( $o['lat'] ?? '' ) && is_numeric( $o['lng'] ?? '' ) ) {
			$out['doors'][] = array( 'b' => $o['b'], 'lat' => round( (float) $o['lat'], 7 ), 'lng' => round( (float) $o['lng'], 7 ), 't' => sanitize_text_field( $o['t'] ?? '' ) );
		}
	}
	$out['paths'] = array();
	foreach ( (array) ( $raw['paths'] ?? array() ) as $o ) {
		$pts = array();
		foreach ( (array) ( $o['pts'] ?? array() ) as $ll ) {
			if ( is_array( $ll ) && count( $ll ) >= 2 && is_numeric( $ll[0] ) && is_numeric( $ll[1] ) ) {
				$pts[] = array( round( (float) $ll[0], 7 ), round( (float) $ll[1], 7 ) );
			}
		}
		if ( count( $pts ) > 1 ) {
			$out['paths'][] = array( 't' => sanitize_text_field( $o['t'] ?? '' ), 'wc' => ! empty( $o['wc'] ), 'pts' => $pts );
		}
	}
	$out['qr'] = array();
	foreach ( (array) ( $raw['qr'] ?? array() ) as $o ) {
		$t = sanitize_text_field( $o['t'] ?? '' );
		if ( '' !== $t ) {
			$out['qr'][] = array( 'id' => sanitize_key( $o['id'] ?? '' ) ?: 'q' . wp_rand( 100, 99999 ), 't' => $t, 'x' => (int) ( $o['x'] ?? 0 ), 'y' => (int) ( $o['y'] ?? 0 ) );
		}
	}
	$geo = array();
	foreach ( (array) ( $raw['geo'] ?? array() ) as $g ) {
		$g = array_values( (array) $g );
		if ( count( $g ) === 4 && (float) $g[2] && (float) $g[3] ) {
			$geo[] = array( (int) $g[0], (int) $g[1], round( (float) $g[2], 7 ), round( (float) $g[3], 7 ) );
		}
	}
	if ( count( $geo ) === 2 ) {
		$out['geo'] = $geo;
	}
	$out['img']  = esc_url_raw( $raw['img'] ?? '' );
	$out['h']    = max( 200, min( 2400, (int) ( $raw['h'] ?? 794 ) ) );
	$out['road'] = sanitize_text_field( $raw['road'] ?? '' );
	$out['gmap'] = sanitize_text_field( $raw['gmap'] ?? '' );
	return $out;
}

/** สร้างหน้าแผนที่ให้อัตโนมัติ (ผังเต็มหน้า) */
add_action( 'admin_post_hos_campus_page', function () {
	if ( ! current_user_can( 'publish_pages' ) || ! check_admin_referer( 'hos_campus_page' ) ) {
		wp_die( 'ไม่มีสิทธิ์' );
	}
	$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'แผนที่และผังโรงพยาบาล', 'post_name' => 'map', 'post_content' => '<!-- wp:hos/campus {"full":true} /-->' ) );
	wp_safe_redirect( $id && ! is_wp_error( $id ) ? get_permalink( $id ) : admin_url( 'admin.php?page=hos-campus' ) );
	exit;
} );

/** หน้าที่มีผัง (ค้นจากเนื้อหา) */
function hos_campus_find_page() {
	$q = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => 1, 's' => 'wp:hos/campus', 'search_columns' => array( 'post_content' ) ) );
	if ( $q ) {
		return $q[0];
	}
	$q = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => 1, 's' => '[hos_campus' ) );
	return $q ? $q[0] : get_page_by_path( 'map' );
}

add_filter( 'admin_footer_text', function ( $t ) {
	$sc = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	return $sc && false !== strpos( (string) $sc->id, 'hos-campus' ) ? 'ผังโรงพยาบาล 3 มิติ ' . HOSCM_VER . ' · พัฒนาโดย <a href="https://idevapp.me" target="_blank" rel="noopener">iDevApp.me</a>' : $t;
} );

add_action( 'admin_post_hos_campus_save', function () {
	if ( ! current_user_can( 'edit_pages' ) || ! check_admin_referer( 'hos_campus_save' ) ) {
		wp_die( 'ไม่มีสิทธิ์' );
	}
	if ( ! empty( $_POST['reset'] ) ) {
		delete_option( 'hos_campus_data' );
		$msg = 'reset';
	} else {
		$raw = json_decode( wp_unslash( $_POST['hos_campus_json'] ?? '' ), true ); // phpcs:ignore
		if ( ! is_array( $raw ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=hos-campus&msg=err' ) );
			exit;
		}
		update_option( 'hos_campus_data', hos_campus_sanitize( $raw ), false );
		$msg = 'saved';
	}
	do_action( 'litespeed_purge_all' );
	wp_safe_redirect( admin_url( 'admin.php?page=hos-campus&msg=' . $msg ) );
	exit;
} );

function hos_campus_admin_page() {
	$d    = hos_campus_data();
	$cats = hos_campus_cats();
	$img  = $d['img'];
	wp_enqueue_media();
	$msg  = sanitize_key( $_GET['msg'] ?? '' ); // phpcs:ignore
	$map  = hos_campus_find_page();
	?>
	<div class="wrap hosc-wrap">
		<h1>🏥 ผังโรงพยาบาล <?php if ( $map ) : ?><a class="page-title-action" target="_blank" href="<?php echo esc_url( get_permalink( $map ) ); ?>">ดูหน้าเว็บ</a><?php endif; ?></h1>
		<?php if ( ! $map ) : ?><div class="notice notice-info"><p>ยังไม่มีหน้าที่แสดงผัง · <a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=hos_campus_page' ), 'hos_campus_page' ) ); ?>">สร้างหน้า “แผนที่และผังโรงพยาบาล” ให้อัตโนมัติ</a> หรือใส่บล็อก “ผังโรงพยาบาล 3 มิติ” / shortcode <code>[hos_campus full="1"]</code> ในหน้าที่ต้องการ</p></div><?php endif; ?>
		<?php if ( 'saved' === $msg ) : ?><div class="notice notice-success is-dismissible"><p>บันทึกแล้ว — หน้าเว็บอัปเดตทันที</p></div><?php endif; ?>
		<?php if ( 'reset' === $msg ) : ?><div class="notice notice-warning is-dismissible"><p>คืนค่าเริ่มต้นแล้ว</p></div><?php endif; ?>
		<?php if ( 'err' === $msg ) : ?><div class="notice notice-error"><p>บันทึกไม่สำเร็จ ลองใหม่อีกครั้ง</p></div><?php endif; ?>
		<p class="description">กดเลือกอาคารบนภาพหรือในรายการ · <b>ลากกรอบ</b>เพื่อย้าย · <b>ลากมุมขวาล่าง</b>เพื่อปรับขนาด · แก้ข้อมูลทางขวา แล้วกด <b>บันทึก</b></p>
		<div class="hosc-grid">
			<div>
				<div class="hosc-canvas" id="hosc-canvas" style="background-image:url('<?php echo esc_url( $img ); ?>')"></div>
				<div class="hosc-legend"><?php foreach ( $cats as $k => $c ) : ?><span style="--c:<?php echo esc_attr( $c[1] ); ?>"><?php echo esc_html( $c[0] ); ?></span><?php endforeach; ?><span class="mk">📍 จุดสังเกต</span></div>
			</div>
			<div class="hosc-side">
				<div class="hosc-tabs"><button type="button" class="button button-primary" data-tab="b">อาคาร</button><button type="button" class="button" data-tab="m">จุดสังเกต</button><button type="button" class="button" data-tab="n">ประตู/ทางเดิน</button><button type="button" class="button" data-tab="g">⚙️ ตั้งค่า / รูปแผนที่</button></div>
				<div data-pane="b">
					<div class="hosc-row"><select id="hosc-list" size="8"></select></div>
					<div class="hosc-row"><button type="button" class="button" id="hosc-add">＋ เพิ่มอาคาร</button> <button type="button" class="button" id="hosc-dup">⧉ ทำสำเนา</button> <button type="button" class="button hosc-del" id="hosc-del">ลบอาคารนี้</button></div>
					<div id="hosc-form" class="hosc-form">
						<label>ชื่ออาคาร<input type="text" data-f="name"></label>
						<div class="hosc-2"><label>ชื่อย่อบนป้าย<input type="text" data-f="short"></label><label>ไอคอน/โลโก้ (อีโมจิ)<input type="text" data-f="icon" maxlength="4" placeholder="เช่น 🚻 🍽️ 💊"></label></div>
						<div class="hosc-2">
							<label>ประเภท<select data-f="cat"><?php foreach ( $cats as $k => $c ) : ?><option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $c[0] ); ?></option><?php endforeach; ?></select></label>
							<label>หลังคา<select data-f="roof"><option value="gable">หลังคาจั่ว</option><option value="flat">ดาดฟ้า (อาคารสมัยใหม่)</option></select></label>
						</div>
						<div class="hosc-2">
							<div class="hosc-col" data-col="roofc"><span>สีหลังคา / ดาดฟ้า <small>(ไม่เลือก = สีตามประเภท)</small></span><div><input type="color" data-c="roofc"><span class="sw"></span><button type="button" class="button-link" data-cx="roofc">ใช้สีตามประเภท</button></div></div>
							<div class="hosc-col" data-col="wallc"><span>สีผนังอาคาร <small>(ไม่เลือก = สีครีม)</small></span><div><input type="color" data-c="wallc"><span class="sw"></span><button type="button" class="button-link" data-cx="wallc">ใช้สีมาตรฐาน</button></div></div>
						</div>
						<div class="hosc-2"><label>ประตูหลักหันไปทาง<select data-f="door"><option value="n">ทิศเหนือ (ด้านบนภาพ)</option><option value="s">ทิศใต้ (ด้านล่างภาพ)</option><option value="e">ทิศตะวันออก (ขวา)</option><option value="w">ทิศตะวันตก (ซ้าย)</option></select></label>
						<label>ป้ายกันสาดทางเข้า <small>(ไม่ใส่ = ไม่มีกันสาด)</small><input type="text" data-f="sign" maxlength="8" placeholder="เช่น ER, OPD"></label></div>
						<label>บริการแต่ละชั้น <small>(บรรทัดที่ขึ้นต้นด้วย “ชั้น” = ชื่อชั้น · บรรทัดที่ขึ้นต้นด้วย “-” = บริการในชั้นนั้น · จำนวนชั้นของตึกนับจากตรงนี้)</small>
							<textarea data-f="floors" rows="12" placeholder="ชั้น 1&#10;- ห้องอุบัติเหตุและฉุกเฉิน&#10;- คลินิกทันตกรรม&#10;ชั้น 2&#10;- งานการเงิน"></textarea></label>
						<div class="hosc-4"><label>X<input type="number" data-r="0"></label><label>Y<input type="number" data-r="1"></label><label>กว้าง<input type="number" data-r="2"></label><label>ยาว<input type="number" data-r="3"></label></div>
					</div>
				</div>
				<div data-pane="m" hidden>
					<p class="description">จุดสังเกตใช้เป็น “จุดเริ่มต้น” ในการนำทางบนหน้าเว็บ ลากหมุดบนภาพเพื่อย้ายตำแหน่ง</p>
					<div id="hosc-marks"></div>
					<button type="button" class="button" id="hosc-addm">＋ เพิ่มจุดสังเกต</button>
				</div>
				<div data-pane="n" hidden>
					<p class="description">ประตูและทางเดินที่เดินเก็บด้วยมือถือ (เมนู 📱 เดินเก็บพิกัด) · ลากจุดบนภาพเพื่อแก้ตำแหน่ง · ประตู = จุดวงกลม · ทางเดิน = เส้นสีส้ม (สีม่วง = รถเข็นผ่านได้)</p>
					<div id="hosc-net"></div>
				</div>
				<div data-pane="g" hidden>
					<h3>🖼️ รูปแผนที่ (พื้นของผัง)</h3>
					<p class="description">ใช้ภาพมุมบน เช่น ภาพดาวเทียมจาก Google Maps (แคปหน้าจอ) หรือแบบแปลนผังพื้นที่ · หันทิศเหนือขึ้นด้านบน · ผังจะกว้าง 960 หน่วย ความสูงตามสัดส่วนภาพ</p>
					<p><img id="hosc-imgprev" src="<?php echo esc_url( $img ); ?>" style="max-width:100%;border-radius:8px;border:1px solid #dcdcde"></p>
					<p><button type="button" class="button button-primary" id="hosc-img">เลือก/อัปโหลดรูปแผนที่</button> <button type="button" class="button-link" id="hosc-imgreset">ใช้รูปเริ่มต้น</button></p>
					<label class="hosc-full">ชื่อถนนด้านทิศเหนือ <small>(เว้นว่าง = ไม่แสดงถนน)</small><input type="text" id="hosc-road" class="widefat"></label>
					<label class="hosc-full">คำค้นสำหรับปุ่ม “นำทางด้วย Google Maps” <small>(เช่น ชื่อสถานที่บน Google Maps)</small><input type="text" id="hosc-gmap" class="widefat"></label>
					<p><button type="button" class="button hosc-del" id="hosc-clear">🗑️ เริ่มผังใหม่ (ลบอาคาร ประตู ทางเดิน จุดสังเกตทั้งหมด)</button></p>
					<h3>📡 พิกัด GPS</h3>
					<p class="description">ใช้เทียบตำแหน่ง GPS ของผู้ใช้กับภาพผัง (ปุ่ม “ตำแหน่งของฉัน”) — ใส่ 2 จุดที่อยู่ห่างกัน เช่น มุมบนซ้ายและมุมล่างขวาของโรงพยาบาล: ตำแหน่งบนภาพ (X, Y) และพิกัดจริงจาก Google Maps (คลิกขวาที่จุดนั้น › คัดลอกพิกัด)</p>
					<div id="hosc-geo"></div>
				</div>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="hosc-save" class="hosc-save">
					<?php wp_nonce_field( 'hos_campus_save' ); ?>
					<input type="hidden" name="action" value="hos_campus_save">
					<input type="hidden" name="hos_campus_json" id="hosc-json">
					<button class="button button-primary button-hero">💾 บันทึก</button>
					<button class="button-link hosc-reset" name="reset" value="1" onclick="return confirm('คืนค่าผังเริ่มต้น? ข้อมูลที่แก้ไขไว้จะหายทั้งหมด')">คืนค่าเริ่มต้น</button>
				</form>
			</div>
		</div>
	</div>
	<style>
	.hosc-grid{display:grid;grid-template-columns:minmax(0,1fr) 420px;gap:20px;margin-top:14px;align-items:start}
	.hosc-canvas{position:relative;width:100%;background-size:100% 100%;border-radius:10px;overflow:hidden;box-shadow:0 4px 18px rgba(0,0,0,.15);user-select:none}
	.hosc-b{position:absolute;border:2px solid var(--c);background:color-mix(in srgb,var(--c) 45%,transparent);border-radius:3px;cursor:move;box-sizing:border-box;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;color:#fff;text-shadow:0 1px 2px #000;text-align:center;line-height:1.1;overflow:hidden}
	.hosc-b.on{outline:3px solid #ffd400;z-index:3;background:color-mix(in srgb,var(--c) 65%,transparent)}
	.hosc-b i{position:absolute;right:-2px;bottom:-2px;width:14px;height:14px;background:#fff;border:2px solid var(--c);cursor:nwse-resize;border-radius:3px}
	.hosc-m{position:absolute;transform:translate(-50%,-100%);background:#fff;border:2px solid #0a7d55;border-radius:999px;padding:2px 8px;font-size:12px;font-weight:700;cursor:move;white-space:nowrap;z-index:4}
	.hosc-svg{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}.hosc-svg polyline{fill:none;stroke:#ff6a00;stroke-width:4;stroke-linejoin:round}.hosc-svg polyline.wc{stroke:#8a5cd6}
	.hosc-v{position:absolute;width:7px;height:7px;margin:-3.5px 0 0 -3.5px;background:#fff;border:1px solid #ff6a00;border-radius:50%;cursor:move;z-index:4}
	.hosc-d{position:absolute;width:14px;height:14px;margin:-7px 0 0 -7px;background:#ff2d55;border:3px solid #fff;border-radius:50%;cursor:move;z-index:5;box-shadow:0 1px 4px #0006}
	.hosc-mrow2{display:flex;gap:8px;align-items:center;padding:4px 0;border-bottom:1px solid #f0f0f1}.hosc-mrow2 .button-link{margin-left:auto}
	.hosc-full{display:block;margin:10px 0;font-weight:600}.hosc-full small{font-weight:400;color:#646970}
	.hosc-legend{display:flex;flex-wrap:wrap;gap:12px;margin-top:10px}.hosc-legend span:before{content:'';display:inline-block;width:12px;height:12px;border-radius:3px;background:var(--c);margin-right:5px;vertical-align:-1px}.hosc-legend .mk:before{display:none}
	.hosc-side{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:16px;position:sticky;top:46px}
	.hosc-tabs{display:flex;gap:6px;margin-bottom:12px}
	.hosc-row{margin-bottom:10px}#hosc-list{width:100%}
	.hosc-form label,#hosc-marks label{display:block;margin-bottom:10px;font-weight:600}
	.hosc-form input[type=text],.hosc-form select,.hosc-form textarea{display:block;width:100%;margin-top:4px;font-weight:400}
	.hosc-form small{font-weight:400;color:#646970}
	.hosc-2{display:grid;grid-template-columns:1fr 1fr;gap:10px}.hosc-4{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.hosc-4 input{width:100%}
	.hosc-del{color:#b32d2e!important;border-color:#b32d2e!important}
	.hosc-col{display:flex;flex-direction:column;gap:5px;font-weight:600}.hosc-col>div{display:flex;align-items:center;gap:6px;flex-wrap:wrap}.hosc-col input[type=color]{width:44px;height:32px;padding:0;border:1px solid #c3c4c7;border-radius:6px;cursor:pointer}.hosc-col .sw{display:flex;gap:3px;flex-wrap:wrap}.hosc-col .sw button{width:18px;height:18px;border-radius:50%;border:1px solid rgba(0,0,0,.2);padding:0;cursor:pointer}.hosc-col [data-cx]{font-size:12px;display:none}.hosc-col.is-set [data-cx]{display:inline}
	.hosc-mrow{display:grid;grid-template-columns:52px 1fr 60px 60px 28px;gap:6px;align-items:center;margin-bottom:8px}.hosc-mrow input{width:100%}
	.hosc-save{margin-top:16px;border-top:1px solid #eee;padding-top:14px;display:flex;align-items:center;gap:14px}.hosc-reset{color:#b32d2e!important}
	@media(max-width:1100px){.hosc-grid{grid-template-columns:1fr}.hosc-side{position:static}}
	</style>
	<script>
	(function () {
		var D = <?php echo wp_json_encode( $d, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ); ?>, CATS = <?php echo wp_json_encode( $cats, JSON_UNESCAPED_UNICODE ); ?>;
		var W = 960, H = +D.h || 794, cv = document.getElementById('hosc-canvas'), list = document.getElementById('hosc-list'), form = document.getElementById('hosc-form'), sel = 0, dirty = false;
		function k() { return cv.clientWidth / W; }
		D.doors = D.doors || []; D.paths = D.paths || []; D.qr = D.qr || [];
		function px(ll) { var a = D.geo[0], b = D.geo[1]; return [a[0] + (ll[1] - a[3]) / (b[3] - a[3]) * (b[0] - a[0]), a[1] + (ll[0] - a[2]) / (b[2] - a[2]) * (b[1] - a[1])]; }
		function ll2(x, y) { var a = D.geo[0], b = D.geo[1]; return [+(a[2] + (y - a[1]) / (b[1] - a[1]) * (b[2] - a[2])).toFixed(7), +(a[3] + (x - a[0]) / (b[0] - a[0]) * (b[3] - a[3])).toFixed(7)]; }
		function bName(id) { var b = D.buildings.filter(function (x) { return x.id === id; })[0]; return b ? b.name : id; }
		function renderNet() { var w = document.getElementById('hosc-net'); if (!w) return;
			w.innerHTML = '<h4>ประตู (' + D.doors.length + ')</h4>' + (D.doors.map(function (o, i) { return '<div class="hosc-mrow2">🚪 ' + bName(o.b) + (o.t ? ' · ' + o.t : '') + ' <button type="button" class="button-link hosc-reset" data-deld="' + i + '">ลบ</button></div>'; }).join('') || '<p>— ยังไม่มี —</p>')
				+ '<h4>ทางเดิน (' + D.paths.length + ')</h4>' + (D.paths.map(function (p, i) { return '<div class="hosc-mrow2">〰️ ' + (p.t || 'ทางเดิน ' + (i + 1)) + ' · ' + p.pts.length + ' จุด ' + '<label><input type="checkbox" data-wcp="' + i + '"' + (p.wc ? ' checked' : '') + '> ♿</label> <button type="button" class="button-link hosc-reset" data-delp="' + i + '">ลบ</button></div>'; }).join('') || '<p>— ยังไม่มี —</p>'); }
		document.addEventListener('click', function (e) { var t = e.target;
			if (t.dataset.deld !== undefined && confirm('ลบประตูนี้?')) { D.doors.splice(+t.dataset.deld, 1); dirty = true; renderNet(); draw(); }
			if (t.dataset.delp !== undefined && confirm('ลบทางเดินนี้?')) { D.paths.splice(+t.dataset.delp, 1); dirty = true; renderNet(); draw(); } });
		document.addEventListener('change', function (e) { if (e.target.dataset.wcp !== undefined) { D.paths[+e.target.dataset.wcp].wc = e.target.checked; dirty = true; draw(); } });
		function floorsText(f) { return (f || []).map(function (x) { return x[0] + '\n' + x[1].map(function (i) { return '- ' + i; }).join('\n'); }).join('\n'); }
		function parseFloors(t) { var out = [], cur = null; t.split('\n').forEach(function (l) { l = l.trim(); if (!l) return; if (/^[-•*]/.test(l)) { if (!cur) { cur = ['ชั้น 1', []]; out.push(cur); } cur[1].push(l.replace(/^[-•*]\s*/, '')); } else { cur = [l, []]; out.push(cur); } }); return out; }
		function draw() {
			cv.innerHTML = ''; var s = k();
			D.buildings.forEach(function (b, i) {
				var e = document.createElement('div'); e.className = 'hosc-b' + (i === sel ? ' on' : ''); e.style.cssText = 'left:' + b.r[0] * s + 'px;top:' + b.r[1] * s + 'px;width:' + b.r[2] * s + 'px;height:' + b.r[3] * s + 'px;--c:' + (b.roofc || (CATS[b.cat] ? CATS[b.cat][1] : '#888'));
				e.textContent = b.short || b.name; var h = document.createElement('i'); e.appendChild(h);
				drag(e, function (dx, dy, rs) { if (rs) { b.r[2] = Math.max(12, Math.round(b._r[2] + dx)); b.r[3] = Math.max(12, Math.round(b._r[3] + dy)); } else { b.r[0] = Math.round(b._r[0] + dx); b.r[1] = Math.round(b._r[1] + dy); } }, function () { b._r = b.r.slice(); if (sel !== i) { sel = i; fill(); } }, h);
				cv.appendChild(e);
			});
			var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('viewBox', '0 0 960 ' + H); svg.setAttribute('class', 'hosc-svg'); cv.appendChild(svg);
			(D.paths || []).forEach(function (p, pi) {
				var pl = document.createElementNS(svg.namespaceURI, 'polyline'); pl.setAttribute('points', p.pts.map(function (ll) { return px(ll).join(','); }).join(' ')); pl.setAttribute('class', p.wc ? 'wc' : ''); svg.appendChild(pl);
				p.pts.forEach(function (ll, k) { var h = document.createElement('div'); h.className = 'hosc-v'; var q = px(ll); h.style.cssText = 'left:' + q[0] * s + 'px;top:' + q[1] * s + 'px';
					drag(h, function (dx, dy) { var n = ll2(p._o[0] + dx, p._o[1] + dy); p.pts[k] = n; }, function () { p._o = px(p.pts[k]); }); cv.appendChild(h); });
			});
			(D.doors || []).forEach(function (o) {
				var e = document.createElement('div'); e.className = 'hosc-d'; var q = px([o.lat, o.lng]); e.style.cssText = 'left:' + q[0] * s + 'px;top:' + q[1] * s + 'px'; e.title = (bName(o.b) + ' ' + (o.t || '')).trim();
				drag(e, function (dx, dy) { var n = ll2(o._o[0] + dx, o._o[1] + dy); o.lat = n[0]; o.lng = n[1]; }, function () { o._o = px([o.lat, o.lng]); }); cv.appendChild(e);
			});
			D.marks.forEach(function (m) {
				var e = document.createElement('div'); e.className = 'hosc-m'; e.style.cssText = 'left:' + m.x * s + 'px;top:' + m.y * s + 'px'; e.textContent = (m.ic ? m.ic + ' ' : '') + m.t;
				drag(e, function (dx, dy) { m.x = Math.round(m._x + dx); m.y = Math.round(m._y + dy); }, function () { m._x = m.x; m._y = m.y; });
				cv.appendChild(e);
			});
		}
		function drag(el, move, start, handle) {
			el.addEventListener('pointerdown', function (e) {
				e.preventDefault(); e.stopPropagation(); var rs = handle && e.target === handle, x0 = e.clientX, y0 = e.clientY; start();
				function mv(ev) { var s = k(); move((ev.clientX - x0) / s, (ev.clientY - y0) / s, rs); dirty = true; draw(); syncNums(); renderMarks(); }
				function up() { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); renderList(); }
				window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
			});
		}
		function renderList() { list.innerHTML = D.buildings.map(function (b, i) { return '<option value="' + i + '"' + (i === sel ? ' selected' : '') + '>' + b.name.replace(/</g, '&lt;') + ' (' + Math.max(1, b.floors.length) + ' ชั้น)</option>'; }).join(''); }
		function q(f) { return form.querySelector('[data-f="' + f + '"]'); }
		function fill() { var b = D.buildings[sel]; form.hidden = !b; if (!b) return; ['name', 'short', 'icon', 'cat', 'roof', 'door', 'sign'].forEach(function (f) { q(f).value = b[f] || (f === 'door' ? 's' : ''); }); q('floors').value = floorsText(b.floors); fillColors(); syncNums(); renderList(); draw(); }
		var SW = { roofc: ['#c0392b', '#d35400', '#e0a100', '#2e7d32', '#0f766e', '#1565c0', '#6a1b9a', '#546e7a', '#8d6e63'], wallc: ['#f5f1e8', '#ffffff', '#fff3d6', '#fde2e2', '#e3f2fd', '#e8f5e9', '#ede7f6', '#eceff1', '#d7ccc8'] };
		function fillColors() { var b = D.buildings[sel]; if (!b) return; ['roofc', 'wallc'].forEach(function (f) { var box = form.querySelector('[data-col="' + f + '"]'), inp = box.querySelector('input'), def = f === 'roofc' ? (CATS[b.cat] ? CATS[b.cat][1] : '#888888') : '#f5f1e8'; inp.value = b[f] || def; box.classList.toggle('is-set', !!b[f]); box.querySelector('.sw').innerHTML = SW[f].map(function (c) { return '<button type="button" style="background:' + c + '" data-sw="' + c + '" title="' + c + '"></button>'; }).join(''); }); }
		form.addEventListener('click', function (e) { var b = D.buildings[sel]; if (!b) return; var t = e.target, box = t.closest('[data-col]'); if (!box) return; var f = box.dataset.col; if (t.dataset.sw) { b[f] = t.dataset.sw; } else if (t.dataset.cx) { b[f] = ''; } else return; dirty = true; fillColors(); draw(); });
		function syncNums() { var b = D.buildings[sel]; if (!b) return; form.querySelectorAll('[data-r]').forEach(function (inp) { inp.value = b.r[+inp.dataset.r]; }); }
		form.addEventListener('input', function (e) {
			var b = D.buildings[sel]; if (!b) return; var t = e.target; dirty = true;
			if (t.dataset.r !== undefined) b.r[+t.dataset.r] = parseInt(t.value, 10) || 0;
			else if (t.dataset.f === 'floors') b.floors = parseFloors(t.value);
			else if (t.dataset.c) { b[t.dataset.c] = t.value; t.closest('[data-col]').classList.add('is-set'); }
			else if (t.dataset.f) b[t.dataset.f] = t.value;
			draw(); renderList();
		});
		list.addEventListener('change', function () { sel = +list.value; fill(); });
		document.getElementById('hosc-add').onclick = function () { D.buildings.push({ id: '', name: 'อาคารใหม่', short: 'อาคารใหม่', cat: 'sup', roof: 'gable', door: 's', sign: '', r: [440, 360, 80, 50], floors: [['ชั้น 1', []]] }); sel = D.buildings.length - 1; dirty = true; fill(); q('name').focus(); q('name').select(); };
		document.getElementById('hosc-dup').onclick = function () { var b = D.buildings[sel]; if (!b) return; var c = JSON.parse(JSON.stringify(b)); c.id = ''; c.name += ' (สำเนา)'; c.r[0] += 20; c.r[1] += 20; D.buildings.push(c); sel = D.buildings.length - 1; dirty = true; fill(); };
		document.getElementById('hosc-del').onclick = function () { var b = D.buildings[sel]; if (!b || !confirm('ลบ “' + b.name + '” ?')) return; D.buildings.splice(sel, 1); sel = Math.max(0, sel - 1); dirty = true; fill(); };
		var mw = document.getElementById('hosc-marks');
		function renderMarks() {
			if (document.activeElement && mw.contains(document.activeElement)) return;
			mw.innerHTML = D.marks.map(function (m, i) { return '<div class="hosc-mrow" data-i="' + i + '"><input data-m="ic" value="' + (m.ic || '').replace(/"/g, '&quot;') + '" placeholder="🚪"><input data-m="t" value="' + m.t.replace(/"/g, '&quot;') + '"><input type="number" data-m="x" value="' + m.x + '"><input type="number" data-m="y" value="' + m.y + '"><button type="button" class="button-link hosc-reset" data-delm>✕</button></div>'; }).join('');
		}
		mw.addEventListener('input', function (e) { var r = e.target.closest('[data-i]'), m = D.marks[+r.dataset.i], f = e.target.dataset.m; m[f] = f === 'x' || f === 'y' ? parseInt(e.target.value, 10) || 0 : e.target.value; dirty = true; draw(); });
		mw.addEventListener('click', function (e) { if (e.target.dataset.delm !== undefined) { D.marks.splice(+e.target.closest('[data-i]').dataset.i, 1); dirty = true; renderMarks(); draw(); } });
		document.getElementById('hosc-addm').onclick = function () { D.marks.push({ t: 'จุดใหม่', ic: '📍', x: 480, y: 400 }); dirty = true; renderMarks(); draw(); };
		var gw = document.getElementById('hosc-geo');
		gw.innerHTML = D.geo.map(function (g, i) { return '<p><b>จุดที่ ' + (i + 1) + '</b></p><div class="hosc-4" data-g="' + i + '"><label>X<input type="number" value="' + g[0] + '"></label><label>Y<input type="number" value="' + g[1] + '"></label><label>ละติจูด<input type="number" step="0.0000001" value="' + g[2] + '"></label><label>ลองจิจูด<input type="number" step="0.0000001" value="' + g[3] + '"></label></div>'; }).join('');
		gw.addEventListener('input', function (e) { var r = e.target.closest('[data-g]'), i = [].indexOf.call(r.querySelectorAll('input'), e.target); D.geo[+r.dataset.g][i] = parseFloat(e.target.value) || 0; dirty = true; });
		document.querySelectorAll('[data-tab]').forEach(function (b) { b.onclick = function () { document.querySelectorAll('[data-tab]').forEach(function (x) { x.classList.toggle('button-primary', x === b); }); document.querySelectorAll('[data-pane]').forEach(function (p) { p.hidden = p.dataset.pane !== b.dataset.tab; }); }; });
		document.getElementById('hosc-save').addEventListener('submit', function (e) {
			if (e.submitter && e.submitter.name === 'reset') { dirty = false; return; }
			D.buildings.forEach(function (b) { delete b._r; }); D.marks.forEach(function (m) { delete m._x; delete m._y; }); D.doors.forEach(function (o) { delete o._o; }); D.paths.forEach(function (p) { delete p._o; });
			document.getElementById('hosc-json').value = JSON.stringify(D); dirty = false;
		});
		window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
		window.addEventListener('resize', draw);
		var DEFIMG = <?php echo wp_json_encode( HOSCM_URL . 'assets/campus-base.jpg' ); ?>;
		function setImg(url, h) { D.img = url; D.h = h; H = h; cv.style.backgroundImage = 'url("' + url + '")'; cv.style.aspectRatio = '960/' + h; document.getElementById('hosc-imgprev').src = url; dirty = true; draw(); }
		cv.style.aspectRatio = '960/' + H;
		var road = document.getElementById('hosc-road'), gm = document.getElementById('hosc-gmap');
		road.value = D.road || ''; gm.value = D.gmap || '';
		road.addEventListener('input', function () { D.road = road.value; dirty = true; }); gm.addEventListener('input', function () { D.gmap = gm.value; dirty = true; });
		var frame = null;
		document.getElementById('hosc-img').onclick = function () {
			if (!frame) { frame = wp.media({ title: 'เลือกรูปแผนที่ (หันทิศเหนือขึ้น)', library: { type: 'image' }, button: { text: 'ใช้รูปนี้' }, multiple: false });
				frame.on('select', function () { var a = frame.state().get('selection').first().toJSON(); var h = a.width && a.height ? Math.round(960 * a.height / a.width) : 794;
					if (D.buildings.length && !confirm('เปลี่ยนรูปแผนที่แล้ว ตำแหน่งอาคารเดิมจะไม่ตรงกับรูปใหม่ — ต้องลากจัดตำแหน่งใหม่ หรือกด “เริ่มผังใหม่” ดำเนินการต่อ?')) return;
					setImg(a.url, Math.max(200, Math.min(2400, h))); }); }
			frame.open();
		};
		document.getElementById('hosc-imgreset').onclick = function () { setImg('', 794); cv.style.backgroundImage = 'url("' + DEFIMG + '")'; document.getElementById('hosc-imgprev').src = DEFIMG; };
		document.getElementById('hosc-clear').onclick = function () { if (!confirm('ลบอาคาร ประตู ทางเดิน และจุดสังเกตทั้งหมด เพื่อเริ่มผังใหม่?')) return; D.buildings = []; D.doors = []; D.paths = []; D.marks = []; sel = 0; dirty = true; fill(); renderMarks(); renderNet(); draw(); };
		fill(); renderMarks(); renderNet();
	})();
	</script>
	<?php
}
