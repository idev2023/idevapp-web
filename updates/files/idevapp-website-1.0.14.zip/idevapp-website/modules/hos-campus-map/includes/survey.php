<?php
/**
 * ผังโรงพยาบาล: 📱 เดินเก็บพิกัด (ประตู / ทางเดิน / จุดสังเกต) และ 📌 QR “คุณอยู่ที่นี่”
 */
defined( 'ABSPATH' ) || exit;

/** ข้อมูลผังปัจจุบัน (ถ้ายังไม่เคยบันทึก ใช้ค่าเริ่มต้น) */
function hos_cs_current() {
	$d = hos_campus_data();
	foreach ( array( 'doors', 'paths', 'qr', 'marks' ) as $k ) {
		if ( ! isset( $d[ $k ] ) ) {
			$d[ $k ] = array();
		}
	}
	return $d;
}

function hos_cs_save( $d ) {
	update_option( 'hos_campus_data', hos_campus_sanitize( $d ), false );
	do_action( 'litespeed_purge_all' );
}

function hos_cs_summary( $d ) {
	return array( 'doors' => count( $d['doors'] ), 'paths' => count( $d['paths'] ), 'marks' => count( $d['marks'] ), 'net' => hos_campus_net( $d ), 'marksPx' => array_values( (array) $d['marks'] ) );
}

add_action( 'wp_ajax_hos_cs', function () {
	if ( ! current_user_can( 'edit_pages' ) || ! check_ajax_referer( 'hos_cs', 'nonce', false ) ) {
		wp_send_json_error( 'ไม่มีสิทธิ์' );
	}
	$d    = hos_cs_current();
	$op   = sanitize_key( $_POST['op'] ?? '' );
	$item = json_decode( wp_unslash( $_POST['item'] ?? '{}' ), true ); // phpcs:ignore
	$item = is_array( $item ) ? $item : array();
	switch ( $op ) {
		case 'door':
			$d['doors'][] = array( 'b' => sanitize_key( $item['b'] ?? '' ), 'lat' => (float) ( $item['lat'] ?? 0 ), 'lng' => (float) ( $item['lng'] ?? 0 ), 't' => sanitize_text_field( $item['t'] ?? '' ) );
			break;
		case 'path':
			$d['paths'][] = array( 't' => sanitize_text_field( $item['t'] ?? '' ), 'wc' => ! empty( $item['wc'] ), 'pts' => (array) ( $item['pts'] ?? array() ) );
			break;
		case 'mark':
			$p            = hos_campus_px( $d['geo'], (float) ( $item['lat'] ?? 0 ), (float) ( $item['lng'] ?? 0 ) );
			$d['marks'][] = array( 't' => sanitize_text_field( $item['t'] ?? '' ), 'ic' => sanitize_text_field( $item['ic'] ?? '📍' ), 'x' => (int) $p[0], 'y' => (int) $p[1], 'k' => sanitize_key( $item['k'] ?? 'spot' ), 'img' => esc_url_raw( (string) ( $item['img'] ?? '' ) ), 'b' => sanitize_key( $item['b'] ?? '' ) );
			break;
		case 'undo':
			$k = sanitize_key( $item['k'] ?? '' );
			if ( in_array( $k, array( 'doors', 'paths', 'marks' ), true ) && $d[ $k ] ) {
				array_pop( $d[ $k ] );
			}
			break;
		case 'qr':
			$d['qr'] = (array) ( $item['qr'] ?? array() );
			break;
		default:
			wp_send_json_error( 'คำสั่งไม่ถูกต้อง' );
	}
	hos_cs_save( $d );
	wp_send_json_success( hos_cs_summary( hos_cs_current() ) );
} );

/* ================= 📱 เดินเก็บพิกัด ================= */
/* photo of a landmark, taken on the walk: goes to the media library */
add_action( 'wp_ajax_hos_cs_photo', function () {
	if ( ! current_user_can( 'upload_files' ) || ! current_user_can( 'edit_pages' ) || ! check_ajax_referer( 'hos_cs', 'nonce', false ) ) {
		wp_send_json_error( 'ไม่มีสิทธิ์อัปโหลดรูป' );
	}
	if ( empty( $_FILES['photo']['tmp_name'] ) ) {
		wp_send_json_error( 'ไม่พบรูป' );
	}
	$type = wp_check_filetype_and_ext( $_FILES['photo']['tmp_name'], sanitize_file_name( $_FILES['photo']['name'] ?? 'photo.jpg' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	if ( ! in_array( $type['type'] ?? '', array( 'image/jpeg', 'image/png', 'image/webp', 'image/heic' ), true ) ) {
		wp_send_json_error( 'รองรับเฉพาะรูป JPG / PNG / WebP' );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$id = media_handle_upload( 'photo', 0, array( 'post_title' => sanitize_text_field( wp_unslash( $_POST['title'] ?? 'จุดสังเกต' ) ) ) );
	if ( is_wp_error( $id ) ) {
		wp_send_json_error( $id->get_error_message() );
	}
	wp_send_json_success( array( 'id' => $id, 'url' => (string) wp_get_attachment_image_url( $id, 'medium_large' ) ) );
} );

function hos_campus_survey_page() {
	$d     = hos_cs_current();
	$img   = $d['img'];
	$kinds = hos_campus_mark_kinds();
	$bld   = array();
	foreach ( $d['buildings'] as $b ) {
		$bld[] = array( 'id' => $b['id'], 'name' => $b['name'], 'r' => $b['r'] );
	}
	$geo_ok = hos_campus_geo_ok( $d['geo'] );
	?>
	<div class="wrap hoss">
		<h1>📱 เดินสำรวจพิกัด</h1>
		<p class="description">เปิดหน้านี้ด้วย<b>มือถือ</b> แล้วเดินในโรงพยาบาล — บันทึกทางเดิน ประตู ทางแยก และจุดสังเกต พร้อมถ่ายรูป ระบบจับคู่กับอาคารบนแผนที่ให้เอง · ยืนในที่โล่งจะแม่นกว่าชิดตึก</p>
		<?php if ( ! $geo_ok ) : ?><div class="notice notice-warning inline"><p><b>ยังไม่ได้เทียบพิกัด GPS ของแผนที่</b> — ตั้งพิกัด 2 จุดที่ <a href="<?php echo esc_url( admin_url( 'admin.php?page=hos-campus' ) ); ?>">แก้ไขผัง</a> ก่อน ตำแหน่งบนแผนที่จึงจะตรง</p></div><?php endif; ?>
		<?php if ( ! is_ssl() ) : ?><div class="notice notice-error inline"><p><b>เว็บยังไม่ใช้ HTTPS</b> — เบราว์เซอร์ในมือถือจะไม่ยอมให้ใช้ GPS ติดตั้ง SSL ที่เมนู SSL / HTTPS ก่อน</p></div><?php endif; ?>

		<div class="hoss-start" id="hoss-start">
			<b>📍 เปิด GPS เพื่อเริ่มเดินสำรวจ</b>
			<span>ระบบใช้ตำแหน่งเฉพาะตอนเปิดหน้านี้ เพื่อวาดทางเดินและระบุจุดบนแผนที่ — ไม่ได้เก็บตำแหน่งของคุณไว้ที่อื่น</span>
			<button type="button" class="button button-primary button-hero" id="hoss-gps-on">เปิด GPS และเริ่ม</button>
		</div>
		<div class="hoss-gps" id="hoss-gps" hidden>⏳ กำลังหาตำแหน่ง…</div>
		<div class="hoss-near" id="hoss-near" hidden></div>
		<div class="hoss-view" id="hoss-view">
			<label>มุมมอง <select id="hoss-vm"><option value="top">🗺️ แผนที่ทั้งหมด</option><option value="follow">🧭 ติดตามตัวฉัน</option><option value="walk">🚶 มุมมองคนเดิน (3 มิติ)</option></select></label>
			<label>แสดงตัวฉันเป็น <select id="hoss-lk"><option value="walker">🚶 คนเดิน</option><option value="arrow">➤ ลูกศร</option><option value="dot">🔵 จุด</option><option value="wheel">🧑‍🦽 รถเข็น</option></select></label>
		</div>
		<div class="hoss-map" id="hoss-map" style="aspect-ratio:960/<?php echo (int) $d['h']; ?>"><div class="hoss-w" id="hoss-w" style="background-image:url('<?php echo esc_url( $img ); ?>')"><svg viewBox="0 0 960 <?php echo (int) $d['h']; ?>" id="hoss-svg"></svg><i id="hoss-me" data-look="walker"><b class="fig" data-fig="🚶"></b></i></div></div>
		<div class="hoss-sum" id="hoss-sum"></div>

		<section class="hoss-card">
			<h2>〰️ บันทึกทางเดิน</h2>
			<p>กดเริ่ม แล้วเดินตามทางจริง (ทางเดินมีหลังคา ทางลาด ทางลัด) ทางที่เดินจะขึ้นเป็นเส้นสีฟ้าบนแผนที่ — เจอทางแยกให้กด “ทางแยกตรงนี้” ได้ระหว่างเดิน · กดหยุดเมื่อถึงปลายทาง</p>
			<input id="hoss-pt" type="text" placeholder="ชื่อทางเดิน (ไม่บังคับ) เช่น ทางเชื่อม OPD–ER">
			<label class="hoss-chk"><input type="checkbox" id="hoss-wc" checked> ♿ รถเข็นผ่านได้ (ไม่มีขั้นบันได)</label>
			<button class="button button-primary button-hero" id="hoss-rec">▶ เริ่มบันทึกทางเดิน</button>
			<div id="hoss-recinfo" class="hoss-recinfo" hidden></div>
			<button class="button button-hero hoss-jx" id="hoss-jx" hidden>🔀 ทางแยกตรงนี้</button>
			<button class="button-link" data-undo="paths">↶ ยกเลิกทางเดินล่าสุด</button>
		</section>

		<section class="hoss-card">
			<h2>📍 บันทึกจุดสังเกต (ถ่ายรูปได้)</h2>
			<p>ทางแยก บันได ลิฟต์ ทางลาด ห้องน้ำ ป้าย — ใช้บอกทางในการนำทาง (“เลี้ยวซ้ายที่ทางแยกหน้า…”) และแสดงรูปให้ผู้มารับบริการดู</p>
			<select id="hoss-mk"><?php foreach ( $kinds as $k => $v ) : ?><option value="<?php echo esc_attr( $k ); ?>" data-ic="<?php echo esc_attr( $v[1] ); ?>"><?php echo esc_html( $v[1] . ' ' . $v[0] ); ?></option><?php endforeach; ?></select>
			<input id="hoss-mt" type="text" placeholder="ชื่อจุด (เว้นว่าง = ตั้งให้ตามอาคารที่อยู่ใกล้)">
			<label class="hoss-photo"><input type="file" id="hoss-mp" accept="image/*" capture="environment"><span>📷 ถ่ายรูป / เลือกรูป (ไม่บังคับ)</span><img id="hoss-mpv" alt="" hidden></label>
			<button class="button button-primary button-hero" data-avg="mark">บันทึกจุดนี้</button>
			<button class="button-link" data-undo="marks">↶ ยกเลิกจุดล่าสุด</button>
		</section>

		<section class="hoss-card">
			<h2>🚪 บันทึกประตูอาคาร</h2>
			<p>ยืนหน้าประตูจริง — ระบบเลือกอาคารที่อยู่ใกล้ให้ (เปลี่ยนเองได้) แล้วกดบันทึก (เฉลี่ยตำแหน่ง 15 วินาที — ยืนนิ่ง ๆ)</p>
			<select id="hoss-b"><?php foreach ( $d['buildings'] as $b ) : ?><option value="<?php echo esc_attr( $b['id'] ); ?>"><?php echo esc_html( $b['name'] ); ?></option><?php endforeach; ?></select>
			<input id="hoss-bt" type="text" placeholder="ชื่อประตู (ไม่บังคับ) เช่น ประตูหน้า, ทางลาด">
			<button class="button button-primary button-hero" data-avg="door">บันทึกประตูนี้</button>
			<button class="button-link" data-undo="doors">↶ ยกเลิกประตูล่าสุด</button>
		</section>
		<div class="hoss-toast" id="hoss-toast" hidden></div>
	</div>
	<style>
	.hoss{max-width:720px}.hoss h2{margin:0 0 6px;font-size:18px}
	.hoss-start{display:flex;flex-direction:column;gap:8px;background:#e8f6f1;border:1px solid #9fd8c4;border-radius:12px;padding:16px;margin:12px 0}
	.hoss-start b{font-size:17px}.hoss-start span{color:#3c5258}
	.hoss-gps{position:sticky;top:32px;z-index:9;background:#1d2327;color:#fff;padding:10px 14px;border-radius:10px;margin:10px 0 4px;font-size:15px}
	.hoss-gps.good{background:#0a7d55}.hoss-gps.bad{background:#b32d2e}
	.hoss-near{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:8px 12px;margin-bottom:8px;font-size:14px}
	.hoss-map{position:relative;width:100%;border-radius:10px;overflow:hidden;margin-bottom:8px;perspective:900px;background:#dfe9e4}
	.hoss-w{position:absolute;left:0;top:0;width:100%;height:100%;background-size:100% 100%;transform-style:preserve-3d;transition:transform .7s ease-out;--rz:0deg;--rx:0deg;--sc:1}
	.hoss-map.is-follow,.hoss-map.is-walk{aspect-ratio:auto!important;height:62vh;min-height:340px}
	.hoss-view{display:flex;flex-wrap:wrap;gap:8px 14px;margin:0 0 8px;font-size:14px}.hoss-view select{font-size:15px;padding:4px 8px;margin-left:4px}
	.hoss-map svg{position:absolute;inset:0;width:100%;height:100%}
	.hoss-map polyline{fill:none;stroke:#ff6a00;stroke-width:5;stroke-linejoin:round}.hoss-map polyline.wc{stroke:#8a5cd6}.hoss-map polyline.live{stroke:#00c2ff;stroke-width:6;stroke-dasharray:8 6}.hoss-map polyline.trail{stroke:#1a73e8;stroke-width:3;opacity:.55}
	.hoss-map rect.bl{fill:rgba(26,115,232,.18);stroke:#1a73e8;stroke-width:3}
	.hoss-map circle.d{fill:#ff2d55;stroke:#fff;stroke-width:3}.hoss-map circle.m{fill:#0a7d55;stroke:#fff;stroke-width:3}.hoss-map circle.m.junction{fill:#f0a020}
	.hoss-map text{font-size:22px}
	#hoss-me{position:absolute;width:0;height:0;display:none;transform-style:preserve-3d;font-style:normal;transition:left .9s linear,top .9s linear}
	#hoss-me:before{content:'';position:absolute;left:-9px;top:-9px;width:18px;height:18px;border-radius:50%;background:rgba(26,115,232,.3);animation:hossme 1.6s ease-out infinite}
	#hoss-me .fig{position:absolute;left:0;top:0;font-size:30px;line-height:1;transform-origin:50% 100%;transform:translate(-50%,-100%) rotateZ(calc(var(--rz) * -1)) rotateX(calc(var(--rx) * -1)) scale(var(--sc)) scaleX(var(--fx,1));filter:drop-shadow(0 3px 3px rgba(0,0,0,.35))}
	#hoss-me .fig:before{content:attr(data-fig)}
	#hoss-me.is-moving .fig{animation:hossstep .45s ease-in-out infinite alternate}
	#hoss-me[data-look=dot] .fig{width:16px;height:16px;font-size:0;border-radius:50%;background:#1a73e8;border:3px solid #fff;transform:translate(-50%,-50%) scale(var(--sc))}
	#hoss-me[data-look=arrow] .fig{font-size:0;width:0;height:0;border-left:11px solid transparent;border-right:11px solid transparent;border-bottom:28px solid #1a73e8;left:-11px;top:-14px;transform-origin:11px 14px;filter:drop-shadow(0 0 2px #fff) drop-shadow(0 2px 3px rgba(0,0,0,.4));transform:rotate(var(--hd,0deg)) scale(var(--sc))}
	@keyframes hossme{to{transform:scale(2.4);opacity:0}}@keyframes hossstep{to{margin-top:-4px}}
	@media(prefers-reduced-motion:reduce){.hoss-w,#hoss-me{transition:none}#hoss-me:before,#hoss-me .fig:before{content:attr(data-fig)}
	#hoss-me.is-moving .fig{animation:none}}
	.hoss-sum{font-size:13px;color:#50575e;margin-bottom:10px}
	.hoss-card{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;margin-bottom:14px}
	.hoss-card select,.hoss-card input[type=text]{width:100%;margin:6px 0;font-size:16px;padding:8px}
	.hoss-card .button-hero{width:100%;margin:6px 0;font-size:17px!important}
	.hoss-jx{background:#fff5d6!important;border-color:#f0a020!important;color:#8a5a00!important}
	.hoss-chk{display:block;margin:8px 0;font-size:15px}
	.hoss-photo{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:6px 0;padding:10px;border:1px dashed #9aabb0;border-radius:10px;cursor:pointer;font-size:15px}
	.hoss-photo input{position:absolute;opacity:0;width:1px;height:1px}.hoss-photo img{max-height:90px;border-radius:8px}
	.hoss-recinfo{background:#e5f6ff;border-radius:8px;padding:8px 12px;font-weight:600}
	.hoss-toast{position:fixed;left:50%;bottom:20px;transform:translateX(-50%);background:#1d2327;color:#fff;padding:12px 18px;border-radius:10px;z-index:99999;font-size:15px;max-width:90vw}
	</style>
	<script>
	(function () {
		var AJ = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>, NONCE = <?php echo wp_json_encode( wp_create_nonce( 'hos_cs' ) ); ?>;
		var GEO = <?php echo wp_json_encode( $d['geo'] ); ?>, S = <?php echo wp_json_encode( hos_cs_summary( $d ), JSON_UNESCAPED_UNICODE ); ?>, B = <?php echo wp_json_encode( $bld, JSON_UNESCAPED_UNICODE ); ?>;
		var MPP = <?php echo wp_json_encode( hos_campus_mpp( $d['geo'] ) ?: 0.5 ); ?>, KINDS = <?php echo wp_json_encode( $kinds, JSON_UNESCAPED_UNICODE ); ?>;
		var $ = function (id) { return document.getElementById(id); };
		var gps = $('hoss-gps'), near = $('hoss-near'), mapEl = $('hoss-map'), svg = $('hoss-svg'), meEl = $('hoss-me'), toastEl = $('hoss-toast');
		var last = null, rec = null, trail = [], here = null, bPicked = false, NS = 'http://www.w3.org/2000/svg';
		function px(lat, lng) { var a = GEO[0], b = GEO[1]; return [a[0] + (lng - a[3]) / (b[3] - a[3]) * (b[0] - a[0]), a[1] + (lat - a[2]) / (b[2] - a[2]) * (b[1] - a[1])]; }
		function meters(a, b) { var R = 6371000, d1 = (b[0] - a[0]) * Math.PI / 180, d2 = (b[1] - a[1]) * Math.PI / 180, x = Math.sin(d1 / 2) * Math.sin(d1 / 2) + Math.cos(a[0] * Math.PI / 180) * Math.cos(b[0] * Math.PI / 180) * Math.sin(d2 / 2) * Math.sin(d2 / 2); return 2 * R * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x)); }
		function toast(t) { toastEl.textContent = t; toastEl.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(function () { toastEl.hidden = true; }, 3500); }
		/* the building you are in or next to (by the map rectangles) */
		function building(p) {
			var best = null, bd = 1e9;
			B.forEach(function (b) { var r = b.r, dx = Math.max(r[0] - p[0], 0, p[0] - (r[0] + r[2])), dy = Math.max(r[1] - p[1], 0, p[1] - (r[1] + r[3])), d = Math.hypot(dx, dy); if (d < bd) { bd = d; best = b; } });
			return best ? { b: best, inside: bd === 0, m: Math.round(bd * MPP) } : null;
		}
		function el(tag, attrs) { var e = document.createElementNS(NS, tag); Object.keys(attrs).forEach(function (k) { e.setAttribute(k, attrs[k]); }); return e; }
		function render() {
			svg.innerHTML = '';
			if (here) { var r = here.b.r; svg.appendChild(el('rect', { x: r[0], y: r[1], width: r[2], height: r[3], 'class': 'bl' })); }
			S.net.paths.forEach(function (p) { svg.appendChild(el('polyline', { points: p.pts.map(function (q) { return q.join(','); }).join(' '), 'class': p.wc ? 'wc' : '' })); });
			if (trail.length > 1) svg.appendChild(el('polyline', { points: trail.map(function (q) { return q.join(','); }).join(' '), 'class': 'trail' }));
			if (rec && rec.pts.length > 1) svg.appendChild(el('polyline', { 'class': 'live', points: rec.pts.map(function (q) { return px(q[0], q[1]).join(','); }).join(' ') }));
			S.net.doors.forEach(function (o) { svg.appendChild(el('circle', { cx: o.x, cy: o.y, r: 7, 'class': 'd' })); });
			S.marksPx.forEach(function (o) { svg.appendChild(el('circle', { cx: o.x, cy: o.y, r: 8, 'class': 'm ' + (o.k || '') })); });
			$('hoss-sum').textContent = 'บันทึกแล้ว: ทางเดิน ' + S.paths + ' · จุดสังเกต ' + S.marks + ' · ประตู ' + S.doors + '  (เส้นฟ้า = ทางที่เดินรอบนี้ · ส้ม = ทางเดิน · ม่วง = รถเข็นผ่านได้ · จุดเหลือง = ทางแยก · เขียว = จุดสังเกต · แดง = ประตู)';
		}
		function send(op, item) {
			var fd = new FormData(); fd.append('action', 'hos_cs'); fd.append('nonce', NONCE); fd.append('op', op); fd.append('item', JSON.stringify(item));
			return fetch(AJ, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) { if (!j.success) throw new Error(j.data || 'error'); S = j.data; render(); return j; });
		}
		function upload(file, title) {
			if (!file) return Promise.resolve('');
			var fd = new FormData(); fd.append('action', 'hos_cs_photo'); fd.append('nonce', NONCE); fd.append('photo', file); fd.append('title', title);
			toast('⏳ กำลังอัปโหลดรูป…');
			return fetch(AJ, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) { if (!j.success) throw new Error(j.data || 'อัปโหลดรูปไม่สำเร็จ'); return j.data.url; });
		}
		/* แสดงเหมือนคนกำลังเดินจริง: ติดตามตัว หันแผนที่ตามทิศที่เดิน มุมมอง 3 มิติ เลือกรูปแบบเองได้ (จำไว้ในเครื่อง) */
		var wEl = $('hoss-w'), vm = $('hoss-vm'), lk = $('hoss-lk'), meQ = null, hd = null, rz = 0, stepT = 0, pref = { view: 'follow', look: 'walker' };
		try { pref = Object.assign(pref, JSON.parse(localStorage.getItem('hos-survey-pref') || '{}')); } catch (e) {}
		vm.value = pref.view; lk.value = pref.look;
		var FIG = { walker: '🚶', wheel: '🧑‍🦽', arrow: '', dot: '' };
		function look() { meEl.dataset.look = lk.value; meEl.querySelector('.fig').dataset.fig = FIG[lk.value] || ''; /* drawn by CSS, so the emoji script leaves it alone */ }
		function camera() {
			var v = vm.value, w = mapEl.clientWidth, h = mapEl.clientHeight;
			mapEl.classList.toggle('is-follow', v === 'follow'); mapEl.classList.toggle('is-walk', v === 'walk');
			if (v === 'top' || !meQ) { wEl.style.width = ''; wEl.style.height = ''; wEl.style.transform = ''; wEl.style.setProperty('--rz', '0deg'); wEl.style.setProperty('--rx', '0deg'); wEl.style.setProperty('--sc', 1); return; }
			// keep the map's own shape inside a taller box, then put “me” in the middle, heading up
			var ww = w, wh = w * <?php echo (int) $d['h']; ?> / 960, r = ww / 960, x = meQ[0] * r, y = meQ[1] * r, z = v === 'walk' ? 2.6 : 1.9, rx = v === 'walk' ? 60 : 0;
			if (hd !== null) { var want = -90 - hd * 180 / Math.PI; while (want - rz > 180) want -= 360; while (rz - want > 180) want += 360; rz = want; }
			wEl.style.width = ww + 'px'; wEl.style.height = wh + 'px'; wEl.style.transformOrigin = x + 'px ' + y + 'px';
			wEl.style.transform = 'translate(' + (w / 2 - x) + 'px,' + (h * (v === 'walk' ? .62 : .55) - y) + 'px) scale(' + z + ') rotateX(' + rx + 'deg) rotateZ(' + rz + 'deg)';
			wEl.style.setProperty('--rz', rz + 'deg'); wEl.style.setProperty('--rx', rx + 'deg'); wEl.style.setProperty('--sc', (1 / z * 1.4).toFixed(3));
		}
		function walkTo(q, gpsHeading) {
			var r = 1;
			if (meQ) { var d = Math.hypot(q[0] - meQ[0], q[1] - meQ[1]) * MPP; if (d > 1.5) { hd = Math.atan2(q[1] - meQ[1], q[0] - meQ[0]); stepT = Date.now(); } }
			else if (typeof gpsHeading === 'number' && !isNaN(gpsHeading)) hd = (gpsHeading - 90) * Math.PI / 180; // compass → map (north up)
			meQ = q; r = (vm.value === 'top' ? mapEl.clientWidth : parseFloat(wEl.style.width) || mapEl.clientWidth) / 960;
			meEl.style.display = 'block'; meEl.style.left = q[0] * r + 'px'; meEl.style.top = q[1] * r + 'px';
			meEl.classList.toggle('is-moving', Date.now() - stepT < 4000);
			if (hd !== null) {
				var scr = hd * 180 / Math.PI + (vm.value === 'top' ? 0 : rz); scr = ((scr + 540) % 360) - 180;
				meEl.style.setProperty('--fx', Math.abs(scr) < 90 ? -1 : 1); // the walker faces the way it goes
				meEl.style.setProperty('--hd', (hd * 180 / Math.PI + 90) + 'deg'); // the arrow lies on the map, so it takes the map direction
			}
			camera(); if (meQ) { r = (vm.value === 'top' ? mapEl.clientWidth : parseFloat(wEl.style.width) || mapEl.clientWidth) / 960; meEl.style.left = q[0] * r + 'px'; meEl.style.top = q[1] * r + 'px'; }
		}
		function savePref() { pref = { view: vm.value, look: lk.value }; try { localStorage.setItem('hos-survey-pref', JSON.stringify(pref)); } catch (e) {} }
		vm.addEventListener('change', function () { savePref(); if (meQ) walkTo(meQ); else camera(); });
		lk.addEventListener('change', function () { savePref(); look(); if (meQ) walkTo(meQ); });
		window.addEventListener('resize', function () { if (meQ) walkTo(meQ); });
		look();
		/* GPS: starts when the button is pressed (phones ask for permission on a tap) */
		function onPos(p) {
			last = { lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy, t: Date.now() };
			gps.textContent = '📡 ความแม่นยำ ±' + Math.round(last.acc) + ' ม.' + (last.acc > 20 ? ' — รอให้ต่ำกว่า 20 ม. หรือออกที่โล่ง' : ' — ใช้ได้');
			gps.className = 'hoss-gps ' + (last.acc <= 20 ? 'good' : 'bad');
			var q = px(last.lat, last.lng); walkTo(q, p.coords.heading);
			if (last.acc <= 30 && (!trail.length || Math.hypot(q[0] - trail[trail.length - 1][0], q[1] - trail[trail.length - 1][1]) * MPP > 2)) trail.push(q);
			here = building(q);
			if (here) {
				near.hidden = false;
				near.innerHTML = '🏢 ' + (here.inside ? 'อยู่ที่ <b>' : 'ใกล้ <b>') + here.b.name + '</b>' + (here.inside ? '' : ' (ประมาณ ' + here.m + ' ม.)');
				if (!bPicked) $('hoss-b').value = here.b.id; // match the door to the building on the map
			}
			if (rec && last.acc <= 25) { var lp = rec.pts[rec.pts.length - 1]; if (!lp || meters(lp, [last.lat, last.lng]) >= 3) { if (lp) rec.dist += meters(lp, [last.lat, last.lng]); rec.pts.push([+last.lat.toFixed(7), +last.lng.toFixed(7)]); recInfo(); } }
			render();
		}
		function startGps() {
			if (!navigator.geolocation) { toast('อุปกรณ์นี้ไม่รองรับ GPS'); return; }
			if (!window.isSecureContext) { toast('ต้องเปิดเว็บด้วย https:// จึงจะใช้ GPS ได้'); return; }
			$('hoss-start').hidden = true; gps.hidden = false;
			navigator.geolocation.watchPosition(onPos, function (e) {
				gps.className = 'hoss-gps bad'; $('hoss-start').hidden = false;
				gps.textContent = e.code === 1 ? '⛔ ไม่ได้รับอนุญาตให้ใช้ตำแหน่ง — iPhone: การตั้งค่า › ความเป็นส่วนตัว › บริการหาตำแหน่ง › Safari / Chrome: แตะไอคอนแม่กุญแจข้างที่อยู่เว็บ › ตำแหน่ง › อนุญาต แล้วกดเปิด GPS อีกครั้ง' : '⚠️ หาตำแหน่งไม่ได้ — ตรวจว่าเปิด GPS / บริการหาตำแหน่งของเครื่องแล้ว';
			}, { enableHighAccuracy: true, maximumAge: 0, timeout: 30000 });
			try { if (navigator.wakeLock) navigator.wakeLock.request('screen').catch(function () {}); } catch (e) {}
		}
		$('hoss-gps-on').addEventListener('click', startGps);
		if (navigator.permissions && navigator.permissions.query) navigator.permissions.query({ name: 'geolocation' }).then(function (st) { if (st.state === 'granted') startGps(); }).catch(function () {});
		$('hoss-b').addEventListener('change', function () { bPicked = true; });
		/* averaged position (weighted by accuracy) */
		function average(sec) {
			return new Promise(function (ok, no) {
				var sw = 0, sl = 0, sg = 0, n = 0, t0 = Date.now(), seen = 0;
				var iv = setInterval(function () {
					if (last && last.t > seen && last.acc < 40) { seen = last.t; var w = 1 / Math.max(1, last.acc * last.acc); sw += w; sl += last.lat * w; sg += last.lng * w; n++; }
					var left = sec - Math.floor((Date.now() - t0) / 1000); toast('⏳ ยืนนิ่ง ๆ… ' + left + ' วินาที (เก็บได้ ' + n + ' ค่า)');
					if (left <= 0) { clearInterval(iv); n ? ok({ lat: +(sl / sw).toFixed(7), lng: +(sg / sw).toFixed(7), n: n }) : no(new Error('สัญญาณ GPS ไม่ดีพอ ลองออกที่โล่งแล้วบันทึกใหม่')); }
				}, 500);
			});
		}
		function autoName(kind, p) {
			var h = building(px(p.lat, p.lng)), k = KINDS[kind] || KINDS.spot;
			return { t: k[0] + (h ? (h.inside ? ' ใน' : ' หน้า') + h.b.name : ''), b: h && h.m < 40 ? h.b.id : '' };
		}
		function saveMark(kind, sec, name, file) {
			if (!last) return toast('ยังไม่พบตำแหน่ง GPS — กด “เปิด GPS และเริ่ม”');
			return average(sec).then(function (p) {
				var a = autoName(kind, p), t = name || a.t;
				return upload(file, t).then(function (img) { return send('mark', { k: kind, ic: (KINDS[kind] || KINDS.spot)[1], t: t, b: a.b, img: img, lat: p.lat, lng: p.lng }); }).then(function () { toast('✅ บันทึก “' + t + '” แล้ว (เฉลี่ยจาก ' + p.n + ' ค่า)'); });
			});
		}
		$('hoss-mp').addEventListener('change', function () { var f = this.files[0], v = $('hoss-mpv'); if (f) { v.src = URL.createObjectURL(f); v.hidden = false; } else v.hidden = true; });
		document.querySelectorAll('[data-avg]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				if (!last) return toast('ยังไม่พบตำแหน่ง GPS — กด “เปิด GPS และเริ่ม”');
				btn.disabled = true;
				var job = btn.dataset.avg === 'door'
					? average(15).then(function (p) { return send('door', { b: $('hoss-b').value, t: $('hoss-bt').value, lat: p.lat, lng: p.lng }).then(function () { toast('✅ บันทึกประตูแล้ว (เฉลี่ยจาก ' + p.n + ' ค่า)'); $('hoss-bt').value = ''; }); })
					: saveMark($('hoss-mk').value, 10, $('hoss-mt').value.trim(), $('hoss-mp').files[0]).then(function () { $('hoss-mt').value = ''; $('hoss-mp').value = ''; $('hoss-mpv').hidden = true; });
				Promise.resolve(job).catch(function (e) { toast('⚠️ ' + e.message); }).then(function () { btn.disabled = false; });
			});
		});
		var recBtn = $('hoss-rec'), recEl = $('hoss-recinfo'), jx = $('hoss-jx');
		function recInfo() { recEl.hidden = !rec; jx.hidden = !rec; if (rec) recEl.textContent = '🔴 กำลังบันทึก · ' + rec.pts.length + ' จุด · ' + Math.round(rec.dist) + ' เมตร'; }
		jx.addEventListener('click', function () { jx.disabled = true; Promise.resolve(saveMark('junction', 4, '', null)).catch(function (e) { toast('⚠️ ' + e.message); }).then(function () { jx.disabled = false; }); });
		recBtn.addEventListener('click', function () {
			if (!last) return toast('ยังไม่พบตำแหน่ง GPS — กด “เปิด GPS และเริ่ม”');
			if (!rec) { rec = { pts: last.acc <= 25 ? [[+last.lat.toFixed(7), +last.lng.toFixed(7)]] : [], dist: 0 }; recBtn.textContent = '■ หยุดและบันทึกทางเดิน'; recInfo(); return; }
			var r = rec; rec = null; recBtn.textContent = '▶ เริ่มบันทึกทางเดิน'; recInfo();
			if (r.pts.length < 2) return toast('ทางเดินสั้นเกินไป (ต้องมีอย่างน้อย 2 จุด) ไม่ได้บันทึก');
			send('path', { t: $('hoss-pt').value, wc: $('hoss-wc').checked, pts: r.pts }).then(function () { toast('✅ บันทึกทางเดินแล้ว ' + r.pts.length + ' จุด · ' + Math.round(r.dist) + ' ม.'); $('hoss-pt').value = ''; }).catch(function (e) { toast('⚠️ ' + e.message); });
		});
		document.querySelectorAll('[data-undo]').forEach(function (b) { b.addEventListener('click', function () { if (confirm('ยกเลิกรายการล่าสุด?')) send('undo', { k: b.dataset.undo }).then(function () { toast('ยกเลิกแล้ว'); }); }); });
		window.addEventListener('beforeunload', function (e) { if (rec) { e.preventDefault(); e.returnValue = ''; } });
		render();
	})();
	</script>
	<?php
}

/* ================= 📌 QR “คุณอยู่ที่นี่” ================= */
function hos_campus_qr_page() {
	$d    = hos_cs_current();
	$img  = $d['img'];
	$map  = hos_campus_find_page();
	$base = $map ? get_permalink( $map ) : home_url( '/map/' );
	wp_enqueue_script( 'hos-qr', HOSCM_URL . 'assets/qr.js', array(), HOSCM_VER, true );
	?>
	<div class="wrap hosq">
		<h1>📌 QR “คุณอยู่ที่นี่”</h1>
		<p class="description">ติดป้าย QR ตามจุดต่าง ๆ (หน้าห้องบัตร, ลิฟต์, ทางแยกทางเดิน) · คนไข้สแกนแล้วแผนที่เปิดพร้อมจุดเริ่มต้นตรงนั้นทันที — ใช้ได้แม้อยู่ในอาคารที่ GPS จับไม่ได้</p>
		<div class="hosq-grid">
			<div><div class="hosq-map" id="hosq-map" style="aspect-ratio:960/<?php echo (int) $d['h']; ?>;background-image:url('<?php echo esc_url( $img ); ?>')"></div><p class="description">กดเลือกจุดในรายการ แล้ว<b>แตะบนภาพ</b>เพื่อวางตำแหน่ง (หรือลากหมุด)</p></div>
			<div>
				<div id="hosq-list"></div>
				<p><button class="button" id="hosq-add">＋ เพิ่มจุด QR</button></p>
				<p><button class="button button-primary button-hero" id="hosq-save">💾 บันทึก</button> <button class="button button-hero" id="hosq-print">🖨️ พิมพ์ป้าย QR ทั้งหมด</button></p>
			</div>
		</div>
		<div id="hosq-printarea"></div>
	</div>
	<style>
	.hosq-grid{display:grid;grid-template-columns:minmax(0,1fr) 420px;gap:20px;align-items:start}
	.hosq-map{position:relative;width:100%;background-size:100% 100%;border-radius:10px;cursor:crosshair}
	.hosq-pin{position:absolute;transform:translate(-50%,-100%);background:#fff;border:2px solid #d63638;border-radius:999px;padding:2px 8px;font-size:12px;font-weight:700;white-space:nowrap;cursor:move}
	.hosq-pin.on{background:#d63638;color:#fff}
	.hosq-row{display:grid;grid-template-columns:1fr auto auto;gap:6px;align-items:center;padding:6px;border:1px solid #dcdcde;border-radius:8px;margin-bottom:6px;background:#fff}
	.hosq-row.on{border-color:#d63638;box-shadow:0 0 0 1px #d63638}.hosq-row input{width:100%}
	#hosq-printarea{display:none}
	@media print{body *{visibility:hidden}#hosq-printarea,#hosq-printarea *{visibility:visible}#hosq-printarea{display:grid!important;position:absolute;left:0;top:0;width:100%;grid-template-columns:1fr 1fr;gap:10mm}
	 .hosq-card{border:2px solid #0a7d55;border-radius:6mm;padding:8mm;text-align:center;page-break-inside:avoid;font-family:sans-serif}.hosq-card h3{font-size:22pt;margin:0;color:#0a7d55}.hosq-card h4{font-size:16pt;margin:2mm 0 4mm}.hosq-card svg{width:55mm;height:55mm}.hosq-card p{font-size:12pt;margin:3mm 0 0}}
	@media(max-width:1000px){.hosq-grid{grid-template-columns:1fr}}
	</style>
	<script>
	(function () {
		var AJ = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>, NONCE = <?php echo wp_json_encode( wp_create_nonce( 'hos_cs' ) ); ?>, BASE = <?php echo wp_json_encode( $base ); ?>;
		var Q = <?php echo wp_json_encode( array_values( $d['qr'] ), JSON_UNESCAPED_UNICODE ); ?>, sel = 0, map = document.getElementById('hosq-map'), list = document.getElementById('hosq-list');
		function k() { return map.clientWidth / 960; }
		function url(q) { return BASE + (BASE.indexOf('?') > -1 ? '&' : '?') + 'from=' + encodeURIComponent(q.id); }
		function draw() {
			map.innerHTML = ''; Q.forEach(function (q, i) { var p = document.createElement('div'); p.className = 'hosq-pin' + (i === sel ? ' on' : ''); p.textContent = '📌 ' + q.t; p.style.left = q.x * k() + 'px'; p.style.top = q.y * k() + 'px';
				p.addEventListener('pointerdown', function (e) { e.stopPropagation(); e.preventDefault(); sel = i; var x0 = e.clientX, y0 = e.clientY, ox = q.x, oy = q.y;
					function mv(ev) { q.x = Math.round(ox + (ev.clientX - x0) / k()); q.y = Math.round(oy + (ev.clientY - y0) / k()); draw(); }
					function up() { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); rows(); }
					window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up); }); map.appendChild(p); });
		}
		function rows() { list.innerHTML = Q.map(function (q, i) { return '<div class="hosq-row' + (i === sel ? ' on' : '') + '" data-i="' + i + '"><input value="' + q.t.replace(/"/g, '&quot;') + '"><a class="button button-small" target="_blank" href="' + url(q) + '">ทดสอบ</a><button class="button-link" data-del style="color:#b32d2e">ลบ</button></div>'; }).join('') || '<p>ยังไม่มีจุด QR</p>'; }
		map.addEventListener('click', function (e) { if (!Q[sel] || e.target !== map) return; var r = map.getBoundingClientRect(); Q[sel].x = Math.round((e.clientX - r.left) / k()); Q[sel].y = Math.round((e.clientY - r.top) / k()); draw(); });
		list.addEventListener('click', function (e) { var r = e.target.closest('[data-i]'); if (!r) return; sel = +r.dataset.i; if (e.target.dataset.del !== undefined && confirm('ลบจุดนี้?')) { Q.splice(sel, 1); sel = 0; } rows(); draw(); });
		list.addEventListener('input', function (e) { var r = e.target.closest('[data-i]'); Q[+r.dataset.i].t = e.target.value; draw(); });
		document.getElementById('hosq-add').onclick = function () { Q.push({ id: 'q' + Date.now().toString(36), t: 'จุดใหม่', x: 480, y: 400 }); sel = Q.length - 1; rows(); draw(); list.querySelector('.on input').select(); };
		document.getElementById('hosq-save').onclick = function () { var fd = new FormData(); fd.append('action', 'hos_cs'); fd.append('nonce', NONCE); fd.append('op', 'qr'); fd.append('item', JSON.stringify({ qr: Q }));
			fetch(AJ, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) { alert(j.success ? 'บันทึกแล้ว' : 'บันทึกไม่สำเร็จ'); }); };
		function qrSvg(text) { var q = window.HosQR(text), n = q.getModuleCount(), d = ''; for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) if (q.isDark(r, c)) d += 'M' + (c + 4) + ' ' + (r + 4) + 'h1v1h-1z'; return '<svg viewBox="0 0 ' + (n + 8) + ' ' + (n + 8) + '" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>'; }
		document.getElementById('hosq-print').onclick = function () {
			if (!Q.length) return alert('ยังไม่มีจุด QR'); var pa = document.getElementById('hosq-printarea');
			pa.innerHTML = Q.map(function (q) { return '<div class="hosq-card"><h3>📍 คุณอยู่ที่นี่</h3><h4>' + q.t.replace(/</g, '&lt;') + '</h4>' + qrSvg(url(q)) + '<p>สแกนเพื่อดูแผนที่และเส้นทางในโรงพยาบาล<br>Scan for hospital map &amp; directions</p></div>'; }).join('');
			window.print();
		};
		rows(); draw(); window.addEventListener('resize', draw);
	})();
	</script>
	<?php
}
