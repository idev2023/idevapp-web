<?php
/**
 * ผังโรงพยาบาลแบบกดได้ (บล็อก hos/campus · shortcode [hos_campus])
 * ตำแหน่งตึกอ้างอิงภาพดาวเทียม 960×794 — แก้ข้อมูลตึกได้ที่ฟังก์ชัน hos_campus_buildings() หรือ filter 'hos_campus_buildings'
 */
defined( 'ABSPATH' ) || exit;

function hos_campus_cats() {
	return array(
		'er'  => array( 'ฉุกเฉิน', '#e8434f' ),
		'opd' => array( 'ตรวจรักษา / คลินิก', '#0f8f86' ),
		'ipd' => array( 'หอผู้ป่วยใน', '#2463d4' ),
		'dx'  => array( 'ตรวจวินิจฉัย', '#8a5cd6' ),
		'sup' => array( 'สนับสนุน / สำนักงาน', '#8a6d3b' ),
	);
}

function hos_campus_default_buildings() {
	// ผังตัวอย่าง: แก้ไขให้ตรงกับโรงพยาบาลจริงที่ ตั้งค่า › ผังโรงพยาบาล 3 มิติ
	$b = array(
		array( 'er', 'อาคารอุบัติเหตุฉุกเฉิน', 'ER', 'er', array( 560, 70, 150, 96 ), array(
			array( 'ชั้น 1', array( 'ห้องอุบัติเหตุและฉุกเฉิน (ER)', 'จุดรับยาผู้ป่วยใน' ) ),
			array( 'ชั้น 2', array( 'งานบริหารทั่วไป', 'ห้องประชุม' ) ),
		) ),
		array( 'opd', 'อาคารผู้ป่วยนอก', 'ผู้ป่วยนอก', 'opd', array( 330, 90, 180, 120 ), array(
			array( 'ชั้น 1', array( 'ประชาสัมพันธ์', 'ห้องบัตร / เวชระเบียน', 'คลินิกผู้ป่วยนอก (OPD)', 'จุดรับชำระเงิน', 'จุดรับยาผู้ป่วยนอก' ) ),
			array( 'ชั้น 2', array( 'คลินิกโรคเรื้อรัง', 'คลินิกทันตกรรม' ) ),
		) ),
		array( 'lab', 'อาคารชันสูตรและรังสีวิทยา', 'ชันสูตร', 'dx', array( 150, 120, 120, 80 ), array(
			array( 'ชั้น 1', array( 'ห้องเจาะเลือด', 'ห้องปฏิบัติการ', 'ห้องเอกซเรย์ (X-ray)' ) ),
		) ),
		array( 'ipd', 'อาคารผู้ป่วยใน', 'ผู้ป่วยใน', 'ipd', array( 300, 330, 260, 100 ), array(
			array( 'ชั้น 1', array( 'หอผู้ป่วยอายุรกรรม' ) ),
			array( 'ชั้น 2', array( 'หอผู้ป่วยศัลยกรรม' ) ),
			array( 'ชั้น 3', array( 'หอผู้ป่วยพิเศษ' ) ),
		) ),
		array( 'thai', 'อาคารแพทย์แผนไทย', 'แผนไทย', 'opd', array( 640, 330, 110, 70 ), array(
			array( 'ชั้น 1', array( 'คลินิกแพทย์แผนไทย', 'กายภาพบำบัด' ) ),
		) ),
		array( 'sup', 'อาคารสนับสนุนบริการ', 'สนับสนุน', 'sup', array( 340, 560, 200, 70 ), array(
			array( 'ชั้น 1', array( 'งานโภชนาการ', 'งานพัสดุ', 'งานซ่อมบำรุง' ) ),
		) ),
		array( 'wc', 'ห้องน้ำสาธารณะ', 'ห้องน้ำ', 'sup', array( 560, 220, 40, 40 ), array() ),
	);
	$flat  = array( 'opd', 'ipd', 'wc' );
	$signs = array( 'er' => 'ER', 'opd' => 'OPD' );
	$out   = array();
	foreach ( $b as $r ) {
		$icons = array( 'wc' => '🚻' );
		$doors = array( 'er' => 'n', 'opd' => 'n' );
		$out[] = array( 'id' => $r[0], 'name' => $r[1], 'short' => $r[2], 'icon' => isset( $icons[ $r[0] ] ) ? $icons[ $r[0] ] : '', 'cat' => $r[3], 'r' => $r[4], 'floors' => $r[5], 'roof' => in_array( $r[0], $flat, true ) ? 'flat' : 'gable', 'sign' => isset( $signs[ $r[0] ] ) ? $signs[ $r[0] ] : '', 'door' => isset( $doors[ $r[0] ] ) ? $doors[ $r[0] ] : 's' );
	}
	return $out;
}

/** ชนิดของจุดสังเกต: key => [ชื่อ, ไอคอน] */
function hos_campus_mark_kinds() {
	return array(
		'junction' => array( 'ทางแยก', '🔀' ),
		'entrance' => array( 'ทางเข้า / ประตูรั้ว', '🚪' ),
		'stairs'   => array( 'บันได', '🪜' ),
		'lift'     => array( 'ลิฟต์', '🛗' ),
		'ramp'     => array( 'ทางลาด', '♿' ),
		'wc'       => array( 'ห้องน้ำ', '🚻' ),
		'parking'  => array( 'ที่จอดรถ', '🅿️' ),
		'sign'     => array( 'ป้าย / จุดนัดพบ', '🪧' ),
		'spot'     => array( 'จุดสังเกตอื่น ๆ', '📍' ),
	);
}

/** เมตรต่อ 1 พิกเซลของภาพผัง (จากจุดเทียบพิกัด 2 จุด) · 0 = ยังไม่ได้เทียบ */
function hos_campus_mpp( $geo ) {
	if ( ! hos_campus_geo_ok( $geo ) ) {
		return 0;
	}
	list( $a, $b ) = $geo;
	$R  = 6371000;
	$f1 = deg2rad( $a[2] );
	$f2 = deg2rad( $b[2] );
	$df = $f2 - $f1;
	$dl = deg2rad( $b[3] - $a[3] );
	$h  = sin( $df / 2 ) ** 2 + cos( $f1 ) * cos( $f2 ) * sin( $dl / 2 ) ** 2;
	$m  = 2 * $R * atan2( sqrt( $h ), sqrt( 1 - $h ) );
	$px = hypot( $b[0] - $a[0], $b[1] - $a[1] );
	return $px > 0 ? round( $m / $px, 4 ) : 0;
}

/** จุดสังเกตเริ่มต้น (ที่จอดรถ ฯลฯ) */
function hos_campus_default_marks() {
	return array(
		array( 't' => 'ทางเข้าโรงพยาบาล', 'ic' => '🚪', 'x' => 470, 'y' => 16 ),
		array( 't' => 'ที่จอดรถ', 'ic' => '🅿️', 'x' => 110, 'y' => 300 ),
		array( 't' => 'ที่จอดรถ', 'ic' => '🅿️', 'x' => 800, 'y' => 520 ),
	);
}

/** มีพิกัดจริง 2 จุดที่ต่างกันหรือยัง */
function hos_campus_geo_ok( $geo ) {
	return is_array( $geo ) && 2 === count( $geo ) && (float) $geo[0][2] !== (float) $geo[1][2] && (float) $geo[0][3] !== (float) $geo[1][3];
}

/** จุดเทียบพิกัด GPS 2 จุด: [x ภาพ, y ภาพ, ละติจูด, ลองจิจูด] (ขอบเขตโรงพยาบาลจาก OpenStreetMap) */
function hos_campus_default_geo() {
	// ยังไม่ได้เทียบพิกัด (ละติจูด/ลองจิจูด = 0): ตั้งพิกัด 2 จุดในหน้าแก้ไขผัง เพื่อเปิดใช้ GPS
	return array( array( 150, 10, 0, 0 ), array( 830, 720, 0, 0 ) );
}

/** แปลงพิกัด GPS ↔ ตำแหน่งบนภาพผัง (เทียบจาก 2 จุดใน geo) */
function hos_campus_px( $geo, $lat, $lng ) {
	if ( ! hos_campus_geo_ok( $geo ) ) {
		return array( 0, 0 );
	}
	list( $a, $b ) = $geo;
	return array( round( $a[0] + ( $lng - $a[3] ) / ( $b[3] - $a[3] ) * ( $b[0] - $a[0] ), 1 ), round( $a[1] + ( $lat - $a[2] ) / ( $b[2] - $a[2] ) * ( $b[1] - $a[1] ), 1 ) );
}
function hos_campus_ll( $geo, $x, $y ) {
	list( $a, $b ) = $geo;
	return array( round( $a[2] + ( $y - $a[1] ) / ( $b[1] - $a[1] ) * ( $b[2] - $a[2] ), 7 ), round( $a[3] + ( $x - $a[0] ) / ( $b[0] - $a[0] ) * ( $b[3] - $a[3] ), 7 ) );
}

/** โครงข่ายทางเดินที่เก็บจริง (ประตู ทางเดิน จุด QR) เป็นพิกัดบนภาพ สำหรับหน้าเว็บ */
function hos_campus_net( $d ) {
	$g   = $d['geo'];
	$net = array( 'doors' => array(), 'paths' => array(), 'qr' => array() );
	foreach ( (array) ( $d['doors'] ?? array() ) as $o ) {
		$p                = hos_campus_px( $g, $o['lat'], $o['lng'] );
		$net['doors'][] = array( 'b' => $o['b'], 'x' => $p[0], 'y' => $p[1], 't' => $o['t'] ?? '' );
	}
	foreach ( (array) ( $d['paths'] ?? array() ) as $o ) {
		$pts = array();
		foreach ( (array) $o['pts'] as $ll ) {
			$pts[] = hos_campus_px( $g, $ll[0], $ll[1] );
		}
		if ( count( $pts ) > 1 ) {
			$net['paths'][] = array( 'wc' => ! empty( $o['wc'] ), 'pts' => $pts );
		}
	}
	foreach ( (array) ( $d['qr'] ?? array() ) as $o ) {
		$net['qr'][] = array( 'id' => $o['id'], 't' => $o['t'], 'x' => (int) $o['x'], 'y' => (int) $o['y'] );
	}
	return $net;
}

/** ข้อมูลผังที่ใช้จริง: จากหน้าแก้ไขผัง (ถ้าบันทึกไว้) หรือค่าเริ่มต้น */
function hos_campus_data() {
	$saved = get_option( 'hos_campus_data' );
	if ( is_array( $saved ) && isset( $saved['buildings'] ) ) {
		$d = $saved;
	} else {
		$d = array( 'buildings' => hos_campus_default_buildings(), 'marks' => hos_campus_default_marks() );
	}
	$d['buildings'] = apply_filters( 'hos_campus_buildings', $d['buildings'] );
	if ( ! isset( $d['marks'] ) ) {
		$d['marks'] = array();
	}
	if ( empty( $d['geo'] ) ) {
		$d['geo'] = hos_campus_default_geo();
	}
	$d += array( 'img' => '', 'h' => 794, 'road' => '', 'gmap' => '' );
	if ( '' === $d['img'] ) {
		$d['img'] = HOSCM_URL . 'assets/campus-base.jpg';
		$d['h']   = 794;
	}
	$d['h'] = max( 200, min( 2400, (int) $d['h'] ) );
	return $d;
}

function hos_campus_buildings() {
	$d = hos_campus_data();
	return $d['buildings'];
}

function hos_campus_render( $atts = array() ) {
	$full = ! empty( $atts['full'] );
	$cats = hos_campus_cats();
	$cd    = hos_campus_data();
	$bs    = $cd['buildings'];
	$marks = $cd['marks'];
	$img  = $cd['img'];
	$H    = (int) $cd['h'];
	$data = array();
	$html = '';
	foreach ( $bs as $b ) {
		$is_flat = isset( $b['roof'] ) && 'flat' === $b['roof'];
		$sign    = isset( $b['sign'] ) ? (string) $b['sign'] : '';
		list( $x, $y, $w, $h ) = $b['r'];
		$c   = isset( $cats[ $b['cat'] ] ) ? $cats[ $b['cat'] ][1] : '#888';
		$fl  = max( 1, count( $b['floors'] ) );
		$z   = 16 + $fl * 14; // ความสูงผนัง (ชั้นล่าง 16px + ชั้นละ 14px)
		$roofc = isset( $b['roofc'] ) ? (string) sanitize_hex_color( $b['roofc'] ) : '';
		$wallc = isset( $b['wallc'] ) ? (string) sanitize_hex_color( $b['wallc'] ) : '';
		if ( $roofc ) {
			$c = $roofc; // สีหลังคา / ดาดฟ้าที่เลือกเอง แทนสีตามประเภท
		}
		$st  = sprintf( 'left:%dpx;top:%dpx;width:%dpx;height:%dpx;--h:%dpx;--c:%s', $x, $y, $w, $h, $z, $c );
		if ( $wallc ) {
			$st .= ';--cw:' . $wallc;
		}
		$roof = '';
		if ( $is_flat ) {
			$roof = '<i class="f top flat"></i><i class="ph" style="left:' . round( $w * .18 ) . 'px;top:' . round( $h * .2 ) . 'px;width:' . round( $w * .22 ) . 'px;height:' . round( $h * .3 ) . 'px"><i class="pt"></i><i class="p1"></i><i class="p3"></i></i>';
		} else {
			// หลังคาจั่ว: สันหลังคาตามด้านยาว
			$lw = max( $w, $h );
			$sw = min( $w, $h );
			$o  = 5; // ชายคายื่น
			$rh = min( round( $sw * .3 ), 20 );
			$hs = $sw / 2 + $o;
			$L  = sqrt( $hs * $hs + $rh * $rh );
			$th = rad2deg( atan2( $rh, $hs ) );
			$rot = $h > $w ? ' rotateZ(90deg)' : '';
			$roof = sprintf(
				'<i class="rf" style="left:%spx;top:%spx;width:%dpx;height:%dpx;transform:translateZ(%dpx)%s;--L:%spx;--th:%sdeg;--rh:%dpx;--o:%dpx">'
				. '<i class="ra"></i><i class="rb"></i><i class="g1"></i><i class="g2"></i></i>',
				round( ( $w - $lw ) / 2, 1 ), round( ( $h - $sw ) / 2, 1 ), $lw, $sw, $z, $rot, round( $L, 2 ), round( $th, 2 ), $rh, $o
			);
		}
		$pc = '';
		if ( '' !== $sign ) {
			$dr = isset( $b['door'] ) && in_array( $b['door'], array( 'n', 's', 'e', 'w' ), true ) ? $b['door'] : 's';
			$pst = in_array( $dr, array( 'n', 's' ), true ) ? 'left:' . round( $w * .32 ) . 'px;width:' . round( $w * .36 ) . 'px' : 'top:' . round( $h * .32 ) . 'px;height:' . round( $h * .36 ) . 'px';
			$pc = '<i class="porch d-' . $dr . '" style="' . $pst . '"><i class="slab"><em>' . esc_html( $sign ) . '</em></i><i class="col c1"></i><i class="col c2"></i></i>';
		}
		$html .= '<div class="cb' . ( $is_flat ? ' is-modern' : '' ) . '" tabindex="0" role="button" data-door="' . esc_attr( isset( $b['door'] ) ? $b['door'] : 's' ) . '" data-id="' . esc_attr( $b['id'] ) . '" data-cat="' . esc_attr( $b['cat'] ) . '"' . ( $roofc ? ' data-cr' : '' ) . ( $wallc ? ' data-cw' : '' ) . ' style="' . esc_attr( $st ) . '" aria-label="' . esc_attr( $b['name'] ) . '">'
			. '<i class="f s1"></i><i class="f s2"></i><i class="f s3"></i><i class="f s4"></i>' . $roof . $pc
			. ( ! empty( $b['icon'] ) ? '<span class="ico" style="--top:' . ( $is_flat ? 0 : min( round( min( $w, $h ) * .3 ), 20 ) ) . 'px">' . esc_html( $b['icon'] ) . '</span>' : '' )
			. '<span class="tag" style="--top:' . ( $is_flat ? 0 : min( round( min( $w, $h ) * .3 ), 20 ) ) . 'px"><b>' . esc_html( $b['short'] ) . '</b>' . ( $fl > 1 ? '<small>' . $fl . ' ชั้น</small>' : '' ) . '</span></div>';
		$data[ $b['id'] ] = array( 'name' => $b['name'], 'cat' => $b['cat'], 'catName' => isset( $cats[ $b['cat'] ] ) ? $cats[ $b['cat'] ][0] : '', 'floors' => $b['floors'] );
	}
	// ทางเดินเชื่อมมีหลังคา
	foreach ( array( array( 550, 96, 25, 12 ), array( 466, 184, 12, 22 ), array( 426, 186, 12, 290 ), array( 422, 266, 180, 10 ), array( 422, 404, 42, 10 ), array( 566, 404, 30, 10 ), array( 388, 108, 8, 40 ), array( 386, 232, 6, 12 ) ) as $wk ) {
		$html .= sprintf( '<div class="wk" style="left:%dpx;top:%dpx;width:%dpx;height:%dpx"><i class="f top"></i><i class="f s1"></i><i class="f s3"></i></div>', $wk[0], $wk[1], $wk[2], $wk[3] );
	}
	// ต้นไม้
	$trees = array( array( 40, 120 ), array( 70, 160 ), array( 120, 60 ), array( 30, 330 ), array( 95, 360 ), array( 40, 420 ), array( 120, 470 ), array( 60, 520 ), array( 20, 600 ), array( 110, 640 ), array( 190, 700 ), array( 240, 650 ), array( 520, 660 ), array( 580, 700 ), array( 640, 650 ), array( 700, 720 ), array( 470, 740 ), array( 860, 120 ), array( 900, 200 ), array( 880, 300 ), array( 920, 380 ), array( 870, 470 ), array( 910, 560 ), array( 860, 640 ), array( 920, 720 ), array( 760, 160 ), array( 800, 100 ), array( 200, 260 ), array( 210, 480 ), array( 560, 560 ), array( 620, 560 ), array( 700, 600 ), array( 360, 700 ), array( 150, 560 ), array( 590, 330 ) );
	foreach ( $trees as $i => $t ) {
		$sz    = 22 + ( $i * 7 ) % 14;
		$html .= '<span class="tr" style="left:' . $t[0] . 'px;top:' . $t[1] . 'px;--s:' . $sz . 'px"></span>';
	}
	$legend = '';
	foreach ( $cats as $k => $c ) {
		$legend .= '<button type="button" data-cat="' . esc_attr( $k ) . '" style="--c:' . esc_attr( $c[1] ) . '">' . esc_html( $c[0] ) . '</button>';
	}
	hoscm_enqueue();
	ob_start();
	?>
	<div class="hos-campus<?php echo $full ? ' is-full' : ''; ?>" data-hos-campus>
		<div class="hos-campus-top">
			<label class="hos-campus-search"><span aria-hidden="true">🔍</span><input type="search" placeholder="ค้นหา เช่น เอกซเรย์, ห้องคลอด, ICU, รับยา, เจาะเลือด" aria-label="ค้นหาตึกหรือบริการ"></label>
			<div class="hos-campus-tabs"><button type="button" class="on" data-ground="sat">🛰️ พื้นดาวเทียม</button><button type="button" data-ground="plan">🗺️ พื้นผัง</button></div>
		</div>
		<div class="hos-campus-legend"><?php echo $legend; // phpcs:ignore ?></div>
		<div class="hos-campus-body">
			<div class="hos-campus-stage" data-stage>
				<div class="hos-campus-world" data-world data-w="960" data-h="<?php echo (int) $H; ?>" style="height:<?php echo (int) $H; ?>px">
					<div class="hos-campus-ground is-sat" style="--img:url('<?php echo esc_url( $img ); ?>')">
						<?php foreach ( $marks as $m ) : ?><span class="mk" style="left:<?php echo (int) $m['x']; ?>px;top:<?php echo (int) $m['y']; ?>px"><b><?php echo esc_html( trim( $m['ic'] . ' ' . $m['t'] ) ); ?></b></span><?php endforeach; ?>
						<svg class="hos-route" viewBox="0 0 960 <?php echo (int) $H; ?>" aria-hidden="true"><polyline points=""/><circle class="a" r="7"/><circle class="b" r="9"/><circle class="me-ring" r="16"/><circle class="me" r="8"/></svg>
						<?php if ( '' !== trim( (string) $cd['road'] ) ) : $rn = esc_html( $cd['road'] ); ?><div class="hos-campus-road"><span><?php echo $rn; ?></span><span><?php echo $rn; ?></span><span><?php echo $rn; ?></span></div><?php endif; ?>
						<?php foreach ( hos_campus_net( $cd )['qr'] as $q ) : ?><span class="mk qr" data-qr="<?php echo esc_attr( $q['id'] ); ?>" style="left:<?php echo (int) $q['x']; ?>px;top:<?php echo (int) $q['y']; ?>px"><b>📌 <?php echo esc_html( $q['t'] ); ?></b></span><?php endforeach; ?>
						<span class="nsew n">N</span><span class="nsew e">E</span><span class="nsew s">S</span><span class="nsew w">W</span>
						<?php echo $html; // phpcs:ignore ?>
					</div>
				</div>
				<div class="hos-campus-ctrl">
					<button type="button" data-act="in" aria-label="ซูมเข้า">＋</button>
					<button type="button" data-act="out" aria-label="ซูมออก">－</button>
					<button type="button" data-act="left" aria-label="หมุนซ้าย">⟲</button>
					<button type="button" data-act="right" aria-label="หมุนขวา">⟳</button>
					<button type="button" data-act="top" aria-label="มุมมองจากด้านบน">⬒</button>
					<button type="button" data-act="reset" aria-label="มุมมองเริ่มต้น">⌂</button>
				</div>
				<div class="hos-campus-compass" data-compass title="ทิศเหนือ" role="button" tabindex="0" aria-label="หันทิศเหนือขึ้นด้านบน"><i></i><b>N</b></div>
				<div class="hos-campus-help">ลากเพื่อหมุน/เอียง · ล้อเมาส์หรือถ่างนิ้วเพื่อซูม</div>
			</div>
			<aside class="hos-campus-info" aria-live="polite">
				<div class="hos-route-bar">
					<div class="hos-route-head"><b>🧭 นำทางในโรงพยาบาล</b><button type="button" class="hos-campus-fold" aria-label="ย่อ/ขยาย">▾</button></div>
					<label>เริ่มจาก<select class="hos-route-from"></select></label>
					<label class="hos-route-wc"><input type="checkbox" class="hos-route-wcbox"> ♿ เส้นทางสำหรับรถเข็น / ไม่มีบันได</label>
					<div class="hos-route-to">ไปที่: <span>แตะเลือกตึกบนแผนที่</span></div>
					<p class="hos-route-msg" hidden></p>
				</div>
				<div class="hos-campus-hint"><b>👆 แตะที่ตึก</b> เพื่อดูว่าแต่ละชั้นมีบริการอะไร หรือพิมพ์ค้นหาบริการที่ต้องการ</div>
				<ul class="hos-campus-results" hidden></ul>
				<div class="hos-campus-detail" hidden></div>
			</aside>
		</div>
		<script type="application/json" class="hos-campus-data"><?php echo wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ); ?></script>
		<script type="application/json" class="hos-campus-net"><?php echo wp_json_encode( hos_campus_net( $cd ), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ); ?></script>
		<script type="application/json" class="hos-campus-geo"><?php echo wp_json_encode( hos_campus_geo_ok( $cd['geo'] ) ? $cd['geo'] : null ); ?></script>
		<script type="application/json" class="hos-campus-mpp"><?php echo wp_json_encode( hos_campus_mpp( $cd['geo'] ) ); ?></script>
		<div class="hos-campus-tip" hidden></div>
		<div class="hos-wf-ask" role="dialog" aria-modal="true" aria-labelledby="hos-wf-ask-t" hidden><div class="box"><b id="hos-wf-ask-t"></b><p></p><div class="acts"></div></div></div>
		<div class="hos-wf" aria-live="polite" hidden>
			<div class="hos-wf-now"><span class="arrow" aria-hidden="true">⬆</span><div><b class="txt"></b><small class="sub"></small></div><img class="photo" alt="" hidden></div>
			<div class="hos-wf-bar"><span class="left"></span><span class="acc"></span><button type="button" class="voice" aria-pressed="true" title="เสียงนำทาง">🔊</button><button type="button" class="steps-btn">ขั้นตอน</button><button type="button" class="stop">หยุดนำทาง</button></div>
			<ol class="hos-wf-steps" hidden></ol>
		</div>
		<script type="application/json" class="hos-campus-marks"><?php echo wp_json_encode( $marks, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ); ?></script>
		<a class="hos-campus-gmap" hidden href="<?php echo esc_url( 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( hoscm_map_query() ) ); ?>"></a>
	</div>
	<?php
	return ob_get_clean();
}
