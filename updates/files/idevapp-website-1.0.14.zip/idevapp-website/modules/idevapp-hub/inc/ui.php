<?php
/** Front-end helpers: mobile quick bar, LINE, back-to-top, text size, cookie consent, image ratios, Google data. */
defined('ABSPATH') || exit;

function ihub_ui_icon($name) {
    $paths = [
        'line' => '<path d="M12 3C6.5 3 2 6.6 2 11c0 3.9 3.5 7.2 8.3 7.9.3.1.8.2.9.5.1.3.1.7 0 1l-.1.9c0 .3-.2 1 .9.5s5.9-3.5 8-6c1.4-1.6 2-3.2 2-4.8C22 6.6 17.5 3 12 3Z"/>',
        'up' => '<path d="m6 15 6-6 6 6"/>',
        'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
        'navigate' => '<path d="m3 11 18-8-8 18-2-8-8-2Z"/>',
        'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    ];
    if (!isset($paths[$name])) return ihub_icon($name);
    $fill = $name === 'line' ? ' fill="currentColor" stroke="none"' : ' fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
    return '<svg viewBox="0 0 24 24"' . $fill . ' aria-hidden="true">' . $paths[$name] . '</svg>';
}

/** Opens Google Maps with the route to us (on phones: the Maps app). Uses the coordinates in the map code when possible. */
function ihub_directions_url() {
    if (ihub_uses('maps') && function_exists('idev_maps_directions_url') && ($u = idev_maps_directions_url())) return $u;
    $dest = ihub_map_destination(ihub_setting('map_query')) ?: ihub_site_local('th')['address'];
    return 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode($dest);
}

/** A- A A+ buttons (theme puts them in the top line). */
function ihub_render_font_tools() {
    if (ihub_setting('font_tools') !== 'true') return '';
    return '<span class="ihub-font-tools" role="group" aria-label="' . esc_attr(ihub_t('ui.textSize')) . '"><button type="button" data-ihub-font="-1" aria-label="' . esc_attr(ihub_t('ui.smaller')) . '">A-</button><button type="button" data-ihub-font="0" aria-label="' . esc_attr(ihub_t('ui.normal')) . '">A</button><button type="button" data-ihub-font="1" aria-label="' . esc_attr(ihub_t('ui.larger')) . '">A+</button></span>';
}

/** iframe that waits for cookie consent (maps, videos) when the cookie banner is on. */
function ihub_consent_iframe($src, $title, $kind = 'map', $attrs = '') {
    if (ihub_setting('cookie_banner') !== 'true' && !ihub_uses('cookie')) return '<iframe src="' . esc_url($src) . '" title="' . esc_attr($title) . '" loading="lazy" ' . $attrs . '></iframe>';
    $label = $kind === 'video' ? ihub_t('ui.loadVideo') : ihub_t('ui.loadMap');
    return '<div class="ihub-consent" data-ihub-consent="' . esc_attr($kind) . '"><iframe data-ihub-src="' . esc_url($src) . '" title="' . esc_attr($title) . '" loading="lazy" ' . $attrs . ' hidden></iframe>'
        . '<div class="ihub-consent-box"><button type="button" class="button button-white" data-ihub-load>' . ihub_ui_icon($kind === 'video' ? 'navigate' : 'pin') . ' ' . esc_html($label) . '</button><small>' . esc_html(ihub_t('ui.consentNote')) . '</small></div></div>';
}

// Image ratios (Settings → รูปภาพ) as CSS variables used by the theme.
add_action('wp_head', function () {
    $ratio = function ($key) { $v = ihub_setting($key); return preg_match('#^\d+/\d+$#', $v) ? str_replace('/', ' / ', $v) : 'auto'; };
    $position = in_array(ihub_setting('img_position'), ['center', 'top', 'bottom'], true) ? ihub_setting('img_position') : 'center';
    echo '<style id="ihub-image-ratios">:root{--ihub-ratio-news:' . $ratio('img_ratio_news') . ';--ihub-ratio-article:' . $ratio('img_ratio_article') . ';--ihub-ratio-gallery:' . $ratio('img_ratio_gallery') . ';--ihub-ratio-team:' . $ratio('img_ratio_team') . ';--ihub-img-position:center ' . $position . '}</style>';
}, 20);

// Google: clinic name, address, phone and opening hours as structured data (home page).
add_action('wp_head', function () {
    if (!is_front_page() || (function_exists('ihub_seo_on') && ihub_seo_on())) return; // the SEO module prints a fuller version
    $local = ihub_site_local('th');
    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    $hours = [];
    foreach (ihub_hours() as $day => $row) if (!$row['closed']) $hours[] = ['@type' => 'OpeningHoursSpecification', 'dayOfWeek' => $days[$day - 1], 'opens' => $row['open'], 'closes' => $row['close']];
    $data = ['@context' => 'https://schema.org', '@type' => 'MedicalClinic', 'name' => $local['name'], 'alternateName' => ihub_setting('site_name_en'), 'url' => home_url('/'),
        'telephone' => ihub_setting('phone'), 'address' => ['@type' => 'PostalAddress', 'streetAddress' => $local['address'], 'addressCountry' => 'TH'], 'openingHoursSpecification' => $hours];
    if (function_exists('idevapp_logo_url')) $data['logo'] = idevapp_logo_url();
    if (ihub_setting('line_url')) $data['sameAs'] = [ihub_setting('line_url')];
    echo '<script type="application/ld+json">' . wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . '</script>';
}, 30);

add_action('wp_footer', function () {
    if (is_admin()) return;
    $phone = ihub_setting('phone');
    $line = ihub_setting('line_url');
    $book = ihub_setting('appointment_url');
    // Mobile quick bar
    if (ihub_setting('quickbar') === 'true') {
        $items = ['<a class="ihub-qb-call" href="tel:' . esc_attr($phone) . '">' . ihub_icon('phone') . '<span>' . esc_html(ihub_t('ui.call')) . '</span></a>'];
        if ($book) $items[] = '<a href="' . esc_url($book) . '" target="_blank" rel="noopener noreferrer">' . ihub_ui_icon('calendar') . '<span>' . esc_html(ihub_t('ui.book')) . '</span></a>';
        $items[] = '<a href="' . esc_url(ihub_directions_url()) . '" target="_blank" rel="noopener noreferrer">' . ihub_ui_icon('navigate') . '<span>' . esc_html(ihub_t('ui.directions')) . '</span></a>';
        if ($line) $items[] = '<a class="ihub-qb-line" href="' . esc_url($line) . '" target="_blank" rel="noopener noreferrer">' . ihub_ui_icon('line') . '<span>' . esc_html(ihub_t('ui.line')) . '</span></a>';
        echo '<nav class="ihub-quickbar" aria-label="' . esc_attr(ihub_t('header.mainMenu')) . '" style="--ihub-qb-count:' . count($items) . '">' . implode('', $items) . '</nav>';
    }
    // Floating buttons (LINE on larger screens, back to top)
    $float = '';
    if ($line) $float .= '<a class="ihub-float ihub-float-line" href="' . esc_url($line) . '" target="_blank" rel="noopener noreferrer" aria-label="LINE">' . ihub_ui_icon('line') . '</a>';
    // a link to #top works even when scripts are delayed or blocked (cache / optimiser plugins); theme แบบที่ 1 has its own button
    if (ihub_setting('back_to_top') === 'true' && get_template() !== 'idevapp-theme-1') $float .= '<a href="#top" class="ihub-float ihub-to-top" aria-label="' . esc_attr(ihub_t('ui.backToTop')) . '" title="' . esc_attr(ihub_t('ui.backToTop')) . '">' . ihub_ui_icon('up') . '</a>';
    if ($float) echo '<div class="ihub-floats' . (ihub_setting('quickbar') === 'true' ? ' has-quickbar' : '') . '">' . $float . '</div>';
    // Cookie consent (iDev Cookie Consent shows its own banner when active)
    if (ihub_setting('cookie_banner') === 'true' && !ihub_uses('cookie')) {
        $privacy = ihub_setting('privacy_url') ?: (get_privacy_policy_url() ?: '');
        echo '<div class="ihub-cookie" role="dialog" aria-live="polite" aria-label="Cookies" hidden><p>' . esc_html(ihub_pick(ihub_setting('cookie_text'), ihub_setting('cookie_text_en'))) . ($privacy ? ' <a href="' . esc_url($privacy) . '">' . esc_html(ihub_t('ui.privacy')) . '</a>' : '') . '</p>'
            . '<div class="ihub-cookie-actions"><button type="button" class="button button-white" data-ihub-consent-choice="necessary">' . esc_html(ihub_t('ui.cookieNecessary')) . '</button><button type="button" class="button button-teal" data-ihub-consent-choice="all">' . esc_html(ihub_t('ui.cookieAccept')) . '</button></div></div>';
    }
}, 5);

/** Doctors / clinics whose name, specialty or bio match a search. */
function ihub_search_providers($query) {
    $query = trim((string) $query);
    if ($query === '') return [];
    $needle = mb_strtolower($query);
    $found = [];
    foreach (ihub_get_providers() as $p) {
        $hay = mb_strtolower(implode(' ', [$p['name'], $p['name_en'], $p['specialty'], $p['specialty_en'], $p['note'], $p['note_en'], $p['bio'], $p['bio_en']]));
        if (strpos($hay, $needle) !== false) $found[] = $p;
    }
    return $found;
}

/** Address of the clinic schedule page (the page with slug "doctors", else the first page with a schedule block). */
function ihub_schedule_page_url() {
    static $url = null;
    if ($url !== null) return $url;
    if (ihub_uses('schedule') && function_exists('idev_cs_schedule_url') && (int) idev_cs_setting('schedule_page')) return $url = idev_cs_schedule_url();
    $page = get_page_by_path('doctors');
    if (!$page || $page->post_status !== 'publish') {
        $pages = get_posts(['post_type' => 'page', 'numberposts' => 1, 's' => 'wp:idevapp/doctors', 'search_columns' => ['post_content'], 'fields' => 'ids']);
        $page = $pages ? get_post($pages[0]) : null;
    }
    return $url = $page ? get_permalink($page) : home_url('/doctors/');
}
