<?php
/**
 * SEO: everything search engines read, filled in automatically when the editor leaves it empty.
 * - <title>, meta description, canonical, robots, hreflang TH/EN, Open Graph / X (Twitter) cards
 * - structured data (JSON-LD): the organisation (hospital / clinic / government office) with address, geo,
 *   phone, opening hours; WebSite + search; BreadcrumbList; NewsArticle for news; FAQPage comes from the FAQ block
 * - per page: SEO box with a Google preview and a checklist (focus word, lengths, headings, image alt texts …)
 * - automatic fill: description, focus word and image alt texts on save, and for the whole site in one click
 * - Search Console / Bing verification, XML sitemap (WordPress) without noindex pages
 * Turns itself off when Yoast SEO, Rank Math, SEOPress or All in One SEO is active.
 */
defined('ABSPATH') || exit;

function ihub_seo_other_plugin() { return defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION') || defined('SEOPRESS_VERSION') || defined('AIOSEO_VERSION'); }
function ihub_seo_on() { return ihub_setting('seo_on') !== 'false' && !ihub_seo_other_plugin(); }


/* ---------- helpers ---------- */

function ihub_seo_meta($id, $k, $lang = null) {
    $th = (string) get_post_meta($id, "_ihub_seo_{$k}", true);
    $en = (string) get_post_meta($id, "_ihub_seo_{$k}_en", true);
    return $lang === 'raw' ? $th : ihub_pick($th, $en, $lang);
}
/** Plain text of a post (blocks rendered, tags and shortcodes removed). */
function ihub_seo_text($post) {
    $html = $post->post_content;
    if (function_exists('do_blocks')) $html = do_blocks($html);
    $html = preg_replace('#<(script|style)[^>]*>.*?</\1>#is', ' ', $html);
    return trim(preg_replace('/\s+/u', ' ', html_entity_decode(wp_strip_all_tags(strip_shortcodes($html)), ENT_QUOTES, 'UTF-8')));
}
function ihub_seo_cut($text, $max = 155) {
    $text = trim(preg_replace('/\s+/u', ' ', (string) $text));
    if (mb_strlen($text) <= $max) return $text;
    $cut = mb_substr($text, 0, $max);
    $sp = mb_strrpos($cut, ' ');
    return rtrim($sp > $max * 0.6 ? mb_substr($cut, 0, $sp) : $cut, " ,.;:-") . '…';
}
/** Description: the one written in the SEO box → summary → start of the text. */
function ihub_seo_description($post = null) {
    $post = get_post($post);
    if (!$post) return '';
    $d = ihub_seo_meta($post->ID, 'desc');
    if ($d !== '') return $d;
    $ex = function_exists('ihub_en_meta') && ihub_lang() === 'en' ? ihub_en_meta($post->ID, 'excerpt') : '';
    if ($ex === '') $ex = $post->post_excerpt;
    return ihub_seo_cut($ex !== '' ? wp_strip_all_tags($ex) : ihub_seo_text($post));
}
function ihub_seo_image($post = null) {
    $post = get_post($post);
    if ($post) {
        $id = (int) get_post_meta($post->ID, '_ihub_seo_image', true) ?: (int) get_post_thumbnail_id($post);
        if ($id && ($u = wp_get_attachment_image_url($id, 'large'))) return $u;
        if (preg_match('/<img[^>]+src=["\']([^"\']+)/i', $post->post_content, $m)) return $m[1];
        if (preg_match('/"image":"(https?:[^"]+)"/', $post->post_content, $m)) return stripslashes($m[1]);
    }
    if (ihub_setting('seo_image')) return ihub_setting('seo_image');
    return function_exists('idevapp_logo_url') ? idevapp_logo_url() : (string) get_site_icon_url(512);
}
/** A focus word guessed from the title (first part before separators). */
function ihub_seo_guess_keyword($title) {
    $parts = preg_split('/\s*[|:–—\-\(\)]\s*/u', (string) $title);
    $k = trim($parts[0] ?? '');
    return mb_strlen($k) > 40 ? mb_substr($k, 0, 40) : $k;
}

/* ---------- languages Google can crawl ----------
 * People switch language with a cookie (?lang=en sets it and reloads). Search engines keep no cookies, so for them
 * ?lang=en / ?lang=th shows that language straight away (the same page a person sees after switching), and the
 * canonical link keeps the parameter, so the English pages can be found too. */
function ihub_seo_is_bot() { return (bool) preg_match('/bot|crawl|spider|slurp|google|bing|yandex|baidu|duckduck|facebookexternalhit|line-poker|embedly|preview/i', (string) ($_SERVER['HTTP_USER_AGENT'] ?? '')); }
add_action('template_redirect', function () {
    global $ihub_seo_lang;
    if (!ihub_seo_on() || !isset($_GET['lang']) || !in_array($_GET['lang'], ['th', 'en'], true) || !ihub_seo_is_bot()) return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $ihub_seo_lang = sanitize_key($_GET['lang']); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    ihub_set_lang($ihub_seo_lang);
    if (function_exists('idev_bilingual_force')) idev_bilingual_force($ihub_seo_lang);
    if (function_exists('switch_to_locale')) switch_to_locale($ihub_seo_lang === 'en' ? 'en_US' : 'th');
    unset($_GET['lang']); // the switch-and-reload handlers then leave the request alone
}, 0);
add_filter('get_canonical_url', function ($url) { global $ihub_seo_lang; return $ihub_seo_lang ? add_query_arg('lang', $ihub_seo_lang, $url) : $url; });

/* ---------- <head> ---------- */

add_filter('document_title_parts', function ($parts) {
    if (!ihub_seo_on()) return $parts;
    if (is_singular() && ($t = ihub_seo_meta(get_queried_object_id(), 'title')) !== '') { $parts['title'] = $t; unset($parts['site'], $parts['tagline']); }
    if (is_front_page()) {
        $t = ihub_pick(ihub_setting('seo_home_title'), ihub_setting('seo_home_title_en'));
        $local = ihub_site_local(ihub_lang());
        $parts = $t !== '' ? ['title' => $t] : ['title' => $local['name'], 'tagline' => $local['tagline']];
    }
    return $parts;
}, 20);
add_action('wp', function () { if (ihub_seo_on()) remove_action('wp_head', 'wp_robots', 1); }); // ours below says the same and more
add_filter('document_title_separator', function ($sep) { return ihub_seo_on() ? '|' : $sep; });

add_action('wp_head', function () {
    if (!ihub_seo_on()) return;
    $lang = ihub_lang();
    $site = ihub_site_local($lang)['name'];
    $obj = get_queried_object();
    $desc = '';
    $type = 'website';
    $url = '';
    $image = ihub_seo_image(is_singular() ? $obj : null);
    if (is_front_page()) {
        $desc = ihub_pick(ihub_setting('seo_home_desc'), ihub_setting('seo_home_desc_en')) ?: ihub_seo_cut(ihub_pick(ihub_setting('hero_text'), ihub_setting('hero_text_en')));
        $url = home_url('/');
    } elseif (is_singular()) {
        $desc = ihub_seo_description($obj);
        $type = $obj->post_type === 'post' ? 'article' : 'website';
        $url = get_permalink($obj);
    } elseif (is_category() || is_tag() || is_tax()) {
        $desc = ihub_seo_cut(wp_strip_all_tags(term_description()) ?: sprintf(ihub_pick('รวมข่าวหมวด %s จาก %s', 'All news in %s from %s'), single_term_title('', false), $site));
        $url = get_term_link($obj);
    } elseif (is_home()) {
        $desc = sprintf(ihub_pick('ข่าวสารและประกาศล่าสุดจาก %s', 'Latest news and announcements from %s'), $site);
        $url = get_permalink(get_option('page_for_posts')) ?: home_url('/');
    }
    $noindex = is_search() || is_404() || (is_paged() && !is_home()) || is_author() || is_date() || (is_singular() && get_post_meta($obj->ID, '_ihub_seo_noindex', true) === '1');
    $out = [];
    if ($desc !== '') $out[] = '<meta name="description" content="' . esc_attr($desc) . '">';
    if ($noindex) $out[] = '<meta name="robots" content="noindex, follow">';
    else $out[] = '<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1">';
    global $ihub_seo_lang;
    if ($url && !is_singular() && !is_wp_error($url)) $out[] = '<link rel="canonical" href="' . esc_url($ihub_seo_lang ? add_query_arg('lang', $ihub_seo_lang, $url) : $url) . '">'; // WordPress prints it for single pages
    if ($url && !is_wp_error($url) && function_exists('ihub_lang_url')) {
        $out[] = '<link rel="alternate" hreflang="th" href="' . esc_url(add_query_arg('lang', 'th', $url)) . '">';
        $out[] = '<link rel="alternate" hreflang="en" href="' . esc_url(add_query_arg('lang', 'en', $url)) . '">';
        $out[] = '<link rel="alternate" hreflang="x-default" href="' . esc_url($url) . '">';
    }
    $title = wp_get_document_title();
    $og = ['og:locale' => $lang === 'en' ? 'en_US' : 'th_TH', 'og:type' => $type, 'og:site_name' => $site, 'og:title' => $title, 'og:description' => $desc, 'og:url' => is_wp_error($url) ? '' : $url, 'og:image' => $image];
    foreach ($og as $k => $v) if ($v !== '') $out[] = '<meta property="' . $k . '" content="' . esc_attr($v) . '">';
    if ($type === 'article') { $out[] = '<meta property="article:published_time" content="' . esc_attr(get_post_time('c', true, $obj)) . '">'; $out[] = '<meta property="article:modified_time" content="' . esc_attr(get_post_modified_time('c', true, $obj)) . '">'; }
    $out[] = '<meta name="twitter:card" content="summary_large_image">';
    foreach (['google-site-verification' => 'seo_google', 'msvalidate.01' => 'seo_bing'] as $n => $k) {
        $code = ihub_setting($k);
        if (preg_match('/content=["\']([^"\']+)/', $code, $m)) $code = $m[1]; // a whole <meta> tag was pasted
        if ($code !== '') $out[] = '<meta name="' . $n . '" content="' . esc_attr($code) . '">';
    }
    echo "\n<!-- iDevApp SEO -->\n" . implode("\n", $out) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above
    foreach (ihub_seo_schema() as $graph) echo '<script type="application/ld+json">' . wp_json_encode($graph, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . "</script>\n";
}, 2);

/** Structured data for this page. */
function ihub_seo_schema() {
    $lang = ihub_lang();
    $local = ihub_site_local($lang);
    $type = ihub_setting('seo_org_type') ?: 'MedicalClinic';
    $org = ['@context' => 'https://schema.org', '@type' => $type, '@id' => home_url('/#organization'), 'name' => $local['name'], 'alternateName' => ihub_setting('site_name_en'), 'url' => home_url('/'),
        'telephone' => ihub_setting('phone'), 'address' => ['@type' => 'PostalAddress', 'streetAddress' => $local['address'], 'addressCountry' => 'TH']];
    $logo = function_exists('idevapp_logo_url') ? idevapp_logo_url() : '';
    if ($logo) { $org['logo'] = $logo; $org['image'] = ihub_setting('seo_image') ?: $logo; }
    foreach (['addressLocality' => 'seo_city', 'addressRegion' => 'seo_province', 'postalCode' => 'seo_postcode'] as $k => $s) if (ihub_setting($s)) $org['address'][$k] = ihub_setting($s);
    if (preg_match('/^\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$/', (string) ihub_setting('seo_geo'), $m)) $org['geo'] = ['@type' => 'GeoCoordinates', 'latitude' => (float) $m[1], 'longitude' => (float) $m[2]];
    $same = array_values(array_filter(array_map('trim', preg_split('/[\s,]+/', (string) ihub_setting('seo_same_as') . ' ' . ihub_setting('line_url')))));
    if ($same) $org['sameAs'] = $same;
    if (in_array($type, ['MedicalClinic', 'Hospital', 'LocalBusiness', 'MedicalOrganization'], true) && function_exists('ihub_hours')) {
        $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $hours = [];
        foreach (ihub_hours() as $day => $row) if (!$row['closed']) $hours[] = ['@type' => 'OpeningHoursSpecification', 'dayOfWeek' => $days[$day - 1], 'opens' => $row['open'], 'closes' => $row['close']];
        if (ihub_setting('emergency_24h') === 'true') $hours = [['@type' => 'OpeningHoursSpecification', 'dayOfWeek' => $days, 'opens' => '00:00', 'closes' => '23:59']];
        if ($hours) $org['openingHoursSpecification'] = $hours;
    }
    $out = [];
    if (is_front_page()) {
        $out[] = $org;
        $out[] = ['@context' => 'https://schema.org', '@type' => 'WebSite', '@id' => home_url('/#website'), 'url' => home_url('/'), 'name' => $local['name'], 'inLanguage' => $lang === 'en' ? 'en' : 'th', 'publisher' => ['@id' => home_url('/#organization')],
            'potentialAction' => ['@type' => 'SearchAction', 'target' => home_url('/?s={search_term_string}'), 'query-input' => 'required name=search_term_string']];
        return $out;
    }
    if (is_singular()) {
        $post = get_queried_object();
        $crumbs = [['@type' => 'ListItem', 'position' => 1, 'name' => ihub_pick('หน้าแรก', 'Home'), 'item' => home_url('/')]];
        $n = 2;
        if ($post->post_type === 'post') { $c = get_the_category($post->ID); if ($c) $crumbs[] = ['@type' => 'ListItem', 'position' => $n++, 'name' => $c[0]->name, 'item' => get_category_link($c[0])]; }
        foreach (array_reverse(get_post_ancestors($post)) as $aid) $crumbs[] = ['@type' => 'ListItem', 'position' => $n++, 'name' => get_the_title($aid), 'item' => get_permalink($aid)];
        $crumbs[] = ['@type' => 'ListItem', 'position' => $n, 'name' => get_the_title($post), 'item' => get_permalink($post)];
        $out[] = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $crumbs];
        if ($post->post_type === 'post') {
            $out[] = ['@context' => 'https://schema.org', '@type' => 'NewsArticle', 'headline' => mb_substr(get_the_title($post), 0, 110), 'description' => ihub_seo_description($post), 'image' => [ihub_seo_image($post)],
                'datePublished' => get_post_time('c', true, $post), 'dateModified' => get_post_modified_time('c', true, $post), 'mainEntityOfPage' => get_permalink($post), 'inLanguage' => $lang === 'en' ? 'en' : 'th',
                'author' => ['@type' => 'Organization', 'name' => $local['name'], 'url' => home_url('/')], 'publisher' => ['@type' => 'Organization', 'name' => $local['name'], 'logo' => ['@type' => 'ImageObject', 'url' => $logo]]];
        }
    }
    return $out;
}

/* Images without alt text get one (the image title, or the page title) — for Google Images and screen readers. */
add_filter('wp_get_attachment_image_attributes', function ($attr, $att) {
    if (ihub_seo_on() && trim((string) ($attr['alt'] ?? '')) === '') $attr['alt'] = ihub_seo_alt_for($att->ID);
    return $attr;
}, 10, 2);
add_filter('the_content', function ($html) {
    if (!ihub_seo_on() || is_admin() || stripos($html, '<img') === false) return $html;
    $fallback = esc_attr(get_the_title());
    return preg_replace_callback('/<img\b[^>]*>/i', function ($m) use ($fallback) {
        $tag = $m[0];
        if (preg_match('/\balt\s*=\s*"[^"]+"/i', $tag)) return $tag;
        $alt = $fallback;
        if (preg_match('/wp-image-(\d+)/', $tag, $id)) $alt = esc_attr(ihub_seo_alt_for((int) $id[1]) ?: $fallback);
        $tag = preg_replace('/\balt\s*=\s*"\s*"/i', '', $tag);
        return preg_replace('/<img\b/i', '<img alt="' . $alt . '"', $tag, 1);
    }, $html);
}, 30);
function ihub_seo_alt_for($id) {
    $alt = trim((string) get_post_meta($id, '_wp_attachment_image_alt', true));
    if ($alt !== '') return $alt;
    $title = trim((string) get_the_title($id));
    if ($title !== '' && !preg_match('/^(img|image|dsc|photo|screenshot|gemini|whatsapp|line)[\s_\-]*[\w\-]*$/i', $title) && !preg_match('/^[0-9a-f\-_ ]{8,}$/i', $title)) return $title;
    $parent = (int) get_post_field('post_parent', $id);
    return $parent ? get_the_title($parent) : ihub_site_local()['name'];
}
// New uploads: alt text from a readable file name.
add_action('add_attachment', function ($id) {
    if (!ihub_seo_on() || !wp_attachment_is_image($id) || get_post_meta($id, '_wp_attachment_image_alt', true) !== '') return;
    $alt = ihub_seo_alt_for($id);
    if ($alt !== '') update_post_meta($id, '_wp_attachment_image_alt', sanitize_text_field($alt));
});

/* Sitemap (WordPress): no noindex pages, no attachment or user lists. */
add_filter('wp_sitemaps_posts_query_args', function ($args) { if (!ihub_seo_on()) return $args; $args['meta_query'] = [['key' => '_ihub_seo_noindex', 'compare' => 'NOT EXISTS']]; return $args; });
add_filter('wp_sitemaps_add_provider', function ($provider, $name) { return ihub_seo_on() && $name === 'users' ? false : $provider; }, 10, 2);

/* ---------- automatic fill ---------- */

/** Fills what is missing on one post: description, focus word, image alt texts. Returns what it filled. */
function ihub_seo_autofill($post_id) {
    $post = get_post($post_id);
    if (!$post || !in_array($post->post_type, ['post', 'page'], true)) return [];
    $done = [];
    if ((string) get_post_meta($post->ID, '_ihub_seo_desc', true) === '') {
        $d = $post->post_excerpt !== '' ? ihub_seo_cut(wp_strip_all_tags($post->post_excerpt)) : ihub_seo_cut(ihub_seo_text($post));
        if (mb_strlen($d) >= 40) { update_post_meta($post->ID, '_ihub_seo_desc', $d); $done[] = 'description'; }
    }
    if ((string) get_post_meta($post->ID, '_ihub_seo_focus', true) === '' && ($k = ihub_seo_guess_keyword($post->post_title)) !== '') { update_post_meta($post->ID, '_ihub_seo_focus', $k); $done[] = 'focus'; }
    $ids = [];
    if (has_post_thumbnail($post)) $ids[] = (int) get_post_thumbnail_id($post);
    if (preg_match_all('/wp-image-(\d+)/', $post->post_content, $m)) $ids = array_merge($ids, array_map('intval', $m[1]));
    if (preg_match_all('/"image":"(https?:[^"]+)"/', $post->post_content, $m2)) foreach ($m2[1] as $u) { $aid = attachment_url_to_postid(stripslashes($u)); if ($aid) $ids[] = $aid; }
    foreach (array_unique($ids) as $aid) {
        if (trim((string) get_post_meta($aid, '_wp_attachment_image_alt', true)) !== '') continue;
        $alt = ihub_seo_alt_for($aid);
        if ($alt === ihub_site_local()['name'] || $alt === '') $alt = $post->post_title;
        update_post_meta($aid, '_wp_attachment_image_alt', sanitize_text_field($alt));
        $done[] = 'alt';
    }
    return $done;
}
add_action('save_post', function ($id, $post) {
    if (!ihub_seo_on() || wp_is_post_revision($id) || wp_is_post_autosave($id) || !in_array($post->post_type, ['post', 'page'], true) || $post->post_status === 'auto-draft') return;
    if (ihub_setting('seo_autofill') !== 'false') ihub_seo_autofill($id);
}, 30, 2);

/* ---------- checklist ---------- */

/** [score 0–100, [[ok, text], …]] for one post. */
function ihub_seo_check($post) {
    $post = get_post($post);
    $title = ihub_seo_meta($post->ID, 'title', 'raw') ?: $post->post_title;
    $desc = ihub_seo_meta($post->ID, 'desc', 'raw') ?: ihub_seo_description($post);
    $focus = mb_strtolower(trim((string) get_post_meta($post->ID, '_ihub_seo_focus', true)));
    $text = ihub_seo_text($post);
    $html = function_exists('do_blocks') ? do_blocks($post->post_content) : $post->post_content;
    $c = [];
    $tl = mb_strlen($title);
    $c[] = [$tl >= 15 && $tl <= 65, sprintf('หัวเรื่องยาว %d ตัวอักษร (เหมาะ 15–65)', $tl)];
    $dl = mb_strlen($desc);
    $c[] = [$dl >= 50 && $dl <= 160, $dl ? sprintf('คำอธิบาย %d ตัวอักษร (เหมาะ 50–160)', $dl) : 'ยังไม่มีคำอธิบาย (meta description)'];
    $c[] = [$focus !== '', $focus !== '' ? 'มีคำค้นหลัก: ' . $focus : 'ยังไม่ได้ตั้งคำค้นหลัก (คำที่อยากให้คนค้นเจอ)'];
    if ($focus !== '') {
        $c[] = [mb_strpos(mb_strtolower($title), $focus) !== false, 'คำค้นหลักอยู่ในหัวเรื่อง'];
        $c[] = [mb_strpos(mb_strtolower($desc), $focus) !== false, 'คำค้นหลักอยู่ในคำอธิบาย'];
        $c[] = [mb_strpos(mb_strtolower(mb_substr($text, 0, 400)), $focus) !== false, 'คำค้นหลักอยู่ในย่อหน้าแรก'];
    }
    $len = mb_strlen($text);
    $c[] = [$len >= 600, sprintf('เนื้อหา %s ตัวอักษร (แนะนำอย่างน้อย 600)', number_format_i18n($len))];
    $c[] = [(bool) preg_match('/<h[23]\b/i', $html), 'มีหัวข้อย่อย (H2/H3) แบ่งเนื้อหา'];
    preg_match_all('/<img\b[^>]*>/i', $html, $imgs);
    $noalt = 0;
    foreach ($imgs[0] as $i) if (!preg_match('/\balt\s*=\s*"[^"]+"/i', $i) && !preg_match('/wp-image-\d+/', $i)) $noalt++;
    $c[] = [(bool) ($imgs[0] || has_post_thumbnail($post)), 'มีรูปภาพ (รูปหน้าปก / รูปในเนื้อหา)'];
    $c[] = [$noalt === 0, $noalt ? $noalt . ' รูปยังไม่มีคำอธิบายรูป (alt)' : 'รูปทุกรูปมีคำอธิบาย (alt)'];
    $c[] = [(bool) preg_match('#<a[^>]+href=["\'](' . preg_quote(home_url('/'), '#') . '|/)#i', $html), 'มีลิงก์ไปหน้าอื่นในเว็บ'];
    $c[] = [get_post_meta($post->ID, '_ihub_seo_noindex', true) !== '1', 'ให้ Google แสดงหน้านี้ (ไม่ได้ตั้ง noindex)'];
    $ok = count(array_filter($c, function ($x) { return $x[0]; }));
    return [(int) round($ok / max(1, count($c)) * 100), $c];
}

/* ---------- SEO box on pages and news ---------- */

add_action('add_meta_boxes', function () {
    if (!ihub_seo_on()) return;
    foreach (['post', 'page'] as $t) add_meta_box('ihub_seo', 'SEO — ให้ Google ค้นเจอ', 'ihub_seo_box', $t, 'normal', 'default');
});
function ihub_seo_box($post) {
    wp_nonce_field('ihub_seo', 'ihub_seo_nonce');
    $v = function ($k) use ($post) { return esc_attr((string) get_post_meta($post->ID, "_ihub_seo_{$k}", true)); };
    [$score, $checks] = ihub_seo_check($post);
    $color = $score >= 80 ? '#16a34a' : ($score >= 50 ? '#f59e0b' : '#dc2626');
    echo '<div class="ihub-seo"><div class="ihub-seo-grid"><div>';
    echo '<label>คำค้นหลัก (focus keyword)<input name="ihub_seo[focus]" value="' . $v('focus') . '" placeholder="เช่น ฉีดวัคซีนไข้หวัดใหญ่ ใกล้ฉัน"></label>';
    echo '<label>หัวเรื่องบน Google (เว้นว่าง = ใช้ชื่อหน้า)<input name="ihub_seo[title]" value="' . $v('title') . '" maxlength="80" data-c="65"></label>';
    echo '<label>คำอธิบายบน Google (เว้นว่าง = ระบบเขียนให้จากเนื้อหา)<textarea name="ihub_seo[desc]" rows="3" maxlength="300" data-c="160">' . esc_textarea((string) get_post_meta($post->ID, '_ihub_seo_desc', true)) . '</textarea></label>';
    echo '<details><summary>ภาษาอังกฤษ / รูปแชร์ / ตั้งค่าเพิ่ม</summary><label>Title (English)<input name="ihub_seo[title_en]" value="' . $v('title_en') . '"></label><label>Description (English)<textarea name="ihub_seo[desc_en]" rows="2">' . esc_textarea((string) get_post_meta($post->ID, '_ihub_seo_desc_en', true)) . '</textarea></label>';
    echo '<label>รูปตอนแชร์ (ID รูป — เว้นว่าง = รูปหน้าปก)<input name="ihub_seo[image]" value="' . $v('image') . '" inputmode="numeric"></label><label class="chk"><input type="checkbox" name="ihub_seo[noindex]" value="1"' . checked($v('noindex'), '1', false) . '> ไม่ให้ Google แสดงหน้านี้ (noindex)</label></details>';
    echo '<p><button type="button" class="button" id="ihub-seo-fill">เติมข้อมูลอัตโนมัติ</button> <small>เติมเฉพาะช่องที่ว่าง: คำอธิบาย คำค้นหลัก และคำอธิบายรูป</small></p>';
    echo '</div><div><div class="ihub-seo-preview"><small>' . esc_html(wp_parse_url(home_url(), PHP_URL_HOST)) . ' › ' . esc_html(urldecode($post->post_name)) . '</small><b id="ihub-seo-pt">' . esc_html(ihub_seo_meta($post->ID, 'title', 'raw') ?: $post->post_title) . '</b><span id="ihub-seo-pd">' . esc_html(ihub_seo_description($post)) . '</span></div>';
    echo '<div class="ihub-seo-score" style="--c:' . esc_attr($color) . '"><b>' . (int) $score . '</b><span>คะแนน SEO</span></div><ul class="ihub-seo-checks">';
    foreach ($checks as [$ok, $text]) echo '<li class="' . ($ok ? 'ok' : 'no') . '">' . ($ok ? '✓' : '✗') . ' ' . esc_html($text) . '</li>';
    echo '</ul><p class="description">คะแนนอัปเดตเมื่อบันทึก</p></div></div></div>';
    echo '<style>.ihub-seo-grid{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(0,1fr);gap:18px}@media(max-width:900px){.ihub-seo-grid{grid-template-columns:1fr}}.ihub-seo label{display:flex;flex-direction:column;gap:4px;font-weight:600;margin:0 0 10px}.ihub-seo label.chk{flex-direction:row;align-items:center}.ihub-seo input:not([type=checkbox]),.ihub-seo textarea{width:100%;font-weight:400}.ihub-seo details{margin:4px 0 10px}.ihub-seo summary{cursor:pointer;color:#2271b1}
.ihub-seo-preview{border:1px solid #e2e6ea;border-radius:12px;padding:12px 14px;background:#fff;font-family:arial,sans-serif;margin-bottom:12px}.ihub-seo-preview small{color:#4d5156;font-size:12px}.ihub-seo-preview b{display:block;color:#1a0dab;font-size:18px;font-weight:400;margin:3px 0;line-height:1.3}.ihub-seo-preview span{color:#4d5156;font-size:13px;line-height:1.5}
.ihub-seo-score{display:flex;align-items:center;gap:10px;margin-bottom:6px}.ihub-seo-score b{width:48px;height:48px;border-radius:50%;border:4px solid var(--c);display:grid;place-items:center;font-size:16px;color:var(--c)}.ihub-seo-checks{margin:0}.ihub-seo-checks li{margin:3px 0}.ihub-seo-checks .ok{color:#15803d}.ihub-seo-checks .no{color:#b91c1c}.ihub-seo [data-cnt]{font-weight:400;color:#64748b}</style>';
    $desc_auto = ihub_seo_cut($post->post_excerpt !== '' ? wp_strip_all_tags($post->post_excerpt) : ihub_seo_text($post));
    echo '<script>(function(){var t=document.querySelector("[name=\'ihub_seo[title]\']"),d=document.querySelector("[name=\'ihub_seo[desc]\']"),f=document.querySelector("[name=\'ihub_seo[focus]\']"),pt=document.getElementById("ihub-seo-pt"),pd=document.getElementById("ihub-seo-pd");var auto=' . wp_json_encode($desc_auto) . ',tit=' . wp_json_encode($post->post_title) . ';function cnt(el){var s=el.closest("label");var c=s.querySelector("[data-cnt]");if(!c){c=document.createElement("span");c.setAttribute("data-cnt","");s.firstChild.after(c)}c.textContent=" ("+el.value.length+"/"+el.dataset.c+")"}[t,d].forEach(function(el){el.addEventListener("input",function(){cnt(el);pt.textContent=t.value||tit;pd.textContent=d.value||auto});cnt(el)});document.getElementById("ihub-seo-fill").addEventListener("click",function(){if(!d.value)d.value=auto;if(!f.value)f.value=(tit.split(/\\s*[|:–—\\-()]\\s*/)[0]||"").slice(0,40);d.dispatchEvent(new Event("input"));})})();</script>';
}
add_action('save_post', function ($id) {
    if (!isset($_POST['ihub_seo_nonce']) || !wp_verify_nonce(sanitize_key($_POST['ihub_seo_nonce']), 'ihub_seo') || !current_user_can('edit_post', $id)) return;
    $in = wp_unslash($_POST['ihub_seo'] ?? []);
    foreach (['focus', 'title', 'title_en'] as $k) update_post_meta($id, "_ihub_seo_{$k}", sanitize_text_field($in[$k] ?? ''));
    foreach (['desc', 'desc_en'] as $k) update_post_meta($id, "_ihub_seo_{$k}", sanitize_textarea_field($in[$k] ?? ''));
    update_post_meta($id, '_ihub_seo_image', (string) absint($in['image'] ?? 0) ?: '');
    if (!empty($in['noindex'])) update_post_meta($id, '_ihub_seo_noindex', '1'); else delete_post_meta($id, '_ihub_seo_noindex');
}, 20);

/* ---------- SEO page: whole site ---------- */

add_action('admin_menu', function () { add_submenu_page('idevapp-hub', 'SEO', 'SEO', 'manage_options', 'ihub-seo', 'ihub_seo_page'); }, 21);
add_action('admin_post_ihub_seo_fill_all', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('ihub_seo_fill_all')) wp_die('ไม่มีสิทธิ์', 403);
    $n = 0;
    foreach (get_posts(['post_type' => ['post', 'page'], 'post_status' => 'publish', 'numberposts' => 500, 'fields' => 'ids']) as $id) if (ihub_seo_autofill($id)) $n++;
    wp_safe_redirect(admin_url('admin.php?page=ihub-seo&filled=' . $n));
    exit;
});
function ihub_seo_page() {
    if (!current_user_can('manage_options')) wp_die('ไม่มีสิทธิ์');
    echo '<div class="wrap"><h1>SEO — ให้ Google ค้นเจอ</h1>';
    if (ihub_seo_other_plugin()) { echo '<div class="notice notice-info"><p>พบปลั๊กอิน SEO อื่นทำงานอยู่ ระบบ SEO ของ iDevApp จึงปิดตัวเองเพื่อไม่ให้ซ้ำกัน</p></div></div>'; return; }
    if (isset($_GET['filled'])) echo '<div class="notice notice-success"><p>เติมข้อมูลอัตโนมัติแล้ว ' . (int) $_GET['filled'] . ' หน้า</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $posts = get_posts(['post_type' => ['page', 'post'], 'post_status' => 'publish', 'numberposts' => 300, 'orderby' => 'modified']);
    $rows = [];
    $sum = 0;
    foreach ($posts as $p) { [$score, $checks] = ihub_seo_check($p); $sum += $score; $rows[] = [$p, $score, $checks]; }
    usort($rows, function ($a, $b) { return $a[1] <=> $b[1]; });
    $avg = $rows ? (int) round($sum / count($rows)) : 0;
    $ready = [
        [get_option('blog_public') === '1', 'เปิดให้เครื่องมือค้นหาเข้าถึงเว็บ (ตั้งค่า → การอ่าน)'],
        [(bool) get_option('permalink_structure'), 'ลิงก์อ่านง่าย (Permalinks) เปิดอยู่'],
        [is_ssl() || strpos(home_url(), 'https://') === 0, 'เว็บใช้ HTTPS'],
        [ihub_setting('seo_google') !== '', 'ยืนยันเว็บกับ Google Search Console แล้ว (ใส่รหัสในตั้งค่า)'],
        [ihub_setting('seo_home_desc') !== '', 'มีคำอธิบายหน้าแรก'],
        [(bool) get_theme_mod('custom_logo') || ihub_setting('seo_image') !== '' || function_exists('idevapp_logo_url'), 'มีโลโก้ / รูปแชร์หลัก'],
        [ihub_setting('seo_geo') !== '', 'มีพิกัด (ช่วยให้ขึ้นใน Google Maps / ค้นหาใกล้ฉัน)'],
        [ihub_setting('phone') !== '' && ihub_setting('address') !== '', 'มีที่อยู่และเบอร์โทร (ข้อมูลเดียวกับ Google Business Profile)'],
    ];
    echo '<div style="display:flex;gap:18px;flex-wrap:wrap;margin:12px 0"><div style="background:#fff;border:1px solid #dcdfe4;border-radius:14px;padding:16px 20px;min-width:220px"><div style="font-size:42px;line-height:1.1;font-weight:800;color:' . ($avg >= 80 ? '#16a34a' : ($avg >= 50 ? '#f59e0b' : '#dc2626')) . '">' . (int) $avg . '</div><div>คะแนนเฉลี่ย ' . count($rows) . ' หน้า</div></div>';
    echo '<div style="background:#fff;border:1px solid #dcdfe4;border-radius:14px;padding:12px 20px;flex:1;min-width:320px"><b>ความพร้อมของทั้งเว็บ</b><ul style="margin:6px 0 0">';
    foreach ($ready as [$ok, $t]) echo '<li style="color:' . ($ok ? '#15803d' : '#b91c1c') . '">' . ($ok ? '✓' : '✗') . ' ' . esc_html($t) . '</li>';
    echo '</ul></div></div>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:0 0 14px">' . wp_nonce_field('ihub_seo_fill_all', '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_seo_fill_all"><button class="button button-primary button-large"><span class="dashicons dashicons-admin-generic" style="margin:5px 4px 0 0"></span>เติมข้อมูล SEO อัตโนมัติทั้งเว็บ</button> <span class="description">เติมเฉพาะส่วนที่ว่าง (คำอธิบาย คำค้นหลัก คำอธิบายรูป) ไม่เขียนทับที่กรอกไว้</span></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<p>ตั้งค่า SEO ของทั้งเว็บ (ประเภทหน่วยงาน หน้าแรก พิกัด โซเชียล รหัส Search Console): <a href="' . esc_url(admin_url('admin.php?page=idevapp-hub')) . '">ศูนย์บริการ → ตั้งค่าเว็บไซต์ → SEO</a> · แผนผังเว็บสำหรับ Google: <a href="' . esc_url(home_url('/wp-sitemap.xml')) . '" target="_blank">' . esc_html(home_url('/wp-sitemap.xml')) . '</a></p>';
    echo '<table class="widefat striped"><thead><tr><th style="width:70px">คะแนน</th><th>หน้า</th><th>สิ่งที่ควรแก้</th></tr></thead><tbody>';
    foreach ($rows as [$p, $score, $checks]) {
        $todo = array_filter($checks, function ($c) { return !$c[0]; });
        echo '<tr><td><b style="color:' . ($score >= 80 ? '#16a34a' : ($score >= 50 ? '#d97706' : '#dc2626')) . '">' . (int) $score . '</b></td><td><a href="' . esc_url(get_edit_post_link($p->ID)) . '">' . esc_html($p->post_title ?: '(ไม่มีชื่อ)') . '</a><br><small>' . esc_html($p->post_type === 'post' ? 'ข่าว' : 'หน้าเว็บ') . '</small></td><td>' . ($todo ? esc_html(implode(' · ', array_column($todo, 1))) : '✓ ครบ') . '</td></tr>';
    }
    echo '</tbody></table></div>';
}
