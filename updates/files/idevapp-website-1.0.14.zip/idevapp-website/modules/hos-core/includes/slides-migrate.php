<?php
/**
 * ย้ายสไลด์ชุดเดิมมาที่ “สไลด์หน้าแรก” (hos_slide)
 * เว็บที่เคยใช้ธีม / ปลั๊กอินอื่นมีสไลด์เป็นชนิดโพสต์ของตัวเอง (เมนูชื่อ “สไลด์…” ซ้ำกับของเรา)
 * → คัดลอกรูป ชื่อ ข้อความ ลิงก์ ลำดับ และสถานะ มาเป็นสไลด์ใหม่ ย้ายของเดิมไปถังขยะ (กู้คืนได้) และซ่อนเมนูเดิม
 */
defined( 'ABSPATH' ) || exit;

/** ชนิดโพสต์สไลด์อื่นที่มีในเว็บ: [type => [ชื่อ, จำนวน]] */
function hos_slides_foreign() {
	$out = array();
	foreach ( get_post_types( array(), 'objects' ) as $name => $pt ) {
		if ( 'hos_slide' === $name || in_array( $name, array( 'attachment', 'revision', 'nav_menu_item', 'wp_block', 'wp_template', 'wp_template_part', 'wp_navigation', 'wp_global_styles', 'wp_font_family', 'wp_font_face', 'idev_popup' ), true ) ) {
			continue;
		}
		$label = (string) ( $pt->labels->name ?? $pt->label );
		if ( ! preg_match( '/slide|slider|banner|carousel|สไลด์|แบนเนอร์/iu', $name . ' ' . $label ) ) {
			continue;
		}
		$n = 0;
		foreach ( (array) wp_count_posts( $name ) as $st => $c ) {
			$n += in_array( $st, array( 'trash', 'auto-draft', 'inherit' ), true ) ? 0 : (int) $c;
		}
		if ( $n ) {
			$out[ $name ] = array( $label, $n );
		}
	}
	return $out;
}

/** ลิงก์ของสไลด์เดิม (ชื่อ meta ที่ธีม / ปลั๊กอินต่าง ๆ ใช้) */
function hos_slides_old_link( $id ) {
	foreach ( array( '_hos_slide_link', '_slide_link', 'slide_link', '_link', 'link', '_url', 'url', 'slide_url', 'banner_link', '_banner_link', 'button_link' ) as $k ) {
		$v = trim( (string) get_post_meta( $id, $k, true ) );
		if ( $v && preg_match( '#^(https?://|/)#', $v ) ) {
			return esc_url_raw( $v );
		}
	}
	return '';
}

/** รูปของสไลด์เดิม: ภาพเด่น · meta ที่เป็นรหัสรูป / ลิงก์รูป · รูปแรกในเนื้อหา */
function hos_slides_old_image( $p ) {
	$img = (int) get_post_thumbnail_id( $p );
	if ( $img ) {
		return array( $img, '' );
	}
	foreach ( (array) get_post_meta( $p->ID ) as $k => $vals ) {
		$v = is_array( $vals ) ? (string) reset( $vals ) : '';
		if ( '' === $v || '_edit_lock' === $k ) {
			continue;
		}
		if ( ctype_digit( $v ) && 'attachment' === get_post_type( (int) $v ) && wp_attachment_is_image( (int) $v ) ) {
			return array( (int) $v, '' );
		}
		if ( preg_match( '#^https?://\S+\.(jpe?g|png|gif|webp)(\?\S*)?$#i', $v ) ) {
			$aid = attachment_url_to_postid( $v );
			return array( $aid, $aid ? '' : $v );
		}
	}
	if ( preg_match( '/<img[^>]+src=["\']([^"\']+)/i', (string) $p->post_content, $m ) ) {
		$aid = attachment_url_to_postid( $m[1] );
		return array( $aid, $aid ? '' : esc_url_raw( $m[1] ) );
	}
	$kids = get_children( array( 'post_parent' => $p->ID, 'post_type' => 'attachment', 'post_mime_type' => 'image', 'numberposts' => 1 ) );
	return $kids ? array( (int) key( $kids ), '' ) : array( 0, '' );
}

/** ย้ายทั้งชนิด · คืน [ย้ายแล้ว, ข้าม (ไม่มีรูป)] */
function hos_slides_migrate( $type ) {
	$moved = 0;
	$skip  = 0;
	$order = (int) count( get_posts( array( 'post_type' => 'hos_slide', 'post_status' => 'any', 'numberposts' => 500, 'fields' => 'ids' ) ) );
	$posts = get_posts( array( 'post_type' => $type, 'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ), 'numberposts' => 500, 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'DESC' ) ) );
	foreach ( $posts as $p ) {
		$done = get_posts( array( 'post_type' => 'hos_slide', 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => '_hos_slide_src', 'meta_value' => $type . ':' . $p->ID ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		if ( $done ) {
			continue;
		}
		list( $img, $url ) = hos_slides_old_image( $p );
		if ( ! $img && ! $url ) {
			$skip++; // no picture, nothing to show: to the trash with the rest (recoverable)
			wp_trash_post( $p->ID );
			continue;
		}
		$title = trim( wp_strip_all_tags( $p->post_title ) );
		if ( preg_match( '/^[\w\-().]+$/', $title ) && ( preg_match( '/\d/', $title ) || preg_match( '/^(img|image|dsc|photo|print|screenshot|banner|slide|untitled)\b/i', $title ) ) ) {
			$title = ''; // a file name, not a heading
		}
		$id = wp_insert_post( wp_slash( array(
			'post_type'    => 'hos_slide',
			'post_title'   => $title,
			'post_excerpt' => wp_strip_all_tags( $p->post_excerpt ),
			'post_status'  => 'publish' === $p->post_status ? 'publish' : 'draft',
			'menu_order'   => $order + (int) $p->menu_order,
			'post_date'    => $p->post_date,
		) ) );
		if ( ! $id || is_wp_error( $id ) ) {
			continue;
		}
		if ( $img ) {
			set_post_thumbnail( $id, $img );
		} else {
			update_post_meta( $id, '_hos_slide_image', $url );
		}
		$link = hos_slides_old_link( $p->ID );
		if ( $link ) {
			update_post_meta( $id, '_hos_slide_link', $link );
		}
		update_post_meta( $id, '_hos_slide_src', $type . ':' . $p->ID ); // where it came from (not _hos_slide_from: that is the start date)
		wp_trash_post( $p->ID ); // recoverable from the trash
		$moved++;
	}
	$hidden          = (array) get_option( 'hos_slides_hidden_types', array() );
	$hidden[ $type ] = 1;
	update_option( 'hos_slides_hidden_types', $hidden );
	do_action( 'litespeed_purge_all' );
	return array( $moved, $skip );
}

/* the old slide list is hidden once its slides are here */
add_filter( 'register_post_type_args', function ( $args, $type ) {
	$hidden = (array) get_option( 'hos_slides_hidden_types', array() );
	if ( isset( $hidden[ $type ] ) ) {
		$args['show_in_menu']      = false;
		$args['show_in_admin_bar'] = false;
	}
	return $args;
}, 20, 2 );
add_action( 'admin_menu', function () {
	foreach ( array_keys( (array) get_option( 'hos_slides_hidden_types', array() ) ) as $t ) {
		remove_menu_page( 'edit.php?post_type=' . $t );
	}
}, 999 );
add_action( 'load-edit.php', function () {
	$t = sanitize_key( $_GET['post_type'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( $t && isset( ( (array) get_option( 'hos_slides_hidden_types', array() ) )[ $t ] ) && 'trash' !== ( $_GET['post_status'] ?? '' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		wp_safe_redirect( admin_url( 'admin.php?page=hos-slides' ) );
		exit;
	}
} );

add_action( 'admin_post_hos_slides_migrate', function () {
	if ( ! current_user_can( 'edit_posts' ) || ! check_admin_referer( 'hos_slides_migrate' ) ) {
		wp_die( 'ไม่มีสิทธิ์', 403 );
	}
	$type = sanitize_key( $_POST['type'] ?? '' );
	if ( ! isset( hos_slides_foreign()[ $type ] ) ) {
		wp_safe_redirect( admin_url( 'admin.php?page=hos-slides' ) );
		exit;
	}
	list( $m, $s ) = hos_slides_migrate( $type );
	wp_safe_redirect( admin_url( 'admin.php?page=hos-slides&migrated=' . $m . '&skipped=' . $s ) );
	exit;
} );

/** กล่องบนหน้า “สไลด์หน้าแรก” */
function hos_slides_migrate_box() {
	if ( isset( $_GET['migrated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$m = (int) $_GET['migrated']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$s = (int) ( $_GET['skipped'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		echo '<div class="idw-note">ย้ายสไลด์ชุดเดิมมาแล้ว ' . (int) $m . ' รายการ — สไลด์ที่เคยเป็นฉบับร่างอยู่ในสถานะ “ปิด” เปิดเฉพาะรูปที่ต้องการแล้วกดบันทึก · ของเดิมอยู่ในถังขยะ (กู้คืนได้) และเมนูเดิมถูกซ่อนแล้ว' . ( $s ? ' · ' . (int) $s . ' รายการที่ไม่มีรูปถูกย้ายไปถังขยะด้วย' : '' ) . '</div>';
	}
	foreach ( hos_slides_foreign() as $type => $info ) {
		$hidden = (array) get_option( 'hos_slides_hidden_types', array() );
		if ( isset( $hidden[ $type ] ) && ! isset( $_GET['migrated'] ) && $info[1] < 1 ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			continue;
		}
		echo '<form class="idw-card hs-migrate" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'hos_slides_migrate' );
		echo '<input type="hidden" name="action" value="hos_slides_migrate"><input type="hidden" name="type" value="' . esc_attr( $type ) . '">';
		echo '<span class="dashicons dashicons-migrate"></span><div><b>พบสไลด์ชุดเดิม “' . esc_html( $info[0] ) . '” ' . (int) $info[1] . ' รายการ</b><span>ย้ายมาไว้ที่นี่ทั้งหมด (รูป ชื่อ ข้อความ ลิงก์ ลำดับ) — ที่เผยแพร่อยู่จะแสดงต่อ ฉบับร่างจะถูกปิดไว้ · ของเดิมไปอยู่ในถังขยะ กู้คืนได้ และเมนูเดิมจะหายไป</span></div>';
		echo '<button class="idw-btn pri">ย้ายมาที่นี่</button></form>';
	}
}

/*
 * After moving: a theme that still reads its own slide type (e.g. an older hospital theme) gets the slides of
 * “สไลด์หน้าแรก” instead — the same pictures, order, links and rules (dates, age) as the slides page shows.
 * Nothing is named here: the old type comes from the moving record (option hos_slides_hidden_types).
 */
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() && ! wp_doing_ajax() ) {
		return;
	}
	$types  = array_keys( (array) get_option( 'hos_slides_hidden_types', array() ) );
	$wanted = (array) $q->get( 'post_type' );
	if ( ! $types || count( $wanted ) !== 1 || ! in_array( (string) reset( $wanted ), $types, true ) ) {
		return;
	}
	$ids = array();
	foreach ( hos_get_slides() as $s ) {
		$ids[] = (int) $s['id'];
	}
	$q->set( 'post_type', 'hos_slide' );
	$q->set( 'post_status', 'publish' );
	$q->set( 'post__in', $ids ? $ids : array( 0 ) );
	$q->set( 'orderby', 'post__in' );
} );
/* the old theme asks for its own meta names (…_slide_link / …_slide_image): answer with ours */
add_filter( 'get_post_metadata', function ( $value, $id, $key, $single ) {
	if ( ! preg_match( '/^_(\w+)_slide_(link|image)$/', (string) $key, $m ) || 'hos' === $m[1] || 'hos_slide' !== get_post_type( $id ) ) {
		return $value;
	}
	$v = get_post_meta( $id, '_hos_slide_' . $m[2], true );
	return $single ? $v : array( $v );
}, 10, 4 );
/* and its own picture-age setting is switched off: the age is checked from the day a slide went up */
add_action( 'after_setup_theme', function () {
	foreach ( array_keys( (array) get_option( 'hos_slides_hidden_types', array() ) ) as $t ) {
		if ( preg_match( '/^(\w+)_slide$/', $t, $m ) && 'hos' !== $m[1] ) {
			add_filter( 'theme_mod_' . $m[1] . '_slide_months', '__return_zero' );
		}
	}
} );
