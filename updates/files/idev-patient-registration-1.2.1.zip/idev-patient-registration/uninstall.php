<?php
/**
 * Patient registrations are medical records: they are NOT deleted when the plugin is removed.
 * The table wp_idev_medreg, the settings and the key file stay so the data can still be read later.
 * To remove everything, delete the table and the options idev_medreg_* by hand after exporting what you need.
 */
defined('WP_UNINSTALL_PLUGIN') || exit;
wp_clear_scheduled_hook('idev_medreg_cleanup');
