<?php
/**
 * Plugin Name:       I-Clinic
 * Plugin URI:        https://idevapp.me/#systems
 * Description:       Clinic system by iDevApp: online patient registration with ID card / passport and patient cards, online appointments with LINE / WhatsApp / SMS reminders, doctors' schedule, dispensing, stock by lot and expiry, receipts and PromptPay.
 * Version:           1.0.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-package
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// One iDevApp package at a time: activating this one switches the other packages off.
register_activation_hook(__FILE__, function () {
    if (!function_exists('deactivate_plugins')) require_once ABSPATH . 'wp-admin/includes/plugin.php';
    foreach (['i-clinic', 'i-clinic-pro', 'i-drug'] as $p) if ($p !== 'i-clinic' && is_plugin_active($p . '/' . $p . '.php')) deactivate_plugins($p . '/' . $p . '.php', true);
});
if (defined('IDEV_PACKAGE')) return;

define('IDEV_PACKAGE', 'clinic');
define('IDEV_PACKAGE_SLUG', 'i-clinic');
define('IDEV_PACKAGE_NAME', 'I-Clinic');
define('IDEV_PACKAGE_VERSION', '1.0.0');
define('IDEV_PACKAGE_FILE', __FILE__);

require_once __DIR__ . '/common/idev-common.php';
foreach (['idev-thai-holidays', 'idev-clinic-schedule', 'idev-patient-registration', 'idev-patient-registration-pro', 'idev-appointments', 'idev-appointments-pro', 'idev-store'] as $idev_pkg_module) require_once __DIR__ . '/modules/' . $idev_pkg_module . '/' . $idev_pkg_module . '.php';
unset($idev_pkg_module);
require_once __DIR__ . '/includes/package.php';

add_action('init', function () { load_plugin_textdomain('idev-package', false, dirname(plugin_basename(__FILE__)) . '/languages'); }, 1);
register_activation_hook(__FILE__, function () { idev_pkg_install(); idev_pkg_takeover(); }); // runs when this package is the one loaded
