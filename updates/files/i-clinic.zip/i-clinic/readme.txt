=== I-Clinic ===
Contributors: idevapp
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Clinic system by iDevApp: online patient registration with ID card / passport and patient cards, online appointments with LINE / WhatsApp / SMS reminders, doctors' schedule, dispensing, stock by lot and expiry, receipts and PromptPay.

One plugin: install the zip from Plugins → Add New → Upload Plugin. A licence key from iDevApp removes "TRIAL" from printed documents.
