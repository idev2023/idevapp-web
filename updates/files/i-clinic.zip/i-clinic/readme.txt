=== I-Clinic ===
Contributors: idevapp
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.4.3
License: GPLv2 or later

Clinic system by iDevApp: examination room with queue, vital signs, doctor's notes, ICD-10 diagnosis, prescriptions, re-med, drug allergy alerts and patient history, online patient registration with ID card / passport and patient cards, online appointments with LINE / WhatsApp / SMS reminders, doctors' schedule, dispensing, stock by lot and expiry, receipts and PromptPay.

One plugin: install the zip from Plugins → Add New → Upload Plugin. A licence key from iDevApp removes "TRIAL" from printed documents.
