<?php
/**
 * บล็อกของธีม (แสดงตัวอย่างจริงในตัวแก้ไข) + ชุดบล็อกสำเร็จรูป (patterns)
 * hos/slider · hos/news · hos/doclist · hos/clinics · hos/map
 */
defined( 'ABSPATH' ) || exit;

add_action( 'after_setup_theme', function () {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( array( hosd_fonts_url(), 'assets/editor.css' ) );
}, 30 );

/**
 * ตัวแก้ไข: โหลด CSS หน้าเว็บจริงทั้งหมดเข้า iframe ของตัวแก้ไข (ธีม + บล็อก iDevApp Hub + iDev plugins)
 * เพื่อให้บล็อกทุกตัวแสดงหน้าตาเหมือนหน้าเว็บ
 */
add_action( 'enqueue_block_assets', function () {
	if ( ! is_admin() ) {
		return;
	}
	$u = get_template_directory_uri() . '/assets/';
	wp_enqueue_style( 'hos-ed-hub', $u . 'hub-compat.css', array(), hos_asset_ver( 'hub-compat.css' ) );
	wp_enqueue_style( 'hos-ed-theme', $u . 'theme.css', array( 'hos-ed-hub' ), hos_asset_ver( 'theme.css' ) );
	wp_enqueue_style( 'hos-ed-fix', $u . 'editor.css', array( 'hos-ed-theme' ), hos_asset_ver( 'editor.css' ) );
	if ( wp_style_is( 'idev-clinic-schedule', 'registered' ) ) {
		wp_enqueue_style( 'idev-clinic-schedule' );
	}
	foreach ( glob( WP_PLUGIN_DIR . '/*/{assets/front.css,*/assets/front.css}', GLOB_BRACE ) ?: array() as $f ) {
		$rel = str_replace( '\\', '/', substr( $f, strlen( WP_PLUGIN_DIR ) + 1 ) );
		if ( preg_match( '#^idev-(post-attachments|clinic-schedule)#', $rel ) ) {
			wp_enqueue_style( 'hos-ed-' . md5( $rel ), plugins_url( $rel ), array(), HOS_THEME_VER );
		}
	}
} );

add_action( 'init', function () {
	wp_register_script( 'hos-blocks', get_template_directory_uri() . '/assets/blocks.js', array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render', 'wp-i18n' ), hos_asset_ver( 'blocks.js' ), true );
	$sources = array( 'all' => 'ทุกหมวด (แท็บ)', 'news' => 'ข่าวประชาสัมพันธ์', 'procurement' => 'ประกาศประกวดราคาและจัดซื้อจัดจ้าง', 'bidding' => '— ข่าวประกวดราคา', 'results' => '— สรุปผลดำเนินการจัดซื้อจัดจ้าง', 'midprice' => '— ประกาศราคากลาง', 'jobs' => 'ข่าวรับสมัครงาน', 'others' => 'ข่าวอื่น ๆ', 'downloads' => 'ดาวน์โหลดเอกสาร', 'forms' => 'แบบฟอร์ม', 'ita' => 'ITA', 'schedule' => 'ไฟล์ตารางแพทย์' );
	wp_localize_script( 'hos-blocks', 'HOS_BLOCKS', array( 'sources' => $sources ) );

	$common = array( 'api_version' => 3, 'editor_script' => 'hos-blocks', 'category' => 'hos' );
	register_block_type( 'hos/slider', $common + array(
		'title' => 'สไลด์ภาพ (จากเมนู สไลด์หน้าแรก)',
		'attributes' => array( 'max' => array( 'type' => 'number', 'default' => 12 ) ),
		'render_callback' => 'hos_block_slider',
	) );
	register_block_type( 'hos/news', $common + array(
		'title' => 'ข่าว/ประกาศ (การ์ด)',
		'attributes' => array( 'source' => array( 'type' => 'string', 'default' => 'all' ), 'count' => array( 'type' => 'number', 'default' => 6 ), 'more' => array( 'type' => 'boolean', 'default' => true ) ),
		'render_callback' => 'hos_block_news',
	) );
	register_block_type( 'hos/doclist', $common + array(
		'title' => 'รายการเอกสาร/ประกาศ (แบบรายการ)',
		'attributes' => array( 'source' => array( 'type' => 'string', 'default' => 'procurement' ), 'count' => array( 'type' => 'number', 'default' => 10 ) ),
		'render_callback' => 'hos_block_doclist',
	) );
	register_block_type( 'hos/clinics', $common + array(
		'title' => 'ตารางออกตรวจ (ค้นหาคลินิก)',
		'attributes' => array(),
		'render_callback' => function () { return function_exists( 'hos_clinic_directory' ) ? hos_clinic_directory() : ''; },
	) );
	register_block_type( 'hos/map', $common + array(
		'title' => 'แผนที่ Google',
		'attributes' => array( 'query' => array( 'type' => 'string', 'default' => '' ), 'height' => array( 'type' => 'number', 'default' => 400 ), 'view' => array( 'type' => 'string', 'default' => 'both' ) ),
		'render_callback' => 'hos_block_map',
	) );
} );

add_filter( 'block_categories_all', function ( $cats ) {
	array_unshift( $cats, array( 'slug' => 'hos', 'title' => 'โรงพยาบาล' ) );
	return $cats;
} );

function hos_block_slider( $a ) {
	$slides = array_values( array_filter( hos_get_slides(), 'hos_slide_image_ok' ) );
	$slides = array_slice( $slides, 0, max( 1, (int) $a['max'] ) );
	if ( ! $slides ) {
		return '<div class="hos-carousel empty"><img class="logo-ph" src="' . esc_url( get_template_directory_uri() . '/assets/logo.png' ) . '" alt=""><p class="hos-ph-note">เพิ่มภาพได้ที่เมนู “สไลด์หน้าแรก”</p></div>';
	}
	$h = '<div class="hos-carousel" data-hos-carousel>';
	foreach ( $slides as $i => $s ) {
		$img  = hos_best_image_url( $s['image'] );
		$tag  = $s['link'] ? 'a' : 'div';
		$href = $s['link'] ? ' href="' . esc_url( $s['link'] ) . '"' : '';
		$h   .= sprintf( '<%1$s class="hos-cslide%2$s"%3$s style="--bg:url(\'%4$s\')"><img src="%4$s" alt="%5$s" %6$s></%1$s>', $tag, 0 === $i ? ' on' : '', $href, esc_url( $img ), esc_attr( $s['title'] ), 0 === $i ? '' : 'loading="lazy"' );
	}
	if ( count( $slides ) > 1 ) {
		$h .= '<button type="button" class="hos-cnav prev" aria-label="ก่อนหน้า">‹</button><button type="button" class="hos-cnav next" aria-label="ถัดไป">›</button><div class="hos-cdots">';
		foreach ( $slides as $i => $s ) {
			$h .= '<button type="button" class="' . ( 0 === $i ? 'on' : '' ) . '" aria-label="สไลด์ ' . ( $i + 1 ) . '"></button>';
		}
		$h .= '</div>';
	}
	return $h . '</div>';
}

function hos_block_news( $a ) {
	$count = max( 1, min( 24, (int) $a['count'] ) );
	ob_start();
	if ( 'all' === $a['source'] ) {
		hos_news_tabs( $count );
	} else {
		$posts = hos_source_posts( $a['source'], $count );
		$posts ? hos_news_cards( $posts ) : print( '<div class="hos-empty">ยังไม่มีรายการ</div>' );
		if ( ! empty( $a['more'] ) ) {
			echo '<p class="news-panel-more"><a class="text-link" href="' . esc_url( hos_source_url( $a['source'] ) ) . '">ดูทั้งหมด <span>→</span></a></p>';
		}
	}
	return '<div class="hos-news-block">' . ob_get_clean() . '</div>';
}

function hos_block_doclist( $a ) {
	ob_start();
	hos_doc_list( hos_source_posts( $a['source'], max( 1, min( 50, (int) $a['count'] ) ), false ) ); // รายการย้อนหลัง: ไม่ซ่อนตามอายุ
	echo '<p class="news-panel-more"><a class="text-link" href="' . esc_url( hos_source_url( $a['source'] ) ) . '">ดูทั้งหมด <span>→</span></a></p>';
	return '<div class="hos-doclist-block">' . ob_get_clean() . '</div>';
}

function hos_block_map( $a ) {
	$q    = ! empty( $a['query'] ) ? $a['query'] : hos_mod( 'hos_map_query' );
	$h    = (int) ( isset( $a['height'] ) ? $a['height'] : 400 );
	$view = isset( $a['view'] ) ? $a['view'] : 'both';
	$src  = function ( $type, $z ) use ( $q ) {
		return 'https://maps.google.com/maps?q=' . rawurlencode( $q ) . '&t=' . $type . '&z=' . $z . '&hl=th&output=embed';
	};
	$frame = function ( $type, $z, $hidden ) use ( $src, $h ) {
		return '<iframe data-map="' . $type . '" title="แผนที่โรงพยาบาล" loading="lazy" style="height:' . $h . 'px"' . ( $hidden ? ' hidden' : '' ) . ' referrerpolicy="no-referrer-when-downgrade" src="' . esc_url( $src( $type, $z ) ) . '"></iframe>';
	};
	$nav = '<a class="hos-map-go" target="_blank" rel="noopener" href="' . esc_url( 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( $q ) ) . '">🧭 นำทางด้วย Google Maps</a>';
	if ( 'road' === $view || 'sat' === $view ) {
		return '<div class="hos-map">' . $frame( 'road' === $view ? 'm' : 'k', 'road' === $view ? 16 : 18, false ) . '<div class="hos-map-bar">' . $nav . '</div></div>';
	}
	return '<div class="hos-map" data-hos-map><div class="hos-map-bar"><div class="hos-map-tabs" role="tablist"><button type="button" class="on" data-show="k">🛰️ ภาพถ่ายดาวเทียม</button><button type="button" data-show="m">🗺️ แผนที่ถนน</button></div>' . $nav . '</div>'
		. $frame( 'k', 18, false ) . $frame( 'm', 16, true ) . '</div>';
}

/** แท็บข่าว (ไม่มีหัวข้อ — หัวข้อเป็นบล็อกหัวข้อที่แก้ได้เอง) */
function hos_news_tabs( $per_tab = 6 ) {
	hos_news_section( $per_tab, false );
}
