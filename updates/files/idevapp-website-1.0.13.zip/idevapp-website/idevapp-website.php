<?php
/**
 * Plugin Name:       iDevApp Website
 * Plugin URI:        https://idevapp.me/
 * Description:       ระบบเว็บไซต์ครบชุดในปลั๊กอินเดียว: ตัวช่วยตั้งค่าเว็บไซต์ ติดตั้งธีม (แบบที่ 1 / แบบที่ 2) ย้ายเว็บเดิม ตรวจความปลอดภัย (OWASP Top 10:2025 + CVE) ติดตั้ง SSL / HTTPS ประกาศข่าวพร้อมตั้งเวลาและอ่าน PDF สองภาษา คุกกี้ PDPA แผนที่ Popup ตารางออกตรวจ นัดหมาย ลงทะเบียนผู้ป่วย และระบบโรงพยาบาล — เปิด / ปิดแต่ละส่วนได้เอง
 * Version:           1.0.13
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idevapp-website
 * Update URI:        https://github.com/idev2023/idevapp-web
 */
defined('ABSPATH') || exit;
if (defined('IDW_VERSION')) return;

define('IDW_VERSION', '1.0.13');
define('IDW_FILE', __FILE__);
define('IDW_DIR', plugin_dir_path(__FILE__));
define('IDW_URL', plugin_dir_url(__FILE__));
define('IDW_BASENAME', plugin_basename(__FILE__));

require_once IDW_DIR . 'common/idev-common.php';
require_once IDW_DIR . 'includes/modules.php';
require_once IDW_DIR . 'includes/updater.php';
require_once IDW_DIR . 'includes/safe-update.php';
require_once IDW_DIR . 'includes/themes.php';
require_once IDW_DIR . 'includes/admin.php';
require_once IDW_DIR . 'includes/wizard.php';

idw_load_modules();

register_activation_hook(__FILE__, 'idw_activate');
register_deactivation_hook(__FILE__, 'idw_deactivate');
