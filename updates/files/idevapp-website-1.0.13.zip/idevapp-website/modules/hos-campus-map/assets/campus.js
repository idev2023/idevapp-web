/* ผังโรงพยาบาล 3 มิติ — ผังโรงพยาบาล 3 มิติ + นำทาง */
(function () {
/* ผังโรงพยาบาล 3 มิติ: ลากหมุน/เอียง, ซูม, เลื่อน, กดตึกดูบริการรายชั้น, ค้นหา */
document.querySelectorAll('[data-hos-campus]').forEach(function (box) {
  var stage = box.querySelector('[data-stage]'), world = box.querySelector('[data-world]'), ground = box.querySelector('.hos-campus-ground');
  var data = {}; try { data = JSON.parse(box.querySelector('.hos-campus-data').textContent); } catch (e) {}
  var W = +world.dataset.w || 960, H = +world.dataset.h || 794, st = { rx: 50, rz: -12, z: .92, px: 0, py: 0 }, DEF = { rx: 50, rz: -12, z: .92, px: 0, py: 0 };
  var info = box.querySelector('.hos-campus-info'), hint = info.querySelector('.hos-campus-hint'), res = info.querySelector('.hos-campus-results'), det = info.querySelector('.hos-campus-detail');
  var input = box.querySelector('input[type=search]'), cats = {}, sel = null, anim = null, compass = box.querySelector('[data-compass]');
  var marks = []; try { marks = JSON.parse(box.querySelector('.hos-campus-marks').textContent); } catch (e) {}
  var gmap = box.querySelector('.hos-campus-gmap'), rsvg = box.querySelector('.hos-route');
  if (compass) { var north = function () { tween({ rz: Math.round(st.rz / 360) * 360 }); }; compass.addEventListener('click', north); compass.addEventListener('keydown', function (e) { if (e.key === 'Enter') north(); }); }
  function fit() { return Math.min(stage.clientWidth / W, stage.clientHeight / H) * 1.05; }
  function draw() {
    st.rx = Math.max(0, Math.min(72, st.rx)); st.z = Math.max(.6, Math.min(4, st.z));
    world.style.transform = 'translate(-50%,-50%) scale(' + (fit() * st.z).toFixed(3) + ') rotateX(' + st.rx + 'deg) rotateZ(' + st.rz + 'deg) translate(' + st.px + 'px,' + st.py + 'px)';
    world.style.setProperty('--rx', st.rx + 'deg'); world.style.setProperty('--rz', st.rz + 'deg');
    world.style.setProperty('--ts', (1 / Math.max(.8, st.z * fit() * 1.4)).toFixed(3));
    if (compass) compass.style.transform = 'rotate(' + st.rz + 'deg)';
  }
  function tween(to) {
    var from = Object.assign({}, st), t0 = performance.now(); cancelAnimationFrame(anim);
    (function step(t) { var k = Math.min(1, (t - t0) / 450), e = 1 - Math.pow(1 - k, 3);
      Object.keys(to).forEach(function (key) { st[key] = from[key] + (to[key] - from[key]) * e; }); draw(); if (k < 1) anim = requestAnimationFrame(step); })(t0);
  }
  // ลาก / ถ่างนิ้ว
  var pts = {}, last = null, moved = 0, pinch = null;
  stage.addEventListener('pointerdown', function (e) { if (e.target.closest('.hos-campus-ctrl')) return; pts[e.pointerId] = { x: e.clientX, y: e.clientY }; last = { x: e.clientX, y: e.clientY, pan: e.button === 2 || e.shiftKey }; moved = 0; pinch = null; cancelAnimationFrame(anim); });
  stage.addEventListener('pointermove', function (e) {
    if (!pts[e.pointerId]) return; pts[e.pointerId] = { x: e.clientX, y: e.clientY };
    var ids = Object.keys(pts);
    if (ids.length >= 2) {
      var a = pts[ids[0]], b = pts[ids[1]], d = Math.hypot(a.x - b.x, a.y - b.y), m = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      if (pinch) { st.z *= d / pinch.d; pan(m.x - pinch.m.x, m.y - pinch.m.y); }
      pinch = { d: d, m: m }; moved += 10; draw(); return;
    }
    var dx = e.clientX - last.x, dy = e.clientY - last.y; moved += Math.abs(dx) + Math.abs(dy);
    if (moved > 6 && !stage.hasPointerCapture(e.pointerId)) { try { stage.setPointerCapture(e.pointerId); } catch (er) {} }
    if (last.pan) pan(dx, dy); else { st.rz += dx * .35; st.rx -= dy * .3; }
    last.x = e.clientX; last.y = e.clientY; draw();
  });
  function up(e) { delete pts[e.pointerId]; pinch = null; }
  stage.addEventListener('pointerup', up); stage.addEventListener('pointercancel', up);
  stage.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  stage.addEventListener('wheel', function (e) { e.preventDefault(); st.z *= e.deltaY < 0 ? 1.12 : 1 / 1.12; draw(); }, { passive: false });
  function pan(dx, dy) {
    var s = fit() * st.z, r = -st.rz * Math.PI / 180, c = Math.cos(st.rx * Math.PI / 180) || 1;
    var gx = dx / s, gy = dy / s / Math.max(.35, c);
    st.px += gx * Math.cos(r) - gy * Math.sin(r); st.py += gx * Math.sin(r) + gy * Math.cos(r);
    st.px = Math.max(-W / 2, Math.min(W / 2, st.px)); st.py = Math.max(-H / 2, Math.min(H / 2, st.py));
  }
  box.querySelector('.hos-campus-ctrl').addEventListener('click', function (e) {
    var b = e.target.closest('[data-act]'); if (!b) return; var a = b.dataset.act;
    if (a === 'in') tween({ z: st.z * 1.3 }); if (a === 'out') tween({ z: st.z / 1.3 });
    if (a === 'left') tween({ rz: st.rz - 45 }); if (a === 'right') tween({ rz: st.rz + 45 });
    if (a === 'top') tween({ rx: 0, rz: 0 }); if (a === 'reset') { tween(DEF); select(null); }
  });
  // พื้น
  box.querySelectorAll('[data-ground]').forEach(function (b) { b.addEventListener('click', function () {
    box.querySelectorAll('[data-ground]').forEach(function (x) { x.classList.toggle('on', x === b); }); ground.classList.toggle('is-sat', b.dataset.ground === 'sat'); }); });
  // หมวด
  box.querySelectorAll('.hos-campus-legend button').forEach(function (b) { b.addEventListener('click', function () {
    b.classList.toggle('off'); cats[b.dataset.cat] = b.classList.contains('off'); paint(); }); });
  function paint(match) {
    box.querySelectorAll('.cb').forEach(function (el) {
      var dim = cats[el.dataset.cat] || (match && !match[el.dataset.id]) || (sel && sel !== el.dataset.id && !match);
      el.classList.toggle('dim', !!dim); el.classList.toggle('on', sel === el.dataset.id || !!(match && match[el.dataset.id]));
    });
  }
  function esc(s) { var i = document.createElement('i'); i.textContent = s; return i.innerHTML; }
  function mark(t, q) { var i = q ? t.toLowerCase().indexOf(q) : -1; return i < 0 ? esc(t) : esc(t.slice(0, i)) + '<mark>' + esc(t.slice(i, i + q.length)) + '</mark>' + esc(t.slice(i + q.length)); }
  function select(id, q) {
    sel = id; q = q || '';
    if (!id) { det.hidden = true; hint.hidden = !!input.value; paint(); rto.textContent = 'แตะเลือกตึกบนแผนที่'; return; }
    var b = data[id], el = box.querySelector('.cb[data-id="' + id + '"]'); hint.hidden = true;
    det.innerHTML = '<span class="cat" style="--c:' + getComputedStyle(el).getPropertyValue('--c') + '">' + esc(b.catName) + '</span><h3>' + esc(b.name) + '</h3>'
      + (b.floors.length ? b.floors.slice().reverse().map(function (f) { return '<div class="flr"><b>' + esc(f[0]) + '</b><ul>' + f[1].map(function (x) { return '<li>' + mark(x, q) + '</li>'; }).join('') + '</ul></div>'; }).join('') : '<p class="muted">ยังไม่มีข้อมูลบริการในอาคารนี้</p>')
      + '<button type="button" class="hos-campus-close">✕ ปิด</button>';
    det.hidden = false; paint(); info.classList.remove('is-folded');
    rto.textContent = b.name;
    drawRoute(rfrom.value, id);
    if (window.innerWidth < 900) det.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
  det.addEventListener('click', function (e) {
    if (e.target.closest('.hos-campus-close')) { clearRoute(); select(null); tween({ px: 0, py: 0, z: DEF.z }); return; }
  });
  /* ---- นำทางภายในโรงพยาบาล: หาเส้นทางเดินบนตาราง หลบตัวอาคาร ---- */
  var rbar = box.querySelector('.hos-route-bar'), rfrom = rbar.querySelector('.hos-route-from'), rto = rbar.querySelector('.hos-route-to span'), rmsg = rbar.querySelector('.hos-route-msg');
  var geo = null; try { geo = JSON.parse(box.querySelector('.hos-campus-geo').textContent); } catch (e) {}
  var net = { doors: [], paths: [], qr: [] }; try { net = JSON.parse(box.querySelector('.hos-campus-net').textContent) || net; } catch (e) {}
  var wcBox = rbar.querySelector('.hos-route-wcbox'); if (wcBox) { if (!net.paths.length) wcBox.closest('label').hidden = true; wcBox.addEventListener('change', function () { graphs = {}; if (sel) drawRoute(rfrom.value, sel); }); }
  var qFrom = new URLSearchParams(location.search).get('from'), qIdx = -1;
  net.qr.forEach(function (q, i) { if (q.id === qFrom) qIdx = i; });
  rfrom.innerHTML = (qIdx > -1 ? '<option value="q' + qIdx + '" selected>📌 คุณอยู่ที่นี่: ' + esc(net.qr[qIdx].t) + '</option>' : '')
    + (geo && navigator.geolocation ? '<option value="gps">📍 ตำแหน่งของฉัน (GPS)</option>' : '')
    + net.qr.map(function (q, i) { return i === qIdx ? '' : '<option value="q' + i + '">📌 ' + esc(q.t) + '</option>'; }).join('')
    + marks.map(function (m, i) { return '<option value="m' + i + '"' + (i === 0 && qIdx < 0 ? ' selected' : '') + '>' + esc((m.ic ? m.ic + ' ' : '') + m.t) + '</option>'; }).join('')
    + Object.keys(data).map(function (k) { return '<option value="b' + k + '">🏢 ' + esc(data[k].name) + '</option>'; }).join('');
  rfrom.addEventListener('change', function () { if (rfrom.value !== 'gps') stopGps(); if (sel) drawRoute(rfrom.value, sel); else if (rfrom.value === 'gps') startGps(); });
  rbar.querySelector('.hos-campus-fold').addEventListener('click', function () { info.classList.toggle('is-folded'); });
  /* GPS → ตำแหน่งบนภาพ */
  var gpsPt = null, gpsWatch = null, me = rsvg && rsvg.querySelector('.me'), meR = rsvg && rsvg.querySelector('.me-ring');
  function toPx(lat, lng) { var a = geo[0], b = geo[1]; return [a[0] + (lng - a[3]) / (b[3] - a[3]) * (b[0] - a[0]), a[1] + (lat - a[2]) / (b[2] - a[2]) * (b[1] - a[1])]; }
  function say(t, gm) { rmsg.hidden = !t; rmsg.innerHTML = t + (gm && gmap ? ' <a target="_blank" rel="noopener" href="' + gmap.href + '">นำทางด้วย Google Maps →</a>' : ''); }
  function showMe(p) { if (!me) return; [me, meR].forEach(function (c) { c.setAttribute('cx', p[0]); c.setAttribute('cy', p[1]); }); rsvg.classList.add('has-me'); }
  function stopGps() { if (gpsWatch !== null) navigator.geolocation.clearWatch(gpsWatch); gpsWatch = null; gpsPt = null; if (rsvg) rsvg.classList.remove('has-me'); }
  function startGps() {
    if (gpsWatch !== null) return;
    say('กำลังหาตำแหน่งของคุณ… (กรุณาอนุญาตการเข้าถึงตำแหน่ง)');
    gpsWatch = navigator.geolocation.watchPosition(function (pos) {
      var p = toPx(pos.coords.latitude, pos.coords.longitude);
      if (p[0] < -120 || p[1] < -160 || p[0] > W + 120 || p[1] > H + 120) { gpsPt = null; rsvg.classList.remove('has-me'); clearRoute(); say('คุณอยู่นอกโรงพยาบาล', true); return; }
      var moved = !gpsPt || Math.hypot(p[0] - gpsPt[0], p[1] - gpsPt[1]) > 6; gpsPt = p; showMe(p);
      if (sel && moved) drawRoute('gps', sel, true); else if (!sel) say('พบตำแหน่งของคุณแล้ว (จุดสีฟ้า) · แตะเลือกตึกที่ต้องการไป');
    }, function (err) { stopGps(); say(err.code === 1 ? 'ไม่ได้รับอนุญาตให้ใช้ตำแหน่ง กรุณาเปิด GPS/อนุญาตตำแหน่งในเบราว์เซอร์ หรือเลือกจุดเริ่มต้นอื่น' : 'หาตำแหน่งไม่ได้ ลองอีกครั้งหรือเลือกจุดเริ่มต้นอื่น'); }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 20000 });
  }
  function rectOf(id) { var el = box.querySelector('.cb[data-id="' + id + '"]'); return el ? [el.offsetLeft, el.offsetTop, el.offsetWidth, el.offsetHeight] : null; }
  var CS = 8, GW = Math.ceil(W / CS), GH = Math.ceil(H / CS), grid = null;
  function buildGrid() {
    grid = new Uint8Array(GW * GH);
    box.querySelectorAll('.cb').forEach(function (el) {
      var x0 = Math.floor((el.offsetLeft - 3) / CS), y0 = Math.floor((el.offsetTop - 3) / CS), x1 = Math.floor((el.offsetLeft + el.offsetWidth + 3) / CS), y1 = Math.floor((el.offsetTop + el.offsetHeight + 3) / CS);
      for (var y = Math.max(0, y0); y <= Math.min(GH - 1, y1); y++) for (var x = Math.max(0, x0); x <= Math.min(GW - 1, x1); x++) grid[y * GW + x] = 1;
    });
  }
  function doorOf(id, toward) { // จุดหน้าอาคาร ด้านที่ใกล้จุดเริ่ม
    var r = rectOf(id), cx = r[0] + r[2] / 2, cy = r[1] + r[3] / 2, pts = [[cx, r[1] - 8], [cx, r[1] + r[3] + 8], [r[0] - 8, cy], [r[0] + r[2] + 8, cy]];
    var rec = net.doors.filter(function (d) { return d.b === id; });
    if (rec.length) { rec.sort(function (p, q) { return Math.hypot(p.x - toward[0], p.y - toward[1]) - Math.hypot(q.x - toward[0], q.y - toward[1]); }); return [rec[0].x, rec[0].y]; }
    var el = box.querySelector('.cb[data-id="' + id + '"]'), dr = el && el.dataset.door, gap = el && el.querySelector('.porch') ? 26 : 8;
    if (dr) return dr === 'n' ? [cx, r[1] - gap] : dr === 'e' ? [r[0] + r[2] + gap, cy] : dr === 'w' ? [r[0] - gap, cy] : [cx, r[1] + r[3] + gap];
    pts.sort(function (p, q) { return Math.hypot(p[0] - toward[0], p[1] - toward[1]) - Math.hypot(q[0] - toward[0], q[1] - toward[1]); });
    return pts[0];
  }
  function free(c) { var x = c[0], y = c[1]; if (x < 0 || y < 0 || x >= GW || y >= GH) return null; if (!grid[y * GW + x]) return c;
    for (var r = 1; r < 6; r++) for (var dy = -r; dy <= r; dy++) for (var dx = -r; dx <= r; dx++) { var X = x + dx, Y = y + dy; if (X >= 0 && Y >= 0 && X < GW && Y < GH && !grid[Y * GW + X]) return [X, Y]; } return null; }
  function astar(a, b) {
    var N = GW * GH, g = new Float32Array(N).fill(1e9), from = new Int32Array(N).fill(-1), open = [a[1] * GW + a[0]], closed = new Uint8Array(N), goal = b[1] * GW + b[0];
    g[open[0]] = 0;
    var h = function (i) { return Math.hypot(i % GW - b[0], (i / GW | 0) - b[1]); };
    var D = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, 1.414], [1, -1, 1.414], [-1, 1, 1.414], [-1, -1, 1.414]];
    while (open.length) {
      var bi = 0; for (var k = 1; k < open.length; k++) if (g[open[k]] + h(open[k]) < g[open[bi]] + h(open[bi])) bi = k;
      var cur = open.splice(bi, 1)[0]; if (cur === goal) break; if (closed[cur]) continue; closed[cur] = 1;
      var cx = cur % GW, cy = cur / GW | 0;
      D.forEach(function (d) { var nx = cx + d[0], ny = cy + d[1]; if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) return; var ni = ny * GW + nx; if (grid[ni] || closed[ni]) return;
        if (d[2] > 1 && (grid[cy * GW + nx] || grid[ny * GW + cx])) return;
        var ng = g[cur] + d[2]; if (ng < g[ni]) { g[ni] = ng; from[ni] = cur; open.push(ni); } });
    }
    if (from[goal] < 0) return null;
    var path = [], i = goal; while (i >= 0) { path.unshift([(i % GW) * CS + CS / 2, (i / GW | 0) * CS + CS / 2]); i = from[i]; }
    return path;
  }
  function simplify(p) { if (p.length < 3) return p; var out = [p[0]];
    for (var i = 1; i < p.length - 1; i++) { var a = out[out.length - 1], b = p[i], c = p[i + 1]; if ((b[0] - a[0]) * (c[1] - b[1]) !== (b[1] - a[1]) * (c[0] - b[0])) out.push(b); }
    out.push(p[p.length - 1]); return out; }
  /* เส้นทางจากทางเดินที่เจ้าหน้าที่เดินเก็บจริง (กราฟ + Dijkstra) */
  var graphs = {};
  function graph(wc) {
    var key = wc ? 'wc' : 'all'; if (graphs[key]) return graphs[key];
    var N = [], E = [];
    function edge(i, j, w) { (E[i] = E[i] || []).push([j, w]); (E[j] = E[j] || []).push([i, w]); }
    net.paths.forEach(function (p, pi) { if (wc && !p.wc) return; var base = N.length;
      p.pts.forEach(function (pt, k) { N.push([pt[0], pt[1], pi]); if (k) edge(base + k - 1, base + k, Math.hypot(pt[0] - p.pts[k - 1][0], pt[1] - p.pts[k - 1][1])); }); });
    for (var i = 0; i < N.length; i++) for (var j = i + 1; j < N.length; j++) { if (N[i][2] === N[j][2]) continue; var d = Math.hypot(N[i][0] - N[j][0], N[i][1] - N[j][1]); if (d < 18) edge(i, j, d); }
    return (graphs[key] = { N: N, E: E });
  }
  function routeNet(start, end, wc) {
    var G = graph(wc), N = G.N.slice(), E = G.E.map(function (e) { return e ? e.slice() : []; }), S = N.length, T = S + 1;
    if (!N.length) return null;
    N.push(start, end); E[S] = []; E[T] = [];
    function link(src, pt) { var near = [], best = -1, bd = 1e9;
      for (var i = 0; i < S; i++) { var d = Math.hypot(N[i][0] - pt[0], N[i][1] - pt[1]); if (d < bd) { bd = d; best = i; } if (d < 70) near.push([i, d]); }
      if (!near.length && best > -1) near.push([best, bd]);
      near.forEach(function (n) { var w = n[1] * 1.6; E[src].push([n[0], w]); (E[n[0]] = E[n[0]] || []).push([src, w]); }); }
    link(S, start); link(T, end);
    var dd = Math.hypot(start[0] - end[0], start[1] - end[1]); if (dd < 60) { E[S].push([T, dd]); }
    var dist = new Float64Array(N.length).fill(Infinity), prev = new Int32Array(N.length).fill(-1), done = new Uint8Array(N.length); dist[S] = 0;
    for (;;) { var u = -1, m = Infinity; for (var k = 0; k < N.length; k++) if (!done[k] && dist[k] < m) { m = dist[k]; u = k; }
      if (u < 0 || u === T) break; done[u] = 1; (E[u] || []).forEach(function (e) { if (dist[u] + e[1] < dist[e[0]]) { dist[e[0]] = dist[u] + e[1]; prev[e[0]] = u; } }); }
    if (!isFinite(dist[T])) return null;
    var out = [], v = T; while (v > -1) { out.unshift([N[v][0], N[v][1]]); v = prev[v]; } return out;
  }
  function clearRoute() { if (!rsvg) return; rsvg.classList.remove('on'); rsvg.querySelector('polyline').setAttribute('points', ''); }
  function drawRoute(fromV, toId, keepView) {
    if (!rsvg) return; buildGrid();
    var start;
    if (fromV === 'gps') { if (!gpsPt) { startGps(); return; } start = gpsPt; }
    else if (fromV.charAt(0) === 'q') { var qq = net.qr[+fromV.slice(1)]; start = [qq.x, qq.y]; }
    else if (fromV.charAt(0) === 'm') { var m = marks[+fromV.slice(1)]; start = [m.x, m.y]; }
    else { var fid = fromV.slice(1), fr = rectOf(fid); start = doorOf(fid, [fr[0] + fr[2] / 2, fr[1] + fr[3] / 2 + 1000]); var tr = rectOf(toId); start = doorOf(fid, [tr[0] + tr[2] / 2, tr[1] + tr[3] / 2]); }
    var end = doorOf(toId, start);
    var a = free([Math.floor(start[0] / CS), Math.floor(start[1] / CS)]), b = free([Math.floor(end[0] / CS), Math.floor(end[1] / CS)]);
    if (fromV.charAt(0) === 'b' && fromV.slice(1) === toId) { clearRoute(); say('จุดเริ่มต้นกับปลายทางเป็นอาคารเดียวกัน'); return; }
    var path = net.paths.length ? routeNet(start, end, wcBox && wcBox.checked) : null;
    if (!path) { path = a && b ? astar(a, b) : null; if (path) path = simplify([start].concat(path, [end])); }
    if (!path) { say('ไม่พบเส้นทาง กรุณาสอบถามประชาสัมพันธ์'); clearRoute(); return; }
    var len = 0; for (var i = 1; i < path.length; i++) len += Math.hypot(path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1]);
    rsvg.querySelector('polyline').setAttribute('points', path.map(function (p) { return p.join(','); }).join(' '));
    var A = rsvg.querySelector('.a'), B = rsvg.querySelector('.b'); A.setAttribute('cx', start[0]); A.setAttribute('cy', start[1]); B.setAttribute('cx', end[0]); B.setAttribute('cy', end[1]);
    rsvg.classList.remove('on'); void rsvg.getBoundingClientRect(); rsvg.classList.add('on');
    var metres = Math.round(len * .5 / 10) * 10; // ภาพ 1px ≈ 0.5 เมตร (โดยประมาณ)
    say('🚶 ระยะเดินประมาณ ' + metres + ' เมตร · ' + Math.max(1, Math.round(metres / 70)) + ' นาที');
    if (keepView) return;
    var xs = path.map(function (p) { return p[0]; }), ys = path.map(function (p) { return p[1]; });
    var cx = (Math.min.apply(0, xs) + Math.max.apply(0, xs)) / 2, cy = (Math.min.apply(0, ys) + Math.max.apply(0, ys)) / 2, span = Math.max(Math.max.apply(0, xs) - Math.min.apply(0, xs), Math.max.apply(0, ys) - Math.min.apply(0, ys));
    var zz = Math.max(.8, Math.min(1.8, 480 / Math.max(200, span))), off = box.classList.contains('is-full') && window.innerWidth > 760 ? 230 / (fit() * zz) : 0;
    tween({ px: W / 2 - cx - off, py: H / 2 - cy, z: zz, rx: 46 });
  }
  box.querySelectorAll('.cb').forEach(function (el) {
    el.addEventListener('click', function () { if (moved > 6) return; select(el.dataset.id, input.value.trim().toLowerCase()); });
    el.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); select(el.dataset.id); } });
  });
  // ค้นหา
  input.addEventListener('input', function () {
    var q = input.value.trim().toLowerCase(), match = null, html = '';
    if (q) {
      match = {};
      Object.keys(data).forEach(function (id) {
        var b = data[id], hits = [];
        if (b.name.toLowerCase().indexOf(q) > -1) hits.push('');
        b.floors.forEach(function (f) { f[1].forEach(function (x) { if (x.toLowerCase().indexOf(q) > -1) hits.push(f[0] + ' · ' + x); }); });
        if (hits.length) { match[id] = 1; html += '<li><button type="button" data-go="' + id + '"><b>' + mark(b.name, q) + '</b>' + hits.filter(Boolean).slice(0, 3).map(function (h) { return '<small>' + mark(h, q) + '</small>'; }).join('') + '</button></li>'; }
      });
      if (!html) html = '<li class="none">ไม่พบ ลองพิมพ์คำอื่น</li>';
    }
    res.innerHTML = html; res.hidden = !q; hint.hidden = !!q || !!sel; det.hidden = !!q || !sel;
    sel = null; paint(match);
  });
  res.addEventListener('click', function (e) { var b = e.target.closest('[data-go]'); if (!b) return; var q = input.value.trim().toLowerCase(); res.hidden = true; select(b.dataset.go, q); });
  window.addEventListener('resize', draw); draw();
  if (qIdx > -1) { var qq0 = net.qr[qIdx]; say('📌 คุณอยู่ที่: ' + qq0.t + ' · แตะตึกที่ต้องการไป หรือค้นหาบริการ'); tween({ px: W / 2 - qq0.x, py: H / 2 - qq0.y, z: 1.4 }); var qm = box.querySelector('.mk.qr[data-qr="' + qFrom + '"]'); if (qm) qm.classList.add('is-here'); }
});

})();
