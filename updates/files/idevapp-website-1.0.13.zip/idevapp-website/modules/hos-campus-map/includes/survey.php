<?php
/**
 * ผังโรงพยาบาล: 📱 เดินเก็บพิกัด (ประตู / ทางเดิน / จุดสังเกต) และ 📌 QR “คุณอยู่ที่นี่”
 */
defined( 'ABSPATH' ) || exit;

/** ข้อมูลผังปัจจุบัน (ถ้ายังไม่เคยบันทึก ใช้ค่าเริ่มต้น) */
function hos_cs_current() {
	$d = hos_campus_data();
	foreach ( array( 'doors', 'paths', 'qr', 'marks' ) as $k ) {
		if ( ! isset( $d[ $k ] ) ) {
			$d[ $k ] = array();
		}
	}
	return $d;
}

function hos_cs_save( $d ) {
	update_option( 'hos_campus_data', hos_campus_sanitize( $d ), false );
	do_action( 'litespeed_purge_all' );
}

function hos_cs_summary( $d ) {
	return array( 'doors' => count( $d['doors'] ), 'paths' => count( $d['paths'] ), 'marks' => count( $d['marks'] ), 'net' => hos_campus_net( $d ), 'marksPx' => $d['marks'] );
}

add_action( 'wp_ajax_hos_cs', function () {
	if ( ! current_user_can( 'edit_pages' ) || ! check_ajax_referer( 'hos_cs', 'nonce', false ) ) {
		wp_send_json_error( 'ไม่มีสิทธิ์' );
	}
	$d    = hos_cs_current();
	$op   = sanitize_key( $_POST['op'] ?? '' );
	$item = json_decode( wp_unslash( $_POST['item'] ?? '{}' ), true ); // phpcs:ignore
	$item = is_array( $item ) ? $item : array();
	switch ( $op ) {
		case 'door':
			$d['doors'][] = array( 'b' => sanitize_key( $item['b'] ?? '' ), 'lat' => (float) ( $item['lat'] ?? 0 ), 'lng' => (float) ( $item['lng'] ?? 0 ), 't' => sanitize_text_field( $item['t'] ?? '' ) );
			break;
		case 'path':
			$d['paths'][] = array( 't' => sanitize_text_field( $item['t'] ?? '' ), 'wc' => ! empty( $item['wc'] ), 'pts' => (array) ( $item['pts'] ?? array() ) );
			break;
		case 'mark':
			$p            = hos_campus_px( $d['geo'], (float) ( $item['lat'] ?? 0 ), (float) ( $item['lng'] ?? 0 ) );
			$d['marks'][] = array( 't' => sanitize_text_field( $item['t'] ?? '' ), 'ic' => sanitize_text_field( $item['ic'] ?? '📍' ), 'x' => (int) $p[0], 'y' => (int) $p[1] );
			break;
		case 'undo':
			$k = sanitize_key( $item['k'] ?? '' );
			if ( in_array( $k, array( 'doors', 'paths', 'marks' ), true ) && $d[ $k ] ) {
				array_pop( $d[ $k ] );
			}
			break;
		case 'qr':
			$d['qr'] = (array) ( $item['qr'] ?? array() );
			break;
		default:
			wp_send_json_error( 'คำสั่งไม่ถูกต้อง' );
	}
	hos_cs_save( $d );
	wp_send_json_success( hos_cs_summary( hos_cs_current() ) );
} );

/* ================= 📱 เดินเก็บพิกัด ================= */
function hos_campus_survey_page() {
	$d   = hos_cs_current();
	$img = $d['img'];
	?>
	<div class="wrap hoss">
		<h1>📱 เดินเก็บพิกัด</h1>
		<p class="description">เปิดหน้านี้ด้วย<b>มือถือ</b> แล้วเดินในโรงพยาบาล · อนุญาตการใช้ตำแหน่งเมื่อเบราว์เซอร์ถาม · ยืนในที่โล่งจะแม่นกว่าชิดตึก</p>
		<div class="hoss-gps" id="hoss-gps">⏳ กำลังหาตำแหน่ง…</div>
		<div class="hoss-map" id="hoss-map" style="aspect-ratio:960/<?php echo (int) $d['h']; ?>;background-image:url('<?php echo esc_url( $img ); ?>')"><svg viewBox="0 0 960 <?php echo (int) $d['h']; ?>" id="hoss-svg"></svg><i id="hoss-me"></i></div>
		<div class="hoss-sum" id="hoss-sum"></div>

		<section class="hoss-card">
			<h2>🚪 บันทึกประตูอาคาร</h2>
			<p>ยืนหน้าประตูจริง เลือกอาคาร แล้วกดบันทึก (ระบบเฉลี่ยตำแหน่ง 15 วินาที — ยืนนิ่ง ๆ)</p>
			<select id="hoss-b"><?php foreach ( $d['buildings'] as $b ) : ?><option value="<?php echo esc_attr( $b['id'] ); ?>"><?php echo esc_html( $b['name'] ); ?></option><?php endforeach; ?></select>
			<input id="hoss-bt" type="text" placeholder="ชื่อประตู (ไม่บังคับ) เช่น ประตูหน้า, ทางลาด">
			<button class="button button-primary button-hero" data-avg="door">บันทึกประตูนี้</button>
			<button class="button-link" data-undo="doors">↶ ยกเลิกประตูล่าสุด</button>
		</section>

		<section class="hoss-card">
			<h2>〰️ บันทึกทางเดิน</h2>
			<p>กดเริ่ม แล้วเดินตามทางจริง (ทางเดินมีหลังคา ทางลาด ทางลัด) กดหยุดเมื่อถึงปลายทาง · เส้นที่ตัดหรือต่อกันจะเชื่อมเป็นโครงข่ายเอง</p>
			<input id="hoss-pt" type="text" placeholder="ชื่อทางเดิน (ไม่บังคับ) เช่น ทางเชื่อม OPD–ER">
			<label class="hoss-chk"><input type="checkbox" id="hoss-wc" checked> ♿ รถเข็นผ่านได้ (ไม่มีขั้นบันได)</label>
			<button class="button button-primary button-hero" id="hoss-rec">▶ เริ่มบันทึกทางเดิน</button>
			<div id="hoss-recinfo" class="hoss-recinfo" hidden></div>
			<button class="button-link" data-undo="paths">↶ ยกเลิกทางเดินล่าสุด</button>
		</section>

		<section class="hoss-card">
			<h2>📍 บันทึกจุดสังเกต</h2>
			<p>เช่น ทางเข้า ที่จอดรถ จุดจอดรถพยาบาล — ใช้เป็นจุดเริ่มต้นการนำทาง</p>
			<div class="hoss-row"><input id="hoss-mi" type="text" value="📍" maxlength="4" style="width:60px"><input id="hoss-mt" type="text" placeholder="ชื่อจุด เช่น ที่จอดรถมอเตอร์ไซค์"></div>
			<button class="button button-primary button-hero" data-avg="mark">บันทึกจุดนี้</button>
			<button class="button-link" data-undo="marks">↶ ยกเลิกจุดล่าสุด</button>
		</section>
		<div class="hoss-toast" id="hoss-toast" hidden></div>
	</div>
	<style>
	.hoss{max-width:720px}.hoss h2{margin:0 0 6px;font-size:18px}
	.hoss-gps{position:sticky;top:32px;z-index:9;background:#1d2327;color:#fff;padding:10px 14px;border-radius:10px;margin:10px 0;font-size:15px}
	.hoss-gps.good{background:#0a7d55}.hoss-gps.bad{background:#b32d2e}
	.hoss-map{position:relative;width:100%;background-size:100% 100%;border-radius:10px;overflow:hidden;margin-bottom:8px}
	.hoss-map svg{position:absolute;inset:0;width:100%;height:100%}
	.hoss-map polyline{fill:none;stroke:#ff6a00;stroke-width:5;stroke-linejoin:round}.hoss-map polyline.wc{stroke:#8a5cd6}.hoss-map polyline.live{stroke:#00c2ff;stroke-dasharray:6 6}
	.hoss-map circle.d{fill:#ff2d55;stroke:#fff;stroke-width:3}.hoss-map circle.m{fill:#0a7d55;stroke:#fff;stroke-width:3}
	#hoss-me{position:absolute;width:16px;height:16px;margin:-8px 0 0 -8px;border-radius:50%;background:#1a73e8;border:3px solid #fff;box-shadow:0 0 0 6px rgba(26,115,232,.3);display:none}
	.hoss-sum{font-size:13px;color:#50575e;margin-bottom:10px}
	.hoss-card{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;margin-bottom:14px}
	.hoss-card select,.hoss-card input[type=text]{width:100%;margin:6px 0;font-size:16px;padding:8px}
	.hoss-card .button-hero{width:100%;margin:6px 0;font-size:17px!important}
	.hoss-row{display:flex;gap:8px}.hoss-chk{display:block;margin:8px 0;font-size:15px}
	.hoss-recinfo{background:#e5f6ff;border-radius:8px;padding:8px 12px;font-weight:600}
	.hoss-toast{position:fixed;left:50%;bottom:20px;transform:translateX(-50%);background:#1d2327;color:#fff;padding:12px 18px;border-radius:10px;z-index:99999;font-size:15px;max-width:90vw}
	</style>
	<script>
	(function () {
		var AJ = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>, NONCE = <?php echo wp_json_encode( wp_create_nonce( 'hos_cs' ) ); ?>;
		var GEO = <?php echo wp_json_encode( $d['geo'] ); ?>, S = <?php echo wp_json_encode( hos_cs_summary( $d ), JSON_UNESCAPED_UNICODE ); ?>;
		var gps = document.getElementById('hoss-gps'), mapEl = document.getElementById('hoss-map'), svg = document.getElementById('hoss-svg'), meEl = document.getElementById('hoss-me'), toastEl = document.getElementById('hoss-toast');
		var last = null, rec = null, NS = 'http://www.w3.org/2000/svg';
		function px(lat, lng) { var a = GEO[0], b = GEO[1]; return [a[0] + (lng - a[3]) / (b[3] - a[3]) * (b[0] - a[0]), a[1] + (lat - a[2]) / (b[2] - a[2]) * (b[1] - a[1])]; }
		function meters(a, b) { var R = 6371000, d1 = (b[0] - a[0]) * Math.PI / 180, d2 = (b[1] - a[1]) * Math.PI / 180, x = Math.sin(d1 / 2) * Math.sin(d1 / 2) + Math.cos(a[0] * Math.PI / 180) * Math.cos(b[0] * Math.PI / 180) * Math.sin(d2 / 2) * Math.sin(d2 / 2); return 2 * R * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x)); }
		function toast(t) { toastEl.textContent = t; toastEl.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(function () { toastEl.hidden = true; }, 3500); }
		function render() {
			svg.innerHTML = '';
			S.net.paths.forEach(function (p) { var l = document.createElementNS(NS, 'polyline'); l.setAttribute('points', p.pts.map(function (q) { return q.join(','); }).join(' ')); if (p.wc) l.setAttribute('class', 'wc'); svg.appendChild(l); });
			if (rec && rec.pts.length > 1) { var l = document.createElementNS(NS, 'polyline'); l.setAttribute('class', 'live'); l.setAttribute('points', rec.pts.map(function (q) { return px(q[0], q[1]).join(','); }).join(' ')); svg.appendChild(l); }
			S.net.doors.forEach(function (o) { var c = document.createElementNS(NS, 'circle'); c.setAttribute('cx', o.x); c.setAttribute('cy', o.y); c.setAttribute('r', 7); c.setAttribute('class', 'd'); svg.appendChild(c); });
			S.marksPx.forEach(function (o) { var c = document.createElementNS(NS, 'circle'); c.setAttribute('cx', o.x); c.setAttribute('cy', o.y); c.setAttribute('r', 7); c.setAttribute('class', 'm'); svg.appendChild(c); });
			document.getElementById('hoss-sum').textContent = 'บันทึกแล้ว: ประตู ' + S.doors + ' · ทางเดิน ' + S.paths + ' · จุดสังเกต ' + S.marks + '  (จุดแดง = ประตู · เส้นส้ม = ทางเดิน · เส้นม่วง = รถเข็นผ่านได้)';
		}
		function send(op, item) {
			var fd = new FormData(); fd.append('action', 'hos_cs'); fd.append('nonce', NONCE); fd.append('op', op); fd.append('item', JSON.stringify(item));
			return fetch(AJ, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) { if (!j.success) throw new Error(j.data || 'error'); S = j.data; render(); return j; });
		}
		if (!navigator.geolocation) { gps.textContent = 'อุปกรณ์นี้ไม่รองรับ GPS'; gps.className = 'hoss-gps bad'; return; }
		navigator.geolocation.watchPosition(function (p) {
			last = { lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy, t: Date.now() };
			gps.textContent = '📡 ความแม่นยำ ±' + Math.round(last.acc) + ' ม. · ' + last.lat.toFixed(6) + ', ' + last.lng.toFixed(6) + (last.acc > 20 ? ' — รอให้ต่ำกว่า 20 ม. หรือออกที่โล่ง' : ' — ใช้ได้');
			gps.className = 'hoss-gps ' + (last.acc <= 20 ? 'good' : 'bad');
			var q = px(last.lat, last.lng), r = mapEl.clientWidth / 960; meEl.style.display = 'block'; meEl.style.left = q[0] * r + 'px'; meEl.style.top = q[1] * r + 'px';
			if (rec && last.acc <= 25) { var lp = rec.pts[rec.pts.length - 1]; if (!lp || meters(lp, [last.lat, last.lng]) >= 3) { if (lp) rec.dist += meters(lp, [last.lat, last.lng]); rec.pts.push([+last.lat.toFixed(7), +last.lng.toFixed(7)]); recInfo(); render(); } }
		}, function (e) { gps.textContent = e.code === 1 ? '⛔ ไม่ได้รับอนุญาตให้ใช้ตำแหน่ง — เปิดในการตั้งค่าเบราว์เซอร์' : '⚠️ หาตำแหน่งไม่ได้'; gps.className = 'hoss-gps bad'; }, { enableHighAccuracy: true, maximumAge: 0, timeout: 30000 });
		// เฉลี่ยตำแหน่ง 15 วินาที (ถ่วงน้ำหนักตามความแม่นยำ)
		function average(sec) {
			return new Promise(function (ok, no) {
				var sw = 0, sl = 0, sg = 0, n = 0, t0 = Date.now(), seen = 0;
				var iv = setInterval(function () {
					if (last && last.t > seen && last.acc < 40) { seen = last.t; var w = 1 / Math.max(1, last.acc * last.acc); sw += w; sl += last.lat * w; sg += last.lng * w; n++; }
					var left = sec - Math.floor((Date.now() - t0) / 1000); toast('⏳ ยืนนิ่ง ๆ… ' + left + ' วินาที (เก็บได้ ' + n + ' ค่า)');
					if (left <= 0) { clearInterval(iv); n ? ok({ lat: +(sl / sw).toFixed(7), lng: +(sg / sw).toFixed(7), n: n }) : no(new Error('สัญญาณ GPS ไม่ดีพอ ลองออกที่โล่งแล้วบันทึกใหม่')); }
				}, 500);
			});
		}
		document.querySelectorAll('[data-avg]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				if (!last) return toast('ยังไม่พบตำแหน่ง GPS');
				btn.disabled = true;
				average(btn.dataset.avg === 'door' ? 15 : 10).then(function (p) {
					var item = btn.dataset.avg === 'door' ? { b: document.getElementById('hoss-b').value, t: document.getElementById('hoss-bt').value, lat: p.lat, lng: p.lng } : { t: document.getElementById('hoss-mt').value || 'จุดสังเกต', ic: document.getElementById('hoss-mi').value, lat: p.lat, lng: p.lng };
					return send(btn.dataset.avg, item).then(function () { toast('✅ บันทึกแล้ว (เฉลี่ยจาก ' + p.n + ' ค่า)'); document.getElementById('hoss-bt').value = ''; });
				}).catch(function (e) { toast('⚠️ ' + e.message); }).then(function () { btn.disabled = false; });
			});
		});
		var recBtn = document.getElementById('hoss-rec'), recEl = document.getElementById('hoss-recinfo');
		function recInfo() { recEl.hidden = !rec; if (rec) recEl.textContent = '🔴 กำลังบันทึก · ' + rec.pts.length + ' จุด · ' + Math.round(rec.dist) + ' เมตร'; }
		recBtn.addEventListener('click', function () {
			if (!rec) { rec = { pts: last && last.acc <= 25 ? [[+last.lat.toFixed(7), +last.lng.toFixed(7)]] : [], dist: 0 }; recBtn.textContent = '■ หยุดและบันทึกทางเดิน'; recBtn.classList.add('button-secondary'); recInfo(); try { navigator.wakeLock && navigator.wakeLock.request('screen'); } catch (e) {} return; }
			var r = rec; rec = null; recBtn.textContent = '▶ เริ่มบันทึกทางเดิน'; recInfo();
			if (r.pts.length < 2) return toast('ทางเดินสั้นเกินไป (ต้องมีอย่างน้อย 2 จุด) ไม่ได้บันทึก');
			send('path', { t: document.getElementById('hoss-pt').value, wc: document.getElementById('hoss-wc').checked, pts: r.pts }).then(function () { toast('✅ บันทึกทางเดินแล้ว ' + r.pts.length + ' จุด · ' + Math.round(r.dist) + ' ม.'); document.getElementById('hoss-pt').value = ''; }).catch(function (e) { toast('⚠️ ' + e.message); });
		});
		document.querySelectorAll('[data-undo]').forEach(function (b) { b.addEventListener('click', function () { if (confirm('ยกเลิกรายการล่าสุด?')) send('undo', { k: b.dataset.undo }).then(function () { toast('ยกเลิกแล้ว'); }); }); });
		window.addEventListener('beforeunload', function (e) { if (rec) { e.preventDefault(); e.returnValue = ''; } });
		render();
	})();
	</script>
	<?php
}

/* ================= 📌 QR “คุณอยู่ที่นี่” ================= */
function hos_campus_qr_page() {
	$d    = hos_cs_current();
	$img  = $d['img'];
	$map  = hos_campus_find_page();
	$base = $map ? get_permalink( $map ) : home_url( '/map/' );
	wp_enqueue_script( 'hos-qr', HOSCM_URL . 'assets/qr.js', array(), HOSCM_VER, true );
	?>
	<div class="wrap hosq">
		<h1>📌 QR “คุณอยู่ที่นี่”</h1>
		<p class="description">ติดป้าย QR ตามจุดต่าง ๆ (หน้าห้องบัตร, ลิฟต์, ทางแยกทางเดิน) · คนไข้สแกนแล้วแผนที่เปิดพร้อมจุดเริ่มต้นตรงนั้นทันที — ใช้ได้แม้อยู่ในอาคารที่ GPS จับไม่ได้</p>
		<div class="hosq-grid">
			<div><div class="hosq-map" id="hosq-map" style="aspect-ratio:960/<?php echo (int) $d['h']; ?>;background-image:url('<?php echo esc_url( $img ); ?>')"></div><p class="description">กดเลือกจุดในรายการ แล้ว<b>แตะบนภาพ</b>เพื่อวางตำแหน่ง (หรือลากหมุด)</p></div>
			<div>
				<div id="hosq-list"></div>
				<p><button class="button" id="hosq-add">＋ เพิ่มจุด QR</button></p>
				<p><button class="button button-primary button-hero" id="hosq-save">💾 บันทึก</button> <button class="button button-hero" id="hosq-print">🖨️ พิมพ์ป้าย QR ทั้งหมด</button></p>
			</div>
		</div>
		<div id="hosq-printarea"></div>
	</div>
	<style>
	.hosq-grid{display:grid;grid-template-columns:minmax(0,1fr) 420px;gap:20px;align-items:start}
	.hosq-map{position:relative;width:100%;background-size:100% 100%;border-radius:10px;cursor:crosshair}
	.hosq-pin{position:absolute;transform:translate(-50%,-100%);background:#fff;border:2px solid #d63638;border-radius:999px;padding:2px 8px;font-size:12px;font-weight:700;white-space:nowrap;cursor:move}
	.hosq-pin.on{background:#d63638;color:#fff}
	.hosq-row{display:grid;grid-template-columns:1fr auto auto;gap:6px;align-items:center;padding:6px;border:1px solid #dcdcde;border-radius:8px;margin-bottom:6px;background:#fff}
	.hosq-row.on{border-color:#d63638;box-shadow:0 0 0 1px #d63638}.hosq-row input{width:100%}
	#hosq-printarea{display:none}
	@media print{body *{visibility:hidden}#hosq-printarea,#hosq-printarea *{visibility:visible}#hosq-printarea{display:grid!important;position:absolute;left:0;top:0;width:100%;grid-template-columns:1fr 1fr;gap:10mm}
	 .hosq-card{border:2px solid #0a7d55;border-radius:6mm;padding:8mm;text-align:center;page-break-inside:avoid;font-family:sans-serif}.hosq-card h3{font-size:22pt;margin:0;color:#0a7d55}.hosq-card h4{font-size:16pt;margin:2mm 0 4mm}.hosq-card svg{width:55mm;height:55mm}.hosq-card p{font-size:12pt;margin:3mm 0 0}}
	@media(max-width:1000px){.hosq-grid{grid-template-columns:1fr}}
	</style>
	<script>
	(function () {
		var AJ = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>, NONCE = <?php echo wp_json_encode( wp_create_nonce( 'hos_cs' ) ); ?>, BASE = <?php echo wp_json_encode( $base ); ?>;
		var Q = <?php echo wp_json_encode( array_values( $d['qr'] ), JSON_UNESCAPED_UNICODE ); ?>, sel = 0, map = document.getElementById('hosq-map'), list = document.getElementById('hosq-list');
		function k() { return map.clientWidth / 960; }
		function url(q) { return BASE + (BASE.indexOf('?') > -1 ? '&' : '?') + 'from=' + encodeURIComponent(q.id); }
		function draw() {
			map.innerHTML = ''; Q.forEach(function (q, i) { var p = document.createElement('div'); p.className = 'hosq-pin' + (i === sel ? ' on' : ''); p.textContent = '📌 ' + q.t; p.style.left = q.x * k() + 'px'; p.style.top = q.y * k() + 'px';
				p.addEventListener('pointerdown', function (e) { e.stopPropagation(); e.preventDefault(); sel = i; var x0 = e.clientX, y0 = e.clientY, ox = q.x, oy = q.y;
					function mv(ev) { q.x = Math.round(ox + (ev.clientX - x0) / k()); q.y = Math.round(oy + (ev.clientY - y0) / k()); draw(); }
					function up() { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); rows(); }
					window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up); }); map.appendChild(p); });
		}
		function rows() { list.innerHTML = Q.map(function (q, i) { return '<div class="hosq-row' + (i === sel ? ' on' : '') + '" data-i="' + i + '"><input value="' + q.t.replace(/"/g, '&quot;') + '"><a class="button button-small" target="_blank" href="' + url(q) + '">ทดสอบ</a><button class="button-link" data-del style="color:#b32d2e">ลบ</button></div>'; }).join('') || '<p>ยังไม่มีจุด QR</p>'; }
		map.addEventListener('click', function (e) { if (!Q[sel] || e.target !== map) return; var r = map.getBoundingClientRect(); Q[sel].x = Math.round((e.clientX - r.left) / k()); Q[sel].y = Math.round((e.clientY - r.top) / k()); draw(); });
		list.addEventListener('click', function (e) { var r = e.target.closest('[data-i]'); if (!r) return; sel = +r.dataset.i; if (e.target.dataset.del !== undefined && confirm('ลบจุดนี้?')) { Q.splice(sel, 1); sel = 0; } rows(); draw(); });
		list.addEventListener('input', function (e) { var r = e.target.closest('[data-i]'); Q[+r.dataset.i].t = e.target.value; draw(); });
		document.getElementById('hosq-add').onclick = function () { Q.push({ id: 'q' + Date.now().toString(36), t: 'จุดใหม่', x: 480, y: 400 }); sel = Q.length - 1; rows(); draw(); list.querySelector('.on input').select(); };
		document.getElementById('hosq-save').onclick = function () { var fd = new FormData(); fd.append('action', 'hos_cs'); fd.append('nonce', NONCE); fd.append('op', 'qr'); fd.append('item', JSON.stringify({ qr: Q }));
			fetch(AJ, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) { alert(j.success ? 'บันทึกแล้ว' : 'บันทึกไม่สำเร็จ'); }); };
		function qrSvg(text) { var q = window.HosQR(text), n = q.getModuleCount(), d = ''; for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) if (q.isDark(r, c)) d += 'M' + (c + 4) + ' ' + (r + 4) + 'h1v1h-1z'; return '<svg viewBox="0 0 ' + (n + 8) + ' ' + (n + 8) + '" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>'; }
		document.getElementById('hosq-print').onclick = function () {
			if (!Q.length) return alert('ยังไม่มีจุด QR'); var pa = document.getElementById('hosq-printarea');
			pa.innerHTML = Q.map(function (q) { return '<div class="hosq-card"><h3>📍 คุณอยู่ที่นี่</h3><h4>' + q.t.replace(/</g, '&lt;') + '</h4>' + qrSvg(url(q)) + '<p>สแกนเพื่อดูแผนที่และเส้นทางในโรงพยาบาล<br>Scan for hospital map &amp; directions</p></div>'; }).join('');
			window.print();
		};
		rows(); draw(); window.addEventListener('resize', draw);
	})();
	</script>
	<?php
}
