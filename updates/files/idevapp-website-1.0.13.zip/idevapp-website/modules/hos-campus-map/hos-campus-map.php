<?php
/**
 * Plugin Name: ผังโรงพยาบาล 3 มิติ — ผังโรงพยาบาล 3 มิติ
 * Description: ผังโรงพยาบาลแบบ 3 มิติ (หมุน/ซูม) กดดูบริการรายชั้น ค้นหา นำทางภายในโรงพยาบาล (GPS / QR “คุณอยู่ที่นี่”) พร้อมหน้าแก้ไขผัง และโหมดเดินเก็บพิกัดด้วยมือถือ · ใช้บล็อก “ผังโรงพยาบาล 3 มิติ” หรือ shortcode [hos_campus] / [hos_campus full="1"]
 * Version: 1.2.0
 * Plugin URI: https://idevapp.me
 * Author: iDevApp
 * Author URI: https://idevapp.me
 * License: GPLv2 or later
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Text Domain: hos-campus-map
 */
defined( 'ABSPATH' ) || exit;

define( 'HOSCM_VER', '1.2.0' );
define( 'HOSCM_DIR', plugin_dir_path( __FILE__ ) );
define( 'HOSCM_URL', plugin_dir_url( __FILE__ ) );

// ธีม iDevApp รุ่นเก่า (ก่อน 3.0) มีผังโรงพยาบาลอยู่ในธีม — ป้องกันฟังก์ชันชนกัน
if ( function_exists( 'hos_campus_render' ) ) {
	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-error"><p><b>ผังโรงพยาบาล 3 มิติ:</b> ธีมที่ใช้อยู่ยังมีผังโรงพยาบาลในตัว — กรุณาอัปเดตธีม iDevApp แบบที่ 1 เป็นรุ่น 3.0 ขึ้นไปก่อน</p></div>';
	} );
	return;
}

require HOSCM_DIR . 'includes/campus.php';
require HOSCM_DIR . 'includes/admin.php';
require HOSCM_DIR . 'includes/survey.php';

/** เวอร์ชันไฟล์ตามเวลาแก้ไข (กันแคชเสิร์ฟไฟล์เก่า) */
function hoscm_asset_ver( $file ) {
	$f = HOSCM_DIR . 'assets/' . $file;
	return file_exists( $f ) ? HOSCM_VER . '.' . filemtime( $f ) : HOSCM_VER;
}

/** ข้อความค้นหาสำหรับปุ่มนำทาง Google Maps */
function hoscm_map_query() {
	$d = get_option( 'hos_campus_data' );
	if ( is_array( $d ) && ! empty( $d['gmap'] ) ) {
		return $d['gmap'];
	}
	if ( function_exists( 'hos_mod' ) && hos_mod( 'hos_map_query' ) ) {
		return hos_mod( 'hos_map_query' );
	}
	return get_bloginfo( 'name' );
}

add_action( 'init', function () {
	wp_register_style( 'hos-campus', HOSCM_URL . 'assets/campus.css', array(), hoscm_asset_ver( 'campus.css' ) );
	wp_register_script( 'hos-campus', HOSCM_URL . 'assets/campus.js', array(), hoscm_asset_ver( 'campus.js' ), true );
	wp_register_script( 'hos-campus-editor', HOSCM_URL . 'assets/editor.js', array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render' ), hoscm_asset_ver( 'editor.js' ), true );
	register_block_type( 'hos/campus', array(
		'api_version'     => 3,
		'title'           => 'ผังโรงพยาบาล 3 มิติ',
		'category'        => 'widgets',
		'icon'            => 'building',
		'editor_script'   => 'hos-campus-editor',
		'attributes'      => array( 'full' => array( 'type' => 'boolean', 'default' => false ) ),
		'render_callback' => 'hos_campus_render',
	) );
	add_shortcode( 'hos_campus', 'hos_campus_render' );
} );

/** โหลด CSS/JS เฉพาะหน้าที่มีผัง */
function hoscm_enqueue() {
	wp_enqueue_style( 'hos-campus' );
	if ( ! is_admin() ) {
		wp_enqueue_script( 'hos-campus' );
	}
}
add_action( 'wp_enqueue_scripts', function () {
	$post = get_post();
	if ( $post && ( has_block( 'hos/campus', $post ) || has_shortcode( (string) $post->post_content, 'hos_campus' ) ) ) {
		hoscm_enqueue();
	}
} );
// ตัวแก้ไขบล็อก: ให้ภาพตัวอย่างในหน้าแก้ไขมีหน้าตาเหมือนหน้าเว็บ
add_action( 'enqueue_block_assets', function () {
	if ( is_admin() ) {
		wp_enqueue_style( 'hos-campus' );
	}
} );

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=hos-campus' ) ) . '">แก้ไขผัง</a>' );
	$links[] = '<a href="https://idevapp.me" target="_blank" rel="noopener">iDevApp</a>';
	return $links;
} );
