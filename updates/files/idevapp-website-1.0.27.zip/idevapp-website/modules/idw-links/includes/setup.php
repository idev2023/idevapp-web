<?php
/**
 * คลิกเดียว: สร้างหน้า “สร้าง QR Code และย่อลิงก์” + เพิ่มการ์ดลิงก์ไปหน้านั้นในชุดการ์ดของหน้า “ระบบงานภายใน”
 * (การ์ดหน้าตาเหมือนการ์ดอื่นในชุด) และเลิกแสดงเครื่องมือต่อท้ายหน้านั้น
 */
defined( 'ABSPATH' ) || exit;

/** หน้าเครื่องมือที่มีอยู่แล้ว (หน้าที่มีบล็อก / shortcode ของเครื่องมือ) */
function idw_lnk_tool_page() {
	$p = get_page_by_path( 'qr-code' );
	if ( $p && 'trash' !== $p->post_status ) {
		return $p;
	}
	global $wpdb;
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$id = (int) $wpdb->get_var( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status IN ('publish','private') AND ( post_content LIKE '%wp:idw/link-tools%' OR post_content LIKE '%[idw_link_tools%' OR post_content LIKE '%[idw_qr%' ) ORDER BY ID LIMIT 1" );
	return $id ? get_post( $id ) : null;
}

/** ชุดการ์ดบริการที่แสดงในหน้านั้น (id ชุด) หรือ '' */
function idw_lnk_cards_set_of( $page ) {
	if ( ! $page || ! function_exists( 'idw_svc_sets' ) ) {
		return '';
	}
	$ids = wp_list_pluck( idw_svc_sets(), 'id' );
	$c   = (string) $page->post_content;
	if ( preg_match_all( '/(?:"set"\s*:\s*"|\bset\s*=\s*["\']?)([a-z0-9_-]+)/i', $c, $m ) ) {
		foreach ( $m[1] as $id ) {
			if ( in_array( $id, $ids, true ) ) {
				return $id;
			}
		}
	}
	// a block / shortcode without a set shows the default set
	if ( preg_match( '/wp:idw\/services|\[idw_(services|cards)/', $c ) ) {
		return function_exists( 'idw_svc_get' ) ? (string) ( idw_svc_get( '' )['id'] ?? '' ) : '';
	}
	// set named after the page
	foreach ( idw_svc_sets() as $s ) {
		if ( get_the_title( $page ) === $s['name'] || get_the_title( $page ) === ( $s['title']['th'] ?? '' ) ) {
			return $s['id'];
		}
	}
	return '';
}

/**
 * ทำทั้งหมด · คืน [ 'page' => id, 'made' => bool, 'set' => id|'', 'card' => 'added'|'had'|'' ]
 */
function idw_lnk_setup_tools_page() {
	$res  = array( 'page' => 0, 'made' => false, 'set' => '', 'card' => '' );
	$page = idw_lnk_tool_page();
	if ( ! $page ) {
		$id = wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => 'สร้าง QR Code และย่อลิงก์',
			'post_name'    => 'qr-code',
			'post_content' => "<!-- wp:paragraph -->\n<p>ย่อลิงก์ยาวให้สั้น และสร้าง QR Code ใส่โลโก้ ดาวน์โหลดไปใช้ในเอกสาร โปสเตอร์ หรือป้ายประชาสัมพันธ์ได้ทันที — QR Code สร้างในเครื่องของคุณ รูปโลโก้ไม่ถูกส่งขึ้นเว็บ</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:idw/link-tools {\"align\":\"wide\"} /-->",
			'comment_status' => 'closed',
		), true );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$page        = get_post( $id );
		$res['made'] = true;
	}
	$res['page'] = $page->ID;
	$url         = get_permalink( $page );

	$staff = idw_lnk_guess_page( 'tools' );
	$set   = idw_lnk_cards_set_of( $staff );
	if ( $set && function_exists( 'idw_svc_get' ) && function_exists( 'idw_svc_put' ) ) {
		$s           = idw_svc_get( $set );
		$res['set']  = $set;
		$path        = wp_parse_url( $url, PHP_URL_PATH );
		foreach ( $s['items'] as $it ) {
			$u = (string) ( $it['url'] ?? '' );
			if ( $u && ( $u === $url || rawurldecode( (string) wp_parse_url( $u, PHP_URL_PATH ) ) === rawurldecode( (string) $path ) ) ) {
				$res['card'] = 'had';
			}
		}
		if ( ! $res['card'] ) {
			$last = $s['items'] ? end( $s['items'] ) : array();
			$s['items'][] = array(
				'icon'      => 'qr',
				'tone'      => 'indigo',
				'imageMode' => 'icon',
				'title'     => array( 'th' => 'QR Code และย่อลิงก์', 'en' => 'QR Code & Short Link' ),
				'text'      => array( 'th' => 'สร้าง QR Code ใส่โลโก้ และย่อลิงก์ยาวให้สั้น', 'en' => 'Make QR codes with a logo and shorten long links' ),
				'url'       => $url,
				'link'      => $last['link'] ?? array( 'th' => '', 'en' => '' ), // the same button text as the other cards
				'on'        => true,
			);
			idw_svc_put( $s );
			$res['card'] = 'added';
		}
	}
	// the tools now live on their own page
	$o = idw_lnk_opts();
	if ( $staff && (int) $o['tools_page'] === $staff->ID ) {
		$o['tools_page'] = 0;
		update_option( 'idw_links_opts', $o );
	}
	do_action( 'litespeed_purge_all' );
	if ( function_exists( 'idw_sec_log' ) ) {
		idw_sec_log( 'settings', 'ตั้งหน้า QR Code และย่อลิงก์ (' . $url . ')' . ( 'added' === $res['card'] ? ' + การ์ดในชุด ' . $set : '' ) );
	}
	return $res;
}

add_action( 'admin_post_idw_lnk_setup', function () {
	idw_lnk_check( 'idw_lnk_setup', 'manage_options' );
	$r = idw_lnk_setup_tools_page();
	if ( is_wp_error( $r ) ) {
		set_transient( 'idw_lnk_err_' . get_current_user_id(), $r->get_error_message(), 60 );
		idw_lnk_back( array( 'tab' => 'settings', 'msg' => 'err' ) );
	}
	set_transient( 'idw_lnk_setup_' . get_current_user_id(), $r, 300 );
	idw_lnk_back( array( 'tab' => 'settings', 'msg' => 'setup' ) );
} );

/** กล่องบนแท็บตั้งค่า */
function idw_lnk_setup_box() {
	$tool  = idw_lnk_tool_page();
	$staff = idw_lnk_guess_page( 'tools' );
	$set   = idw_lnk_cards_set_of( $staff );
	$has   = false;
	if ( $tool && $set ) {
		$s = idw_svc_get( $set );
		foreach ( (array) ( $s['items'] ?? array() ) as $it ) {
			$has = $has || ( ! empty( $it['url'] ) && rawurldecode( (string) wp_parse_url( $it['url'], PHP_URL_PATH ) ) === rawurldecode( (string) wp_parse_url( get_permalink( $tool ), PHP_URL_PATH ) ) );
		}
	}
	$o    = idw_lnk_opts();
	$done = $tool && ( ! $staff || ! $set || $has ) && ! ( $staff && (int) $o['tools_page'] === $staff->ID );
	if ( $done ) {
		echo '<div class="idw-lnk-hero is-done"><div><b>หน้าเครื่องมือ: <a href="' . esc_url( get_permalink( $tool ) ) . '" target="_blank">' . esc_html( get_the_title( $tool ) ) . ' ↗</a></b><p>'
			. ( $has ? 'มีการ์ดลิงก์ไปหน้านี้ในหน้า “' . esc_html( get_the_title( $staff ) ) . '” แล้ว — แก้ชื่อ ไอคอน หรือสีการ์ดได้ที่เมนู การ์ดบริการ' : 'วางลิงก์ไปหน้านี้ในเมนูหรือหน้าอื่นได้ตามต้องการ' )
			. '</p></div><a class="button" href="' . esc_url( get_edit_post_link( $tool ) ) . '">แก้หน้านี้</a></div>';
		return;
	}
	$steps = array();
	$steps[] = $tool ? 'ใช้หน้า “' . esc_html( get_the_title( $tool ) ) . '” ที่มีอยู่' : 'สร้างหน้าใหม่ “สร้าง QR Code และย่อลิงก์” (' . esc_html( home_url( '/qr-code/' ) ) . ')';
	if ( $staff && $set ) {
		$steps[] = 'เพิ่มการ์ด “QR Code และย่อลิงก์” ต่อท้ายการ์ดในหน้า “' . esc_html( get_the_title( $staff ) ) . '” หน้าตาเหมือนการ์ดอื่น (ชุด ' . esc_html( idw_svc_get( $set )['name'] ?? $set ) . ')';
	} elseif ( $staff ) {
		$steps[] = 'หน้า “' . esc_html( get_the_title( $staff ) ) . '” ไม่ได้ใช้การ์ดบริการ — วางลิงก์ไปหน้าใหม่เองหลังกดปุ่ม';
	}
	if ( $staff && (int) $o['tools_page'] === $staff->ID ) {
		$steps[] = 'เลิกแสดงเครื่องมือต่อท้ายหน้า “' . esc_html( get_the_title( $staff ) ) . '”';
	}
	echo '<div class="idw-lnk-hero"><div><b>แยกเครื่องมือไปไว้หน้าของตัวเอง</b><ol><li>' . implode( '</li><li>', $steps ) . '</li></ol><p class="description">เนื้อหาอื่นของหน้าเดิมไม่เปลี่ยน · ลบการ์ดหรือหน้าที่สร้างได้ภายหลัง</p></div>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above
		. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' . wp_nonce_field( 'idw_lnk_setup', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="idw_lnk_setup"><button class="button button-primary button-hero">ทำเลย</button></form></div>';
}
