<?php
/** หลังบ้าน: เมนู “ลิงก์ QR และเอกสาร” — รายการเอกสาร · ลิงก์ย่อ · QR Code · ตั้งค่า */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_menu_page( 'ลิงก์ QR และเอกสาร', 'ลิงก์ QR และเอกสาร', 'edit_posts', 'idw-links', 'idw_lnk_page', 'dashicons-admin-links', 23 );
} );
add_action( 'load-toplevel_page_idw-links', function () {
	global $title;
	$title = 'ลิงก์ QR และเอกสาร'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- the program-mode menu may hide this item
} );

function idw_lnk_tab() {
	$t = sanitize_key( $_GET['tab'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$tabs = idw_lnk_tabs();
	return isset( $tabs[ $t ] ) ? $t : array_key_first( $tabs );
}
function idw_lnk_tabs() {
	$t = array();
	if ( current_user_can( 'edit_pages' ) ) {
		$t['docs'] = 'รายการเอกสาร';
	}
	$t['short'] = 'ย่อลิงก์';
	$t['qr']    = 'QR Code';
	if ( current_user_can( 'manage_options' ) ) {
		$t['settings'] = 'ตั้งค่า';
	}
	return $t;
}
function idw_lnk_url( $args = array() ) {
	return add_query_arg( $args, admin_url( 'admin.php?page=idw-links' ) );
}
function idw_lnk_back( $args ) {
	wp_safe_redirect( idw_lnk_url( $args ) );
	exit;
}
function idw_lnk_check( $action, $cap ) {
	if ( ! current_user_can( $cap ) || ! check_admin_referer( $action ) ) {
		wp_die( 'ไม่มีสิทธิ์', 403 );
	}
}

add_action( 'admin_enqueue_scripts', function () {
	if ( 'idw-links' !== ( $_GET['page'] ?? '' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	wp_enqueue_style( 'idw-links' );
	wp_enqueue_style( 'idw-links-admin', IDW_LNK_URL . 'assets/admin.css', array( 'idw-links' ), IDW_LNK_VER );
	if ( 'docs' === idw_lnk_tab() ) {
		wp_enqueue_media();
		wp_enqueue_script( 'idw-links-admin', IDW_LNK_URL . 'assets/admin.js', array( 'jquery', 'jquery-ui-sortable' ), IDW_LNK_VER, true );
		$all = idw_docs_all();
		$cur = sanitize_key( $_GET['list'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$d   = ( $cur && isset( $all[ $cur ] ) ) ? $all[ $cur ] : ( $all ? reset( $all ) : null );
		wp_localize_script( 'idw-links-admin', 'IDW_DOCS', array( 'data' => $d ) );
	}
} );

/* ---------- actions: document lists ---------- */
add_action( 'admin_post_idw_docs_save', function () {
	idw_lnk_check( 'idw_docs_save', 'edit_pages' );
	$d = json_decode( wp_unslash( $_POST['json'] ?? '' ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- idw_docs_clean() sanitises every field
	if ( ! is_array( $d ) ) {
		idw_lnk_back( array( 'tab' => 'docs', 'msg' => 'bad' ) );
	}
	$s = idw_docs_save( $d );
	if ( function_exists( 'idw_sec_log' ) ) {
		idw_sec_log( 'settings', 'แก้รายการเอกสาร “' . $s['name'] . '” (' . idw_docs_count( $s ) . ' รายการ)' );
	}
	idw_lnk_back( array( 'tab' => 'docs', 'list' => $s['id'], 'msg' => 'saved' ) );
} );
add_action( 'admin_post_idw_docs_new', function () {
	idw_lnk_check( 'idw_docs_new', 'edit_pages' );
	$name = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ) ?: 'รายการเอกสาร';
	$s    = idw_docs_save( idw_docs_blank( $name ) );
	idw_lnk_back( array( 'tab' => 'docs', 'list' => $s['id'] ) );
} );
add_action( 'admin_post_idw_docs_delete', function () {
	idw_lnk_check( 'idw_docs_delete', 'edit_pages' );
	$id  = sanitize_key( $_POST['id'] ?? '' );
	$all = idw_docs_all();
	unset( $all[ $id ] );
	update_option( 'idw_docs', $all, false );
	do_action( 'litespeed_purge_all' );
	idw_lnk_back( array( 'tab' => 'docs', 'msg' => 'deleted' ) );
} );
add_action( 'admin_post_idw_docs_import', function () {
	idw_lnk_check( 'idw_docs_import', 'edit_pages' );
	$pid = absint( $_POST['page_id'] ?? 0 );
	$r   = idw_docs_import_page( $pid );
	if ( is_wp_error( $r ) ) {
		idw_lnk_back( array( 'tab' => 'docs', 'msg' => 'nopage' ) );
	}
	if ( ! $r['n'] ) {
		idw_lnk_back( array( 'tab' => 'docs', 'msg' => 'nolinks', 'src' => $r['src'] ) );
	}
	$into = sanitize_key( $_POST['into'] ?? '' );
	$d    = $into ? idw_docs_get( $into ) : null;
	if ( $d ) {
		$d['groups'] = array_merge( $d['groups'][0]['items'] || '' !== $d['groups'][0]['title'] ? $d['groups'] : array(), $r['groups'] );
	} else {
		$d         = idw_docs_blank( $r['title'] );
		$d['groups'] = $r['groups'];
		$d['page'] = $pid; // ready to show on that page; shown only after the admin picks how
	}
	$s = idw_docs_save( $d );
	idw_lnk_back( array( 'tab' => 'docs', 'list' => $s['id'], 'msg' => 'imported', 'n' => $r['n'] ) );
} );

/* ---------- actions: short links ---------- */
function idw_lnk_can_edit( $row ) {
	return $row && ( current_user_can( 'edit_others_posts' ) || (int) $row['created_by'] === get_current_user_id() );
}
add_action( 'admin_post_idw_short_new', function () {
	idw_lnk_check( 'idw_short_new', 'edit_posts' );
	$r = idw_lnk_create( wp_unslash( $_POST['url'] ?? '' ), sanitize_text_field( wp_unslash( $_POST['code'] ?? '' ) ), sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- checked in idw_lnk_check_url()
	if ( is_wp_error( $r ) ) {
		set_transient( 'idw_lnk_err_' . get_current_user_id(), $r->get_error_message(), 60 );
		idw_lnk_back( array( 'tab' => 'short', 'msg' => 'err' ) );
	}
	idw_lnk_back( array( 'tab' => 'short', 'msg' => 'made', 'code' => $r['code'] ) );
} );
add_action( 'admin_post_idw_short_edit', function () {
	idw_lnk_check( 'idw_short_edit', 'edit_posts' );
	global $wpdb;
	$row = idw_lnk_get( sanitize_text_field( wp_unslash( $_POST['code'] ?? '' ) ) );
	if ( ! idw_lnk_can_edit( $row ) ) {
		wp_die( 'ไม่มีสิทธิ์แก้ลิงก์นี้', 403 );
	}
	if ( isset( $_POST['delete'] ) ) {
		$wpdb->delete( idw_lnk_table(), array( 'id' => $row['id'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		idw_lnk_back( array( 'tab' => 'short', 'msg' => 'deleted' ) );
	}
	$url = idw_lnk_check_url( wp_unslash( $_POST['url'] ?? '' ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	if ( is_wp_error( $url ) ) {
		set_transient( 'idw_lnk_err_' . get_current_user_id(), $url->get_error_message(), 60 );
		idw_lnk_back( array( 'tab' => 'short', 'msg' => 'err' ) );
	}
	$wpdb->update( idw_lnk_table(), array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		'url'    => $url,
		'title'  => mb_substr( sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) ), 0, 190 ),
		'on_off' => empty( $_POST['on'] ) ? 0 : 1,
	), array( 'id' => $row['id'] ) );
	idw_lnk_back( array( 'tab' => 'short', 'msg' => 'updated', 'code' => $row['code'] ) );
} );

/* ---------- actions: settings ---------- */
add_action( 'admin_post_idw_lnk_settings', function () {
	idw_lnk_check( 'idw_lnk_settings', 'manage_options' );
	idw_lnk_save_opts( wp_unslash( $_POST ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- every field is checked in idw_lnk_save_opts()
	do_action( 'litespeed_purge_all' );
	idw_lnk_back( array( 'tab' => 'settings', 'msg' => 'saved' ) );
} );
add_action( 'admin_post_idw_lnk_quick', function () {
	idw_lnk_check( 'idw_lnk_quick', 'manage_options' );
	$p = idw_lnk_guess_page( 'tools' );
	if ( $p ) {
		$o               = idw_lnk_opts();
		$o['tools_page'] = $p->ID;
		update_option( 'idw_links_opts', $o );
		do_action( 'litespeed_purge_post', $p->ID );
	}
	idw_lnk_back( array( 'tab' => 'settings', 'msg' => $p ? 'placed' : 'nopage' ) );
} );

/* ---------- page ---------- */
function idw_lnk_notice() {
	$m = sanitize_key( $_GET['msg'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$t = array(
		'saved'    => array( 'success', 'บันทึกแล้ว — หน้าเว็บแสดงตามนี้ทันที' ),
		'deleted'  => array( 'success', 'ลบแล้ว' ),
		'imported' => array( 'success', 'ดึงลิงก์จากหน้าเดิมมา ' . absint( $_GET['n'] ?? 0 ) . ' รายการ — ตรวจชื่อ ลบที่ไม่ต้องการ แล้วเลือก “แสดงในหน้า” ด้านล่าง กดบันทึก' ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		'nolinks'  => array( 'warning', 'ไม่พบลิงก์ในหน้านั้น' . ( 'elementor' === ( $_GET['src'] ?? '' ) ? ' (หน้า Elementor: เปิดใช้ปลั๊กอิน Elementor ไว้ก่อนแล้วลองใหม่)' : '' ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		'nopage'   => array( 'error', 'ไม่พบหน้านี้' ),
		'bad'      => array( 'error', 'ข้อมูลไม่ครบ ลองบันทึกอีกครั้ง' ),
		'made'     => array( 'success', 'สร้างลิงก์ย่อแล้ว' ),
		'updated'  => array( 'success', 'แก้ลิงก์ย่อแล้ว' ),
		'placed'   => array( 'success', 'แสดงเครื่องมือ QR Code และย่อลิงก์ท้ายหน้า “' . ( idw_lnk_guess_page( 'tools' ) ? get_the_title( idw_lnk_guess_page( 'tools' ) ) : '' ) . '” แล้ว' ),
		'err'      => array( 'error', (string) get_transient( 'idw_lnk_err_' . get_current_user_id() ) ),
		'setup'    => array( 'success', idw_lnk_setup_msg() ),
	);
	if ( isset( $t[ $m ] ) && '' !== $t[ $m ][1] ) {
		echo '<div class="notice notice-' . esc_attr( $t[ $m ][0] ) . ' is-dismissible"><p>' . esc_html( $t[ $m ][1] ) . '</p></div>';
	}
}

function idw_lnk_page() {
	$tab = idw_lnk_tab();
	echo '<div class="wrap idw-lnk-wrap"><h1>ลิงก์ QR และเอกสาร</h1>';
	idw_lnk_notice();
	echo '<nav class="nav-tab-wrapper idw-lnk-tabs">';
	foreach ( idw_lnk_tabs() as $k => $v ) {
		echo '<a class="nav-tab' . ( $k === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( idw_lnk_url( array( 'tab' => $k ) ) ) . '">' . esc_html( $v ) . '</a>';
	}
	echo '</nav>';
	call_user_func( 'idw_lnk_tab_' . $tab );
	echo '</div>';
}

function idw_lnk_pages_select( $name, $sel, $empty = '— เลือกหน้า —' ) {
	return wp_dropdown_pages( array( 'name' => $name, 'selected' => (int) $sel, 'show_option_none' => $empty, 'option_none_value' => 0, 'echo' => 0, 'post_status' => array( 'publish', 'private' ) ) );
}

function idw_lnk_tab_docs() {
	$all = idw_docs_all();
	$cur = sanitize_key( $_GET['list'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$d   = ( $cur && isset( $all[ $cur ] ) ) ? $all[ $cur ] : ( $all ? reset( $all ) : null );
	$g   = idw_lnk_guess_page( 'docs' );
	$used = array();
	foreach ( $all as $x ) {
		$used[ (int) $x['page'] ] = 1;
	}
	if ( $g && ! isset( $used[ $g->ID ] ) ) {
		echo '<div class="idw-lnk-hero"><div><b>พบหน้า “' . esc_html( get_the_title( $g ) ) . '”</b><p>ดึงลิงก์ทุกอันจากหน้านี้มาเป็นรายการที่เพิ่ม ลบ และลากเรียงได้ง่าย แยกหมวดตามหัวข้อในหน้า — หน้าเดิมยังไม่เปลี่ยนจนกว่าคุณจะเลือกให้แสดง</p></div>'
			. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' . wp_nonce_field( 'idw_docs_import', '_wpnonce', true, false )
			. '<input type="hidden" name="action" value="idw_docs_import"><input type="hidden" name="page_id" value="' . (int) $g->ID . '"><button class="button button-primary button-hero">ดึงลิงก์จากหน้านี้</button></form></div>';
	}
	echo '<div class="idw-lnk-lists">';
	foreach ( $all as $x ) {
		$on = $d && $x['id'] === $d['id'];
		echo '<a class="idw-lnk-pill' . ( $on ? ' is-on' : '' ) . '" href="' . esc_url( idw_lnk_url( array( 'tab' => 'docs', 'list' => $x['id'] ) ) ) . '">' . esc_html( $x['name'] ) . ' <small>' . (int) idw_docs_count( $x ) . '</small></a>';
	}
	echo '<details class="idw-lnk-add"><summary class="button">+ รายการใหม่</summary><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' . wp_nonce_field( 'idw_docs_new', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="idw_docs_new"><input type="text" name="name" placeholder="ชื่อรายการ เช่น แบบฟอร์มงานบุคคล" required> <button class="button button-primary">สร้าง</button></form></details>';
	echo '<details class="idw-lnk-add"><summary class="button">ดึงลิงก์จากหน้า…</summary><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' . wp_nonce_field( 'idw_docs_import', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="idw_docs_import">'
		. idw_lnk_pages_select( 'page_id', 0 ) . ' <select name="into"><option value="">เป็นรายการใหม่</option>';
	foreach ( $all as $x ) {
		echo '<option value="' . esc_attr( $x['id'] ) . '">ต่อท้ายรายการ “' . esc_html( $x['name'] ) . '”</option>';
	}
	echo '</select> <button class="button button-primary">ดึงลิงก์</button><p class="description">หัวข้อในหน้ากลายเป็นหมวด ลิงก์กลายเป็นรายการ — ใช้ได้กับหน้า Elementor · ไม่แก้หน้าเดิม</p></form></details>';
	echo '</div>';

	if ( ! $d ) {
		echo '<div class="idw-lnk-empty"><p>ยังไม่มีรายการเอกสาร — กด <b>+ รายการใหม่</b> หรือ <b>ดึงลิงก์จากหน้า…</b></p></div>';
		return;
	}
	?>
	<form id="idw-docs-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wp_nonce_field( 'idw_docs_save' ); ?>
		<input type="hidden" name="action" value="idw_docs_save">
		<input type="hidden" name="json" id="idw-docs-json">
		<div class="idw-de">
			<div class="idw-de__main">
				<div class="idw-de__name"><label>ชื่อรายการ <input type="text" id="idw-de-name" class="regular-text" value="<?php echo esc_attr( $d['name'] ); ?>"></label></div>
				<div id="idw-de-groups" class="idw-de__groups" aria-live="polite"></div>
				<p><button type="button" class="button" id="idw-de-addgroup">+ เพิ่มหมวด</button></p>
			</div>
			<aside class="idw-de__side">
				<div class="idw-de__box">
					<h3>แสดงในหน้า</h3>
					<p><?php echo idw_lnk_pages_select( 'idw_page', $d['page'], '— ไม่แสดงอัตโนมัติ —' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
					<p><select id="idw-de-mode">
						<option value="" <?php selected( $d['mode'], '' ); ?>>ยังไม่แสดง</option>
						<option value="replace" <?php selected( $d['mode'], 'replace' ); ?>>แทนเนื้อหาเดิมของหน้า</option>
						<option value="before" <?php selected( $d['mode'], 'before' ); ?>>ด้านบนเนื้อหาเดิม</option>
						<option value="after" <?php selected( $d['mode'], 'after' ); ?>>ต่อท้ายเนื้อหาเดิม</option>
					</select></p>
					<p class="description">เนื้อหาเดิมของหน้าไม่ถูกแก้หรือลบ — เปลี่ยนกลับเป็น “ยังไม่แสดง” ได้ทุกเมื่อ<?php echo $d['page'] ? ' · <a href="' . esc_url( get_permalink( $d['page'] ) ) . '" target="_blank">ดูหน้า ↗</a>' : ''; ?></p>
					<p class="description">หรือวางในหน้าใดก็ได้: <code class="idw-lnk-copy" title="คลิกเพื่อคัดลอก">[idw_docs id="<?php echo esc_html( $d['id'] ); ?>"]</code> (Elementor: วิดเจ็ต Shortcode) หรือบล็อก “รายการเอกสาร”</p>
				</div>
				<div class="idw-de__box">
					<h3>การแสดงผล</h3>
					<p><label>รูปแบบ <select id="idw-de-layout">
						<option value="list" <?php selected( $d['layout'], 'list' ); ?>>รายการ (การ์ดแถวเดียว)</option>
						<option value="grid" <?php selected( $d['layout'], 'grid' ); ?>>การ์ด 2–3 คอลัมน์</option>
						<option value="compact" <?php selected( $d['layout'], 'compact' ); ?>>รายการแบบกระชับ</option>
					</select></label></p>
					<p><label>ช่องค้นหา <select id="idw-de-search">
						<option value="auto" <?php selected( $d['search'], 'auto' ); ?>>อัตโนมัติ (เมื่อมีมากกว่า 10)</option>
						<option value="on" <?php selected( $d['search'], 'on' ); ?>>แสดงเสมอ</option>
						<option value="off" <?php selected( $d['search'], 'off' ); ?>>ไม่แสดง</option>
					</select></label></p>
					<p><label><input type="checkbox" id="idw-de-meta" <?php checked( $d['meta'] ); ?>> แสดงชนิดไฟล์ ขนาด และวันที่</label></p>
					<p><label><input type="checkbox" id="idw-de-newtab" <?php checked( $d['newtab'] ); ?>> เปิดในแท็บใหม่</label></p>
				</div>
				<div class="idw-de__box idw-de__save">
					<button class="button button-primary button-large" id="idw-de-save">บันทึก</button>
					<span class="idw-de__dirty" hidden>มีการแก้ไขที่ยังไม่บันทึก</span>
				</div>
			</aside>
		</div>
	</form>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="idw-de__del" onsubmit="return confirm('ลบรายการ “<?php echo esc_js( $d['name'] ); ?>” ทั้งรายการ? (ไฟล์ในคลังสื่อไม่ถูกลบ)');">
		<?php wp_nonce_field( 'idw_docs_delete' ); ?>
		<input type="hidden" name="action" value="idw_docs_delete"><input type="hidden" name="id" value="<?php echo esc_attr( $d['id'] ); ?>">
		<button class="button-link button-link-delete">ลบรายการนี้</button>
	</form>
	<?php
	idw_lnk_copy_js();
}

function idw_lnk_tab_short() {
	global $wpdb;
	$t     = idw_lnk_table();
	$all   = current_user_can( 'edit_others_posts' );
	$s     = sanitize_text_field( wp_unslash( $_GET['s'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$pg    = max( 1, absint( $_GET['paged'] ?? 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$per   = 50;
	$where = '1=1';
	$args  = array();
	if ( ! $all ) {
		$where .= ' AND created_by = %d';
		$args[] = get_current_user_id();
	}
	if ( '' !== $s ) {
		$like   = '%' . $wpdb->esc_like( $s ) . '%';
		$where .= ' AND ( code LIKE %s OR url LIKE %s OR title LIKE %s )';
		array_push( $args, $like, $like, $like );
	}
	// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$total = (int) $wpdb->get_var( $args ? $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE $where", $args ) : "SELECT COUNT(*) FROM $t WHERE $where" );
	$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d", array_merge( $args, array( $per, ( $pg - 1 ) * $per ) ) ), ARRAY_A );
	// phpcs:enable
	$new = sanitize_text_field( wp_unslash( $_GET['code'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$o   = idw_lnk_opts();
	?>
	<div class="idw-lnk-grid">
		<form class="idw-lnk-card" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'idw_short_new' ); ?><input type="hidden" name="action" value="idw_short_new">
			<h2>สร้างลิงก์ย่อ</h2>
			<p><label>ลิงก์ปลายทาง<br><input type="url" name="url" class="large-text" required placeholder="https://…"></label></p>
			<p><label>รหัส (ไม่บังคับ — เว้นว่างให้สุ่ม)<br><span class="idw-lnk-prefix"><?php echo esc_html( preg_replace( '#^https?://#', '', idw_lnk_short_url( '' ) ) ); ?></span><input type="text" name="code" pattern="[A-Za-z0-9_\-]{2,40}" maxlength="40" placeholder="form-2569"></label></p>
			<p><label>ชื่อเรียก (สำหรับค้นหาในหลังบ้าน)<br><input type="text" name="title" class="large-text" maxlength="190"></label></p>
			<p><button class="button button-primary">สร้างลิงก์ย่อ</button></p>
			<?php if ( ! $o['staff_any'] ) : ?><p class="description">ย่อได้เฉพาะลิงก์ของ <?php echo esc_html( implode( ', ', $o['domains'] ) ); ?></p><?php endif; ?>
		</form>
		<div class="idw-lnk-card">
			<h2>ใช้งาน</h2>
			<p>ลิงก์ย่อเปิดแล้วพาไปปลายทางทันที นับจำนวนคลิก และ<b>เปลี่ยนปลายทางได้ภายหลัง</b> โดยลิงก์ย่อ / QR ที่พิมพ์ไปแล้วยังใช้ได้</p>
			<p>ให้ผู้ใช้ทั่วไปย่อลิงก์บนหน้าเว็บ: วาง <code class="idw-lnk-copy">[idw_link_tools]</code> หรือบล็อก “QR Code และย่อลิงก์” หรือเลือกหน้าที่แท็บ ตั้งค่า</p>
		</div>
	</div>
	<form method="get" class="idw-lnk-search"><input type="hidden" name="page" value="idw-links"><input type="hidden" name="tab" value="short"><input type="search" name="s" value="<?php echo esc_attr( $s ); ?>" placeholder="ค้นหารหัส ลิงก์ หรือชื่อ"> <button class="button">ค้นหา</button> <span class="description"><?php echo (int) $total; ?> ลิงก์<?php echo $all ? '' : ' (ของคุณ)'; ?></span></form>
	<div class="idw-lnk-table">
	<?php if ( ! $rows ) : ?>
		<p class="idw-lnk-empty">ยังไม่มีลิงก์ย่อ</p>
	<?php endif; ?>
	<?php foreach ( $rows as $r ) :
		$short = idw_lnk_short_url( $r['code'] );
		$u     = $r['created_by'] ? get_userdata( (int) $r['created_by'] ) : null;
		?>
		<details class="idw-lnk-row<?php echo $r['on_off'] ? '' : ' is-off'; ?>"<?php echo $new === $r['code'] ? ' open' : ''; ?>>
			<summary>
				<span class="idw-lnk-row__code"><b><?php echo esc_html( preg_replace( '#^https?://#', '', $short ) ); ?></b><?php echo $r['title'] ? '<small>' . esc_html( $r['title'] ) . '</small>' : ''; ?></span>
				<span class="idw-lnk-row__url" title="<?php echo esc_attr( $r['url'] ); ?>">→ <?php echo esc_html( $r['url'] ); ?></span>
				<span class="idw-lnk-row__n"><?php echo esc_html( number_format_i18n( (int) $r['clicks'] ) ); ?> คลิก<?php echo $r['on_off'] ? '' : ' · ปิด'; ?></span>
			</summary>
			<div class="idw-lnk-row__body">
				<p class="idw-lnk-row__acts">
					<button type="button" class="button idw-lnk-copy" data-copy="<?php echo esc_attr( $short ); ?>">คัดลอกลิงก์ย่อ</button>
					<a class="button" href="<?php echo esc_url( idw_lnk_url( array( 'tab' => 'qr', 'data' => rawurlencode( $short ) ) ) ); ?>">ทำ QR Code</a>
					<a class="button" href="<?php echo esc_url( $short ); ?>" target="_blank" rel="noopener">ทดสอบ ↗</a>
					<span class="description">สร้างโดย <?php echo esc_html( $u ? $u->display_name : 'ผู้ใช้ทั่วไป (หน้าเว็บ)' ); ?> · <?php echo esc_html( get_date_from_gmt( $r['created_at'], 'j M Y H:i' ) ); ?><?php echo $r['last_at'] ? ' · คลิกล่าสุด ' . esc_html( get_date_from_gmt( $r['last_at'], 'j M Y H:i' ) ) : ''; ?></span>
				</p>
				<?php if ( idw_lnk_can_edit( $r ) ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="idw-lnk-edit">
					<?php wp_nonce_field( 'idw_short_edit' ); ?><input type="hidden" name="action" value="idw_short_edit"><input type="hidden" name="code" value="<?php echo esc_attr( $r['code'] ); ?>">
					<label>ปลายทาง <input type="url" name="url" class="large-text" value="<?php echo esc_attr( $r['url'] ); ?>" required></label>
					<label>ชื่อเรียก <input type="text" name="title" class="regular-text" value="<?php echo esc_attr( $r['title'] ); ?>"></label>
					<label><input type="checkbox" name="on" value="1" <?php checked( (int) $r['on_off'] ); ?>> เปิดใช้งาน</label>
					<span><button class="button button-primary">บันทึก</button> <button class="button-link button-link-delete" name="delete" value="1" onclick="return confirm('ลบลิงก์ย่อนี้? ลิงก์และ QR ที่พิมพ์ไปแล้วจะใช้ไม่ได้');">ลบ</button></span>
				</form>
				<?php endif; ?>
			</div>
		</details>
	<?php endforeach; ?>
	</div>
	<?php
	$pages = (int) ceil( $total / $per );
	if ( $pages > 1 ) {
		echo '<p class="idw-lnk-pages">' . paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $pg, 'total' => $pages ) ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	idw_lnk_copy_js();
}

function idw_lnk_tab_qr() {
	$data = esc_url_raw( rawurldecode( (string) wp_unslash( $_GET['data'] ?? '' ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	echo '<p class="description">สร้าง QR Code ในเครื่องของคุณ (รูปโลโก้ไม่ถูกส่งขึ้นเว็บ) — ถ้าลิงก์ยาว ย่อลิงก์ก่อนจะสแกนง่ายกว่า</p>';
	echo idw_lnk_tools_html( array( 'show' => 'both', 'data' => $data ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

function idw_lnk_tab_settings() {
	$o  = idw_lnk_opts();
	$g  = idw_lnk_guess_page( 'tools' );
	$pc = get_page_by_path( $o['prefix'] );
	idw_lnk_setup_box();
	?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="idw-lnk-card idw-lnk-settings">
		<?php wp_nonce_field( 'idw_lnk_settings' ); ?><input type="hidden" name="action" value="idw_lnk_settings">
		<h2>แสดงเครื่องมือบนหน้าเว็บ</h2>
		<table class="form-table" role="presentation">
			<tr><th>หน้า</th><td><?php echo idw_lnk_pages_select( 'tools_page', $o['tools_page'], '— ไม่แสดงอัตโนมัติ —' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<select name="tools_pos"><option value="after" <?php selected( $o['tools_pos'], 'after' ); ?>>ต่อท้ายเนื้อหาเดิม</option><option value="before" <?php selected( $o['tools_pos'], 'before' ); ?>>ด้านบนเนื้อหาเดิม</option></select>
				<p class="description">หรือวาง <code class="idw-lnk-copy">[idw_link_tools]</code> · <code class="idw-lnk-copy">[idw_qr]</code> · <code class="idw-lnk-copy">[idw_shortlink]</code> ในหน้าใดก็ได้ (Elementor: วิดเจ็ต Shortcode)</p></td></tr>
			<tr><th>เครื่องมือ</th><td><select name="tools_show"><option value="both" <?php selected( $o['tools_show'], 'both' ); ?>>ย่อลิงก์ + QR Code</option><option value="qr" <?php selected( $o['tools_show'], 'qr' ); ?>>QR Code อย่างเดียว</option><option value="short" <?php selected( $o['tools_show'], 'short' ); ?>>ย่อลิงก์อย่างเดียว</option></select>
				<label><input type="checkbox" name="logo" value="1" <?php checked( $o['logo'] ); ?>> ปุ่ม “ใช้โลโก้เว็บ” ใน QR Code</label></td></tr>
		</table>
		<h2>ลิงก์ย่อ</h2>
		<table class="form-table" role="presentation">
			<tr><th>รูปแบบลิงก์</th><td><code><?php echo esc_html( home_url( '/' ) ); ?></code><input type="text" name="prefix" value="<?php echo esc_attr( $o['prefix'] ); ?>" pattern="[a-z0-9\-]{1,12}" size="6"><code>/รหัส</code>
				<p class="description">เปลี่ยนแล้ว ลิงก์ย่อ / QR ที่แจกไปแล้วจะใช้ไม่ได้</p>
				<?php if ( $pc ) : ?><p class="idw-lnk-warn">มีหน้า “<?php echo esc_html( get_the_title( $pc ) ); ?>” ที่ใช้ชื่อ /<?php echo esc_html( $o['prefix'] ); ?>/ อยู่ — เลือกคำอื่น</p><?php endif; ?></td></tr>
			<tr><th>บุคคลทั่วไป</th><td>
				<label><input type="radio" name="public" value="allow" <?php checked( $o['public'], 'allow' ); ?>> ย่อลิงก์บนหน้าเว็บได้ เฉพาะโดเมนในรายการ</label><br>
				<label><input type="radio" name="public" value="off" <?php checked( $o['public'], 'off' ); ?>> ย่อไม่ได้ (ต้องเข้าสู่ระบบ)</label>
				<p><textarea name="domains" rows="4" cols="40" placeholder="บรรทัดละโดเมน"><?php echo esc_textarea( implode( "\n", $o['domains'] ) ); ?></textarea></p>
				<p class="description">บรรทัดละโดเมน · ใส่ <code>go.th</code> = ทุกเว็บราชการ (.go.th) · กันคนนอกใช้ชื่อเว็บหน่วยงานย่อลิงก์ไปเว็บหลอกลวง</p>
				<p><label>ไม่เกิน <input type="number" name="rate" value="<?php echo (int) $o['rate']; ?>" min="1" max="500" class="small-text"> ลิงก์ต่อชั่วโมงต่อเครื่อง</label></p></td></tr>
			<tr><th>เจ้าหน้าที่</th><td><label><input type="checkbox" name="staff_any" value="1" <?php checked( $o['staff_any'] ); ?>> ผู้ที่เข้าสู่ระบบ (ผู้เขียนขึ้นไป) ย่อลิงก์ไปเว็บใดก็ได้ และตั้งรหัสเองได้</label></td></tr>
		</table>
		<p><button class="button button-primary">บันทึก</button></p>
	</form>
	<?php
	idw_lnk_copy_js();
}

function idw_lnk_copy_js() {
	?>
	<script>document.addEventListener('click',function(e){var c=e.target.closest('.idw-lnk-copy');if(!c)return;var t=c.getAttribute('data-copy')||c.textContent;if(navigator.clipboard){navigator.clipboard.writeText(t).then(function(){var o=c.textContent;if(c.tagName==='BUTTON'){c.textContent='คัดลอกแล้ว ✓';setTimeout(function(){c.textContent=o;},1500);}else{c.classList.add('is-copied');setTimeout(function(){c.classList.remove('is-copied');},1500);}});}});</script>
	<?php
}

function idw_lnk_setup_msg() {
	$r = get_transient( 'idw_lnk_setup_' . get_current_user_id() );
	if ( ! is_array( $r ) || empty( $r['page'] ) ) {
		return 'เรียบร้อย';
	}
	$m = ( $r['made'] ? 'สร้างหน้า “' : 'ใช้หน้า “' ) . get_the_title( $r['page'] ) . '” แล้ว';
	if ( 'added' === $r['card'] ) {
		$m .= ' · เพิ่มการ์ดลิงก์ในหน้าระบบงานภายในแล้ว';
	} elseif ( 'had' === $r['card'] ) {
		$m .= ' · หน้าระบบงานภายในมีการ์ดลิงก์อยู่แล้ว';
	} else {
		$m .= ' · วางลิงก์ไปหน้านี้ในหน้าที่ต้องการได้เลย';
	}
	return $m;
}
