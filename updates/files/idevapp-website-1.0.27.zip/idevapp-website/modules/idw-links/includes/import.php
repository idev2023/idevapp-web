<?php
/**
 * ดึงลิงก์จากหน้าเดิม (หน้าแบบบล็อก / Classic / Elementor) มาเป็นรายการเอกสาร
 * หัวข้อในหน้า (h1–h6, หัวข้อ Elementor, หัวแท็บ / accordion) → หมวด · ลิงก์ → รายการ · ไม่แก้หน้าเดิม
 */
defined( 'ABSPATH' ) || exit;

/** HTML ของหน้าเหมือนที่ผู้เข้าชมเห็น */
function idw_docs_page_html( $post ) {
	$html = '';
	$src  = 'content';
	if ( 'builder' === get_post_meta( $post->ID, '_elementor_edit_mode', true ) ) {
		$src = 'elementor';
		if ( class_exists( '\Elementor\Plugin' ) ) {
			try {
				$html = (string) \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $post->ID, true );
			} catch ( \Throwable $e ) {
				$html = '';
			}
		}
		if ( '' === trim( wp_strip_all_tags( $html ) ) ) {
			$html = idw_docs_elementor_html( (string) get_post_meta( $post->ID, '_elementor_data', true ) );
		}
	}
	if ( '' === trim( $html ) ) {
		$GLOBALS['post'] = $post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		setup_postdata( $post );
		$html = (string) apply_filters( 'the_content', $post->post_content ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
		wp_reset_postdata();
		if ( 'elementor' === $src && '' === trim( $html ) ) {
			$src = 'content';
		}
	}
	return array( $html, $src );
}

/** สำรอง: สร้าง HTML จากข้อมูล Elementor โดยตรง (เมื่อ Elementor ไม่ได้เปิดใช้) */
function idw_docs_elementor_html( $json ) {
	$data = json_decode( $json, true );
	if ( ! is_array( $data ) ) {
		return '';
	}
	$out  = '';
	$walk = function ( $els ) use ( &$walk, &$out ) {
		foreach ( (array) $els as $e ) {
			$s = (array) ( $e['settings'] ?? array() );
			$w = (string) ( $e['widgetType'] ?? '' );
			$u = function ( $l ) {
				return is_array( $l ) ? (string) ( $l['url'] ?? '' ) : (string) $l;
			};
			if ( 'heading' === $w ) {
				$link = $u( $s['link'] ?? '' );
				$out .= $link ? '<p><a href="' . esc_url( $link ) . '">' . esc_html( wp_strip_all_tags( (string) ( $s['title'] ?? '' ) ) ) . '</a></p>' : '<h3>' . esc_html( wp_strip_all_tags( (string) ( $s['title'] ?? '' ) ) ) . '</h3>';
			} elseif ( 'button' === $w ) {
				$out .= '<p><a href="' . esc_url( $u( $s['link'] ?? '' ) ) . '">' . esc_html( (string) ( $s['text'] ?? '' ) ) . '</a></p>';
			} elseif ( in_array( $w, array( 'icon-list', 'accordion', 'toggle', 'tabs' ), true ) ) {
				foreach ( (array) ( $s['icon_list'] ?? $s['tabs'] ?? array() ) as $it ) {
					if ( isset( $it['tab_title'] ) ) {
						$out .= '<h4>' . esc_html( wp_strip_all_tags( (string) $it['tab_title'] ) ) . '</h4>' . (string) ( $it['tab_content'] ?? '' );
					} else {
						$link = $u( $it['link'] ?? '' );
						$t    = esc_html( wp_strip_all_tags( (string) ( $it['text'] ?? '' ) ) );
						$out .= $link ? '<p><a href="' . esc_url( $link ) . '">' . $t . '</a></p>' : '<p>' . $t . '</p>';
					}
				}
			} else {
				foreach ( $s as $k => $v ) {
					if ( is_string( $v ) && false !== stripos( $v, '<a ' ) ) {
						$out .= $v;
					} elseif ( is_array( $v ) && ! empty( $v['url'] ) && preg_match( '/link|url|button/i', (string) $k ) ) {
						$t = '';
						foreach ( array( 'text', 'title', 'button_text', 'title_text', 'heading', 'caption' ) as $tk ) {
							if ( ! empty( $s[ $tk ] ) && is_string( $s[ $tk ] ) ) {
								$t = $s[ $tk ];
								break;
							}
						}
						$out .= '<p><a href="' . esc_url( (string) $v['url'] ) . '">' . esc_html( wp_strip_all_tags( $t ) ) . '</a></p>';
					}
				}
			}
			$walk( $e['elements'] ?? array() );
		}
	};
	$walk( $data );
	return $out;
}

function idw_docs_text( $s ) {
	return trim( preg_replace( '/\s+/u', ' ', html_entity_decode( (string) $s, ENT_QUOTES, 'UTF-8' ) ) );
}

/** แยกหมวดและลิงก์ตามลำดับในหน้า */
function idw_docs_parse_html( $html, $base ) {
	$groups = array( array( 'title' => '', 'items' => array() ) );
	if ( '' === trim( $html ) || ! class_exists( 'DOMDocument' ) ) {
		return $groups;
	}
	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML( '<?xml encoding="UTF-8"><div id="idw-root">' . $html . '</div>', LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING );
	libxml_clear_errors();
	$root = $doc->getElementById( 'idw-root' );
	if ( ! $root ) {
		return $groups;
	}
	$seen    = array();
	$generic = '/^(คลิก(ที่นี่|เพื่อ.*)?|ดาวน์โหลด|ดาวโหลด|download|โหลด|ดู|อ่าน(ต่อ|เพิ่มเติม)?|เปิด|รายละเอียด|click( here)?|read more|more|link|ลิงก์|ลิ้งค์|pdf|\.\.\.|>>|»)$/iu';
	$is_head = function ( DOMElement $n ) {
		if ( preg_match( '/^h[1-6]$/i', $n->nodeName ) ) {
			return true;
		}
		$c = ' ' . $n->getAttribute( 'class' ) . ' ';
		return (bool) preg_match( '/ (elementor-heading-title|elementor-tab-title|elementor-accordion-title|elementor-toggle-title|e-n-accordion-item-title-text|elementor-tab-desktop-title) /', $c );
	};
	$walk = function ( DOMNode $n ) use ( &$walk, &$groups, &$seen, $generic, $is_head, $base ) {
		foreach ( iterator_to_array( $n->childNodes ) as $ch ) {
			if ( ! $ch instanceof DOMElement ) {
				continue;
			}
			if ( in_array( strtolower( $ch->nodeName ), array( 'script', 'style', 'noscript', 'svg', 'form', 'nav' ), true ) ) {
				continue;
			}
			// mobile copies of tab titles
			if ( false !== strpos( ' ' . $ch->getAttribute( 'class' ) . ' ', ' elementor-tab-mobile-title ' ) ) {
				continue;
			}
			if ( 'a' === strtolower( $ch->nodeName ) ) {
				$href = trim( $ch->getAttribute( 'href' ) );
				if ( '' === $href || '#' === $href[0] || preg_match( '/^(javascript|data|tel|mailto):/i', $href ) ) {
					continue;
				}
				if ( ! preg_match( '#^https?://#i', $href ) ) {
					$href = 0 === strpos( $href, '//' ) ? 'https:' . $href : WP_Http::make_absolute_url( $href, $base );
				}
				$text = idw_docs_text( $ch->textContent );
				if ( '' === $text ) {
					foreach ( $ch->getElementsByTagName( 'img' ) as $img ) {
						$text = idw_docs_text( $img->getAttribute( 'alt' ) ?: $img->getAttribute( 'title' ) );
						break;
					}
				}
				if ( '' === $text || preg_match( $generic, $text ) ) {
					// a generic “download” button: use the text of its row / item / paragraph
					for ( $p = $ch->parentNode; $p && $p instanceof DOMElement && 'idw-root' !== $p->getAttribute( 'id' ); $p = $p->parentNode ) {
						if ( in_array( strtolower( $p->nodeName ), array( 'tr', 'li', 'p', 'dd', 'figure' ), true ) || preg_match( '/elementor-widget-wrap|elementor-icon-box-wrapper|elementor-image-box-wrapper/', $p->getAttribute( 'class' ) ) ) {
							$row = idw_docs_text( str_replace( $ch->textContent, ' ', $p->textContent ) );
							if ( '' !== $row ) {
								$text = mb_substr( $row, 0, 200 );
							}
							break;
						}
					}
				}
				if ( '' === $text ) {
					$text = rawurldecode( wp_basename( (string) wp_parse_url( $href, PHP_URL_PATH ) ) );
				}
				$key = $href . '|' . $text;
				if ( '' !== $text && ! isset( $seen[ $key ] ) ) {
					$seen[ $key ] = 1;
					$groups[ count( $groups ) - 1 ]['items'][] = array( 't' => mb_substr( $text, 0, 300 ), 'url' => esc_url_raw( $href ) );
				}
				continue;
			}
			if ( $is_head( $ch ) && 0 === $ch->getElementsByTagName( 'a' )->length ) {
				$t = idw_docs_text( $ch->textContent );
				if ( '' !== $t ) {
					if ( ! $groups[ count( $groups ) - 1 ]['items'] ) {
						$groups[ count( $groups ) - 1 ]['title'] = mb_substr( $t, 0, 200 ); // headings right after one another: keep the closest
					} else {
						$groups[] = array( 'title' => mb_substr( $t, 0, 200 ), 'items' => array() );
					}
				}
				continue;
			}
			$walk( $ch );
		}
	};
	$walk( $root );
	$groups = array_values( array_filter( $groups, function ( $g ) {
		return (bool) $g['items'];
	} ) );
	return $groups ? $groups : array( array( 'title' => '', 'items' => array() ) );
}

/** ลิงก์ไฟล์ในคลังสื่อของเว็บนี้ → ผูกกับไฟล์ (รู้ขนาดไฟล์ เปลี่ยนไฟล์ได้ภายหลัง) */
function idw_docs_link_media( $groups ) {
	foreach ( $groups as &$g ) {
		foreach ( $g['items'] as &$it ) {
			$id = attachment_url_to_postid( $it['url'] );
			if ( $id ) {
				$it['att'] = $id;
			}
		}
	}
	return $groups;
}

function idw_docs_import_page( $page_id ) {
	$post = get_post( $page_id );
	if ( ! $post || ! in_array( $post->post_type, array( 'page', 'post' ), true ) ) {
		return new WP_Error( 'page', 'ไม่พบหน้านี้' );
	}
	list( $html, $src ) = idw_docs_page_html( $post );
	$groups = idw_docs_link_media( idw_docs_parse_html( $html, get_permalink( $post ) ) );
	$n      = 0;
	foreach ( $groups as $g ) {
		$n += count( $g['items'] );
	}
	return array( 'groups' => $groups, 'n' => $n, 'src' => $src, 'title' => get_the_title( $post ) );
}
