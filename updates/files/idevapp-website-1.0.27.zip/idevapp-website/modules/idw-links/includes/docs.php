<?php
/**
 * รายการดาวน์โหลดเอกสาร: หลายรายการ · แต่ละรายการมีหลายหมวด · แต่ละหมวดมีลิงก์ / ไฟล์
 * option idw_docs = [ id => [ id, name, groups => [ [ title, items => [ [ t, url, att, note, date, sz ] ] ] ], layout, search, meta, newtab, page, mode ] ]
 */
defined( 'ABSPATH' ) || exit;

function idw_docs_all() {
	$a = get_option( 'idw_docs', array() );
	return is_array( $a ) ? $a : array();
}

function idw_docs_get( $id ) {
	$a = idw_docs_all();
	if ( '' === (string) $id ) {
		return $a ? reset( $a ) : null;
	}
	return $a[ $id ] ?? null;
}

function idw_docs_blank( $name = 'ดาวน์โหลดเอกสาร' ) {
	return array(
		'id'     => '',
		'name'   => $name,
		'groups' => array( array( 'title' => '', 'items' => array() ) ),
		'layout' => 'list',
		'search' => 'auto',
		'meta'   => 1,
		'newtab' => 1,
		'page'   => 0,
		'mode'   => '',
	);
}

function idw_docs_new_id( $name ) {
	$all  = idw_docs_all();
	$base = sanitize_key( remove_accents( $name ) );
	if ( ! $base || is_numeric( $base ) ) {
		$base = 'docs';
	}
	$id = $base;
	for ( $i = 2; isset( $all[ $id ] ); $i++ ) {
		$id = $base . '-' . $i;
	}
	return $id;
}

/** นามสกุลไฟล์จากลิงก์ (pdf docx xlsx …) หรือ '' สำหรับลิงก์เว็บ */
function idw_docs_ext( $url ) {
	$path = (string) wp_parse_url( (string) $url, PHP_URL_PATH );
	if ( preg_match( '/\.([a-z0-9]{2,5})$/i', $path, $m ) ) {
		$e = strtolower( $m[1] );
		if ( in_array( $e, array( 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'ppt', 'pptx', 'odt', 'ods', 'odp', 'zip', 'rar', '7z', 'jpg', 'jpeg', 'png', 'gif', 'webp', 'txt', 'rtf', 'mp4', 'mp3' ), true ) ) {
			return $e;
		}
	}
	$host = strtolower( (string) wp_parse_url( (string) $url, PHP_URL_HOST ) );
	if ( preg_match( '/(^|\.)docs\.google\.com$/', $host ) ) {
		if ( strpos( $url, '/spreadsheets/' ) ) {
			return 'gsheet';
		}
		if ( strpos( $url, '/forms/' ) ) {
			return 'gform';
		}
		return 'gdoc';
	}
	if ( 'forms.gle' === $host ) {
		return 'gform';
	}
	if ( preg_match( '/(^|\.)drive\.google\.com$/', $host ) ) {
		return 'drive';
	}
	return '';
}

/** [ ชื่อชนิด, สี, ป้ายสั้น ] */
function idw_docs_kind( $ext ) {
	$w = array( 'Word', '#2b579a', 'DOC' );
	$x = array( 'Excel', '#1d7044', 'XLS' );
	$p = array( 'PowerPoint', '#c43e1c', 'PPT' );
	$z = array( 'ไฟล์บีบอัด', '#6b5b95', 'ZIP' );
	$i = array( 'รูปภาพ', '#0e7490', 'IMG' );
	$map = array(
		'pdf' => array( 'PDF', '#d92d20', 'PDF' ),
		'doc' => $w, 'docx' => $w, 'odt' => $w, 'rtf' => $w, 'gdoc' => array( 'Google Docs', '#2b579a', 'DOC' ),
		'xls' => $x, 'xlsx' => $x, 'ods' => $x, 'csv' => array( 'CSV', '#1d7044', 'CSV' ), 'gsheet' => array( 'Google Sheets', '#1d7044', 'XLS' ),
		'ppt' => $p, 'pptx' => $p, 'odp' => $p,
		'zip' => $z, 'rar' => $z, '7z' => $z,
		'jpg' => $i, 'jpeg' => $i, 'png' => $i, 'gif' => $i, 'webp' => $i,
		'mp4' => array( 'วิดีโอ', '#7c3aed', 'VID' ), 'mp3' => array( 'เสียง', '#7c3aed', 'MP3' ), 'txt' => array( 'ข้อความ', '#475467', 'TXT' ),
		'gform' => array( 'แบบฟอร์มออนไลน์', '#673ab7', 'FORM' ), 'drive' => array( 'Google Drive', '#1a73e8', 'DRIVE' ),
	);
	return $map[ $ext ] ?? array( 'ลิงก์', '#475467', '↗' );
}

function idw_docs_size_label( $bytes ) {
	$bytes = (int) $bytes;
	return $bytes > 0 ? size_format( $bytes, $bytes >= MB_IN_BYTES ? 1 : 0 ) : '';
}

/** ข้อมูลจากหลังบ้าน (JSON) → ข้อมูลที่ปลอดภัย · เติมขนาดไฟล์ของไฟล์ในคลังสื่อ */
function idw_docs_clean( $d, $id = '' ) {
	$b   = idw_docs_blank();
	$out = array(
		'id'     => $id,
		'name'   => mb_substr( sanitize_text_field( (string) ( $d['name'] ?? '' ) ), 0, 120 ) ?: $b['name'],
		'groups' => array(),
		'layout' => in_array( $d['layout'] ?? '', array( 'list', 'grid', 'compact' ), true ) ? $d['layout'] : 'list',
		'search' => in_array( $d['search'] ?? '', array( 'auto', 'on', 'off' ), true ) ? $d['search'] : 'auto',
		'meta'   => empty( $d['meta'] ) ? 0 : 1,
		'newtab' => empty( $d['newtab'] ) ? 0 : 1,
		'page'   => absint( $d['page'] ?? 0 ),
		'mode'   => in_array( $d['mode'] ?? '', array( '', 'replace', 'before', 'after' ), true ) ? $d['mode'] : '',
	);
	foreach ( array_slice( (array) ( $d['groups'] ?? array() ), 0, 200 ) as $g ) {
		$items = array();
		foreach ( array_slice( (array) ( $g['items'] ?? array() ), 0, 1000 ) as $it ) {
			$att = absint( $it['att'] ?? 0 );
			$url = esc_url_raw( trim( (string) ( $it['url'] ?? '' ) ) );
			if ( $att && 'attachment' === get_post_type( $att ) ) {
				$url = (string) wp_get_attachment_url( $att );
			} else {
				$att = 0;
			}
			$t = mb_substr( sanitize_text_field( (string) ( $it['t'] ?? '' ) ), 0, 300 );
			if ( '' === $url && '' === $t ) {
				continue;
			}
			$sz = 0;
			if ( $att ) {
				$f  = get_attached_file( $att );
				$sz = ( $f && file_exists( $f ) ) ? (int) filesize( $f ) : 0;
			}
			$date = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $it['date'] ?? '' ) ) ? $it['date'] : '';
			$items[] = array(
				't'    => '' !== $t ? $t : wp_basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ),
				'url'  => $url,
				'att'  => $att,
				'note' => mb_substr( sanitize_text_field( (string) ( $it['note'] ?? '' ) ), 0, 300 ),
				'date' => $date,
				'sz'   => $sz,
				'off'  => empty( $it['off'] ) ? 0 : 1,
			);
		}
		$title = mb_substr( sanitize_text_field( (string) ( $g['title'] ?? '' ) ), 0, 200 );
		if ( $items || '' !== $title ) {
			$out['groups'][] = array( 'title' => $title, 'items' => $items );
		}
	}
	if ( ! $out['groups'] ) {
		$out['groups'] = $b['groups'];
	}
	return $out;
}

function idw_docs_save( $d ) {
	$all = idw_docs_all();
	$id  = (string) ( $d['id'] ?? '' );
	if ( '' === $id || ! isset( $all[ $id ] ) ) {
		$id = idw_docs_new_id( (string) ( $d['name'] ?? 'docs' ) );
	}
	$all[ $id ] = idw_docs_clean( $d, $id );
	// one list per page
	if ( $all[ $id ]['page'] && $all[ $id ]['mode'] ) {
		foreach ( $all as $k => $v ) {
			if ( $k !== $id && (int) $v['page'] === $all[ $id ]['page'] ) {
				$all[ $k ]['mode'] = '';
			}
		}
	}
	update_option( 'idw_docs', $all, false );
	// pages that show lists through a shortcode / block are not known here: clear the page cache
	do_action( 'litespeed_purge_all' );
	return $all[ $id ];
}

function idw_docs_count( $d ) {
	$n = 0;
	foreach ( (array) ( $d['groups'] ?? array() ) as $g ) {
		$n += count( (array) $g['items'] );
	}
	return $n;
}
