<?php
/**
 * หน้าเว็บ: เครื่องมือ QR / ย่อลิงก์ และรายการเอกสาร
 * [idw_link_tools show="both|qr|short"] · [idw_qr] · [idw_shortlink] · [idw_docs id="…"] · บล็อก idw/link-tools และ idw/docs
 * แสดงในหน้าที่เลือกไว้ให้อัตโนมัติ (ต่อท้าย / ด้านบน / แทนเนื้อหาเดิม) โดยไม่แก้เนื้อหาเดิมของหน้า — ใช้ได้กับหน้า Elementor
 */
defined( 'ABSPATH' ) || exit;

add_action( 'init', function () {
	wp_register_style( 'idw-links', IDW_LNK_URL . 'assets/links.css', array(), IDW_LNK_VER );
	wp_register_script( 'idw-qr-lib', IDW_LNK_URL . 'assets/qr-code-styling.js', array(), '1.9.2', true );
	wp_register_script( 'idw-link-tools', IDW_LNK_URL . 'assets/tools.js', array( 'idw-qr-lib' ), IDW_LNK_VER, true );
	wp_register_script( 'idw-docs', IDW_LNK_URL . 'assets/docs.js', array(), IDW_LNK_VER, true );

	wp_register_script( 'idw-links-block', IDW_LNK_URL . 'assets/block.js', array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render' ), IDW_LNK_VER, true );
	register_block_type( 'idw/link-tools', array(
		'editor_script'   => 'idw-links-block',
		'style'           => 'idw-links',
		'attributes'      => array( 'show' => array( 'type' => 'string', 'default' => 'both' ), 'className' => array( 'type' => 'string', 'default' => '' ) ),
		'render_callback' => function ( $a ) {
			return idw_lnk_tools_html( $a );
		},
	) );
	register_block_type( 'idw/docs', array(
		'editor_script'   => 'idw-links-block',
		'style'           => 'idw-links',
		'attributes'      => array( 'id' => array( 'type' => 'string', 'default' => '' ), 'head' => array( 'type' => 'boolean', 'default' => false ), 'className' => array( 'type' => 'string', 'default' => '' ) ),
		'render_callback' => function ( $a ) {
			return idw_docs_html( $a );
		},
	) );

	add_shortcode( 'idw_link_tools', function ( $a ) {
		return idw_lnk_tools_html( shortcode_atts( array( 'show' => 'both' ), $a ) );
	} );
	add_shortcode( 'idw_qr', function () {
		return idw_lnk_tools_html( array( 'show' => 'qr' ) );
	} );
	add_shortcode( 'idw_shortlink', function () {
		return idw_lnk_tools_html( array( 'show' => 'short' ) );
	} );
	add_shortcode( 'idw_docs', function ( $a ) {
		$a = shortcode_atts( array( 'id' => '', 'head' => '0' ), $a );
		return idw_docs_html( array( 'id' => $a['id'], 'head' => in_array( strtolower( (string) $a['head'] ), array( '1', 'true', 'yes' ), true ) ) );
	} );
} );

add_action( 'enqueue_block_editor_assets', function () {
	$sets = array();
	foreach ( idw_docs_all() as $d ) {
		$sets[] = array( 'id' => $d['id'], 'name' => $d['name'], 'n' => idw_docs_count( $d ) );
	}
	wp_localize_script( 'idw-links-block', 'IDW_LNK_EDITOR', array( 'sets' => $sets, 'admin' => admin_url( 'admin.php?page=idw-links' ) ) );
} );

function idw_lnk_site_logo() {
	$id  = (int) get_theme_mod( 'custom_logo' );
	$url = $id ? wp_get_attachment_image_url( $id, 'medium' ) : '';
	return $url ? $url : (string) get_site_icon_url( 256 );
}

/* ---------- QR + short link tool ---------- */
function idw_lnk_tools_html( $a ) {
	static $n = 0;
	$n++;
	$o     = idw_lnk_opts();
	$show  = in_array( $a['show'] ?? '', array( 'both', 'qr', 'short' ), true ) ? $a['show'] : 'both';
	$staff = is_user_logged_in() && current_user_can( 'edit_posts' );
	$can   = $staff || 'off' !== $o['public'];
	wp_enqueue_style( 'idw-links' );
	wp_enqueue_script( 'idw-link-tools' );
	static $loc = false;
	if ( ! $loc ) {
		$loc = true;
		wp_localize_script( 'idw-link-tools', 'IDW_LNK', array(
			'rest'    => esc_url_raw( rest_url( 'idw/v1/short' ) ),
			'nonce'   => $staff ? wp_create_nonce( 'wp_rest' ) : '',
			'staff'   => $staff ? 1 : 0,
			'can'     => $can ? 1 : 0,
			'domains' => ( $staff && $o['staff_any'] ) ? array() : array_values( $o['domains'] ),
			'logo'    => $o['logo'] ? idw_lnk_site_logo() : '',
			'login'   => wp_login_url( get_permalink() ?: home_url( '/' ) ),
			'name'    => sanitize_title( get_bloginfo( 'name' ) ) ?: 'qr',
		) );
	}
	$id  = 'idw-lt-' . $n;
	$cls = 'idw-lt idw-lt--' . $show;
	if ( ! empty( $a['className'] ) ) {
		$cls .= ' ' . implode( ' ', array_map( 'sanitize_html_class', preg_split( '/\s+/', (string) $a['className'] ) ) );
	}
	ob_start();
	?>
	<section class="<?php echo esc_attr( $cls ); ?>" id="<?php echo esc_attr( $id ); ?>" data-show="<?php echo esc_attr( $show ); ?>"><div class="idw-lt__wrap">
		<?php if ( 'qr' !== $show ) : ?>
		<div class="idw-lt__card idw-lt__short">
			<h3 class="idw-lt__h"><span aria-hidden="true">🔗</span> ย่อลิงก์</h3>
			<?php if ( $can ) : ?>
			<form class="idw-lt__form" data-role="short" novalidate>
				<label class="idw-lt__lbl" for="<?php echo esc_attr( $id ); ?>-url">ลิงก์ที่ต้องการย่อ</label>
				<input class="idw-lt__in" id="<?php echo esc_attr( $id ); ?>-url" type="url" inputmode="url" autocomplete="off" placeholder="https://…" required>
				<?php if ( $staff ) : ?>
				<details class="idw-lt__more"><summary>ตั้งรหัสเอง (ไม่บังคับ)</summary>
					<div class="idw-lt__code"><span><?php echo esc_html( preg_replace( '#^https?://#', '', idw_lnk_short_url( '' ) ) ); ?></span><input class="idw-lt__in" type="text" data-role="code" maxlength="40" pattern="[A-Za-z0-9_-]{2,40}" placeholder="เช่น form-2569" aria-label="รหัสลิงก์ย่อ"></div>
				</details>
				<?php elseif ( $o['domains'] ) : ?>
				<p class="idw-lt__note">ย่อได้เฉพาะลิงก์ของ <?php echo esc_html( implode( ', ', $o['domains'] ) ); ?> · <a href="<?php echo esc_url( wp_login_url( get_permalink() ?: home_url( '/' ) ) ); ?>">เจ้าหน้าที่เข้าสู่ระบบ</a> เพื่อย่อลิงก์อื่น</p>
				<?php endif; ?>
				<button class="idw-lt__btn" type="submit">ย่อลิงก์</button>
				<div class="idw-lt__res" data-role="res" hidden aria-live="polite">
					<input class="idw-lt__in idw-lt__out" type="text" readonly aria-label="ลิงก์ย่อ">
					<div class="idw-lt__row">
						<button class="idw-lt__btn idw-lt__btn--2" type="button" data-act="copy">คัดลอก</button>
						<?php if ( 'both' === $show ) : ?><button class="idw-lt__btn idw-lt__btn--2" type="button" data-act="toqr">ทำ QR Code</button><?php endif; ?>
						<a class="idw-lt__btn idw-lt__btn--2" data-act="open" href="#" target="_blank" rel="noopener">เปิดทดสอบ ↗</a>
					</div>
				</div>
				<p class="idw-lt__msg" data-role="msg" aria-live="polite"></p>
			</form>
			<?php else : ?>
			<p class="idw-lt__note">เข้าสู่ระบบก่อนย่อลิงก์ · <a href="<?php echo esc_url( wp_login_url( get_permalink() ?: home_url( '/' ) ) ); ?>">เข้าสู่ระบบ</a></p>
			<?php endif; ?>
		</div>
		<?php endif; ?>
		<?php if ( 'short' !== $show ) : ?>
		<div class="idw-lt__card idw-lt__qr" data-role="qr">
			<h3 class="idw-lt__h"><span aria-hidden="true">▦</span> สร้าง QR Code</h3>
			<div class="idw-lt__grid">
				<div class="idw-lt__opts">
					<label class="idw-lt__lbl" for="<?php echo esc_attr( $id ); ?>-data">ข้อความหรือลิงก์</label>
					<textarea class="idw-lt__in" id="<?php echo esc_attr( $id ); ?>-data" data-k="data" rows="3"><?php echo esc_textarea( ! empty( $a['data'] ) ? $a['data'] : home_url( '/' ) ); ?></textarea>
					<div class="idw-lt__two">
						<div><label class="idw-lt__lbl">สี QR Code</label><input class="idw-lt__color" type="color" data-k="fg" value="#1f2937" aria-label="สี QR Code"></div>
						<div><label class="idw-lt__lbl">สีพื้นหลัง</label><input class="idw-lt__color" type="color" data-k="bg" value="#ffffff" aria-label="สีพื้นหลัง"></div>
					</div>
					<div class="idw-lt__two">
						<div><label class="idw-lt__lbl">รูปแบบจุด</label>
							<select class="idw-lt__in" data-k="dots" aria-label="รูปแบบจุด">
								<option value="rounded">มุมมน</option><option value="square">สี่เหลี่ยม</option><option value="dots">วงกลม</option><option value="classy">คลาสสิก</option><option value="classy-rounded">คลาสสิกมุมมน</option><option value="extra-rounded">มนมาก</option>
							</select></div>
						<div><label class="idw-lt__lbl">กรอบมุม</label>
							<select class="idw-lt__in" data-k="corner" aria-label="รูปแบบกรอบมุม">
								<option value="extra-rounded">มนมาก</option><option value="square">สี่เหลี่ยม</option><option value="dot">วงกลม</option>
							</select></div>
					</div>
					<label class="idw-lt__lbl">โลโก้ตรงกลาง</label>
					<div class="idw-lt__row idw-lt__logo">
						<label class="idw-lt__btn idw-lt__btn--2 idw-lt__file">เลือกรูป<input type="file" data-k="logo" accept="image/png,image/jpeg,image/webp" hidden></label>
						<?php if ( $o['logo'] && idw_lnk_site_logo() ) : ?><button class="idw-lt__btn idw-lt__btn--2" type="button" data-act="sitelogo">ใช้โลโก้เว็บ</button><?php endif; ?>
						<button class="idw-lt__btn idw-lt__btn--2" type="button" data-act="nologo" hidden>เอาโลโก้ออก</button>
					</div>
					<p class="idw-lt__note" data-role="logoname">ไม่มีโลโก้ · รูปไม่ถูกส่งขึ้นเว็บ สร้างในเครื่องของคุณเท่านั้น</p>
					<label class="idw-lt__lbl" for="<?php echo esc_attr( $id ); ?>-size">ขนาดไฟล์ <output data-role="sizeout">600</output> พิกเซล</label>
					<input class="idw-lt__range" id="<?php echo esc_attr( $id ); ?>-size" type="range" min="200" max="2000" step="50" value="600" data-k="size">
				</div>
				<div class="idw-lt__pv">
					<div class="idw-lt__canvas" data-role="canvas" aria-label="ตัวอย่าง QR Code"></div>
					<p class="idw-lt__msg" data-role="qrmsg" aria-live="polite">กำลังเตรียม QR Code…</p>
					<div class="idw-lt__row">
						<button class="idw-lt__btn" type="button" data-act="png">ดาวน์โหลด PNG</button>
						<button class="idw-lt__btn idw-lt__btn--2" type="button" data-act="svg">SVG</button>
					</div>
					<p class="idw-lt__note">สแกนทดสอบด้วยมือถือก่อนนำไปพิมพ์ทุกครั้ง</p>
				</div>
			</div>
		</div>
		<?php endif; ?>
	</div></section>
	<?php
	return (string) ob_get_clean();
}

/* ---------- document list ---------- */
function idw_docs_date( $ymd ) {
	if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', (string) $ymd, $m ) ) {
		return '';
	}
	$mon = array( '', 'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.' );
	return (int) $m[3] . ' ' . $mon[ (int) $m[2] ] . ' ' . ( (int) $m[1] + 543 );
}

function idw_docs_html( $a ) {
	$d = idw_docs_get( (string) ( $a['id'] ?? '' ) );
	if ( ! $d ) {
		return current_user_can( 'edit_pages' ) ? '<p class="idw-docs-empty">ยังไม่มีรายการเอกสาร — สร้างได้ที่เมนู ลิงก์ QR และเอกสาร</p>' : '';
	}
	wp_enqueue_style( 'idw-links' );
	$total = 0;
	foreach ( $d['groups'] as $g ) {
		foreach ( $g['items'] as $it ) {
			$total += empty( $it['off'] ) ? 1 : 0;
		}
	}
	if ( ! $total ) {
		return current_user_can( 'edit_pages' ) ? '<p class="idw-docs-empty">รายการ “' . esc_html( $d['name'] ) . '” ยังไม่มีเอกสาร — เพิ่มได้ที่เมนู ลิงก์ QR และเอกสาร</p>' : '';
	}
	$search = 'on' === $d['search'] || ( 'auto' === $d['search'] && $total > 10 );
	if ( $search ) {
		wp_enqueue_script( 'idw-docs' );
	}
	$cls = 'idw-docs idw-docs--' . $d['layout'];
	if ( ! empty( $a['className'] ) ) {
		$cls .= ' ' . implode( ' ', array_map( 'sanitize_html_class', preg_split( '/\s+/', (string) $a['className'] ) ) );
	}
	$tgt = $d['newtab'] ? ' target="_blank" rel="noopener"' : '';
	$h   = '<div class="' . esc_attr( $cls ) . '" data-idw-docs>';
	if ( ! empty( $a['head'] ) ) {
		$h .= '<h2 class="idw-docs__title">' . esc_html( $d['name'] ) . '</h2>';
	}
	if ( $search ) {
		$h .= '<div class="idw-docs__search"><input type="search" placeholder="ค้นหาเอกสาร… (' . (int) $total . ' รายการ)" aria-label="ค้นหาเอกสาร" data-idw-docs-q><p class="idw-docs__none" hidden>ไม่พบเอกสารที่ค้นหา</p></div>';
	}
	foreach ( $d['groups'] as $g ) {
		$rows = '';
		foreach ( $g['items'] as $it ) {
			if ( ! empty( $it['off'] ) || '' === $it['url'] ) {
				continue;
			}
			$ext  = idw_docs_ext( $it['url'] );
			$kind = idw_docs_kind( $ext );
			$meta = array();
			if ( $d['meta'] ) {
				$meta[] = $kind[0];
				if ( $it['sz'] ) {
					$meta[] = idw_docs_size_label( $it['sz'] );
				}
				if ( $it['date'] ) {
					$meta[] = idw_docs_date( $it['date'] );
				}
			}
			$dl    = ( $it['att'] && ! in_array( $ext, array( 'pdf', 'jpg', 'jpeg', 'png', 'gif', 'webp', 'mp4', 'mp3', 'txt' ), true ) ) ? ' download' : '';
			$badge = $kind[2];
			$rows .= '<li class="idw-docs__item"><a class="idw-docs__a" href="' . esc_url( $it['url'] ) . '"' . $tgt . $dl . ' style="--idw-docs-c:' . esc_attr( $kind[1] ) . '">'
				. '<span class="idw-docs__badge" aria-hidden="true">' . esc_html( $badge ) . '</span>'
				. '<span class="idw-docs__txt"><span class="idw-docs__t">' . esc_html( $it['t'] ) . '</span>'
				. ( $it['note'] ? '<span class="idw-docs__note">' . esc_html( $it['note'] ) . '</span>' : '' )
				. ( $meta ? '<span class="idw-docs__meta">' . esc_html( implode( ' · ', $meta ) ) . '</span>' : '' )
				. '</span><span class="idw-docs__go" aria-hidden="true">' . ( $dl ? '⤓' : '›' ) . '</span></a></li>';
		}
		if ( '' === $rows ) {
			continue;
		}
		$h .= '<section class="idw-docs__group">' . ( '' !== $g['title'] ? '<h3 class="idw-docs__gh">' . esc_html( $g['title'] ) . '</h3>' : '' ) . '<ul class="idw-docs__list">' . $rows . '</ul></section>';
	}
	if ( current_user_can( 'edit_pages' ) ) {
		$h .= '<p class="idw-docs__edit"><a href="' . esc_url( admin_url( 'admin.php?page=idw-links&tab=docs&list=' . rawurlencode( $d['id'] ) ) ) . '">✎ แก้ไขรายการนี้</a></p>';
	}
	return $h . '</div>';
}

/* ---------- show on the chosen pages without touching their content (works with Elementor) ---------- */
add_filter( 'the_content', function ( $html ) {
	if ( is_admin() || ! is_singular() || ! in_the_loop() || ! is_main_query() ) {
		return $html;
	}
	$pid = (int) get_queried_object_id();
	if ( (int) get_the_ID() !== $pid ) {
		return $html;
	}
	static $done = array();
	if ( isset( $done[ $pid ] ) ) {
		return $html; // Elementor may run the_content more than once
	}
	$out = $html;
	foreach ( idw_docs_all() as $d ) {
		if ( (int) $d['page'] === $pid && $d['mode'] ) {
			$list = idw_docs_html( array( 'id' => $d['id'] ) );
			if ( '' === $list ) {
				break;
			}
			$done[ $pid ] = 1;
			$out = 'replace' === $d['mode'] ? $list : ( 'before' === $d['mode'] ? $list . $out : $out . $list );
			break;
		}
	}
	$o = idw_lnk_opts();
	if ( (int) $o['tools_page'] === $pid && false === strpos( $html, 'class="idw-lt ' ) ) {
		$done[ $pid ] = 1;
		$tools = idw_lnk_tools_html( array( 'show' => $o['tools_show'] ) );
		$out   = 'before' === $o['tools_pos'] ? $tools . $out : $out . $tools;
	}
	return $out;
}, 999 );
