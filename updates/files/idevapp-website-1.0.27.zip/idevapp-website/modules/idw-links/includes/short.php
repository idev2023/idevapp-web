<?php
/**
 * ลิงก์ย่อ: https://เว็บ/go/รหัส → ลิงก์จริง (302 ไม่ถูกแคช เปลี่ยนปลายทางได้ภายหลัง) · นับคลิก
 * ใช้ได้ทุกแบบลิงก์ถาวร: /go/รหัส (ลิงก์ถาวรแบบสวย) หรือ /?go=รหัส
 */
defined( 'ABSPATH' ) || exit;

function idw_lnk_table() {
	global $wpdb;
	return $wpdb->prefix . 'idw_short';
}

function idw_lnk_install() {
	if ( (int) get_option( 'idw_short_db' ) === IDW_LNK_DB ) {
		return;
	}
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$t = idw_lnk_table();
	dbDelta( "CREATE TABLE $t (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		code varchar(40) NOT NULL,
		url text NOT NULL,
		title varchar(190) NOT NULL DEFAULT '',
		clicks bigint(20) unsigned NOT NULL DEFAULT 0,
		on_off tinyint(1) NOT NULL DEFAULT 1,
		created_by bigint(20) unsigned NOT NULL DEFAULT 0,
		ip_hash varchar(64) NOT NULL DEFAULT '',
		created_at datetime NOT NULL,
		last_at datetime NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY code (code),
		KEY created_by (created_by)
	) " . $wpdb->get_charset_collate() . ';' );
	update_option( 'idw_short_db', IDW_LNK_DB, false );
}
add_action( 'init', 'idw_lnk_install', 1 );

/** ชื่อที่ใช้เป็นรหัสไม่ได้ (ชนกับระบบ) */
function idw_lnk_reserved( $code ) {
	return in_array( strtolower( $code ), array( 'admin', 'wp', 'wp-admin', 'wp-login', 'login', 'api', 'feed', 'go', 'new', 'edit' ), true );
}

function idw_lnk_get( $code ) {
	global $wpdb;
	if ( ! preg_match( '/^[A-Za-z0-9_-]{2,40}$/', (string) $code ) ) {
		return null;
	}
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery
	return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . idw_lnk_table() . ' WHERE code = %s', $code ), ARRAY_A );
}

function idw_lnk_short_url( $code ) {
	$o = idw_lnk_opts();
	return get_option( 'permalink_structure' )
		? home_url( '/' . $o['prefix'] . '/' . rawurlencode( $code ) )
		: add_query_arg( $o['prefix'], rawurlencode( $code ), home_url( '/' ) );
}

function idw_lnk_new_code() {
	$a = 'abcdefghjkmnpqrstuvwxyzACDEFGHJKLMNPQRTUVWXYZ2346789'; // no look-alikes (0/O, 1/l/I, 5/S)
	for ( $len = 5; $len < 12; $len++ ) {
		for ( $try = 0; $try < 6; $try++ ) {
			$c = '';
			for ( $i = 0; $i < $len; $i++ ) {
				$c .= $a[ random_int( 0, strlen( $a ) - 1 ) ];
			}
			if ( ! idw_lnk_get( $c ) ) {
				return $c;
			}
		}
	}
	return strtolower( wp_generate_password( 14, false, false ) );
}

function idw_lnk_host_ok( $host, $domains ) {
	$host = strtolower( (string) $host );
	foreach ( (array) $domains as $d ) {
		if ( $host === $d || substr( $host, -strlen( '.' . $d ) ) === '.' . $d ) {
			return true;
		}
	}
	return false;
}

/** ตรวจลิงก์ปลายทาง · คืนลิงก์ที่ใช้ได้ หรือ WP_Error */
function idw_lnk_check_url( $url, $staff ) {
	$url = trim( (string) $url );
	if ( '' !== $url && ! preg_match( '#^[a-z][a-z0-9+.-]*:#i', $url ) ) {
		$url = 'https://' . $url;
	}
	$url = esc_url_raw( $url, array( 'http', 'https' ) );
	$p   = $url ? wp_parse_url( $url ) : false;
	if ( ! $p || empty( $p['host'] ) || ! in_array( strtolower( $p['scheme'] ?? '' ), array( 'http', 'https' ), true ) || strlen( $url ) > 2000 ) {
		return new WP_Error( 'url', 'ลิงก์ไม่ถูกต้อง — ต้องขึ้นต้นด้วย http:// หรือ https://' );
	}
	$o    = idw_lnk_opts();
	$self = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	if ( strtolower( $p['host'] ) === $self ) {
		$path = '/' . ltrim( (string) ( $p['path'] ?? '' ), '/' );
		$home = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		if ( 0 === strpos( $path, $home . '/' . $o['prefix'] . '/' ) || preg_match( '/(^|&)' . preg_quote( $o['prefix'], '/' ) . '=/', (string) ( $p['query'] ?? '' ) ) ) {
			return new WP_Error( 'loop', 'ลิงก์นี้เป็นลิงก์ย่ออยู่แล้ว' );
		}
	}
	if ( ! ( $staff && $o['staff_any'] ) && ! idw_lnk_host_ok( $p['host'], $o['domains'] ) ) {
		return new WP_Error( 'domain', 'ย่อได้เฉพาะลิงก์ของ ' . implode( ', ', $o['domains'] ) . ( $staff ? '' : ' — เจ้าหน้าที่เข้าสู่ระบบเพื่อย่อลิงก์อื่น' ) );
	}
	return $url;
}

function idw_lnk_ip_hash() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	return $ip ? hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) ) : '';
}

/**
 * สร้างลิงก์ย่อ · $staff = ผู้ใช้ที่เข้าสู่ระบบและมีสิทธิ์ edit_posts
 * คืน แถวข้อมูล (array) หรือ WP_Error
 */
function idw_lnk_create( $url, $code = '', $title = '', $staff = false ) {
	global $wpdb;
	$url = idw_lnk_check_url( $url, $staff );
	if ( is_wp_error( $url ) ) {
		return $url;
	}
	$uid = $staff ? get_current_user_id() : 0;
	$ip  = idw_lnk_ip_hash();
	if ( ! $staff ) {
		$o = idw_lnk_opts();
		if ( 'off' === $o['public'] ) {
			return new WP_Error( 'login', 'เข้าสู่ระบบก่อนย่อลิงก์' );
		}
		$k = 'idw_lnk_rate_' . substr( $ip, 0, 20 );
		$n = (int) get_transient( $k );
		if ( $n >= (int) $o['rate'] ) {
			return new WP_Error( 'rate', 'ย่อลิงก์ครบจำนวนต่อชั่วโมงแล้ว ลองใหม่ภายหลัง' );
		}
		set_transient( $k, $n + 1, HOUR_IN_SECONDS );
		$code = ''; // the public gets random codes only
	}
	$code = trim( (string) $code );
	if ( '' !== $code ) {
		if ( ! preg_match( '/^[A-Za-z0-9_-]{2,40}$/', $code ) || idw_lnk_reserved( $code ) ) {
			return new WP_Error( 'code', 'รหัสใช้ได้เฉพาะ a-z A-Z 0-9 _ - ยาว 2–40 ตัว' );
		}
		if ( idw_lnk_get( $code ) ) {
			return new WP_Error( 'taken', 'รหัส “' . $code . '” ถูกใช้แล้ว' );
		}
	} else {
		// the same link made by the same person: give back the one that exists
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$old = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . idw_lnk_table() . ' WHERE url = %s AND created_by = %d AND on_off = 1 AND ( created_by > 0 OR ip_hash = %s ) ORDER BY id LIMIT 1', $url, $uid, $ip ), ARRAY_A );
		if ( $old ) {
			return $old;
		}
		$code = idw_lnk_new_code();
	}
	$row = array(
		'code'       => $code,
		'url'        => $url,
		'title'      => mb_substr( sanitize_text_field( (string) $title ), 0, 190 ),
		'created_by' => $uid,
		'ip_hash'    => $ip,
		'created_at' => current_time( 'mysql', true ),
	);
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery
	if ( ! $wpdb->insert( idw_lnk_table(), $row ) ) {
		return new WP_Error( 'db', 'บันทึกไม่สำเร็จ' );
	}
	if ( function_exists( 'idw_sec_log' ) && $staff ) {
		idw_sec_log( 'settings', 'สร้างลิงก์ย่อ /' . idw_lnk_opts()['prefix'] . '/' . $code );
	}
	return idw_lnk_get( $code );
}

function idw_lnk_public_row( $r ) {
	return array( 'code' => $r['code'], 'short' => idw_lnk_short_url( $r['code'] ), 'url' => $r['url'] );
}

/* ---------- redirect ---------- */
function idw_lnk_request_code() {
	$o = idw_lnk_opts();
	if ( isset( $_GET[ $o['prefix'] ] ) && ! is_admin() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return sanitize_text_field( wp_unslash( $_GET[ $o['prefix'] ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	$home = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( preg_match( '#^' . preg_quote( $home . '/' . $o['prefix'] . '/', '#' ) . '([A-Za-z0-9_-]{2,40})/?$#', rawurldecode( $uri ), $m ) ) {
		return $m[1];
	}
	return '';
}

add_action( 'init', function () {
	$code = idw_lnk_request_code();
	if ( '' === $code || wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}
	$r = idw_lnk_get( $code );
	if ( ! $r || ! (int) $r['on_off'] ) {
		nocache_headers();
		wp_die( '<p>ไม่พบลิงก์นี้ หรือลิงก์ถูกปิดใช้งานแล้ว</p><p><a href="' . esc_url( home_url( '/' ) ) . '">ไปหน้าแรกของเว็บไซต์</a></p>', 'ไม่พบลิงก์', array( 'response' => 404 ) );
	}
	global $wpdb;
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$wpdb->query( $wpdb->prepare( 'UPDATE ' . idw_lnk_table() . ' SET clicks = clicks + 1, last_at = %s WHERE id = %d', current_time( 'mysql', true ), $r['id'] ) );
	do_action( 'litespeed_control_set_nocache', 'idw short link' );
	nocache_headers();
	header( 'X-Robots-Tag: noindex', true );
	header( 'Referrer-Policy: strict-origin-when-cross-origin', true );
	// phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- the target is any site the admin allowed when the link was made
	wp_redirect( $r['url'], 302, 'iDevApp' );
	exit;
}, 2 );

/* ---------- REST: create a short link from the page tool ---------- */
add_action( 'rest_api_init', function () {
	register_rest_route( 'idw/v1', '/short', array(
		'methods'             => 'POST',
		'permission_callback' => '__return_true', // checked inside: the public is limited to the allowed domains and a rate
		'args'                => array(
			'url'  => array( 'type' => 'string', 'required' => true ),
			'code' => array( 'type' => 'string', 'required' => false ),
		),
		'callback'            => function ( WP_REST_Request $q ) {
			$staff = is_user_logged_in() && current_user_can( 'edit_posts' );
			$r     = idw_lnk_create( (string) $q['url'], $staff ? (string) $q['code'] : '', '', $staff );
			if ( is_wp_error( $r ) ) {
				return new WP_REST_Response( array( 'ok' => false, 'msg' => $r->get_error_message() ), 400 );
			}
			return array( 'ok' => true ) + idw_lnk_public_row( $r );
		},
	) );
} );
