<?php
/** ตั้งค่าของโมดูล: คำนำหน้าลิงก์ย่อ ใครย่อลิงก์ได้ โดเมนที่อนุญาต และหน้าที่แสดงเครื่องมือ */
defined( 'ABSPATH' ) || exit;

function idw_lnk_defaults() {
	$host = wp_parse_url( home_url(), PHP_URL_HOST );
	return array(
		'prefix'     => 'go',
		'public'     => 'allow',          // บุคคลทั่วไปย่อลิงก์ได้: allow = เฉพาะโดเมนในรายการ · off = ไม่ได้ (เฉพาะเจ้าหน้าที่ที่เข้าสู่ระบบ)
		'domains'    => array_values( array_filter( array( $host, 'go.th' ) ) ),
		'staff_any'  => 1,                // เจ้าหน้าที่ที่เข้าสู่ระบบย่อลิงก์ไปเว็บใดก็ได้
		'rate'       => 20,               // ลิงก์ต่อชั่วโมงต่อเครื่อง (บุคคลทั่วไป)
		'tools_page' => 0,                // หน้าที่แสดงเครื่องมือ QR / ย่อลิงก์ให้อัตโนมัติ
		'tools_pos'  => 'after',          // before | after
		'tools_show' => 'both',           // both | qr | short
		'logo'       => 1,                // ปุ่ม “ใช้โลโก้เว็บ”
	);
}

function idw_lnk_opts() {
	static $o = null;
	if ( null === $o || did_action( 'update_option_idw_links_opts' ) ) {
		$saved = get_option( 'idw_links_opts', array() );
		$o     = array_merge( idw_lnk_defaults(), is_array( $saved ) ? $saved : array() );
	}
	return $o;
}

/** รายการโดเมน: บรรทัดละโดเมน · “go.th” = go.th และทุกโดเมนย่อย */
function idw_lnk_clean_domains( $raw ) {
	$out = array();
	foreach ( preg_split( '/[\s,]+/', strtolower( (string) $raw ) ) as $d ) {
		$d = preg_replace( '#^https?://#', '', trim( $d ) );
		$d = trim( preg_replace( '#[/:].*$#', '', $d ), '.*' );
		if ( $d && preg_match( '/^[a-z0-9.-]+\.[a-z]{2,}$|^[a-z0-9-]+\.[a-z0-9-]+$/', $d ) ) {
			$out[] = $d;
		}
	}
	return array_values( array_unique( $out ) );
}

function idw_lnk_save_opts( $in ) {
	$o = idw_lnk_opts();
	$o['prefix']     = preg_match( '/^[a-z0-9-]{1,12}$/', (string) ( $in['prefix'] ?? '' ) ) ? $in['prefix'] : 'go';
	$o['public']     = 'off' === ( $in['public'] ?? '' ) ? 'off' : 'allow';
	$o['domains']    = idw_lnk_clean_domains( $in['domains'] ?? '' );
	$o['staff_any']  = empty( $in['staff_any'] ) ? 0 : 1;
	$o['rate']       = max( 1, min( 500, (int) ( $in['rate'] ?? 20 ) ) );
	$o['tools_page'] = absint( $in['tools_page'] ?? 0 );
	$o['tools_pos']  = 'before' === ( $in['tools_pos'] ?? '' ) ? 'before' : 'after';
	$o['tools_show'] = in_array( $in['tools_show'] ?? '', array( 'both', 'qr', 'short' ), true ) ? $in['tools_show'] : 'both';
	$o['logo']       = empty( $in['logo'] ) ? 0 : 1;
	update_option( 'idw_links_opts', $o );
	return $o;
}

/** หน้าที่น่าจะเป็นหน้า “ระบบงานภายใน” / “ดาวน์โหลดเอกสาร” ของเว็บ (ให้กดตั้งในคลิกเดียว) */
function idw_lnk_guess_page( $kind ) {
	$slugs = 'tools' === $kind
		? array( 'ระบบงานภายใน', 'สำหรับเจ้าหน้าที่', 'intranet', 'staff' )
		: array( 'ดาวน์โหลดเอกสาร', 'ดาน์โหลดเอกสาร', 'ดาวน์โหลด', 'download', 'downloads' );
	foreach ( $slugs as $s ) {
		$p = get_page_by_path( $s );
		if ( $p && 'publish' === $p->post_status ) {
			return $p;
		}
	}
	return null;
}
