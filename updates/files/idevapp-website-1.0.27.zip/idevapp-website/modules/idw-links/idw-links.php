<?php
/**
 * Plugin Name: ลิงก์ QR และเอกสาร (ย่อลิงก์ · สร้าง QR Code · รายการดาวน์โหลดเอกสาร)
 * Description: ย่อลิงก์เป็น /go/รหัส พร้อมนับจำนวนคลิก · สร้าง QR Code ใส่โลโก้ เลือกสีและรูปแบบ ดาวน์โหลด PNG / SVG · รายการดาวน์โหลดเอกสารที่เพิ่ม ลบ ลากเรียงได้ในหลังบ้าน ดึงลิงก์จากหน้าเดิมได้ — แสดงด้วยบล็อก หรือ [idw_link_tools] [idw_qr] [idw_docs id="…"] ใช้ได้กับทุกธีมและ Elementor
 * Version: 1.0.0
 * Author: iDevApp
 * Author URI: https://idevapp.me/
 * Text Domain: idw-links
 *
 * ข้อมูล: ตาราง {prefix}idw_short (ลิงก์ย่อ) · option idw_docs (รายการเอกสาร) · option idw_links_opts (ตั้งค่า)
 * QR Code สร้างในเบราว์เซอร์ทั้งหมด (qr-code-styling, MIT) — รูปโลโก้ที่เลือกไม่ถูกส่งขึ้นเซิร์ฟเวอร์
 */
defined( 'ABSPATH' ) || exit;
if ( defined( 'IDW_LNK_VER' ) ) {
	return;
}
define( 'IDW_LNK_VER', defined( 'IDW_VERSION' ) ? IDW_VERSION : '1.0.0' );
define( 'IDW_LNK_URL', plugin_dir_url( __FILE__ ) );
define( 'IDW_LNK_DB', 2 ); // table schema version

require_once __DIR__ . '/includes/options.php';
require_once __DIR__ . '/includes/short.php';
require_once __DIR__ . '/includes/docs.php';
require_once __DIR__ . '/includes/render.php';
if ( is_admin() ) {
	require_once __DIR__ . '/includes/import.php';
	require_once __DIR__ . '/includes/admin.php';
	require_once __DIR__ . '/includes/setup.php';
}
