/* บล็อก “QR Code และย่อลิงก์” และ “รายการเอกสาร” */
( function ( wp ) {
	var el = wp.element.createElement, be = wp.blockEditor, c = wp.components, SSR = wp.serverSideRender;
	var E = window.IDW_LNK_EDITOR || {}, admin = E.admin || 'admin.php?page=idw-links', sets = E.sets || [];

	wp.blocks.registerBlockType( 'idw/link-tools', {
		apiVersion: 2,
		title: 'QR Code และย่อลิงก์',
		description: 'ย่อลิงก์เป็น /go/รหัส และสร้าง QR Code ใส่โลโก้ ดาวน์โหลด PNG / SVG',
		category: 'widgets',
		icon: 'admin-links',
		keywords: [ 'qr', 'qrcode', 'short', 'link', 'คิวอาร์', 'ย่อลิงก์', 'ลิงก์' ],
		supports: { html: false, align: [ 'wide', 'full' ] },
		attributes: { show: { type: 'string', default: 'both' } },
		edit: function ( p ) {
			var a = p.attributes;
			return el( 'div', be.useBlockProps(),
				el( be.InspectorControls, null,
					el( c.PanelBody, { title: 'แสดง', initialOpen: true },
						el( c.SelectControl, { label: 'เครื่องมือ', value: a.show, options: [ { label: 'ย่อลิงก์ + QR Code', value: 'both' }, { label: 'QR Code อย่างเดียว', value: 'qr' }, { label: 'ย่อลิงก์อย่างเดียว', value: 'short' } ], onChange: function ( v ) { p.setAttributes( { show: v } ); } } ),
						el( 'p', null, 'ใครย่อลิงก์ได้ และโดเมนที่อนุญาต ตั้งที่เมนู ลิงก์ QR และเอกสาร → ตั้งค่า' ),
						el( c.Button, { variant: 'secondary', href: admin + '&tab=settings', target: '_blank' }, 'ตั้งค่า ↗' )
					)
				),
				el( c.Disabled, null, el( SSR, { block: 'idw/link-tools', attributes: a } ) )
			);
		},
		save: function () { return null; }
	} );

	wp.blocks.registerBlockType( 'idw/docs', {
		apiVersion: 2,
		title: 'รายการเอกสาร',
		description: 'รายการดาวน์โหลดเอกสาร แบบฟอร์ม และลิงก์ — เพิ่ม ลบ เรียงได้ที่เมนู ลิงก์ QR และเอกสาร',
		category: 'widgets',
		icon: 'media-document',
		keywords: [ 'download', 'document', 'file', 'ดาวน์โหลด', 'เอกสาร', 'แบบฟอร์ม' ],
		supports: { html: false, align: [ 'wide', 'full' ] },
		attributes: { id: { type: 'string', default: '' }, head: { type: 'boolean', default: false } },
		edit: function ( p ) {
			var a = p.attributes;
			var opts = sets.length ? sets.map( function ( s ) { return { label: s.name + ' (' + s.n + ' รายการ)', value: s.id }; } ) : [ { label: 'ยังไม่มีรายการ', value: '' } ];
			return el( 'div', be.useBlockProps(),
				el( be.InspectorControls, null,
					el( c.PanelBody, { title: 'รายการเอกสาร', initialOpen: true },
						el( c.SelectControl, { label: 'แสดงรายการ', value: a.id || ( sets[ 0 ] ? sets[ 0 ].id : '' ), options: opts, onChange: function ( v ) { p.setAttributes( { id: v } ); } } ),
						el( c.ToggleControl, { label: 'แสดงชื่อรายการเป็นหัวข้อ', checked: a.head, onChange: function ( v ) { p.setAttributes( { head: v } ); } } ),
						el( c.Button, { variant: 'primary', href: admin + '&tab=docs' + ( a.id ? '&list=' + encodeURIComponent( a.id ) : '' ), target: '_blank' }, 'เพิ่ม / ลบเอกสาร ↗' )
					)
				),
				el( c.Disabled, null, el( SSR, { block: 'idw/docs', attributes: a } ) )
			);
		},
		save: function () { return null; }
	} );
}( window.wp ) );
