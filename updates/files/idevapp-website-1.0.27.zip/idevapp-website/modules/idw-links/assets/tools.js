/* เครื่องมือ QR Code + ย่อลิงก์ — QR สร้างในเบราว์เซอร์ (qr-code-styling) รูปโลโก้ไม่ถูกส่งขึ้นเว็บ */
( function () {
	'use strict';
	var C = window.IDW_LNK || {};

	function lum( hex ) {
		var m = /^#?([0-9a-f]{6})$/i.exec( hex || '' );
		if ( ! m ) return 1;
		var n = parseInt( m[ 1 ], 16 ), rgb = [ n >> 16 & 255, n >> 8 & 255, n & 255 ].map( function ( v ) {
			v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow( ( v + 0.055 ) / 1.055, 2.4 );
		} );
		return 0.2126 * rgb[ 0 ] + 0.7152 * rgb[ 1 ] + 0.0722 * rgb[ 2 ];
	}
	function contrast( a, b ) {
		var x = lum( a ), y = lum( b );
		return ( Math.max( x, y ) + 0.05 ) / ( Math.min( x, y ) + 0.05 );
	}
	function copy( text, btn ) {
		var done = function () { var t = btn.textContent; btn.textContent = 'คัดลอกแล้ว ✓'; setTimeout( function () { btn.textContent = t; }, 1600 ); };
		if ( navigator.clipboard && window.isSecureContext ) {
			navigator.clipboard.writeText( text ).then( done, function () { fallback(); } );
		} else fallback();
		function fallback() {
			var i = document.createElement( 'textarea' ); i.value = text; i.setAttribute( 'readonly', '' ); i.style.position = 'fixed'; i.style.opacity = '0';
			document.body.appendChild( i ); i.select();
			try { document.execCommand( 'copy' ); done(); } catch ( e ) {}
			document.body.removeChild( i );
		}
	}

	function initQR( box ) {
		if ( ! box ) return null;
		var q = function ( s ) { return box.querySelector( s ); };
		var el = { data: q( '[data-k="data"]' ), fg: q( '[data-k="fg"]' ), bg: q( '[data-k="bg"]' ), dots: q( '[data-k="dots"]' ), corner: q( '[data-k="corner"]' ),
			logo: q( '[data-k="logo"]' ), size: q( '[data-k="size"]' ), sizeout: q( '[data-role="sizeout"]' ), canvas: q( '[data-role="canvas"]' ),
			msg: q( '[data-role="qrmsg"]' ), logoname: q( '[data-role="logoname"]' ), nologo: q( '[data-act="nologo"]' ) };
		var logo = '', qr = null, timer = 0;
		function say( t, bad ) { el.msg.textContent = t; el.msg.classList.toggle( 'is-bad', !! bad ); }
		function opts( forFile ) {
			var size = Math.max( 200, Math.min( 2000, parseInt( el.size.value, 10 ) || 600 ) );
			var o = {
				width: forFile ? size : 280, height: forFile ? size : 280, type: forFile ? 'canvas' : 'svg',
				data: el.data.value.trim() || ' ', margin: forFile ? Math.round( size * 0.07 ) : 12,
				qrOptions: { errorCorrectionLevel: logo ? 'H' : 'Q' },
				dotsOptions: { color: el.fg.value, type: el.dots.value },
				backgroundOptions: { color: el.bg.value },
				cornersSquareOptions: { color: el.fg.value, type: el.corner.value },
				cornersDotOptions: { color: el.fg.value, type: 'dot' === el.corner.value ? 'dot' : ( 'square' === el.corner.value ? 'square' : 'dot' ) }
			};
			if ( logo ) {
				o.image = logo;
				o.imageOptions = { hideBackgroundDots: true, imageSize: 0.24, margin: 4, crossOrigin: 'anonymous' };
			}
			return o;
		}
		function draw() {
			if ( ! window.QRCodeStyling ) { say( 'โหลดตัวสร้าง QR Code ไม่สำเร็จ — รีเฟรชหน้าเว็บ', true ); return; }
			el.sizeout.textContent = el.size.value;
			var text = el.data.value.trim();
			try {
				qr = new window.QRCodeStyling( opts( false ) );
				el.canvas.innerHTML = '';
				qr.append( el.canvas );
			} catch ( e ) { say( 'ข้อความยาวเกินกว่าจะทำเป็น QR Code — ย่อลิงก์ก่อน', true ); return; }
			var c = contrast( el.fg.value, el.bg.value );
			if ( ! text ) say( 'พิมพ์ข้อความหรือลิงก์ก่อน', true );
			else if ( c < 3 ) say( 'สี QR กับสีพื้นใกล้กันเกินไป มือถืออาจสแกนไม่ได้ — ใช้สีเข้มบนพื้นอ่อน', true );
			else if ( lum( el.fg.value ) > lum( el.bg.value ) ) say( 'QR สีอ่อนบนพื้นเข้ม แอปสแกนบางแอปอ่านไม่ได้ — ทดสอบก่อนใช้', true );
			else if ( text.length > 300 ) say( 'ข้อความยาว QR จะมีจุดถี่ สแกนยาก — ย่อลิงก์ก่อนจะสแกนง่ายกว่า', true );
			else say( logo ? 'ใส่โลโก้แล้ว — สแกนทดสอบก่อนดาวน์โหลด' : 'พร้อมดาวน์โหลด' );
		}
		function later() { clearTimeout( timer ); timer = setTimeout( draw, 150 ); }
		function setLogo( src, name ) {
			logo = src; el.nologo.hidden = ! src;
			el.logoname.textContent = src ? 'โลโก้: ' + name : 'ไม่มีโลโก้ · รูปไม่ถูกส่งขึ้นเว็บ สร้างในเครื่องของคุณเท่านั้น';
			draw();
		}
		[ 'data', 'fg', 'bg', 'dots', 'corner', 'size' ].forEach( function ( k ) {
			el[ k ].addEventListener( 'input', later );
			el[ k ].addEventListener( 'change', later );
		} );
		el.logo.addEventListener( 'change', function () {
			var f = el.logo.files && el.logo.files[ 0 ];
			if ( ! f ) return;
			if ( [ 'image/png', 'image/jpeg', 'image/webp' ].indexOf( f.type ) < 0 ) { say( 'เลือกไฟล์ PNG, JPG หรือ WEBP', true ); el.logo.value = ''; return; }
			if ( f.size > 3 * 1024 * 1024 ) { say( 'ไฟล์โลโก้ใหญ่เกิน 3 MB', true ); el.logo.value = ''; return; }
			var r = new FileReader();
			r.onload = function () { setLogo( r.result, f.name ); };
			r.onerror = function () { say( 'อ่านไฟล์โลโก้ไม่สำเร็จ', true ); };
			r.readAsDataURL( f );
		} );
		box.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '[data-act]' );
			if ( ! b ) return;
			var act = b.getAttribute( 'data-act' );
			if ( 'sitelogo' === act && C.logo ) setLogo( C.logo, 'โลโก้เว็บ' );
			if ( 'nologo' === act ) { el.logo.value = ''; setLogo( '', '' ); }
			if ( 'png' === act || 'svg' === act ) {
				if ( ! window.QRCodeStyling || ! el.data.value.trim() ) return;
				var o = opts( true );
				if ( 'svg' === act ) o.type = 'svg';
				var name = ( C.name || 'qr' ) + '-qr';
				try { new window.QRCodeStyling( o ).download( { name: name, extension: act } ); } catch ( err ) { say( 'ดาวน์โหลดไม่สำเร็จ', true ); }
			}
		} );
		draw();
		return { set: function ( text ) { el.data.value = text; draw(); el.canvas.scrollIntoView( { behavior: 'smooth', block: 'center' } ); } };
	}

	function initShort( form, qrApi ) {
		if ( ! form ) return;
		var url = form.querySelector( 'input[type="url"]' ), code = form.querySelector( '[data-role="code"]' ),
			res = form.querySelector( '[data-role="res"]' ), out = form.querySelector( '.idw-lt__out' ), msg = form.querySelector( '[data-role="msg"]' ),
			btn = form.querySelector( 'button[type="submit"]' ), open = form.querySelector( '[data-act="open"]' ), busy = false;
		function say( t, bad ) { msg.textContent = t; msg.classList.toggle( 'is-bad', !! bad ); }
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			if ( busy ) return;
			var v = url.value.trim();
			if ( ! v ) { say( 'ใส่ลิงก์ก่อน', true ); url.focus(); return; }
			if ( ! /^[a-z][a-z0-9+.-]*:/i.test( v ) ) v = 'https://' + v;
			if ( ! /^https?:\/\/[^\s/]+\.[^\s]+/i.test( v ) ) { say( 'ลิงก์ไม่ถูกต้อง', true ); return; }
			if ( C.domains && C.domains.length ) {
				var host = '';
				try { host = new URL( v ).hostname.toLowerCase(); } catch ( err ) {}
				var ok = C.domains.some( function ( d ) { return host === d || host.slice( -( d.length + 1 ) ) === '.' + d; } );
				if ( ! ok ) { say( 'ย่อได้เฉพาะลิงก์ของ ' + C.domains.join( ', ' ), true ); return; }
			}
			busy = true; btn.disabled = true; btn.textContent = 'กำลังย่อ…'; say( '' );
			var h = { 'Content-Type': 'application/json' };
			if ( C.nonce ) h[ 'X-WP-Nonce' ] = C.nonce;
			fetch( C.rest, { method: 'POST', credentials: 'same-origin', headers: h, body: JSON.stringify( { url: v, code: code ? code.value.trim() : '' } ) } )
				.then( function ( r ) { return r.json().catch( function () { return { ok: false, msg: 'เซิร์ฟเวอร์ตอบกลับผิดรูปแบบ (' + r.status + ')' }; } ); } )
				.then( function ( j ) {
					if ( ! j || ! j.ok ) { say( ( j && ( j.msg || j.message ) ) || 'ย่อลิงก์ไม่สำเร็จ', true ); return; }
					out.value = j.short; open.href = j.short; res.hidden = false; say( 'ย่อแล้ว ✓' ); out.select();
				} )
				.catch( function () { say( 'เชื่อมต่อไม่ได้ ลองอีกครั้ง', true ); } )
				.then( function () { busy = false; btn.disabled = false; btn.textContent = 'ย่อลิงก์'; } );
		} );
		form.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '[data-act]' );
			if ( ! b ) return;
			if ( 'copy' === b.getAttribute( 'data-act' ) ) copy( out.value, b );
			if ( 'toqr' === b.getAttribute( 'data-act' ) && qrApi ) qrApi.set( out.value );
		} );
	}

	function boot() {
		document.querySelectorAll( '.idw-lt' ).forEach( function ( s ) {
			if ( s.getAttribute( 'data-ready' ) ) return;
			s.setAttribute( 'data-ready', '1' );
			var api = initQR( s.querySelector( '[data-role="qr"]' ) );
			initShort( s.querySelector( '[data-role="short"]' ), api );
		} );
	}
	if ( 'loading' === document.readyState ) document.addEventListener( 'DOMContentLoaded', boot ); else boot();
}() );
