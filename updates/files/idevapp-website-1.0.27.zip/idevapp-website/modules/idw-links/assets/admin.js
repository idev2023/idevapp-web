/* หลังบ้าน: แก้รายการเอกสาร — หมวด / ลิงก์ / ไฟล์ ลากเรียง เพิ่ม ลบ แล้วกดบันทึก */
( function ( $ ) {
	'use strict';
	var D = ( window.IDW_DOCS || {} ).data;
	if ( ! D ) return;
	var $groups = $( '#idw-de-groups' ), dirty = false;

	function esc( s ) { return $( '<div>' ).text( s == null ? '' : String( s ) ).html(); }
	function ext( url ) {
		var m = /\.([a-z0-9]{2,5})(?:[?#]|$)/i.exec( ( url || '' ).split( '?' )[ 0 ] );
		if ( m ) return m[ 1 ].toUpperCase();
		if ( /docs\.google\.com\/spreadsheets/.test( url ) ) return 'SHEET';
		if ( /docs\.google\.com\/forms|forms\.gle/.test( url ) ) return 'FORM';
		if ( /docs\.google\.com/.test( url ) ) return 'DOC';
		if ( /drive\.google\.com/.test( url ) ) return 'DRIVE';
		return url ? '↗' : '';
	}
	function mark() {
		if ( ! dirty ) { dirty = true; $( '.idw-de__dirty' ).prop( 'hidden', false ); }
	}
	function count() {
		$groups.find( '.idw-de-g' ).each( function () {
			var n = $( this ).find( '.idw-de-i' ).length;
			$( this ).find( '.idw-de-g__n' ).text( n + ' รายการ' );
			$( this ).find( '.idw-de-g__empty' ).prop( 'hidden', n > 0 );
		} );
	}

	function itemHtml( it ) {
		it = it || {};
		return '<li class="idw-de-i' + ( it.off ? ' is-off' : '' ) + '" data-att="' + ( it.att || 0 ) + '" data-sz="' + ( it.sz || 0 ) + '">' +
			'<span class="idw-de-i__h" title="ลากเพื่อย้าย" aria-hidden="true">⋮⋮</span>' +
			'<span class="idw-de-i__x">' + esc( ext( it.url ) ) + '</span>' +
			'<span class="idw-de-i__f">' +
				'<input type="text" class="idw-de-i__t" placeholder="ชื่อเอกสาร / ลิงก์" value="' + esc( it.t ) + '" aria-label="ชื่อ">' +
				'<span class="idw-de-i__u"><input type="url" class="idw-de-i__url" placeholder="https://… หรือกด เลือกไฟล์" value="' + esc( it.url ) + '" aria-label="ลิงก์">' +
				'<button type="button" class="button idw-de-pick">เลือกไฟล์</button></span>' +
				'<details class="idw-de-i__more"' + ( it.note || it.date ? ' open' : '' ) + '><summary>รายละเอียด</summary>' +
					'<input type="text" class="idw-de-i__note" placeholder="คำอธิบายสั้น (ไม่บังคับ)" value="' + esc( it.note ) + '">' +
					'<label>วันที่ <input type="date" class="idw-de-i__date" value="' + esc( it.date ) + '"></label>' +
					'<label><input type="checkbox" class="idw-de-i__off"' + ( it.off ? ' checked' : '' ) + '> ซ่อนไว้ก่อน</label>' +
				'</details>' +
			'</span>' +
			'<span class="idw-de-i__a">' +
				'<a class="button idw-de-open" href="' + esc( it.url || '#' ) + '" target="_blank" rel="noopener" title="เปิดดู">↗</a>' +
				'<button type="button" class="button idw-de-del" title="ลบ" aria-label="ลบรายการนี้">✕</button>' +
			'</span></li>';
	}
	function groupHtml( g ) {
		g = g || { title: '', items: [] };
		var h = '<section class="idw-de-g"><header class="idw-de-g__head">' +
			'<span class="idw-de-g__h" title="ลากเพื่อย้ายหมวด" aria-hidden="true">⋮⋮</span>' +
			'<input type="text" class="idw-de-g__t" placeholder="ชื่อหมวด (ไม่บังคับ) เช่น แบบฟอร์มงานบุคคล" value="' + esc( g.title ) + '" aria-label="ชื่อหมวด">' +
			'<span class="idw-de-g__n"></span>' +
			'<button type="button" class="button-link idw-de-g__fold" aria-label="ย่อ / ขยาย">▾</button>' +
			'<button type="button" class="button-link button-link-delete idw-de-g__del">ลบหมวด</button></header>' +
			'<ul class="idw-de-g__items">';
		( g.items || [] ).forEach( function ( it ) { h += itemHtml( it ); } );
		return h + '</ul><p class="idw-de-g__empty" hidden>ยังไม่มีรายการ — ลากรายการมาวางที่นี่ หรือกดปุ่มด้านล่าง</p>' +
			'<p class="idw-de-g__add"><button type="button" class="button idw-de-addlink">+ เพิ่มลิงก์</button> ' +
			'<button type="button" class="button idw-de-addfiles">+ อัปโหลด / เลือกไฟล์ (หลายไฟล์ได้)</button></p></section>';
	}
	function sortable() {
		$groups.sortable( { handle: '.idw-de-g__h', items: '> .idw-de-g', axis: 'y', placeholder: 'idw-de-ph', forcePlaceholderSize: true, update: mark } );
		$groups.find( '.idw-de-g__items' ).sortable( { handle: '.idw-de-i__h', connectWith: '.idw-de-g__items', placeholder: 'idw-de-ph', forcePlaceholderSize: true, update: function () { mark(); count(); } } );
	}

	D.groups.forEach( function ( g ) { $groups.append( groupHtml( g ) ); } );
	sortable(); count();

	/* media library: one file for a row, many files for a group */
	function media( multi, done ) {
		var f = wp.media( { title: multi ? 'เลือกหรืออัปโหลดเอกสาร (เลือกได้หลายไฟล์)' : 'เลือกหรืออัปโหลดเอกสาร', button: { text: 'ใช้ไฟล์นี้' }, multiple: multi ? 'add' : false } );
		f.on( 'select', function () { done( f.state().get( 'selection' ).toJSON() ); } );
		f.open();
	}
	function fromAtt( a ) {
		return { t: a.title || a.filename, url: a.url, att: a.id, sz: a.filesizeInBytes || 0, date: a.date ? new Date( a.date ).toISOString().slice( 0, 10 ) : '' };
	}

	$( '#idw-de-addgroup' ).on( 'click', function () {
		var $g = $( groupHtml() );
		$groups.append( $g ); sortable(); count(); mark();
		$g.find( '.idw-de-g__t' ).trigger( 'focus' );
	} );
	$groups.on( 'click', '.idw-de-addlink', function () {
		var $li = $( itemHtml() );
		$( this ).closest( '.idw-de-g' ).find( '.idw-de-g__items' ).append( $li );
		count(); mark(); $li.find( '.idw-de-i__t' ).trigger( 'focus' );
	} );
	$groups.on( 'click', '.idw-de-addfiles', function () {
		var $ul = $( this ).closest( '.idw-de-g' ).find( '.idw-de-g__items' );
		media( true, function ( list ) {
			list.forEach( function ( a ) { $ul.append( itemHtml( fromAtt( a ) ) ); } );
			count(); mark();
		} );
	} );
	$groups.on( 'click', '.idw-de-pick', function () {
		var $li = $( this ).closest( '.idw-de-i' );
		media( false, function ( list ) {
			var a = list[ 0 ]; if ( ! a ) return;
			var it = fromAtt( a );
			$li.find( '.idw-de-i__url' ).val( it.url );
			visuals( $li, it.url );
			$li.attr( 'data-att', it.att ).attr( 'data-sz', it.sz );
			if ( ! $li.find( '.idw-de-i__t' ).val() ) $li.find( '.idw-de-i__t' ).val( it.t );
			mark();
		} );
	} );
	function visuals( $li, v ) {
		$li.find( '.idw-de-i__x' ).text( ext( v ) );
		$li.find( '.idw-de-open' ).attr( 'href', v || '#' );
	}
	$groups.on( 'input', '.idw-de-i__url', function () {
		var $li = $( this ).closest( '.idw-de-i' );
		visuals( $li, this.value );
		$li.attr( 'data-att', 0 ); // a typed link is no longer the chosen file
	} );
	$groups.on( 'change', '.idw-de-i__off', function () { $( this ).closest( '.idw-de-i' ).toggleClass( 'is-off', this.checked ); } );
	$groups.on( 'click', '.idw-de-del', function () {
		var $li = $( this ).closest( '.idw-de-i' ), $next = $li.next(), $ul = $li.parent();
		$li.detach(); count(); mark();
		toast( 'ลบ “' + ( $li.find( '.idw-de-i__t' ).val() || 'รายการ' ) + '” แล้ว', function () {
			if ( $next.length && $next.parent().is( $ul ) ) $li.insertBefore( $next ); else $ul.append( $li );
			count();
		} );
	} );
	$groups.on( 'click', '.idw-de-g__del', function () {
		var $g = $( this ).closest( '.idw-de-g' ), n = $g.find( '.idw-de-i' ).length, $next = $g.next();
		if ( n && ! window.confirm( 'ลบหมวดนี้และ ' + n + ' รายการในหมวด?' ) ) return;
		$g.detach(); mark();
		toast( 'ลบหมวดแล้ว', function () { if ( $next.length ) $g.insertBefore( $next ); else $groups.append( $g ); sortable(); count(); } );
	} );
	$groups.on( 'click', '.idw-de-g__fold', function () { $( this ).closest( '.idw-de-g' ).toggleClass( 'is-folded' ); } );
	$( '#idw-docs-form' ).on( 'input change', 'input, select', mark );

	var tTimer = 0;
	function toast( msg, undo ) {
		$( '.idw-de-toast' ).remove();
		var $t = $( '<div class="idw-de-toast" role="status"><span></span> <button type="button" class="button-link">ย้อนกลับ</button></div>' );
		$t.find( 'span' ).text( msg );
		$t.find( 'button' ).on( 'click', function () { undo(); $t.remove(); } );
		$( 'body' ).append( $t );
		clearTimeout( tTimer ); tTimer = setTimeout( function () { $t.remove(); }, 7000 );
	}

	function collect() {
		var out = {
			id: D.id, name: $( '#idw-de-name' ).val(),
			layout: $( '#idw-de-layout' ).val(), search: $( '#idw-de-search' ).val(),
			meta: $( '#idw-de-meta' ).is( ':checked' ) ? 1 : 0, newtab: $( '#idw-de-newtab' ).is( ':checked' ) ? 1 : 0,
			page: parseInt( $( 'select[name="idw_page"]' ).val(), 10 ) || 0, mode: $( '#idw-de-mode' ).val(), groups: []
		};
		$groups.find( '.idw-de-g' ).each( function () {
			var g = { title: $( this ).find( '.idw-de-g__t' ).val(), items: [] };
			$( this ).find( '.idw-de-i' ).each( function () {
				var $i = $( this );
				g.items.push( { t: $i.find( '.idw-de-i__t' ).val(), url: $i.find( '.idw-de-i__url' ).val(), att: parseInt( $i.attr( 'data-att' ), 10 ) || 0,
					note: $i.find( '.idw-de-i__note' ).val(), date: $i.find( '.idw-de-i__date' ).val(), off: $i.find( '.idw-de-i__off' ).is( ':checked' ) ? 1 : 0 } );
			} );
			out.groups.push( g );
		} );
		return out;
	}
	$( '#idw-docs-form' ).on( 'submit', function () {
		var d = collect(), bad = 0;
		d.groups.forEach( function ( g ) { g.items.forEach( function ( it ) { if ( it.t && ! it.url ) bad++; } ); } );
		if ( bad && ! window.confirm( bad + ' รายการยังไม่มีลิงก์ จะไม่แสดงบนหน้าเว็บ — บันทึกต่อ?' ) ) return false;
		if ( d.mode && ! d.page ) { window.alert( 'เลือกหน้าที่จะแสดงก่อน หรือตั้งเป็น “ยังไม่แสดง”' ); return false; }
		if ( 'replace' === d.mode && ! window.confirm( 'หน้าเว็บจะแสดงรายการนี้แทนเนื้อหาเดิมของหน้า (เนื้อหาเดิมไม่ถูกลบ เปลี่ยนกลับได้) — ตกลง?' ) ) return false;
		$( '#idw-docs-json' ).val( JSON.stringify( d ) );
		dirty = false;
		$( '#idw-de-save' ).prop( 'disabled', true ).text( 'กำลังบันทึก…' );
	} );
	$( window ).on( 'beforeunload', function () { if ( dirty ) return 'มีการแก้ไขที่ยังไม่บันทึก'; } );
}( jQuery ) );
