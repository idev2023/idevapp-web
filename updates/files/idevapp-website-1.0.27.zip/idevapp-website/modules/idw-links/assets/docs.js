/* รายการเอกสาร: ช่องค้นหา (ไม่ต้องโหลดหน้าใหม่) */
( function () {
	'use strict';
	function norm( s ) { return ( s || '' ).toLowerCase().replace( /\s+/g, ' ' ).trim(); }
	function boot() {
		document.querySelectorAll( '[data-idw-docs]' ).forEach( function ( box ) {
			var q = box.querySelector( '[data-idw-docs-q]' );
			if ( ! q || q.getAttribute( 'data-ready' ) ) return;
			q.setAttribute( 'data-ready', '1' );
			var none = box.querySelector( '.idw-docs__none' ), t = 0;
			q.addEventListener( 'input', function () {
				clearTimeout( t );
				t = setTimeout( function () {
					var words = norm( q.value ).split( ' ' ).filter( Boolean ), any = false;
					box.querySelectorAll( '.idw-docs__group' ).forEach( function ( g ) {
						var head = norm( ( g.querySelector( '.idw-docs__gh' ) || {} ).textContent ), shown = 0;
						g.querySelectorAll( '.idw-docs__item' ).forEach( function ( li ) {
							var txt = head + ' ' + norm( li.textContent );
							var ok = words.every( function ( w ) { return txt.indexOf( w ) >= 0; } );
							li.hidden = ! ok; shown += ok ? 1 : 0;
						} );
						g.hidden = ! shown; any = any || shown > 0;
					} );
					if ( none ) none.hidden = any;
				}, 120 );
			} );
		} );
	}
	if ( 'loading' === document.readyState ) document.addEventListener( 'DOMContentLoaded', boot ); else boot();
}() );
