<?php
defined('WP_UNINSTALL_PLUGIN') || exit;
global $wpdb;
delete_option('idev_cookie_consent');
delete_option('idev_cc_db');
wp_clear_scheduled_hook('idev_cc_prune');
$wpdb->query($wpdb->prepare('DROP TABLE IF EXISTS %i', $wpdb->prefix . 'idev_consent_log')); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- removing the plugin's own table on uninstall
