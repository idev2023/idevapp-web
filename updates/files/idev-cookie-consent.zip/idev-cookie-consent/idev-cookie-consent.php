<?php
/**
 * Plugin Name:       iDev Cookie Consent (PDPA / GDPR)
 * Plugin URI:        https://idevapp.me/plugins/idev-cookie-consent
 * Description:       Cookie banner for Thai PDPA and GDPR: Accept / Reject / choose categories, asked again on every page until the visitor answers, consent log with CSV export, scripts and embeds that wait for consent, and Google Consent Mode v2. Thai / English.
 * Version:           1.0.1
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-cookie-consent
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// The Pro version contains this plugin; when both are installed the Pro one is used.
if (defined('IDEV_CC_VERSION')) return;

define('IDEV_CC_VERSION', '1.0.1');
define('IDEV_CC_FILE', __FILE__);
require_once __DIR__ . '/common/idev-common.php';
require_once __DIR__ . '/includes/consent.php';
require_once __DIR__ . '/includes/admin.php';
register_activation_hook(__FILE__, 'idev_cc_install');
