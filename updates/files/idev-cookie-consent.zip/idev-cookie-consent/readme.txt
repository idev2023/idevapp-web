=== iDev Cookie Consent (PDPA / GDPR) ===
Contributors: idevapp2023
Donate link: https://idevapp.me/
Tags: cookie, pdpa, gdpr, consent
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Cookie banner for Thai PDPA and GDPR: Accept / Reject / choose categories, asked on every page until answered, consent log with CSV export, scripts

== Description ==

Cookie banner for Thai PDPA and GDPR: Accept / Reject / choose categories, asked on every page until answered, consent log with CSV export, scripts that wait for consent, Google Consent Mode v2.

= Features =

* Bar, corner box or centre layout
* Asked again on every page until the visitor answers
* Consent log (hashed IP) and CSV export
* Statistics / marketing scripts held until allowed
* Google Consent Mode v2

Thai and English interface. Works with any theme. Part of the iDevApp plugin suite for hospitals and clinics — all iDev plugins appear under the **iDevApp** menu.

== Installation ==

1. Plugins → Add New → Upload Plugin, choose the zip, Install, Activate.
2. Open **iDevApp** in the admin menu for settings.

== Changelog ==

= 1.0.0 =
* First release.
