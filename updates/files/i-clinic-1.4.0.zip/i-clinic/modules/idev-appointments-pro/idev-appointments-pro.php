<?php
/**
 * Plugin Name:       iDev Appointments Pro
 * Plugin URI:        https://idevapp.me/plugins/idev-appointments/#pro
 * Description:       Add-on for iDev Appointments: LINE and SMS reminders, waiting list that tells people when a time becomes free, branches, reports with no-show rates and export, and a connector that can send appointments to HOSxP.
 * Version:           1.4.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-appointments-pro
 * Domain Path:       /languages
 */
defined('ABSPATH') || exit;

// Loaded once: the same plugin may also be inside an iDevApp package (I-Clinic / I-Drug) or a Pro version.
if (defined('IDEV_APRO_VERSION')) return;

define('IDEV_APRO_VERSION', '1.4.0');
define('IDEV_APRO_FILE', __FILE__);
define('IDEV_APRO_DIR', __DIR__);

if (!function_exists('idev_free_plugin_active')) {
    /** Is this plugin active as a separate plugin (this site or network)? */
    function idev_free_plugin_active($slug) {
        $f = $slug . '/' . $slug . '.php';
        if (in_array($f, (array) get_option('active_plugins', []), true)) return true;
        return is_multisite() && isset(((array) get_site_option('active_sitewide_plugins', []))[$f]);
    }
}
/* One plugin to install: the Pro zip contains the free plugin (iDev Appointments) in core/. */
// WordPress loads "idev-appointments-pro" before "idev-appointments": when the separate free plugin is still active, let it load itself
// (it is switched off on the next admin page) instead of loading the copy in core/ — loading both would be a fatal error.
if (!defined('IDEV_APPT_VERSION') && is_file(__DIR__ . '/core/idev-appointments.php') && !idev_free_plugin_active('idev-appointments')) require_once __DIR__ . '/core/idev-appointments.php';
require_once dirname(__DIR__, 2) . '/common/idev-common.php';
require_once __DIR__ . '/includes/core.php';

add_action('plugins_loaded', function () {
    if (!function_exists('idev_appt_settings')) {
        add_action('admin_notices', function () {
            if (!current_user_can('activate_plugins')) return;
            echo '<div class="notice notice-error"><p>' . esc_html__('iDev Appointments Pro needs the free plugin iDev Appointments (version 1.2 or newer). Please install and activate it.', 'idev-appointments-pro') . '</p></div>';
        });
        return;
    }
    foreach (['branches', 'messages', 'whatsapp', 'waitlist', 'reports', 'emails', 'hosxp', 'admin'] as $f) require_once __DIR__ . '/includes/' . $f . '.php';
}, 20);

register_activation_hook(__FILE__, function () use (&$idev_apro_takeover) {
    if (function_exists('idev_appt_install')) { idev_appt_install(); update_option('idev_appt_flush', 1, false); }
    idev_apro_install();
    $idev_apro_takeover();
});
/** The free plugin is inside this one: switch the separate free plugin off (settings and data are shared). */
$idev_apro_takeover = function () {
    if (!is_dir(__DIR__ . '/core')) return;
    if (!function_exists('is_plugin_active')) require_once ABSPATH . 'wp-admin/includes/plugin.php';
    $free = 'idev-appointments/idev-appointments.php';
    if (!is_plugin_active($free)) return;
    deactivate_plugins($free, true);
    set_transient('idev_apro_took_over', 1, 600);
};
add_action('admin_init', $idev_apro_takeover);
add_action('admin_notices', function () {
    if (!get_transient('idev_apro_took_over') || !current_user_can('activate_plugins')) return;
    delete_transient('idev_apro_took_over');
    echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('The Pro version already contains the free plugin, so the separate free plugin was switched off. Your settings and data are kept. You can delete the free plugin.', 'idev-appointments-pro') . '</p></div>';
});
