<?php
/**
 * Title: ภาพหลัก (ราชการ)
 * Slug: idev-gov/hero
 * Categories: idev-gov
 * Description: ภาพหลัก (ราชการ) — แก้ข้อความ รูป และสีได้ในตัวแก้ไข
 */
?>
<!-- wp:group {"tagName":"section","align":"full","className":"idev-hero idev-hero-gov","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}}},"textColor":"base","gradient":"hero","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull idev-hero idev-hero-gov has-base-color has-hero-gradient-background has-text-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"verticalAlignment":"center","align":"wide"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"58%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:58%"><!-- wp:paragraph {"className":"idev-kicker idev-kicker-light"} -->
<p class="idev-kicker idev-kicker-light">ยินดีต้อนรับ</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"textColor":"base","fontSize":"xx-large"} -->
<h1 class="wp-block-heading has-base-color has-text-color has-xx-large-font-size">บริการประชาชนด้วยความโปร่งใส รวดเร็ว และเข้าถึงได้ทุกคน</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"base","fontSize":"large"} -->
<p class="has-base-color has-text-color has-large-font-size">ข่าวสาร ประกาศ บริการออนไลน์ และช่องทางติดต่อหน่วยงาน ครบในที่เดียว</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"accent","textColor":"ink"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-accent-background-color has-text-color has-background wp-element-button" href="/e-service/">บริการออนไลน์ (e-Service)</a></div>
<!-- /wp:button -->

<!-- wp:button {"textColor":"base","className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-base-color has-text-color wp-element-button" href="/contact/">ติดต่อหน่วยงาน</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"42%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:42%"><!-- wp:image {"sizeSlug":"full","className":"idev-hero-art"} -->
<figure class="wp-block-image size-full idev-hero-art"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/hero-gov.svg" alt="อาคารหน่วยงาน"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
