<?php
/**
 * Title: ประกาศ / จัดซื้อจัดจ้าง
 * Slug: idev-gov/announce
 * Categories: idev-gov
 * Description: ประกาศ / จัดซื้อจัดจ้าง — แก้ข้อความ รูป และสีได้ในตัวแก้ไข
 */
?>
<!-- wp:group {"tagName":"section","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"surface","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull has-surface-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"60%"} -->
<div class="wp-block-column" style="flex-basis:60%"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"idev-kicker"} -->
<p class="idev-kicker">ประกาศ</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">ประกาศล่าสุด</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:latest-posts {"postsToShow":6,"displayPostDate":true,"className":"idev-announce"} /--></div>
<!-- /wp:column -->

<!-- wp:column {"width":"40%"} -->
<div class="wp-block-column" style="flex-basis:40%"><!-- wp:group {"className":"is-style-idev-card","style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group is-style-idev-card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">ผู้บริหาร</h3>
<!-- /wp:heading -->

<!-- wp:html -->
<div class="idev-exec"><div class="idev-exec-photo" aria-hidden="true"></div></div>
<!-- /wp:html -->

<!-- wp:paragraph {"style":{"typography":{"textAlign":"center"}}} -->
<p class="has-text-align-center"><strong>ชื่อ-นามสกุล ผู้บริหาร</strong><br>ตำแหน่ง</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"textAlign":"center"}},"fontSize":"small"} -->
<p class="has-text-align-center has-small-font-size"><a href="/executives/">ทำเนียบผู้บริหาร →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
