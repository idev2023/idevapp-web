=== iDev Gov ===
Contributors: idevapp
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

ธีมเว็บไซต์หน่วยงานราชการ โรงพยาบาลรัฐ อบต./เทศบาล: แถบเข้าถึงง่าย (ขยายตัวอักษร สีตัดกัน) บริการ e-Service ข่าวประชาสัมพันธ์ ประกาศ ITA/OIT และแผนที่ ใช้คู่กับปลั๊กอิน iDevApp

== Copyright ==
iDev Gov © iDevApp, GPLv2 or later.
Fonts: SIL Open Font License 1.1. Illustrations: by iDevApp, GPLv2 or later.
