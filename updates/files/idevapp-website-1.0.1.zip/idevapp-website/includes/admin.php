<?php
/**
 * Back office: menu "iDevApp Website" — แดชบอร์ด, โมดูล (เปิด / ปิด), ตั้งค่าเว็บไซต์ (wizard), ธีม, อัปเดต.
 * The shared iDevApp menu (slug "idevapp") becomes this menu, so module settings pages stay under it.
 */
defined('ABSPATH') || exit;

function idw_icon($name) {
    $extra = [
        'star' => '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
        'globe' => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
        'grid' => '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
        'map' => '<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2Z"/><path d="M9 4v14M15 6v14"/>',
        'clip' => '<path d="m21 12-8.5 8.5a5 5 0 0 1-7-7L14 5a3.5 3.5 0 0 1 5 5l-8.5 8.5a2 2 0 0 1-3-3L15 8"/>',
        'spark' => '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/>',
        'check' => '<path d="m5 12 5 5 9-10"/>',
        'toggle' => '<rect x="2" y="7" width="20" height="10" rx="5"/><circle cx="16" cy="12" r="3"/>',
        'theme' => '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M9 9v11"/>',
        'wand' => '<path d="m15 4 5 5L9 20H4v-5L15 4Z"/><path d="m13 6 5 5"/>',
        'lock' => '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
        'upload' => '<path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>',
        'external' => '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
    ];
    if (isset($extra[$name])) return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $extra[$name] . '</svg>';
    $map = ['refresh' => 'refresh', 'clock' => 'clock'];
    return function_exists('idev_icon') ? idev_icon($map[$name] ?? $name) : '';
}

/** Date and time for people: Thai months and พ.ศ. on Thai pages. */
function idw_dt($ts, $time = true) {
    $ts = (int) $ts;
    if (!$ts) return '';
    if (function_exists('idev_format_datetime')) return idev_format_datetime(wp_date($time ? 'Y-m-d H:i' : 'Y-m-d', $ts));
    return wp_date($time ? 'j M Y H:i' : 'j M Y', $ts);
}

/* ---------- menu ---------- */

add_action('admin_menu', function () {
    global $menu, $submenu;
    // the shared "iDevApp" menu (added by the iDevApp helpers) becomes ours; its hook names stay "idevapp_page_…"
    $icon = 'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#a7aaad" d="M3 3h6v6H3zM11 3h6v6h-6zM3 11h6v6H3zM14 11a3 3 0 1 1 0 6 3 3 0 0 1 0-6z"/></svg>');
    $found = false;
    foreach ((array) $menu as $i => $item) {
        if (($item[2] ?? '') !== 'idevapp') continue;
        unset($menu[$i]);
        $item[0] = 'iDevApp Website';
        $item[3] = 'iDevApp Website';
        $item[6] = $icon;
        $menu['2.5'] = $item; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
        $found = true;
    }
    if (!$found) add_menu_page('iDevApp Website', 'iDevApp Website', 'edit_posts', 'idevapp', 'idw_page_dashboard', $icon, 2.5);
    remove_all_actions('toplevel_page_idevapp');
    add_action('toplevel_page_idevapp', 'idw_page_dashboard');
    add_submenu_page('idevapp', 'ตั้งค่าเว็บไซต์', 'ตั้งค่าเว็บไซต์', 'manage_options', 'idw-setup', 'idw_page_setup');
    add_submenu_page('idevapp', 'โมดูล', 'โมดูล (เปิด / ปิด)', 'manage_options', 'idw-modules', 'idw_page_modules');
    add_submenu_page('idevapp', 'ธีม', 'ธีม', 'switch_themes', 'idw-themes', 'idw_page_themes');
    $n = current_user_can('update_plugins') ? count(idw_pending_updates()) : 0;
    add_submenu_page('idevapp', 'อัปเดต', 'อัปเดต' . ($n ? ' <span class="awaiting-mod">' . $n . '</span>' : ''), 'update_plugins', 'idw-updates', 'idw_page_updates');
    // our pages first, then the module settings pages in the order they were added
    if (!empty($submenu['idevapp'])) {
        $mine = ['idevapp', 'idw-setup', 'idw-modules', 'idw-themes', 'idw-updates'];
        $head = []; $rest = [];
        foreach ($submenu['idevapp'] as $item) {
            if (in_array($item[2], $mine, true)) { if (!isset($head[$item[2]])) $head[$item[2]] = $item; } else $rest[] = $item;
        }
        if (isset($head['idevapp'])) { $head['idevapp'][0] = 'แดชบอร์ด'; $head['idevapp'][3] = 'แดชบอร์ด'; }
        $sorted = [];
        foreach ($mine as $slug) if (isset($head[$slug])) $sorted[] = $head[$slug];
        $submenu['idevapp'] = array_merge($sorted, $rest); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
    }
}, 99);

add_action('admin_enqueue_scripts', function ($hook) {
    wp_register_style('idw-fonts', 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Thai:wght@400;500;600;700&display=swap', [], null);
    wp_register_style('idw-admin', IDW_URL . 'assets/admin.css', ['idw-fonts'], IDW_VERSION);
    wp_register_script('idw-admin', IDW_URL . 'assets/admin.js', ['jquery'], IDW_VERSION, true);
    $page = sanitize_key($_GET['page'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (in_array($page, ['idevapp', 'idw-setup', 'idw-modules', 'idw-themes', 'idw-updates'], true)) {
        wp_enqueue_style('idw-admin');
        wp_enqueue_script('idw-admin');
        if ($page === 'idw-setup') wp_enqueue_media();
    }
});

/* First activation → setup wizard. */
add_action('admin_init', function () {
    if (!get_transient('idw_go_setup') || wp_doing_ajax() || isset($_GET['activate-multi']) || !current_user_can('manage_options')) return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    delete_transient('idw_go_setup');
    wp_safe_redirect(admin_url('admin.php?page=idw-setup'));
    exit;
}, 20);

add_filter('plugin_action_links_' . IDW_BASENAME, function ($links) {
    array_unshift($links, '<a href="' . esc_url(admin_url('admin.php?page=idw-setup')) . '"><b>ตั้งค่าเว็บไซต์</b></a>', '<a href="' . esc_url(admin_url('admin.php?page=idw-modules')) . '">โมดูล</a>');
    return $links;
});

/* ---------- page shell ---------- */

function idw_open($title, $sub = '', $acts = '') {
    $page = sanitize_key($_GET['page'] ?? 'idevapp'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $tabs = ['idevapp' => ['แดชบอร์ด', 'home', 'edit_posts'], 'idw-setup' => ['ตั้งค่าเว็บไซต์', 'wand', 'manage_options'], 'idw-modules' => ['โมดูล', 'toggle', 'manage_options'], 'idw-themes' => ['ธีม', 'theme', 'switch_themes'], 'idw-updates' => ['อัปเดต', 'refresh', 'update_plugins']];
    $n = current_user_can('update_plugins') ? count(idw_pending_updates()) : 0;
    echo '<div class="wrap idw"><div class="idw-hero"><div class="idw-brand"><span class="lg">i<b>D</b></span><div><strong>iDevApp Website</strong><small>พัฒนาโดย iDevApp · idevapp.me</small></div><span class="ver">v' . esc_html(IDW_VERSION) . '</span></div>';
    echo '<h1>' . esc_html($title) . '</h1>' . ($sub ? '<p class="sub">' . esc_html($sub) . '</p>' : '');
    if ($acts) echo '<div class="acts">' . $acts . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts
    echo '<nav class="idw-tabs">';
    foreach ($tabs as $slug => [$label, $icon, $cap]) {
        if (!current_user_can($cap)) continue;
        echo '<a class="' . ($slug === $page ? 'on' : '') . '" href="' . esc_url(admin_url('admin.php?page=' . $slug)) . '">' . idw_icon($icon) . esc_html($label) . ($slug === 'idw-updates' && $n ? ' <span class="n">' . (int) $n . '</span>' : '') . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
    echo '</nav></div><div class="idw-body"><hr class="wp-header-end">';
}
function idw_close() {
    echo '<div class="idw-foot">iDevApp Website v' . esc_html(IDW_VERSION) . ' · พัฒนาโดย <a href="https://idevapp.me/" target="_blank" rel="noopener">iDevApp</a> · <a href="https://idevapp.me/" target="_blank" rel="noopener">ขอความช่วยเหลือ</a></div></div></div>';
}
function idw_note($text, $type = '') {
    echo '<div class="idw-note ' . esc_attr($type) . '">' . idw_icon($type === 'err' ? 'shield' : ($type === 'warn' ? 'bell' : 'check')) . '<div>' . wp_kses_post($text) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
function idw_btn($label, $url, $class = '', $icon = '', $attrs = '') {
    return '<a class="idw-btn ' . esc_attr($class) . '" href="' . esc_url($url) . '"' . $attrs . '>' . ($icon ? idw_icon($icon) : '') . esc_html($label) . '</a>';
}

/* ---------- dashboard ---------- */

/** Setup checklist: [key => [label, hint, done, url]] */
function idw_checklist() {
    $s = (array) get_option('idw_site', []);
    $theme = get_stylesheet();
    $ours = in_array($theme, IDW_THEMES, true);
    $cats = 0;
    foreach (array_keys(idw_news_categories()) as $slug) if (term_exists($slug, 'category')) $cats++;
    $front = get_option('show_on_front') === 'page' && get_post((int) get_option('page_on_front'));
    $posts = (int) (wp_count_posts('post')->publish ?? 0);
    return [
        'info' => ['ข้อมูลเว็บไซต์', 'ชื่อ โลโก้ เบอร์โทร ที่อยู่', !empty($s['name']) && (!empty($s['phone']) || !empty($s['address'])), admin_url('admin.php?page=idw-setup&step=info')],
        'theme' => ['เลือกแบบเว็บไซต์', 'แบบที่ 1 หรือแบบที่ 2', $ours, admin_url('admin.php?page=idw-setup&step=theme')],
        'modules' => ['เลือกโมดูลที่ใช้', 'เปิดเฉพาะส่วนที่ต้องการ', get_option('idw_modules', null) !== null && !empty(((array) get_option('idw_setup', []))['modules']), admin_url('admin.php?page=idw-setup&step=modules')],
        'content' => ['หน้าเว็บและหมวดข่าว', 'สร้างหน้าแรก เมนู และหมวดข่าว', $front && $cats >= 4, admin_url('admin.php?page=idw-setup&step=content')],
        'news' => ['ประกาศข่าวแรก', 'ลองเขียนประกาศ หรือนำเข้าจาก PDF', $posts > 0, idw_module_on('announcements') ? admin_url('admin.php?page=idw-news&tab=write') : admin_url('post-new.php')],
    ];
}

function idw_page_dashboard() {
    $check = idw_checklist();
    $done = count(array_filter(array_column($check, 2)));
    $pct = (int) round($done / count($check) * 100);
    $acts = idw_btn('ดูหน้าเว็บ', home_url('/'), 'glass', 'external', ' target="_blank" rel="noopener"');
    if (current_user_can('manage_options')) $acts = idw_btn($done < count($check) ? 'ตั้งค่าเว็บไซต์ต่อ' : 'ตัวช่วยตั้งค่า', admin_url('admin.php?page=idw-setup'), 'acc', 'wand') . $acts;
    idw_open(get_option('blogname') ?: 'เว็บไซต์ของคุณ', 'ภาพรวมเว็บไซต์ โมดูลที่เปิดใช้ และงานที่ต้องทำ', $acts);

    $loaded = $GLOBALS['idw_loaded'] ?? [];
    $count = wp_count_posts('post');
    $updates = current_user_can('update_plugins') ? idw_pending_updates() : [];
    $theme = wp_get_theme();
    echo '<div class="idw-stats">';
    echo '<a class="idw-stat" href="' . esc_url(admin_url('admin.php?page=idw-modules')) . '"><span class="ic">' . idw_icon('toggle') . '</span><div><b>' . count($loaded) . '/' . count(idw_module_list()) . '</b><span>โมดูลที่เปิดใช้</span></div></a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<a class="idw-stat b" href="' . esc_url(idw_module_on('announcements') ? admin_url('admin.php?page=idw-news&tab=list') : admin_url('edit.php')) . '"><span class="ic">' . idw_icon('news') . '</span><div><b>' . (int) ($count->publish ?? 0) . '</b><span>ข่าวที่เผยแพร่</span></div></a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<a class="idw-stat o" href="' . esc_url(idw_module_on('announcements') ? admin_url('admin.php?page=idw-news&tab=review') : admin_url('edit.php?post_status=pending')) . '"><span class="ic">' . idw_icon('clock') . '</span><div><b>' . (int) ($count->pending ?? 0) . ' · ' . (int) ($count->future ?? 0) . '</b><span>รออนุมัติ · ตั้งเวลาไว้</span></div></a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<a class="idw-stat v" href="' . esc_url(admin_url('admin.php?page=idw-updates')) . '"><span class="ic">' . idw_icon('refresh') . '</span><div><b>' . ($updates ? count($updates) . ' รายการ' : 'ล่าสุดแล้ว') . '</b><span>อัปเดต</span></div></a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div>';

    echo '<div class="idw-cols"><div>';
    // quick links of the modules that are on
    echo '<div class="idw-card"><h2>' . idw_icon('grid') . 'เมนูลัด</h2><p class="d">ส่วนที่เปิดใช้อยู่ — คลิกเพื่อตั้งค่าหรือใช้งาน</p><div class="idw-mods">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $list = idw_module_list();
    $shown = 0;
    foreach ($loaded as $k) {
        $m = $list[$k];
        if (!$m[6]) continue;
        $shown++;
        echo '<a class="idw-mod on" style="text-decoration:none;color:inherit" href="' . esc_url(admin_url($m[6])) . '"><span class="ic">' . idw_icon($m[4]) . '</span><span class="tx"><b>' . esc_html($m[1]) . '</b><p>' . esc_html(wp_trim_words($m[2], 14, '…')) . '</p></span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
    if (!$shown) echo '<p class="idw-empty">ยังไม่ได้เปิดโมดูล — <a href="' . esc_url(admin_url('admin.php?page=idw-modules')) . '">เลือกโมดูล</a></p>';
    echo '</div></div>';

    // recent news
    $recent = get_posts(['post_type' => 'post', 'post_status' => ['publish', 'future', 'pending', 'draft'], 'numberposts' => 6, 'orderby' => 'modified']);
    echo '<div class="idw-card"><h2>' . idw_icon('megaphone') . 'ประกาศข่าวล่าสุด</h2><p class="d">ข่าวที่แก้ไขล่าสุด</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if ($recent) {
        echo '<table class="idw-table"><tbody>';
        $st = ['publish' => ['เผยแพร่', 'ok'], 'future' => ['ตั้งเวลา', 'info'], 'pending' => ['รออนุมัติ', 'warn'], 'draft' => ['ร่าง', '']];
        foreach ($recent as $p) {
            [$l, $c] = $st[$p->post_status] ?? [$p->post_status, ''];
            $edit = idw_module_on('announcements') ? admin_url('admin.php?page=idw-news&tab=write&post=' . $p->ID) : get_edit_post_link($p->ID, '');
            echo '<tr><td><a href="' . esc_url($edit) . '"><b>' . esc_html($p->post_title ?: '(ไม่มีหัวเรื่อง)') . '</b></a></td><td style="width:110px"><span class="idw-chip ' . esc_attr($c) . '">' . esc_html($l) . '</span></td><td style="width:150px;color:#64748b">' . esc_html(idw_dt(get_post_timestamp($p, $p->post_status === 'future' ? 'date' : 'modified'))) . '</td></tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<div class="idw-empty">' . idw_icon('news') . '<p>ยังไม่มีข่าว</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
    echo '</div></div><div>';

    // checklist
    echo '<div class="idw-card"><h2>' . idw_icon('wand') . 'ตั้งค่าเว็บไซต์</h2><p class="d">เสร็จแล้ว ' . (int) $done . ' จาก ' . count($check) . ' ขั้น</p><div class="idw-progress"><i style="width:' . (int) $pct . '%"></i></div><ul class="idw-check">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $i = 0;
    foreach ($check as [$label, $hint, $ok, $url]) {
        $i++;
        echo '<li class="' . ($ok ? 'done' : '') . '"><span class="dot">' . ($ok ? '✓' : '') . '</span><span class="t"><b>' . esc_html($label) . '</b><small>' . esc_html($hint) . '</small></span>' . ($ok ? '' : '<a class="idw-btn sm" href="' . esc_url($url) . '">ทำต่อ</a>') . '</li>';
    }
    echo '</ul></div>';
    // theme
    echo '<div class="idw-card"><h2>' . idw_icon('theme') . 'ธีมที่ใช้</h2><p class="d">' . esc_html($theme->get('Name')) . ' · v' . esc_html($theme->get('Version')) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if ($theme->get_screenshot()) echo '<img src="' . esc_url($theme->get_screenshot()) . '" alt="" style="width:100%;border-radius:12px;border:1px solid #e2e8f0">';
    echo '<p style="margin:12px 0 0;display:flex;gap:8px;flex-wrap:wrap">' . idw_btn('ปรับแต่งหน้าตา', admin_url('customize.php'), 'sm', 'palette') . idw_btn('เปลี่ยนแบบ', admin_url('admin.php?page=idw-themes'), 'sm', 'theme') . '</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    // licence
    if (function_exists('idev_license_products') && current_user_can('manage_options')) {
        echo '<div class="idw-card"><h2>' . idw_icon('star') . 'ฟีเจอร์ Pro</h2><p class="d">ลงทะเบียนผู้ป่วย Pro · นัดหมาย Pro · คุกกี้ PDPA Pro ใช้ได้เมื่อมี license</p>' . idw_btn('จัดการ license', admin_url('admin.php?page=idev-license'), 'sm') . ' ' . idw_btn('ติดต่อ iDevApp', 'https://idevapp.me/', 'sm link', 'external', ' target="_blank" rel="noopener"') . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
    echo '</div></div>';
    idw_close();
}

/* ---------- modules ---------- */

add_action('admin_post_idw_modules', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_modules')) wp_die('ไม่มีสิทธิ์', 403);
    $keys = array_map('sanitize_key', array_keys((array) ($_POST['m'] ?? [])));
    $new = idw_set_modules($keys);
    $back = sanitize_key($_POST['back'] ?? '');
    if ($back === 'setup') {
        $setup = (array) get_option('idw_setup', []);
        $setup['modules'] = 1;
        update_option('idw_setup', $setup, false);
        wp_safe_redirect(admin_url('admin.php?page=idw-setup&step=content'));
    } else {
        wp_safe_redirect(admin_url('admin.php?page=idw-modules&done=saved&new=' . count($new)));
    }
    exit;
});

/** Toggle cards for the modules, grouped. $checked: keys switched on in the form. */
function idw_module_toggles($checked, $highlight = []) {
    $list = idw_module_list();
    $loaded = $GLOBALS['idw_loaded'] ?? [];
    $blocked = $GLOBALS['idw_blocked'] ?? [];
    foreach (idw_module_groups() as $g => [$gname, $gdesc]) {
        echo '<div class="idw-sec"><h2>' . esc_html($gname) . '</h2><p class="d">' . esc_html($gdesc) . '</p></div><div class="idw-mods">';
        foreach ($list as $k => $m) {
            if ($m[3] !== $g) continue;
            $locked = in_array($k, idw_theme_needs(), true);
            $on = $locked || in_array($k, $checked, true);
            $pro = strpos($k, '-pro') !== false;
            echo '<label class="idw-mod' . ($on ? ' on' : '') . '" data-mod="' . esc_attr($k) . '" data-needs="' . esc_attr(implode(',', $m[5])) . '"><span class="ic">' . idw_icon($m[4]) . '</span><span class="tx"><b>' . esc_html($m[1]) . '</b><p>' . esc_html($m[2]) . '</p><span class="meta">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            if ($pro) echo '<span class="idw-chip pro">Pro</span>';
            if ($locked) echo '<span class="idw-chip info">ธีมที่ใช้อยู่ต้องใช้</span>';
            elseif (in_array($k, $highlight, true)) echo '<span class="idw-chip acc">แนะนำสำหรับธีมนี้</span>';
            if (isset($blocked[$k])) echo '<span class="idw-chip warn">ทำงานจากปลั๊กอินแยก</span>';
            elseif (in_array($k, $loaded, true) && $m[6]) echo '<a href="' . esc_url(admin_url($m[6])) . '">ตั้งค่า →</a>';
            echo '</span></span><span class="idw-switch"><input type="checkbox" name="m[' . esc_attr($k) . ']" value="1"' . checked($on, true, false) . disabled($locked, true, false) . '><span></span></span></label>';
        }
        echo '</div>';
    }
}

function idw_page_modules() {
    if (!current_user_can('manage_options')) wp_die('ไม่มีสิทธิ์');
    idw_open('โมดูล', 'เปิดเฉพาะส่วนที่ใช้ เว็บจะเบาและหลังบ้านจะไม่รก — ปิดแล้วข้อมูลยังอยู่ เปิดใหม่เมื่อไรก็กลับมาเหมือนเดิม');
    $done = sanitize_key($_GET['done'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if ($done === 'saved') idw_note('บันทึกแล้ว' . (!empty($_GET['new']) ? ' — โมดูลที่เพิ่งเปิดจะเตรียมข้อมูลให้อัตโนมัติ' : '')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if ($done === 'takeover') idw_note('ปิดปลั๊กอินแยกแล้ว ตอนนี้ใช้โมดูลในปลั๊กอินนี้ (ข้อมูลเดิมอยู่ครบ)');
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" id="idw-mod-form">';
    wp_nonce_field('idw_modules');
    echo '<input type="hidden" name="action" value="idw_modules">';
    idw_module_toggles(idw_enabled_modules());
    echo '<div class="idw-savebar"><span class="msg">เปิด <b id="idw-mod-count">' . count(idw_enabled_modules()) . '</b> จาก ' . count(idw_module_list()) . ' โมดูล · โมดูล Pro ต้องเปิดโมดูลหลักด้วย (เปิดให้อัตโนมัติ)</span><button class="idw-btn pri">' . idw_icon('check') . 'บันทึก</button></div></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    idw_close();
}

/* ---------- themes ---------- */

function idw_page_themes() {
    if (!current_user_can('switch_themes')) wp_die('ไม่มีสิทธิ์');
    idw_open('ธีม', 'ธีมที่มาพร้อมปลั๊กอิน ติดตั้งและตั้งค่าให้ในคลิกเดียว — อัปเดตอัตโนมัติจาก iDevApp');
    if (!empty($_GET['err'])) idw_note(esc_html(wp_unslash($_GET['err'])), 'err'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
    if (($_GET['done'] ?? '') === 'use') idw_note('เปลี่ยนธีมแล้ว ตั้งค่าข้อมูลเว็บไซต์ให้ธีมใหม่เรียบร้อย — <a href="' . esc_url(admin_url('admin.php?page=idw-setup&step=content')) . '">สร้างหน้าเว็บและเมนู →</a>'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (($_GET['done'] ?? '') === 'install') idw_note('ติดตั้ง / อัปเดตธีมแล้ว'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    idw_theme_cards('idw-themes');
    idw_close();
}

/** Theme cards with install / use buttons. */
function idw_theme_cards($back) {
    $cur = get_stylesheet();
    echo '<div class="idw-themes">';
    foreach (idw_themes() as $slug => $t) {
        $have = idw_theme_installed_version($slug);
        $bundled = idw_theme_bundled_version($slug);
        $is = $cur === $slug;
        echo '<div class="idw-theme' . ($is ? ' cur' : '') . '" style="cursor:default">';
        if ($is) echo '<span class="badge idw-chip ok">ใช้อยู่</span>';
        echo '<div class="shot" style="background-image:url(' . esc_url(idw_theme_screenshot($slug)) . ')"></div><div class="in"><h3>' . esc_html($t['name']) . ' <span class="idw-chip">' . esc_html($t['title']) . '</span></h3><p>' . esc_html($t['desc']) . '</p><div class="tags">';
        foreach ($t['tags'] as $tag) echo '<span class="idw-chip info">' . esc_html($tag) . '</span>';
        echo '</div><p style="font-size:12.5px">' . ($have !== '' ? 'ติดตั้งแล้ว v' . esc_html($have) : 'ยังไม่ได้ติดตั้ง') . ($bundled !== '' && $have !== '' && version_compare($bundled, $have, '>') ? ' · มีเวอร์ชันใหม่ v' . esc_html($bundled) : '') . '</p><div class="row">';
        $form = function ($do, $label, $class) use ($slug, $back) {
            return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('idw_theme', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_theme"><input type="hidden" name="theme" value="' . esc_attr($slug) . '"><input type="hidden" name="do" value="' . esc_attr($do) . '"><input type="hidden" name="back" value="' . esc_attr($back) . '"><button class="idw-btn ' . $class . '">' . esc_html($label) . '</button></form>';
        };
        if (!$is) echo $form('use', $have !== '' ? 'ใช้แบบนี้' : 'ติดตั้งและใช้แบบนี้', 'pri'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        if ($have !== '' && $bundled !== '' && version_compare($bundled, $have, '>')) echo $form('install', 'อัปเดตธีม', ''); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        if ($is) echo idw_btn('ปรับแต่งหน้าตา', admin_url('customize.php'), '', 'palette') . idw_btn('ดูหน้าเว็บ', home_url('/'), 'link', 'external', ' target="_blank" rel="noopener"'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '</div></div></div>';
    }
    echo '</div>';
}

/* ---------- updates ---------- */

function idw_page_updates() {
    if (!current_user_can('update_plugins')) wp_die('ไม่มีสิทธิ์');
    $m = idw_manifest();
    $pending = idw_pending_updates();
    $check = '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="display:inline">' . wp_nonce_field('idw_check_updates', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_check_updates"><button class="idw-btn glass">' . idw_icon('refresh') . 'ตรวจสอบเดี๋ยวนี้</button></form>';
    idw_open('อัปเดต', 'ปลั๊กอินและธีมอัปเดตจาก GitHub ของ iDevApp — ตรวจทุก 12 ชั่วโมงและติดตั้งให้อัตโนมัติ หรือกดอัปเดตเองได้ทันที', $check);
    if (isset($_GET['checked'])) idw_note((int) $_GET['checked'] ? 'พบอัปเดต ' . (int) $_GET['checked'] . ' รายการ' : 'ตรวจแล้ว — ทุกอย่างเป็นเวอร์ชันล่าสุด'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (isset($_GET['saved'])) idw_note('บันทึกแล้ว'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (!empty($m['error'])) idw_note('ติดต่อเซิร์ฟเวอร์อัปเดตไม่ได้ (' . esc_html($m['error']) . ') — จะลองใหม่อัตโนมัติ', 'warn');

    echo '<div class="idw-cols"><div><div class="idw-card"><h2>' . idw_icon('box') . 'ปลั๊กอินและธีม</h2><p class="d">เวอร์ชันที่ติดตั้งกับเวอร์ชันล่าสุด</p><table class="idw-table"><thead><tr><th>รายการ</th><th>ติดตั้งอยู่</th><th>ล่าสุด</th><th></th></tr></thead><tbody>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $rows = [['plugin', 'idevapp-website', 'iDevApp Website', IDW_VERSION]];
    foreach (IDW_THEMES as $slug) { $v = idw_theme_installed_version($slug); if ($v !== '') $rows[] = ['theme', $slug, wp_get_theme($slug)->get('Name'), $v]; }
    $by = [];
    foreach ($pending as $p) $by[$p['slug']] = $p;
    foreach ($rows as [$kind, $slug, $name, $v]) {
        $latest = (string) ($m[$kind === 'plugin' ? 'plugins' : 'themes'][$slug]['version'] ?? '');
        echo '<tr><td><b>' . esc_html($name) . '</b><br><small style="color:#64748b">' . ($kind === 'plugin' ? 'ปลั๊กอิน' : 'ธีม') . '</small></td><td>v' . esc_html($v) . '</td><td>' . ($latest !== '' ? 'v' . esc_html($latest) : '—') . '</td><td style="text-align:right">';
        if (isset($by[$slug])) echo '<a class="idw-btn pri sm" href="' . esc_url($by[$slug]['url']) . '">' . idw_icon('refresh') . 'อัปเดตเป็น v' . esc_html($by[$slug]['to']) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        elseif ($latest !== '' && version_compare($latest, $v, '>')) echo '<span class="idw-chip warn">กด “ตรวจสอบเดี๋ยวนี้”</span>';
        else echo '<span class="idw-chip ok">ล่าสุดแล้ว</span>';
        echo '</td></tr>';
    }
    echo '</tbody></table></div>';
    $log = (string) ($m['plugins']['idevapp-website']['changelog'] ?? '');
    if ($log !== '') echo '<div class="idw-card"><h2>' . idw_icon('list') . 'มีอะไรใหม่</h2><div style="font-size:14px;line-height:1.7">' . wp_kses_post($log) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div><div><div class="idw-card"><h2>' . idw_icon('gear') . 'อัปเดตอัตโนมัติ</h2><p class="d">เมื่อ iDevApp ออกเวอร์ชันใหม่ เว็บจะติดตั้งให้เองภายใน 12 ชั่วโมง ข้อมูลและการตั้งค่าเดิมอยู่ครบ</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('idw_auto_update', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_auto_update"><label class="idw-opt"><span class="idw-switch"><input type="checkbox" name="on" value="1"' . checked(idw_auto_update_on(), true, false) . ' onchange="this.form.submit()"><span></span></span><span><b>อัปเดตอัตโนมัติ</b><small>ปลั๊กอิน iDevApp Website และธีมแบบที่ 1 / แบบที่ 2</small></span></label></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $last = (int) get_site_option('idw_last_check', 0);
    $next = wp_next_scheduled('idw_update_check');
    $fmt = 'idw_dt';
    echo '<ul class="idw-check" style="margin-top:10px"><li><span class="t"><b>ตรวจล่าสุด</b><small>' . esc_html($last ? $fmt($last) : 'ยังไม่เคย') . '</small></span></li><li><span class="t"><b>ตรวจครั้งถัดไป</b><small>' . esc_html($next ? $fmt($next) : '—') . '</small></span></li><li><span class="t"><b>แหล่งอัปเดต</b><small>github.com/idev2023/idevapp-web</small></span></li></ul></div></div></div>';
    idw_close();
}
