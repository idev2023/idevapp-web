/* iDevApp Website — back office */
jQuery(function ($) {
  // module toggles: card state, Pro needs its free module, count
  var $mods = $('.idw-mod[data-mod]');
  function sync() {
    $mods.each(function () { $(this).toggleClass('on', $(this).find('input').prop('checked')); });
    $('#idw-mod-count').text($mods.find('input:checked').length);
  }
  $mods.on('change', 'input', function () {
    var $card = $(this).closest('.idw-mod'), key = $card.data('mod'), on = this.checked;
    if (on) {
      String($card.data('needs') || '').split(',').filter(Boolean).forEach(function (k) { $('.idw-mod[data-mod="' + k + '"] input').prop('checked', true); });
    } else {
      $mods.filter(function () { return String($(this).data('needs') || '').split(',').indexOf(key) > -1; }).find('input').prop('checked', false);
    }
    sync();
  });
  sync();

  // logo picker
  $('.idw-logo-pick [data-pick]').on('click', function (e) {
    e.preventDefault();
    if (!window.wp || !wp.media) return;
    var $w = $(this).closest('.idw-logo-pick');
    var f = wp.media({ title: 'เลือกโลโก้', multiple: false, library: { type: 'image' } });
    f.on('select', function () {
      var a = f.state().get('selection').first().toJSON();
      $w.find('input[type=hidden]').val(a.id);
      $w.find('.pv').html('<img alt="" src="' + ((a.sizes && (a.sizes.thumbnail || a.sizes.medium)) || a).url + '">');
    });
    f.open();
  });
  $('.idw-logo-pick [data-clear]').on('click', function (e) {
    e.preventDefault();
    var $w = $(this).closest('.idw-logo-pick');
    $w.find('input[type=hidden]').val('');
    $w.find('.pv').html('โลโก้');
  });

  // theme choice cards in the wizard
  $('.idw-theme input[type=radio]').on('change', function () {
    $('.idw-theme').removeClass('cur');
    $(this).closest('.idw-theme').addClass('cur');
    $('[data-theme-submit]').prop('disabled', false);
  });

  // busy state on long actions
  $('form[data-busy]').on('submit', function () {
    var $b = $(this).find('button[type=submit],button:not([type])').last();
    $b.prop('disabled', true).data('t', $b.html()).html('<span class="spinner is-active" style="float:none;margin:0 6px 0 0"></span>' + ($(this).data('busy') || 'กำลังทำ…'));
  });
});
