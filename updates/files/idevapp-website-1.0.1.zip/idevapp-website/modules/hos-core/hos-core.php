<?php
/**
 * Module: ระบบเว็บโรงพยาบาล — ประเภทข่าว/ประกาศ ฟิลด์เสริม ไฟล์แนบ ปีงบประมาณ (ITA) สไลด์หน้าแรก
 * หน้าเข้าสู่ระบบ (ซ่อน URL ได้) และ shortcode [hos_posts] [hos_slider] · ใช้คู่กับธีม iDevApp แบบที่ 1
 */
defined( 'ABSPATH' ) || exit;
if ( defined( 'HOS_CORE_VER' ) ) {
	return;
}

define( 'HOS_CORE_VER', IDW_VERSION );
define( 'HOS_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'HOS_CORE_URL', plugin_dir_url( __FILE__ ) );

require_once HOS_CORE_DIR . 'includes/post-types.php';   // ประเภทเนื้อหา
require_once HOS_CORE_DIR . 'includes/fields.php';       // ฟิลด์เสริม (get_field)
require_once HOS_CORE_DIR . 'includes/fields-compat.php';
require_once HOS_CORE_DIR . 'includes/attachments.php';  // ไฟล์แนบเอกสาร / ปีงบประมาณ
require_once HOS_CORE_DIR . 'includes/slider.php';       // สไลด์หน้าแรก
require_once HOS_CORE_DIR . 'includes/login.php';        // URL เข้าสู่ระบบ + หน้าเข้าสู่ระบบ
require_once HOS_CORE_DIR . 'includes/shortcodes.php';   // [hos_posts] [hos_slider]
require_once HOS_CORE_DIR . 'includes/pages.php';        // สร้างหน้าเว็บสำหรับธีมแบบที่ 1
require_once HOS_CORE_DIR . 'includes/admin-fixes.php';  // ตัวแก้ไขบล็อกหลังบ้าน

register_activation_hook( __FILE__, function () {
	hos_register_slide_type();
	flush_rewrite_rules();
} );
