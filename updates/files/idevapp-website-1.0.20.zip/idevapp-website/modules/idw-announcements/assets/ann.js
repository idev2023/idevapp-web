/* ประกาศข่าว: form, schedule, PDF import (pdf.js, OCR with tesseract.js for scanned files) */
(function ($) {
  'use strict';
  var C = window.IDW_ANN || {};
  var M = C.months || [], D = C.days || [];

  /* ---------- editor helpers ---------- */
  function ed() { return window.tinymce && tinymce.get('idw_ann_details'); }
  function getBody() { var e = ed(); return (e && !e.isHidden() ? e.getContent() : $('#idw_ann_details').val()) || ''; }
  function setBody(h) { var e = ed(); if (e && !e.isHidden()) e.setContent(h); else $('#idw_ann_details').val(h); }
  function blank(h) { return String(h).replace(/<[^>]*>|&nbsp;|\s|…/g, '') === ''; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function catId() { return $('#ann-cats input:checked').val() || ''; }

  /* ---------- category template ---------- */
  $('#ann-cats').on('change', 'input', function () {
    var t = (C.tpl || {})[this.value];
    if (t && blank(getBody())) setBody(t);
  });
  $('#ann-tpl').on('click', function () {
    var t = (C.tpl || {})[catId()];
    if (!t) { $('#ann-cats').addClass('flash'); setTimeout(function () { $('#ann-cats').removeClass('flash'); }, 900); return; }
    if (blank(getBody()) || window.confirm('แทนที่รายละเอียดเดิมด้วยแม่แบบของหมวดนี้?')) setBody(t);
  });

  /* ---------- counters ---------- */
  $('.cnt').each(function () {
    var $c = $(this), $i = $('#' + $c.data('for')), max = $i.attr('maxlength');
    function u() { $c.text(($i.val() || '').length + ' / ' + max); }
    $i.on('input', u); u();
  });

  /* ---------- schedule ---------- */
  function be(dateStr, timeStr) {
    if (!dateStr) return '';
    var p = dateStr.split('-'), d = new Date(+p[0], +p[1] - 1, +p[2]);
    return 'วัน' + D[d.getDay()] + 'ที่ ' + (+p[2]) + ' ' + M[+p[1] - 1] + ' ' + (+p[0] + 543) + (timeStr ? ' เวลา ' + timeStr + ' น.' : '');
  }
  function whenText() {
    var later = $('input[name=when]:checked').val() === 'later';
    $('#ann-later').prop('hidden', !later);
    var d = $('#ann-pub-date').val(), t = $('#ann-pub-time').val();
    var past = later && d && new Date(d + 'T' + (t || '00:00')) < new Date();
    $('#ann-pub-be').text(later ? (past ? 'เวลาที่เลือกผ่านไปแล้ว — จะแสดงทันที (ลงวันที่ ' + be(d, t) + ')' : 'จะแสดงบนเว็บ ' + be(d, t)) : '').toggleClass('past', !!past);
    var $s = $('#ann-send');
    $s.find('.t').text(later && !past ? $s.data('later') : $s.data('now'));
    var on = $('#ann-exp-on').prop('checked');
    $('#ann-exp').prop('hidden', !on);
    $('#ann-exp-be').text(on ? 'ซ่อนจากเว็บ ' + be($('#ann-exp-date').val(), $('#ann-exp-time').val()) : '');
  }
  $(document).on('change input', 'input[name=when],#ann-pub-date,#ann-pub-time,#ann-exp-on,#ann-exp-date,#ann-exp-time', whenText);
  function ymd(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function hm(d) { return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); }
  $('.quick').on('click', 'button', function () {
    var d = new Date(), q = $(this).data('q');
    if (q === 'tomorrow8') { d.setDate(d.getDate() + 1); d.setHours(8, 0, 0, 0); }
    if (q === 'monday8') { d.setDate(d.getDate() + ((8 - d.getDay()) % 7 || 7)); d.setHours(8, 0, 0, 0); }
    if (q === 'plus1h') { d.setMinutes(0, 0, 0); d.setHours(d.getHours() + 1); }
    $('#ann-pub-date').val(ymd(d)); $('#ann-pub-time').val(hm(d)); whenText();
  });
  whenText();
  $('#ann-form').on('submit', function (e) {
    var sub = e.originalEvent && e.originalEvent.submitter;
    if (sub && sub.value === 'send' && !catId()) { e.preventDefault(); $('#ann-cats').addClass('flash'); $('html,body').animate({ scrollTop: $('#ann-cats').offset().top - 120 }, 200); setTimeout(function () { $('#ann-cats').removeClass('flash'); }, 900); }
  });

  /* ---------- media ---------- */
  function coverSet(id, url) { $('#ann-cover').val(id || ''); $('#ann-cover-prev').html(id ? '<img alt="" src="' + esc(url) + '">' : '<span><span class="dashicons dashicons-format-image"></span>ยังไม่มีรูป</span>'); }
  function fileAdd(id, name, label) {
    var $li = $('<li><input type="hidden" name="files[]"><span class="fn"><span class="dashicons dashicons-media-default"></span><span></span></span><input name="file_labels[]" placeholder="ชื่อที่แสดง" class="idw-in"><button type="button" class="button-link-delete" data-rm aria-label="ลบ"><span class="dashicons dashicons-no-alt"></span></button></li>');
    $li.find('input[type=hidden]').val(id); $li.find('.fn span:last').text(name); $li.find('input[name^=file_labels]').val(label || '');
    $('#ann-files').append($li);
  }
  $('#ann-files').on('click', '[data-rm]', function () { $(this).closest('li').remove(); });
  if (window.wp && wp.media) {
    $('#ann-cover-pick').on('click', function () {
      var f = wp.media({ title: 'รูปหน้าปก', multiple: false, library: { type: 'image' } });
      f.on('select', function () { var a = f.state().get('selection').first().toJSON(); coverSet(a.id, ((a.sizes && a.sizes.medium) || a).url); });
      f.open();
    });
    $('#ann-file-add').on('click', function () {
      var f = wp.media({ title: 'แนบไฟล์', multiple: true });
      f.on('select', function () { f.state().get('selection').each(function (m) { var a = m.toJSON(); fileAdd(a.id, a.filename || a.title, a.title); }); });
      f.open();
    });
  }
  $('#ann-cover-clear').on('click', function () { coverSet(0); });

  /* ---------- PDF import ---------- */
  var $pdf = $('#ann-pdf');
  if (!$pdf.length) return;
  var state = null;

  function load(src) {
    return new Promise(function (ok, bad) {
      var s = document.createElement('script'); s.src = src; s.async = true; s.onload = ok; s.onerror = function () { bad(new Error('โหลดตัวอ่าน PDF ไม่ได้ (ตรวจการเชื่อมต่ออินเทอร์เน็ต)')); };
      document.head.appendChild(s);
    });
  }
  function pdfLib() {
    if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
    return load(C.pdfjs).then(function () { window.pdfjsLib.GlobalWorkerOptions.workerSrc = C.pdfworker; return window.pdfjsLib; });
  }
  function busy(on, text, pct) {
    $('#ann-drop').prop('hidden', on || !!state);
    $('#ann-pdf-busy').prop('hidden', !on);
    if (text) $('#ann-pdf-step').text(text);
    if (pct != null) $('#ann-pdf-bar').css('width', Math.max(5, Math.min(100, pct)) + '%');
  }

  /* Thai text from PDFs: presentation forms (PUA) back to normal letters, sara am, mark order */
  var PUA = { '\uF700': '\u0E10', '\uF701': '\u0E34', '\uF702': '\u0E35', '\uF703': '\u0E36', '\uF704': '\u0E37', '\uF705': '\u0E48', '\uF706': '\u0E49', '\uF707': '\u0E4A', '\uF708': '\u0E4B', '\uF709': '\u0E4C', '\uF70A': '\u0E48', '\uF70B': '\u0E49', '\uF70C': '\u0E4A', '\uF70D': '\u0E4B', '\uF70E': '\u0E4C', '\uF70F': '\u0E0D', '\uF710': '\u0E31', '\uF711': '\u0E4D', '\uF712': '\u0E47', '\uF713': '\u0E48', '\uF714': '\u0E49', '\uF715': '\u0E4A', '\uF716': '\u0E4B', '\uF717': '\u0E4C', '\uF718': '\u0E38', '\uF719': '\u0E39', '\uF71A': '\u0E3A' };
  function thaiFix(s) {
    s = String(s).replace(/[\u0000-\u0008\u000B-\u001F\u007F\uFFFD\u200B]/g, '').replace(/[\uF700-\uF71A]/g, function (c) { return PUA[c] || ''; });
    s = s.normalize ? s.normalize('NFC') : s;
    s = s.replace(/\u0E4D([\u0E48-\u0E4B]?)\u0E32/g, '$1\u0E33');
    s = s.replace(/\u0E33([\u0E48-\u0E4B])/g, '$1\u0E33');
    s = s.replace(/([\u0E48-\u0E4C])([\u0E31\u0E34-\u0E37\u0E47])/g, '$2$1'); // tone mark before an upper vowel
    s = s.replace(/([\u0E48-\u0E4C])([\u0E38-\u0E3A])/g, '$2$1');
    s = s.replace(/\u0E40\u0E40/g, '\u0E41');
    s = s.replace(/([\u0E31\u0E34-\u0E3A\u0E47-\u0E4E]) (?=[\u0E01-\u0E2E])/g, '$1'); // a space right after a Thai mark is a PDF artifact
    return s.replace(/[ \t\u00A0]+/g, ' ');
  }
  var TH = /[\u0E00-\u0E7F]/;
  function joinText(a, b) { if (!a) return b; if (!b) return a; if (/^(พ\.ศ\.|ค\.ศ\.|[0-9๐-๙])/.test(b) || /[0-9๐-๙.:)]$/.test(a)) return a + ' ' + b; return TH.test(a.slice(-1)) && TH.test(b.charAt(0)) ? a + b : a + ' ' + b; }

  /* text items of one page → lines [{t, x, y, h}] */
  function pageLines(items) {
    var it = items.filter(function (i) { return i.str && i.str.trim() !== '' || i.str === ' '; }).map(function (i) {
      var h = Math.abs(i.transform[3]) || Math.abs(i.transform[0]) || i.height || 10;
      return { s: i.str, x: i.transform[4], y: i.transform[5], w: i.width, h: h };
    });
    it.sort(function (a, b) { return Math.abs(b.y - a.y) > Math.min(a.h, b.h) * 0.45 ? b.y - a.y : a.x - b.x; });
    var lines = [], cur = null;
    it.forEach(function (i) {
      if (!cur || Math.abs(cur.y - i.y) > Math.min(cur.h, i.h) * 0.6) { cur = { parts: [i], y: i.y, h: i.h }; lines.push(cur); } else { cur.parts.push(i); cur.h = Math.max(cur.h, i.h); }
    });
    return lines.map(function (l) {
      l.parts.sort(function (a, b) { return a.x - b.x; });
      var t = '', end = null;
      l.parts.forEach(function (p) {
        if (end !== null && p.x - end > l.h * 0.28 && !/\s$/.test(t) && !/^\s/.test(p.s)) t += ' ';
        t += p.s; end = p.x + p.w;
      });
      return { t: thaiFix(t).trim(), x: l.parts[0].x, y: l.y, h: l.h };
    }).filter(function (l) { return l.t !== ''; });
  }

  function render(page, width) {
    var v = page.getViewport({ scale: 1 }), sc = width / v.width, vp = page.getViewport({ scale: sc });
    var cv = document.createElement('canvas'); cv.width = Math.round(vp.width); cv.height = Math.round(vp.height);
    var ctx = cv.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height);
    return page.render({ canvasContext: ctx, viewport: vp }).promise.then(function () { return cv; });
  }

  function ocr(canvases) {
    return (window.Tesseract ? Promise.resolve() : load(C.tess)).then(function () {
      var out = [];
      return canvases.reduce(function (p, cv, i) {
        return p.then(function () {
          return Tesseract.recognize(cv, 'tha+eng', { logger: function (m) { if (m.status === 'recognizing text') busy(true, 'กำลังอ่านภาพสแกน หน้า ' + (i + 1) + '/' + canvases.length + '…', 35 + (i + m.progress) / canvases.length * 60); } })
            .then(function (r) {
              var ls = String(r.data.text || '').split(/\n/).map(function (s) { return thaiFix(s).replace(/([\u0E00-\u0E7F]) (?=[\u0E00-\u0E7F])/g, '$1').trim(); }).filter(Boolean);
              out.push(ls.map(function (t, k) { return { t: t, x: 0, y: -k, h: 10 }; }));
            });
        });
      }, Promise.resolve()).then(function () { return out; });
    });
  }

  var RE_TOPIC = /^เร\u0E37?\u0E48?อง\s*/;
  var STOP = /^(ด้วย|ตาม|เนื่องจาก|โดยที่|อาศัย|ข้าพเจ้า|เรียน|อ้างถึง|สิ่งที่ส่งมาด้วย|ประกาศ\s*ณ|ทั้งนี้|จึง|\(|[-–—]|\d+[.)]|[๐-๙]+[.)])/;
  function guessCat(text) {
    var rules = [
      [/ราคากลาง/, ['midprice', 'ราคากลาง']],
      [/ผลการ(จัด|พิจารณา|คัดเลือก)|ผู้ชนะ|ผู้ได้รับการคัดเลือก|สรุปผล/, ['results', 'สรุปผล']],
      [/ประกวดราคา|e-?bidding|เชิญชวน|สอบราคา|ประมูล/i, ['bidding', 'ประกวดราคา']],
      [/จัดซื้อ|จัดจ้าง|พัสดุ|ซื้อ.{0,20}(วัสดุ|ครุภัณฑ์)|จ้าง.{0,20}(เหมา|บริการ)/, ['procurement', 'จัดซื้อ']],
      [/รับสมัคร|สรรหา|เลือกสรร|คัดเลือก.{0,20}(บุคคล|พนักงาน|ลูกจ้าง)|ขึ้นบัญชี|ตำแหน่งว่าง|สอบ(แข่งขัน|คัดเลือก)/, ['jobs', 'รับสมัคร']],
      [/กิจกรรม|โครงการ.{0,30}(อบรม|รณรงค์)|ร่วมกัน|พิธี/, ['activity', 'กิจกรรม']],
      [/ประกาศ/, ['announcement', 'ประกาศ']],
      [/./, ['news', 'ประชาสัมพันธ์']]
    ];
    var cats = C.cats || {};
    for (var r = 0; r < rules.length; r++) {
      if (!rules[r][0].test(text)) continue;
      for (var id in cats) { var s = String(cats[id]).split(' '); if (s[0] === rules[r][1][0]) return id; }
      for (var id2 in cats) if (String(cats[id2]).indexOf(rules[r][1][1]) > -1) return id2;
    }
    return '';
  }

  /* words of a text (Thai has no spaces: the browser's Thai word breaker is used) */
  function words(t) {
    try {
      if (window.Intl && Intl.Segmenter) return Array.from(new Intl.Segmenter('th', { granularity: 'word' }).segment(t));
    } catch (e) { /* fall back below */ }
    return null;
  }
  /* short summary: the first paragraphs, at most n words, cut at the end of a word (and of a sentence when one ends near it) */
  function shortSum(paras, n) {
    var text = '';
    for (var i = 0; i < paras.length && text.length < 2000; i++) {
      var p = paras[i].trim();
      if (!p || /^(\d+[.)]|[๐-๙]+[.)])/.test(p) && text) break; // a list starts: the intro is enough
      text = text ? text + ' ' + p : p;
    }
    text = text.replace(/\s+/g, ' ').trim();
    if (!text) return '';
    var seg = words(text), out = '', count = 0;
    if (seg) {
      for (var k = 0; k < seg.length; k++) {
        if (seg[k].isWordLike) { if (count >= n) break; count++; }
        out += seg[k].segment;
      }
    } else {
      var w = text.split(' '); out = w.slice(0, n).join(' '); count = Math.min(w.length, n);
    }
    out = out.trim();
    if (out.length >= text.length) return text;
    var stop = Math.max(out.lastIndexOf(' '), out.lastIndexOf('。'), out.lastIndexOf('.'));
    if (stop > out.length * 0.7 && /[ .]/.test(out.charAt(stop))) out = out.slice(0, stop); // end at a space (Thai sentence break) when it is close
    return out.replace(/[\s,;:–-]+$/, '') + '…';
  }

  /* lines of all pages → {title, org, summary, html, dateLine} */
  function parse(pages) {
    var all = [];
    pages.forEach(function (ls, p) { ls.forEach(function (l) { if (!/^[-–(]?\s*[0-9๐-๙]{1,3}\s*[-–)]?$/.test(l.t)) all.push($.extend({ p: p }, l)); }); });
    if (!all.length) return null;
    var head = all.slice(0, 25), ti = -1, org = '';
    for (var i = 0; i < head.length; i++) if (RE_TOPIC.test(head[i].t)) { ti = i; break; }
    for (var j = 0; j < (ti > -1 ? ti : Math.min(head.length, 8)); j++) if (/^(ประกาศ|คำสั่ง)/.test(head[j].t) && head[j].t.length < 120) { org = head[j].t; break; }
    var title = '', start = 0;
    if (ti > -1) {
      title = head[ti].t.replace(RE_TOPIC, '').replace(/^[:：]\s*/, '');
      start = ti + 1;
      // the title often wraps to a second (and third) line
      while (start < all.length && start < ti + 3 && all[start].p === all[ti].p && !STOP.test(all[start].t) && all[start].t.length < 90 && Math.abs(all[start].h - all[ti].h) < all[ti].h * 0.25 && all[start].x > all[ti].x - 5) { title = joinText(title, all[start].t); start++; }
    } else {
      var best = null;
      head.slice(0, 15).forEach(function (l, k) { if (l.t.length >= 6 && (!best || l.h > best.h + 0.5)) { best = l; best.k = k; } });
      title = best ? best.t : all[0].t; start = best ? best.k + 1 : 1;
      if (/^(ประกาศ|คำสั่ง)/.test(title) && start < all.length && all[start].t.length < 120 && !STOP.test(all[start].t)) { org = title; title = all[start].t.replace(RE_TOPIC, ''); start++; }
    }
    // body until "ประกาศ ณ วันที่" (signature lines after it are left out)
    var body = [], dateLine = '';
    for (var k = start; k < all.length; k++) {
      if (/^(ประกาศ|สั่ง)\s*ณ\s*วันที/.test(all[k].t)) { dateLine = all[k].t; break; }
      body.push(all[k]);
    }
    if (body.length && /^-+$/.test(body[0].t.replace(/\s/g, ''))) body.shift();
    // paragraphs: a new one starts at an indented line, a list item, or after a short line
    var minX = Math.min.apply(null, body.map(function (l) { return l.x; }).concat([1e9]));
    var paras = [], cur = '', prev = null;
    body.forEach(function (l) {
      var indent = l.x > minX + l.h * 1.2, item = /^(\d+[.)]|[๐-๙]+[.)]|[-•●▪]\s)/.test(l.t), short = prev && prev.t.length < 35 && prev.x <= minX + prev.h * 1.2;
      if (!cur || indent || item || short || (prev && l.p !== prev.p && indent)) { if (cur) paras.push(cur); cur = l.t; } else cur = joinText(cur, l.t);
      prev = l;
    });
    if (cur) paras.push(cur);
    paras = paras.filter(function (s) { return s.replace(/[-–—_.\s]/g, '') !== ''; });
    var first = paras[0] || '';
    var summary = shortSum(paras, +C.words || 50);
    var html = paras.map(function (s) { return '<p>' + esc(s) + '</p>'; }).join('\n');
    if (org) html = '<p><strong>' + esc(org) + '</strong><br>เรื่อง ' + esc(title) + '</p>\n' + html;
    if (dateLine) html += '\n<p>' + esc(dateLine) + '</p>';
    return { title: title.trim(), org: org, summary: summary, html: html, dateLine: dateLine, cat: guessCat(title + ' ' + org + ' ' + first) };
  }

  function readFile(file) {
    if (!file) return;
    if (!/pdf$/i.test(file.type) && !/\.pdf$/i.test(file.name)) { window.alert('กรุณาเลือกไฟล์ PDF'); return; }
    if (file.size > 40 * 1024 * 1024) { window.alert('ไฟล์ใหญ่เกิน 40 MB'); return; }
    state = null;
    $('#ann-pdf-out').prop('hidden', true);
    busy(true, 'กำลังเปิดไฟล์…', 5);
    var doc, pages = [], first;
    pdfLib().then(function (lib) {
      return file.arrayBuffer().then(function (buf) { return lib.getDocument({ data: buf, cMapUrl: C.cmaps, cMapPacked: true }).promise; });
    }).then(function (d) {
      doc = d;
      var n = Math.min(doc.numPages, 6), chain = Promise.resolve();
      for (var i = 1; i <= n; i++) (function (i) {
        chain = chain.then(function () { return doc.getPage(i); }).then(function (pg) {
          if (i === 1) first = pg;
          busy(true, 'กำลังอ่านหน้า ' + i + '/' + n + '…', 10 + i / n * 25);
          return pg.getTextContent().then(function (tc) { pages.push(pageLines(tc.items)); });
        });
      })(i);
      return chain;
    }).then(function () {
      var chars = pages.reduce(function (a, ls) { return a + ls.reduce(function (b, l) { return b + l.t.replace(/\s/g, '').length; }, 0); }, 0);
      var scanned = chars < 40 * pages.length;
      var txt = pages.map(function (ls) { return ls.map(function (l) { return l.t; }).join(' '); }).join(' ');
      var garbled = !scanned && ((txt.match(/[\uFFFD]/g) || []).length > 5);
      if ((scanned || garbled) && C.ocr) {
        busy(true, 'ไฟล์นี้เป็นภาพสแกน กำลังเตรียมอ่านตัวอักษร…', 30);
        var n2 = Math.min(doc.numPages, 2), cvs = [], ch = Promise.resolve();
        for (var i = 1; i <= n2; i++) (function (i) { ch = ch.then(function () { return doc.getPage(i); }).then(function (pg) { return render(pg, 2000); }).then(function (cv) { cvs.push(cv); }); })(i);
        return ch.then(function () { return ocr(cvs); }).then(function (o) { return { pages: o, ocr: true }; });
      }
      return { pages: pages, ocr: false, scanned: scanned };
    }).then(function (r) {
      busy(true, 'กำลังสรุป…', 97);
      var res = parse(r.pages) || { title: file.name.replace(/\.pdf$/i, ''), summary: '', html: '', cat: '' };
      res.ocr = r.ocr; res.scanned = r.scanned && !r.ocr; res.file = file; res.pagesTotal = doc.numPages;
      state = res;
      return render(first, 300).then(function (cv) {
        var t = document.getElementById('ann-pdf-thumb'); t.width = cv.width; t.height = cv.height; t.getContext('2d').drawImage(cv, 0, 0);
        res.firstPage = first;
      });
    }).then(function () {
      busy(false);
      var r = state;
      $('#ann-pdf-name').text(r.file.name);
      $('#ann-pdf-meta').text(r.pagesTotal + ' หน้า' + (r.ocr ? ' · อ่านจากภาพสแกน' : ''));
      $('#ann-pdf-title').val(r.title); $('#ann-pdf-sum').val(r.summary);
      $('#ann-pdf-hint').text(r.scanned ? 'ไฟล์นี้เป็นภาพสแกนและไม่ได้เปิดการอ่านภาพ (OCR) — แนบไฟล์และใช้หน้าแรกเป็นรูปปกได้ ใส่หัวเรื่องเอง' : (r.ocr ? 'อ่านจากภาพสแกน ตรวจตัวสะกดก่อนเผยแพร่' : 'ตรวจและแก้ข้อความได้ก่อนเติมลงฟอร์ม'));
      var cats = C.cats || {};
      $('#ann-pdf-cat').text(r.cat && cats[r.cat] ? String(cats[r.cat]).split(' ').slice(1).join(' ') : '—');
      $('#ann-pdf-use-cat').prop('checked', !!r.cat).prop('disabled', !r.cat);
      $('#ann-pdf-use-body').prop('checked', !!r.html && !!C.body).prop('disabled', !r.html); // default: title and short summary only (setting)
      $('#ann-drop').prop('hidden', true);
      $('#ann-pdf-out').prop('hidden', false);
    }).catch(function (e) {
      busy(false); state = null; $('#ann-drop').prop('hidden', false);
      window.alert('อ่านไฟล์ไม่สำเร็จ: ' + (e && e.message ? e.message : e));
    });
  }

  function upload(blob, name, type) {
    return fetch(C.rest, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'X-WP-Nonce': C.nonce, 'Content-Type': type, 'Content-Disposition': 'attachment; filename="' + (name.replace(/[^\x20-\x7E]/g, '').replace(/["\\]/g, '') || 'file') + '"; filename*=UTF-8\'\'' + encodeURIComponent(name) },
      body: blob
    }).then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j && j.message ? j.message : 'HTTP ' + r.status); return j; }); });
  }

  $('#ann-pdf-fill').on('click', function () {
    if (!state) return;
    var $b = $(this).prop('disabled', true), r = state, jobs = [];
    if ($('#ann-pdf-use-title').prop('checked') && $('#ann-pdf-title').val()) $('#ann-title').val($('#ann-pdf-title').val()).trigger('input');
    if ($('#ann-pdf-use-sum').prop('checked')) $('#ann-sum').val($('#ann-pdf-sum').val()).trigger('input');
    if ($('#ann-pdf-use-cat').prop('checked') && r.cat) $('#ann-cats input[value="' + r.cat + '"]').prop('checked', true);
    if ($('#ann-pdf-use-body').prop('checked') && r.html) {
      if (blank(getBody()) || /…/.test(getBody()) || window.confirm('แทนที่รายละเอียดเดิมด้วยข้อความจาก PDF?')) setBody(r.html);
    }
    if ($('#ann-pdf-use-attach').prop('checked')) {
      jobs.push(upload(r.file, r.file.name, 'application/pdf').then(function (a) {
        var label = ($('#ann-title').val() || r.file.name.replace(/\.pdf$/i, '')).slice(0, 200);
        fileAdd(a.id, (a.media_details && a.media_details.file ? String(a.media_details.file).split('/').pop() : r.file.name), label);
      }));
    }
    if ($('#ann-pdf-use-cover').prop('checked') && r.firstPage) {
      jobs.push(render(r.firstPage, 1200).then(function (cv) {
        return new Promise(function (ok) { cv.toBlob(ok, 'image/jpeg', 0.86); });
      }).then(function (blob) {
        return upload(blob, r.file.name.replace(/\.pdf$/i, '') + '-cover.jpg', 'image/jpeg');
      }).then(function (a) {
        coverSet(a.id, (a.media_details && a.media_details.sizes && a.media_details.sizes.medium ? a.media_details.sizes.medium.source_url : a.source_url));
      }));
    }
    $('#ann-from-pdf').val('1');
    $b.html('<span class="spinner is-active" style="float:none;margin:0 6px 0 0"></span>กำลังอัปโหลด…');
    Promise.all(jobs).then(function () {
      $b.html('<span class="dashicons dashicons-yes"></span>เติมแล้ว — ตรวจแล้วกดเผยแพร่');
    }).catch(function (e) {
      $b.prop('disabled', false).html('<span class="dashicons dashicons-download"></span>เติมลงฟอร์ม');
      window.alert('อัปโหลดไฟล์ไม่สำเร็จ: ' + (e && e.message ? e.message : e));
    });
  });

  $('#ann-pdf-reset').on('click', function () {
    state = null; $('#ann-pdf-out').prop('hidden', true); $('#ann-drop').prop('hidden', false);
    $('#ann-pdf-fill').prop('disabled', false).html('<span class="dashicons dashicons-download"></span>เติมลงฟอร์ม');
    $('#ann-pdf-file').val('');
  });
  $('#ann-drop').on('click keydown', function (e) { if (e.type === 'click' || e.key === 'Enter' || e.key === ' ') { e.preventDefault(); $('#ann-pdf-file').trigger('click'); } });
  $('#ann-pdf-file').on('change', function () { readFile(this.files[0]); });
  $pdf.on('dragover dragenter', function (e) { e.preventDefault(); $pdf.addClass('over'); })
    .on('dragleave dragend', function () { $pdf.removeClass('over'); })
    .on('drop', function (e) { e.preventDefault(); $pdf.removeClass('over'); var f = e.originalEvent.dataTransfer.files; if (f && f[0]) readFile(f[0]); });

  // test hook (also lets developers check the reader from the console)
  window.idwAnnParse = function (pages) { return parse(pages); };
  window.idwAnnThaiFix = thaiFix;
  window.idwAnnLines = pageLines;
})(jQuery);
