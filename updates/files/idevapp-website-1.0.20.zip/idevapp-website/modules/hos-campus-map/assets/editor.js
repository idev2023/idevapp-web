/* ผังโรงพยาบาล 3 มิติ — บล็อกในตัวแก้ไข */
(function (wp) {
  var el = wp.element.createElement, C = wp.components, BE = wp.blockEditor, SSR = wp.serverSideRender;
  wp.blocks.registerBlockType('hos/campus', {
    edit: function (p) {
      return el(wp.element.Fragment, null,
        el(BE.InspectorControls, null, el(C.PanelBody, { title: 'ผังโรงพยาบาล' },
          el(C.ToggleControl, { label: 'แสดงเต็มหน้าจอ', checked: !!p.attributes.full, onChange: function (v) { p.setAttributes({ full: v }); } }),
          el('p', { style: { fontSize: 12, color: '#666' } }, 'แก้ไขอาคาร บริการรายชั้น จุดสังเกต ทางเดิน และ QR ได้ที่เมนู “ผังโรงพยาบาล” ในหลังบ้าน'))),
        el('div', BE.useBlockProps(), el(C.Disabled, null, el(SSR, { block: 'hos/campus', attributes: p.attributes }))));
    },
    save: function () { return null; }
  });
})(window.wp);
