<?php
/**
 * Module: ย้ายเว็บเดิม
 * ใส่ที่อยู่เว็บเดิม → วิเคราะห์โครงสร้าง (ระบบที่ใช้ เมนู หน้า ข่าว หมวด ข้อมูลติดต่อ โลโก้ สี)
 * → เลือกสิ่งที่จะนำเข้า → นำเข้าทีละรายการ (รูปและเอกสารถูกคัดลอกเข้าคลังสื่อ เนื้อหาเป็นบล็อกที่แก้ได้ทันที)
 * Running it again updates what was imported before instead of making copies.
 */
defined('ABSPATH') || exit;
if (defined('IDW_IMP_VERSION')) return;
define('IDW_IMP_VERSION', defined('IDW_VERSION') ? IDW_VERSION : '1.0.0');

require_once __DIR__ . '/includes/analyze.php';
require_once __DIR__ . '/includes/convert.php';

function idw_imp_scan() { $s = get_option('idw_import_scan'); return is_array($s) ? $s : null; }

/* ---------- analyse ---------- */

add_action('admin_post_idw_imp_analyze', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_imp_analyze')) wp_die('ไม่มีสิทธิ์', 403);
    @set_time_limit(120); // phpcs:ignore
    $r = idw_imp_analyze(wp_unslash($_POST['url'] ?? '')); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- validated inside
    if (is_wp_error($r)) { set_transient('idw_imp_msg_' . get_current_user_id(), '!' . $r->get_error_message(), 120); wp_safe_redirect(admin_url('admin.php?page=idw-import')); exit; }
    update_option('idw_import_scan', $r, false);
    wp_safe_redirect(admin_url('admin.php?page=idw-import&step=pick'));
    exit;
});

/* ---------- import, one item per request (called by assets/import.js) ---------- */

function idw_imp_find($src) {
    global $wpdb;
    return (int) $wpdb->get_var($wpdb->prepare("SELECT p.ID FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_idw_src' WHERE m.meta_value = %s AND p.post_type IN ('post','page') AND p.post_status <> 'trash' LIMIT 1", $src)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}

/** Category of our site for a category of the old site (by name → our known slugs, else created). */
function idw_imp_cat($name, $slug = '') {
    $map = ['midprice' => '/ราคากลาง/u', 'results' => '/สรุปผล|ผลการจัดซื้อ|ผู้ชนะ/u', 'bidding' => '/ประกวดราคา|e-?bidding|สอบราคา|เชิญชวน/iu', 'procurement' => '/จัดซื้อ|จัดจ้าง|พัสดุ|procure/iu', 'jobs' => '/รับสมัคร|สมัครงาน|สรรหา|job|career/iu', 'activity' => '/กิจกรรม|ภาพข่าว|activit/iu', 'announcement' => '/ประกาศ|announce/iu', 'news' => '/ข่าว|ประชาสัมพันธ์|news|uncategori|ไม่มีหมวด/iu'];
    foreach ($map as $s => $re) if (preg_match($re, $name . ' ' . $slug)) { $t = get_term_by('slug', $s, 'category'); if ($t) return (int) $t->term_id; }
    $t = get_term_by('name', $name, 'category');
    if ($t) return (int) $t->term_id;
    $n = wp_insert_term($name, 'category', $slug ? ['slug' => sanitize_title($slug)] : []);
    return is_wp_error($n) ? (int) get_option('default_category') : (int) $n['term_id'];
}

/** Save a post / page from imported parts. */
function idw_imp_save($type, $src, $d, $opt) {
    $id = idw_imp_find($src);
    $arr = ['post_type' => $type, 'post_title' => $d['title'] !== '' ? $d['title'] : wp_basename((string) wp_parse_url($src, PHP_URL_PATH)), 'post_content' => $d['content'], 'post_status' => $opt['status']];
    if (!empty($d['excerpt']) && $type === 'post') $arr['post_excerpt'] = mb_substr($d['excerpt'], 0, 400);
    if ($opt['dates'] && !empty($d['ts'])) { $arr['post_date'] = wp_date('Y-m-d H:i:s', $d['ts']); $arr['post_date_gmt'] = gmdate('Y-m-d H:i:s', $d['ts']); }
    if (!empty($d['slug'])) $arr['post_name'] = $d['slug'];
    if (!empty($d['parent'])) $arr['post_parent'] = (int) $d['parent'];
    if (!empty($d['cats'])) $arr['post_category'] = $d['cats'];
    kses_remove_filters(); // block markup from our converter is already cleaned
    if ($id) { $arr['ID'] = $id; $r = wp_update_post(wp_slash($arr), true); } else { $r = wp_insert_post(wp_slash($arr), true); }
    kses_init_filters();
    if (is_wp_error($r)) return $r;
    update_post_meta($r, '_idw_src', $src);
    if (!empty($d['image'])) set_post_thumbnail($r, (int) $d['image']);
    if (!empty($d['files'])) {
        $key = (function_exists('idw_module_on') && idw_module_on('attachments')) ? '_idev_attachments' : 'ihub_attachments';
        update_post_meta($r, $key, wp_slash(wp_json_encode(array_map(function ($f) { return ['id' => (int) $f['id'], 'label' => mb_substr((string) $f['label'], 0, 200), 'label_en' => '']; }, $d['files']), JSON_UNESCAPED_UNICODE)));
    }
    return ['id' => (int) $r, 'updated' => (bool) $id];
}

add_action('wp_ajax_idw_imp_item', function () {
    if (!current_user_can('manage_options') || !check_ajax_referer('idw_imp', false, false)) wp_send_json_error('ไม่มีสิทธิ์', 403);
    @set_time_limit(120); // phpcs:ignore
    $scan = idw_imp_scan();
    if (!$scan) wp_send_json_error('วิเคราะห์เว็บเดิมใหม่อีกครั้ง');
    $opt = ['status' => ($_POST['status'] ?? '') === 'draft' ? 'draft' : 'publish', 'dates' => !empty($_POST['dates']), 'media' => !empty($_POST['media'])];
    $kind = sanitize_key($_POST['kind'] ?? '');
    $res = null;
    if ($kind === 'wp-page' || $kind === 'wp-post') {
        // WordPress source: one REST object
        $type = $kind === 'wp-page' ? 'pages' : 'posts';
        $rid = (int) ($_POST['id'] ?? 0);
        $page = (int) ($_POST['page'] ?? 0);
        $api = trailingslashit($scan['api']) . 'wp/v2/' . $type . ($rid ? '/' . $rid . '?_embed=1' : '?per_page=10&page=' . max(1, $page) . '&orderby=date&order=desc&_embed=1');
        $r = idw_imp_get($api, ['timeout' => 30]);
        if (is_wp_error($r)) wp_send_json_error($r->get_error_message());
        $j = json_decode(wp_remote_retrieve_body($r), true);
        $list = $rid ? [$j] : (array) $j;
        $done = [];
        foreach ($list as $o) {
            if (empty($o['id'])) continue;
            $src = (string) $o['link'];
            $id = idw_imp_find($src);
            $files = [];
            $content = idw_imp_blocks_from_html((string) ($o['content']['rendered'] ?? ''), $src, $id, $opt['media'], $files);
            $d = ['title' => wp_strip_all_tags(html_entity_decode($o['title']['rendered'] ?? '')), 'content' => $content, 'ts' => strtotime((string) ($o['date_gmt'] ?? '') . ' UTC') ?: 0, 'slug' => urldecode((string) ($o['slug'] ?? '')), 'excerpt' => wp_strip_all_tags(html_entity_decode((string) ($o['excerpt']['rendered'] ?? ''))), 'files' => $files];
            $fm = $o['_embedded']['wp:featuredmedia'][0]['source_url'] ?? '';
            if ($fm && $opt['media']) $d['image'] = idw_imp_media($fm, $id);
            if ($kind === 'wp-post') {
                $cats = [];
                foreach ((array) ($o['_embedded']['wp:term'][0] ?? []) as $t) if (($t['taxonomy'] ?? '') === 'category') $cats[] = idw_imp_cat(html_entity_decode($t['name']), $t['slug']);
                $d['cats'] = $cats ?: [idw_imp_cat('ข่าวประชาสัมพันธ์', 'news')];
            } elseif (!empty($o['parent'])) {
                $parent_src = '';
                foreach ($scan['pages'] as $p) if ((int) $p['id'] === (int) $o['parent']) $parent_src = $p['u'];
                if ($parent_src) $d['parent'] = idw_imp_find($parent_src);
            }
            $s = idw_imp_save($kind === 'wp-page' ? 'page' : 'post', $src, $d, $opt);
            $done[] = is_wp_error($s) ? ['ok' => 0, 't' => $d['title'], 'e' => $s->get_error_message()] : ['ok' => 1, 't' => $d['title'], 'edit' => get_edit_post_link($s['id'], ''), 'up' => $s['updated']];
        }
        wp_send_json_success(['items' => $done, 'more' => !$rid && count($list) === 10]);
    }
    if ($kind === 'page' || $kind === 'news') {
        $url = esc_url_raw(wp_unslash($_POST['url'] ?? ''));
        if (!$url || !idw_imp_same_site($url, $scan['site'])) wp_send_json_error('ลิงก์ไม่ได้อยู่ในเว็บเดิม');
        $id = idw_imp_find($url);
        $d = idw_imp_page_from_html($url, $id, $opt['media']);
        if (is_wp_error($d)) wp_send_json_error($d->get_error_message());
        if ($opt['media']) $d['image'] = $d['image_url'] ? idw_imp_media(idw_imp_abs($d['image_url'], $url), $id) : $d['first_image'];
        if ($kind === 'news') {
            $cat = (int) ($_POST['cat'] ?? 0);
            $chosen = $cat && term_exists($cat, 'category') ? $cat : idw_imp_cat('ข่าวประชาสัมพันธ์', 'news');
            // a clearly different kind of news (procurement, jobs, activities …) goes to its own category
            $guess = preg_match('/ราคากลาง|ประกวดราคา|จัดซื้อ|จัดจ้าง|สรุปผล|รับสมัคร|สรรหา|กิจกรรม/u', $d['title']) ? idw_imp_cat($d['title']) : 0;
            $d['cats'] = [$guess ?: $chosen];
        } else {
            $d['slug'] = sanitize_title(urldecode(wp_basename(untrailingslashit((string) wp_parse_url($url, PHP_URL_PATH)))));
            if (preg_match('/^(index|default|home)(\.\w+)?$/', $d['slug'])) unset($d['slug']);
        }
        $s = idw_imp_save($kind === 'news' ? 'post' : 'page', $url, $d, $opt);
        if (is_wp_error($s)) wp_send_json_error($s->get_error_message());
        wp_send_json_success(['items' => [['ok' => 1, 't' => $d['title'], 'edit' => get_edit_post_link($s['id'], ''), 'up' => $s['updated'], 'empty' => trim(wp_strip_all_tags($d['content'])) === '']]]);
    }
    if ($kind === 'info') {
        $i = $scan['info'];
        $site = function_exists('idw_site_info') ? idw_site_info() : [];
        foreach (['name', 'tagline', 'phone', 'email', 'address', 'facebook', 'line'] as $k) if (!empty($i[$k]) && (empty($site[$k]) || !empty($_POST['overwrite']))) $site[$k] = $i[$k];
        if (!empty($i['logo']) && empty($site['logo'])) { $lid = idw_imp_media($i['logo'], 0, 'โลโก้'); if ($lid) $site['logo'] = $lid; }
        update_option('idw_site', $site, false);
        if (function_exists('idw_apply_site_info')) idw_apply_site_info();
        if (!empty($_POST['color']) && !empty($i['color'])) update_option('idw_brand_color', sanitize_hex_color($i['color']));
        wp_send_json_success(['items' => [['ok' => 1, 't' => 'ข้อมูลเว็บไซต์ โลโก้ และช่องทางติดต่อ' . (!empty($_POST['color']) && !empty($i['color']) ? ' · สีหลัก ' . $i['color'] : '')]]]);
    }
    if ($kind === 'menu') {
        $made = idw_imp_build_menu($scan);
        wp_send_json_success(['items' => [is_wp_error($made) ? ['ok' => 0, 't' => 'เมนู', 'e' => $made->get_error_message()] : ['ok' => 1, 't' => 'เมนูหลักจากเว็บเดิม (' . $made . ' รายการ)']]]);
    }
    wp_send_json_error('ไม่รู้จักรายการ');
});

/** Menu from the old navigation: links to imported pages point to the new pages, others stay as links. */
function idw_imp_build_menu($scan) {
    if (empty($scan['menu'])) return new WP_Error('idw_imp', 'ไม่พบเมนูในเว็บเดิม');
    $name = 'เมนูหลัก (นำเข้าจากเว็บเดิม)';
    $obj = wp_get_nav_menu_object($name);
    if ($obj) wp_delete_nav_menu($obj->term_id);
    $menu_id = wp_create_nav_menu($name);
    if (is_wp_error($menu_id)) return $menu_id;
    $n = 0;
    $add = function ($items, $parent) use (&$add, $menu_id, &$n, $scan) {
        foreach ($items as $it) {
            $args = ['menu-item-title' => $it['t'], 'menu-item-status' => 'publish', 'menu-item-parent-id' => $parent];
            $pid = $it['u'] ? idw_imp_find($it['u']) : 0;
            if (!$pid && $it['u'] && rtrim($it['u'], '/') === rtrim($scan['site'], '/')) { $args['menu-item-type'] = 'custom'; $args['menu-item-url'] = home_url('/'); }
            elseif ($pid) { $args['menu-item-type'] = 'post_type'; $args['menu-item-object'] = get_post_type($pid); $args['menu-item-object-id'] = $pid; }
            else { $args['menu-item-type'] = 'custom'; $args['menu-item-url'] = $it['u'] && idw_imp_same_site($it['u'], $scan['site']) ? home_url((string) wp_parse_url($it['u'], PHP_URL_PATH)) : ($it['u'] ?: '#'); }
            $mid = wp_update_nav_menu_item($menu_id, 0, $args);
            if (is_wp_error($mid)) continue;
            $n++;
            if (!empty($it['c'])) $add($it['c'], $mid);
        }
    };
    $add($scan['menu'], 0);
    $locs = get_registered_nav_menus();
    if ($locs) {
        $set = get_theme_mod('nav_menu_locations', []);
        $loc = isset($locs['primary']) ? 'primary' : (isset($locs['main']) ? 'main' : array_key_first($locs));
        $set[$loc] = $menu_id;
        set_theme_mod('nav_menu_locations', $set);
        if (get_stylesheet() === 'idevapp-theme-1') set_theme_mod('hos_menu_source', 'wp');
    }
    return $n;
}

/* ---------- page ---------- */

add_action('admin_menu', function () {
    add_submenu_page('idevapp', 'ย้ายเว็บเดิม', 'ย้ายเว็บเดิม', 'manage_options', 'idw-import', 'idw_imp_page');
}, 22);
add_action('admin_enqueue_scripts', function () {
    if (($_GET['page'] ?? '') !== 'idw-import') return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    wp_enqueue_style('idw-admin');
    wp_enqueue_script('idw-admin');
    wp_enqueue_style('idw-imp', plugin_dir_url(__FILE__) . 'assets/import.css', ['idw-admin'], IDW_IMP_VERSION);
    wp_enqueue_script('idw-imp', plugin_dir_url(__FILE__) . 'assets/import.js', ['jquery'], IDW_IMP_VERSION, true);
    wp_localize_script('idw-imp', 'IDW_IMP', ['ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('idw_imp')]);
});

function idw_imp_page() {
    if (!current_user_can('manage_options')) wp_die('ไม่มีสิทธิ์');
    $scan = idw_imp_scan();
    $step = sanitize_key($_GET['step'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    idw_open('ย้ายเว็บเดิม', 'ใส่ที่อยู่เว็บเดิม ระบบจะวิเคราะห์โครงสร้าง แล้วนำหน้าเว็บ ข่าว รูป เอกสาร เมนู และข้อมูลติดต่อเข้ามาเป็นบล็อกที่แก้ไขได้ทันทีในธีมใหม่');
    $msg = get_transient('idw_imp_msg_' . get_current_user_id());
    if ($msg) { delete_transient('idw_imp_msg_' . get_current_user_id()); idw_note(esc_html(ltrim($msg, '!')), strpos($msg, '!') === 0 ? 'err' : ''); }
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="idw-card imp-url" data-busy="กำลังวิเคราะห์เว็บเดิม… (ไม่เกิน 1 นาที)">' . wp_nonce_field('idw_imp_analyze', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_imp_analyze"><span class="ic">' . idw_icon('globe') . '</span><input type="url" name="url" class="idw-in" required placeholder="https://www.เว็บเดิม.go.th/" value="' . esc_attr($scan['url'] ?? '') . '"><button class="idw-btn acc lg">' . idw_icon('spark') . ($scan ? 'วิเคราะห์ใหม่' : 'วิเคราะห์เว็บเดิม') . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if (!$scan) {
        echo '<div class="idw-grid">';
        foreach ([['spark', 'วิเคราะห์โครงสร้าง', 'รู้ว่าเว็บเดิมสร้างด้วยอะไร มีกี่หน้า กี่ข่าว เมนูเป็นอย่างไร โลโก้ สี และช่องทางติดต่อ'], ['upload', 'นำเข้าเนื้อหา', 'คัดลอกหน้าเว็บและข่าว พร้อมรูปและไฟล์ PDF / Word เข้าคลังสื่อ วันที่ข่าวตรงกับของเดิม'], ['grid', 'แก้ไขได้ทันที', 'เนื้อหาถูกแปลงเป็นบล็อก (ย่อหน้า หัวข้อ รายการ รูป ตาราง วิดีโอ) ในธีมแบบที่ 1 หรือแบบที่ 2']] as [$i, $t, $d]) echo '<div class="idw-mod on"><span class="ic">' . idw_icon($i) . '</span><span class="tx"><b>' . esc_html($t) . '</b><p>' . esc_html($d) . '</p></span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '</div><p class="idw-note warn" style="margin-top:16px">' . idw_icon('shield') . '<span>นำเข้าเฉพาะเว็บของหน่วยงานคุณเองหรือที่ได้รับอนุญาต · รองรับ WordPress (ผ่าน REST API — ได้ครบที่สุด) Joomla Drupal และเว็บ HTML ทั่วไป (ผ่าน sitemap และลิงก์ในหน้า)</span></p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        idw_close();
        return;
    }
    $plat = ['wordpress' => 'WordPress', 'joomla' => 'Joomla', 'drupal' => 'Drupal', 'wix' => 'Wix', 'google-sites' => 'Google Sites', 'html' => 'เว็บ HTML ทั่วไป'][$scan['platform']] ?? $scan['platform'];
    $i = $scan['info'];
    $c = $scan['counts'];
    echo '<div class="idw-stats"><div class="idw-stat"><span class="ic">' . idw_icon('globe') . '</span><div><b>' . esc_html($plat) . '</b><span>' . ($scan['source'] === 'rest' ? 'อ่านผ่าน REST API (ครบที่สุด)' : 'อ่านจาก sitemap / ลิงก์ในหน้า') . '</span></div></div><div class="idw-stat b"><span class="ic">' . idw_icon('file') . '</span><div><b>' . (int) ($c['pages'] ?? 0) . '</b><span>หน้าเว็บ</span></div></div><div class="idw-stat o"><span class="ic">' . idw_icon('news') . '</span><div><b>' . (int) ($c['news'] ?? 0) . '</b><span>ข่าว / โพสต์</span></div></div><div class="idw-stat v"><span class="ic">' . idw_icon('grid') . '</span><div><b>' . count($scan['menu']) . '</b><span>เมนูหลัก' . (isset($c['media']) && $c['media'] >= 0 ? ' · สื่อ ' . (int) $c['media'] . ' ไฟล์' : '') . '</span></div></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if (!empty($scan['rest_error'])) idw_note('เว็บเดิมเป็น WordPress แต่ ' . esc_html($scan['rest_error']) . ' — จะอ่านจากหน้าเว็บแทน', 'warn');
    echo '<div class="idw-cols"><div>';
    // site info
    echo '<div class="idw-card"><h2>' . idw_icon('building') . 'ข้อมูลเว็บไซต์ที่พบ</h2><div class="imp-info">' . ($i['logo'] ? '<img src="' . esc_url($i['logo']) . '" alt="" referrerpolicy="no-referrer">' : '') . '<div class="imp-kv">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    foreach (['name' => 'ชื่อ', 'tagline' => 'คำอธิบาย', 'phone' => 'โทร', 'email' => 'อีเมล', 'address' => 'ที่อยู่', 'facebook' => 'Facebook', 'line' => 'LINE'] as $k => $l) if (!empty($i[$k])) echo '<b>' . esc_html($l) . '</b><span>' . esc_html($i[$k]) . '</span>';
    if (!empty($i['color'])) echo '<b>สีหลัก</b><span><i class="imp-sw" style="background:' . esc_attr($i['color']) . '"></i>' . esc_html($i['color']) . '</span>';
    echo '</div></div><div class="idw-opts" style="margin-top:12px"><label class="idw-opt"><input type="checkbox" data-job="info" checked><span><b>ใช้ข้อมูลนี้กับเว็บใหม่</b><small>ชื่อ โลโก้ เบอร์โทร อีเมล ที่อยู่ — ช่องที่ตั้งไว้แล้วจะไม่ถูกเขียนทับ</small></span></label>' . (!empty($i['color']) ? '<label class="idw-opt"><input type="checkbox" id="imp-color" checked><span><b>ใช้สีหลักของเว็บเดิม</b><small>ปรับเปลี่ยนภายหลังได้ที่ หน้าตา → ปรับแต่ง → สีหลักของเว็บ</small></span></label>' : '') . '</div></div>';
    // menu
    echo '<div class="idw-card"><h2>' . idw_icon('list') . 'โครงสร้างเมนู</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if ($scan['menu']) {
        $tree = function ($items) use (&$tree) { $h = '<ul>'; foreach ($items as $it) $h .= '<li><span>' . esc_html($it['t']) . '</span>' . ($it['c'] ? $tree($it['c']) : '') . '</li>'; return $h . '</ul>'; };
        echo '<div class="imp-tree">' . $tree($scan['menu']) . '</div><label class="idw-opt" style="margin-top:10px"><input type="checkbox" data-job="menu" checked><span><b>สร้างเมนูหลักจากโครงสร้างนี้</b><small>ลิงก์ไปหน้าที่นำเข้าจะชี้ไปหน้าใหม่ — แก้ได้ที่ หน้าตา → เมนู</small></span></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    } else echo '<p class="d">ไม่พบเมนูในหน้าแรกของเว็บเดิม — ใช้เมนูของธีมใหม่</p>';
    echo '</div>';
    // pages
    echo '<div class="idw-card"><h2>' . idw_icon('file') . 'หน้าเว็บ <small class="imp-cnt" data-for="page"></small></h2><p class="d">เลือกหน้าที่จะนำเข้า · <a href="#" data-all="page">เลือกทั้งหมด</a> · <a href="#" data-none="page">ไม่เลือก</a></p><div class="imp-list">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    foreach ($scan['pages'] as $p) {
        $exists = idw_imp_find($p['u']);
        echo '<label><input type="checkbox" data-kind="' . ($scan['source'] === 'rest' ? 'wp-page' : 'page') . '" data-group="page" value="' . esc_attr($scan['source'] === 'rest' ? $p['id'] : $p['u']) . '" checked><span>' . esc_html($p['t'] ?: $p['u']) . '<small>' . esc_html(urldecode((string) wp_parse_url($p['u'], PHP_URL_PATH))) . '</small></span>' . ($exists ? '<em class="idw-chip ok">นำเข้าแล้ว</em>' : '') . '</label>';
    }
    if (!$scan['pages']) echo '<p class="d">ไม่พบหน้าเว็บ</p>';
    echo '</div></div></div><div>';
    // news
    echo '<div class="idw-card"><h2>' . idw_icon('news') . 'ข่าว / โพสต์</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if ($scan['source'] === 'rest') {
        echo '<p class="d">' . (int) ($c['news'] ?? 0) . ' ข่าว · หมวดของเว็บเดิมจะจับคู่กับหมวดข่าวของเว็บใหม่ให้อัตโนมัติ (ประชาสัมพันธ์ จัดซื้อจัดจ้าง ราคากลาง รับสมัครงาน …)</p>';
        if ($scan['cats']) { echo '<div class="imp-cats">'; foreach ($scan['cats'] as $ct) if ($ct['count']) echo '<span class="idw-chip">' . esc_html($ct['name']) . ' · ' . (int) $ct['count'] . '</span>'; echo '</div>'; }
        echo '<label class="idw-opt" style="margin-top:10px"><input type="checkbox" data-job="wp-posts" data-total="' . (int) ($c['news'] ?? 0) . '"' . (($c['news'] ?? 0) ? ' checked' : '') . '><span><b>นำเข้าข่าวทั้งหมด</b><small>ใหม่สุดก่อน ครั้งละ 10 ข่าว — หยุดและทำต่อได้</small></span></label>';
    } else {
        $cats = get_terms(['taxonomy' => 'category', 'hide_empty' => false]);
        echo '<p class="d">ข่าวที่พบจากลิงก์ในเว็บเดิม · เข้าหมวด <select id="imp-cat" class="idw-in" style="width:auto;min-height:32px;padding:2px 8px">';
        foreach ($cats as $ct) echo '<option value="' . (int) $ct->term_id . '"' . selected($ct->slug, 'news', false) . '>' . esc_html($ct->name) . '</option>';
        echo '</select> · <a href="#" data-all="news">ทั้งหมด</a> · <a href="#" data-none="news">ไม่เลือก</a></p><div class="imp-list">';
        foreach ($scan['news'] as $p) echo '<label><input type="checkbox" data-kind="news" data-group="news" value="' . esc_attr($p['u']) . '" checked><span>' . esc_html($p['t'] ?: $p['u']) . '<small>' . esc_html(urldecode((string) wp_parse_url($p['u'], PHP_URL_PATH))) . '</small></span>' . (idw_imp_find($p['u']) ? '<em class="idw-chip ok">นำเข้าแล้ว</em>' : '') . '</label>';
        if (!$scan['news']) echo '<p class="d">ไม่พบลิงก์ข่าว</p>';
        echo '</div>';
    }
    echo '</div>';
    // options + run
    echo '<div class="idw-card imp-run"><h2>' . idw_icon('upload') . 'นำเข้า</h2><div class="idw-opts"><label class="idw-opt"><input type="checkbox" id="imp-media" checked><span><b>คัดลอกรูปและไฟล์เอกสาร</b><small>เข้าคลังสื่อของเว็บใหม่ ไม่ต้องพึ่งเว็บเดิม</small></span></label><label class="idw-opt"><input type="checkbox" id="imp-dates" checked><span><b>ใช้วันที่เดิมของข่าว</b></span></label><label class="idw-opt"><input type="checkbox" id="imp-draft"><span><b>นำเข้าเป็นฉบับร่าง</b><small>ตรวจก่อนแสดงบนเว็บ</small></span></label></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div class="imp-prog" hidden><div class="bar"><i></i></div><p class="st"></p></div><p style="display:flex;gap:8px;margin:14px 0 0"><button type="button" class="idw-btn pri lg" id="imp-go" style="flex:1">' . idw_icon('upload') . 'เริ่มนำเข้า</button><button type="button" class="idw-btn" id="imp-stop" hidden>หยุด</button></p><ol class="imp-log"></ol></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div></div>';
    echo '<p class="idw-note" style="margin-top:6px">' . idw_icon('wand') . '<span>นำเข้าซ้ำได้ — รายการที่เคยนำเข้าจะถูกอัปเดต ไม่สร้างซ้ำ · หน้าที่นำเข้าแก้ได้ด้วยตัวแก้ไขบล็อก · ตรวจผลที่ <a href="' . esc_url(admin_url('edit.php?post_type=page')) . '">หน้าเว็บ</a> และ <a href="' . esc_url(admin_url('edit.php')) . '">ข่าว</a></span></p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    idw_close();
}
