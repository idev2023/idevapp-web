<?php
/**
 * Old page → title, date, main content → WordPress blocks (paragraph, heading, list, image, table, embed, html),
 * with pictures and documents copied into the media library.
 */
defined('ABSPATH') || exit;

/** Copy a file from the old site into the media library (once). Returns attachment ID or 0. */
function idw_imp_media($url, $post_id = 0, $title = '') {
    global $wpdb;
    $url = esc_url_raw($url);
    if (!$url) return 0;
    $have = (int) $wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_idw_src' AND meta_value = %s LIMIT 1", $url)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    if ($have && get_post_type($have) === 'attachment') return $have;
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    if (!wp_http_validate_url($url)) return 0;
    $tmp = download_url($url, 60);
    if (is_wp_error($tmp)) return 0;
    $name = sanitize_file_name(urldecode(wp_basename((string) wp_parse_url($url, PHP_URL_PATH))));
    if ($name === '' || strpos($name, '.') === false) {
        $type = function_exists('mime_content_type') ? (string) @mime_content_type($tmp) : ''; // phpcs:ignore
        $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp', 'application/pdf' => 'pdf'][$type] ?? '';
        if (!$ext) { @unlink($tmp); return 0; } // phpcs:ignore
        $name = 'file-' . substr(md5($url), 0, 8) . '.' . $ext;
    }
    $id = media_handle_sideload(['name' => $name, 'tmp_name' => $tmp], $post_id, $title ?: null);
    if (is_wp_error($id)) { @unlink($tmp); return 0; } // phpcs:ignore
    update_post_meta($id, '_idw_src', $url);
    return (int) $id;
}

/** Find the main content element of a page. */
function idw_imp_main($dom) {
    $xp = new DOMXPath($dom);
    foreach (['//script', '//style', '//noscript', '//template', '//form[not(.//iframe)]', '//nav', '//header', '//footer', '//aside', '//*[@role="navigation" or @role="banner" or @role="contentinfo"]', '//*[contains(concat(" ",normalize-space(@class)," ")," sidebar ") or contains(@class,"breadcrumb") or contains(@class,"share") or contains(@class,"comments") or contains(@id,"comments") or contains(@class,"related") or contains(@class,"cookie") or contains(@class,"widget") or contains(@class,"pagination") or contains(@class,"post-navigation") or contains(@class,"skip-link")]'] as $q) {
        foreach (iterator_to_array($xp->query($q)) as $n) if ($n->parentNode) $n->parentNode->removeChild($n);
    }
    foreach (['//*[contains(@class,"entry-content")]', '//*[contains(@class,"post-content")]', '//*[contains(@class,"article-content")]', '//*[@itemprop="articleBody"]', '//*[contains(@class,"item-page")]', '//*[contains(@class,"field--name-body") or contains(@class,"field-name-body")]', '//article', '//main', '//*[@role="main"]', '//*[@id="content"]', '//*[contains(@class,"content")]'] as $q) {
        $n = $xp->query($q)->item(0);
        if ($n && mb_strlen(idw_imp_text($n)) > 40) return $n;
    }
    // densest block of paragraphs
    $best = null; $bestN = 0;
    foreach ($xp->query('//div | //section | //td') as $d) {
        $n = 0;
        foreach ($xp->query('./p | ./*/p', $d) as $p) $n += mb_strlen(idw_imp_text($p));
        if ($n > $bestN) { $best = $d; $bestN = $n; }
    }
    return $best ?: $xp->query('//body')->item(0);
}

/** Title and date of a page. */
function idw_imp_meta($dom) {
    $xp = new DOMXPath($dom);
    $m = function ($k) use ($xp) { $n = $xp->query('//meta[@property="' . $k . '" or @name="' . $k . '" or @itemprop="' . $k . '"]/@content')->item(0); return $n ? trim($n->nodeValue) : ''; };
    $h1 = $xp->query('//h1')->item(0);
    $title = $m('og:title') ?: ($h1 ? idw_imp_text($h1) : '');
    if ($title === '') { $t = $xp->query('//title')->item(0); $title = $t ? trim(preg_split('/\s+[|\-–—]\s+/u', idw_imp_text($t))[0]) : ''; }
    $date = $m('article:published_time') ?: $m('datePublished');
    if (!$date) { $t = $xp->query('//time/@datetime')->item(0); if ($t) $date = $t->nodeValue; }
    $ts = $date ? strtotime($date) : 0;
    if (!$ts) $ts = idw_imp_thai_date(idw_imp_text($xp->query('//body')->item(0) ?: $dom));
    $img = $m('og:image');
    return ['title' => wp_strip_all_tags(html_entity_decode($title)), 'ts' => $ts ?: 0, 'image' => $img, 'desc' => wp_strip_all_tags($m('og:description') ?: $m('description'))];
}

/** "12 พฤศจิกายน 2569" / "12 พ.ย. 69" / "12/11/2569" → timestamp (first one in the text) */
function idw_imp_thai_date($text) {
    $mon = ['มกราคม' => 1, 'กุมภาพันธ์' => 2, 'มีนาคม' => 3, 'เมษายน' => 4, 'พฤษภาคม' => 5, 'มิถุนายน' => 6, 'กรกฎาคม' => 7, 'สิงหาคม' => 8, 'กันยายน' => 9, 'ตุลาคม' => 10, 'พฤศจิกายน' => 11, 'ธันวาคม' => 12, 'ม.ค.' => 1, 'ก.พ.' => 2, 'มี.ค.' => 3, 'เม.ย.' => 4, 'พ.ค.' => 5, 'มิ.ย.' => 6, 'ก.ค.' => 7, 'ส.ค.' => 8, 'ก.ย.' => 9, 'ต.ค.' => 10, 'พ.ย.' => 11, 'ธ.ค.' => 12];
    $text = strtr((string) $text, array_combine(['๐', '๑', '๒', '๓', '๔', '๕', '๖', '๗', '๘', '๙'], range(0, 9)));
    $re = implode('|', array_map(function ($k) { return preg_quote($k, '/'); }, array_keys($mon)));
    if (preg_match('/(\d{1,2})\s*(' . $re . ')\s*(?:พ\.ศ\.\s*)?(\d{2,4})/u', $text, $x)) {
        $y = (int) $x[3]; if ($y < 100) $y += 2500; if ($y > 2400) $y -= 543;
        try { return (new DateTime(sprintf('%04d-%02d-%02d 09:00:00', $y, $mon[$x[2]], (int) $x[1]), wp_timezone()))->getTimestamp(); } catch (Exception $e) { return 0; }
    }
    return 0;
}

function idw_imp_inner($node) {
    $h = '';
    foreach ($node->childNodes as $c) $h .= $node->ownerDocument->saveHTML($c);
    return $h;
}

/** Inline HTML allowed inside a paragraph / heading / list item; links and images resolved. */
function idw_imp_inline($html, $base) {
    $html = wp_kses($html, ['a' => ['href' => true, 'target' => true], 'strong' => [], 'b' => [], 'em' => [], 'i' => [], 'u' => [], 'br' => [], 'sub' => [], 'sup' => [], 'mark' => [], 'code' => [], 's' => []]);
    $html = preg_replace_callback('/href="([^"]*)"/i', function ($m) use ($base) { $u = idw_imp_abs(html_entity_decode($m[1]), $base); return 'href="' . esc_url($u ?: '#') . '"'; }, $html);
    return trim(preg_replace('/\s+/u', ' ', $html));
}

/**
 * Element tree → block markup. $ctx: base URL, post id, download (bool), files (collected documents) by reference.
 */
function idw_imp_blocks($node, &$ctx) {
    $out = [];
    $buf = '';
    $flush = function () use (&$buf, &$out) { $t = trim($buf); if ($t !== '' && wp_strip_all_tags($t) !== '') $out[] = "<!-- wp:paragraph -->\n<p>" . $t . "</p>\n<!-- /wp:paragraph -->"; $buf = ''; };
    foreach (iterator_to_array($node->childNodes) as $c) {
        if ($c instanceof DOMText) { $buf .= esc_html($c->nodeValue); continue; }
        if (!$c instanceof DOMElement) continue;
        $tag = strtolower($c->tagName);
        if (in_array($tag, ['a', 'strong', 'b', 'em', 'i', 'u', 'span', 'br', 'sub', 'sup', 'font', 'small', 'mark', 'code', 's', 'abbr'], true) && !idw_imp_has($c, ['img', 'iframe', 'table', 'ul', 'ol', 'p', 'div'])) {
            // a link to a document becomes an attachment
            if ($tag === 'a' && preg_match('/\.(pdf|docx?|xlsx?|pptx?|zip|rar)(\?|$)/i', $c->getAttribute('href'))) {
                $u = idw_imp_abs($c->getAttribute('href'), $ctx['base']);
                $ctx['files'][] = ['url' => $u, 'label' => idw_imp_text($c)];
                if (!empty($ctx['download'])) {
                    $id = idw_imp_media($u, $ctx['post'], idw_imp_text($c));
                    if ($id) { $c->setAttribute('href', wp_get_attachment_url($id)); $ctx['file_ids'][] = ['id' => $id, 'label' => idw_imp_text($c)]; }
                }
            }
            $buf .= idw_imp_inline($c->ownerDocument->saveHTML($c), $ctx['base']);
            continue;
        }
        switch ($tag) {
            case 'time':
                break;
            case 'p':
                $flush();
                idw_imp_doc_links($c, $ctx);
                if (idw_imp_has($c, ['img', 'iframe'])) { $out = array_merge($out, idw_imp_blocks($c, $ctx)); break; }
                $in = idw_imp_inline(idw_imp_inner($c), $ctx['base']);
                if (wp_strip_all_tags($in) !== '' || strpos($in, '<a') !== false) $out[] = "<!-- wp:paragraph -->\n<p>" . $in . "</p>\n<!-- /wp:paragraph -->";
                break;
            case 'h1': case 'h2': case 'h3': case 'h4': case 'h5': case 'h6':
                $flush();
                $lv = max(2, (int) $tag[1]);
                $t = idw_imp_inline(idw_imp_inner($c), $ctx['base']);
                if (wp_strip_all_tags($t) === '' || (!empty($ctx['title']) && trim(wp_strip_all_tags($t)) === $ctx['title'])) break;
                $out[] = '<!-- wp:heading' . ($lv !== 2 ? ' {"level":' . $lv . '}' : '') . " -->\n<h{$lv} class=\"wp-block-heading\">" . $t . "</h{$lv}>\n<!-- /wp:heading -->";
                break;
            case 'ul': case 'ol':
                $flush();
                idw_imp_doc_links($c, $ctx);
                $items = '';
                foreach ($c->childNodes as $li) if ($li instanceof DOMElement && strtolower($li->tagName) === 'li') {
                    $txt = idw_imp_inline(idw_imp_inner($li), $ctx['base']);
                    if (wp_strip_all_tags($txt) !== '') $items .= "<!-- wp:list-item -->\n<li>" . $txt . "</li>\n<!-- /wp:list-item -->\n";
                }
                if ($items !== '') $out[] = '<!-- wp:list' . ($tag === 'ol' ? ' {"ordered":true}' : '') . " -->\n<{$tag} class=\"wp-block-list\">" . $items . "</{$tag}>\n<!-- /wp:list -->";
                break;
            case 'img':
                $flush();
                $b = idw_imp_image($c, $ctx);
                if ($b) $out[] = $b;
                break;
            case 'figure':
                $flush();
                $img = $c->getElementsByTagName('img')->item(0);
                if ($img) { $b = idw_imp_image($img, $ctx, ($cap = $c->getElementsByTagName('figcaption')->item(0)) ? idw_imp_text($cap) : ''); if ($b) $out[] = $b; }
                elseif ($c->getElementsByTagName('table')->item(0) || $c->getElementsByTagName('iframe')->item(0)) $out = array_merge($out, idw_imp_blocks($c, $ctx));
                break;
            case 'table':
                $flush();
                $out[] = idw_imp_table($c, $ctx);
                break;
            case 'iframe':
                $flush();
                $src = idw_imp_abs($c->getAttribute('src'), $ctx['base']);
                if (preg_match('#youtube(-nocookie)?\.com/embed/([\w-]{6,})#', $src, $m)) {
                    $u = 'https://www.youtube.com/watch?v=' . $m[2];
                    $out[] = '<!-- wp:embed {"url":"' . esc_url($u) . '","type":"video","providerNameSlug":"youtube","responsive":true,"className":"wp-embed-aspect-16-9 wp-has-aspect-ratio"} -->' . "\n" . '<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">' . "\n" . esc_url($u) . "\n" . '</div></figure>' . "\n<!-- /wp:embed -->";
                } elseif (preg_match('#^https://(www\.)?(google\.[a-z.]+/maps|maps\.google\.|docs\.google\.com|drive\.google\.com|www\.facebook\.com/plugins)#', $src)) {
                    $out[] = "<!-- wp:html -->\n" . '<iframe src="' . esc_url($src) . '" width="100%" height="' . max(240, min(900, (int) $c->getAttribute('height') ?: 450)) . '" style="border:0" loading="lazy" allowfullscreen></iframe>' . "\n<!-- /wp:html -->";
                }
                break;
            case 'blockquote':
                $flush();
                $t = idw_imp_inline(idw_imp_inner($c), $ctx['base']);
                if (wp_strip_all_tags($t) !== '') $out[] = "<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><!-- wp:paragraph -->\n<p>" . $t . "</p>\n<!-- /wp:paragraph --></blockquote>\n<!-- /wp:quote -->";
                break;
            case 'hr':
                $flush();
                $out[] = "<!-- wp:separator -->\n<hr class=\"wp-block-separator has-alpha-channel-opacity\"/>\n<!-- /wp:separator -->";
                break;
            case 'pre':
                $flush();
                $out[] = "<!-- wp:preformatted -->\n<pre class=\"wp-block-preformatted\">" . esc_html($c->textContent) . "</pre>\n<!-- /wp:preformatted -->";
                break;
            case 'script': case 'style': case 'form': case 'input': case 'button': case 'select': case 'svg': case 'video': case 'audio': case 'object': case 'embed':
                break;
            default: // div, section, article, center, td … → look inside
                $flush();
                $out = array_merge($out, idw_imp_blocks($c, $ctx));
        }
    }
    $flush();
    return $out;
}
/** Links to documents inside an element: copy the files and point the links at the copies. */
function idw_imp_doc_links($el, &$ctx) {
    foreach (iterator_to_array($el->getElementsByTagName('a')) as $a) {
        if (!preg_match('/\.(pdf|docx?|xlsx?|pptx?|zip|rar)(\?|$)/i', $a->getAttribute('href'))) continue;
        $u = idw_imp_abs($a->getAttribute('href'), $ctx['base']);
        $ctx['files'][] = ['url' => $u, 'label' => idw_imp_text($a)];
        if (empty($ctx['download'])) continue;
        $id = idw_imp_media($u, $ctx['post'], idw_imp_text($a));
        if ($id) { $a->setAttribute('href', wp_get_attachment_url($id)); $ctx['file_ids'][] = ['id' => $id, 'label' => idw_imp_text($a)]; }
    }
}
function idw_imp_has($el, $tags) { foreach ($tags as $t) if ($el->getElementsByTagName($t)->length) return true; return false; }

function idw_imp_image($img, &$ctx, $caption = '') {
    $src = $img->getAttribute('data-src') ?: $img->getAttribute('data-lazy-src') ?: $img->getAttribute('src');
    if (!$src && $img->getAttribute('srcset')) $src = trim(explode(' ', trim(explode(',', $img->getAttribute('srcset'))[0]))[0]);
    $src = idw_imp_abs($src, $ctx['base']);
    if (!$src || preg_match('/(spacer|blank|pixel|loading)\.(gif|png)|^data:/i', $src)) return '';
    $w = (int) $img->getAttribute('width');
    if ($w && $w < 40) return ''; // icons
    $alt = esc_attr(wp_strip_all_tags($img->getAttribute('alt')));
    $id = !empty($ctx['download']) ? idw_imp_media($src, $ctx['post'], $alt) : 0;
    if ($id) {
        if (empty($ctx['first_image'])) $ctx['first_image'] = $id;
        $url = wp_get_attachment_image_url($id, 'large') ?: wp_get_attachment_url($id);
        return '<!-- wp:image {"id":' . $id . ',"sizeSlug":"large","linkDestination":"none"} -->' . "\n" . '<figure class="wp-block-image size-large"><img src="' . esc_url($url) . '" alt="' . $alt . '" class="wp-image-' . $id . '"/>' . ($caption !== '' ? '<figcaption class="wp-element-caption">' . esc_html($caption) . '</figcaption>' : '') . "</figure>\n<!-- /wp:image -->";
    }
    return "<!-- wp:image -->\n" . '<figure class="wp-block-image"><img src="' . esc_url($src) . '" alt="' . $alt . '"/>' . ($caption !== '' ? '<figcaption class="wp-element-caption">' . esc_html($caption) . '</figcaption>' : '') . "</figure>\n<!-- /wp:image -->";
}

function idw_imp_table($t, &$ctx) {
    $head = ''; $body = '';
    foreach ($t->getElementsByTagName('tr') as $tr) {
        $cells = '';
        $is_head = $tr->parentNode instanceof DOMElement && strtolower($tr->parentNode->tagName) === 'thead';
        if (!$is_head && $head === '' && $body === '') { $th = 0; $all = 0; foreach ($tr->childNodes as $x) if ($x instanceof DOMElement) { $all++; if (strtolower($x->tagName) === 'th') $th++; } $is_head = $all > 0 && $th === $all; }
        foreach ($tr->childNodes as $td) {
            if (!$td instanceof DOMElement || !in_array(strtolower($td->tagName), ['td', 'th'], true)) continue;
            $tag = $is_head ? 'th' : 'td';
            $span = ((int) $td->getAttribute('colspan') > 1 ? ' colspan="' . (int) $td->getAttribute('colspan') . '"' : '') . ((int) $td->getAttribute('rowspan') > 1 ? ' rowspan="' . (int) $td->getAttribute('rowspan') . '"' : '');
            $cells .= "<{$tag}{$span}>" . idw_imp_inline(idw_imp_inner($td), $ctx['base']) . "</{$tag}>";
        }
        if ($cells === '') continue;
        if ($is_head) $head .= '<tr>' . $cells . '</tr>'; else $body .= '<tr>' . $cells . '</tr>';
    }
    if ($head === '' && $body === '') return '';
    // a table used for layout (one big cell with paragraphs) → its content instead
    if ($t->getElementsByTagName('td')->length <= 2 && idw_imp_has($t, ['p', 'img', 'div'])) return implode("\n\n", idw_imp_blocks($t, $ctx));
    return "<!-- wp:table -->\n<figure class=\"wp-block-table\"><table>" . ($head ? '<thead>' . $head . '</thead>' : '') . '<tbody>' . $body . "</tbody></table></figure>\n<!-- /wp:table -->";
}

/** Fetch one page and turn it into [title, content (blocks), ts, image (attachment ID), excerpt, files]. */
function idw_imp_page_from_html($url, $post_id, $download) {
    $r = idw_imp_get($url);
    if (is_wp_error($r)) return $r;
    $dom = idw_imp_dom(wp_remote_retrieve_body($r));
    $meta = idw_imp_meta($dom);
    $main = idw_imp_main($dom);
    $ctx = ['base' => $url, 'post' => $post_id, 'download' => $download, 'files' => [], 'file_ids' => [], 'title' => $meta['title']];
    $blocks = $main ? idw_imp_blocks($main, $ctx) : [];
    return ['title' => $meta['title'], 'content' => implode("\n\n", array_filter($blocks)), 'ts' => $meta['ts'], 'image_url' => $meta['image'], 'first_image' => $ctx['first_image'] ?? 0, 'excerpt' => $meta['desc'], 'files' => $ctx['file_ids']];
}

/** HTML already rendered by WordPress (REST) → blocks the same way. */
function idw_imp_blocks_from_html($html, $base, $post_id, $download, &$files = []) {
    $dom = idw_imp_dom('<div id="idw-root">' . $html . '</div>');
    $root = $dom->getElementById('idw-root');
    $ctx = ['base' => $base, 'post' => $post_id, 'download' => $download, 'files' => [], 'file_ids' => []];
    $b = $root ? idw_imp_blocks($root, $ctx) : [];
    $files = $ctx['file_ids'];
    return implode("\n\n", array_filter($b));
}
