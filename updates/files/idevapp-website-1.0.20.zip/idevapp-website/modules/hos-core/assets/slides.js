/* สไลด์หน้าแรก: editor */
jQuery(function ($) {
  var S = (window.HOS_SLIDES || []).map(function (s) { s.key = 'k' + Math.random().toString(36).slice(2); return s; });
  var $grid = $('#hs-grid'), dirty = false, cur = 0, timer = null;
  var today = new Date().toISOString().slice(0, 10);
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function thDate(d) { if (!d) return ''; var p = d.split('-'); var m = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.']; return (+p[2]) + ' ' + m[+p[1] - 1] + ' ' + (+p[0] + 543); }
  function state(s) {
    if (!s.on) return ['ซ่อนอยู่', ''];
    if (s.from && s.from > today) return ['เริ่มแสดง ' + thDate(s.from), 'info'];
    if (s.until && s.until < today) return ['หมดเวลาแล้ว', 'warn'];
    if (s.old && !s.renew) return ['ลงไว้นานเกินกำหนด — ซ่อนจากหน้าเว็บแล้ว', 'warn'];
    if (s.why === 'file') return ['ไม่พบไฟล์รูปบนเซิร์ฟเวอร์ — เปลี่ยนรูป', 'warn'];
    if (s.why === 'noimg' || !s.url) return ['ไม่มีรูป', 'warn'];
    var end = s.until && (!s.ends || s.until < s.ends) ? s.until : (s.renew ? '' : s.ends);
    return ['กำลังแสดง' + (end ? ' ถึง ' + thDate(end) : ''), 'ok'];
  }
  function live() { return S.filter(function (s) { return state(s)[1] === 'ok' && s.url; }); }
  function touch() { dirty = true; $('#hs-msg').html('<b>มีการแก้ไขที่ยังไม่บันทึก</b>'); preview(); count(); }
  function count() { var n = live().length, aged = S.filter(function (s) { return s.on && s.old && !s.renew; }).length; $('#hs-count').text(S.length + ' สไลด์ · แสดงอยู่ ' + n + (aged ? ' · ซ่อนเพราะลงไว้นานเกินกำหนด ' + aged + ' (กด “แสดงต่อ” ที่สไลด์)' : '')); }
  function card(s, i) {
    var st = state(s);
    var small = s.w && s.w < 1200 ? '<span class="idw-chip warn">รูปเล็ก ' + s.w + '×' + s.h + ' อาจไม่คมชัด</span>' : '';
    return '<div class="hs-card' + (s.on ? '' : ' off') + '" data-key="' + s.key + '">' +
      '<div class="hs-img" style="background-image:url(\'' + esc(s.url) + '\')"><span class="hs-n">' + (i + 1) + '</span><span class="hs-drag dashicons dashicons-move" title="ลากเพื่อเรียง"></span><button type="button" class="hs-change">เปลี่ยนรูป</button></div>' +
      '<div class="hs-body"><div class="hs-row"><span class="idw-chip ' + st[1] + '">' + esc(st[0]) + '</span>' + (s.on && s.old && !s.renew ? '<button type="button" class="button-link hs-renew" title="นับอายุสไลด์ใหม่ตั้งแต่วันนี้">แสดงต่อ</button>' : '') + small + '<label class="idw-switch" title="แสดง / ซ่อน"><input type="checkbox" data-f="on"' + (s.on ? ' checked' : '') + '><span></span></label></div>' +
      '<input class="idw-in" data-f="title" placeholder="หัวข้อ (ใช้เป็นคำอธิบายรูป)" value="' + esc(s.title) + '">' +
      '<input class="idw-in" data-f="link" list="hs-pages" placeholder="ลิงก์เมื่อคลิก — เลือกหน้าหรือวาง https://" value="' + esc(s.link) + '">' +
      '<details' + (s.from || s.until || s.sub ? ' open' : '') + '><summary>ช่วงวันที่แสดง · ข้อความรอง</summary><div class="hs-dates"><label>เริ่ม<input type="date" class="idw-in" data-f="from" value="' + esc(s.from) + '"></label><label>สิ้นสุด<input type="date" class="idw-in" data-f="until" value="' + esc(s.until) + '"></label></div><textarea class="idw-in" data-f="sub" rows="2" placeholder="ข้อความรอง (ถ้ามี)">' + esc(s.sub) + '</textarea></details>' +
      '<div class="hs-acts"><button type="button" class="button-link hs-dup">ทำสำเนา</button><button type="button" class="button-link hs-del">ลบ</button></div></div></div>';
  }
  function render() {
    $grid.html(S.length ? S.map(card).join('') : '<div class="hs-none"><span class="dashicons dashicons-images-alt2"></span><p>ยังไม่มีสไลด์</p><button type="button" class="idw-btn pri" id="hs-add2">เพิ่มรูปแรก</button></div>');
    count(); preview();
  }
  function find(el) { var k = $(el).closest('.hs-card').data('key'); for (var i = 0; i < S.length; i++) if (S[i].key === k) return S[i]; }
  function preview() {
    var L = live(), $st = $('#hs-stage');
    clearInterval(timer);
    if (!L.length) { $st.html('<div class="hs-empty"><span class="dashicons dashicons-format-gallery"></span><b>ยังไม่มีสไลด์ที่แสดง</b><span>กด “เพิ่มรูป” หรือเปิดสวิตช์ของสไลด์</span></div>'); $('#hs-dots').empty(); $('#hs-pv-title').text(''); return; }
    cur = cur % L.length;
    $st.html(L.map(function (s, i) { return '<div class="hs-slide' + (i === cur ? ' on' : '') + '" style="--bg:url(\'' + esc(s.url) + '\')"><img src="' + esc(s.url) + '" alt=""></div>'; }).join(''));
    $('#hs-dots').html(L.map(function (s, i) { return '<button type="button" class="' + (i === cur ? 'on' : '') + '" data-i="' + i + '"></button>'; }).join(''));
    show(cur);
    var ms = Math.max(2, +$('#hs-interval').val() || 5.5) * 1000;
    if (L.length > 1) timer = setInterval(function () { show(cur + 1); }, ms);
  }
  function show(i) {
    var L = live(); if (!L.length) return;
    cur = (i + L.length) % L.length;
    $('#hs-stage .hs-slide').removeClass('on').eq(cur).addClass('on');
    $('#hs-dots button').removeClass('on').eq(cur).addClass('on');
    var s = L[cur]; $('#hs-pv-title').text((cur + 1) + '/' + L.length + (s.title ? ' · ' + s.title : '') + (s.link ? ' → ' + s.link.replace(/^https?:\/\//, '') : ''));
  }
  $('#hs-dots').on('click', 'button', function () { show(+$(this).data('i')); });
  $('#hs-interval').on('change', function () { touch(); });
  $grid.on('input change', '[data-f]', function () {
    var s = find(this), f = $(this).data('f');
    var was = s.on;
    s[f] = this.type === 'checkbox' ? this.checked : this.value;
    if (f === 'on' && s.on && !was) s.old = false; // switched on: its time starts when saved
    if (f === 'on' || f === 'from' || f === 'until') { var $c = $(this).closest('.hs-card'); $c.toggleClass('off', !s.on); var st = state(s); $c.find('.hs-row .idw-chip').first().attr('class', 'idw-chip ' + st[1]).text(st[0]); }
    touch();
  });
  $grid.on('click', '.hs-renew', function () { var s = find(this); s.renew = 1; render(); touch(); });
  $grid.on('click', '.hs-del', function () { var s = find(this); if (!confirm('ลบสไลด์นี้?')) return; S.splice(S.indexOf(s), 1); render(); touch(); });
  $grid.on('click', '.hs-dup', function () { var s = find(this), c = $.extend({}, s, { id: 0, key: 'k' + Math.random().toString(36).slice(2) }); S.splice(S.indexOf(s) + 1, 0, c); render(); touch(); });
  function pick(multi, cb) {
    var f = wp.media({ title: multi ? 'เลือกรูปสไลด์ (เลือกได้หลายรูป)' : 'เปลี่ยนรูปสไลด์', multiple: multi, library: { type: 'image' }, button: { text: multi ? 'เพิ่มเป็นสไลด์' : 'ใช้รูปนี้' } });
    f.on('select', function () { cb(f.state().get('selection').toJSON()); });
    f.open();
  }
  function fromAtt(a) { var u = (a.sizes && (a.sizes.large || a.sizes.full) || a).url; return { img: a.id, url: u, w: a.width, h: a.height, old: false, why: '' }; }
  $(document).on('click', '#hs-add,#hs-add2', function () {
    pick(true, function (list) { list.forEach(function (a) { S.push($.extend({ id: 0, key: 'k' + Math.random().toString(36).slice(2), title: a.title || '', sub: '', link: '', on: true, from: '', until: '' }, fromAtt(a))); }); render(); touch(); $('html,body').animate({ scrollTop: $grid.offset().top - 60 }, 250); });
  });
  $grid.on('click', '.hs-change', function () { var s = find(this); pick(false, function (l) { $.extend(s, fromAtt(l[0])); render(); touch(); }); });
  $grid.sortable({ items: '.hs-card', handle: '.hs-img', placeholder: 'hs-card hs-ph', tolerance: 'pointer', update: function () {
    var order = $grid.children('.hs-card').map(function () { return $(this).data('key'); }).get();
    S.sort(function (a, b) { return order.indexOf(a.key) - order.indexOf(b.key); }); render(); touch();
  } });
  $('#hs-form').on('submit', function () {
    dirty = false;
    $('#hs-data').val(JSON.stringify(S.map(function (s) { return { id: s.id || 0, img: s.img || 0, title: s.title, sub: s.sub, link: s.link, on: s.on ? 1 : 0, from: s.from, until: s.until, renew: s.renew ? 1 : 0 }; })));
    $('#hs-save').prop('disabled', true).text('กำลังบันทึก…');
  });
  window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
  render();
});
