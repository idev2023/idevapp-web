<?php
/**
 * ไฟล์แนบเอกสาร + ปีงบประมาณ (ใช้กับประกาศจัดซื้อจัดจ้าง รับสมัครงาน ITA เอกสารดาวน์โหลด)
 * hos_get_document_url() หาไฟล์จากข้อมูลเดิมให้อัตโนมัติ: ไฟล์แนบใหม่ → ฟิลด์ ACF ไฟล์ → ลิงก์ PDF ในเนื้อหา → PDF ที่อัปโหลดกับโพสต์
 */
defined( 'ABSPATH' ) || exit;

add_action( 'add_meta_boxes', function ( $post_type ) {
	if ( array_key_exists( $post_type, hos_content_post_types() ) ) {
		add_meta_box( 'hos-document', 'ไฟล์แนบเอกสาร', 'hos_document_box', $post_type, 'side', 'high' );
	}
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		wp_enqueue_media();
		wp_enqueue_script( 'hos-admin', HOS_CORE_URL . 'includes/admin.js', array( 'jquery' ), HOS_CORE_VER, true );
	}
} );

function hos_document_box( $post ) {
	wp_nonce_field( 'hos_document_save', 'hos_document_nonce' );
	$id   = get_post_meta( $post->ID, '_hos_document_id', true );
	$url  = get_post_meta( $post->ID, '_hos_document_url', true );
	$year = get_post_meta( $post->ID, '_hos_fiscal_year', true );
	$cur  = $id ? wp_get_attachment_url( (int) $id ) : '';
	echo '<div class="hos-media-field"><input type="hidden" class="hos-media-id" name="hos_document_id" value="' . esc_attr( $id ) . '">';
	echo '<p><span class="hos-media-name">' . ( $cur ? '<a href="' . esc_url( $cur ) . '" target="_blank">' . esc_html( basename( $cur ) ) . '</a>' : 'ยังไม่มีไฟล์' ) . '</span></p>';
	echo '<p><button type="button" class="button hos-media-pick">เลือก/อัปโหลดไฟล์</button> <button type="button" class="button-link hos-media-clear">ล้าง</button></p></div>';
	echo '<p><label>หรือลิงก์ไฟล์<br><input type="url" class="widefat" name="hos_document_url" value="' . esc_attr( $url ) . '" placeholder="https://"></label></p>';
	echo '<p><label>ปีงบประมาณ (สำหรับ ITA)<br><input type="text" inputmode="numeric" maxlength="4" class="widefat" name="hos_fiscal_year" value="' . esc_attr( $year ) . '" placeholder="2569"></label></p>';
	$auto = hos_get_document_url( $post->ID, false );
	if ( ! $id && ! $url && $auto ) {
		echo '<p class="description">พบไฟล์จากข้อมูลเดิม: <a href="' . esc_url( $auto ) . '" target="_blank">' . esc_html( basename( $auto ) ) . '</a></p>';
	}
}

add_action( 'save_post', function ( $post_id ) {
	if ( ! isset( $_POST['hos_document_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hos_document_nonce'] ) ), 'hos_document_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$id = isset( $_POST['hos_document_id'] ) ? absint( $_POST['hos_document_id'] ) : 0;
	$id ? update_post_meta( $post_id, '_hos_document_id', $id ) : delete_post_meta( $post_id, '_hos_document_id' );
	$url = isset( $_POST['hos_document_url'] ) ? esc_url_raw( wp_unslash( $_POST['hos_document_url'] ) ) : '';
	$url ? update_post_meta( $post_id, '_hos_document_url', $url ) : delete_post_meta( $post_id, '_hos_document_url' );
	$year = isset( $_POST['hos_fiscal_year'] ) ? preg_replace( '/\D/', '', sanitize_text_field( wp_unslash( $_POST['hos_fiscal_year'] ) ) ) : '';
	$year ? update_post_meta( $post_id, '_hos_fiscal_year', substr( $year, 0, 4 ) ) : delete_post_meta( $post_id, '_hos_fiscal_year' );
} );

/**
 * URL ไฟล์เอกสารหลักของโพสต์
 * @param bool $own_first ถ้า false จะข้ามค่าที่ตั้งใน meta box (ใช้แสดงไฟล์ที่ตรวจพบจากข้อมูลเดิม)
 */
if ( ! function_exists( 'hos_get_document_url' ) ) { // the theme may load first (e.g. while the plugin is being switched on)
function hos_get_document_url( $post_id = null, $own_first = true ) {
	$post_id = $post_id ? (int) $post_id : get_the_ID();
	if ( $own_first ) {
		$id = (int) get_post_meta( $post_id, '_hos_document_id', true );
		if ( $id && ( $u = wp_get_attachment_url( $id ) ) ) {
			return $u;
		}
		$u = get_post_meta( $post_id, '_hos_document_url', true );
		if ( $u ) {
			return $u;
		}
	}
	// ฟิลด์ ACF ชนิดไฟล์ (ข้อมูลเดิม)
	if ( function_exists( 'hos_field_groups' ) ) {
		$post = get_post( $post_id );
		foreach ( hos_field_groups() as $g ) {
			if ( ! $post || ! hos_field_group_matches( $g, $post ) ) {
				continue;
			}
			foreach ( $g['fields'] as $f ) {
				if ( 'file' === $f['type'] && $f['name'] ) {
					$v = get_post_meta( $post_id, $f['name'], true );
					if ( is_numeric( $v ) && $v && ( $u = wp_get_attachment_url( (int) $v ) ) ) {
						return $u;
					}
					if ( is_string( $v ) && filter_var( $v, FILTER_VALIDATE_URL ) ) {
						return $v;
					}
				}
			}
		}
	}
	// ลิงก์เอกสารในเนื้อหา (เช่น ปุ่ม Elementor / ลิงก์ PDF)
	$content = (string) get_post_field( 'post_content', $post_id );
	if ( preg_match( '#href=["\']([^"\']+\.(?:pdf|docx?|xlsx?))["\']#i', $content, $m ) ) {
		return html_entity_decode( $m[1] );
	}
	if ( preg_match( '#(https?://[^\s"\'<>]+\.pdf)#i', $content, $m ) ) {
		return $m[1];
	}
	// PDF ที่อัปโหลดแนบกับโพสต์
	$files = get_children( array( 'post_parent' => $post_id, 'post_type' => 'attachment', 'post_mime_type' => 'application/pdf', 'numberposts' => 1, 'orderby' => 'menu_order ID', 'order' => 'ASC' ) );
	if ( $files ) {
		return wp_get_attachment_url( (int) key( $files ) );
	}
	return (string) apply_filters( 'hos_document_url_fallback', '', $post_id ); // เช่น iDev Post Attachments
}
}

/** นามสกุลไฟล์ (PDF/DOC/...) สำหรับป้าย */
if ( ! function_exists( 'hos_file_ext' ) ) { // the theme may load first (e.g. while the plugin is being switched on)
function hos_file_ext( $url ) {
	$path = wp_parse_url( $url, PHP_URL_PATH );
	$ext  = $path ? strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) : '';
	return $ext && strlen( $ext ) <= 4 ? $ext : '';
}
}
