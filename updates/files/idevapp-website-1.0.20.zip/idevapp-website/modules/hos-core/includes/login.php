<?php
/**
 * แทน WPS Hide Login + LoginPress
 * - ซ่อน wp-login.php / wp-admin สำหรับผู้ที่ยังไม่ล็อกอิน ใช้ URL เข้าสู่ระบบที่ตั้งเอง
 *   (ค่าเริ่มต้นดึงจาก option `whl_page` ของ WPS Hide Login เดิม URL เดิมจึงใช้ได้ต่อ)
 * - ปรับหน้าตาหน้าเข้าสู่ระบบให้เป็นของโรงพยาบาล
 * ฉุกเฉิน: ใส่ define( 'HOS_DISABLE_HIDE_LOGIN', true ); ใน wp-config.php เพื่อปิดการซ่อน
 */
defined( 'ABSPATH' ) || exit;

function hos_login_slug() {
	if ( defined( 'HOS_DISABLE_HIDE_LOGIN' ) && HOS_DISABLE_HIDE_LOGIN ) {
		return '';
	}
	if ( class_exists( 'WPS\WPS_Hide_Login\Plugin' ) || function_exists( 'wps_hide_login' ) ) {
		return ''; // plugin เดิมยังเปิดอยู่
	}
	$slug = get_option( 'hos_login_slug', null );
	if ( null === $slug ) {
		$slug = (string) get_option( 'whl_page', '' );
	}
	$slug = sanitize_title( $slug );
	return in_array( $slug, array( '', 'wp-login', 'wp-admin', 'login', 'admin' ), true ) ? '' : $slug;
}

function hos_request_path() {
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
	$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	if ( $home && 0 === strpos( $path, $home ) ) {
		$path = substr( $path, strlen( $home ) );
	}
	return trim( rawurldecode( $path ), '/' );
}

add_action( 'plugins_loaded', function () {
	$slug = hos_login_slug();
	if ( ! $slug || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
		return;
	}
	$path = hos_request_path();
	$GLOBALS['hos_is_login_slug'] = ( $path === $slug );
	$GLOBALS['hos_block_login']   = ( 'wp-login.php' === basename( $path ) || 'wp-register.php' === basename( $path ) ) && ! $GLOBALS['hos_is_login_slug'];
}, 1 );

add_action( 'wp_loaded', function () {
	$slug = hos_login_slug();
	if ( ! $slug ) {
		return;
	}
	global $pagenow;
	$req_action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : '';
	// อนุญาตลิงก์จากอีเมลรีเซ็ตรหัสผ่าน / ออกจากระบบ / หน้าใส่รหัสโพสต์
	$allowed_actions = array( 'postpass', 'logout', 'rp', 'resetpass', 'confirmaction' );

	if ( ! empty( $GLOBALS['hos_block_login'] ) && ! in_array( $req_action, $allowed_actions, true ) ) {
		hos_login_404();
	}
	if ( is_admin() && ! is_user_logged_in() && ! wp_doing_ajax() && 'admin-post.php' !== $pagenow && ! ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
		hos_login_404();
	}
	if ( ! empty( $GLOBALS['hos_is_login_slug'] ) ) {
		$pagenow = 'wp-login.php'; // phpcs:ignore
		global $error, $interim_login, $action, $user_login, $user, $redirect_to; // ตัวแปรที่ wp-login.php ใช้
		require_once ABSPATH . 'wp-login.php';
		exit;
	}
} );

function hos_login_404() {
	status_header( 404 );
	nocache_headers();
	$tpl = get_404_template();
	if ( $tpl ) {
		global $wp_query;
		$wp_query->set_404();
		include $tpl;
	} else {
		echo '<h1>404</h1>';
	}
	exit;
}

function hos_filter_login_url( $url ) {
	$slug = hos_login_slug();
	if ( ! $slug || false === strpos( $url, 'wp-login.php' ) ) {
		return $url;
	}
	$parts = explode( '?', $url, 2 );
	$new   = home_url( '/' . $slug . '/' );
	return isset( $parts[1] ) ? $new . '?' . $parts[1] : $new;
}
foreach ( array( 'site_url', 'network_site_url', 'wp_redirect', 'login_url', 'logout_url', 'lostpassword_url', 'register_url' ) as $hook ) {
	add_filter( $hook, 'hos_filter_login_url', 100 );
}
add_filter( 'site_option_welcome_email', function ( $v ) {
	$slug = hos_login_slug();
	return $slug ? str_replace( 'wp-login.php', trailingslashit( $slug ), $v ) : $v;
} );

// ---------- หน้าตาหน้าเข้าสู่ระบบ (แทน LoginPress) ----------
add_action( 'login_enqueue_scripts', function () {
	$logo  = get_theme_mod( 'custom_logo' ) ? wp_get_attachment_image_url( (int) get_theme_mod( 'custom_logo' ), 'medium' ) : '';
	if ( ! $logo && file_exists( get_template_directory() . '/assets/logo.png' ) ) {
		$logo = get_template_directory_uri() . '/assets/logo.png';
	}
	$color = get_theme_mod( 'hos_style', 'green' ) === 'vachira' ? '#163d8f' : '#0a7d55';
	?>
	<style>
		body.login{background:linear-gradient(135deg,<?php echo esc_attr( $color ); ?>,#062e20);font-family:'IBM Plex Sans Thai',sans-serif}
		.login h1 a{<?php echo $logo ? 'background-image:url(' . esc_url( $logo ) . ');background-size:contain;width:120px;height:120px;background-color:#fff;border-radius:50%;' : 'background:none;text-indent:0;width:auto;height:auto;font-size:22px;color:#fff;font-weight:700;'; ?>}
		.login form{border-radius:16px;border:0;box-shadow:0 20px 50px rgba(0,0,0,.25);padding:28px}
		.login label{font-weight:600}.login input[type=text],.login input[type=password]{border-radius:10px;padding:6px 12px}
		.wp-core-ui .button-primary{background:<?php echo esc_attr( $color ); ?>;border-color:<?php echo esc_attr( $color ); ?>;border-radius:10px;padding:2px 20px}
		.login #nav a,.login #backtoblog a,.login .privacy-policy-link{color:#fff!important}
	</style>
	<?php
} );
add_filter( 'login_headerurl', function () { return home_url( '/' ); } );
add_filter( 'login_headertext', function () { return get_bloginfo( 'name' ); } );
