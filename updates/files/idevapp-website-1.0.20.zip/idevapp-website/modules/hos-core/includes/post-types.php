<?php
/**
 * แทน Custom Post Type UI:
 * อ่านนิยาม post type / taxonomy ที่ CPT UI เก็บไว้ใน option `cptui_post_types`, `cptui_taxonomies`
 * แล้วลงทะเบียนด้วยค่าเดิม (slug เดิม) ข้อมูลโพสต์เดิมจึงแสดงผลได้ทันทีโดยไม่ต้องใช้ CPT UI
 */
defined( 'ABSPATH' ) || exit;

function hos_cpt_bool( $v ) {
	return in_array( $v, array( true, 'true', '1', 1 ), true );
}

add_action( 'init', 'hos_register_legacy_types', 5 );
function hos_register_legacy_types() {
	if ( function_exists( 'cptui_register_my_cpts' ) || class_exists( 'CPT_UI' ) ) {
		return; // CPT UI ยังเปิดอยู่ ให้มันทำงานเอง
	}
	$types = get_option( 'cptui_post_types', array() );
	if ( is_array( $types ) ) {
		foreach ( $types as $slug => $t ) {
			$slug = sanitize_key( isset( $t['name'] ) ? $t['name'] : $slug );
			if ( ! $slug || post_type_exists( $slug ) ) {
				continue;
			}
			$label    = ! empty( $t['label'] ) ? $t['label'] : $slug;
			$singular = ! empty( $t['singular_label'] ) ? $t['singular_label'] : $label;
			$supports = ! empty( $t['supports'] ) && is_array( $t['supports'] ) ? $t['supports'] : array( 'title', 'editor', 'thumbnail' );
			$rewrite  = hos_cpt_bool( isset( $t['rewrite'] ) ? $t['rewrite'] : true );
			$args     = array(
				'labels'              => array( 'name' => $label, 'singular_name' => $singular, 'menu_name' => ! empty( $t['labels']['menu_name'] ) ? $t['labels']['menu_name'] : $label, 'add_new_item' => 'เพิ่ม' . $singular ),
				'description'         => isset( $t['description'] ) ? $t['description'] : '',
				'public'              => hos_cpt_bool( isset( $t['public'] ) ? $t['public'] : true ),
				'publicly_queryable'  => hos_cpt_bool( isset( $t['publicly_queryable'] ) ? $t['publicly_queryable'] : true ),
				'show_ui'             => hos_cpt_bool( isset( $t['show_ui'] ) ? $t['show_ui'] : true ),
				'show_in_rest'        => hos_cpt_bool( isset( $t['show_in_rest'] ) ? $t['show_in_rest'] : true ),
				'has_archive'         => hos_cpt_bool( isset( $t['has_archive'] ) ? $t['has_archive'] : false ) ? ( ! empty( $t['has_archive_string'] ) ? $t['has_archive_string'] : true ) : false,
				'exclude_from_search' => hos_cpt_bool( isset( $t['exclude_from_search'] ) ? $t['exclude_from_search'] : false ),
				'hierarchical'        => hos_cpt_bool( isset( $t['hierarchical'] ) ? $t['hierarchical'] : false ),
				'menu_position'       => ! empty( $t['menu_position'] ) ? (int) $t['menu_position'] : 25,
				'menu_icon'           => ! empty( $t['menu_icon'] ) ? $t['menu_icon'] : 'dashicons-media-document',
				'supports'            => $supports,
				'taxonomies'          => ! empty( $t['taxonomies'] ) && is_array( $t['taxonomies'] ) ? $t['taxonomies'] : array(),
				'rewrite'             => $rewrite ? array( 'slug' => ! empty( $t['rewrite_slug'] ) ? $t['rewrite_slug'] : $slug, 'with_front' => hos_cpt_bool( isset( $t['rewrite_withfront'] ) ? $t['rewrite_withfront'] : true ) ) : false,
				'query_var'           => true,
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
			);
			register_post_type( $slug, $args );
		}
	}

	$taxes = get_option( 'cptui_taxonomies', array() );
	if ( is_array( $taxes ) ) {
		foreach ( $taxes as $slug => $t ) {
			$slug = sanitize_key( isset( $t['name'] ) ? $t['name'] : $slug );
			if ( ! $slug || taxonomy_exists( $slug ) ) {
				continue;
			}
			$objects = ! empty( $t['object_types'] ) && is_array( $t['object_types'] ) ? $t['object_types'] : array( 'post' );
			register_taxonomy( $slug, $objects, array(
				'labels'            => array( 'name' => ! empty( $t['label'] ) ? $t['label'] : $slug, 'singular_name' => ! empty( $t['singular_label'] ) ? $t['singular_label'] : $slug ),
				'public'            => hos_cpt_bool( isset( $t['public'] ) ? $t['public'] : true ),
				'hierarchical'      => hos_cpt_bool( isset( $t['hierarchical'] ) ? $t['hierarchical'] : true ),
				'show_ui'           => true,
				'show_admin_column' => hos_cpt_bool( isset( $t['show_admin_column'] ) ? $t['show_admin_column'] : true ),
				'show_in_rest'      => true,
				'rewrite'           => array( 'slug' => ! empty( $t['rewrite_slug'] ) ? $t['rewrite_slug'] : $slug ),
			) );
		}
	}
}

/** รายชื่อ post type ที่เป็นเนื้อหา (ใช้ในหน้าตั้งค่า / theme) */
function hos_content_post_types() {
	$out = array( 'post' => 'เรื่อง (Posts)' );
	foreach ( get_post_types( array( 'public' => true, '_builtin' => false ), 'objects' ) as $pt ) {
		if ( in_array( $pt->name, array( 'hos_slide', 'elementor_library', 'e-landing-page' ), true ) ) {
			continue;
		}
		$out[ $pt->name ] = $pt->label;
	}
	return $out;
}
