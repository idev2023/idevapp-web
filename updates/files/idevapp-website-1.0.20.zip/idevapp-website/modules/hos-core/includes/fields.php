<?php
/**
 * แทน Advanced Custom Fields:
 * - ฟังก์ชัน get_field() / the_field() / get_fields() ที่ theme เดิมอาจเรียกใช้ (อ่านจาก postmeta เดิม)
 * - อ่านนิยามกลุ่มฟิลด์ ACF ที่อยู่ในฐานข้อมูล (post type acf-field-group / acf-field)
 *   แล้วสร้าง meta box ให้แก้ไขค่าได้เหมือนเดิม
 * ทำงานเฉพาะเมื่อ ACF ปิดอยู่
 */
defined( 'ABSPATH' ) || exit;

add_action( 'plugins_loaded', function () {
	if ( class_exists( 'ACF' ) ) {
		return;
	}
	require_once __DIR__ . '/fields-compat.php';
	add_action( 'init', 'hos_fields_register_internal_types', 1 );
	add_action( 'add_meta_boxes', 'hos_fields_meta_boxes', 10, 2 );
	add_action( 'save_post', 'hos_fields_save', 10, 2 );
	add_action( 'admin_enqueue_scripts', function ( $hook ) {
		if ( in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			wp_enqueue_media();
			wp_enqueue_script( 'hos-admin', HOS_CORE_URL . 'includes/admin.js', array( 'jquery' ), HOS_CORE_VER, true );
		}
	} );
}, 20 );

/** ให้ WordPress รู้จัก post type ภายในของ ACF เพื่อ query นิยามฟิลด์ได้ */
function hos_fields_register_internal_types() {
	foreach ( array( 'acf-field-group', 'acf-field' ) as $pt ) {
		if ( ! post_type_exists( $pt ) ) {
			register_post_type( $pt, array( 'public' => false, 'show_ui' => false, 'rewrite' => false, 'query_var' => false, 'supports' => array( 'title' ) ) );
		}
	}
}

/** อ่านกลุ่มฟิลด์ทั้งหมดจากฐานข้อมูล (cache ต่อ request) */
function hos_field_groups() {
	static $groups = null;
	if ( null !== $groups ) {
		return $groups;
	}
	$groups = array();
	$posts  = get_posts( array( 'post_type' => 'acf-field-group', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC', 'suppress_filters' => true ) );
	foreach ( $posts as $g ) {
		$conf   = maybe_unserialize( $g->post_content );
		$fields = array();
		foreach ( get_posts( array( 'post_type' => 'acf-field', 'post_parent' => $g->ID, 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC', 'suppress_filters' => true ) ) as $f ) {
			$fc = maybe_unserialize( $f->post_content );
			$fields[] = array(
				'key'     => $f->post_name,
				'name'    => $f->post_excerpt,
				'label'   => $f->post_title,
				'type'    => is_array( $fc ) && ! empty( $fc['type'] ) ? $fc['type'] : 'text',
				'choices' => is_array( $fc ) && ! empty( $fc['choices'] ) ? (array) $fc['choices'] : array(),
				'return'  => is_array( $fc ) && ! empty( $fc['return_format'] ) ? $fc['return_format'] : '',
				'instructions' => is_array( $fc ) && ! empty( $fc['instructions'] ) ? $fc['instructions'] : '',
			);
		}
		$groups[] = array( 'id' => $g->ID, 'title' => $g->post_title, 'location' => is_array( $conf ) && ! empty( $conf['location'] ) ? $conf['location'] : array(), 'fields' => $fields );
	}
	return $groups;
}

/** ตรวจกฎ location ของ ACF แบบพื้นฐาน (post_type, page_template, post_category, taxonomy) */
function hos_field_group_matches( $group, $post ) {
	if ( empty( $group['location'] ) ) {
		return false;
	}
	foreach ( $group['location'] as $and ) {
		$ok = true;
		foreach ( (array) $and as $rule ) {
			$param = isset( $rule['param'] ) ? $rule['param'] : '';
			$value = isset( $rule['value'] ) ? $rule['value'] : '';
			$eq    = ! isset( $rule['operator'] ) || '==' === $rule['operator'];
			switch ( $param ) {
				case 'post_type':
					$hit = $post->post_type === $value;
					break;
				case 'page_template':
					$hit = get_page_template_slug( $post ) === $value || ( 'default' === $value && ! get_page_template_slug( $post ) );
					break;
				case 'post_category':
				case 'post_taxonomy':
					$parts = explode( ':', $value, 2 );
					$tax   = 2 === count( $parts ) ? $parts[0] : 'category';
					$term  = 2 === count( $parts ) ? $parts[1] : $value;
					$hit   = has_term( $term, $tax, $post );
					break;
				case 'page':
				case 'post':
					$hit = (string) $post->ID === (string) $value;
					break;
				default:
					$hit = true; // กฎที่ไม่รองรับ ให้ผ่าน เพื่อไม่ให้ฟิลด์หาย
			}
			if ( $hit !== $eq ) {
				$ok = false;
				break;
			}
		}
		if ( $ok ) {
			return true;
		}
	}
	return false;
}

function hos_fields_meta_boxes( $post_type, $post ) {
	if ( ! $post instanceof WP_Post ) {
		return;
	}
	foreach ( hos_field_groups() as $g ) {
		if ( hos_field_group_matches( $g, $post ) && $g['fields'] ) {
			add_meta_box( 'hos-fg-' . $g['id'], $g['title'], 'hos_fields_render_box', $post_type, 'normal', 'high', $g );
		}
	}
}

function hos_fields_render_box( $post, $box ) {
	$g = $box['args'];
	wp_nonce_field( 'hos_fields_save', 'hos_fields_nonce' );
	echo '<table class="form-table hos-fields">';
	foreach ( $g['fields'] as $f ) {
		if ( ! $f['name'] || in_array( $f['type'], array( 'tab', 'message', 'accordion', 'repeater', 'flexible_content', 'group', 'clone', 'gallery' ), true ) ) {
			continue;
		}
		$name  = 'hos_field[' . esc_attr( $f['name'] ) . ']';
		$value = get_post_meta( $post->ID, $f['name'], true );
		echo '<tr><th><label>' . esc_html( $f['label'] ) . '</label></th><td>';
		switch ( $f['type'] ) {
			case 'textarea':
			case 'wysiwyg':
				echo '<textarea class="large-text" rows="5" name="' . $name . '">' . esc_textarea( $value ) . '</textarea>';
				break;
			case 'select':
			case 'radio':
				echo '<select name="' . $name . '"><option value="">—</option>';
				foreach ( $f['choices'] as $k => $l ) {
					echo '<option value="' . esc_attr( $k ) . '"' . selected( $value, $k, false ) . '>' . esc_html( $l ) . '</option>';
				}
				echo '</select>';
				break;
			case 'true_false':
				echo '<input type="hidden" name="' . $name . '" value="0"><label><input type="checkbox" name="' . $name . '" value="1"' . checked( $value, '1', false ) . '> ใช่</label>';
				break;
			case 'file':
			case 'image':
				$url = $value && is_numeric( $value ) ? wp_get_attachment_url( (int) $value ) : $value;
				echo '<input type="hidden" class="hos-media-id" name="' . $name . '" value="' . esc_attr( $value ) . '">';
				echo '<span class="hos-media-name">' . ( $url ? '<a href="' . esc_url( $url ) . '" target="_blank">' . esc_html( basename( $url ) ) . '</a>' : 'ยังไม่มีไฟล์' ) . '</span> ';
				echo '<button type="button" class="button hos-media-pick" data-type="' . esc_attr( $f['type'] ) . '">เลือกไฟล์</button> <button type="button" class="button-link hos-media-clear">ล้าง</button>';
				break;
			case 'date_picker':
				$v = preg_match( '/^(\d{4})(\d{2})(\d{2})$/', (string) $value, $m ) ? "$m[1]-$m[2]-$m[3]" : $value;
				echo '<input type="date" name="' . $name . '" value="' . esc_attr( $v ) . '" data-acf-date="1"><input type="hidden" name="hos_field_date[' . esc_attr( $f['name'] ) . ']" value="1">';
				break;
			case 'number':
				echo '<input type="number" step="any" name="' . $name . '" value="' . esc_attr( $value ) . '">';
				break;
			case 'url':
			case 'email':
			case 'link':
				echo '<input type="' . ( 'email' === $f['type'] ? 'email' : 'url' ) . '" class="regular-text" name="' . $name . '" value="' . esc_attr( is_array( $value ) ? ( isset( $value['url'] ) ? $value['url'] : '' ) : $value ) . '">';
				break;
			default:
				echo '<input type="text" class="large-text" name="' . $name . '" value="' . esc_attr( is_scalar( $value ) ? $value : '' ) . '">';
		}
		if ( $f['instructions'] ) {
			echo '<p class="description">' . esc_html( $f['instructions'] ) . '</p>';
		}
		echo '</td></tr>';
	}
	echo '</table>';
}

function hos_fields_save( $post_id, $post ) {
	if ( ! isset( $_POST['hos_fields_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hos_fields_nonce'] ) ), 'hos_fields_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE || ! current_user_can( 'edit_post', $post_id ) || empty( $_POST['hos_field'] ) || ! is_array( $_POST['hos_field'] ) ) {
		return;
	}
	$dates = isset( $_POST['hos_field_date'] ) ? array_map( 'sanitize_key', array_keys( (array) $_POST['hos_field_date'] ) ) : array();
	$keys  = array();
	foreach ( hos_field_groups() as $g ) {
		foreach ( $g['fields'] as $f ) {
			$keys[ $f['name'] ] = $f;
		}
	}
	foreach ( wp_unslash( $_POST['hos_field'] ) as $name => $value ) {
		if ( ! isset( $keys[ $name ] ) ) {
			continue;
		}
		$type  = $keys[ $name ]['type'];
		$value = in_array( $type, array( 'textarea', 'wysiwyg' ), true ) ? wp_kses_post( $value ) : sanitize_text_field( $value );
		if ( in_array( $name, $dates, true ) ) {
			$value = str_replace( '-', '', $value ); // ACF เก็บวันที่แบบ Ymd
		}
		update_post_meta( $post_id, $name, $value );
		update_post_meta( $post_id, '_' . $name, $keys[ $name ]['key'] ); // คงรูปแบบเดิมของ ACF
	}
}
