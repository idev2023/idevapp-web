<?php
/** ฟังก์ชันเทียบเท่า ACF (โหลดเมื่อ ACF ปิดอยู่เท่านั้น) */
defined( 'ABSPATH' ) || exit;

function hos_field_def( $name ) {
	foreach ( hos_field_groups() as $g ) {
		foreach ( $g['fields'] as $f ) {
			if ( $f['name'] === $name ) {
				return $f;
			}
		}
	}
	return null;
}

function hos_resolve_post_id( $post_id ) {
	if ( false === $post_id || null === $post_id ) {
		return get_the_ID();
	}
	if ( 'option' === $post_id || 'options' === $post_id ) {
		return 'options';
	}
	return is_numeric( $post_id ) ? (int) $post_id : $post_id;
}

if ( ! function_exists( 'get_field' ) ) {
	function get_field( $selector, $post_id = false, $format_value = true ) {
		$post_id = hos_resolve_post_id( $post_id );
		$value   = 'options' === $post_id ? get_option( 'options_' . $selector ) : get_post_meta( (int) $post_id, $selector, true );
		if ( ! $format_value || '' === $value || null === $value ) {
			return $value;
		}
		$def = hos_field_def( $selector );
		if ( ! $def ) {
			return $value;
		}
		switch ( $def['type'] ) {
			case 'file':
			case 'image':
				if ( is_numeric( $value ) ) {
					$id = (int) $value;
					if ( 'id' === $def['return'] ) {
						return $id;
					}
					if ( 'url' === $def['return'] ) {
						return wp_get_attachment_url( $id );
					}
					return array( 'ID' => $id, 'id' => $id, 'url' => wp_get_attachment_url( $id ), 'title' => get_the_title( $id ), 'filename' => basename( (string) get_attached_file( $id ) ), 'mime_type' => get_post_mime_type( $id ), 'alt' => get_post_meta( $id, '_wp_attachment_image_alt', true ) );
				}
				return $value;
			case 'true_false':
				return (bool) $value;
			case 'date_picker':
				return preg_match( '/^(\d{4})(\d{2})(\d{2})$/', (string) $value, $m ) ? ( $def['return'] ? date_i18n( $def['return'], strtotime( "$m[1]-$m[2]-$m[3]" ) ) : $value ) : $value;
			case 'wysiwyg':
				return wpautop( $value );
		}
		return $value;
	}
}
if ( ! function_exists( 'the_field' ) ) {
	function the_field( $selector, $post_id = false ) {
		$v = get_field( $selector, $post_id );
		if ( is_array( $v ) ) {
			$v = isset( $v['url'] ) ? $v['url'] : implode( ', ', array_filter( $v, 'is_scalar' ) );
		}
		echo wp_kses_post( (string) $v );
	}
}
if ( ! function_exists( 'get_fields' ) ) {
	function get_fields( $post_id = false ) {
		$post_id = hos_resolve_post_id( $post_id );
		$out     = array();
		foreach ( hos_field_groups() as $g ) {
			foreach ( $g['fields'] as $f ) {
				if ( $f['name'] && metadata_exists( 'post', (int) $post_id, $f['name'] ) ) {
					$out[ $f['name'] ] = get_field( $f['name'], $post_id );
				}
			}
		}
		return $out;
	}
}
if ( ! function_exists( 'get_field_object' ) ) {
	function get_field_object( $selector, $post_id = false ) {
		$def = hos_field_def( $selector );
		return $def ? array_merge( $def, array( 'value' => get_field( $selector, $post_id ) ) ) : false;
	}
}
if ( ! function_exists( 'have_rows' ) ) {
	function have_rows() { return false; } // repeater ไม่รองรับในโหมดแทน ACF
}
