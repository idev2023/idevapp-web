<?php
/**
 * แทน Content Views / Post Grid / Elementor post widgets
 * [hos_posts type="post" category="slug" taxonomy="" term="" limit="10" style="list|grid" more="URL"]
 * shortcode เดิม [pt_view id=".."] และ [post_grid id=".."] ยังใช้ได้: อ่านค่าหมวด/ประเภท/จำนวนจากการตั้งค่าเดิมเท่าที่หาได้
 */
defined( 'ABSPATH' ) || exit;

function hos_posts_shortcode( $atts ) {
	$a = shortcode_atts( array( 'type' => 'post', 'category' => '', 'taxonomy' => '', 'term' => '', 'limit' => 10, 'style' => 'list', 'more' => '', 'year' => '' ), $atts, 'hos_posts' );
	$q = array( 'post_type' => array_map( 'sanitize_key', explode( ',', $a['type'] ) ), 'posts_per_page' => max( 1, min( 100, (int) $a['limit'] ) ), 'ignore_sticky_posts' => true, 'no_found_rows' => true );
	if ( $a['category'] ) {
		$q['category_name'] = sanitize_text_field( $a['category'] );
	}
	if ( $a['taxonomy'] && $a['term'] ) {
		$q['tax_query'] = array( array( 'taxonomy' => sanitize_key( $a['taxonomy'] ), 'field' => is_numeric( $a['term'] ) ? 'term_id' : 'slug', 'terms' => array_map( 'trim', explode( ',', $a['term'] ) ) ) );
	}
	if ( $a['year'] ) {
		$q['meta_key']   = '_hos_fiscal_year';
		$q['meta_value'] = sanitize_text_field( $a['year'] );
	}
	$posts = get_posts( $q );
	if ( function_exists( 'hos_theme_post_list' ) ) {
		ob_start();
		hos_theme_post_list( $posts, $a['style'] );
		$html = ob_get_clean();
	} else {
		$html = '<ul class="hos-sc-list">';
		foreach ( $posts as $p ) {
			$doc   = hos_get_document_url( $p->ID );
			$html .= '<li><a href="' . esc_url( $doc && ! trim( wp_strip_all_tags( $p->post_content ) ) ? $doc : get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a> <small>' . esc_html( get_the_date( '', $p ) ) . '</small></li>';
		}
		$html .= '</ul>';
	}
	if ( $a['more'] ) {
		$html .= '<p class="hos-sc-more"><a href="' . esc_url( $a['more'] ) . '">ดูทั้งหมด →</a></p>';
	}
	return $html;
}
add_shortcode( 'hos_posts', 'hos_posts_shortcode' );

/** อ่านค่า Content Views / Post Grid เดิมแบบ best-effort จาก postmeta ของ view */
function hos_legacy_view_atts( $view_id ) {
	$atts = array( 'limit' => 10 );
	if ( ! $view_id ) {
		return $atts;
	}
	$meta = get_post_meta( (int) $view_id );
	if ( ! $meta ) {
		// Content Views เก็บ view เป็นโพสต์ที่มี meta view id
		global $wpdb;
		$pid = $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key LIKE %s AND meta_value = %s LIMIT 1", '%view_id%', $view_id ) );
		$meta = $pid ? get_post_meta( (int) $pid ) : array();
	}
	foreach ( (array) $meta as $k => $v ) {
		$v = maybe_unserialize( is_array( $v ) ? $v[0] : $v );
		if ( is_array( $v ) ) {
			// post_grid_meta_options (Post Grid) เก็บเป็น array ซ้อน
			array_walk_recursive( $v, function ( $val, $key ) use ( &$atts ) {
				if ( in_array( $key, array( 'post_types', 'post_type' ), true ) && is_string( $val ) ) {
					$atts['type'] = $val;
				}
				if ( in_array( $key, array( 'posts_per_page', 'items_per_page', 'limit' ), true ) && is_numeric( $val ) ) {
					$atts['limit'] = (int) $val;
				}
			} );
			continue;
		}
		$k = (string) $k;
		if ( preg_match( '/(post_type|content-type)$/', $k ) && $v && is_string( $v ) ) {
			$atts['type'] = $v;
		} elseif ( preg_match( '/(limit|posts_per_page|pagination-items-per-page)$/', $k ) && is_numeric( $v ) ) {
			$atts['limit'] = (int) $v;
		} elseif ( preg_match( '/taxonomy-category$|category__in$/', $k ) && $v ) {
			$term = get_term( is_numeric( $v ) ? (int) $v : 0, 'category' );
			if ( $term && ! is_wp_error( $term ) ) {
				$atts['category'] = $term->slug;
			}
		}
	}
	return $atts;
}

add_action( 'init', function () {
	foreach ( array( 'pt_view', 'post_grid', 'content_views' ) as $tag ) {
		if ( ! shortcode_exists( $tag ) ) {
			add_shortcode( $tag, function ( $atts ) {
				$atts = (array) $atts;
				return hos_posts_shortcode( array_merge( hos_legacy_view_atts( isset( $atts['id'] ) ? $atts['id'] : 0 ), array_diff_key( $atts, array( 'id' => 1 ) ) ) );
			} );
		}
	}
}, 20 );
