<?php
/**
 * แก้ CSP (Content-Security-Policy) ในหน้าหลังบ้าน
 * ปลั๊กอิน HTTP Headers ตั้ง CSP ที่ไม่อนุญาต blob: ทำให้ตัวแก้ไขบล็อก (Gutenberg) และการอัปโหลดรูปพัง
 * เพิ่ม blob: ให้ worker-src / frame-src / child-src / img-src เฉพาะหน้า wp-admin (หน้าเว็บสาธารณะไม่เปลี่ยน)
 * ปิดได้ด้วย define( 'HOS_DISABLE_CSP_FIX', true ); ใน wp-config.php
 */
defined( 'ABSPATH' ) || exit;

function hos_csp_add_blob( $value ) {
	$add = array( 'worker-src', 'frame-src', 'child-src', 'img-src', 'media-src' );
	$parts = array_filter( array_map( 'trim', explode( ';', $value ) ) );
	$map   = array();
	foreach ( $parts as $p ) {
		$sp = preg_split( '/\s+/', $p, 2 );
		$map[ strtolower( $sp[0] ) ] = isset( $sp[1] ) ? $sp[1] : '';
	}
	foreach ( $add as $d ) {
		// a directive that is not set (and no default-src) allows everything: leave it alone
		if ( ! isset( $map[ $d ] ) && ! isset( $map['default-src'] ) ) {
			continue;
		}
		$src = isset( $map[ $d ] ) ? $map[ $d ] : $map['default-src'];
		if ( false === strpos( $src, 'blob:' ) ) {
			$src .= ' blob:';
		}
		$map[ $d ] = trim( $src );
	}
	$out = array();
	foreach ( $map as $k => $v ) {
		$out[] = trim( $k . ' ' . $v );
	}
	return implode( '; ', $out );
}

function hos_fix_admin_csp() {
	if ( ( defined( 'HOS_DISABLE_CSP_FIX' ) && HOS_DISABLE_CSP_FIX ) || headers_sent() ) {
		return;
	}
	foreach ( headers_list() as $h ) {
		foreach ( array( 'Content-Security-Policy', 'Content-Security-Policy-Report-Only' ) as $name ) {
			if ( 0 === stripos( $h, $name . ':' ) ) {
				$val = trim( substr( $h, strlen( $name ) + 1 ) );
				header_remove( $name );
				header( $name . ': ' . hos_csp_add_blob( $val ) );
			}
		}
	}
}
// หลังปลั๊กอินอื่นส่ง header แล้ว แต่ก่อนแสดงผลหน้า
add_action( 'admin_init', 'hos_fix_admin_csp', PHP_INT_MAX );
add_action( 'admin_head', 'hos_fix_admin_csp', 0 );
add_action( 'login_init', 'hos_fix_admin_csp', PHP_INT_MAX );
