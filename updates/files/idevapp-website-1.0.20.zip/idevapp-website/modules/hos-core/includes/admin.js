/* ตัวเลือกไฟล์จาก Media Library สำหรับฟิลด์ไฟล์/รูป และไฟล์แนบเอกสาร */
jQuery(function ($) {
  $(document).on('click', '.hos-media-pick', function (e) {
    e.preventDefault();
    var $td = $(this).closest('td, .hos-media-field');
    var frame = wp.media({ title: 'เลือกไฟล์', multiple: false, library: $(this).data('type') === 'image' ? { type: 'image' } : {} });
    frame.on('select', function () {
      var a = frame.state().get('selection').first().toJSON();
      $td.find('.hos-media-id').val(a.id);
      $td.find('.hos-media-name').html($('<a target="_blank">').attr('href', a.url).text(a.filename || a.url));
    });
    frame.open();
  });
  $(document).on('click', '.hos-media-clear', function (e) {
    e.preventDefault();
    var $td = $(this).closest('td, .hos-media-field');
    $td.find('.hos-media-id').val('');
    $td.find('.hos-media-name').text('ยังไม่มีไฟล์');
  });
});
