<?php
/**
 * Module: แปลภาษาอัตโนมัติ
 * แปลทุกหน้าในเบราว์เซอร์ (Google Translate) จากภาษาไทยเป็นภาษาที่เลือกไว้ — เปิด / ปิดได้ เลือกเพิ่ม / ลดภาษาเองได้
 * ปุ่มเลือกภาษาแสดงในที่ของธีม (ถ้าธีมรองรับ) หรือลอยที่มุมจอ หรือวางเองด้วย [idw_lang_switch]
 * ผลการแปลจำไว้ในเครื่องผู้เข้าชม (localStorage) · ข้อความที่มี class="notranslate" หรือ translate="no" ไม่ถูกแปล
 */
defined('ABSPATH') || exit;
if (defined('IDW_TR_VERSION')) return;
define('IDW_TR_VERSION', defined('IDW_VERSION') ? IDW_VERSION : '1.0.0');

/** code => [native name, Thai name, flag] — Google Translate language codes */
function idw_tr_catalog() {
    return [
        'en' => ['English', 'อังกฤษ', '🇬🇧'], 'zh-CN' => ['中文 (简体)', 'จีน (ตัวย่อ)', '🇨🇳'], 'zh-TW' => ['中文 (繁體)', 'จีน (ตัวเต็ม)', '🇹🇼'],
        'ja' => ['日本語', 'ญี่ปุ่น', '🇯🇵'], 'ko' => ['한국어', 'เกาหลี', '🇰🇷'], 'ru' => ['Русский', 'รัสเซีย', '🇷🇺'], 'de' => ['Deutsch', 'เยอรมัน', '🇩🇪'],
        'fr' => ['Français', 'ฝรั่งเศส', '🇫🇷'], 'es' => ['Español', 'สเปน', '🇪🇸'], 'it' => ['Italiano', 'อิตาลี', '🇮🇹'], 'pt' => ['Português', 'โปรตุเกส', '🇵🇹'],
        'nl' => ['Nederlands', 'ดัตช์', '🇳🇱'], 'sv' => ['Svenska', 'สวีเดน', '🇸🇪'], 'fi' => ['Suomi', 'ฟินแลนด์', '🇫🇮'], 'da' => ['Dansk', 'เดนมาร์ก', '🇩🇰'], 'no' => ['Norsk', 'นอร์เวย์', '🇳🇴'],
        'pl' => ['Polski', 'โปแลนด์', '🇵🇱'], 'uk' => ['Українська', 'ยูเครน', '🇺🇦'], 'cs' => ['Čeština', 'เช็ก', '🇨🇿'], 'tr' => ['Türkçe', 'ตุรกี', '🇹🇷'], 'he' => ['עברית', 'ฮีบรู', '🇮🇱'],
        'ar' => ['العربية', 'อาหรับ', '🇸🇦'], 'fa' => ['فارسی', 'เปอร์เซีย', '🇮🇷'], 'hi' => ['हिन्दी', 'ฮินดี', '🇮🇳'], 'bn' => ['বাংলা', 'เบงกาลี', '🇧🇩'],
        'ms' => ['Bahasa Melayu', 'มลายู', '🇲🇾'], 'id' => ['Bahasa Indonesia', 'อินโดนีเซีย', '🇮🇩'], 'vi' => ['Tiếng Việt', 'เวียดนาม', '🇻🇳'], 'tl' => ['Filipino', 'ฟิลิปปินส์', '🇵🇭'],
        'my' => ['မြန်မာ', 'เมียนมา', '🇲🇲'], 'km' => ['ខ្មែរ', 'เขมร', '🇰🇭'], 'lo' => ['ລາວ', 'ลาว', '🇱🇦'],
    ];
}
function idw_tr_settings() {
    $s = get_option('idw_translate', []);
    $s = wp_parse_args(is_array($s) ? $s : [], ['on' => '1', 'langs' => ['en'], 'style' => 'auto', 'place' => 'auto', 'side' => 'left']);
    $cat = idw_tr_catalog();
    $s['langs'] = array_values(array_filter((array) $s['langs'], function ($c) use ($cat) { return isset($cat[$c]); }));
    return $s;
}
function idw_tr_on() { $s = idw_tr_settings(); return '1' === $s['on'] && $s['langs'] && !is_admin(); }

/* The translation built into older hospital themes (theme setting “…_auto_translate”) steps aside, so there is one switcher only. */
function idw_tr_theme_prefixes() {
    static $out = null;
    if (null !== $out) return $out;
    $out = [];
    foreach (array_keys((array) get_theme_mods()) as $k) if (preg_match('/^([a-z0-9]+)_auto_translate$/', $k, $m)) $out[] = $m[1];
    foreach (get_defined_functions()['user'] as $f) if (preg_match('/^([a-z0-9]+)_translate_on$/', $f, $m) && 'idw_tr' !== $m[1]) $out[] = $m[1];
    return $out = array_values(array_unique($out));
}
add_action('after_setup_theme', function () {
    if ('1' !== idw_tr_settings()['on']) return;
    foreach (idw_tr_theme_prefixes() as $p) add_filter('theme_mod_' . $p . '_auto_translate', function () { return 'off'; });
    // the older theme's own switcher lived in “<prefix>-social” of its top bar: put ours there
    $GLOBALS['idw_tr_slots'] = array_map(function ($p) { return '.' . $p . '-social'; }, idw_tr_theme_prefixes());
}, 20);

/* ---------- switcher ---------- */
function idw_tr_switcher($extra = '') {
    if (!idw_tr_on()) return '';
    $s = idw_tr_settings(); $cat = idw_tr_catalog();
    $GLOBALS['idw_tr_printed'] = 1;
    $all = array_merge(['th'], $s['langs']);
    $dd = 'dropdown' === $s['style'] || ('auto' === $s['style'] && count($all) > 3);
    $name = function ($c) use ($cat) { return 'th' === $c ? 'ไทย' : $cat[$c][0]; };
    $flag = function ($c) use ($cat) { return 'th' === $c ? '🇹🇭' : $cat[$c][2]; };
    $short = function ($c) { return strtoupper(substr($c, 0, 2)); };
    if (!$dd) {
        $h = '<span class="idw-lang notranslate ' . esc_attr($extra) . '" translate="no" role="group" aria-label="เลือกภาษา / Language">';
        foreach ($all as $c) $h .= '<a href="#" data-idw-lang="' . esc_attr($c) . '" lang="' . esc_attr($c) . '" title="' . esc_attr($name($c)) . '">' . esc_html($short($c)) . '</a>';
        return $h . '</span>';
    }
    $h = '<details class="idw-lang idw-lang-dd notranslate ' . esc_attr($extra) . '" translate="no"><summary aria-label="เลือกภาษา / Language"><span class="g" aria-hidden="true">🌐</span><b data-idw-cur>TH</b><i aria-hidden="true">▾</i></summary><div class="m">';
    foreach ($all as $c) $h .= '<a href="#" data-idw-lang="' . esc_attr($c) . '" lang="' . esc_attr($c) . '"><span class="f wp-exclude-emoji" aria-hidden="true">' . esc_html($flag($c)) . '</span>' . esc_html($name($c)) . '</a>';
    return $h . '</div></details>';
}
add_shortcode('idw_lang_switch', function () { return idw_tr_switcher(); });

add_action('wp_head', function () {
    if (!idw_tr_on()) return;
    echo '<style id="idw-tr">.idw-lang{display:inline-flex;align-items:center;gap:2px;font:700 13px/1 system-ui,sans-serif;vertical-align:middle}'
        . '.idw-lang>a{display:inline-flex;align-items:center;justify-content:center;min-width:34px;min-height:30px;padding:0 9px;border-radius:999px;color:inherit;text-decoration:none;opacity:.85}.idw-lang>a.on{background:#fff;color:#0b3d2e;opacity:1}'
        . '.idw-lang-dd{position:relative}.idw-lang-dd summary{list-style:none;cursor:pointer;display:inline-flex;align-items:center;gap:6px;min-height:32px;padding:0 12px;border-radius:999px;border:1px solid rgba(127,127,127,.35);color:inherit}.idw-lang-dd summary::-webkit-details-marker{display:none}.idw-lang-dd summary i{font-style:normal;font-size:10px;opacity:.7}'
        . '.idw-lang-dd .m{position:absolute;z-index:99990;top:calc(100% + 6px);right:0;min-width:190px;max-height:60vh;overflow:auto;background:#fff;color:#14281f;border-radius:12px;box-shadow:0 14px 40px rgba(0,0,0,.22);padding:6px;font-weight:600}'
        . '.idw-lang-dd .m a{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:8px;color:inherit;text-decoration:none}.idw-lang-dd .m a:hover,.idw-lang-dd .m a.on{background:#eef6f2}.idw-lang-dd .m a.on{color:#0a7d55}.idw-lang-dd .f{font-size:18px}'
        . '.idw-lang-float{position:fixed;z-index:99980;bottom:84px;background:#fff;color:#14281f;border-radius:999px;box-shadow:0 8px 24px rgba(0,0,0,.18);padding:3px}.idw-lang-float.l{left:16px}.idw-lang-float.r{right:16px}.idw-lang-float>a.on{background:#0a7d55;color:#fff}.idw-lang-float.idw-lang-dd summary{border:0}.idw-lang-float .m{top:auto;bottom:calc(100% + 8px)}.idw-lang-float.l .m{left:0;right:auto}'
        . '@media(max-width:760px){.idw-lang-float{bottom:calc(80px + env(safe-area-inset-bottom))}}'
        . '.idw-tr-badge{position:fixed;left:50%;top:14px;transform:translate(-50%,-10px);z-index:99999;background:#075a3e;color:#fff;font:600 13px/1 system-ui,sans-serif;padding:9px 14px;border-radius:999px;box-shadow:0 8px 24px rgba(0,0,0,.2);opacity:0;transition:.25s;pointer-events:none}.idw-tr-badge.on{opacity:1;transform:translate(-50%,0)}.idw-tr-badge:before{content:"";display:inline-block;width:10px;height:10px;margin-right:8px;border:2px solid #fff;border-right-color:transparent;border-radius:50%;animation:idwspin .7s linear infinite;vertical-align:-1px}@keyframes idwspin{to{transform:rotate(360deg)}}</style>' . "\n";
}, 1);

add_action('wp_footer', function () {
    if (!idw_tr_on()) return;
    $s = idw_tr_settings();
    $float = '';
    if ('none' !== $s['place'] && ('float' === $s['place'] || empty($GLOBALS['idw_tr_printed']))) {
        $float = idw_tr_switcher('idw-lang-float ' . ('right' === $s['side'] ? 'r' : 'l'));
    }
    $bl = function_exists('idev_bl_settings') ? (string) idev_bl_settings()['cookie'] : '';
    $cfg = ['langs' => array_merge(['th'], $s['langs']), 'bl' => $bl, 'slots' => 'auto' === $s['place'] ? array_values((array) ($GLOBALS['idw_tr_slots'] ?? [])) : [], 'rtl' => ['ar', 'he', 'fa', 'ur']];
    echo '<template id="idw-tr-float">' . $float . '</template>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    ?>
    <script>
    /* แปลภาษาอัตโนมัติ: ไทย → ภาษาที่เลือก แปลข้อความทุกส่วนของหน้าในเบราว์เซอร์ (Google Translate) และจำผลไว้ในเครื่อง */
    (function () {
        var C = <?php echo wp_json_encode($cfg); ?>, TH = /[฀-๿]/, LETTER = /[A-Za-zÀ-ɏ฀-๿Ѐ-ӿ؀-ۿ぀-ヿ一-鿿가-힯]/,
            SKIP = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEXTAREA: 1, CODE: 1, PRE: 1, svg: 1, TEMPLATE: 1 };
        function getLang() { var m = document.cookie.match(/(?:^|; )idw_lang=([\w-]+)/); return m && C.langs.indexOf(m[1]) > -1 ? m[1] : 'th'; }
        function setLang(l) {
            document.cookie = 'idw_lang=' + l + ';path=/;max-age=31536000;SameSite=Lax';
            if (C.bl) document.cookie = C.bl + '=' + (l === 'en' ? 'en' : 'th') + ';path=/;max-age=31536000;SameSite=Lax'; // the bilingual module's own English texts for EN, Thai as the source for the others
            ['googtrans', 'hos_lang'].forEach(function (k) { document.cookie = k + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/'; });
        }
        var lang = getLang();
        /* the switcher: in the theme's spot, or floating */
        var tpl = document.getElementById('idw-tr-float');
        if (tpl && tpl.innerHTML.trim()) {
            var slot = null; C.slots.forEach(function (s) { if (!slot) slot = document.querySelector(s); });
            var holder = document.createElement('div'); holder.innerHTML = tpl.innerHTML; var sw = holder.firstElementChild;
            if (slot) { sw.classList.remove('idw-lang-float', 'l', 'r'); slot.insertBefore(sw, slot.firstChild); } else document.body.appendChild(sw);
        }
        document.querySelectorAll('[data-idw-lang]').forEach(function (a) { a.classList.toggle('on', a.dataset.idwLang === lang); });
        document.querySelectorAll('[data-idw-cur]').forEach(function (b) { b.textContent = lang.slice(0, 2).toUpperCase(); });
        document.addEventListener('click', function (e) {
            var a = e.target.closest('[data-idw-lang]'); if (!a) { document.querySelectorAll('details.idw-lang-dd[open]').forEach(function (d) { if (!d.contains(e.target)) d.removeAttribute('open'); }); return; }
            e.preventDefault(); if (a.dataset.idwLang === getLang()) return; setLang(a.dataset.idwLang); location.reload();
        });
        if (lang === 'th') return;
        document.documentElement.lang = lang; document.documentElement.classList.add('idw-tr-' + lang);
        if (C.rtl.indexOf(lang) > -1) document.documentElement.dir = 'rtl';
        var fromThai = lang === 'en', mem = {}, store = null; try { store = window.localStorage; } catch (e) {}
        var KEY = 'idwT:' + lang + ':';
        function cached(t) { if (mem[t] !== undefined) return mem[t]; try { var v = store && store.getItem(KEY + t); if (v !== null && v !== undefined) return (mem[t] = v); } catch (e) {} return undefined; }
        function remember(t, v) { mem[t] = v; try { store && store.setItem(KEY + t, v); } catch (e) {} }
        function want(t) { return fromThai ? TH.test(t) : LETTER.test(t); }
        function skip(el) { for (; el && el !== document.body; el = el.parentElement) { if (SKIP[el.nodeName] || (el.classList && el.classList.contains('notranslate')) || (el.getAttribute && el.getAttribute('translate') === 'no') || el.isContentEditable) return true; } return false; }
        function collect(root, jobs) {
            var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), n;
            while ((n = w.nextNode())) {
                if (n.__idw || !want(n.nodeValue) || skip(n.parentElement)) continue;
                var raw = n.nodeValue, core = raw.replace(/\s+/g, ' ').trim(); if (!core) continue;
                jobs.push({ text: core, apply: (function (node, r) { return function (v) { node.__idw = 1; node.nodeValue = r.match(/^\s*/)[0] + v + r.match(/\s*$/)[0]; }; })(n, raw) });
            }
            (root.querySelectorAll ? root.querySelectorAll('[placeholder],[title],[aria-label],img[alt],input[type=submit],input[type=button]') : []).forEach(function (el) {
                if (skip(el)) return;
                ['placeholder', 'title', 'aria-label', 'alt', 'value'].forEach(function (at) {
                    var v = el.getAttribute(at); if (!v || !want(v) || (at === 'value' && !/submit|button/.test(el.type))) return;
                    jobs.push({ text: v.replace(/\s+/g, ' ').trim(), apply: function (x) { el.setAttribute(at, x); } });
                });
            });
        }
        function request(list) {
            return fetch('https://translate.googleapis.com/translate_a/single?client=gtx&sl=' + (fromThai ? 'th' : 'auto') + '&tl=' + encodeURIComponent(lang) + '&dt=t', { method: 'POST', body: new URLSearchParams({ q: list.join('\n') }) })
                .then(function (r) { return r.json(); })
                .then(function (j) { return (j && j[0] ? j[0].map(function (s) { return s[0] || ''; }).join('') : '').split('\n').map(function (s) { return s.trim(); }); });
        }
        function translateBatch(list) {
            return request(list).then(function (out) {
                if (out.length === list.length) { list.forEach(function (t, i) { remember(t, out[i]); }); return; }
                return Promise.all(list.map(function (t) { return request([t]).then(function (o) { remember(t, o.join(' ')); }); }));
            }).catch(function () {});
        }
        var badge = null, running = 0;
        function busy(on) { running += on ? 1 : -1; if (!badge) { badge = document.createElement('div'); badge.className = 'idw-tr-badge notranslate'; badge.textContent = 'Translating…'; document.body.appendChild(badge); } badge.classList.toggle('on', running > 0); }
        function run(root) {
            var jobs = []; collect(root, jobs); if (!jobs.length) return;
            var todo = [], seen = {};
            jobs.forEach(function (j) { var c = cached(j.text); if (c !== undefined) j.apply(c); else if (!seen[j.text]) { seen[j.text] = 1; todo.push(j.text); } });
            if (!todo.length) return;
            var batches = [], cur = [], len = 0;
            todo.forEach(function (t) { if (len + t.length > 1800 && cur.length) { batches.push(cur); cur = []; len = 0; } cur.push(t); len += t.length + 1; });
            if (cur.length) batches.push(cur);
            busy(true); var i = 0;
            function next() { if (i >= batches.length) return Promise.resolve(); return translateBatch(batches[i++]).then(next); }
            Promise.all([next(), next(), next()]).then(function () { jobs.forEach(function (j) { var c = cached(j.text); if (c !== undefined && c !== '') j.apply(c); }); busy(false); });
        }
        function start() {
            run(document.body);
            var pending = [], t = null;
            new MutationObserver(function (ms) {
                ms.forEach(function (m) { m.addedNodes.forEach(function (n) { if (n.nodeType === 1 || n.nodeType === 3) pending.push(n.nodeType === 3 ? n.parentNode : n); }); if (m.type === 'characterData' && m.target.parentNode && !m.target.__idw) pending.push(m.target.parentNode); });
                clearTimeout(t); t = setTimeout(function () { var p = pending; pending = []; p.forEach(function (n) { if (n && n.isConnected && n !== badge) run(n); }); }, 120);
            }).observe(document.body, { childList: true, subtree: true });
        }
        if (document.title && want(document.title)) { var ct = cached(document.title); if (ct) document.title = ct; else request([document.title]).then(function (o) { remember(document.title, o.join(' ')); document.title = o.join(' '); }).catch(function () {}); }
        document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', start) : start();
    })();
    </script>
    <?php
}, 50);

/* ---------- settings page ---------- */
add_action('admin_menu', function () {
    add_submenu_page('idevapp', 'แปลภาษาอัตโนมัติ', 'แปลภาษาอัตโนมัติ', 'manage_options', 'idw-translate', 'idw_tr_page');
}, 22);
add_action('admin_enqueue_scripts', function () {
    if (($_GET['page'] ?? '') !== 'idw-translate') return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    wp_enqueue_style('idw-admin'); wp_enqueue_script('idw-admin');
});
add_action('admin_post_idw_tr_save', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_tr_save')) wp_die('ไม่มีสิทธิ์', 403);
    $cat = idw_tr_catalog();
    $langs = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array) wp_unslash($_POST['langs'] ?? [])), function ($c) use ($cat) { return isset($cat[$c]); })));
    update_option('idw_translate', [
        'on' => empty($_POST['on']) ? '0' : '1',
        'langs' => $langs,
        'style' => in_array($_POST['style'] ?? '', ['auto', 'buttons', 'dropdown'], true) ? $_POST['style'] : 'auto', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
        'place' => in_array($_POST['place'] ?? '', ['auto', 'float', 'none'], true) ? $_POST['place'] : 'auto', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
        'side' => ($_POST['side'] ?? '') === 'right' ? 'right' : 'left',
    ]);
    if (function_exists('idw_sec_purge')) idw_sec_purge();
    wp_safe_redirect(add_query_arg(['page' => 'idw-translate', 'saved' => 1], admin_url('admin.php')));
    exit;
});

function idw_tr_page() {
    if (!current_user_can('manage_options')) wp_die('ไม่มีสิทธิ์');
    $s = idw_tr_settings(); $cat = idw_tr_catalog();
    idw_open('แปลภาษาอัตโนมัติ', 'ผู้เข้าชมกดเลือกภาษา แล้วข้อความทั้งหน้าแปลจากภาษาไทยให้ทันที (Google Translate) — เลือกเองได้ว่าจะเปิดใช้ไหม และมีภาษาอะไรบ้าง');
    if (isset($_GET['saved'])) idw_note('บันทึกแล้ว — เปิดหน้าเว็บดูได้เลย (ถ้าใช้ปลั๊กอินแคช ระบบล้างแคชให้แล้ว)'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $row = function ($c) use ($cat) { return '<li data-c="' . esc_attr($c) . '"><span class="f">' . esc_html($cat[$c][2]) . '</span><span class="n"><b>' . esc_html($cat[$c][1]) . '</b><small>' . esc_html($cat[$c][0]) . ' · ' . esc_html($c) . '</small></span><input type="hidden" name="langs[]" value="' . esc_attr($c) . '"><button type="button" class="idw-btn sm" data-mv="-1" title="เลื่อนขึ้น">↑</button><button type="button" class="idw-btn sm" data-mv="1" title="เลื่อนลง">↓</button><button type="button" class="idw-btn sm" data-rm title="เอาออก">✕</button></li>'; };
    ?>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="idw-tr">
        <?php wp_nonce_field('idw_tr_save'); ?><input type="hidden" name="action" value="idw_tr_save">
        <div class="idw-cols"><div>
        <div class="idw-card">
            <label class="idw-opt"><input type="checkbox" name="on" value="1" <?php checked($s['on'], '1'); ?>><span><b>เปิดใช้การแปลภาษาอัตโนมัติ</b><small>ปิด = ไม่มีปุ่มเลือกภาษาและไม่แปล (ถ้าเปิดโมดูล “สองภาษา” ไว้ ปุ่ม TH / EN ของโมดูลนั้นยังใช้ได้ตามปกติ)</small></span></label>
        </div>
        <div class="idw-card">
            <h2><?php echo idw_icon('globe'); // phpcs:ignore ?>ภาษาที่ให้เลือก</h2>
            <p class="d">ภาษาไทยเป็นภาษาต้นฉบับเสมอ · เพิ่ม / เอาออก / เรียงลำดับได้ตามต้องการ</p>
            <ul class="tr-list"><li class="th"><span class="f">🇹🇭</span><span class="n"><b>ไทย</b><small>ภาษาต้นฉบับของเว็บ</small></span></li><?php foreach ($s['langs'] as $c) echo $row($c); // phpcs:ignore ?></ul>
            <p class="tr-add"><select id="tr-pick" class="idw-in"><option value="">— เลือกภาษาที่จะเพิ่ม —</option><?php foreach ($cat as $c => $v) echo '<option value="' . esc_attr($c) . '"' . (in_array($c, $s['langs'], true) ? ' disabled' : '') . '>' . esc_html($v[2] . ' ' . $v[1] . ' — ' . $v[0]) . '</option>'; ?></select> <button type="button" class="idw-btn pri" id="tr-addb">＋ เพิ่มภาษา</button></p>
        </div>
        </div><div>
        <div class="idw-card">
            <h2>ปุ่มเลือกภาษา</h2>
            <p class="d" style="margin-bottom:6px"><b>รูปแบบ</b></p>
            <div class="idw-opts">
                <?php foreach (['auto' => ['อัตโนมัติ', 'ไม่เกิน 3 ภาษา = ปุ่ม TH EN · มากกว่านั้น = เมนูเลือกภาษา'], 'buttons' => ['ปุ่มเรียงกัน', 'TH EN RU DE …'], 'dropdown' => ['เมนูเลือกภาษา', '🌐 TH ▾ แล้วเลือกจากรายการพร้อมธงชาติ']] as $k => $v) echo '<label class="idw-opt"><input type="radio" name="style" value="' . esc_attr($k) . '" ' . checked($s['style'], $k, false) . '><span><b>' . esc_html($v[0]) . '</b><small>' . esc_html($v[1]) . '</small></span></label>'; ?>
            </div>
            <p class="d" style="margin:14px 0 6px"><b>ตำแหน่ง</b></p>
            <div class="idw-opts">
                <?php foreach (['auto' => ['ในที่ของธีม', 'แถบบนสุดของธีม (ถ้ามี) — ถ้าธีมไม่มีที่ให้ จะลอยที่มุมจอ'], 'float' => ['ลอยที่มุมจอเสมอ', 'ปุ่มลอยมุมล่างของหน้าจอ'], 'none' => ['วางเอง', 'ใส่ [idw_lang_switch] ในเมนู วิดเจ็ต หรือหน้าเว็บ']] as $k => $v) echo '<label class="idw-opt"><input type="radio" name="place" value="' . esc_attr($k) . '" ' . checked($s['place'], $k, false) . '><span><b>' . esc_html($v[0]) . '</b><small>' . esc_html($v[1]) . '</small></span></label>'; ?>
            </div>
            <p class="d" style="margin:14px 0 6px"><b>ปุ่มลอยอยู่ด้าน</b></p>
            <div class="idw-opts"><label class="idw-opt"><input type="radio" name="side" value="left" <?php checked($s['side'], 'left'); ?>><span><b>ซ้าย</b></span></label><label class="idw-opt"><input type="radio" name="side" value="right" <?php checked($s['side'], 'right'); ?>><span><b>ขวา</b></span></label></div>
        </div>
        <div class="idw-card"><p class="d" style="margin:0">ข้อความถูกส่งไปแปลที่ Google จากเบราว์เซอร์ของผู้เข้าชมเมื่อเลือกภาษาอื่นเท่านั้น · ข้อความที่ไม่ต้องการให้แปล (เช่น ชื่อแพทย์) ใส่ class <code>notranslate</code> · หน้าที่แปลเองไว้ในโมดูล “สองภาษา” จะใช้ข้อความภาษาอังกฤษที่เขียนไว้</p></div>
        </div></div>
        <p><button class="idw-btn pri"><?php echo idw_icon('check'); // phpcs:ignore ?>บันทึก</button></p>
    </form>
    <style>.idw-tr .tr-list{list-style:none;margin:0 0 12px;padding:0}.idw-tr .tr-list li{display:flex;align-items:center;gap:10px;padding:8px 10px;border:1px solid #e3e8ef;border-radius:10px;margin-bottom:6px;background:#fff}.idw-tr .tr-list li.th{background:#f6f8fa}.idw-tr .tr-list .f{font-size:22px;width:30px;text-align:center;flex:none}.idw-tr .tr-list .f img{width:22px;height:22px}.idw-tr .tr-list .n{flex:1;min-width:0}.idw-tr .tr-list .n b{display:block}.idw-tr .tr-list .n small{color:#646970}.idw-tr .tr-list .idw-btn{flex:none}.idw-tr .tr-add{display:flex;gap:8px;flex-wrap:wrap}.idw-tr .tr-add select{flex:1;min-width:220px}</style>
    <script>
    (function () {
        var list = document.querySelector('.tr-list'), pick = document.getElementById('tr-pick'), CAT = <?php echo wp_json_encode($cat, JSON_UNESCAPED_UNICODE); ?>;
        function esc(t) { var i = document.createElement('i'); i.textContent = t; return i.innerHTML; }
        function sync() { var on = {}; list.querySelectorAll('li[data-c]').forEach(function (li) { on[li.dataset.c] = 1; }); [].forEach.call(pick.options, function (o) { if (o.value) o.disabled = !!on[o.value]; }); pick.value = ''; }
        document.getElementById('tr-addb').addEventListener('click', function () {
            var c = pick.value; if (!c || list.querySelector('li[data-c="' + c + '"]')) return; var v = CAT[c], li = document.createElement('li'); li.dataset.c = c;
            li.innerHTML = '<span class="f">' + esc(v[2]) + '</span><span class="n"><b>' + esc(v[1]) + '</b><small>' + esc(v[0]) + ' · ' + esc(c) + '</small></span><input type="hidden" name="langs[]" value="' + esc(c) + '"><button type="button" class="idw-btn sm" data-mv="-1">↑</button><button type="button" class="idw-btn sm" data-mv="1">↓</button><button type="button" class="idw-btn sm" data-rm>✕</button>';
            list.appendChild(li); sync();
        });
        list.addEventListener('click', function (e) {
            var b = e.target.closest('button'); if (!b) return; var li = b.closest('li'); // closest(): the emoji may be an <img>
            if (b.hasAttribute('data-rm')) { li.remove(); sync(); return; }
            var mv = +b.dataset.mv; if (mv < 0 && li.previousElementSibling && li.previousElementSibling.dataset.c) list.insertBefore(li, li.previousElementSibling); if (mv > 0 && li.nextElementSibling) list.insertBefore(li.nextElementSibling, li);
        });
    })();
    </script>
    <?php
    idw_close();
}
