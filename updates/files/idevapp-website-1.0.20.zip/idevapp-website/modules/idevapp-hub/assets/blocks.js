/* Editor for the "iDevApp" blocks: live server preview in the page, all fields (TH + EN) in the side panel. */
(function (wp) {
  const { registerBlockType } = wp.blocks;
  const h = wp.element.createElement;
  const { Fragment, useState, useEffect, useRef } = wp.element;
  const { InspectorControls, BlockControls, MediaUpload, MediaUploadCheck, useBlockProps } = wp.blockEditor;
  const { PanelBody, TextControl, TextareaControl, ToggleControl, SelectControl, RangeControl, Button, Modal, ToolbarGroup, ToolbarButton, Disabled, BaseControl } = wp.components;
  const ServerSideRender = wp.serverSideRender;
  const CONFIG = window.IHUB_BLOCKS || { types: {}, categories: [], settings: {} };

  const clone = (v) => JSON.parse(JSON.stringify(v === undefined ? null : v));
  const asT = (v) => (v && typeof v === 'object' ? { th: v.th || '', en: v.en || '' } : { th: String(v || ''), en: '' });
  const options = (list) => list.map(([value, label]) => ({ value: String(value), label: String(label) }));
  const strip = (html) => String(html || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();

  function HtmlModal({ title, value, onSave, onClose }) {
    const id = useRef('ihub-html-' + Math.random().toString(36).slice(2)).current;
    useEffect(() => {
      const timer = setTimeout(() => wp.oldEditor.initialize(id, { tinymce: { wpautop: true, height: 320, toolbar1: 'formatselect,bold,italic,underline,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,unlink,forecolor,removeformat,undo,redo' }, quicktags: true, mediaButtons: true }), 50);
      return () => { clearTimeout(timer); try { wp.oldEditor.remove(id); } catch (e) { /* already removed */ } };
    }, []);
    return h(Modal, { title, onRequestClose: onClose, className: 'ihub-html-modal', shouldCloseOnClickOutside: false },
      h('textarea', { id, defaultValue: value, rows: 14, className: 'widefat' }),
      h('div', { className: 'ihub-modal-actions' },
        h(Button, { variant: 'secondary', onClick: onClose }, 'ยกเลิก'),
        h(Button, { variant: 'primary', onClick: () => onSave(wp.oldEditor.getContent(id)) }, 'ใช้ข้อความนี้')));
  }

  function HtmlField({ label, value, onChange }) {
    const [editing, setEditing] = useState('');
    const v = asT(value);
    return h(BaseControl, { label, className: 'ihub-field' },
      ['th', 'en'].map((lang) => h('div', { key: lang, className: 'ihub-html-preview' },
        h('small', null, lang === 'th' ? 'ไทย' : 'English'),
        h('p', null, strip(v[lang]).slice(0, 120) || '— ว่าง —'),
        h(Button, { variant: 'secondary', size: 'small', onClick: () => setEditing(lang) }, lang === 'th' ? 'แก้ไขภาษาไทย' : 'Edit English'))),
      editing && h(HtmlModal, { title: `${label} (${editing === 'th' ? 'ไทย' : 'English'})`, value: v[editing], onClose: () => setEditing(''), onSave: (html) => { onChange(Object.assign({}, v, { [editing]: html })); setEditing(''); } }));
  }

  function ImageField({ label, value, onChange }) {
    return h(BaseControl, { label, className: 'ihub-field' },
      value && h('img', { src: value, alt: '', className: 'ihub-image-preview' }),
      h('div', { className: 'ihub-row' },
        h(MediaUploadCheck, null, h(MediaUpload, { allowedTypes: ['image'], onSelect: (media) => onChange(media.url), render: ({ open }) => h(Button, { variant: 'secondary', size: 'small', onClick: open }, value ? 'เปลี่ยนรูป' : 'เลือกรูป') })),
        value && h(Button, { variant: 'link', isDestructive: true, onClick: () => onChange('') }, 'นำออก')),
      h(TextControl, { value: value || '', placeholder: 'หรือวาง URL รูป', onChange, __nextHasNoMarginBottom: true }));
  }

  function Field({ field, value, onChange }) {
    const [key, kind, label, extra] = field;
    switch (kind) {
      case 't':
      case 'ta': {
        const v = asT(value);
        const Control = kind === 't' ? TextControl : TextareaControl;
        return h('div', { className: 'ihub-field ihub-bilingual' }, h('span', { className: 'ihub-label' }, label),
          h(Control, { label: 'ไทย', value: v.th, rows: 3, onChange: (th) => onChange({ th, en: v.en }) }),
          h(Control, { label: 'English', value: v.en, rows: 3, onChange: (en) => onChange({ th: v.th, en }) }));
      }
      case 'text': return h(TextControl, { label, value: value || '', onChange });
      case 'url': return h(TextControl, { label, value: value || '', onChange, help: 'เช่น /news, /contact, https://… หรือ tel:076…' });
      case 'bool': return h(ToggleControl, { label, checked: !!value, onChange });
      case 'select': return h(SelectControl, { label, value: String(value || ''), options: options(extra), onChange });
      case 'number': return h(RangeControl, { label, value: Number(value) || extra.min, min: extra.min, max: extra.max, onChange: (n) => onChange(Number(n)) });
      case 'category': return h(SelectControl, { label, value: value || '', options: [{ value: '', label: 'ทุกหมวด (มีแท็บ)' }].concat(options(CONFIG.categories)), onChange });
      case 'image': return h(ImageField, { label, value, onChange });
      case 'html': return h(HtmlField, { label, value, onChange });
      case 'list': return h(ListField, { label, value: Array.isArray(value) ? value : [], config: extra, onChange });
      default: return null;
    }
  }

  function ListField({ label, value, config, onChange }) {
    const set = (index, item) => onChange(value.map((v, i) => (i === index ? item : v)));
    const move = (index, step) => { const list = value.slice(); const [item] = list.splice(index, 1); list.splice(index + step, 0, item); onChange(list); };
    return h('div', { className: 'ihub-field ihub-list' }, h('span', { className: 'ihub-label' }, `${label} (${value.length})`),
      value.map((item, index) => {
        const title = item.title ? asT(item.title).th : item.text ? asT(item.text).th : item.label || (item.url ? 'รูป' : '');
        return h('details', { key: index, className: 'ihub-list-item' },
          h('summary', null, `${index + 1}. ${title || 'รายการ'}`),
          config.fields.map((sub) => h(Field, { key: sub[0], field: sub, value: item[sub[0]], onChange: (v) => set(index, Object.assign({}, item, { [sub[0]]: v })) })),
          h('div', { className: 'ihub-row' },
            h(Button, { size: 'small', variant: 'tertiary', disabled: index === 0, onClick: () => move(index, -1) }, '↑ ขึ้น'),
            h(Button, { size: 'small', variant: 'tertiary', disabled: index === value.length - 1, onClick: () => move(index, 1) }, '↓ ลง'),
            h(Button, { size: 'small', variant: 'tertiary', onClick: () => { const list = value.slice(); list.splice(index + 1, 0, clone(item)); onChange(list); } }, '⧉ สำเนา'),
            h(Button, { size: 'small', variant: 'link', isDestructive: true, onClick: () => onChange(value.filter((_, i) => i !== index)) }, 'ลบ')));
      }),
      value.length < config.max && h(Button, { variant: 'secondary', size: 'small', onClick: () => onChange(value.concat([clone(config.item)])) }, '＋ เพิ่ม'));
  }

  Object.keys(CONFIG.types).forEach((type) => {
    const def = CONFIG.types[type];
    registerBlockType('idevapp/' + def.slug, {
      edit: function Edit({ attributes, setAttributes, name }) {
        const [lang, setLang] = useState('th');
        const data = Object.assign(clone(def.data), attributes.data || {});
        const settings = Object.assign({}, CONFIG.settings[type], attributes.settings || {});
        const setData = (key, value) => setAttributes({ data: Object.assign({}, data, { [key]: value }) });
        const setSetting = (key, value) => setAttributes({ settings: Object.assign({}, settings, { [key]: value }) });
        const blockProps = useBlockProps({ className: 'ihub-block-edit' + (settings.hidden ? ' is-hidden-block' : '') });
        return h(Fragment, null,
          h(BlockControls, null, h(ToolbarGroup, null,
            h(ToolbarButton, { isPressed: lang === 'th', onClick: () => setLang('th') }, 'TH'),
            h(ToolbarButton, { isPressed: lang === 'en', onClick: () => setLang('en') }, 'EN'))),
          h(InspectorControls, null,
            h(PanelBody, { title: 'เนื้อหา', initialOpen: true }, def.fields.map((field) => h(Field, { key: field[0], field, value: data[field[0]], onChange: (v) => setData(field[0], v) }))),
            h(PanelBody, { title: 'การแสดงผล', initialOpen: false },
              type !== 'hero' && h(SelectControl, { label: 'พื้นหลัง', value: settings.background, options: options([['white', 'ขาว'], ['light', 'เทาอ่อน'], ['dark', 'เข้ม'], ['teal', 'เขียว']]), onChange: (v) => setSetting('background', v) }),
              type !== 'hero' && h(SelectControl, { label: 'ระยะห่างบน-ล่าง', value: settings.spacing, options: options([['none', 'ไม่มี'], ['small', 'น้อย'], ['normal', 'ปกติ'], ['large', 'มาก']]), onChange: (v) => setSetting('spacing', v) }),
              h(TextControl, { label: 'Anchor (ลิงก์ในหน้า #...)', value: settings.anchor || '', onChange: (v) => setSetting('anchor', v.replace(/[^\w-]/g, '')) }),
              h(ToggleControl, { label: 'ซ่อนส่วนนี้ชั่วคราว', checked: !!settings.hidden, onChange: (v) => setSetting('hidden', v) }))),
          h('div', blockProps,
            settings.hidden && h('div', { className: 'ihub-hidden-note' }, 'ส่วนนี้ถูกซ่อน (ผู้ชมไม่เห็น)'),
            h(Disabled, null, h(ServerSideRender, { block: name, attributes: { data, settings, align: attributes.align }, urlQueryArgs: { ihub_preview_lang: lang }, httpMethod: 'POST' }))));
      },
      save: () => null,
    });
  });
})(window.wp);
