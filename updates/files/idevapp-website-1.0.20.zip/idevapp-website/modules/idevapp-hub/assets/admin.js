/* Small admin helpers. */
jQuery(function ($) {
  $(document).on('click', '.ihub-confirm', function (e) { if (!window.confirm('ยืนยันการลบ?')) e.preventDefault(); });
});
