/* Reads text that OCR found on a passport (MRZ lines) or a Thai ID card. Pure functions: also used in tests. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.IHUBIdParse = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  const MONTHS_EN = { JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6, JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12 };
  const MONTHS_TH = { 'ม.ค.': 1, 'ก.พ.': 2, 'มี.ค.': 3, 'เม.ย.': 4, 'พ.ค.': 5, 'มิ.ย.': 6, 'ก.ค.': 7, 'ส.ค.': 8, 'ก.ย.': 9, 'ต.ค.': 10, 'พ.ย.': 11, 'ธ.ค.': 12 };
  const pad = (n) => String(n).padStart(2, '0');
  const iso = (y, m, d) => {
    const date = new Date(Date.UTC(y, m - 1, d));
    return date.getUTCFullYear() === y && date.getUTCMonth() === m - 1 && date.getUTCDate() === d ? `${y}-${pad(m)}-${pad(d)}` : '';
  };

  /* ---------- Passport (ICAO 9303 TD3: two lines of 44 characters) ---------- */
  const mrzValue = (c) => (c === '<' ? 0 : /\d/.test(c) ? Number(c) : c.charCodeAt(0) - 55);
  function checkDigit(text) {
    const weights = [7, 3, 1];
    let sum = 0;
    for (let i = 0; i < text.length; i++) sum += mrzValue(text[i]) * weights[i % 3];
    return String(sum % 10);
  }
  const toDigits = (s) => s.replace(/[OQDU]/g, '0').replace(/[IL|]/g, '1').replace(/Z/g, '2').replace(/S/g, '5').replace(/G/g, '6').replace(/B/g, '8').replace(/T/g, '7');
  const clean = (s) => s.toUpperCase().replace(/[«‹(\[{]/g, '<').replace(/\s+/g, '').replace(/[^A-Z0-9<]/g, '');

  function parseMrz(text) {
    const lines = String(text || '').split(/\r?\n/).map(clean).filter((l) => l.length >= 30);
    let l1 = '', l2 = '';
    for (let i = 0; i < lines.length - 1; i++) {
      if (/^P[A-Z<]/.test(lines[i]) && lines[i].includes('<<')) { l1 = lines[i]; l2 = lines[i + 1]; break; }
    }
    if (!l1) {
      // Second line alone: document number, nationality, birth date (with check digits)
      l2 = lines.find((l) => /^[A-Z0-9<]{9}\d[A-Z<]{3}\d{6}/.test(toDigits(l.slice(0, 9)) + l.slice(9))) || '';
      if (!l2) return null;
    }
    l1 = (l1 + '<'.repeat(44)).slice(0, 44);
    l2 = (l2 + '<'.repeat(44)).slice(0, 44);
    const docRaw = l2.slice(0, 9);
    const docCheck = toDigits(l2[9]);
    const nationality = l2.slice(10, 13).replace(/0/g, 'O').replace(/</g, '');
    const dobRaw = toDigits(l2.slice(13, 19));
    const dobCheck = toDigits(l2[19]);
    const sex = l2[20] === 'F' ? 'female' : l2[20] === 'M' ? 'male' : '';
    let doc = docRaw;
    if (checkDigit(doc) !== docCheck) { const alt = toDigits(docRaw); if (checkDigit(alt) === docCheck) doc = alt; }
    const yy = Number(dobRaw.slice(0, 2)), mm = Number(dobRaw.slice(2, 4)), dd = Number(dobRaw.slice(4, 6));
    const nowYY = new Date().getFullYear() % 100;
    const birthdate = /^\d{6}$/.test(dobRaw) ? iso(yy > nowYY ? 1900 + yy : 2000 + yy, mm, dd) : '';
    const names = l1.slice(5).replace(/<+$/, '').split('<<');
    const fix = (s) => (s || '').replace(/0/g, 'O').replace(/1/g, 'I').replace(/5/g, 'S').replace(/8/g, 'B').replace(/</g, ' ').replace(/[^A-Z ]/g, '').trim();
    const title = (s) => s.toLowerCase().replace(/\b[a-z]/g, (c) => c.toUpperCase());
    return {
      doc_type: 'passport',
      passport_no: doc.replace(/</g, ''),
      nationality,
      issuer: l1.slice(2, 5).replace(/</g, ''),
      birthdate,
      sex,
      last_name_en: title(fix(names[0])),
      first_name_en: title(fix(names.slice(1).join(' '))),
      checks: { document: checkDigit(doc) === docCheck, birthdate: checkDigit(dobRaw) === dobCheck },
    };
  }

  /* ---------- Thai national ID card (front side) ---------- */
  function validThaiId(cid) {
    if (!/^\d{13}$/.test(cid)) return false;
    let sum = 0;
    for (let i = 0; i < 12; i++) sum += Number(cid[i]) * (13 - i);
    return (11 - (sum % 11)) % 10 === Number(cid[12]);
  }
  const PREFIX_TH = ['เด็กชาย', 'เด็กหญิง', 'นางสาว', 'นาง', 'นาย', 'ด.ช.', 'ด.ญ.'];

  function parseThaiId(text) {
    const raw = String(text || '');
    const flat = raw.replace(/\r/g, '');
    const out = { doc_type: 'thai_id' };
    // 13-digit ID (often printed "1 2345 67890 12 3"); keep the first one with a valid checksum.
    const digitRuns = flat.replace(/[OoQD]/g, '0').replace(/[Il|]/g, '1').match(/\d[\d\s-]{11,24}\d/g) || [];
    for (const run of digitRuns) {
      const digits = run.replace(/\D/g, '');
      for (let i = 0; i + 13 <= digits.length; i++) { const c = digits.slice(i, i + 13); if (validThaiId(c)) { out.cid = c; break; } }
      if (out.cid) break;
    }
    const en = flat.match(/Name\s*[:.]?\s*(Mr|Mrs|Miss|Ms|Master)\.?[ \t]+([A-Za-z][A-Za-z-]+(?:[ \t][A-Za-z][A-Za-z-]+)?)/i);
    if (en) { out.prefix_en = en[1]; out.first_name_en = en[2].trim(); }
    const last = flat.match(/Last\s*name\s*[:.]?\s*([A-Za-z][A-Za-z-]+)/i);
    if (last) out.last_name_en = last[1];
    const thLine = flat.split('\n').find((l) => /ชื่อตัวและชื่อสกุล|ชื่อ-?สกุล/.test(l)) || flat.split('\n').find((l) => PREFIX_TH.some((p) => l.trim().startsWith(p))) || '';
    if (thLine) {
      const rest = thLine.replace(/.*(ชื่อตัวและชื่อสกุล|ชื่อ-?สกุล)\s*/, '').trim();
      const prefix = PREFIX_TH.find((p) => rest.startsWith(p));
      const words = (prefix ? rest.slice(prefix.length) : rest).trim().split(/\s+/).filter((w) => /^[฀-๿]+$/.test(w));
      if (prefix) out.prefix = prefix.replace('ด.ช.', 'เด็กชาย').replace('ด.ญ.', 'เด็กหญิง');
      if (words.length >= 2) { out.first_name = words[0]; out.last_name = words.slice(1).join(' '); }
    }
    const dobEn = flat.match(/Date\s*of\s*Birth\s*[:.]?\s*(\d{1,2})\s*([A-Za-z]{3})[a-z]*\.?\s*(\d{4})/i);
    const dobTh = flat.match(/เกิดวันที่\s*(\d{1,2})\s*([฀-๿.]+?)\s*(\d{4})/);
    if (dobEn && MONTHS_EN[dobEn[2].toUpperCase()]) out.birthdate = iso(Number(dobEn[3]), MONTHS_EN[dobEn[2].toUpperCase()], Number(dobEn[1]));
    else if (dobTh) {
      const month = MONTHS_TH[dobTh[2]] || MONTHS_TH[dobTh[2].replace(/\.?$/, '.')];
      if (month) out.birthdate = iso(Number(dobTh[3]) - 543, month, Number(dobTh[1]));
    }
    const prefix = out.prefix || out.prefix_en || '';
    if (/^(นาย|เด็กชาย|Master|Mr(?!s))/i.test(prefix)) out.sex = 'male';
    else if (/^(นาง|นางสาว|เด็กหญิง|Mrs|Miss|Ms)/i.test(prefix)) out.sex = 'female';
    const addr = flat.match(/ที่อยู่\s*(.+(?:\n(?!.*(?:วันออกบัตร|Date of Issue|วันบัตรหมดอายุ)).+)?)/);
    if (addr) out.address = addr[1].replace(/\s*\n\s*/g, ' ').trim();
    return out;
  }

  return { parseMrz, parseThaiId, validThaiId, checkDigit };
});
