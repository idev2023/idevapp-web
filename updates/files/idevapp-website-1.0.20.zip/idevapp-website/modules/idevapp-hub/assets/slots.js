/* Clinic times editor for one doctor/clinic. State is kept in JS and written to the hidden input as JSON. */
(function () {
  const root = document.getElementById('ihub-slots');
  const input = document.getElementById('ihub-slots-input');
  if (!root || !input) return;
  const parse = (value) => { try { const v = JSON.parse(value || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } };
  let slots = parse(root.dataset.slots);
  let templates = parse(root.dataset.templates);
  const sources = parse(root.dataset.sources);
  let message = '';
  const open = new Set();

  const RECURRENCES = [['weekly', 'ทุกสัปดาห์'], ['monthly_week', 'ทุกเดือน (เลือกสัปดาห์ที่)'], ['monthly_day', 'ทุกเดือน (เลือกวันที่)'], ['yearly', 'ทุกปี (วันและเดือน)'], ['date', 'เฉพาะวันที่']];
  const DAYS = ['จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์', 'อาทิตย์'];
  const MONTHS = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
  const WEEKS = [[1, 'สัปดาห์ที่ 1'], [2, 'สัปดาห์ที่ 2'], [3, 'สัปดาห์ที่ 3'], [4, 'สัปดาห์ที่ 4'], [5, 'สัปดาห์สุดท้าย']];
  const WEEK_TH = ['', 'ที่ 1', 'ที่ 2', 'ที่ 3', 'ที่ 4', 'สุดท้าย'];
  const today = () => new Date().toISOString().slice(0, 10);
  const empty = (patch) => Object.assign({ recurrence: 'weekly', weekday: 1, week_of_month: null, day_of_month: null, month_of_year: null, on_date: null, valid_from: null, valid_until: null, start_time: '09:00', end_time: '16:00', note: '', note_en: '' }, patch || {});
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const day = (value) => { if (!value) return ''; const [y, m, d] = value.split('-').map(Number); return `${d} ${MONTHS[m - 1]} ${y + 543}`; };

  function valid(s) {
    const time = /^([01]\d|2[0-3]):[0-5]\d$/;
    if (!time.test(s.start_time || '') || !time.test(s.end_time || '') || s.end_time <= s.start_time) return false;
    if ((s.recurrence === 'weekly' || s.recurrence === 'monthly_week') && !s.weekday) return false;
    if (s.recurrence === 'monthly_week' && !s.week_of_month) return false;
    if ((s.recurrence === 'monthly_day' || s.recurrence === 'yearly') && !s.day_of_month) return false;
    if (s.recurrence === 'yearly' && !s.month_of_year) return false;
    if (s.recurrence === 'date' && !s.on_date) return false;
    if (s.valid_from && s.valid_until && s.valid_until < s.valid_from) return false;
    return true;
  }
  function describe(s) {
    const d = s.weekday ? DAYS[s.weekday - 1] : '';
    const rules = {
      weekly: `ทุกวัน${d}`, monthly_week: `${d}${WEEK_TH[s.week_of_month || 1]} ของเดือน`, monthly_day: `ทุกวันที่ ${s.day_of_month} ของเดือน`,
      yearly: `ทุกปี วันที่ ${s.day_of_month} ${MONTHS[(s.month_of_year || 1) - 1]}`, date: day(s.on_date)
    };
    const range = s.valid_from || s.valid_until ? ` (${s.valid_from ? day(s.valid_from) : '…'} – ${s.valid_until ? day(s.valid_until) : '…'})` : '';
    return `${rules[s.recurrence] || ''} ${s.start_time}–${s.end_time}${range}`;
  }
  const options = (list, current) => list.map(([v, l]) => `<option value="${v}"${String(v) === String(current) ? ' selected' : ''}>${esc(l)}</option>`).join('');

  function render() {
    input.value = JSON.stringify(slots);
    const rows = slots.map((s, i) => {
      const bad = !valid(s);
      const more = open.has(i) || s.valid_from || s.valid_until || s.note || s.note_en;
      let fields = `<label>รูปแบบ<select data-i="${i}" data-k="recurrence">${options(RECURRENCES, s.recurrence)}</select></label>`;
      if (s.recurrence === 'weekly' || s.recurrence === 'monthly_week') fields += `<label>วัน<select data-i="${i}" data-k="weekday" data-num>${options(DAYS.map((d, n) => [n + 1, d]), s.weekday || 1)}</select></label>`;
      if (s.recurrence === 'monthly_week') fields += `<label>สัปดาห์<select data-i="${i}" data-k="week_of_month" data-num>${options(WEEKS, s.week_of_month || 1)}</select></label>`;
      if (s.recurrence === 'monthly_day' || s.recurrence === 'yearly') fields += `<label>วันที่<select data-i="${i}" data-k="day_of_month" data-num>${options(Array.from({ length: 31 }, (_, n) => [n + 1, n + 1]), s.day_of_month || 1)}</select></label>`;
      if (s.recurrence === 'yearly') fields += `<label>เดือน<select data-i="${i}" data-k="month_of_year" data-num>${options(MONTHS.map((m, n) => [n + 1, m]), s.month_of_year || 1)}</select></label>`;
      if (s.recurrence === 'date') fields += `<label>วันที่<input type="date" data-i="${i}" data-k="on_date" value="${esc(s.on_date || '')}"></label>`;
      fields += `<label>เริ่ม<input type="time" data-i="${i}" data-k="start_time" value="${esc(s.start_time)}"></label><label>ถึง<input type="time" data-i="${i}" data-k="end_time" value="${esc(s.end_time)}"></label>`;
      return `<div class="ihub-slot${bad ? ' is-invalid' : ''}">
        <div class="ihub-slot-head"><strong>${i + 1}. ${bad ? 'ตรวจสอบข้อมูลให้ครบ' : esc(describe(s))}</strong><span><button type="button" class="button-link" data-act="copy" data-i="${i}" title="ทำสำเนาแถวนี้">⧉ สำเนา</button> <button type="button" class="button-link-delete" data-act="remove" data-i="${i}">ลบ</button></span></div>
        <div class="ihub-slot-grid">${fields}</div>
        <details class="ihub-slot-more" data-i="${i}"${more ? ' open' : ''}><summary>ช่วงวันที่มีผล / หมายเหตุ</summary><div class="ihub-slot-grid">
          <label>มีผลตั้งแต่<input type="date" data-i="${i}" data-k="valid_from" value="${esc(s.valid_from || '')}"></label>
          <label>ถึงวันที่<input type="date" data-i="${i}" data-k="valid_until" value="${esc(s.valid_until || '')}"></label>
          <label class="ihub-slot-wide">หมายเหตุ<input data-i="${i}" data-k="note" maxlength="120" placeholder="เช่น รับนัดล่วงหน้า" value="${esc(s.note)}"></label>
          <label class="ihub-slot-wide">Note (English)<input data-i="${i}" data-k="note_en" maxlength="120" value="${esc(s.note_en)}"></label>
        </div><small class="description">เช่น ตารางเฉพาะปี 2570 ให้ใส่ 1 ม.ค. 2570 – 31 ธ.ค. 2570 · เว้นว่าง = มีผลตลอด</small></details>
      </div>`;
    }).join('');
    const withSlots = sources.filter((s) => s.slots && s.slots.length);
    root.innerHTML = `${slots.length ? '' : '<p class="ihub-empty">ยังไม่มีเวลาออกตรวจ กดปุ่มด้านล่างเพื่อเพิ่ม หรือใช้ template</p>'}${rows}
      <div class="ihub-slot-add">
        <button type="button" class="button" data-add="one">＋ เพิ่มเวลา</button>
        <button type="button" class="button" data-add="weekdays">＋ จันทร์–ศุกร์</button>
        <button type="button" class="button" data-add="weekend">＋ เสาร์–อาทิตย์</button>
        <button type="button" class="button" data-add="monthly">＋ รายเดือน</button>
        <button type="button" class="button" data-add="date">＋ เฉพาะวัน</button>
      </div>
      <div class="ihub-slot-tools">
        <label>ใช้ template<select data-pick="template"><option value="">— เลือก template —</option>${templates.map((t) => `<option value="${esc(t.id)}">${esc(t.name)} (${t.slots.length} ช่วง)</option>`).join('')}</select></label>
        <label>คัดลอกเวลาจาก<select data-pick="source"><option value="">— เลือกแพทย์/คลินิก —</option>${withSlots.map((s) => `<option value="${esc(s.id)}">${esc(s.name)} (${s.slots.length} ช่วง)</option>`).join('')}</select></label>
        <button type="button" class="button" data-act="save-template"${slots.length ? '' : ' disabled'}>💾 บันทึกเป็น template</button>
      </div>
      ${templates.length ? `<details class="ihub-slot-more"><summary>จัดการ template (${templates.length})</summary><ul class="ihub-templates">${templates.map((t) => `<li><span>${esc(t.name)}<small>${esc(t.slots.map(describe).join(' · '))}</small></span><button type="button" class="button-link-delete" data-act="delete-template" data-id="${esc(t.id)}">ลบ</button></li>`).join('')}</ul></details>` : ''}
      ${slots.some((s) => !valid(s)) ? '<p class="ihub-error">มีบางแถวไม่ครบ (เวลาสิ้นสุดต้องหลังเวลาเริ่ม และต้องเลือกวัน/วันที่) แถวที่ไม่ครบจะไม่ถูกบันทึก</p>' : ''}
      ${message ? `<p class="ihub-message">${esc(message)}</p>` : ''}`;
  }

  function apply(list, label) {
    if (!list || !list.length) return;
    const replace = slots.length > 0 && window.confirm(`ใช้เวลาจาก “${label}”\n\nกด OK = แทนที่เวลาที่มีอยู่ทั้งหมด\nกด Cancel = เพิ่มต่อท้าย`);
    slots = (replace ? [] : slots).concat(list.map((s) => empty(s)));
    message = `นำเวลาจาก “${label}” มาใช้แล้ว อย่าลืมกดอัปเดต/เผยแพร่`;
    render();
  }

  function changeRecurrence(i, recurrence) {
    const s = slots[i];
    s.recurrence = recurrence;
    if (recurrence === 'monthly_week') { s.weekday = s.weekday || 1; s.week_of_month = s.week_of_month || 1; }
    if (recurrence === 'monthly_day' || recurrence === 'yearly') { s.day_of_month = s.day_of_month || 1; s.month_of_year = recurrence === 'yearly' ? s.month_of_year || 1 : null; }
    if (recurrence === 'date') s.on_date = s.on_date || today();
    if (recurrence === 'weekly') s.weekday = s.weekday || 1;
  }

  async function ajax(data) {
    const body = new URLSearchParams(Object.assign({ action: 'ihub_template', nonce: window.IHUB_SLOTS.nonce }, data));
    const response = await fetch(window.IHUB_SLOTS.ajax, { method: 'POST', credentials: 'same-origin', body });
    return response.json();
  }

  root.addEventListener('change', (event) => {
    const el = event.target;
    if (el.dataset.pick) {
      const list = el.dataset.pick === 'template' ? templates : sources;
      const found = list.find((item) => String(item.id) === el.value);
      if (found) apply(found.slots, found.name);
      return;
    }
    if (el.dataset.i === undefined || !el.dataset.k) return;
    const i = Number(el.dataset.i);
    if (el.dataset.k === 'recurrence') changeRecurrence(i, el.value);
    else slots[i][el.dataset.k] = el.hasAttribute('data-num') ? Number(el.value) : (el.value || (['note', 'note_en', 'start_time', 'end_time'].includes(el.dataset.k) ? '' : null));
    render();
  });
  root.addEventListener('input', (event) => {
    const el = event.target;
    if (el.dataset.i === undefined || !['note', 'note_en'].includes(el.dataset.k)) return;
    slots[Number(el.dataset.i)][el.dataset.k] = el.value;
    input.value = JSON.stringify(slots);
  });
  root.addEventListener('toggle', (event) => {
    const el = event.target;
    if (el.tagName === 'DETAILS' && el.dataset.i !== undefined) { if (el.open) open.add(Number(el.dataset.i)); else open.delete(Number(el.dataset.i)); }
  }, true);
  root.addEventListener('click', async (event) => {
    const el = event.target.closest('button');
    if (!el) return;
    event.preventDefault();
    const add = el.dataset.add;
    if (add === 'one') slots.push(empty());
    if (add === 'weekdays') [1, 2, 3, 4, 5].forEach((weekday) => slots.push(empty({ weekday })));
    if (add === 'weekend') [6, 7].forEach((weekday) => slots.push(empty({ weekday, start_time: '09:00', end_time: '12:00' })));
    if (add === 'monthly') slots.push(empty({ recurrence: 'monthly_week', weekday: 3, week_of_month: 1 }));
    if (add === 'date') slots.push(empty({ recurrence: 'date', on_date: today() }));
    const i = Number(el.dataset.i);
    if (el.dataset.act === 'copy') slots.splice(i + 1, 0, Object.assign({}, slots[i]));
    if (el.dataset.act === 'remove') slots.splice(i, 1);
    if (el.dataset.act === 'save-template') {
      const name = window.prompt('ตั้งชื่อ template เช่น “อายุรกรรม จ-ศ เช้า”');
      if (!name) return;
      const result = await ajax({ do: 'save', name, slots: JSON.stringify(slots) });
      if (result.success) { templates = result.data; message = `บันทึก template “${name}” แล้ว`; } else message = result.data || 'บันทึกไม่สำเร็จ';
    }
    if (el.dataset.act === 'delete-template') {
      if (!window.confirm('ลบ template นี้?')) return;
      const result = await ajax({ do: 'delete', id: el.dataset.id });
      if (result.success) templates = result.data;
    }
    render();
  });
  render();
})();
