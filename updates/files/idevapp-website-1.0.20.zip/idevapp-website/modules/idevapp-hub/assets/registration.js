/* New patient registration: steps, ID photo (resized on the device), on-device OCR (Tesseract.js), GPS, review, submit. */
(function () {
  const root = document.querySelector('[data-ihub-reg]');
  if (!root) return;
  const config = JSON.parse(root.dataset.ahReg);
  const t = config.t;
  const form = root.querySelector('.ihub-reg-form');
  const steps = Array.from(root.querySelectorAll('.ihub-reg-step'));
  const marks = Array.from(root.querySelectorAll('.ihub-reg-steps li'));
  const btnBack = root.querySelector('[data-ihub-back]');
  const btnNext = root.querySelector('[data-ihub-next]');
  const btnSubmit = root.querySelector('[data-ihub-submit]');
  const fileInput = root.querySelector('#ihub-reg-file');
  const preview = root.querySelector('.ihub-reg-preview');
  const ocrBox = root.querySelector('.ihub-reg-ocr');
  const ocrText = root.querySelector('.ihub-reg-ocr-text');
  const ocrBar = root.querySelector('.ihub-reg-bar i');
  let step = 0;
  let photo = null; // Blob (JPEG, resized)
  let ocrRun = 0;
  const $ = (name) => form.elements[name];
  const val = (name) => { const el = $(name); if (!el) return ''; if (el instanceof RadioNodeList) return el.value; return el.type === 'checkbox' ? (el.checked ? '1' : '') : el.value.trim(); };
  const docType = () => val('doc_type') || 'thai_id';

  function validThaiId(cid) { return window.IHUBIdParse.validThaiId(cid); }

  function setError(name, message) {
    const box = root.querySelector(`[data-field="${name}"] .ihub-reg-error`) || root.querySelector(`[data-error="${name}"]`);
    if (!box) return;
    box.textContent = message || '';
    box.hidden = !message;
    const wrap = root.querySelector(`[data-field="${name}"]`);
    if (wrap) wrap.classList.toggle('has-error', !!message);
  }
  function clearErrors() { root.querySelectorAll('.ihub-reg-error').forEach((e) => { e.hidden = true; e.textContent = ''; }); root.querySelectorAll('.has-error').forEach((e) => e.classList.remove('has-error')); }

  function validate(index) {
    clearErrors();
    const missing = [];
    const need = (name) => { if (!val(name)) { setError(name, t.required); missing.push(name); } };
    if (index === 0 && !val('consent_pdpa')) { setError('consent', t.consentRequired); return false; }
    if (index === 1 && !photo) { setError('photo', t.photoRequired); return false; }
    if (index === 2) {
      if (docType() === 'thai_id') {
        const cid = val('cid').replace(/\D/g, '');
        if (!cid) need('cid'); else if (!validThaiId(cid)) { setError('cid', t.invalidCid); missing.push('cid'); }
      } else { need('passport_no'); need('nationality'); }
      ['first_name', 'last_name', 'sex', 'birthdate'].forEach(need);
    }
    if (index === 3) {
      ['phone', 'email', 'address'].forEach(need);
      if (val('email') && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val('email'))) { setError('email', t.required); missing.push('email'); }
    }
    if (missing.length) { const el = root.querySelector(`[data-field="${missing[0]}"] input, [data-field="${missing[0]}"] textarea`); if (el) el.focus(); }
    return !missing.length;
  }

  function show(index, scroll = true) {
    step = index;
    steps.forEach((s, i) => { s.hidden = i !== index; s.classList.toggle('is-active', i === index); });
    marks.forEach((m, i) => { m.classList.toggle('active', i === index); m.classList.toggle('done', i < index); });
    btnBack.hidden = index === 0;
    btnNext.hidden = index === steps.length - 1;
    btnSubmit.hidden = index !== steps.length - 1;
    root.querySelectorAll('.ihub-reg-doc').forEach((el) => { el.hidden = !el.classList.contains('ihub-reg-doc-' + docType()); });
    if (index === steps.length - 1) renderReview();
    if (scroll) root.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function renderReview() {
    const rows = [];
    const add = (label, value) => { if (value) rows.push(`<dt>${esc(label)}</dt><dd>${esc(value)}</dd>`); };
    add(t.docType, docType() === 'thai_id' ? t.thaiId : t.passport);
    if (docType() === 'thai_id') add(t.cid, val('cid')); else { add(t.passportNo, val('passport_no')); add(t.nationality, val('nationality')); }
    add(t.firstName, [val('prefix'), val('first_name'), val('last_name')].filter(Boolean).join(' '));
    add(t.firstNameEn, [val('first_name_en'), val('last_name_en')].filter(Boolean).join(' '));
    add(t.sex, val('sex') === 'male' ? t.male : val('sex') === 'female' ? t.female : '');
    add(t.birthdate, val('birthdate') ? new Date(val('birthdate') + 'T00:00:00Z').toLocaleDateString(config.lang === 'en' ? 'en-GB' : 'th-TH', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }) : '');
    add(t.phone, val('phone')); add(t.email, val('email')); add(t.address, val('address'));
    if (val('lat')) add(t.location, `${val('lat')}, ${val('lng')}`);
    add(t.allergy, val('drug_allergy')); add(t.emergencyName, [val('emergency_name'), val('emergency_phone')].filter(Boolean).join(' · '));
    root.querySelector('.ihub-reg-review').innerHTML = rows.join('') + (preview.src ? `<dt>${esc(t.photo)}</dt><dd><img src="${preview.src}" alt=""></dd>` : '');
  }
  const esc = (s) => String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  btnNext.addEventListener('click', () => { if (validate(step)) show(step + 1); });
  btnBack.addEventListener('click', () => show(step - 1));
  form.addEventListener('change', (e) => { if (e.target.name === 'doc_type') { show(step, false); if (photo) runOcr(); } });
  form.addEventListener('input', (e) => { if (e.target.name === 'cid') e.target.value = e.target.value.replace(/[^\d\s-]/g, ''); if (['passport_no', 'nationality'].includes(e.target.name)) e.target.value = e.target.value.toUpperCase(); });

  /* ---------- Photo: resize on the device (also removes EXIF / location) ---------- */
  fileInput.addEventListener('change', async () => {
    const file = fileInput.files && fileInput.files[0];
    if (!file) return;
    try {
      const bitmap = await loadImage(file);
      const scale = Math.min(1, 1800 / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(bitmap.width * scale); canvas.height = Math.round(bitmap.height * scale);
      canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      photo = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.88));
      preview.src = canvas.toDataURL('image/jpeg', 0.7);
      preview.hidden = false;
      root.querySelector('.ihub-reg-shoot').innerHTML = '📷 ' + esc(t.retake);
      setError('photo', '');
      runOcr(canvas);
    } catch (e) { setError('photo', t.photoRequired); }
  });
  function loadImage(file) {
    if (window.createImageBitmap) return createImageBitmap(file, { imageOrientation: 'from-image' }).catch(() => fallback());
    return fallback();
    function fallback() { return new Promise((resolve, reject) => { const img = new Image(); img.onload = () => resolve(img); img.onerror = reject; img.src = URL.createObjectURL(file); }); }
  }

  /* ---------- OCR on the device ---------- */
  let tesseractLoading = null;
  function loadTesseract() {
    if (window.Tesseract) return Promise.resolve(window.Tesseract);
    if (!tesseractLoading) tesseractLoading = new Promise((resolve, reject) => { const s = document.createElement('script'); s.src = config.tesseract; s.async = true; s.onload = () => resolve(window.Tesseract); s.onerror = reject; document.head.appendChild(s); });
    return tesseractLoading;
  }
  function ocrStatus(text, progress) { ocrBox.hidden = false; ocrText.textContent = text; ocrBar.style.width = Math.round((progress || 0) * 100) + '%'; ocrBox.classList.toggle('is-busy', progress !== null && progress < 1); }

  async function runOcr(canvas) {
    if (!config.ocr) return;
    const run = ++ocrRun;
    const source = canvas || preview;
    const type = docType();
    ocrStatus(t.reading, 0.05);
    try {
      const Tesseract = await loadTesseract();
      const image = type === 'passport' ? cropBottom(source, 0.38) : grayscale(source);
      const result = await Tesseract.recognize(image, type === 'passport' ? 'eng' : 'tha+eng', { logger: (m) => { if (run === ocrRun && m.status === 'recognizing text') ocrStatus(t.reading, 0.1 + m.progress * 0.8); } });
      if (run !== ocrRun) return;
      const text = result.data.text || '';
      const data = type === 'passport' ? window.IHUBIdParse.parseMrz(text) : window.IHUBIdParse.parseThaiId(text);
      if (type !== 'passport' && data) await rereadName(Tesseract, image, result.data.lines || [], data);
      if (run !== ocrRun) return;
      const filled = fill(data || {});
      ocrStatus(filled >= 4 ? t.readOk : filled > 0 ? t.readPartial : t.readFail, null);
    } catch (e) {
      if (run === ocrRun) ocrStatus(t.readFail, null);
    }
  }
  /** The Thai name line again, alone and enlarged with room above and below: on a whole-card reading the
      small vowels and tone marks above / below the letters are often dropped. Keeps the reading with more marks. */
  async function rereadName(Tesseract, card, lines, data) {
    const marks = (s) => (String(s || '').match(/[\u0E31\u0E34-\u0E3A\u0E47-\u0E4E]/g) || []).length;
    const line = lines.find((l) => /ชื่อตัว|ชื่อ\s*-?\s*สกุล/.test(l.text || '')) || lines.find((l) => /^\s*(นาย|นางสาว|นาง|เด็กชาย|เด็กหญิง)/.test(l.text || ''));
    if (!line || !line.bbox) return;
    const b = line.bbox, lh = Math.max(8, b.y1 - b.y0);
    const x0 = Math.max(0, b.x0 - lh), y0 = Math.max(0, b.y0 - lh * 0.8);
    const w = Math.min(card.width, b.x1 + lh * 4) - x0, h = Math.min(card.height, b.y1 + lh * 0.8) - y0;
    const scale = Math.max(1, 2400 / w);
    const c = document.createElement('canvas'); c.width = Math.round(w * scale); c.height = Math.round(h * scale);
    const ctx = c.getContext('2d'); ctx.imageSmoothingQuality = 'high'; ctx.drawImage(card, x0, y0, w, h, 0, 0, c.width, c.height);
    try {
      const r = await Tesseract.recognize(c, 'tha');
      const n = window.IHUBIdParse.parseThaiId(r.data.text || '');
      if (n.first_name && n.last_name && (!data.first_name || marks(n.first_name + n.last_name) > marks(data.first_name + (data.last_name || '')))) {
        data.first_name = n.first_name; data.last_name = n.last_name; if (n.prefix && !data.prefix) data.prefix = n.prefix;
      }
    } catch (e) { /* keep the first reading */ }
  }
  function cropBottom(source, part) {
    const w = source.naturalWidth || source.width, h = source.naturalHeight || source.height;
    const c = document.createElement('canvas');
    c.width = w; c.height = Math.round(h * part);
    c.getContext('2d').drawImage(source, 0, h - c.height, w, c.height, 0, 0, w, c.height);
    return grayscale(c);
  }
  function grayscale(source) {
    const w = source.naturalWidth || source.width, h = source.naturalHeight || source.height;
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const ctx = c.getContext('2d');
    ctx.drawImage(source, 0, 0, w, h);
    const img = ctx.getImageData(0, 0, w, h);
    for (let i = 0; i < img.data.length; i += 4) {
      const g = 0.299 * img.data[i] + 0.587 * img.data[i + 1] + 0.114 * img.data[i + 2];
      const v = Math.max(0, Math.min(255, (g - 128) * 1.4 + 128));
      img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
    }
    ctx.putImageData(img, 0, 0);
    return c;
  }
  /** Puts what OCR found into empty fields (never overwrites what the person typed). Returns how many were filled. */
  function fill(data) {
    let count = 0;
    const set = (name, value) => {
      if (!value) return;
      const el = $(name);
      if (!el) return;
      if (el instanceof RadioNodeList) { if (!el.value) { el.value = value; count++; } return; }
      if (!el.value.trim()) { el.value = value; count++; }
    };
    if (data.doc_type === 'passport') {
      set('passport_no', data.passport_no); set('nationality', data.nationality);
      set('first_name', data.first_name_en); set('last_name', data.last_name_en);
      set('first_name_en', data.first_name_en); set('last_name_en', data.last_name_en);
      if (data.sex) set('prefix', data.sex === 'male' ? 'Mr' : 'Ms');
    } else {
      set('cid', data.cid); set('prefix', data.prefix || data.prefix_en);
      set('first_name', data.first_name); set('last_name', data.last_name);
      set('first_name_en', data.first_name_en); set('last_name_en', data.last_name_en);
      set('address', data.address);
    }
    set('birthdate', data.birthdate); set('sex', data.sex);
    return count;
  }

  /* ---------- GPS ---------- */
  const gpsStatus = root.querySelector('.ihub-reg-gps-status');
  root.querySelector('[data-ihub-gps]').addEventListener('click', () => {
    if (!navigator.geolocation) { gpsStatus.textContent = t.gpsFail; return; }
    gpsStatus.textContent = '…';
    navigator.geolocation.getCurrentPosition((pos) => {
      $('lat').value = pos.coords.latitude.toFixed(6);
      $('lng').value = pos.coords.longitude.toFixed(6);
      gpsStatus.innerHTML = `✓ ${esc(t.gpsOk)} <a href="https://www.google.com/maps?q=${$('lat').value},${$('lng').value}" target="_blank" rel="noopener">${$('lat').value}, ${$('lng').value} ↗</a> · <button type="button" class="link-like" data-ihub-gps-clear>${esc(t.gpsClear)}</button>`;
    }, () => { gpsStatus.textContent = t.gpsFail; }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 });
  });
  root.addEventListener('click', (e) => { if (e.target.closest('[data-ihub-gps-clear]')) { $('lat').value = ''; $('lng').value = ''; gpsStatus.textContent = ''; } });

  /* ---------- Submit ---------- */
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    for (let i = 0; i < steps.length - 1; i++) if (!validate(i)) { show(i); validate(i); return; }
    const body = new FormData(form);
    body.set('cid', val('cid').replace(/\D/g, ''));
    body.set('photo', photo, 'document.jpg');
    btnSubmit.disabled = true;
    btnSubmit.textContent = t.sending;
    try {
      const response = await fetch(config.rest, { method: 'POST', body, credentials: 'same-origin' });
      const json = await response.json().catch(() => ({}));
      if (response.ok && json.ok) {
        form.hidden = true;
        root.querySelector('.ihub-reg-steps').hidden = true;
        root.querySelector('.ihub-reg-done-text').textContent = t.doneText.replace('{ref}', json.ref).replace('{email}', val('email'));
        root.querySelector('.ihub-reg-done').hidden = false;
        root.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      const errors = json.errors || { form: t.errorGeneric };
      const order = [['consent', 0], ['photo', 1], ['cid', 2], ['passport_no', 2], ['nationality', 2], ['first_name', 2], ['last_name', 2], ['sex', 2], ['birthdate', 2], ['phone', 3], ['email', 3], ['address', 3]];
      const first = order.find(([name]) => errors[name]);
      if (first) { show(first[1]); }
      Object.keys(errors).forEach((name) => setError(name, errors[name]));
      if (!first) setError('form', errors.form || t.errorGeneric);
    } catch (err) {
      setError('form', t.errorGeneric);
    } finally {
      btnSubmit.disabled = false;
      btnSubmit.textContent = t.submit;
    }
  });

  show(0, false);
})();
