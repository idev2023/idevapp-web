/* Front end: important popups (one at a time, dismissed for 8 hours) and the home page news tabs. */
(function () {
  // News tabs
  document.querySelectorAll('[data-ihub-tabs]').forEach((tabs) => {
    const scope = tabs.parentElement;
    tabs.addEventListener('click', (event) => {
      const button = event.target.closest('button[data-tab]');
      if (!button) return;
      tabs.querySelectorAll('button').forEach((b) => { const on = b === button; b.classList.toggle('active', on); b.setAttribute('aria-selected', on ? 'true' : 'false'); });
      scope.querySelectorAll(':scope > .news-panel').forEach((panel) => { panel.hidden = panel.dataset.panel !== button.dataset.tab; });
    });
  });

  // Popups
  const source = document.getElementById('ihub-popups');
  if (!source) return;
  let config;
  try { config = JSON.parse(source.textContent); } catch (e) { return; }
  const KEY = 'idevapphub-popups-dismissed';
  const HIDE = 8 * 60 * 60 * 1000;
  const signature = (p) => `${p.id}|${p.title}|${p.body}|${p.imageUrl}`.slice(0, 300);
  const read = () => { try { const v = JSON.parse(localStorage.getItem(KEY) || '{}'); return v && typeof v === 'object' ? v : {}; } catch (e) { return {}; } };
  const dismissed = read();
  let queue = config.items.filter((p) => Date.now() - Number(dismissed[signature(p)] || 0) > HIDE);
  const esc = (s) => String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let backdrop = null;

  function close() {
    const current = queue[0];
    if (!current) return;
    const store = read();
    store[signature(current)] = Date.now();
    Object.keys(store).forEach((k) => { if (Date.now() - Number(store[k]) > HIDE) delete store[k]; });
    try { localStorage.setItem(KEY, JSON.stringify(store)); } catch (e) { /* storage unavailable */ }
    queue = queue.slice(1);
    render();
  }
  function render() {
    if (backdrop) backdrop.remove();
    backdrop = null;
    const p = queue[0];
    if (!p) { document.removeEventListener('keydown', onKey); return; }
    const remaining = queue.length - 1;
    backdrop = document.createElement('div');
    backdrop.className = 'popup-backdrop';
    backdrop.setAttribute('role', 'presentation');
    backdrop.innerHTML = `<section class="important-popup" role="dialog" aria-modal="true" aria-labelledby="important-popup-title">
      <button class="popup-close" aria-label="${esc(config.close)}">×</button>
      ${p.imageUrl ? `<img class="popup-image" src="${esc(p.imageUrl)}" alt="">` : ''}
      <div class="popup-content"><span class="section-kicker">${esc(config.kicker)}${queue.length > 1 ? ` · 1/${queue.length}` : ''}</span>
      ${p.title ? `<h2 id="important-popup-title">${esc(p.title)}</h2>` : ''}${p.body ? `<p>${esc(p.body)}</p>` : ''}
      <div class="popup-actions">${p.linkUrl && p.linkText ? `<a class="button button-teal" href="${esc(p.linkUrl)}">${esc(p.linkText)}</a>` : ''}${remaining > 0 ? `<button type="button" class="button button-white popup-next">${esc(config.next)} (${remaining}) →</button>` : ''}</div></div></section>`;
    backdrop.addEventListener('mousedown', (e) => { if (e.target === backdrop) close(); });
    backdrop.querySelector('.popup-close').addEventListener('click', close);
    const next = backdrop.querySelector('.popup-next');
    if (next) next.addEventListener('click', close);
    document.body.appendChild(backdrop);
    backdrop.querySelector('.popup-close').focus();
  }
  function onKey(e) { if (e.key === 'Escape') close(); }
  if (queue.length) { document.addEventListener('keydown', onKey); render(); }
})();

/* 1.1: text size, back to top, cookie consent, sliders, counters. */
(function () {
  const store = {
    get(key) { try { return localStorage.getItem(key); } catch (e) { return null; } },
    set(key, value) { try { localStorage.setItem(key, value); } catch (e) { /* storage unavailable */ } },
  };
  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Text size: 0 = normal, 1 = large, 2 = larger (zoom on <body>, so the whole layout scales)
  const SIZES = [1, 1.12, 1.25];
  let size = Math.min(2, Math.max(0, Number(store.get('ihub-text-size')) || 0));
  const applySize = () => {
    document.body.style.zoom = SIZES[size] === 1 ? '' : String(SIZES[size]);
    document.querySelectorAll('[data-ihub-font]').forEach((b) => b.setAttribute('aria-pressed', String((b.dataset.ahFont === '0' && size === 0) || (b.dataset.ahFont === '1' && size > 0))));
  };
  applySize();
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-ihub-font]');
    if (!b) return;
    const step = Number(b.dataset.ahFont);
    size = step === 0 ? 0 : Math.min(2, Math.max(0, size + step));
    store.set('ihub-text-size', String(size));
    applySize();
  });

  // Back to top
  document.querySelectorAll('.ihub-to-top').forEach((top) => {
    const y = () => window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
    const toggle = () => { top.hidden = false; top.classList.toggle('is-off', y() < 500); };
    window.addEventListener('scroll', toggle, { passive: true });
    toggle();
    top.addEventListener('click', (e) => {
      e.preventDefault();
      try { window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' }); } catch (err) { window.scrollTo(0, 0); }
      if (document.body.scrollTop && document.body.scrollHeight > document.body.clientHeight) document.body.scrollTop = 0; // pages where <body> is the scroller
      if (history.replaceState && location.hash === '#top') history.replaceState(null, '', location.pathname + location.search);
      const skip = document.querySelector('.brand, .site-logo, a[rel="home"]');
      if (skip) setTimeout(() => skip.focus({ preventScroll: true }), 400);
    });
  });

  // Cookie consent: "all" loads maps/videos right away; otherwise they load when the visitor taps them.
  const KEY = 'ihub-consent';
  const loadFrame = (box) => {
    const frame = box.querySelector('iframe[data-ihub-src]');
    if (!frame) return;
    frame.src = frame.dataset.ahSrc;
    frame.removeAttribute('data-ihub-src');
    frame.hidden = false;
    box.classList.add('is-loaded');
  };
  const consent = store.get(KEY);
  if (consent === 'all') document.querySelectorAll('[data-ihub-consent]').forEach(loadFrame);
  // iDev Cookie Consent: load maps and videos when the visitor allows external media.
  const idevOk = () => window.idevConsent && window.idevConsent.allowed('external');
  if (idevOk()) document.querySelectorAll('[data-ihub-consent]').forEach(loadFrame);
  document.addEventListener('idev:consent', () => { if (idevOk()) document.querySelectorAll('[data-ihub-consent]').forEach(loadFrame); });
  document.addEventListener('click', (e) => {
    const load = e.target.closest('[data-ihub-load]');
    if (load) loadFrame(load.closest('[data-ihub-consent]'));
  });
  const banner = document.querySelector('.ihub-cookie');
  if (banner && !consent) {
    banner.hidden = false;
    document.body.classList.add('has-cookie-banner');
    banner.addEventListener('click', (e) => {
      const choice = e.target.closest('[data-ihub-consent-choice]');
      if (!choice) return;
      store.set(KEY, choice.dataset.ahConsentChoice);
      if (choice.dataset.ahConsentChoice === 'all') document.querySelectorAll('[data-ihub-consent]').forEach(loadFrame);
      banner.hidden = true;
      document.body.classList.remove('has-cookie-banner');
    });
  }

  // Sliders
  document.querySelectorAll('[data-ihub-slider]').forEach((slider) => {
    const slides = Array.from(slider.querySelectorAll('.ihub-slide'));
    const dots = Array.from(slider.querySelectorAll('[data-ihub-dot]'));
    if (slides.length < 2) return;
    let index = 0;
    let timer = null;
    const show = (next) => {
      index = (next + slides.length) % slides.length;
      slides.forEach((s, i) => { s.classList.toggle('is-active', i === index); s.setAttribute('aria-hidden', i === index ? 'false' : 'true'); });
      dots.forEach((d, i) => { d.classList.toggle('active', i === index); if (i === index) d.setAttribute('aria-current', 'true'); else d.removeAttribute('aria-current'); });
    };
    const play = () => {
      stop();
      if (slider.dataset.autoplay === '1' && !reduceMotion) timer = setInterval(() => show(index + 1), Number(slider.dataset.interval || 6) * 1000);
    };
    function stop() { if (timer) clearInterval(timer); timer = null; }
    slider.addEventListener('click', (e) => {
      if (e.target.closest('[data-ihub-prev]')) { show(index - 1); play(); }
      if (e.target.closest('[data-ihub-next]')) { show(index + 1); play(); }
      const dot = e.target.closest('[data-ihub-dot]');
      if (dot) { show(Number(dot.dataset.ahDot)); play(); }
    });
    slider.addEventListener('mouseenter', stop);
    slider.addEventListener('mouseleave', play);
    slider.addEventListener('focusin', stop);
    let startX = null;
    slider.addEventListener('touchstart', (e) => { startX = e.touches[0].clientX; stop(); }, { passive: true });
    slider.addEventListener('touchend', (e) => {
      if (startX === null) return;
      const dx = e.changedTouches[0].clientX - startX;
      if (Math.abs(dx) > 40) show(index + (dx < 0 ? 1 : -1));
      startX = null;
      play();
    });
    play();
  });

  // Counters
  const counters = document.querySelectorAll('[data-ihub-count]');
  if (counters.length && 'IntersectionObserver' in window && !reduceMotion) {
    const format = (n, decimals) => n.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        observer.unobserve(entry.target);
        const el = entry.target;
        const target = Number(el.dataset.ahCount);
        const decimals = (el.dataset.ahCount.split('.')[1] || '').length;
        const start = performance.now();
        const step = (now) => {
          const t = Math.min(1, (now - start) / 1400);
          el.textContent = format(target * (1 - Math.pow(1 - t, 3)), decimals);
          if (t < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
      });
    }, { threshold: 0.4 });
    counters.forEach((el) => observer.observe(el));
  }
})();
