/* News attachments: pick files from the media library, give each a label, keep the order. */
(function ($) {
  const root = document.getElementById('ihub-attachments');
  const input = document.getElementById('ihub-attachments-input');
  if (!root || !input) return;
  let files = [];
  try { files = JSON.parse(root.dataset.files || '[]'); } catch (e) { files = []; }
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function render() {
    input.value = JSON.stringify(files.map((f) => ({ id: f.id, label: f.label || '' })));
    root.innerHTML = (files.length ? '<ul class="ihub-files">' + files.map((f, i) => `<li><span class="ihub-file-badge">${esc((f.ext || '').toUpperCase())}</span><span class="ihub-file-main"><input data-i="${i}" value="${esc(f.label)}" placeholder="${esc(f.title || f.name)}"><small>${esc(f.name)}</small></span><span><button type="button" class="button-link" data-up="${i}"${i ? '' : ' disabled'}>↑</button> <button type="button" class="button-link" data-down="${i}"${i < files.length - 1 ? '' : ' disabled'}>↓</button> <button type="button" class="button-link-delete" data-remove="${i}">นำออก</button></span></li>`).join('') + '</ul>' : '<p class="ihub-empty">ยังไม่มีไฟล์แนบ</p>')
      + '<p><button type="button" class="button" data-add>＋ แนบไฟล์</button> <span class="description">ชื่อที่แสดง: เว้นว่าง = ใช้ชื่อไฟล์</span></p>';
  }
  root.addEventListener('input', (e) => { if (e.target.dataset.i !== undefined) { files[Number(e.target.dataset.i)].label = e.target.value; input.value = JSON.stringify(files.map((f) => ({ id: f.id, label: f.label || '' }))); } });
  root.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    e.preventDefault();
    if (b.dataset.remove !== undefined) files.splice(Number(b.dataset.remove), 1);
    if (b.dataset.up !== undefined) { const i = Number(b.dataset.up); [files[i - 1], files[i]] = [files[i], files[i - 1]]; }
    if (b.dataset.down !== undefined) { const i = Number(b.dataset.down); [files[i + 1], files[i]] = [files[i], files[i + 1]]; }
    if (b.dataset.add !== undefined) {
      const frame = wp.media({ title: 'เลือกเอกสารแนบ', multiple: true, library: { type: ['application'] }, button: { text: 'แนบไฟล์' } });
      frame.on('select', () => {
        frame.state().get('selection').each((a) => {
          const d = a.toJSON();
          if (!files.some((f) => f.id === d.id)) files.push({ id: d.id, label: '', title: d.title, name: d.filename, ext: (d.filename.split('.').pop() || '').toLowerCase() });
        });
        render();
      });
      frame.open();
      return;
    }
    render();
  });
  render();
})(jQuery);
