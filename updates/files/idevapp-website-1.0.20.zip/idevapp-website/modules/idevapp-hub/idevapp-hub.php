<?php
/**
 * Plugin Name: iDevApp Hub
 * Plugin URI: https://idevapp.me/
 * Description: ระบบเว็บไซต์และหลังบ้านแบบโปรแกรมสำหรับโรงพยาบาล คลินิก และหน่วยงานราชการ: บล็อกออกแบบหน้า สองภาษา TH/EN ตารางออกตรวจ ห้องบัตร ห้องตรวจ ประกาศข่าวพร้อมอนุมัติ ผู้ใช้และสิทธิ์ (RBAC) แม่แบบเว็บราชการ และ SEO — ทำงานร่วมกับปลั๊กอิน iDevApp อัตโนมัติ
 * Version: 1.5.3
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Author: iDevApp
 * Author URI: https://idevapp.me/
 * Text Domain: idevapp-hub
 */

defined('ABSPATH') || exit;

define('IHUB_VERSION', '1.5.3');
define('IHUB_FILE', __FILE__);
define('IHUB_DIR', plugin_dir_path(__FILE__));
define('IHUB_URL', plugin_dir_url(__FILE__));

require_once IHUB_DIR . 'inc/idev.php';
$ihub_modules = ['i18n', 'settings', 'helpers', 'schedule', ihub_uses('holidays') ? 'compat-holidays' : 'holidays', 'providers', 'notices', 'content', 'news', 'map', 'status', 'ui', 'appmode', 'rbac', 'workspaces', 'site-templates', 'seo'];
if (!ihub_uses('announcements')) $ihub_modules[] = 'news-workflow'; // the "ประกาศข่าว" module does this job when it is on
$ihub_modules = array_merge($ihub_modules, ihub_uses('registration') ? ['compat-registration'] : ['barcode', 'registration', 'registration-admin', 'registration-form'], ['blocks']);
foreach ($ihub_modules as $ihub_file) require_once IHUB_DIR . "inc/{$ihub_file}.php";

register_activation_hook(__FILE__, function () {
    ihub_holidays_install();
    ihub_reg_install();
    ihub_register_post_types();
    flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, 'flush_rewrite_rules');
add_action('plugins_loaded', function () {
    if (get_option('ihub_db_version') !== IHUB_VERSION) ihub_holidays_install();
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script('ihub-front', IHUB_URL . 'assets/front.js', [], IHUB_VERSION, ['in_footer' => true, 'strategy' => 'defer']);
});

// Mourning mode: grayscale on <html> (a filter on a wrapper would break the fixed popup).
add_action('wp_head', function () {
    if (ihub_setting('mourning_mode') === 'true') echo '<style id="ihub-mourning">html{filter:grayscale(1)}</style>';
});
