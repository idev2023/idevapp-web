<?php
/** Back office for new patient registrations (เมนู “ลงทะเบียนผู้ป่วยใหม่”). Needs the ihub_registrations capability. */
defined('ABSPATH') || exit;

add_action('admin_menu', function () {
    global $wpdb;
    $pending = (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . ihub_reg_table() . " WHERE status IN ('pending','error')");
    $badge = $pending ? ' <span class="awaiting-mod">' . $pending . '</span>' : '';
    add_menu_page('ลงทะเบียนผู้ป่วยใหม่', 'ลงทะเบียนผู้ป่วย' . $badge, 'ihub_registrations', 'ihub-registrations', 'ihub_reg_admin_page', 'dashicons-id-alt', 4);
    add_submenu_page('ihub-registrations', 'รายการลงทะเบียน', 'รายการลงทะเบียน', 'ihub_registrations', 'ihub-registrations', 'ihub_reg_admin_page');
    add_submenu_page('ihub-registrations', 'ตั้งค่าการลงทะเบียน / HOSxP', 'ตั้งค่า / HOSxP', 'manage_options', 'ihub-registration-settings', 'ihub_reg_settings_page');
});

function ihub_reg_mask($value) {
    $value = (string) $value;
    return strlen($value) > 4 ? str_repeat('•', strlen($value) - 4) . substr($value, -4) : $value;
}

function ihub_reg_status_badge($status) {
    $colors = ['pending' => '#b26a00', 'approved' => '#2271b1', 'synced' => '#0a7d55', 'error' => '#b32d2e', 'rejected' => '#646970'];
    return '<span style="display:inline-block;padding:2px 9px;border-radius:12px;font-size:12px;font-weight:600;color:#fff;background:' . ($colors[$status] ?? '#646970') . '">' . esc_html(IHUB_REG_STATUSES[$status] ?? $status) . '</span>';
}

function ihub_reg_admin_page() {
    if (!current_user_can('ihub_registrations')) wp_die('ไม่มีสิทธิ์');
    if (isset($_GET['id'])) { ihub_reg_admin_view((int) $_GET['id']); return; }
    global $wpdb;
    $table = ihub_reg_table();
    $status = isset($_GET['status']) && array_key_exists($_GET['status'], IHUB_REG_STATUSES) ? sanitize_key($_GET['status']) : '';
    $search = trim(sanitize_text_field(wp_unslash($_GET['s'] ?? '')));
    $counts = [];
    foreach ($wpdb->get_results("SELECT status, COUNT(*) AS n FROM {$table} GROUP BY status", ARRAY_A) as $row) $counts[$row['status']] = (int) $row['n'];
    echo '<div class="wrap ihub-admin"><h1 class="wp-heading-inline">ลงทะเบียนผู้ป่วยใหม่</h1>';
    foreach (['done' => 'บันทึกแล้ว', 'deleted' => 'ลบรายการแล้ว', 'mailed' => 'ส่งอีเมลบัตรคนไข้แล้ว', 'mailfail' => 'ส่งอีเมลไม่สำเร็จ (ตรวจการตั้งค่าส่งอีเมลของ server / SMTP)'] as $key => $text) if (isset($_GET[$key])) echo '<div class="notice notice-' . ($key === 'mailfail' ? 'error' : 'success') . '"><p>' . esc_html($text) . '</p></div>';
    echo '<ul class="subsubsub"><li><a href="' . esc_url(admin_url('admin.php?page=ihub-registrations')) . '"' . ($status === '' ? ' class="current"' : '') . '>ทั้งหมด (' . array_sum($counts) . ')</a></li>';
    foreach (IHUB_REG_STATUSES as $key => $label) echo '<li> | <a href="' . esc_url(admin_url('admin.php?page=ihub-registrations&status=' . $key)) . '"' . ($status === $key ? ' class="current"' : '') . '>' . esc_html($label) . ' (' . ($counts[$key] ?? 0) . ')</a></li>';
    echo '</ul><form method="get" class="search-box" style="margin:8px 0"><input type="hidden" name="page" value="ihub-registrations"><input type="search" name="s" value="' . esc_attr($search) . '" placeholder="เลขอ้างอิง, HN, ชื่อ, เบอร์, เลขบัตร"><button class="button">ค้นหา</button></form>';
    $where = $status ? $wpdb->prepare('WHERE status=%s', $status) : '';
    $rows = $wpdb->get_results("SELECT * FROM {$table} {$where} ORDER BY FIELD(status,'pending','error','approved','synced','rejected'), id DESC LIMIT 500", ARRAY_A);
    echo '<table class="widefat striped"><thead><tr><th>เลขอ้างอิง</th><th>ชื่อ</th><th>เอกสาร</th><th>โทร</th><th>สถานะ</th><th>HN</th><th>ส่งเมื่อ</th></tr></thead><tbody>';
    $shown = 0;
    foreach ($rows as $row) {
        $p = json_decode((string) ihub_reg_decrypt($row['data']), true) ?: [];
        $number = $row['doc_type'] === 'passport' ? ($p['passport_no'] ?? '') : ($p['cid'] ?? '');
        if ($search !== '') {
            $hay = mb_strtolower(implode(' ', [$row['ref'], $row['hn'], ihub_reg_name($p), $p['first_name_en'] ?? '', $p['last_name_en'] ?? '', $p['phone'] ?? '', $number, $p['email'] ?? '']));
            if (strpos($hay, mb_strtolower($search)) === false) continue;
        }
        $shown++;
        $url = admin_url('admin.php?page=ihub-registrations&id=' . $row['id']);
        echo '<tr><td><a href="' . esc_url($url) . '"><strong>' . esc_html($row['ref']) . '</strong></a></td><td><a href="' . esc_url($url) . '">' . esc_html(ihub_reg_name($p) ?: '(อ่านข้อมูลไม่ได้)') . '</a></td>';
        echo '<td>' . ($row['doc_type'] === 'passport' ? 'Passport ' . esc_html(($p['nationality'] ?? '') . ' ' . ihub_reg_mask($number)) : 'บัตรประชาชน ' . esc_html(ihub_reg_mask($number))) . '</td><td>' . esc_html($p['phone'] ?? '') . '</td><td>' . ihub_reg_status_badge($row['status']) . '</td><td>' . esc_html($row['hn']) . '</td><td>' . esc_html(get_date_from_gmt($row['created_at'], 'j M Y H:i')) . '</td></tr>';
    }
    if (!$shown) echo '<tr><td colspan="7">ไม่มีรายการ</td></tr>';
    echo '</tbody></table>';
    $seen = (int) get_option('ihub_reg_connector_seen');
    echo '<p class="description">ตัวเชื่อม HOSxP ติดต่อล่าสุด: ' . ($seen ? esc_html(wp_date('j M Y H:i', $seen)) . ($seen < time() - 15 * MINUTE_IN_SECONDS ? ' <strong style="color:#b32d2e">(เกิน 15 นาที — ตรวจสอบเครื่องที่รันตัวเชื่อม)</strong>' : '') : 'ยังไม่เคยติดต่อ') . '</p></div>';
}

function ihub_reg_admin_view($id) {
    $row = ihub_reg_get($id);
    if (!$row) { echo '<div class="wrap"><p>ไม่พบรายการ</p></div>'; return; }
    $p = $row['person'];
    $form = function ($do, $label, $class = 'button', $extra = '', $confirm = '') use ($id) {
        return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="ihub-inline-form"' . ($confirm ? ' onsubmit="return confirm(\'' . esc_js($confirm) . '\')"' : '') . '>' . wp_nonce_field('ihub_reg_' . $id, '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_reg"><input type="hidden" name="id" value="' . $id . '"><input type="hidden" name="do" value="' . esc_attr($do) . '">' . $extra . '<button class="' . esc_attr($class) . '">' . esc_html($label) . '</button></form>';
    };
    $value = function ($key) use ($p) { return esc_attr((string) ($p[$key] ?? '')); };
    echo '<div class="wrap ihub-admin"><p><a href="' . esc_url(admin_url('admin.php?page=ihub-registrations')) . '">← รายการลงทะเบียน</a></p>';
    echo '<h1>' . esc_html($row['ref']) . ' ' . ihub_reg_status_badge($row['status']) . ($row['hn'] ? ' <span style="font-size:18px">HN <strong>' . esc_html($row['hn']) . '</strong></span>' : '') . '</h1>';
    if (isset($_GET['done'])) echo '<div class="notice notice-success"><p>บันทึกแล้ว</p></div>';
    if (isset($_GET['mailed'])) echo '<div class="notice notice-success"><p>ส่งอีเมลบัตรคนไข้แล้ว</p></div>';
    if (isset($_GET['mailfail'])) echo '<div class="notice notice-error"><p>ส่งอีเมลไม่สำเร็จ ตรวจการตั้งค่าส่งอีเมลของ server (แนะนำปลั๊กอิน SMTP)</p></div>';
    if ($row['message']) echo '<div class="notice notice-' . ($row['status'] === 'error' ? 'error' : 'info') . '"><p>' . esc_html($row['message']) . '</p></div>';
    echo '<div class="ihub-reg-layout"><div class="ihub-card">';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('ihub_reg_' . $id, '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_reg"><input type="hidden" name="id" value="' . $id . '"><input type="hidden" name="do" value="save">';
    echo '<h2>ข้อมูลผู้ป่วย</h2><p class="description">ตรวจกับรูปบัตรด้านขวา แก้ได้ถ้าระบบอ่านบัตรผิด</p><div class="ihub-grid2">';
    echo '<label>เอกสาร<select name="doc_type"><option value="thai_id"' . selected($p['doc_type'] ?? '', 'thai_id', false) . '>บัตรประชาชน</option><option value="passport"' . selected($p['doc_type'] ?? '', 'passport', false) . '>Passport</option></select></label>';
    echo '<label>เลขบัตรประชาชน<input name="cid" value="' . $value('cid') . '" inputmode="numeric"></label>';
    echo '<label>เลข Passport<input name="passport_no" value="' . $value('passport_no') . '"></label><label>สัญชาติ (ISO 3 ตัว เช่น THA, DEU)<input name="nationality" value="' . $value('nationality') . '" maxlength="3"></label>';
    echo '<label>คำนำหน้า<input name="prefix" value="' . $value('prefix') . '"></label><label>เพศ<select name="sex"><option value="male"' . selected($p['sex'] ?? '', 'male', false) . '>ชาย</option><option value="female"' . selected($p['sex'] ?? '', 'female', false) . '>หญิง</option></select></label>';
    echo '<label>ชื่อ<input name="first_name" value="' . $value('first_name') . '"></label><label>นามสกุล<input name="last_name" value="' . $value('last_name') . '"></label>';
    echo '<label>ชื่อ (อังกฤษ)<input name="first_name_en" value="' . $value('first_name_en') . '"></label><label>นามสกุล (อังกฤษ)<input name="last_name_en" value="' . $value('last_name_en') . '"></label>';
    echo '<label>วันเกิด<input type="date" name="birthdate" value="' . $value('birthdate') . '"></label><label>เบอร์โทร<input name="phone" value="' . $value('phone') . '"></label>';
    echo '<label>อีเมล<input type="email" name="email" value="' . $value('email') . '"></label><label>ภาษาอีเมล<select name="lang"><option value="th"' . selected($p['lang'] ?? 'th', 'th', false) . '>ไทย</option><option value="en"' . selected($p['lang'] ?? 'th', 'en', false) . '>English</option></select></label></div>';
    echo '<label class="ihub-wide">ที่อยู่ปัจจุบัน<textarea name="address" rows="3">' . esc_textarea($p['address'] ?? '') . '</textarea></label>';
    if (!empty($p['lat']) && !empty($p['lng'])) echo '<p>พิกัด GPS: <a href="' . esc_url('https://www.google.com/maps?q=' . $p['lat'] . ',' . $p['lng']) . '" target="_blank" rel="noopener">' . esc_html($p['lat'] . ', ' . $p['lng']) . ' ↗</a></p>';
    echo '<input type="hidden" name="lat" value="' . $value('lat') . '"><input type="hidden" name="lng" value="' . $value('lng') . '">';
    echo '<div class="ihub-grid2"><label>ประวัติแพ้ยา<input name="drug_allergy" value="' . $value('drug_allergy') . '"></label><span></span><label>ผู้ติดต่อฉุกเฉิน<input name="emergency_name" value="' . $value('emergency_name') . '"></label><label>เบอร์ผู้ติดต่อฉุกเฉิน<input name="emergency_phone" value="' . $value('emergency_phone') . '"></label></div>';
    echo '<p><button class="button button-primary">บันทึกการแก้ไข</button></p></form></div>';
    echo '<div><div class="ihub-card"><h2>รูปบัตร</h2>';
    if ($row['photo']) {
        $src = wp_nonce_url(admin_url('admin-post.php?action=ihub_reg_photo&id=' . $id), 'ihub_reg_photo_' . $id);
        echo '<a href="' . esc_url($src) . '" target="_blank" rel="noopener"><img src="' . esc_url($src) . '" alt="รูปบัตร" style="width:100%;border-radius:8px;border:1px solid #dcdcde"></a>';
        echo '<p>' . $form('delete_photo', 'ลบรูปบัตรตอนนี้', 'button-link-delete', '', 'ลบรูปบัตร? กู้คืนไม่ได้') . '</p>';
    } else echo '<p class="description">ลบรูปแล้ว (ระบบลบรูปบัตรอัตโนมัติหลังลงทะเบียนเสร็จ ' . (int) ihub_reg_setting('photo_days') . ' วัน)</p>';
    echo '</div><div class="ihub-card"><h2>ดำเนินการ</h2>';
    if (in_array($row['status'], ['pending', 'error', 'rejected'], true)) echo '<p>' . $form('approve', $row['status'] === 'error' ? '↻ ส่งเข้า HOSxP อีกครั้ง' : '✓ อนุมัติ ส่งเข้า HOSxP', 'button button-primary') . '</p><p class="description">ตัวเชื่อมใน รพ. จะดึงไปบันทึก HOSxP (ถ้ามีประวัติเดิมจะใช้ HN เดิม) แล้วส่งบัตรคนไข้ทางอีเมลอัตโนมัติ</p>';
    if ($row['status'] === 'approved') echo '<p>' . $form('unapprove', 'ยกเลิกการอนุมัติ (กลับไปรอตรวจสอบ)') . '</p>';
    if ($row['status'] !== 'synced') {
        echo '<hr><p><strong>หรือ ใส่ HN เอง</strong> (บันทึกใน HOSxP ด้วยมือแล้ว)</p>' . $form('manual_hn', 'บันทึก HN และส่งบัตรคนไข้', 'button', '<input name="hn" placeholder="HN" required style="width:140px"> ');
        if ($row['status'] !== 'rejected') echo '<hr>' . $form('reject', 'ไม่อนุมัติ', 'button', '<input name="reason" placeholder="เหตุผล (ไม่ส่งถึงผู้ป่วย)" style="width:220px"> ');
    } else {
        echo '<p>' . $form('resend', 'ส่งอีเมลบัตรคนไข้อีกครั้ง') . '</p>' . ($row['emailed_at'] ? '<p class="description">ส่งล่าสุด ' . esc_html(get_date_from_gmt($row['emailed_at'], 'j M Y H:i')) . '</p>' : '');
    }
    echo '<hr>' . $form('delete', 'ลบรายการนี้ทั้งหมด', 'button-link-delete', '', 'ลบข้อมูลลงทะเบียนนี้ทั้งหมด (รวมรูปบัตร)? กู้คืนไม่ได้ — ไม่กระทบข้อมูลใน HOSxP') . '</div>';
    echo '<div class="ihub-card"><h2>ประวัติ</h2><ul class="ihub-log">';
    $consent = $p['consent'] ?? [];
    if ($consent) echo '<li>ยินยอม PDPA/GDPR ฉบับที่ ' . esc_html($consent['version'] ?? '') . ' เมื่อ ' . esc_html(wp_date('j M Y H:i', strtotime($consent['at'] ?? 'now'))) . '</li>';
    foreach (array_reverse($p['_log'] ?? []) as $entry) echo '<li>' . esc_html(wp_date('j M Y H:i', strtotime($entry[0]))) . ' · ' . esc_html($entry[1]) . ' · ' . esc_html($entry[2]) . '</li>';
    echo '</ul></div></div></div></div>';
    // Viewing personal data is logged.
    $person = $p;
    ihub_reg_log($person, 'เปิดดูข้อมูล');
    ihub_reg_save_person($id, $person, [], false);
}

add_action('admin_post_ihub_reg_photo', function () {
    $id = (int) ($_GET['id'] ?? 0);
    if (!current_user_can('ihub_registrations') || !wp_verify_nonce(sanitize_key($_GET['_wpnonce'] ?? ''), 'ihub_reg_photo_' . $id)) wp_die('ไม่มีสิทธิ์', 403);
    $row = ihub_reg_get($id);
    $bytes = $row ? ihub_reg_photo_bytes($row['photo']) : null;
    if (!$bytes) wp_die('ไม่พบรูป', 404);
    nocache_headers();
    header('Content-Type: image/jpeg');
    header('X-Content-Type-Options: nosniff');
    header('Content-Length: ' . strlen($bytes));
    echo $bytes; // phpcs:ignore
    exit;
});

add_action('admin_post_ihub_reg', function () {
    $id = (int) ($_POST['id'] ?? 0);
    if (!current_user_can('ihub_registrations') || !check_admin_referer('ihub_reg_' . $id)) wp_die('ไม่มีสิทธิ์');
    global $wpdb;
    $row = ihub_reg_get($id);
    if (!$row) wp_die('ไม่พบรายการ');
    $person = $row['person'];
    $do = sanitize_key($_POST['do'] ?? '');
    $back = ['page' => 'ihub-registrations', 'id' => $id, 'done' => 1];
    switch ($do) {
        case 'save':
            [$clean] = ihub_reg_clean($_POST);
            foreach ($clean as $key => $v) $person[$key] = $v;
            ihub_reg_log($person, 'แก้ไขข้อมูล');
            $number = $person['doc_type'] === 'thai_id' ? $person['cid'] : $person['passport_no'];
            ihub_reg_save_person($id, $person, ['doc_type' => $person['doc_type'], 'search_key' => ihub_reg_search_key($person['doc_type'], $number)]);
            break;
        case 'approve':
            ihub_reg_log($person, 'อนุมัติ ส่งเข้า HOSxP');
            ihub_reg_save_person($id, $person, ['status' => 'approved', 'message' => '']);
            break;
        case 'unapprove':
            ihub_reg_log($person, 'ยกเลิกการอนุมัติ');
            ihub_reg_save_person($id, $person, ['status' => 'pending']);
            break;
        case 'reject':
            $reason = sanitize_text_field(wp_unslash($_POST['reason'] ?? ''));
            ihub_reg_log($person, 'ไม่อนุมัติ' . ($reason ? ': ' . $reason : ''));
            ihub_reg_save_person($id, $person, ['status' => 'rejected', 'message' => $reason ? 'ไม่อนุมัติ: ' . $reason : 'ไม่อนุมัติ']);
            break;
        case 'manual_hn':
            $hn = preg_replace('/[^0-9A-Za-z-]/', '', wp_unslash($_POST['hn'] ?? ''));
            if ($hn === '') break;
            ihub_reg_log($person, 'ใส่ HN เอง ' . $hn);
            ihub_reg_save_person($id, $person, ['status' => 'synced', 'hn' => $hn, 'message' => 'ใส่ HN โดยเจ้าหน้าที่', 'synced_at' => current_time('mysql', true)]);
            $back[ihub_reg_mail_card($id) ? 'mailed' : 'mailfail'] = 1;
            break;
        case 'resend':
            $back[ihub_reg_mail_card($id) ? 'mailed' : 'mailfail'] = 1;
            break;
        case 'delete_photo':
            ihub_reg_delete_photo($row);
            ihub_reg_log($person, 'ลบรูปบัตร');
            ihub_reg_save_person($id, $person);
            break;
        case 'delete':
            ihub_reg_delete_photo($row);
            $wpdb->delete(ihub_reg_table(), ['id' => $id]);
            wp_safe_redirect(admin_url('admin.php?page=ihub-registrations&deleted=1'));
            exit;
    }
    wp_safe_redirect(add_query_arg($back, admin_url('admin.php')));
    exit;
});

/* ---------- Settings + connector token ---------- */

function ihub_reg_settings_page() {
    if (!current_user_can('manage_options')) wp_die('ไม่มีสิทธิ์');
    $new_token = '';
    if (isset($_POST['ihub_reg_nonce']) && wp_verify_nonce(sanitize_key($_POST['ihub_reg_nonce']), 'ihub_reg_settings')) {
        if (!empty($_POST['new_token'])) {
            $new_token = 'ahx_' . bin2hex(random_bytes(24));
            update_option('ihub_reg_token_hash', hash('sha256', $new_token), false);
        } else {
            $in = wp_unslash($_POST['reg'] ?? []);
            $old = get_option('ihub_reg_settings', []);
            $values = [];
            foreach (ihub_reg_setting_defaults() as $key => $default) {
                $raw = $in[$key] ?? '';
                if (in_array($key, ['enabled', 'ocr'], true)) $values[$key] = $raw ? 'true' : 'false';
                elseif (in_array($key, ['consent_text', 'consent_text_en', 'card_note', 'card_note_en', 'dpo_contact', 'connector_ips'], true)) $values[$key] = sanitize_textarea_field($raw);
                elseif (in_array($key, ['photo_days', 'rejected_days'], true)) $values[$key] = (string) max(0, min(3650, (int) $raw));
                elseif ($key === 'staff_email') $values[$key] = sanitize_email($raw);
                elseif ($key === 'consent_version') $values[$key] = (string) ($old['consent_version'] ?? '1');
                else $values[$key] = sanitize_text_field($raw);
            }
            // A changed consent text is a new consent version (stored with every registration).
            if (($old['consent_text'] ?? ihub_reg_setting_defaults()['consent_text']) !== $values['consent_text'] || ($old['consent_text_en'] ?? ihub_reg_setting_defaults()['consent_text_en']) !== $values['consent_text_en']) $values['consent_version'] = (string) ((int) ($old['consent_version'] ?? 1) + 1);
            update_option('ihub_reg_settings', $values, false);
            echo '<div class="notice notice-success"><p>บันทึกแล้ว</p></div>';
        }
    }
    $s = function ($key) { return ihub_reg_setting($key); };
    echo '<div class="wrap ihub-admin"><h1>ตั้งค่าการลงทะเบียนผู้ป่วยใหม่ / HOSxP</h1>';
    if ($new_token) echo '<div class="notice notice-warning"><p><strong>รหัสตัวเชื่อม (คัดลอกเก็บไว้ตอนนี้ — จะไม่แสดงอีก):</strong></p><p><code style="font-size:15px;user-select:all">' . esc_html($new_token) . '</code></p><p>นำไปใส่ใน <code>config.php</code> ของตัวเชื่อม HOSxP (รหัสเดิมใช้ไม่ได้แล้ว)</p></div>';
    if (!defined('IHUB_REG_KEY')) echo '<div class="notice notice-info"><p>ข้อมูลผู้ป่วยถูกเข้ารหัสด้วยกุญแจจาก wp-config.php — <strong>อย่าเปลี่ยนค่า AUTH_KEY / SECURE_AUTH_KEY</strong> มิฉะนั้นข้อมูลลงทะเบียนเดิมจะอ่านไม่ได้ (หรือกำหนด <code>IHUB_REG_KEY</code> แยกใน wp-config.php ก่อนเริ่มใช้งาน)</p></div>';
    echo '<form method="post">' . wp_nonce_field('ihub_reg_settings', 'ihub_reg_nonce', true, false) . '<table class="form-table">';
    $row = function ($label, $html, $help = '') { echo '<tr><th>' . esc_html($label) . '</th><td>' . $html . ($help ? '<p class="description">' . esc_html($help) . '</p>' : '') . '</td></tr>'; };
    $row('เปิดรับลงทะเบียน', '<label><input type="checkbox" name="reg[enabled]" value="1"' . checked($s('enabled'), 'true', false) . '> เปิด</label>');
    $row('อ่านข้อมูลจากรูปบัตรอัตโนมัติ', '<label><input type="checkbox" name="reg[ocr]" value="1"' . checked($s('ocr'), 'true', false) . '> เปิด</label>', 'อ่านบนเครื่องผู้ใช้ (รูปไม่ถูกส่งไปบริการภายนอก) ผู้ใช้ตรวจแก้ก่อนส่งเสมอ · Passport อ่านจากแถบ MRZ แม่นยำ · บัตรประชาชนอ่านได้บางส่วน');
    $row('อีเมลแจ้งเจ้าหน้าที่', '<input type="email" class="regular-text" name="reg[staff_email]" value="' . esc_attr($s('staff_email')) . '">', 'แจ้งเมื่อมีผู้ลงทะเบียนใหม่ (ไม่มีข้อมูลส่วนตัวในอีเมล)');
    $row('ข้อความความยินยอม (ไทย)', '<textarea class="large-text" rows="8" name="reg[consent_text]">' . esc_textarea($s('consent_text')) . '</textarea>', 'ฉบับที่ ' . $s('consent_version') . ' — แก้ข้อความแล้วระบบจะนับเป็นฉบับใหม่อัตโนมัติ · ควรให้เจ้าหน้าที่คุ้มครองข้อมูล (DPO) / ฝ่ายกฎหมายตรวจก่อนใช้งานจริง');
    $row('Consent text (English, GDPR)', '<textarea class="large-text" rows="8" name="reg[consent_text_en]">' . esc_textarea($s('consent_text_en')) . '</textarea>');
    $row('ช่องทางติดต่อ DPO', '<textarea class="large-text" rows="2" name="reg[dpo_contact]">' . esc_textarea($s('dpo_contact')) . '</textarea>', 'เช่น อีเมล dpo@... โทร ... (แสดงใต้ข้อความความยินยอม)');
    $row('ลบรูปบัตรหลังได้ HN / ไม่อนุมัติ', '<input type="number" min="0" name="reg[photo_days]" value="' . esc_attr($s('photo_days')) . '" style="width:90px"> วัน', '0 = ลบในรอบถัดไป (ระบบตรวจวันละครั้ง)');
    $row('ลบรายการที่ไม่อนุมัติ', '<input type="number" min="1" name="reg[rejected_days]" value="' . esc_attr($s('rejected_days')) . '" style="width:90px"> วัน');
    $row('หมายเหตุท้ายบัตรคนไข้ (ไทย)', '<textarea class="large-text" rows="2" name="reg[card_note]">' . esc_textarea($s('card_note')) . '</textarea>');
    $row('Card note (English)', '<textarea class="large-text" rows="2" name="reg[card_note_en]">' . esc_textarea($s('card_note_en')) . '</textarea>');
    $row('IP ที่ตัวเชื่อมใช้ (ถ้ามี)', '<input class="regular-text" name="reg[connector_ips]" value="' . esc_attr($s('connector_ips')) . '">', 'IP สาธารณะของ รพ. คั่นด้วยจุลภาค — เว้นว่าง = ไม่จำกัด (ใช้รหัสตัวเชื่อมอย่างเดียว)');
    echo '</table>';
    submit_button('บันทึก');
    echo '</form><div class="ihub-card"><h2>ตัวเชื่อม HOSxP</h2>';
    $seen = (int) get_option('ihub_reg_connector_seen');
    echo '<p>สถานะ: ' . (get_option('ihub_reg_token_hash') ? 'ตั้งรหัสแล้ว' : '<strong>ยังไม่ได้สร้างรหัส</strong>') . ' · ติดต่อล่าสุด: ' . ($seen ? esc_html(wp_date('j M Y H:i', $seen)) : 'ยังไม่เคย') . '</p>';
    echo '<p>Address ของเว็บ (ใส่ใน config ตัวเชื่อม): <code>' . esc_html(home_url('/')) . '</code></p>';
    echo '<form method="post" onsubmit="return confirm(\'สร้างรหัสใหม่? รหัสเดิมจะใช้ไม่ได้ทันที\')">' . wp_nonce_field('ihub_reg_settings', 'ihub_reg_nonce', true, false) . '<input type="hidden" name="new_token" value="1"><button class="button">สร้างรหัสตัวเชื่อมใหม่</button></form>';
    echo '<p><a class="button button-primary" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=ihub_reg_connector'), 'ihub_reg_connector')) . '">ดาวน์โหลดตัวเชื่อม HOSxP (zip)</a></p>';
    echo '<p class="description">ตัวเชื่อมเป็นโปรแกรม PHP เล็ก ๆ รันบนเครื่องใน รพ. ที่เข้าถึงฐานข้อมูล HOSxP ได้ ทำงานทุก 1–5 นาที: ดึงรายการที่อนุมัติ → ตรวจว่ามีผู้ป่วยเดิมไหม → สร้าง HN → ส่ง HN กลับมา เว็บไม่ต้องต่อเข้าฐานข้อมูล HOSxP โดยตรง</p></div></div>';
}

add_action('admin_post_ihub_reg_connector', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('ihub_reg_connector')) wp_die('ไม่มีสิทธิ์');
    $dir = IHUB_DIR . 'tools/hosxp-connector';
    $zip_path = wp_tempnam('hosxp-connector.zip');
    $zip = new ZipArchive();
    $zip->open($zip_path, ZipArchive::OVERWRITE);
    foreach (['hosxp-connector.php', 'config.sample.php', 'README-TH.md'] as $file) $zip->addFile("$dir/$file", "hosxp-connector/$file");
    $zip->close();
    nocache_headers();
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="hosxp-connector.zip"');
    header('Content-Length: ' . filesize($zip_path));
    readfile($zip_path);
    @unlink($zip_path);
    exit;
});
