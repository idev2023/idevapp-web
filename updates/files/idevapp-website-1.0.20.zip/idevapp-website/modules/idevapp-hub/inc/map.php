<?php
/** Google Maps without an API key: the "Embed a map" iframe code/URL, a maps link with coordinates, or an address. */
defined('ABSPATH') || exit;

function ihub_map_extract_src($value) {
    if (preg_match('/<iframe[^>]*\ssrc\s*=\s*["\']([^"\']+)["\']/i', $value, $m)) return str_replace('&amp;', '&', $m[1]);
    return $value;
}

/** Safe iframe src, or null when the input cannot be embedded (e.g. a maps.app.goo.gl short link). */
function ihub_map_embed_src($input) {
    $raw = ihub_map_extract_src(trim((string) $input));
    if ($raw === '') return null;
    $url = wp_parse_url($raw);
    if (!empty($url['scheme']) && !empty($url['host'])) {
        if ($url['scheme'] !== 'https' || !in_array($url['host'], ['www.google.com', 'google.com', 'maps.google.com'], true)) return null;
        $path = $url['path'] ?? '';
        if (strpos($path, '/maps/embed') === 0) return $raw;
        parse_str($url['query'] ?? '', $params);
        if (preg_match('/@(-?\d+\.\d+),(-?\d+\.\d+)/', $path, $m)) $query = "{$m[1]},{$m[2]}";
        elseif (!empty($params['q'])) $query = $params['q'];
        elseif (preg_match('#/maps/place/([^/]+)#', $path, $m)) $query = str_replace('+', ' ', urldecode($m[1]));
        else return null;
        return 'https://www.google.com/maps?q=' . rawurlencode($query) . '&output=embed';
    }
    if (preg_match('/[<>"]/', $raw) || strlen($raw) > 300) return null;
    return 'https://www.google.com/maps?q=' . rawurlencode($raw) . '&output=embed';
}

function ihub_map_open_link($input, $fallback) {
    $raw = ihub_map_extract_src(trim((string) $input));
    $url = wp_parse_url($raw);
    $host = $url['host'] ?? '';
    $google = $host && (preg_match('/(^|\.)google\.[a-z.]+$/', $host) || preg_match('/(^|\.)goo\.gl$/', $host));
    if ($google && ($url['scheme'] ?? '') === 'https' && strpos($url['path'] ?? '', '/maps/embed') !== 0) return $raw;
    $query = ihub_map_destination($raw) ?: $fallback;
    return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($query);
}

/** "lat,lng" (or a place) for directions, taken from an embed code / maps link; '' when there is none. */
function ihub_map_destination($input) {
    $raw = ihub_map_extract_src(trim((string) $input));
    if ($raw === '') return '';
    if (!preg_match('#^https?://#i', $raw)) return preg_match('/[<>"]/', $raw) ? '' : $raw;
    $url = wp_parse_url($raw);
    parse_str($url['query'] ?? '', $params);
    // Embed links ("Share → Embed a map"): !2d = longitude, !3d = latitude of the marked place.
    if (!empty($params['pb']) && preg_match('/!2d(-?\d+\.\d+)!3d(-?\d+\.\d+)/', $params['pb'], $m)) return "{$m[2]},{$m[1]}";
    if (preg_match('/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/', $raw, $m)) return "{$m[1]},{$m[2]}";
    if (preg_match('/@(-?\d+\.\d+),(-?\d+\.\d+)/', $url['path'] ?? '', $m)) return "{$m[1]},{$m[2]}";
    foreach (['q', 'query', 'destination', 'daddr'] as $k) if (!empty($params[$k])) return (string) $params[$k];
    if (preg_match('#/maps/place/([^/]+)#', $url['path'] ?? '', $m)) return str_replace('+', ' ', urldecode($m[1]));
    return '';
}

/** Map section with heading and "Open in Google Maps"; empty when no usable map is set. */
function ihub_render_map($title = null) {
    if (ihub_uses('maps') && function_exists('idev_map_render')) return idev_map_render($title ? ['title' => $title] : []);
    $query = ihub_setting('map_query');
    $src = $query !== '' ? ihub_map_embed_src($query) : null;
    if (!$src) return '';
    $title = $title ?: ihub_t('map.title');
    $local = ihub_site_local();
    return '<section class="map-block"><div class="map-heading"><h2>' . esc_html($title) . '</h2><a class="button button-white" href="' . esc_url(ihub_map_open_link($query, $local['address'])) . '" target="_blank" rel="noopener noreferrer">' . esc_html(ihub_t('map.open')) . ' ↗</a></div>'
        . '<div class="map-frame">' . ihub_consent_iframe($src, $title, 'map', 'referrerpolicy="no-referrer-when-downgrade" allowfullscreen') . '</div></section>';
}

add_shortcode('idevapp_map', function ($atts) {
    $atts = shortcode_atts(['title' => ''], $atts);
    return ihub_render_map($atts['title'] ?: null);
});
