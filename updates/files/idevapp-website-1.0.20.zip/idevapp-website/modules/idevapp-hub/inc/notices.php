<?php
/** Announcement bars (static or scrolling) and important popups, both with start/end times and TH/EN text. */
defined('ABSPATH') || exit;

function ihub_now_local() {
    return (new DateTimeImmutable('now', new DateTimeZone('Asia/Bangkok')))->format('Y-m-d H:i');
}

/** Published items whose start/end window (Bangkok time) contains now. */
function ihub_active_items($type, $limit = 10) {
    $now = ihub_now_local();
    $posts = get_posts(['post_type' => $type, 'post_status' => 'publish', 'numberposts' => 50, 'orderby' => $type === 'ihub_popup' ? ['menu_order' => 'ASC', 'date' => 'DESC'] : ['date' => 'DESC'], 'suppress_filters' => false]);
    $active = [];
    foreach ($posts as $post) {
        $start = (string) get_post_meta($post->ID, 'ihub_starts_at', true);
        $end = (string) get_post_meta($post->ID, 'ihub_ends_at', true);
        if ($start !== '' && $start > $now) continue;
        if ($end !== '' && $end <= $now) continue;
        $active[] = $post;
        if (count($active) >= $limit) break;
    }
    return $active;
}

function ihub_meta($post_id, $key) {
    return (string) get_post_meta($post_id, "ihub_{$key}", true);
}

/* ---------- Edit screens ---------- */

add_action('add_meta_boxes', function () {
    add_meta_box('ihub_notice_box', 'ข้อความประกาศ', 'ihub_notice_box', 'ihub_notice', 'normal', 'high');
    add_meta_box('ihub_popup_box', 'เนื้อหา Popup', 'ihub_popup_box', 'ihub_popup', 'normal', 'high');
});

function ihub_schedule_fields($post) {
    $local = function ($value) { return $value ? str_replace(' ', 'T', $value) : ''; };
    return '<div class="ihub-grid2"><label>เริ่มแสดง (เว้นว่าง = ทันที)<input type="datetime-local" name="ah[starts_at]" value="' . esc_attr($local(ihub_meta($post->ID, 'starts_at'))) . '"></label>'
        . '<label>หยุดแสดง (เว้นว่าง = ไม่มีกำหนด)<input type="datetime-local" name="ah[ends_at]" value="' . esc_attr($local(ihub_meta($post->ID, 'ends_at'))) . '"></label></div>'
        . '<p class="description">เวลาประเทศไทย · ปิดชั่วคราว: เปลี่ยนสถานะเป็น “ฉบับร่าง”</p>';
}

function ihub_notice_box($post) {
    wp_nonce_field('ihub_items_save', 'ihub_items_nonce');
    $mode = ihub_meta($post->ID, 'display_mode') ?: 'static';
    $modes = ['static' => 'แสดงนิ่ง', 'scroll-slow' => 'วิ่งช้า', 'scroll' => 'วิ่งปกติ', 'scroll-fast' => 'วิ่งเร็ว'];
    echo '<div class="ihub-admin">';
    echo '<label class="ihub-wide">Label (English)<input name="ah[title_en]" value="' . esc_attr(ihub_meta($post->ID, 'title_en')) . '" placeholder="Important notice"></label>';
    echo '<label class="ihub-wide">ข้อความประกาศ (ไทย)<textarea name="ah[body]" rows="3" required>' . esc_textarea(ihub_meta($post->ID, 'body')) . '</textarea></label>';
    echo '<label class="ihub-wide">Message (English)<textarea name="ah[body_en]" rows="3">' . esc_textarea(ihub_meta($post->ID, 'body_en')) . '</textarea></label>';
    echo '<fieldset class="ihub-kind"><legend>การแสดงผล</legend>';
    foreach ($modes as $value => $label) echo '<label class="ihub-kind-option"><input type="radio" name="ah[display_mode]" value="' . $value . '"' . checked($mode, $value, false) . '><span><strong>' . esc_html($label) . '</strong></span></label>';
    echo '</fieldset><p class="description">ข้อความวิ่งจะหยุดเมื่อเอาเมาส์ชี้ และไม่วิ่งถ้าเครื่องผู้ชมตั้งค่าลดการเคลื่อนไหว</p>';
    echo ihub_schedule_fields($post) . '</div>';
}

function ihub_popup_box($post) {
    wp_nonce_field('ihub_items_save', 'ihub_items_nonce');
    $field = function ($key, $label, $type = 'text', $placeholder = '') use ($post) {
        if ($type === 'textarea') return '<label class="ihub-wide">' . esc_html($label) . '<textarea name="ah[' . $key . ']" rows="4">' . esc_textarea(ihub_meta($post->ID, $key)) . '</textarea></label>';
        return '<label>' . esc_html($label) . '<input type="' . $type . '" name="ah[' . $key . ']" value="' . esc_attr(ihub_meta($post->ID, $key)) . '" placeholder="' . esc_attr($placeholder) . '"></label>';
    };
    echo '<div class="ihub-admin">';
    echo '<label class="ihub-wide">Title (English)<input name="ah[title_en]" value="' . esc_attr(ihub_meta($post->ID, 'title_en')) . '"></label>';
    echo $field('body', 'ข้อความ (ไทย)', 'textarea') . $field('body_en', 'Message (English)', 'textarea');
    echo '<div class="ihub-grid2">' . $field('link_text', 'ข้อความปุ่ม (ไทย)', 'text', 'เช่น อ่านรายละเอียด') . $field('link_text_en', 'Button text (English)') . '</div>';
    echo '<label class="ihub-wide">ลิงก์ปุ่ม<input type="text" name="ah[link_url]" value="' . esc_attr(ihub_meta($post->ID, 'link_url')) . '" placeholder="https://... หรือ /news/..."></label>';
    echo ihub_schedule_fields($post);
    echo '<p class="description">แสดงทีละอันตาม “ลำดับ” (คุณลักษณะ → ลำดับ) ผู้ชมกดปิดแล้วจะไม่เห็นซ้ำ 8 ชั่วโมง ถ้าแก้ข้อความจะแสดงใหม่</p></div>';
}

add_action('save_post', function ($post_id, $post) {
    if (!in_array($post->post_type, ['ihub_notice', 'ihub_popup'], true)) return;
    if (!isset($_POST['ihub_items_nonce']) || !wp_verify_nonce(sanitize_key($_POST['ihub_items_nonce']), 'ihub_items_save')) return;
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $post_id)) return;
    $in = isset($_POST['ah']) && is_array($_POST['ah']) ? wp_unslash($_POST['ah']) : [];
    $text = ['title_en'];
    $areas = ['body', 'body_en'];
    if ($post->post_type === 'ihub_notice') {
        update_post_meta($post_id, 'ihub_display_mode', in_array($in['display_mode'] ?? '', ['static', 'scroll-slow', 'scroll', 'scroll-fast'], true) ? $in['display_mode'] : 'static');
    } else {
        $text = array_merge($text, ['link_text', 'link_text_en']);
        update_post_meta($post_id, 'ihub_link_url', ihub_safe_url($in['link_url'] ?? ''));
    }
    foreach ($text as $key) update_post_meta($post_id, "ihub_{$key}", sanitize_text_field($in[$key] ?? ''));
    foreach ($areas as $key) update_post_meta($post_id, "ihub_{$key}", sanitize_textarea_field($in[$key] ?? ''));
    foreach (['starts_at', 'ends_at'] as $key) {
        $value = str_replace('T', ' ', sanitize_text_field($in[$key] ?? ''));
        update_post_meta($post_id, "ihub_{$key}", preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $value) ? $value : '');
    }
}, 10, 2);

foreach (['ihub_notice', 'ihub_popup'] as $ihub_type) {
    add_filter("manage_{$ihub_type}_posts_columns", function ($columns) use ($ihub_type) {
        $extra = $ihub_type === 'ihub_notice' ? ['ihub_body' => 'ข้อความ', 'ihub_mode' => 'การแสดง'] : ['ihub_body' => 'ข้อความ', 'ihub_order' => 'ลำดับ'];
        return ['cb' => $columns['cb'], 'title' => 'หัวข้อ'] + $extra + ['ihub_window' => 'ช่วงเวลาแสดง', 'ihub_live' => 'ตอนนี้', 'date' => $columns['date']];
    });
    add_action("manage_{$ihub_type}_posts_custom_column", function ($column, $post_id) {
        $modes = ['static' => 'นิ่ง', 'scroll-slow' => 'วิ่งช้า', 'scroll' => 'วิ่งปกติ', 'scroll-fast' => 'วิ่งเร็ว'];
        if ($column === 'ihub_body') echo esc_html(wp_trim_words(ihub_meta($post_id, 'body'), 15));
        if ($column === 'ihub_mode') echo esc_html($modes[ihub_meta($post_id, 'display_mode')] ?? 'นิ่ง');
        if ($column === 'ihub_order') echo (int) get_post_field('menu_order', $post_id);
        if ($column === 'ihub_window') echo esc_html((ihub_meta($post_id, 'starts_at') ?: 'ทันที') . ' → ' . (ihub_meta($post_id, 'ends_at') ?: 'ไม่มีกำหนด'));
        if ($column === 'ihub_live') {
            $live = in_array($post_id, wp_list_pluck(ihub_active_items(get_post_type($post_id), 50), 'ID'), true);
            echo $live ? '<span style="color:#0a7d55;font-weight:600">● แสดงอยู่</span>' : '<span style="color:#8a8f98">ไม่แสดง</span>';
        }
    }, 10, 2);
}

/* ---------- Front end ---------- */

/** Announcement bars under the top line (called by the theme). */
function ihub_render_announcements() {
    if (ihub_uses('ticker')) return function_exists('idev_ticker_render') ? idev_ticker_render() : '';
    $speeds = ['scroll-slow' => 0.45, 'scroll' => 0.3, 'scroll-fast' => 0.18];
    $html = '';
    foreach (ihub_active_items('ihub_notice') as $post) {
        $title = ihub_pick($post->post_title, ihub_meta($post->ID, 'title_en')) ?: ihub_t('header.notice');
        $body = ihub_pick(ihub_meta($post->ID, 'body'), ihub_meta($post->ID, 'body_en'));
        if ($body === '') continue;
        $speed = $speeds[ihub_meta($post->ID, 'display_mode')] ?? 0;
        $tag = '<span class="alert-tag"><span aria-hidden="true">!</span> ' . esc_html($title) . '</span>';
        if (!$speed) { $html .= '<div class="announcement"><div class="container">' . $tag . esc_html($body) . '</div></div>'; continue; }
        $seconds = max(12, (int) round(mb_strlen($body) * $speed));
        $html .= '<div class="announcement is-ticker"><div class="container ticker-row">' . $tag . '<div class="ticker"><span class="sr-only">' . esc_html($body) . '</span><div class="ticker-track" style="animation-duration:' . $seconds . 's" aria-hidden="true"><span>' . esc_html($body) . '</span><span>' . esc_html($body) . '</span></div></div></div></div>';
    }
    return $html;
}

/** Popups as JSON for assets/front.js (shown one at a time, dismissed for 8 hours). */
function ihub_popup_items() {
    $items = [];
    foreach (ihub_active_items('ihub_popup') as $post) {
        $title = ihub_pick($post->post_title, ihub_meta($post->ID, 'title_en'));
        $body = ihub_pick(ihub_meta($post->ID, 'body'), ihub_meta($post->ID, 'body_en'));
        if ($title === '' && $body === '') continue;
        $items[] = [
            'id' => (string) $post->ID, 'title' => $title, 'body' => $body, 'imageUrl' => (string) get_the_post_thumbnail_url($post, 'large'),
            'linkText' => ihub_pick(ihub_meta($post->ID, 'link_text'), ihub_meta($post->ID, 'link_text_en')), 'linkUrl' => ihub_href(ihub_meta($post->ID, 'link_url')),
        ];
    }
    return $items;
}

add_action('wp_footer', function () {
    if (is_admin() || !empty($GLOBALS['ihub_no_popup']) || ihub_uses('popup')) return;
    $items = ihub_popup_items();
    if (!$items) return;
    echo '<script type="application/json" id="ihub-popups">' . wp_json_encode(['items' => $items, 'kicker' => ihub_t('popup.kicker'), 'close' => ihub_t('popup.close'), 'next' => ihub_t('popup.next')], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) . '</script>';
});
