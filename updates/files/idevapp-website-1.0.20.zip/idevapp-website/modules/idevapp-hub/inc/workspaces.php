<?php
/**
 * Work pages by job (shown in program mode, each person sees the ones their role allows):
 * - ห้องบัตร (medical records / front desk): new patients online + walk-in, HNs to check from appointments,
 *   all appointment data. Needs idev_medreg or idev_appt_manage.
 * - ห้องตรวจ (doctor): online appointments today / this week, waiting for confirmation, patients waiting in HOSxP
 *   (counts sent by the HOSxP connector of iDev Appointments Pro). Needs idev_appt_doctor (administrators see all).
 */
defined('ABSPATH') || exit;

function ihub_ws_desk_cap() { return current_user_can('idev_medreg') || current_user_can('idev_appt_manage'); }
function ihub_ws_room_cap() { return function_exists('idev_appt_table') && (current_user_can('idev_appt_doctor') || current_user_can('manage_options')); }

add_action('admin_menu', function () {
    if (function_exists('idev_appt_table') || function_exists('idev_medreg_table')) {
        add_menu_page('ห้องบัตร', 'ห้องบัตร', 'read', 'ihub-desk', 'ihub_ws_desk_page', 'dashicons-id', 2);
        if (!ihub_ws_desk_cap()) remove_menu_page('ihub-desk');
    }
    if (function_exists('idev_appt_table')) {
        add_menu_page('ห้องตรวจ', 'ห้องตรวจ', 'read', 'ihub-room', 'ihub_ws_room_page', 'dashicons-heart', 2);
        if (!ihub_ws_room_cap()) remove_menu_page('ihub-room');
    }
}, 6);

/** Start page by job (program mode). */
add_filter('ihub_app_home_url', function ($url, $user) {
    if (user_can($user, 'manage_options')) return $url;
    if (function_exists('idev_appt_table') && user_can($user, 'idev_appt_doctor') && !user_can($user, 'idev_appt_manage')) return admin_url('admin.php?page=ihub-room');
    if (user_can($user, 'idev_medreg') || user_can($user, 'idev_appt_manage')) return admin_url('admin.php?page=ihub-desk');
    if (user_can($user, 'edit_posts') && function_exists('idw_ann_page')) return admin_url('admin.php?page=idw-news');
    if (user_can($user, 'edit_posts') && function_exists('ihub_news_page')) return admin_url('admin.php?page=ihub-news');
    return $url;
}, 10, 2);

/* ---------- shared bits ---------- */

function ihub_ws_css() {
    return '.ihub-ws{max-width:1240px}.ihub-ws h1{margin-bottom:4px}.ihub-ws .sub{color:#64748b;margin:0 0 14px}
.ihub-ws-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;margin:12px 0 18px}
.ihub-ws-stat{display:block;background:#fff;border:1px solid #e2e6ea;border-radius:14px;padding:14px 16px;text-decoration:none;color:#0f2f3a;position:relative;overflow:hidden}
.ihub-ws-stat:before{content:"";position:absolute;left:0;top:0;bottom:0;width:5px;background:var(--c,#16857c)}
.ihub-ws-stat small{display:block;color:#64748b;font-size:12.5px;font-weight:600}.ihub-ws-stat b{display:block;font-size:30px;line-height:1.2;margin:2px 0}.ihub-ws-stat em{font-style:normal;font-size:12px;color:#64748b}
.ihub-ws-stat.warn{--c:#f59e0b}.ihub-ws-stat.bad{--c:#ef4444}.ihub-ws-stat.info{--c:#3b82f6}.ihub-ws-stat.vio{--c:#8b5cf6}
a.ihub-ws-stat:hover{border-color:#16857c}
.ihub-ws-box{background:#fff;border:1px solid #e2e6ea;border-radius:14px;padding:6px 16px 14px;margin:0 0 18px}
.ihub-ws-box h2{font-size:16px;display:flex;align-items:center;gap:8px;justify-content:space-between}.ihub-ws-box h2 a{font-size:13px;font-weight:600;text-decoration:none}
.ihub-ws table{border-collapse:collapse;width:100%}.ihub-ws th,.ihub-ws td{text-align:left;padding:8px 8px;border-bottom:1px solid #eef1f3;vertical-align:middle;font-size:13.5px}.ihub-ws th{color:#64748b;font-size:12px;font-weight:700}
.ihub-ws .chip{display:inline-block;border-radius:99px;padding:1px 9px;font-size:11.5px;font-weight:700;background:#f1f5f9;color:#334155;white-space:nowrap}
.ihub-ws .chip.pending{background:#fef3c7;color:#92400e}.ihub-ws .chip.confirmed,.ihub-ws .chip.synced{background:#dcfce7;color:#166534}.ihub-ws .chip.approved{background:#dbeafe;color:#1e40af}.ihub-ws .chip.error,.ihub-ws .chip.rejected,.ihub-ws .chip.cancelled{background:#fee2e2;color:#991b1b}.ihub-ws .chip.walkin{background:#ede9fe;color:#5b21b6}.ihub-ws .chip.online{background:#e0f2fe;color:#075985}
.ihub-ws .hn-form{display:flex;gap:6px;align-items:center;flex-wrap:wrap}.ihub-ws .hn-form input[type=text]{width:120px;font-weight:700}
.ihub-ws .empty{color:#94a3b8;padding:10px 0}.ihub-ws .hn-ok{display:block;color:#15803d;font-weight:600;margin-top:4px}.ihub-ws-search{margin:6px 0 12px;display:flex;gap:6px;flex-wrap:wrap}.ihub-ws-search input[type=search]{min-width:280px}
.ihub-ws-grid2{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:18px}@media(max-width:1100px){.ihub-ws-grid2{grid-template-columns:minmax(0,1fr)}}
.ihub-ws-form{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px 14px}.ihub-ws-form label{display:flex;flex-direction:column;gap:4px;font-weight:600;font-size:13px}.ihub-ws-form input,.ihub-ws-form select,.ihub-ws-form textarea{font-weight:400}.ihub-ws-form .wide{grid-column:1/-1}
.ihub-ws .nav-tab-wrapper{margin-bottom:14px}
.ihub-ws-doc{display:grid;grid-template-columns:repeat(auto-fit,minmax(330px,1fr));gap:14px;margin-bottom:18px}
.ihub-ws-doc .card{background:#fff;border:1px solid #e2e6ea;border-radius:16px;padding:16px}.ihub-ws-doc .card h2{margin:0 0 10px;font-size:17px}
.ihub-ws-doc .nums{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.ihub-ws-doc .num{background:#f8fafc;border-radius:12px;padding:10px;text-align:center}.ihub-ws-doc .num b{display:block;font-size:26px;line-height:1.15}.ihub-ws-doc .num small{color:#64748b;font-size:12px;font-weight:600}
.ihub-ws-doc .num.hx{background:#ecfdf5}.ihub-ws-doc .num.hx b{color:#047857}.ihub-ws-doc .num.warn b{color:#b45309}
.ihub-ws-doc .hxnote{margin:8px 0 0;font-size:12px;color:#64748b}
@media(max-width:600px){.ihub-ws-doc .nums{grid-template-columns:repeat(2,minmax(0,1fr))}.ihub-ws .hide-s{display:none}}';
}
add_action('admin_enqueue_scripts', function () {
    $page = sanitize_key($_GET['page'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (!in_array($page, ['ihub-desk', 'ihub-room'], true)) return;
    wp_register_style('ihub-ws', false, [], IHUB_VERSION);
    wp_enqueue_style('ihub-ws');
    wp_add_inline_style('ihub-ws', ihub_ws_css());
});

function ihub_ws_status_label($s) {
    $map = ['pending' => 'รอยืนยัน', 'confirmed' => 'ยืนยันแล้ว', 'cancelled' => 'ยกเลิก', 'completed' => 'มาแล้ว', 'no_show' => 'ไม่มา'];
    return $map[$s] ?? $s;
}
function ihub_ws_provider_name($id) {
    static $cache = [];
    if (!isset($cache[$id])) {
        $post = get_post($id);
        $cache[$id] = $post && function_exists('idev_cs_provider') ? (function ($p) { return ihub_pick($p['name'], $p['name_en']); })(idev_cs_provider($post)) : ($post ? $post->post_title : '');
    }
    return $cache[$id];
}
function ihub_ws_date($d) { return function_exists('ihub_format_day') ? ihub_format_day($d, 'th', true) : $d; }

/* ---------- ห้องบัตร ---------- */

add_action('admin_post_ihub_ws_hn', function () {
    if (!function_exists('idev_appt_set_hn') || !idev_appt_can_check_hn() || !check_admin_referer('ihub_ws_hn')) wp_die('ไม่มีสิทธิ์', 403);
    $res = idev_appt_set_hn((int) ($_POST['id'] ?? 0), sanitize_text_field(wp_unslash($_POST['hn'] ?? '')));
    $back = wp_get_referer() ?: admin_url('admin.php?page=ihub-desk&tab=hn');
    wp_safe_redirect(add_query_arg(is_wp_error($res) ? ['ws_err' => rawurlencode($res->get_error_message())] : ['ws_ok' => 'hn'], remove_query_arg(['ws_ok', 'ws_err'], $back)));
    exit;
});
add_action('admin_post_ihub_ws_recheck', function () {
    if (!function_exists('idev_appt_mark_rechecked') || !idev_appt_can_check_hn() || !check_admin_referer('ihub_ws_recheck')) wp_die('ไม่มีสิทธิ์', 403);
    $res = idev_appt_mark_rechecked((int) ($_POST['id'] ?? 0));
    $back = wp_get_referer() ?: admin_url('admin.php?page=ihub-desk&tab=regappt');
    wp_safe_redirect(add_query_arg(is_wp_error($res) ? ['ws_err' => rawurlencode($res->get_error_message())] : ['ws_ok' => 'recheck'], remove_query_arg(['ws_ok', 'ws_err'], $back)));
    exit;
});
add_action('admin_post_ihub_ws_walkin', function () {
    if (!function_exists('idev_medreg_create_walkin') || !current_user_can('idev_medreg') || !check_admin_referer('ihub_ws_walkin')) wp_die('ไม่มีสิทธิ์', 403);
    $in = wp_unslash($_POST['w'] ?? []); // cleaned field by field in idev_medreg_clean()
    $res = idev_medreg_create_walkin(is_array($in) ? $in : []);
    $back = admin_url('admin.php?page=ihub-desk&tab=new');
    if (is_wp_error($res)) {
        set_transient('ihub_ws_walkin_' . get_current_user_id(), $in, 10 * MINUTE_IN_SECONDS);
        wp_safe_redirect(add_query_arg(['ws_err' => rawurlencode($res->get_error_message()), 'walkin' => 1], $back));
    } else {
        wp_safe_redirect(add_query_arg(['ws_ok' => 'walkin', 'ref' => $res[1]], $back));
    }
    exit;
});

function ihub_ws_notices() {
    $ok = sanitize_key($_GET['ws_ok'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $err = sanitize_text_field(rawurldecode(wp_unslash($_GET['ws_err'] ?? ''))); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $msgs = ['recheck' => 'บันทึกว่าตรวจข้อมูลผู้ลงทะเบียนแล้ว', 'hn' => 'บันทึก HN แล้ว', 'walkin' => 'ลงทะเบียน walk-in แล้ว เลขที่ ' . sanitize_text_field(wp_unslash($_GET['ref'] ?? '')) . ' — ออก HN ได้ที่รายการลงทะเบียน']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (isset($msgs[$ok])) echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($msgs[$ok]) . '</p></div>';
    if ($err !== '') echo '<div class="notice notice-error"><p>' . esc_html($err) . '</p></div>';
}

/** Recent registrations (decrypted for the list). */
function ihub_ws_registrations($where, $limit = 50) {
    global $wpdb;
    if (!function_exists('idev_medreg_table')) return [];
    $rows = $wpdb->get_results('SELECT id FROM ' . idev_medreg_table() . " WHERE {$where} ORDER BY created_at DESC LIMIT " . (int) $limit, ARRAY_A); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- fixed conditions from this file
    return array_filter(array_map(function ($r) { return idev_medreg_get((int) $r['id']); }, $rows));
}

function ihub_ws_hn_table($items, $limit = 0, $checked = false) {
    if (!$items) { echo '<p class="empty">' . ($checked ? 'ไม่พบรายการ' : 'ไม่มีนัดที่รอตรวจสอบ HN 👍') . '</p>'; return; }
    $shown = $limit ? array_slice($items, 0, $limit) : $items;
    echo '<table><thead><tr><th>วันนัด</th><th class="hide-s">แพทย์ / คลินิก</th><th>ผู้ป่วย</th><th class="hide-s">โทร / วันเกิด / บัตร</th><th>' . ($checked ? 'HN (แก้ไขได้)' : 'HN ที่ผู้ป่วยให้') . '</th></tr></thead><tbody>';
    foreach ($shown as $a) {
        $p = $a['p'];
        echo '<tr><td><b>' . esc_html(ihub_ws_date($a['appt_date'])) . '</b><br>' . esc_html($a['start_time']) . ' <span class="chip ' . esc_attr($a['status']) . '">' . esc_html(ihub_ws_status_label($a['status'])) . '</span></td>';
        echo '<td class="hide-s">' . esc_html(ihub_ws_provider_name((int) $a['provider_id'])) . '</td>';
        echo '<td><b>' . esc_html($p['name'] ?? '—') . '</b>' . (!empty($a['reg_ref']) ? '<br><span class="chip online">ลงทะเบียนใหม่ ' . esc_html($a['reg_ref']) . '</span>' : '') . '<br><small>' . esc_html($a['ref']) . '</small></td>';
        echo '<td class="hide-s">' . esc_html($p['phone'] ?? '') . '<br><small>' . esc_html($p['dob'] ?? '') . '</small>' . (!empty($p['cid']) ? '<br><small>บัตร/Passport ' . esc_html($p['cid']) . '</small>' : '') . '</td>';
        echo '<td><form class="hn-form" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('ihub_ws_hn', '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_ws_hn"><input type="hidden" name="id" value="' . (int) $a['id'] . '"><input type="text" name="hn" value="' . esc_attr($p['hn'] ?? '') . '" placeholder="HN" required> <button class="button ' . ($checked ? '' : 'button-primary') . '">' . ($checked ? 'แก้ HN' : 'ถูกต้อง / บันทึก') . '</button></form>' . ($checked ? '<small class="hn-ok">✓ ตรวจแล้ว</small>' : '') . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- nonce field
    }
    echo '</tbody></table>';
    if ($limit && count($items) > $limit) echo '<p><a href="' . esc_url(admin_url('admin.php?page=ihub-desk&tab=hn')) . '">ดูทั้งหมด ' . count($items) . ' รายการ →</a></p>';
}

function ihub_ws_reg_table($regs) {
    if (!$regs) { echo '<p class="empty">ไม่มีรายการ</p>'; return; }
    $statuses = function_exists('idev_medreg_statuses') ? idev_medreg_statuses() : [];
    echo '<table><thead><tr><th>เลขที่ / เวลา</th><th>ผู้ป่วย</th><th class="hide-s">เอกสาร</th><th>สถานะ</th><th>HN</th></tr></thead><tbody>';
    foreach ($regs as $r) {
        $p = $r['person'];
        $url = admin_url('admin.php?page=idev-medreg&id=' . (int) $r['id']);
        echo '<tr><td><a href="' . esc_url($url) . '"><b>' . esc_html($r['ref']) . '</b></a><br><small>' . esc_html(get_date_from_gmt($r['created_at'], 'j M H:i')) . '</small></td>';
        echo '<td><a href="' . esc_url($url) . '">' . esc_html(function_exists('idev_medreg_name') ? idev_medreg_name($p) : '') . '</a> ' . ($r['method'] === 'walkin' ? '<span class="chip walkin">walk-in</span>' : '<span class="chip online">online</span>') . '<br><small>' . esc_html($p['phone'] ?? '') . '</small></td>';
        echo '<td class="hide-s">' . esc_html($r['doc_type'] === 'passport' ? 'Passport ' . ($p['nationality'] ?? '') : 'บัตรประชาชน') . '</td>';
        echo '<td><span class="chip ' . esc_attr($r['status']) . '">' . esc_html($statuses[$r['status']] ?? $r['status']) . '</span></td><td>' . esc_html($r['hn'] ?? '') . '</td></tr>';
    }
    echo '</tbody></table>';
}

/** Patients who registered online and booked online: registration data next to the appointment, any status. */
function ihub_ws_regappt_table($items) {
    if (!$items) { echo '<p class="empty">ไม่พบรายการ</p>'; return; }
    $statuses = function_exists('idev_medreg_statuses') ? idev_medreg_statuses() : [];
    echo '<table><thead><tr><th>วันนัด</th><th>ข้อมูลตอนนัด</th><th>ข้อมูลลงทะเบียน</th><th>HN</th><th>ตรวจข้อมูล</th></tr></thead><tbody>';
    foreach ($items as $a) {
        $p = $a['p'];
        $reg = function_exists('idev_appt_find_registration') ? idev_appt_find_registration('reg', $a['reg_ref']) : null;
        $rp = $reg ? $reg['person'] : [];
        $diff = function ($x, $y) { return $x !== '' && $y !== '' && preg_replace('/\W/u', '', mb_strtolower($x)) !== preg_replace('/\W/u', '', mb_strtolower($y)); };
        $rname = $reg && function_exists('idev_medreg_name') ? idev_medreg_name($rp) : '';
        $rcid = (string) ($rp['cid'] ?? '') ?: (string) ($rp['passport_no'] ?? '');
        echo '<tr><td><b>' . esc_html(ihub_ws_date($a['appt_date'])) . '</b><br>' . esc_html($a['start_time']) . ' <span class="chip ' . esc_attr($a['status']) . '">' . esc_html(ihub_ws_status_label($a['status'])) . '</span><br><small>' . esc_html(ihub_ws_provider_name((int) $a['provider_id'])) . '</small></td>';
        echo '<td><b>' . esc_html($p['name'] ?? '') . '</b><br><small>โทร ' . esc_html($p['phone'] ?? '') . ' · เกิด ' . esc_html($p['dob'] ?? '') . (!empty($p['cid']) ? '<br>บัตร ' . esc_html($p['cid']) : '') . '</small></td>';
        if ($reg) {
            $flags = [];
            if ($diff((string) ($p['name'] ?? ''), $rname)) $flags[] = 'ชื่อไม่ตรง';
            if ($diff((string) ($p['phone'] ?? ''), (string) ($rp['phone'] ?? ''))) $flags[] = 'เบอร์ไม่ตรง';
            if ($diff((string) ($p['cid'] ?? ''), $rcid)) $flags[] = 'เลขบัตรไม่ตรง';
            echo '<td><a href="' . esc_url(admin_url('admin.php?page=idev-medreg&id=' . (int) $reg['id'])) . '"><b>' . esc_html($a['reg_ref']) . '</b></a> <span class="chip ' . esc_attr($reg['status']) . '">' . esc_html($statuses[$reg['status']] ?? $reg['status']) . '</span><br><small>' . esc_html($rname) . ' · ' . esc_html($rp['phone'] ?? '') . ' · เกิด ' . esc_html($rp['birthdate'] ?? '') . ($rcid !== '' ? '<br>บัตร ' . esc_html($rcid) : '') . '</small>' . ($flags ? '<br><span class="chip error">⚠ ' . esc_html(implode(' · ', $flags)) . '</span>' : '') . '</td>';
        } else echo '<td><b>' . esc_html($a['reg_ref']) . '</b><br><span class="chip error">ไม่พบข้อมูลลงทะเบียน</span></td>';
        echo '<td><form class="hn-form" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('ihub_ws_hn', '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_ws_hn"><input type="hidden" name="id" value="' . (int) $a['id'] . '"><input type="text" name="hn" value="' . esc_attr(($p['hn'] ?? '') ?: ($reg['hn'] ?? '')) . '" placeholder="HN" required> <button class="button">' . ($a['verified'] ? 'แก้ HN' : 'บันทึก HN') . '</button></form>' . ($a['verified'] ? '<small class="hn-ok">✓ HN ตรวจแล้ว</small>' : '') . '</td>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- nonce field
        $rc = $p['rechecked'] ?? null;
        echo '<td>' . (is_array($rc) ? '<small class="hn-ok">✓ ' . esc_html($rc['by'] . ' ' . ihub_format_datetime($rc['at'])) . '</small><br>' : '') . '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('ihub_ws_recheck', '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_ws_recheck"><input type="hidden" name="id" value="' . (int) $a['id'] . '"><button class="button button-small' . (is_array($rc) ? '' : ' button-primary') . '">' . (is_array($rc) ? 'ตรวจอีกครั้ง' : 'ตรวจข้อมูลแล้ว') . '</button></form></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
    echo '</tbody></table>';
}
function ihub_ws_search_form($tab, $q, $days) {
    echo '<form method="get" class="ihub-ws-search"><input type="hidden" name="page" value="ihub-desk"><input type="hidden" name="tab" value="' . esc_attr($tab) . '"><input type="search" name="q" value="' . esc_attr($q) . '" placeholder="ค้นหา ชื่อ HN เลขบัตร เบอร์โทร เลขที่นัด"> <select name="days">';
    foreach ([7 => '7 วันก่อน – ล่วงหน้า', 30 => '30 วันก่อน – ล่วงหน้า', 90 => '90 วันก่อน – ล่วงหน้า', 365 => '1 ปี'] as $k => $l) echo '<option value="' . (int) $k . '"' . selected($days, $k, false) . '>' . esc_html($l) . '</option>';
    echo '</select> <button class="button">ค้นหา</button></form>';
}

function ihub_ws_walkin_form() {
    $old = get_transient('ihub_ws_walkin_' . get_current_user_id());
    delete_transient('ihub_ws_walkin_' . get_current_user_id());
    $v = function ($k, $d = '') use ($old) { return esc_attr(is_array($old) && isset($old[$k]) ? (string) $old[$k] : $d); };
    $sel = function ($k, $val) use ($old) { return is_array($old) && ($old[$k] ?? '') === $val ? ' selected' : ''; };
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('ihub_ws_walkin', '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_ws_walkin"><div class="ihub-ws-form">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label>เอกสาร<select name="w[doc_type]"><option value="thai_id">บัตรประชาชน</option><option value="passport"' . $sel('doc_type', 'passport') . '>Passport</option></select></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label>เลขบัตรประชาชน<input name="w[cid]" value="' . $v('cid') . '" inputmode="numeric" maxlength="17"></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label>เลข Passport<input name="w[passport_no]" value="' . $v('passport_no') . '"></label><label>สัญชาติ (3 ตัว เช่น GBR)<input name="w[nationality]" value="' . $v('nationality') . '" maxlength="3"></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label>คำนำหน้า<input name="w[prefix]" value="' . $v('prefix') . '" placeholder="นาย / นาง / Mr."></label><label>ชื่อ *<input name="w[first_name]" value="' . $v('first_name') . '" required></label><label>นามสกุล *<input name="w[last_name]" value="' . $v('last_name') . '" required></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label>เพศ *<select name="w[sex]" required><option value="">—</option><option value="male"' . $sel('sex', 'male') . '>ชาย</option><option value="female"' . $sel('sex', 'female') . '>หญิง</option></select></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label>วันเกิด *<input type="date" name="w[birthdate]" value="' . $v('birthdate') . '" required></label><label>โทรศัพท์ *<input name="w[phone]" value="' . $v('phone') . '" required inputmode="tel"></label><label>อีเมล<input type="email" name="w[email]" value="' . $v('email') . '"></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label>แพ้ยา<input name="w[drug_allergy]" value="' . $v('drug_allergy') . '"></label><label>ผู้ติดต่อฉุกเฉิน<input name="w[emergency_name]" value="' . $v('emergency_name') . '"></label><label>โทรผู้ติดต่อฉุกเฉิน<input name="w[emergency_phone]" value="' . $v('emergency_phone') . '"></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label class="wide">ที่อยู่<textarea name="w[address]" rows="2">' . esc_textarea(is_array($old) ? (string) ($old['address'] ?? '') : '') . '</textarea></label></div>';
    echo '<p class="description">ตรวจเอกสารตัวจริงที่เคาน์เตอร์ และให้ผู้ป่วยลงนามยินยอมตามแบบฟอร์มของโรงพยาบาล</p><p><button class="button button-primary button-large">บันทึกผู้ป่วย walk-in</button></p></form>';
}

function ihub_ws_desk_page() {
    if (!ihub_ws_desk_cap()) wp_die('ไม่มีสิทธิ์');
    $tab = sanitize_key($_GET['tab'] ?? 'today'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $has_appt = function_exists('idev_appt_unchecked');
    $has_reg = function_exists('idev_medreg_counts') && current_user_can('idev_medreg');
    $can_hn = $has_appt && idev_appt_can_check_hn();
    $unchecked = $can_hn ? idev_appt_unchecked() : [];
    $counts = $has_reg ? idev_medreg_counts() : null;
    $u = function ($t) { return esc_url(admin_url('admin.php?page=ihub-desk&tab=' . $t)); };
    echo '<div class="wrap ihub-ws"><h1>ห้องบัตร</h1><p class="sub">' . esc_html(ihub_ws_date(current_time('Y-m-d'))) . ' · ผู้ป่วยใหม่ ตรวจสอบ HN และข้อมูลนัดหมาย</p>';
    ihub_ws_notices();
    $tabs = ['today' => 'ภาพรวมวันนี้'];
    if ($can_hn) $tabs['hn'] = 'HN ที่ต้องตรวจสอบ (' . count($unchecked) . ')';
    if ($can_hn) $tabs['hnok'] = 'HN ตรวจแล้ว (แก้ไข)';
    if ($can_hn && function_exists('idev_appt_with_registration')) $tabs['regappt'] = 'ผู้ลงทะเบียนที่นัด online';
    if ($has_reg) $tabs['new'] = 'ผู้ป่วยใหม่ online / walk-in';
    if ($has_appt && current_user_can('idev_appt_manage')) $tabs['appts'] = 'ข้อมูลนัดหมายทั้งหมด';
    if (!isset($tabs[$tab])) $tab = 'today';
    echo '<nav class="nav-tab-wrapper">';
    foreach ($tabs as $k => $l) echo '<a class="nav-tab' . ($tab === $k ? ' nav-tab-active' : '') . '" href="' . $u($k) . '">' . esc_html($l) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</nav>';

    if ($tab === 'today') {
        global $wpdb;
        echo '<div class="ihub-ws-stats">';
        if ($counts) {
            echo '<a class="ihub-ws-stat info" href="' . esc_url(admin_url('admin.php?page=idev-medreg&status=pending')) . '"><small>ลงทะเบียน online รอตรวจ</small><b>' . (int) $counts['online'] . '</b><em>ตรวจเอกสาร แล้วออก HN</em></a>';
            echo '<a class="ihub-ws-stat vio" href="' . $u('new') . '"><small>walk-in รอออก HN</small><b>' . (int) $counts['walkin'] . '</b><em>ลงทะเบียนที่ห้องบัตร</em></a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            echo '<a class="ihub-ws-stat" href="' . esc_url(admin_url('admin.php?page=idev-medreg&status=approved')) . '"><small>อนุมัติแล้ว รอ HOSxP</small><b>' . (int) $counts['approved'] . '</b><em>ผู้ป่วยใหม่วันนี้ ' . (int) $counts['today'] . ' ราย</em></a>';
        }
        if ($has_appt) {
            $t = idev_appt_table();
            $today = idev_today();
            $n_today = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE appt_date=%s AND status IN ('pending','confirmed','completed')", $today)); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $n_pend = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE status='pending' AND appt_date>=%s", $today)); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ($can_hn) echo '<a class="ihub-ws-stat ' . ($unchecked ? 'bad' : '') . '" href="' . $u('hn') . '"><small>HN ที่ต้องตรวจสอบ</small><b>' . count($unchecked) . '</b><em>จากการนัดหมาย online</em></a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            echo '<a class="ihub-ws-stat" href="' . esc_url(admin_url('admin.php?page=idev-appt')) . '"><small>นัดหมายวันนี้</small><b>' . $n_today . '</b><em>ทุกแพทย์ / คลินิก</em></a>';
            echo '<a class="ihub-ws-stat warn" href="' . esc_url(admin_url('admin.php?page=idev-appt')) . '"><small>นัดรอยืนยัน</small><b>' . $n_pend . '</b><em>ตั้งแต่วันนี้</em></a>';
        }
        echo '</div><div class="ihub-ws-grid2">';
        if ($can_hn) { echo '<div class="ihub-ws-box"><h2>HN ที่ต้องตรวจสอบ <a href="' . $u('hn') . '">ทั้งหมด →</a></h2>'; ihub_ws_hn_table($unchecked, 8); echo '</div>'; } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        if ($has_reg) { echo '<div class="ihub-ws-box"><h2>ผู้ป่วยใหม่ล่าสุด <a href="' . $u('new') . '">ทั้งหมด →</a></h2>'; ihub_ws_reg_table(ihub_ws_registrations("status IN ('pending','approved','error')", 8)); echo '</div>'; } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '</div>';
    } elseif ($tab === 'hn') {
        echo '<div class="ihub-ws-box"><h2>นัดหมาย online ที่ HN ยังไม่ได้ตรวจสอบ</h2><p class="description">เทียบ HN ที่ผู้ป่วยกรอกกับ HOSxP (ชื่อ วันเกิด เบอร์โทร) ถ้าถูกต้องกด “ถูกต้อง / บันทึก” ถ้าไม่ถูกให้แก้เลข HN แล้วกดบันทึก · นัดที่ตรวจแล้วจะส่งเข้า HOSxP ต่อได้ (ถ้าเปิดตัวเชื่อม)</p>';
        ihub_ws_hn_table($unchecked);
        echo '</div>';
    } elseif ($tab === 'hnok') {
        $q = sanitize_text_field(wp_unslash($_GET['q'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $days = (int) ($_GET['days'] ?? 30); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        echo '<div class="ihub-ws-box"><h2>HN ที่ตรวจแล้ว — แก้ไขได้</h2><p class="description">ถ้าพบว่า HN ที่บันทึกไว้ผิด แก้เลขแล้วกด “แก้ HN” ระบบเก็บประวัติการแก้ไว้ในนัดหมาย และส่งเลขใหม่เข้า HOSxP (ถ้าเปิดตัวเชื่อม)</p>';
        ihub_ws_search_form('hnok', $q, $days);
        ihub_ws_hn_table(idev_appt_checked($days, $q), 0, true);
        echo '</div>';
    } elseif ($tab === 'regappt') {
        $q = sanitize_text_field(wp_unslash($_GET['q'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $days = (int) ($_GET['days'] ?? 30); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        echo '<div class="ihub-ws-box"><h2>ผู้ลงทะเบียน online ที่ทำนัด online — ตรวจข้อมูลซ้ำ</h2><p class="description">ผู้ลงทะเบียนนัดได้ทุกสถานะการลงทะเบียน (รอตรวจ / อนุมัติแล้ว / มี HN / ไม่อนุมัติ) — เทียบข้อมูลตอนนัดกับข้อมูลลงทะเบียน ระบบเตือนเมื่อชื่อ เบอร์ หรือเลขบัตรไม่ตรงกัน</p>';
        ihub_ws_search_form('regappt', $q, $days);
        ihub_ws_regappt_table(idev_appt_with_registration($days, $q));
        echo '</div>';
    } elseif ($tab === 'new') {
        $sub = sanitize_key($_GET['f'] ?? 'pending'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $filters = ['pending' => ["status='pending'", 'รอตรวจ / รอออก HN'], 'online' => ["method<>'walkin'", 'online ทั้งหมด'], 'walkin' => ["method='walkin'", 'walk-in ทั้งหมด'], 'done' => ["status='synced'", 'ออก HN แล้ว']];
        if (!isset($filters[$sub])) $sub = 'pending';
        $open = !empty($_GET['walkin']); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        echo '<div class="ihub-ws-box"><h2>ลงทะเบียนผู้ป่วยใหม่ walk-in</h2><details' . ($open ? ' open' : '') . '><summary class="button">＋ เพิ่มผู้ป่วย walk-in</summary><div style="margin-top:12px">';
        ihub_ws_walkin_form();
        echo '</div></details></div><div class="ihub-ws-box"><h2>รายการผู้ป่วยใหม่ <span>';
        foreach ($filters as $k => [, $l]) echo ' <a class="button button-small' . ($k === $sub ? ' button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ihub-desk&tab=new&f=' . $k)) . '">' . esc_html($l) . '</a>';
        echo '</span></h2>';
        ihub_ws_reg_table(ihub_ws_registrations($filters[$sub][0], 100));
        echo '<p><a href="' . esc_url(admin_url('admin.php?page=idev-medreg')) . '">เปิดหน้ารายการลงทะเบียนเต็ม (ค้นหา ตรวจเอกสาร ออก HN) →</a></p></div>';
    } elseif ($tab === 'appts') {
        echo '<p class="description">นัดหมายของทุกแพทย์และคลินิก — ดูข้อมูลผู้ป่วย ยืนยัน เลื่อน ยกเลิก และเพิ่มนัด</p>';
        echo idev_appt_portal_app(true); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped by iDev Appointments
    }
    echo '</div>';
}

/* ---------- ห้องตรวจ (แพทย์) ---------- */

function ihub_ws_room_page() {
    global $wpdb;
    if (!ihub_ws_room_cap()) wp_die('ไม่มีสิทธิ์');
    $ids = idev_appt_user_providers();
    $t = idev_appt_table();
    $today = idev_today();
    $monday = idev_add_days($today, -((int) wp_date('N', strtotime($today)) - 1));
    $sunday = idev_add_days($monday, 6);
    $hx = function_exists('idev_apro_hx_waiting');
    echo '<div class="wrap ihub-ws"><h1>ห้องตรวจ</h1><p class="sub">' . esc_html(ihub_ws_date($today)) . ' · ' . esc_html(wp_get_current_user()->display_name) . ' <a class="button" href="' . esc_url(admin_url('admin.php?page=idev-appt')) . '">เปิดปฏิทินนัดหมาย</a></p>';
    if (!$ids) { echo '<p>ยังไม่มีแพทย์หรือคลินิกที่ผูกกับบัญชีนี้ — ผู้ดูแลระบบผูกได้ที่หน้าแก้ไขแพทย์ (จองออนไลน์ → บัญชีแพทย์)</p></div>'; return; }
    $in = implode(',', array_map('intval', $ids));
    $count = function ($where, ...$args) use ($wpdb, $t, $in) { return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE provider_id=%d AND {$where}", ...$args)); }; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    echo '<div class="ihub-ws-doc">';
    foreach (array_slice($ids, 0, 12) as $pid) {
        $c_today = $count("appt_date=%s AND status IN ('pending','confirmed','completed')", $pid, $today);
        $c_pend = $count("appt_date>=%s AND status='pending'", $pid, $today);
        $c_week = $count("appt_date BETWEEN %s AND %s AND status IN ('pending','confirmed','completed')", $pid, $monday, $sunday);
        $w = $hx ? idev_apro_hx_waiting($pid) : null;
        echo '<div class="card"><h2>' . esc_html(ihub_ws_provider_name($pid)) . '</h2><div class="nums">';
        echo '<div class="num"><b>' . $c_today . '</b><small>นัด online วันนี้</small></div>';
        echo '<div class="num warn"><b>' . $c_pend . '</b><small>รอยืนยัน</small></div>';
        echo '<div class="num"><b>' . $c_week . '</b><small>นัดสัปดาห์นี้</small></div>';
        echo '<div class="num hx"><b>' . ($w ? (int) $w['waiting'] : '–') . '</b><small>รอตรวจ (HOSxP)</small></div>';
        echo '</div><p class="hxnote">' . ($w ? 'HOSxP: ตรวจแล้ววันนี้ ' . (int) $w['done'] . ' ราย · อัปเดต ' . esc_html(wp_date('H:i', $w['at'])) . ($w['stale'] ? ' (ข้อมูลเก่า — ตรวจสอบตัวเชื่อม)' : '') : 'จำนวนรอตรวจจาก HOSxP: ยังไม่ได้เชื่อม (ตัวเชื่อม HOSxP ของ Appointments Pro + รหัสแพทย์ HOSxP)') . '</p></div>';
    }
    echo '</div>';
    $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t} WHERE provider_id IN ({$in}) AND appt_date=%s AND status<>'cancelled' ORDER BY start_time, id", $today), ARRAY_A); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    echo '<div class="ihub-ws-box"><h2>นัดหมาย online วันนี้ (' . count($rows) . ')</h2>';
    if (!$rows) echo '<p class="empty">ไม่มีนัดวันนี้</p>';
    else {
        echo '<table><thead><tr><th>เวลา</th><th>ผู้ป่วย</th><th>HN</th><th class="hide-s">อาการ / เหตุผลที่มา</th><th>สถานะ</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            $a = idev_appt_hydrate($row);
            $p = $a['p'];
            echo '<tr><td><b>' . esc_html($a['start_time']) . '</b></td><td>' . esc_html($p['name'] ?? '—') . (count($ids) > 1 ? '<br><small>' . esc_html(ihub_ws_provider_name((int) $a['provider_id'])) . '</small>' : '') . '</td><td>' . esc_html($p['hn'] ?? '') . ($a['verified'] ? '' : ' <span class="chip pending">ยังไม่ตรวจ HN</span>') . '</td><td class="hide-s">' . esc_html($p['reason'] ?? '') . '</td><td><span class="chip ' . esc_attr($a['status']) . '">' . esc_html(ihub_ws_status_label($a['status'])) . '</span></td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '</div><script>setTimeout(function(){if(!document.hidden)location.reload()},120000)</script></div>';
}
