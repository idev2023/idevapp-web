<?php
/**
 * Working together with the iDevApp plugins (https://idevapp.me/).
 * When an iDev plugin that does the same job is active, iDevApp Hub hands that job over to it
 * (no double cookie banners, popups or announcement bars) and keeps its own functions working for the theme.
 */
defined('ABSPATH') || exit;

function ihub_idev_plugins() {
    return [
        'bilingual' => 'idev-bilingual/idev-bilingual.php',
        'schedule' => ['idev-clinic-schedule/idev-clinic-schedule.php', 'i-clinic/i-clinic.php', 'i-clinic-pro/i-clinic-pro.php', 'i-drug/i-drug.php'],
        'holidays' => ['idev-thai-holidays/idev-thai-holidays.php', 'i-clinic/i-clinic.php', 'i-clinic-pro/i-clinic-pro.php', 'i-drug/i-drug.php'],
        'popup' => 'idev-popup-notice/idev-popup-notice.php',
        'ticker' => 'idev-news-ticker/idev-news-ticker.php',
        'attachments' => 'idev-post-attachments/idev-post-attachments.php',
        'maps' => 'idev-maps/idev-maps.php',
        'cookie' => ['idev-cookie-consent/idev-cookie-consent.php', 'idev-cookie-consent-pro/idev-cookie-consent-pro.php'],
        // Pro versions and the I-Clinic / I-Drug packages include the free plugin.
        'registration' => ['idev-patient-registration/idev-patient-registration.php', 'idev-patient-registration-pro/idev-patient-registration-pro.php', 'i-clinic/i-clinic.php', 'i-clinic-pro/i-clinic-pro.php', 'i-drug/i-drug.php'],
    ];
}

/** Is this feature handled by an active iDev plugin? (Decided once, when plugins load.) */
function ihub_uses($feature) {
    static $active = null;
    if ($active === null) {
        $list = (array) get_option('active_plugins', []);
        if (is_multisite()) $list = array_merge($list, array_keys((array) get_site_option('active_sitewide_plugins', [])));
        $active = [];
        foreach (ihub_idev_plugins() as $f => $files) $active[$f] = (bool) array_intersect((array) $files, $list);
    }
    return (bool) apply_filters('ihub_uses_idev', $active[$feature] ?? false, $feature);
}

/* Settings → iDevApp Hub: show which parts are now run by iDev plugins. */
add_action('admin_notices', function () {
    $screen = get_current_screen();
    if (!$screen || strpos((string) $screen->id, 'idevapp-hub') === false) return;
    $names = ['bilingual' => 'สองภาษา TH/EN', 'schedule' => 'ตารางออกตรวจ / ทีมแพทย์ / เวลาทำการ', 'holidays' => 'วันหยุด', 'popup' => 'Popup', 'ticker' => 'ประกาศวิ่ง', 'attachments' => 'ไฟล์แนบข่าว', 'maps' => 'แผนที่ / ปุ่มนำทาง', 'cookie' => 'แบนเนอร์คุกกี้ PDPA', 'registration' => 'ลงทะเบียนผู้ป่วยใหม่'];
    $on = array_filter(array_keys($names), 'ihub_uses');
    if (!$on) return;
    echo '<div class="notice notice-info"><p><strong>ใช้โมดูลของ iDevApp Website:</strong> ' . esc_html(implode(' · ', array_map(function ($k) use ($names) { return $names[$k]; }, $on))) . ' — ตั้งค่าส่วนเหล่านี้ที่เมนู <a href="' . esc_url(admin_url('admin.php?page=idevapp')) . '">iDevApp Website</a> (ค่าในหน้านี้สำหรับส่วนดังกล่าวจะไม่ถูกใช้)</p></div>';
});
