<?php
/** Annual holidays: filled automatically every year, editable; days that "close clinics" replace the schedule. */
defined('ABSPATH') || exit;

function ihub_holidays_table() {
    global $wpdb;
    return $wpdb->prefix . 'ihub_holidays';
}

function ihub_holidays_install() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $table = ihub_holidays_table();
    dbDelta("CREATE TABLE {$table} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  holiday_date date NOT NULL,
  name varchar(200) NOT NULL,
  name_en varchar(200) NOT NULL DEFAULT '',
  closes_clinics tinyint(1) NOT NULL DEFAULT 1,
  source varchar(20) NOT NULL DEFAULT 'manual',
  PRIMARY KEY  (id),
  UNIQUE KEY holiday_date_name (holiday_date,name(150)),
  KEY holiday_date (holiday_date)
) {$wpdb->get_charset_collate()};");
    update_option('ihub_db_version', IHUB_VERSION);
}

/** Thai public holidays on the same date every year. Lunar holidays and substitution days come from Google or by hand. */
function ihub_fixed_holidays() {
    return [
        ['01-01', 'วันขึ้นปีใหม่', "New Year's Day"], ['04-06', 'วันจักรี', 'Chakri Memorial Day'],
        ['04-13', 'วันสงกรานต์', 'Songkran Festival'], ['04-14', 'วันสงกรานต์', 'Songkran Festival'], ['04-15', 'วันสงกรานต์', 'Songkran Festival'],
        ['05-01', 'วันแรงงานแห่งชาติ', 'National Labour Day'], ['05-04', 'วันฉัตรมงคล', 'Coronation Day'],
        ['06-03', 'วันเฉลิมพระชนมพรรษาสมเด็จพระราชินี', "Queen Suthida's Birthday"], ['07-28', 'วันเฉลิมพระชนมพรรษาพระบาทสมเด็จพระเจ้าอยู่หัว', "King's Birthday"],
        ['08-12', 'วันแม่แห่งชาติ', "Mother's Day"], ['10-13', 'วันนวมินทรมหาราช', 'King Bhumibol Memorial Day'], ['10-23', 'วันปิยมหาราช', 'Chulalongkorn Day'],
        ['12-05', 'วันพ่อแห่งชาติ', "Father's Day"], ['12-10', 'วันรัฐธรรมนูญ', 'Constitution Day'], ['12-31', 'วันสิ้นปี', "New Year's Eve"],
    ];
}

function ihub_get_holidays($from, $to) {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare('SELECT id, holiday_date, name, name_en, closes_clinics, source FROM ' . ihub_holidays_table() . ' WHERE holiday_date BETWEEN %s AND %s ORDER BY holiday_date, name', $from, $to), ARRAY_A);
    foreach ($rows ?: [] as &$row) { $row['closes_clinics'] = (bool) (int) $row['closes_clinics']; $row['holiday_date'] = substr($row['holiday_date'], 0, 10); }
    return $rows ?: [];
}

/** Inserts a holiday unless the same name already exists on that date. Returns true when added. */
function ihub_insert_holiday($date, $name, $name_en = '', $closes = true, $source = 'manual') {
    global $wpdb;
    $table = ihub_holidays_table();
    if ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE holiday_date=%s AND name=%s", $date, $name))) return false;
    return (bool) $wpdb->insert($table, ['holiday_date' => $date, 'name' => mb_substr($name, 0, 200), 'name_en' => mb_substr($name_en, 0, 200), 'closes_clinics' => $closes ? 1 : 0, 'source' => $source]);
}

function ihub_add_fixed_holidays($year) {
    $added = 0;
    foreach (ihub_fixed_holidays() as [$monthday, $name, $name_en]) $added += ihub_insert_holiday("{$year}-{$monthday}", $name, $name_en, true, 'builtin') ? 1 : 0;
    return $added;
}

function ihub_parse_ics($text) {
    $lines = preg_split('/\r?\n/', preg_replace('/\r?\n[ \t]/', '', (string) $text));
    $events = []; $current = null;
    foreach ($lines as $line) {
        if ($line === 'BEGIN:VEVENT') $current = [];
        elseif ($line === 'END:VEVENT') { if (!empty($current['date']) && !empty($current['summary'])) $events[] = $current + ['description' => '']; $current = null; }
        elseif (is_array($current) && strpos($line, ':') !== false) {
            [$key, $value] = explode(':', $line, 2);
            $value = trim(str_replace(['\\,', '\\n'], [',', "\n"], $value));
            if (strpos($key, 'DTSTART') === 0 && preg_match('/^(\d{4})(\d{2})(\d{2})/', $value, $m)) $current['date'] = "{$m[1]}-{$m[2]}-{$m[3]}";
            elseif ($key === 'SUMMARY') $current['summary'] = $value;
            elseif ($key === 'DESCRIPTION') $current['description'] = $value;
        }
    }
    return $events;
}

function ihub_fetch_ics($lang) {
    $url = "https://calendar.google.com/calendar/ical/{$lang}.th%23holiday%40group.v.calendar.google.com/public/basic.ics";
    $response = wp_remote_get($url, ['timeout' => 8]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) throw new Exception('Google Calendar unreachable');
    return ihub_parse_ics(wp_remote_retrieve_body($response));
}

/** Thai public holidays (with lunar and substitution days) from Google's public calendar. */
function ihub_import_google_holidays($year) {
    $th = ihub_fetch_ics('th');
    try { $en = ihub_fetch_ics('en'); } catch (Exception $e) { $en = []; }
    // Google marks days that are not days off as "Observance".
    $day_off = function ($event) { return !preg_match('/observance|วันสำคัญ/iu', $event['description']); };
    $english = [];
    foreach (array_filter($en, $day_off) as $event) $english[$event['date']] = $event['summary'];
    $added = 0;
    foreach (array_filter($th, $day_off) as $event) {
        if (strpos($event['date'], "{$year}-") !== 0) continue;
        $added += ihub_insert_holiday($event['date'], $event['summary'], $english[$event['date']] ?? '', true, 'google') ? 1 : 0;
    }
    return $added;
}

/** First time a year is shown, fill it (fixed days + Google when reachable). Once per year, so deletions stick. */
function ihub_ensure_holiday_years($years) {
    foreach (array_unique($years) as $year) {
        if ($year < 2000 || $year > 2100) continue;
        if (!add_option("ihub_holidays_seeded_{$year}", '1', '', false)) continue;
        ihub_add_fixed_holidays($year);
        try { ihub_import_google_holidays($year); } catch (Exception $e) { /* offline server: fixed days only */ }
    }
}

/* ---------- Admin page ---------- */

add_action('admin_menu', function () {
    add_submenu_page('idevapp-hub', 'วันหยุดประจำปี', 'วันหยุดประจำปี', 'edit_posts', 'ihub-holidays', 'ihub_render_holidays_page');
}, 20);

add_action('admin_post_ihub_holiday', function () {
    if (!current_user_can('edit_posts') || !check_admin_referer('ihub_holiday')) wp_die('ไม่มีสิทธิ์');
    global $wpdb;
    $table = ihub_holidays_table();
    $year = (int) ($_POST['year'] ?? gmdate('Y'));
    $do = sanitize_key($_POST['do'] ?? '');
    $back = ['page' => 'ihub-holidays', 'year' => $year];
    if ($do === 'fill') {
        $source = sanitize_key($_POST['source'] ?? 'builtin');
        try { $back['imported'] = $source === 'google' ? ihub_import_google_holidays($year) : ihub_add_fixed_holidays($year); }
        catch (Exception $e) { $back['error'] = 'google'; }
    } elseif ($do === 'delete') {
        $wpdb->delete($table, ['id' => (int) $_POST['id']]);
        $back['deleted'] = 1;
    } else {
        $date = sanitize_text_field(wp_unslash($_POST['holiday_date'] ?? ''));
        $name = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
        $data = ['holiday_date' => $date, 'name' => mb_substr($name, 0, 200), 'name_en' => mb_substr(sanitize_text_field(wp_unslash($_POST['name_en'] ?? '')), 0, 200), 'closes_clinics' => empty($_POST['closes_clinics']) ? 0 : 1];
        $id = (int) ($_POST['id'] ?? 0);
        if (!ihub_is_valid_date($date) || $name === '') $back['error'] = 'invalid';
        elseif ((int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE holiday_date=%s AND name=%s AND id<>%d", $date, $data['name'], $id))) $back['error'] = 'duplicate';
        elseif ($id) { $wpdb->update($table, $data, ['id' => $id]); $back['saved'] = 1; }
        else { $wpdb->insert($table, $data + ['source' => 'manual']); $back['saved'] = 1; }
    }
    wp_safe_redirect(add_query_arg($back, admin_url('admin.php')));
    exit;
});

function ihub_render_holidays_page() {
    $this_year = (int) substr(ihub_today(), 0, 4);
    $year = isset($_GET['year']) && preg_match('/^\d{4}$/', $_GET['year']) ? (int) $_GET['year'] : $this_year;
    ihub_ensure_holiday_years([$year]);
    $holidays = ihub_get_holidays("{$year}-01-01", "{$year}-12-31");
    $sources = ['builtin' => 'อัตโนมัติ', 'google' => 'Google', 'manual' => 'เพิ่มเอง'];
    $errors = ['invalid' => 'กรุณาเลือกวันที่และใส่ชื่อวันหยุด', 'duplicate' => 'มีวันหยุดชื่อนี้ในวันนั้นแล้ว', 'google' => 'ดึงข้อมูลจาก Google Calendar ไม่สำเร็จ (server อาจออกอินเทอร์เน็ตไม่ได้) เพิ่มเองได้ด้วยฟอร์มด้านบน'];
    $form = function ($fields, $button, $class = 'button') use ($year) {
        $html = '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="ihub-inline-form">' . wp_nonce_field('ihub_holiday', '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_holiday"><input type="hidden" name="year" value="' . $year . '">';
        foreach ($fields as $key => $value) $html .= '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
        return $html . '<button class="' . esc_attr($class) . '">' . esc_html($button) . '</button></form>';
    };
    echo '<div class="wrap ihub-admin"><h1>วันหยุดประจำปี ' . ($year + 543) . '</h1>';
    if (isset($_GET['saved'])) echo '<div class="notice notice-success"><p>บันทึกแล้ว</p></div>';
    if (isset($_GET['deleted'])) echo '<div class="notice notice-success"><p>ลบแล้ว</p></div>';
    if (isset($_GET['imported'])) echo '<div class="notice notice-success"><p>เพิ่มวันหยุด ' . (int) $_GET['imported'] . ' วัน (วันที่มีอยู่แล้วจะไม่ซ้ำ)</p></div>';
    if (isset($_GET['error'])) echo '<div class="notice notice-error"><p>' . esc_html($errors[$_GET['error']] ?? 'กรุณาตรวจสอบข้อมูล') . '</p></div>';
    $nav = admin_url('admin.php?page=ihub-holidays&year=');
    echo '<p class="ihub-year-nav"><a class="button" href="' . esc_url($nav . ($year - 1)) . '">← ' . ($year - 1 + 543) . '</a> <strong>พ.ศ. ' . ($year + 543) . ' (ค.ศ. ' . $year . ')</strong> <a class="button" href="' . esc_url($nav . ($year + 1)) . '">' . ($year + 1 + 543) . ' →</a></p>';
    echo '<div class="ihub-card"><h2>เพิ่มวันหยุด</h2><p class="description">วันที่ติ๊ก “ปิดคลินิก” จะไม่แสดงเวลาออกตรวจในตาราง แต่จะขึ้นป้ายวันหยุดแทน</p>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="ihub-holiday-form">' . wp_nonce_field('ihub_holiday', '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_holiday"><input type="hidden" name="year" value="' . $year . '">';
    echo '<label>วันที่<input type="date" name="holiday_date" required value="' . $year . '-01-01"></label><label>ชื่อวันหยุด<input name="name" required placeholder="เช่น วันมาฆบูชา, หยุดชดเชย"></label><label>Name (English)<input name="name_en" placeholder="Makha Bucha Day"></label><label class="ihub-check"><input type="checkbox" name="closes_clinics" value="1" checked> ปิดคลินิก</label><button class="button button-primary">เพิ่มวันหยุด</button></form>';
    echo '<p>' . $form(['do' => 'fill', 'source' => 'builtin'], '↻ เติมวันหยุดราชการ (วันที่คงที่) ปี ' . ($year + 543)) . ' ' . $form(['do' => 'fill', 'source' => 'google'], '⬇ ดึงวันหยุดไทยจาก Google Calendar (รวมวันพระ/หยุดชดเชย)') . '</p>';
    echo '<p class="description">ระบบเติมวันหยุดให้อัตโนมัติครั้งแรกที่มีการเปิดดูแต่ละปี วันหยุดตามจันทรคติ (มาฆบูชา วิสาขบูชา อาสาฬหบูชา เข้าพรรษา) และวันหยุดชดเชยเปลี่ยนทุกปี ให้ตรวจสอบ/เพิ่มเองหลัง ครม. ประกาศ</p></div>';
    echo '<div class="ihub-card"><h2>รายการวันหยุด (' . count($holidays) . ')</h2>';
    if (!$holidays) echo '<p>ยังไม่มีวันหยุดในปีนี้</p>';
    $days = ihub_t('doctors.days', 'th');
    foreach ($holidays as $h) {
        echo '<div class="ihub-holiday-item"><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('ihub_holiday', '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_holiday"><input type="hidden" name="year" value="' . $year . '"><input type="hidden" name="id" value="' . (int) $h['id'] . '">';
        echo '<span class="ihub-holiday-date"><strong>' . esc_html(ihub_format_day($h['holiday_date'], 'th')) . '</strong><small>วัน' . esc_html($days[ihub_iso_weekday($h['holiday_date']) - 1]) . ' · ' . esc_html($sources[$h['source']] ?? $h['source']) . '</small></span>';
        echo '<input type="date" name="holiday_date" value="' . esc_attr($h['holiday_date']) . '" aria-label="วันที่"><input name="name" value="' . esc_attr($h['name']) . '" aria-label="ชื่อวันหยุด"><input name="name_en" value="' . esc_attr($h['name_en']) . '" placeholder="English" aria-label="ชื่อภาษาอังกฤษ">';
        echo '<label class="ihub-check"><input type="checkbox" name="closes_clinics" value="1"' . checked($h['closes_clinics'], true, false) . '> ปิดคลินิก</label><button class="button">บันทึก</button></form>';
        echo $form(['do' => 'delete', 'id' => $h['id']], 'ลบ', 'button-link-delete ihub-confirm') . '</div>';
    }
    echo '</div></div>';
}
