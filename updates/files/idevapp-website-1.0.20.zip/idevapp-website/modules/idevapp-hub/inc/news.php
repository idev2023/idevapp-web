<?php
/** News cards, the home page tabs (latest N overall and per category) and the news index. */
defined('ABSPATH') || exit;

function ihub_news_url() {
    $page = (int) get_option('page_for_posts');
    return $page ? get_permalink($page) : home_url('/');
}

function ihub_post_category($post) {
    $terms = get_the_category($post->ID);
    return $terms ? $terms[0] : null;
}

function ihub_news_card($post) {
    $url = get_permalink($post);
    $style = get_post_meta($post->ID, 'ihub_display_style', true) ?: 'card';
    $image = get_the_post_thumbnail_url($post, 'large');
    $category = ihub_post_category($post);
    $title = get_the_title($post);
    $html = '<article class="news-card news-' . esc_attr($style) . '">';
    if ($image) $html .= '<a class="news-image" href="' . esc_url($url) . '"><img src="' . esc_url($image) . '" alt="" loading="lazy"></a>';
    $html .= '<div class="news-card-content"><div class="news-meta"><span class="news-category">' . esc_html(ihub_term_name($category)) . '</span><time class="news-date">' . esc_html(ihub_format_post_date($post)) . '</time></div>';
    $html .= '<h3><a href="' . esc_url($url) . '">' . $title . '</a></h3><p>' . esc_html(ihub_pick($post->post_excerpt, ihub_en_meta($post->ID, 'excerpt'))) . '</p>';
    $html .= '<a class="text-link" href="' . esc_url($url) . '">' . esc_html(ihub_t('news.readMore')) . ' <span>→</span></a></div></article>';
    return $html;
}

function ihub_empty_news($title = null, $text = null) {
    return '<div class="empty-news"><span>' . ihub_icon('news') . '</span><div><strong>' . esc_html($title ?? ihub_t('news.emptyTitle')) . '</strong><p>' . esc_html($text ?? ihub_t('news.emptyText')) . '</p></div></div>';
}

/** Categories that have published posts, most recently updated first. */
function ihub_news_categories() {
    $terms = get_terms(['taxonomy' => 'category', 'hide_empty' => true]);
    if (is_wp_error($terms)) return [];
    $latest = [];
    foreach ($terms as $term) {
        $post = get_posts(['category' => $term->term_id, 'numberposts' => 1, 'fields' => 'ids']);
        $latest[$term->term_id] = $post ? get_post_time('U', true, $post[0]) : 0;
    }
    usort($terms, function ($a, $b) use ($latest) { return $latest[$b->term_id] <=> $latest[$a->term_id]; });
    return $terms;
}

/** Home page news: "All" plus one tab per category, each with at most $limit posts. */
/** On the home page, news older than the age set at ประกาศข่าว › ตั้งค่า is left out (lists elsewhere stay complete). */
function ihub_news_age_args($args) {
    if (function_exists('idw_ann_months') && is_front_page() && ($m = idw_ann_months('news'))) $args['date_query'] = [['after' => $m . ' months ago', 'inclusive' => true]];
    return $args;
}
function ihub_render_news_browser($limit = 9, $show_tabs = true, $category_slug = '') {
    $limit = max(1, min(30, (int) $limit));
    if ($category_slug !== '') {
        $posts = get_posts(ihub_news_age_args(['numberposts' => $limit, 'category_name' => $category_slug]));
        if (!$posts) return ihub_empty_news();
        return '<div class="news-grid">' . implode('', array_map('ihub_news_card', $posts)) . '</div>';
    }
    $all = get_posts(ihub_news_age_args(['numberposts' => $limit]));
    if (!$all) return ihub_empty_news();
    $categories = $show_tabs ? ihub_news_categories() : [];
    $html = '';
    if (count($categories) > 1) {
        $html .= '<div class="news-tabs" role="tablist" aria-label="' . esc_attr(ihub_t('news.chooseCategory')) . '" data-ihub-tabs><button role="tab" aria-selected="true" class="active" data-tab="all">' . esc_html(ihub_t('news.all')) . '</button>';
        foreach ($categories as $term) $html .= '<button role="tab" aria-selected="false" data-tab="cat-' . (int) $term->term_id . '">' . esc_html(ihub_term_name($term)) . '</button>';
        $html .= '</div>';
    }
    $html .= '<div class="news-panel" data-panel="all"><div class="news-grid">' . implode('', array_map('ihub_news_card', $all)) . '</div></div>';
    if (count($categories) > 1) {
        foreach ($categories as $term) {
            $posts = get_posts(ihub_news_age_args(['numberposts' => $limit, 'cat' => $term->term_id]));
            $html .= '<div class="news-panel" data-panel="cat-' . (int) $term->term_id . '" hidden><div class="news-grid">' . implode('', array_map('ihub_news_card', $posts)) . '</div>';
            $html .= '<p class="news-more"><a class="text-link" href="' . esc_url(get_term_link($term)) . '">' . esc_html(ihub_t('newsExtra.viewAll')) . ' →</a></p></div>';
        }
    }
    return $html;
}

/** Category tabs for the news index (links, with counts). */
function ihub_render_news_tabs($current_term_id = 0) {
    $categories = ihub_news_categories();
    if (count($categories) < 2) return '';
    $html = '<nav class="news-tabs" aria-label="' . esc_attr(ihub_t('news.chooseCategory')) . '"><a href="' . esc_url(ihub_news_url()) . '"' . (!$current_term_id ? ' class="active" aria-current="page"' : '') . '>' . esc_html(ihub_t('news.all')) . '</a>';
    foreach ($categories as $term) {
        $active = (int) $current_term_id === (int) $term->term_id;
        $html .= '<a href="' . esc_url(get_term_link($term)) . '"' . ($active ? ' class="active" aria-current="page"' : '') . '>' . esc_html(ihub_term_name($term)) . ' <span class="tab-count">' . (int) $term->count . '</span></a>';
    }
    return $html . '</nav>';
}

function ihub_render_pagination() {
    global $wp_query;
    $pages = (int) $wp_query->max_num_pages;
    if ($pages < 2) return '';
    $page = max(1, (int) get_query_var('paged'));
    $prev = $page > 1 ? '<a href="' . esc_url(get_pagenum_link($page - 1)) . '">' . esc_html(ihub_t('newsExtra.prev')) . '</a>' : '<span></span>';
    $next = $page < $pages ? '<a href="' . esc_url(get_pagenum_link($page + 1)) . '">' . esc_html(ihub_t('newsExtra.next')) . '</a>' : '<span></span>';
    return '<nav class="pagination public-pagination" aria-label="' . esc_attr(ihub_t('newsExtra.page')) . '">' . $prev . '<span>' . esc_html(ihub_t('newsExtra.page')) . ' ' . $page . ' / ' . $pages . '</span>' . $next . '</nav>';
}

// News index: 9 per page; old addresses /news?category=X and /news?page=N redirect to the WordPress ones.
add_action('pre_get_posts', function ($query) {
    if (!is_admin() && $query->is_main_query() && ($query->is_home() || $query->is_category())) $query->set('posts_per_page', 9);
});
add_action('template_redirect', function () {
    if (!is_home() || empty($_GET)) return;
    if (!empty($_GET['category'])) {
        $term = get_term_by('name', sanitize_text_field(wp_unslash($_GET['category'])), 'category');
        if ($term) { wp_redirect(get_term_link($term), 301); exit; }
    }
});
