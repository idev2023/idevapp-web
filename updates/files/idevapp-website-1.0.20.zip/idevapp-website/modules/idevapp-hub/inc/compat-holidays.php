<?php
/** Holidays are managed by iDev Thai Holidays: the iDevApp Hub functions used by the schedule read from it. */
defined('ABSPATH') || exit;
function ihub_holidays_install() {}
function ihub_holidays_table() { return function_exists('idev_hol_table') ? idev_hol_table() : $GLOBALS['wpdb']->prefix . 'idev_holidays'; }
function ihub_get_holidays($from, $to) { return function_exists('idev_holidays_get') ? idev_holidays_get($from, $to) : []; }
function ihub_ensure_holiday_years($years) { if (function_exists('idev_holidays_ensure_years')) idev_holidays_ensure_years($years); }
