<?php
/**
 * Page blocks "iDevApp" (same sections as the old block editor): hero, heading, text, image, image+text, cards, news,
 * clinic schedule, map, contact band, buttons, gallery, spacer. Every text has Thai and English fields.
 * Server-rendered; the editor (assets/blocks.js) builds its side panel from ihub_block_types().
 */
defined('ABSPATH') || exit;

function ihub_bt($th = '', $en = '') { return ['th' => $th, 'en' => $en]; }

function ihub_block_types() {
    $icons = ihub_icon_options();
    $icons_none = array_merge([['none', '— ไม่แสดงไอคอน —']], $icons);
    $badge_tones = [['amber', 'เหลือง (เร็ว ๆ นี้)'], ['green', 'เขียว (เปิดให้บริการ)'], ['blue', 'ฟ้า'], ['rose', 'ชมพู/แดง']];
    $tones = []; foreach (ihub_tones() as $k => $l) $tones[] = [$k, $l];
    return [
        'hero' => ['slug' => 'hero', 'label' => 'แบนเนอร์หลัก (Hero)', 'description' => 'หัวข้อใหญ่ ภาพพื้นหลัง ปุ่มโทร/ลงทะเบียน และการ์ดสถานะ', 'icon' => 'star-filled',
            'data' => ['eyebrow' => ihub_bt('PRIMARY & EMERGENCY CARE', 'PRIMARY & EMERGENCY CARE'), 'title' => ihub_bt('หัวข้อหลัก', 'Main headline'), 'highlight' => ihub_bt(), 'text' => ihub_bt(), 'image' => '', 'showEmergency' => true, 'showRegister' => true, 'showAppointment' => true, 'showStatus' => false, 'status' => []],
            'fields' => [['eyebrow', 't', 'ข้อความเล็กด้านบน'], ['title', 't', 'หัวข้อ'], ['highlight', 't', 'หัวข้อบรรทัดที่ 2 (สีเน้น)'], ['text', 'ta', 'คำอธิบาย'], ['image', 'image', 'ภาพพื้นหลัง'],
                ['showEmergency', 'bool', 'ปุ่มโทรฉุกเฉิน'], ['showRegister', 'bool', 'ปุ่มลงทะเบียนผู้ป่วยใหม่ (ลิงก์จากหน้าตั้งค่า)'], ['showAppointment', 'bool', 'ปุ่มนัดหมาย (ลิงก์จากหน้าตั้งค่า)'], ['showStatus', 'bool', 'การ์ดสถานะ'],
                ['status', 'list', 'การ์ดสถานะ', ['max' => 6, 'item' => ['label' => 'General Clinic', 'text' => ihub_bt('เปิดให้บริการ', 'Open'), 'icon' => 'plus', 'tone' => 'green'], 'fields' => [['label', 'text', 'ป้ายเล็ก (อังกฤษ)'], ['auto', 'bool', 'สถานะเปิด/ปิดอัตโนมัติ (จากเวลาทำการในหน้าตั้งค่า)'], ['text', 't', 'ข้อความ (ใช้เมื่อไม่ได้เปิดสถานะอัตโนมัติ)'], ['icon', 'select', 'ไอคอน', $icons], ['tone', 'select', 'สี', [['green', 'เขียว'], ['pink', 'ชมพู'], ['blue', 'ฟ้า']]]]]]]],
        'heading' => ['slug' => 'heading', 'label' => 'หัวข้อส่วน', 'description' => 'หัวข้อส่วน พร้อมคำโปรยและลิงก์', 'icon' => 'heading',
            'data' => ['kicker' => ihub_bt(), 'title' => ihub_bt('หัวข้อใหม่', 'New heading'), 'text' => ihub_bt(), 'align' => 'left', 'linkText' => ihub_bt(), 'url' => ''],
            'fields' => [['kicker', 't', 'ข้อความเล็กด้านบน'], ['title', 't', 'หัวข้อ'], ['text', 'ta', 'คำโปรย'], ['align', 'select', 'จัดวาง', [['left', 'ชิดซ้าย'], ['center', 'กึ่งกลาง']]], ['linkText', 't', 'ข้อความลิงก์'], ['url', 'url', 'ลิงก์']]],
        'richtext' => ['slug' => 'richtext', 'label' => 'ข้อความสองภาษา', 'description' => 'ย่อหน้า หัวข้อย่อย รายการ ลิงก์ (ไทย/อังกฤษ)', 'icon' => 'editor-paragraph',
            'data' => ['html' => ihub_bt('<p>พิมพ์ข้อความที่นี่</p>', '')],
            'fields' => [['html', 'html', 'ข้อความ']]],
        'image' => ['slug' => 'image', 'label' => 'รูปภาพ', 'description' => 'รูปเดี่ยว พร้อมคำบรรยาย', 'icon' => 'format-image',
            'data' => ['url' => '', 'alt' => ihub_bt(), 'caption' => ihub_bt(), 'size' => 'normal', 'link' => ''],
            'fields' => [['url', 'image', 'รูป'], ['alt', 't', 'คำอธิบายรูป (alt)'], ['caption', 't', 'คำบรรยายใต้รูป'], ['size', 'select', 'ขนาด', [['normal', 'ปกติ'], ['wide', 'กว้าง'], ['full', 'เต็มจอ']]], ['link', 'url', 'ลิงก์เมื่อกดรูป']]],
        'mediaText' => ['slug' => 'media-text', 'label' => 'รูป + ข้อความ', 'description' => 'รูปด้านหนึ่ง ข้อความอีกด้าน', 'icon' => 'align-pull-left',
            'data' => ['image' => '', 'title' => ihub_bt('หัวข้อ', 'Heading'), 'html' => ihub_bt('<p>ข้อความ</p>', ''), 'imageSide' => 'left'],
            'fields' => [['image', 'image', 'รูป'], ['title', 't', 'หัวข้อ'], ['html', 'html', 'ข้อความ'], ['imageSide', 'select', 'รูปอยู่ด้าน', [['left', 'ซ้าย'], ['right', 'ขวา']]]]],
        'cards' => ['slug' => 'cards', 'label' => 'การ์ดบริการ', 'description' => 'การ์ดพร้อมไอคอน 2–4 คอลัมน์', 'icon' => 'grid-view',
            'data' => ['kicker' => ihub_bt(), 'title' => ihub_bt('บริการของเรา', 'Our services'), 'columns' => 3, 'iconStyle' => 'soft', 'iconSize' => 'large', 'align' => 'left', 'items' => [
                ['icon' => 'plus', 'tone' => 'mint', 'title' => ihub_bt('ชื่อบริการ', 'Service'), 'text' => ihub_bt('รายละเอียด', 'Details'), 'linkText' => ihub_bt(), 'url' => ''],
                ['icon' => 'emergency', 'tone' => 'rose', 'title' => ihub_bt('ชื่อบริการ', 'Service'), 'text' => ihub_bt('รายละเอียด', 'Details'), 'linkText' => ihub_bt(), 'url' => ''],
                ['icon' => 'xray', 'tone' => 'sky', 'title' => ihub_bt('ชื่อบริการ', 'Service'), 'text' => ihub_bt('รายละเอียด', 'Details'), 'linkText' => ihub_bt(), 'url' => '']]],
            'fields' => [['kicker', 't', 'ข้อความเล็กด้านบน'], ['title', 't', 'หัวข้อ'], ['columns', 'number', 'จำนวนคอลัมน์', ['min' => 2, 'max' => 4]],
                ['iconStyle', 'select', 'แบบไอคอน', [['soft', 'พื้นสีอ่อน'], ['solid', 'พื้นสีเต็ม ไอคอนขาว'], ['gradient', 'ไล่สี'], ['outline', 'เส้นขอบ']]],
                ['iconSize', 'select', 'ขนาดไอคอน', [['normal', 'ปกติ'], ['large', 'ใหญ่'], ['xl', 'ใหญ่มาก']]],
                ['align', 'select', 'จัดวาง', [['left', 'ชิดซ้าย'], ['center', 'กึ่งกลาง']]],
                ['items', 'list', 'การ์ด', ['max' => 12, 'item' => ['icon' => 'plus', 'tone' => 'mint', 'title' => ihub_bt('ชื่อบริการ', 'Service'), 'text' => ihub_bt(), 'linkText' => ihub_bt(), 'url' => ''], 'fields' => [['image', 'image', 'รูป (ไม่ใส่ก็ได้)'], ['imageMode', 'select', 'แสดงรูปแบบ', [['cover', 'รูปเต็มด้านบนการ์ด'], ['icon', 'รูปเล็กแทนไอคอน']]], ['title', 't', 'ชื่อ'], ['text', 'ta', 'รายละเอียด'], ['icon', 'select', 'ไอคอน', $icons_none], ['tone', 'select', 'สี', $tones], ['linkText', 't', 'ข้อความลิงก์'], ['url', 'url', 'ลิงก์']]]]]],
        'rates' => ['slug' => 'rates', 'label' => 'อัตราค่าบริการ', 'description' => 'ค่าบริการเริ่มต้น คนไทย/ต่างชาติ ในเวลา/นอกเวลา รายการราคา และรายการเสริม', 'icon' => 'money-alt',
            'data' => ['kicker' => ihub_bt('SERVICE RATES', 'SERVICE RATES'), 'title' => ihub_bt('อัตราค่าบริการทางการแพทย์', 'Medical service rates'), 'text' => ihub_bt(), 'image' => '',
                'priceView' => 'lang', 'tabThai' => ihub_bt('คนไทย', 'Thai'), 'tabForeign' => ihub_bt('ต่างชาติ', 'Foreigner'),
                'baseTitle' => ihub_bt('อัตราค่าบริการเริ่มต้น', 'Starting service rates'), 'baseTag' => ihub_bt('อัตรามาตรฐาน', 'Standard rate'),
                'officeLabel' => ihub_bt('ในเวลาราชการ', 'Office hours'), 'afterLabel' => ihub_bt('นอกเวลาราชการ', 'After hours'),
                'thaiOffice' => '', 'thaiAfter' => '', 'foreignOffice' => '', 'foreignAfter' => '',
                'includesLabel' => ihub_bt('ราคานี้รวมรายการดังต่อไปนี้แล้ว', 'This starting rate includes'), 'includesThai' => ihub_bt(), 'includesForeign' => ihub_bt(),
                'notice' => ihub_bt(), 'listTitle' => ihub_bt('รายการค่าบริการ', 'Service fees'), 'listSub' => ihub_bt(),
                'items' => [['name' => ihub_bt('รายการ', 'Item'), 'thai' => '', 'foreign' => '']],
                'addonName' => ihub_bt(), 'addonNote' => ihub_bt(), 'addonPrice' => '',
                'from' => ihub_bt('เริ่มต้น', 'From'), 'unit' => ihub_bt('บาท', 'THB')],
            'fields' => [['kicker', 't', 'ข้อความเล็กด้านบน'], ['title', 't', 'หัวข้อ'], ['text', 'ta', 'คำโปรย'], ['image', 'image', 'รูปด้านบน (ไม่ใส่ก็ได้)'],
                ['priceView', 'select', 'การแสดงราคา', [['lang', 'ตามภาษาของเว็บ (ไทย = ราคาคนไทย, English = ราคาต่างชาติ)'], ['both', 'แสดงทั้งสองราคาคู่กัน'], ['tabs', 'ปุ่มสลับคนไทย / ต่างชาติ']]],
                ['tabThai', 't', 'ชื่อราคาคนไทย'], ['tabForeign', 't', 'ชื่อราคาต่างชาติ'],
                ['baseTitle', 't', 'หัวข้อ ค่าบริการเริ่มต้น'], ['baseTag', 't', 'ป้ายเล็กข้างหัวข้อ'], ['officeLabel', 't', 'ชื่อช่อง ในเวลา'], ['afterLabel', 't', 'ชื่อช่อง นอกเวลา'],
                ['thaiOffice', 'text', 'คนไทย ในเวลา (บาท)'], ['thaiAfter', 'text', 'คนไทย นอกเวลา (บาท)'], ['foreignOffice', 'text', 'ต่างชาติ ในเวลา (บาท)'], ['foreignAfter', 'text', 'ต่างชาติ นอกเวลา (บาท)'],
                ['includesLabel', 't', 'หัวข้อ "ราคานี้รวม"'], ['includesThai', 'ta', 'ราคานี้รวม — คนไทย (บรรทัดละรายการ)'], ['includesForeign', 'ta', 'ราคานี้รวม — ต่างชาติ (บรรทัดละรายการ)'],
                ['notice', 'ta', 'หมายเหตุสำคัญ (กล่องสีเหลือง)'],
                ['listTitle', 't', 'หัวข้อรายการราคา'], ['listSub', 't', 'คำอธิบายเล็กข้างหัวข้อ'],
                ['items', 'list', 'รายการราคา', ['max' => 40, 'item' => ['name' => ihub_bt('รายการ', 'Item'), 'thai' => '', 'foreign' => ''], 'fields' => [['name', 't', 'ชื่อรายการ'], ['thai', 'text', 'ราคาคนไทย (บาท)'], ['foreign', 'text', 'ราคาต่างชาติ (บาท)']]]],
                ['addonName', 't', 'รายการเสริม (เช่น 3-D reconstruction)'], ['addonNote', 't', 'คำอธิบายรายการเสริม'], ['addonPrice', 'text', 'ราคารายการเสริม (บาท)'],
                ['from', 't', 'คำนำหน้าราคา (เริ่มต้น)'], ['unit', 't', 'หน่วยเงิน']]],
        'feature' => ['slug' => 'feature', 'label' => 'แนะนำคลินิก/บริการ', 'description' => 'ป้ายสถานะ หัวข้อ รูปใหญ่ ปุ่ม เหตุผลที่ควรเลือก รายการบริการ และกล่องประกาศ', 'icon' => 'heart',
            'data' => ['badge' => ihub_bt(), 'badgeTone' => 'amber', 'title' => ihub_bt('ชื่อคลินิก', 'Clinic name'), 'text' => ihub_bt(), 'image' => '',
                'button1Text' => ihub_bt('สอบถามผ่าน LINE', 'Ask us on LINE'), 'button1Url' => '', 'button2Text' => ihub_bt('โทรติดต่อ', 'Call us'), 'button2Url' => '',
                'whyTitle' => ihub_bt(), 'why' => [], 'servicesTitle' => ihub_bt(), 'services' => [], 'noticeTitle' => ihub_bt(), 'notice' => ihub_bt()],
            'fields' => [['badge', 't', 'ป้ายสถานะ (เช่น เปิดให้บริการเร็ว ๆ นี้)'], ['badgeTone', 'select', 'สีป้าย', $badge_tones], ['title', 't', 'หัวข้อ'], ['text', 'ta', 'คำอธิบาย'], ['image', 'image', 'รูปใหญ่'],
                ['button1Text', 't', 'ปุ่มที่ 1'], ['button1Url', 'url', 'ลิงก์ปุ่มที่ 1 (ว่าง = LINE จากหน้าตั้งค่า)'], ['button2Text', 't', 'ปุ่มที่ 2'], ['button2Url', 'url', 'ลิงก์ปุ่มที่ 2 (ว่าง = โทรเบอร์จากหน้าตั้งค่า)'],
                ['whyTitle', 't', 'หัวข้อ "ทำไมต้องเลือกเรา"'],
                ['why', 'list', 'จุดเด่น', ['max' => 6, 'item' => ['emoji' => '✅', 'title' => ihub_bt('หัวข้อ', 'Title'), 'text' => ihub_bt()], 'fields' => [['emoji', 'text', 'อีโมจิ/สัญลักษณ์'], ['title', 't', 'หัวข้อ'], ['text', 'ta', 'รายละเอียด']]]],
                ['servicesTitle', 't', 'หัวข้อรายการบริการ'],
                ['services', 'list', 'บริการ', ['max' => 12, 'item' => ['emoji' => '🩺', 'title' => ihub_bt('บริการ', 'Service'), 'text' => ihub_bt()], 'fields' => [['emoji', 'text', 'อีโมจิ/สัญลักษณ์'], ['title', 't', 'ชื่อบริการ'], ['text', 'ta', 'รายละเอียด']]]],
                ['noticeTitle', 't', 'หัวข้อกล่องประกาศ'], ['notice', 'ta', 'ข้อความกล่องประกาศ']]],
        'news' => ['slug' => 'news', 'label' => 'ข่าวสาร', 'description' => 'ข่าวล่าสุด เลือกหมวดได้', 'icon' => 'megaphone',
            'data' => ['kicker' => ihub_bt('NEWS & UPDATES', 'NEWS & UPDATES'), 'title' => ihub_bt('ข่าวสารและประกาศ', 'News and announcements'), 'category' => '', 'count' => 9, 'showTabs' => true, 'showAllLink' => true],
            'fields' => [['kicker', 't', 'ข้อความเล็กด้านบน'], ['title', 't', 'หัวข้อ'], ['category', 'category', 'หมวดข่าว'], ['count', 'number', 'จำนวนข่าว', ['min' => 1, 'max' => 30]], ['showTabs', 'bool', 'แท็บแยกหมวด (เมื่อแสดงทุกหมวด)'], ['showAllLink', 'bool', 'ลิงก์ “ข่าวสารทั้งหมด”']]],
        'doctors' => ['slug' => 'doctors', 'label' => 'ตารางออกตรวจ', 'description' => 'ตารางแพทย์/คลินิก แบบเดือน สัปดาห์ หรือวัน', 'icon' => 'calendar-alt',
            'data' => ['title' => ihub_bt('ตารางออกตรวจ', 'Clinic schedule'), 'text' => ihub_bt(), 'view' => 'week', 'showNavigation' => false],
            'fields' => [['title', 't', 'หัวข้อ'], ['text', 'ta', 'คำอธิบาย'], ['view', 'select', 'มุมมองเริ่มต้น', [['week', 'สัปดาห์'], ['month', 'เดือน'], ['day', 'วัน']]], ['showNavigation', 'bool', 'ปุ่มเปลี่ยนมุมมอง / เลื่อนวัน / กรองแพทย์-คลินิก']]],
        'map' => ['slug' => 'map', 'label' => 'Google Map', 'description' => 'แผนที่จากหน้าตั้งค่า', 'icon' => 'location-alt',
            'data' => ['title' => ihub_bt('แผนที่การเดินทาง', 'How to find us')],
            'fields' => [['title', 't', 'หัวข้อ']]],
        'cta' => ['slug' => 'cta', 'label' => 'แถบติดต่อ', 'description' => 'แถบเด่นพร้อมปุ่มโทรหรือลิงก์', 'icon' => 'phone',
            'data' => ['kicker' => ihub_bt('WE ARE HERE FOR YOU', 'WE ARE HERE FOR YOU'), 'title' => ihub_bt('ต้องการความช่วยเหลือ?', 'Need help?'), 'text' => ihub_bt(), 'buttonText' => ihub_bt(), 'url' => '', 'phoneButton' => true],
            'fields' => [['kicker', 't', 'ข้อความเล็กด้านบน'], ['title', 't', 'หัวข้อ'], ['text', 'ta', 'ข้อความ (เว้นว่าง = ที่อยู่)'], ['phoneButton', 'bool', 'ปุ่มโทร'], ['buttonText', 't', 'ข้อความปุ่มที่ 2'], ['url', 'url', 'ลิงก์ปุ่มที่ 2']]],
        'buttons' => ['slug' => 'buttons', 'label' => 'ปุ่ม', 'description' => 'ปุ่มลิงก์หนึ่งหรือหลายปุ่ม', 'icon' => 'button',
            'data' => ['align' => 'left', 'items' => [['text' => ihub_bt('ปุ่ม', 'Button'), 'url' => '/', 'style' => 'teal']]],
            'fields' => [['align', 'select', 'จัดวาง', [['left', 'ชิดซ้าย'], ['center', 'กึ่งกลาง']]], ['items', 'list', 'ปุ่ม', ['max' => 6, 'item' => ['text' => ihub_bt('ปุ่ม', 'Button'), 'url' => '/', 'style' => 'teal'], 'fields' => [['text', 't', 'ข้อความ'], ['url', 'url', 'ลิงก์'], ['style', 'select', 'สี', [['teal', 'เขียว'], ['coral', 'แดง'], ['white', 'ขาว']]]]]]]],
        'gallery' => ['slug' => 'gallery', 'label' => 'แกลเลอรี', 'description' => 'รูปหลายรูปแบบตาราง', 'icon' => 'format-gallery',
            'data' => ['columns' => 3, 'items' => []],
            'fields' => [['columns', 'number', 'จำนวนคอลัมน์', ['min' => 2, 'max' => 4]], ['items', 'list', 'รูป', ['max' => 40, 'item' => ['url' => '', 'caption' => ihub_bt()], 'fields' => [['url', 'image', 'รูป'], ['caption', 't', 'คำบรรยาย']]]]]],
        'slider' => ['slug' => 'slider', 'label' => 'สไลด์ภาพ', 'description' => 'ภาพสไลด์เปลี่ยนอัตโนมัติ พร้อมหัวข้อและปุ่ม', 'icon' => 'slides',
            'data' => ['items' => [['image' => '', 'title' => ihub_bt('หัวข้อสไลด์', 'Slide title'), 'text' => ihub_bt(), 'buttonText' => ihub_bt(), 'url' => '']], 'autoplay' => true, 'interval' => 6, 'height' => 'normal', 'align' => 'left'],
            'fields' => [['items', 'list', 'สไลด์', ['max' => 10, 'item' => ['image' => '', 'title' => ihub_bt('หัวข้อสไลด์', 'Slide title'), 'text' => ihub_bt(), 'buttonText' => ihub_bt(), 'url' => ''], 'fields' => [['image', 'image', 'ภาพ'], ['title', 't', 'หัวข้อ'], ['text', 'ta', 'ข้อความ'], ['buttonText', 't', 'ข้อความปุ่ม'], ['url', 'url', 'ลิงก์ปุ่ม']]]],
                ['autoplay', 'bool', 'เลื่อนอัตโนมัติ'], ['interval', 'number', 'เปลี่ยนภาพทุก (วินาที)', ['min' => 3, 'max' => 12]], ['height', 'select', 'ความสูง', [['short', 'เตี้ย'], ['normal', 'ปกติ'], ['tall', 'สูง']]], ['align', 'select', 'ตำแหน่งข้อความ', [['left', 'ซ้าย'], ['center', 'กึ่งกลาง']]]]],
        'stats' => ['slug' => 'stats', 'label' => 'ตัวเลขสถิติ', 'description' => 'ตัวเลขเด่นนับขึ้นเมื่อเลื่อนมาถึง', 'icon' => 'chart-bar',
            'data' => ['kicker' => ihub_bt(), 'title' => ihub_bt(), 'items' => [['number' => '24', 'suffix' => ihub_bt('ชม.', 'h'), 'label' => ihub_bt('หน่วยฉุกเฉินพร้อมดูแล', 'Emergency care')], ['number' => '10', 'suffix' => ihub_bt('+', '+'), 'label' => ihub_bt('ปีที่ให้บริการ', 'Years of service')], ['number' => '20', 'suffix' => ihub_bt('+', '+'), 'label' => ihub_bt('แพทย์และพยาบาล', 'Doctors and nurses')]]],
            'fields' => [['kicker', 't', 'ข้อความเล็กด้านบน'], ['title', 't', 'หัวข้อ'], ['items', 'list', 'ตัวเลข', ['max' => 6, 'item' => ['number' => '100', 'suffix' => ihub_bt(), 'label' => ihub_bt('คำอธิบาย', 'Label')], 'fields' => [['number', 'text', 'ตัวเลข (เช่น 24, 1,200)'], ['suffix', 't', 'ต่อท้าย (เช่น +, ชม., %)'], ['label', 't', 'คำอธิบาย']]]]]],
        'faq' => ['slug' => 'faq', 'label' => 'คำถามพบบ่อย (FAQ)', 'description' => 'คำถาม-คำตอบ กดเปิด/ปิด', 'icon' => 'editor-help',
            'data' => ['kicker' => ihub_bt('FAQ', 'FAQ'), 'title' => ihub_bt('คำถามพบบ่อย', 'Frequently asked questions'), 'items' => [['q' => ihub_bt('ต้องนัดล่วงหน้าหรือไม่?', 'Do I need an appointment?'), 'a' => ihub_bt('คลินิกทั่วไป Walk-in ได้ หากต้องการพบแพทย์เฉพาะทางแนะนำให้นัดล่วงหน้า', 'Walk-ins are welcome at the general clinic. Please book ahead for specialists.')]]],
            'fields' => [['kicker', 't', 'ข้อความเล็กด้านบน'], ['title', 't', 'หัวข้อ'], ['items', 'list', 'คำถาม', ['max' => 30, 'item' => ['q' => ihub_bt('คำถาม', 'Question'), 'a' => ihub_bt()], 'fields' => [['q', 't', 'คำถาม'], ['a', 'ta', 'คำตอบ']]]]]],
        'steps' => ['slug' => 'steps', 'label' => 'ขั้นตอนการรับบริการ', 'description' => 'ขั้นตอน 1-2-3 พร้อมไอคอน', 'icon' => 'editor-ol',
            'data' => ['kicker' => ihub_bt('HOW IT WORKS', 'HOW IT WORKS'), 'title' => ihub_bt('ขั้นตอนการรับบริการ', 'Your visit, step by step'), 'items' => [
                ['icon' => 'plus', 'title' => ihub_bt('ลงทะเบียน', 'Register'), 'text' => ihub_bt('ยื่นบัตรประชาชนหรือพาสปอร์ตที่จุดลงทะเบียน', 'Show your ID card or passport at registration')],
                ['icon' => 'clock', 'title' => ihub_bt('ซักประวัติ', 'Screening'), 'text' => ihub_bt('พยาบาลวัดความดันและซักประวัติ', 'A nurse checks your vital signs')],
                ['icon' => 'emergency', 'title' => ihub_bt('พบแพทย์', 'See the doctor'), 'text' => ihub_bt('แพทย์ตรวจและให้คำแนะนำ', 'The doctor examines and advises you')],
                ['icon' => 'news', 'title' => ihub_bt('รับยา / ชำระเงิน', 'Medicine & payment'), 'text' => ihub_bt('รับยาและชำระค่าบริการ', 'Collect your medicine and pay')]]],
            'fields' => [['kicker', 't', 'ข้อความเล็กด้านบน'], ['title', 't', 'หัวข้อ'], ['items', 'list', 'ขั้นตอน', ['max' => 8, 'item' => ['icon' => 'plus', 'title' => ihub_bt('ขั้นตอน', 'Step'), 'text' => ihub_bt()], 'fields' => [['title', 't', 'ชื่อขั้นตอน'], ['text', 'ta', 'รายละเอียด'], ['icon', 'select', 'ไอคอน', $icons]]]]]],
        'video' => ['slug' => 'video', 'label' => 'วิดีโอ', 'description' => 'วิดีโอจาก YouTube หรือ Vimeo', 'icon' => 'video-alt3',
            'data' => ['url' => '', 'title' => ihub_bt(), 'caption' => ihub_bt()],
            'fields' => [['url', 'text', 'ลิงก์วิดีโอ YouTube / Vimeo'], ['title', 't', 'หัวข้อ'], ['caption', 't', 'คำบรรยายใต้วิดีโอ']]],
        'team' => ['slug' => 'team', 'label' => 'ทีมแพทย์', 'description' => 'รูป ประวัติ และลิงก์ตารางออกตรวจของแพทย์แต่ละท่าน (ดึงจากตารางออกตรวจ)', 'icon' => 'groups',
            'data' => ['kicker' => ihub_bt('OUR DOCTORS', 'OUR DOCTORS'), 'title' => ihub_bt('ทีมแพทย์ของเรา', 'Our doctors'), 'kind' => 'doctor', 'columns' => 3, 'showBio' => true, 'showSchedule' => true],
            'fields' => [['kicker', 't', 'ข้อความเล็กด้านบน'], ['title', 't', 'หัวข้อ'], ['kind', 'select', 'แสดง', [['doctor', 'เฉพาะแพทย์'], ['clinic', 'เฉพาะคลินิก'], ['all', 'ทั้งหมด']]], ['columns', 'number', 'จำนวนคอลัมน์', ['min' => 2, 'max' => 4]], ['showBio', 'bool', 'แสดงประวัติ'], ['showSchedule', 'bool', 'ปุ่ม “ดูตารางออกตรวจ”']]],
        'logos' => ['slug' => 'logos', 'label' => 'โลโก้ / สิทธิการรักษา', 'description' => 'โลโก้ประกัน สิทธิการรักษา หรือพันธมิตร', 'icon' => 'shield',
            'data' => ['kicker' => ihub_bt('INSURANCE & COVERAGE', 'INSURANCE & COVERAGE'), 'title' => ihub_bt('สิทธิการรักษาและประกันที่รับ', 'Coverage and insurance we accept'), 'columns' => 5, 'grayscale' => false, 'items' => [['image' => '', 'name' => ihub_bt('ประกันสังคม', 'Social Security'), 'url' => '']]],
            'fields' => [['kicker', 't', 'ข้อความเล็กด้านบน'], ['title', 't', 'หัวข้อ'], ['columns', 'number', 'จำนวนต่อแถว', ['min' => 2, 'max' => 6]], ['grayscale', 'bool', 'โลโก้สีเทา (สีขึ้นเมื่อชี้)'], ['items', 'list', 'โลโก้', ['max' => 40, 'item' => ['image' => '', 'name' => ihub_bt('ชื่อ', 'Name'), 'url' => ''], 'fields' => [['image', 'image', 'โลโก้'], ['name', 't', 'ชื่อ'], ['url', 'url', 'ลิงก์ (ถ้ามี)']]]]]],
        'registration' => ['slug' => 'registration', 'label' => 'ฟอร์มลงทะเบียนผู้ป่วยใหม่', 'description' => 'ยินยอม PDPA → ถ่ายบัตร → กรอกข้อมูล → ส่งให้เจ้าหน้าที่ (ตั้งค่าที่เมนู ลงทะเบียนผู้ป่วย)', 'icon' => 'id-alt',
            'data' => ['title' => ihub_bt(), 'text' => ihub_bt()],
            'fields' => [['title', 't', 'หัวข้อ (ไม่บังคับ)'], ['text', 'ta', 'คำอธิบาย (ไม่บังคับ)']]],
        'spacer' => ['slug' => 'spacer', 'label' => 'ระยะห่าง / เส้นคั่น', 'description' => 'เว้นช่องว่างระหว่างส่วน', 'icon' => 'image-flip-vertical',
            'data' => ['size' => 'medium', 'line' => false],
            'fields' => [['size', 'select', 'ขนาด', [['small', 'เล็ก'], ['medium', 'กลาง'], ['large', 'ใหญ่']]], ['line', 'bool', 'เส้นคั่น']]],
    ];
}

function ihub_block_settings_defaults($type) {
    return ['background' => $type === 'cta' ? 'dark' : ($type === 'news' ? 'light' : 'white'), 'spacing' => $type === 'hero' ? 'none' : 'normal', 'anchor' => '', 'hidden' => false];
}

/** Merges saved data with defaults (one level, plus list items) so missing keys never break rendering. */
function ihub_block_data($type, $data) {
    $defaults = ihub_block_types()[$type]['data'];
    $data = is_array($data) ? array_merge($defaults, $data) : $defaults;
    foreach ($defaults as $key => $value) {
        if (is_array($value) && isset($value['th']) && !is_array($data[$key])) $data[$key] = ihub_bt((string) $data[$key]);
    }
    return $data;
}

add_action('init', function () {
    foreach (ihub_block_types() as $type => $def) {
        register_block_type("idevapp/{$def['slug']}", [
            'api_version' => 3,
            'title' => $def['label'],
            'description' => $def['description'],
            'category' => 'idevapp',
            'icon' => $def['icon'],
            'attributes' => [
                'data' => ['type' => 'object', 'default' => $def['data']],
                'settings' => ['type' => 'object', 'default' => ihub_block_settings_defaults($type)],
                'align' => ['type' => 'string', 'default' => 'full'],
            ],
            'supports' => ['html' => false, 'align' => ['full'], 'customClassName' => false],
            'editor_script' => 'ihub-blocks',
            'render_callback' => function ($attributes) use ($type) { return ihub_render_block($type, $attributes); },
        ]);
    }
});

add_filter('block_categories_all', function ($categories) {
    array_unshift($categories, ['slug' => 'idevapp', 'title' => 'iDevApp (ออกแบบหน้า)', 'icon' => null]);
    return $categories;
});

add_action('init', function () {
    wp_register_script('ihub-blocks', IHUB_URL . 'assets/blocks.js', ['wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render', 'wp-data', 'editor'], IHUB_VERSION, true);
}, 5);

add_action('enqueue_block_editor_assets', function () {
    wp_enqueue_editor();
    wp_enqueue_media();
    $categories = [];
    foreach (get_terms(['taxonomy' => 'category', 'hide_empty' => false]) as $term) if (!is_wp_error($term)) $categories[] = [$term->slug, $term->name];
    $types = [];
    foreach (ihub_block_types() as $type => $def) $types[$type] = ['slug' => $def['slug'], 'label' => $def['label'], 'fields' => $def['fields'], 'data' => $def['data']];
    wp_add_inline_script('ihub-blocks', 'window.IHUB_BLOCKS = ' . wp_json_encode(['types' => $types, 'categories' => $categories, 'settings' => array_map('ihub_block_settings_defaults', array_combine(array_keys($types), array_keys($types)))], JSON_UNESCAPED_UNICODE) . ';', 'before');
    wp_enqueue_style('ihub-blocks-editor', IHUB_URL . 'assets/blocks-editor.css', [], IHUB_VERSION);
});

// Editor preview language (TH/EN buttons on each block).
add_action('rest_api_init', function () {
    if (isset($_GET['ihub_preview_lang'])) ihub_set_lang(sanitize_key($_GET['ihub_preview_lang']));
});

/* ---------- Rendering ---------- */

function ihub_block_heading($kicker, $title, $center = false) {
    $k = ihub_tx($kicker); $h = ihub_tx($title);
    if ($k === '' && $h === '') return '';
    return '<div class="pb-heading' . ($center ? ' is-center' : '') . '">' . ($k !== '' ? '<span class="section-kicker">' . esc_html($k) . '</span>' : '') . ($h !== '' ? '<h2>' . esc_html($h) . '</h2>' : '') . '</div>';
}

function ihub_rich($html) {
    $h = ihub_tx($html);
    // Rich text from the editor is HTML: line breaks between tags must not become gaps (.article-content keeps line breaks for plain text).
    $is_html = (bool) preg_match('/<(p|ul|ol|li|h[1-6]|div|table|br|blockquote)\b/i', $h);
    return '<div class="article-content' . ($is_html ? ' is-html' : '') . '">' . wp_kses_post($h) . '</div>';
}

/* ---------- Rates (Thai / foreigner switch without JavaScript) ---------- */

function ihub_money($v) { $v = trim((string) $v); return $v === '' ? '' : (is_numeric(str_replace(',', '', $v)) ? number_format((float) str_replace(',', '', $v), (float) str_replace(',', '', $v) == floor((float) str_replace(',', '', $v)) ? 0 : 2) : $v); }
function ihub_lines($t) { return array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string) $t)), 'strlen')); }
function ihub_render_rates($d) {
    static $n = 0; $n++;
    $id = 'ihub-rt-' . $n;
    $from = ihub_tx($d['from']); $unit = ihub_tx($d['unit']);
    // which prices: the site language (Thai site = Thai prices, English = foreign prices), both side by side, or switch buttons
    $view = in_array($d['priceView'] ?? 'lang', ['lang', 'both', 'tabs'], true) ? ($d['priceView'] ?? 'lang') : 'lang';
    $only = $view === 'lang' ? (ihub_lang() === 'en' ? 'fo' : 'th') : '';
    $names = ['th' => ihub_tx($d['tabThai']) ?: ihub_pick('คนไทย', 'Thai'), 'fo' => ihub_tx($d['tabForeign']) ?: ihub_pick('ต่างชาติ', 'Foreigner')];
    $price = function ($th, $fo, $cls = '') use ($from, $unit, $only, $view, $names) {
        $o = '';
        foreach (['th' => $th, 'fo' => $fo] as $k => $v) {
            if ($only && $k !== $only) continue;
            $o .= '<span class="ihub-rt-p p-' . $k . ' ' . $cls . '">' . ($view === 'both' ? '<em>' . esc_html($names[$k]) . '</em> ' : '') . (ihub_money($v) !== '' ? ($cls === 'big' || $view === 'both' ? '' : esc_html($from) . ' ') . '<b>' . esc_html(ihub_money($v)) . '</b> <small>' . esc_html($unit) . '</small>' : '—') . '</span>';
        }
        return $view === 'both' ? '<span class="ihub-rt-pp">' . $o . '</span>' : $o;
    };
    $h = '<div class="container ihub-rates is-' . $view . '" id="' . $id . '">';
    if ($view === 'tabs') $h .= '<input type="radio" name="' . $id . '" id="' . $id . '-th" class="ihub-rt-r r-th" checked><input type="radio" name="' . $id . '" id="' . $id . '-fo" class="ihub-rt-r r-fo">';
    $h .= '<div class="ihub-rt-card">';
    if ($d['image']) $h .= '<img class="ihub-rt-img" src="' . esc_url($d['image']) . '" alt="" loading="lazy">';
    if (ihub_tx($d['kicker']) . ihub_tx($d['title']) . ihub_tx($d['text']) !== '') $h .= '<div class="ihub-rt-head">' . (ihub_tx($d['kicker']) !== '' ? '<span class="ihub-rt-kicker">' . esc_html(ihub_tx($d['kicker'])) . '</span>' : '') . (ihub_tx($d['title']) !== '' ? '<h2>' . esc_html(ihub_tx($d['title'])) . '</h2>' : '') . (ihub_tx($d['text']) !== '' ? '<p>' . esc_html(ihub_tx($d['text'])) . '</p>' : '') . '</div>';
    if ($view === 'tabs') $h .= '<div class="ihub-rt-tabs" role="tablist"><label for="' . $id . '-th">' . esc_html($names['th']) . '</label><label for="' . $id . '-fo">' . esc_html($names['fo']) . '</label></div>';
    // starting rates
    if ($d['thaiOffice'] . $d['thaiAfter'] . $d['foreignOffice'] . $d['foreignAfter'] !== '') {
        $h .= '<section class="ihub-rt-sec"><div class="ihub-rt-sechead"><h3>💳 ' . esc_html(ihub_tx($d['baseTitle'])) . '</h3>' . (ihub_tx($d['baseTag']) !== '' ? '<span class="ihub-rt-tag">' . esc_html(ihub_tx($d['baseTag'])) . '</span>' : '') . '</div>';
        $h .= '<div class="ihub-rt-base"><div><span>☀️ ' . esc_html(ihub_tx($d['officeLabel'])) . '</span>' . $price($d['thaiOffice'], $d['foreignOffice'], 'big') . '</div><div><span>🌙 ' . esc_html(ihub_tx($d['afterLabel'])) . '</span>' . $price($d['thaiAfter'], $d['foreignAfter'], 'big') . '</div></div>';
        $inc_th = ihub_lines(ihub_tx($d['includesThai'])); $inc_fo = ihub_lines(ihub_tx($d['includesForeign']));
        foreach (['th' => $inc_th, 'fo' => $inc_fo] as $k => $list) if ($list && (!$only || $k === $only) && !($view === 'both' && $k === 'fo' && $list === $inc_th)) $h .= '<div class="ihub-rt-inc p-' . $k . '"><b>✅ ' . esc_html(ihub_tx($d['includesLabel'])) . ($view === 'both' && $inc_fo && $inc_fo !== $inc_th ? ' (' . esc_html($names[$k]) . ')' : '') . '</b><ul><li>' . implode('</li><li>', array_map('esc_html', $list)) . '</li></ul></div>';
        if (ihub_tx($d['notice']) !== '') $h .= '<div class="ihub-rt-notice"><span>⚠️</span><p>' . nl2br(esc_html(ihub_tx($d['notice']))) . '</p></div>';
        $h .= '</section>';
    }
    // price list
    $items = array_values(array_filter(is_array($d['items']) ? $d['items'] : [], function ($i) { return ihub_tx($i['name'] ?? '') !== ''; }));
    if ($items) {
        $h .= '<section class="ihub-rt-sec"><div class="ihub-rt-sechead"><h3>' . esc_html(ihub_tx($d['listTitle'])) . '</h3>' . (ihub_tx($d['listSub']) !== '' ? '<span class="ihub-rt-sub">' . esc_html(ihub_tx($d['listSub'])) . '</span>' : '') . '</div><ul class="ihub-rt-list">';
        foreach ($items as $i) $h .= '<li><span>' . esc_html(ihub_tx($i['name'])) . '</span>' . $price($i['thai'] ?? '', $i['foreign'] ?? '') . '</li>';
        $h .= '</ul>';
        if (ihub_tx($d['addonName']) !== '') $h .= '<div class="ihub-rt-addon"><span class="ihub-rt-addtag">ADD-ON</span><div><b>' . esc_html(ihub_tx($d['addonName'])) . '</b>' . (ihub_tx($d['addonNote']) !== '' ? '<small>' . esc_html(ihub_tx($d['addonNote'])) . '</small>' : '') . '</div><strong>+ ' . esc_html(ihub_money($d['addonPrice'])) . ' <small>' . esc_html($unit) . '</small></strong></div>';
        $h .= '</section>';
    }
    return $h . '</div></div>';
}

/* ---------- Clinic / service introduction ---------- */

function ihub_render_feature($d) {
    $tone = in_array($d['badgeTone'], ['amber', 'green', 'blue', 'rose'], true) ? $d['badgeTone'] : 'amber';
    $h = '<div class="container ihub-feature"><div class="ihub-ft-hero">';
    if (ihub_tx($d['badge']) !== '') $h .= '<span class="ihub-ft-badge t-' . $tone . '">' . esc_html(ihub_tx($d['badge'])) . '</span>';
    $h .= '<h2>' . esc_html(ihub_tx($d['title'])) . '</h2>' . (ihub_tx($d['text']) !== '' ? '<p class="ihub-ft-lead">' . esc_html(ihub_tx($d['text'])) . '</p>' : '');
    if ($d['image']) $h .= '<img class="ihub-ft-img" src="' . esc_url($d['image']) . '" alt="" loading="lazy">';
    $b1 = $d['button1Url'] ?: ihub_setting('line_url');
    $phone = preg_replace('/[^0-9+]/', '', (string) ihub_setting('phone'));
    $b2 = $d['button2Url'] ?: ($phone !== '' ? 'tel:' . $phone : '');
    $btn = '';
    if ($b1 && ihub_tx($d['button1Text']) !== '') $btn .= ihub_link($b1, '💬 ' . esc_html(ihub_tx($d['button1Text'])), 'button button-teal');
    if ($b2 && ihub_tx($d['button2Text']) !== '') $btn .= ihub_link($b2, '📞 ' . esc_html(ihub_tx($d['button2Text'])), 'button button-navy');
    if ($btn) $h .= '<div class="ihub-ft-btns">' . $btn . '</div>';
    $h .= '</div>';
    $why = array_values(array_filter(is_array($d['why']) ? $d['why'] : [], function ($i) { return ihub_tx($i['title'] ?? '') !== ''; }));
    if ($why) {
        $h .= '<section class="ihub-ft-why">' . (ihub_tx($d['whyTitle']) !== '' ? '<h3>' . esc_html(ihub_tx($d['whyTitle'])) . '</h3>' : '') . '<div class="ihub-ft-grid">';
        foreach ($why as $w) $h .= '<div><b>' . esc_html(trim(($w['emoji'] ?? '') . ' ' . ihub_tx($w['title']))) . '</b>' . (ihub_tx($w['text'] ?? '') !== '' ? '<p>' . esc_html(ihub_tx($w['text'])) . '</p>' : '') . '</div>';
        $h .= '</div></section>';
    }
    $srv = array_values(array_filter(is_array($d['services']) ? $d['services'] : [], function ($i) { return ihub_tx($i['title'] ?? '') !== ''; }));
    if ($srv) {
        $h .= '<section class="ihub-ft-srv">' . (ihub_tx($d['servicesTitle']) !== '' ? '<h3>' . esc_html(ihub_tx($d['servicesTitle'])) . '</h3>' : '') . '<ul>';
        foreach ($srv as $s2) $h .= '<li><span class="ihub-ft-ic">' . esc_html($s2['emoji'] ?? '') . '</span><div><b>' . esc_html(ihub_tx($s2['title'])) . '</b>' . (ihub_tx($s2['text'] ?? '') !== '' ? '<p>' . esc_html(ihub_tx($s2['text'])) . '</p>' : '') . '</div></li>';
        $h .= '</ul></section>';
    }
    if (ihub_tx($d['notice']) !== '') $h .= '<div class="ihub-ft-notice"><span>📢</span><div>' . (ihub_tx($d['noticeTitle']) !== '' ? '<b>' . esc_html(ihub_tx($d['noticeTitle'])) . '</b>' : '') . '<p>' . nl2br(esc_html(ihub_tx($d['notice']))) . '</p></div></div>';
    return $h . '</div>';
}

/** Our own themes style the blocks; any other theme gets the scoped stylesheet and a wrapper. */
function ihub_theme_native() {
    return (bool) array_intersect([get_stylesheet(), get_template()], ['idevapp-theme-1', 'idevapp-theme-2']);
}
function ihub_scope_wrap($html, $align = '') {
    if ($html === '' || ihub_theme_native() || (defined('REST_REQUEST') && REST_REQUEST) || is_admin()) return $html;
    return '<div class="ihub-scope' . ($align ? ' align' . $align : '') . '">' . $html . '</div>';
}
add_action('wp_enqueue_scripts', function () {
    if (ihub_theme_native()) return;
    wp_enqueue_style('ihub-fonts', 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Thai:wght@400;500;600;700&family=Manrope:wght@500;700;800&display=swap', [], null);
    wp_enqueue_style('ihub-any-theme', IHUB_URL . 'assets/blocks-any-theme.css', [], IHUB_VERSION);
    $c = function_exists('idw_brand_color') ? idw_brand_color() : '';
    if ($c && function_exists('idw_color_mix')) wp_add_inline_style('ihub-any-theme', '.ihub-scope{--teal:' . $c . ';--teal-dark:' . idw_color_mix($c, '#000000', .25) . '}');
});
add_filter('do_shortcode_tag', function ($out, $tag) {
    return in_array($tag, ['idevapp_map', 'idevapp_registration', 'idevapp_schedule', 'ihub_sitemap', 'idevapp_open_status'], true) ? ihub_scope_wrap((string) $out) : $out;
}, 10, 2);

function ihub_render_block($type, $attributes) {
    // block themes: blocks use the wide width, the hero the full width (classic themes ignore these classes)
    return ihub_scope_wrap(ihub_render_block_inner($type, $attributes), $type === 'hero' ? 'full' : 'wide');
}
function ihub_render_block_inner($type, $attributes) {
    $data = ihub_block_data($type, $attributes['data'] ?? []);
    $settings = array_merge(ihub_block_settings_defaults($type), is_array($attributes['settings'] ?? null) ? $attributes['settings'] : []);
    $editing = defined('REST_REQUEST') && REST_REQUEST;
    if (!empty($settings['hidden']) && !$editing) return '';
    $anchor = preg_replace('/[^\w-]/', '', (string) $settings['anchor']);
    $id = $anchor !== '' ? ' id="' . esc_attr($anchor) . '"' : '';
    $hidden = !empty($settings['hidden']) ? ' pb-hidden' : '';
    if ($type === 'hero') return '<div class="pb-wrap' . $hidden . '"' . $id . '>' . ihub_render_hero($data) . '</div>';
    $body = ihub_render_block_body($type, $data);
    if ($body === '') return $editing ? '<div class="pb-empty-preview">' . esc_html(ihub_block_types()[$type]['label']) . ' — ยังไม่มีเนื้อหา</div>' : '';
    $background = in_array($settings['background'], ['white', 'light', 'dark', 'teal'], true) ? $settings['background'] : 'white';
    $spacing = in_array($settings['spacing'], ['none', 'small', 'normal', 'large'], true) ? $settings['spacing'] : 'normal';
    $classes = 'pb-block pb-' . $type . ' bg-' . $background . ' sp-' . $spacing . ($type === 'cta' ? ' contact-band' : '') . $hidden;
    return '<section class="' . $classes . '"' . $id . '>' . $body . '</section>';
}

function ihub_render_hero($d) {
    $phone = ihub_setting('phone');
    $style = $d['image'] ? ' style="background-image:linear-gradient(90deg,rgba(13,26,41,.94) 0%,rgba(18,32,47,.77) 45%,rgba(11,35,45,.28) 100%),url(&quot;' . esc_url($d['image']) . '&quot;)"' : '';
    $status = !empty($d['showStatus']) && !empty($d['status']) && is_array($d['status']) ? array_slice($d['status'], 0, 6) : [];
    $html = '<section class="hero pb-hero' . ($status ? ' has-status' : '') . '"' . $style . '><div class="container hero-content">';
    if (ihub_tx($d['eyebrow']) !== '') $html .= '<span class="eyebrow"><span class="pulse"></span> ' . esc_html(ihub_tx($d['eyebrow'])) . '</span>';
    $highlight = ihub_tx($d['highlight']);
    $html .= '<h1>' . esc_html(ihub_tx($d['title'])) . ($highlight !== '' ? '<br><em>' . esc_html($highlight) . '</em>' : '') . '</h1>';
    if (ihub_tx($d['text']) !== '') $html .= '<p>' . esc_html(ihub_tx($d['text'])) . '</p>';
    $html .= '<div class="hero-actions">';
    if (!empty($d['showEmergency'])) $html .= '<a class="button button-coral" href="tel:' . esc_attr($phone) . '">' . ihub_icon('emergency') . ' ' . esc_html(ihub_t('home.emergencyCall')) . '</a>';
    if (!empty($d['showRegister']) && ihub_setting('registration_url')) $html .= '<a class="button button-teal" href="' . esc_url(ihub_setting('registration_url')) . '" target="_blank" rel="noopener noreferrer">' . ihub_icon('plus') . ' ' . esc_html(ihub_t('home.register')) . '</a>';
    if (!empty($d['showAppointment']) && ihub_setting('appointment_url')) $html .= '<a class="button button-white" href="' . esc_url(ihub_setting('appointment_url')) . '" target="_blank" rel="noopener noreferrer">' . ihub_icon('clock') . ' ' . esc_html(ihub_t('home.appointment')) . '</a>';
    $html .= '</div></div>';
    if ($status) {
        $html .= '<div class="container status-card" style="grid-template-columns:repeat(' . min(count($status), 3) . ',1fr)">';
        foreach ($status as $item) {
            $tone = in_array($item['tone'] ?? '', ['green', 'pink', 'blue'], true) ? $item['tone'] : 'green';
            if (!empty($item['auto'])) { $live = ihub_open_status(); $text = '<strong class="status-live is-' . $live['state'] . '">' . esc_html($live['text']) . '</strong>'; }
            else $text = '<strong>' . esc_html(ihub_tx($item['text'] ?? '')) . '</strong>';
            $html .= '<div class="status-item"><span class="status-icon ' . $tone . '">' . ihub_icon($item['icon'] ?? 'plus') . '</span><span><small>' . esc_html($item['label'] ?? '') . '</small>' . $text . '</span></div>';
        }
        $html .= '</div>';
    }
    return $html . '</section>';
}

function ihub_render_block_body($type, $d) {
    $phone = ihub_setting('phone');
    switch ($type) {
        case 'heading':
            $html = '<div class="container"><div class="pb-heading-block' . ($d['align'] === 'center' ? ' is-center' : '') . '">';
            if (ihub_tx($d['kicker']) !== '') $html .= '<span class="section-kicker">' . esc_html(ihub_tx($d['kicker'])) . '</span>';
            $html .= '<h2>' . esc_html(ihub_tx($d['title'])) . '</h2>';
            if (ihub_tx($d['text']) !== '') $html .= '<p>' . esc_html(ihub_tx($d['text'])) . '</p>';
            if ($d['url'] && ihub_tx($d['linkText']) !== '') $html .= ihub_link($d['url'], esc_html(ihub_tx($d['linkText'])) . ' →', 'text-link');
            return $html . '</div></div>';
        case 'richtext':
            return '<div class="container pb-narrow">' . ihub_rich($d['html']) . '</div>';
        case 'image':
            if (!$d['url']) return '';
            $img = '<img src="' . esc_url($d['url']) . '" alt="' . esc_attr(ihub_tx($d['alt'])) . '" loading="lazy">';
            $size = in_array($d['size'], ['normal', 'wide', 'full'], true) ? $d['size'] : 'normal';
            return '<figure class="pb-image size-' . $size . ($size === 'full' ? '' : ' container') . '">' . ($d['link'] ? ihub_link($d['link'], $img) : $img) . (ihub_tx($d['caption']) !== '' ? '<figcaption>' . esc_html(ihub_tx($d['caption'])) . '</figcaption>' : '') . '</figure>';
        case 'mediaText':
            $img = $d['image'] ? '<img src="' . esc_url($d['image']) . '" alt="" loading="lazy">' : '<div class="pb-image-placeholder"></div>';
            return '<div class="container pb-media-text image-' . ($d['imageSide'] === 'right' ? 'right' : 'left') . '">' . $img . '<div>' . (ihub_tx($d['title']) !== '' ? '<h2>' . esc_html(ihub_tx($d['title'])) . '</h2>' : '') . ihub_rich($d['html']) . '</div></div>';
        case 'cards':
            $cols = max(2, min(4, (int) $d['columns']));
            $style = in_array($d['iconStyle'] ?? '', ['soft', 'solid', 'gradient', 'outline'], true) ? $d['iconStyle'] : 'soft';
            $isize = in_array($d['iconSize'] ?? '', ['normal', 'large', 'xl'], true) ? $d['iconSize'] : 'large';
            $html = '<div class="container">' . ihub_block_heading($d['kicker'], $d['title']) . '<div class="service-grid pb-cards cols-' . $cols . ' icons-' . $style . ' icons-' . $isize . (($d['align'] ?? '') === 'center' ? ' is-center' : '') . '">';
            foreach (is_array($d['items']) ? $d['items'] : [] as $item) {
                $tone = array_key_exists($item['tone'] ?? '', ihub_tones()) ? $item['tone'] : 'mint';
                $as_icon = !empty($item['image']) && ($item['imageMode'] ?? 'cover') === 'icon';
                $img = !empty($item['image']) && !$as_icon ? '<img class="service-img" src="' . esc_url($item['image']) . '" alt="" loading="lazy">' : '';
                $icon = $as_icon ? '<span class="service-icon is-image ' . $tone . '"><img src="' . esc_url($item['image']) . '" alt="" loading="lazy"></span>'
                    : (($item['icon'] ?? 'plus') === 'none' ? '' : '<span class="service-icon ' . $tone . '">' . ihub_icon($item['icon'] ?? 'plus') . '</span>');
                $html .= '<article class="service-card' . ($img ? ' has-image' : '') . ($icon ? '' : ' no-icon') . '">' . $img . $icon . '<h3>' . esc_html(ihub_tx($item['title'] ?? '')) . '</h3>';
                if (ihub_tx($item['text'] ?? '') !== '') $html .= '<p>' . esc_html(ihub_tx($item['text'])) . '</p>';
                if (!empty($item['url']) && ihub_tx($item['linkText'] ?? '') !== '') $html .= ihub_link($item['url'], esc_html(ihub_tx($item['linkText'])) . ' →');
                $html .= '</article>';
            }
            return $html . '</div></div>';
        case 'rates':
            return ihub_render_rates($d);
        case 'feature':
            return ihub_render_feature($d);
        case 'news':
            $category = (string) $d['category'];
            $term = $category !== '' ? get_term_by('slug', $category, 'category') : null;
            $all = $term ? get_term_link($term) : ihub_news_url();
            $html = '<div class="container"><div class="section-heading">' . ihub_block_heading($d['kicker'], $d['title']);
            if (!empty($d['showAllLink'])) $html .= '<a href="' . esc_url($all) . '" class="text-link">' . esc_html(ihub_t('home.allNews')) . ' →</a>';
            return $html . '</div>' . ihub_render_news_browser((int) $d['count'], !empty($d['showTabs']), $term ? $term->slug : '') . '</div>';
        case 'doctors':
            $html = '<div class="container">' . ihub_block_heading(ihub_bt(), $d['title']);
            if (ihub_tx($d['text']) !== '') $html .= '<p class="pb-lead">' . esc_html(ihub_tx($d['text'])) . '</p>';
            $nav = !empty($d['showNavigation']);
            $view = in_array($d['view'], ['week', 'month', 'day'], true) ? $d['view'] : 'week';
            return $html . ihub_render_schedule([
                'view' => $nav && isset($_GET['view']) ? sanitize_key($_GET['view']) : $view, 'default_view' => $view,
                'date' => $nav && isset($_GET['date']) ? sanitize_text_field(wp_unslash($_GET['date'])) : '',
                'kind' => $nav && isset($_GET['kind']) ? sanitize_key($_GET['kind']) : '',
                'provider' => $nav && isset($_GET['provider']) ? (int) $_GET['provider'] : 0,
                'navigation' => $nav, 'base_url' => get_permalink() ?: home_url('/'),
            ]) . '</div>';
        case 'map':
            $map = ihub_render_map(ihub_tx($d['title']));
            return $map ? '<div class="container">' . $map . '</div>' : '';
        case 'cta':
            $text = ihub_tx($d['text']) ?: ihub_site_local()['address'];
            $html = '<div class="container contact-inner"><div>' . (ihub_tx($d['kicker']) !== '' ? '<span class="section-kicker">' . esc_html(ihub_tx($d['kicker'])) . '</span>' : '') . '<h2>' . esc_html(ihub_tx($d['title'])) . '</h2><p>' . esc_html($text) . '</p></div><div class="pb-cta-actions">';
            if (!empty($d['phoneButton'])) $html .= '<a class="button button-coral" href="tel:' . esc_attr($phone) . '">' . ihub_icon('phone') . ' ' . esc_html(ihub_t('home.call') . ' ' . $phone) . '</a>';
            if ($d['url'] && ihub_tx($d['buttonText']) !== '') $html .= ihub_link($d['url'], esc_html(ihub_tx($d['buttonText'])), 'button button-white');
            return $html . '</div></div>';
        case 'buttons':
            $html = '<div class="container pb-buttons align-' . ($d['align'] === 'center' ? 'center' : 'left') . '">';
            foreach (is_array($d['items']) ? $d['items'] : [] as $item) {
                $style = in_array($item['style'] ?? '', ['coral', 'teal', 'white'], true) ? $item['style'] : 'teal';
                if (!empty($item['url'])) $html .= ihub_link($item['url'], esc_html(ihub_tx($item['text'] ?? '')), 'button button-' . $style);
            }
            return $html . '</div>';
        case 'gallery':
            $items = array_filter(is_array($d['items']) ? $d['items'] : [], function ($item) { return !empty($item['url']); });
            if (!$items) return '';
            $html = '<div class="container pb-gallery cols-' . max(2, min(4, (int) $d['columns'])) . '">';
            foreach ($items as $item) {
                $caption = ihub_tx($item['caption'] ?? '');
                $html .= '<figure><a href="' . esc_url($item['url']) . '" target="_blank" rel="noopener"><img src="' . esc_url($item['url']) . '" alt="' . esc_attr($caption) . '" loading="lazy"></a>' . ($caption !== '' ? '<figcaption>' . esc_html($caption) . '</figcaption>' : '') . '</figure>';
            }
            return $html . '</div>';
        case 'slider':
            $items = array_values(array_filter(is_array($d['items']) ? $d['items'] : [], function ($i) { return !empty($i['image']) || ihub_tx($i['title'] ?? '') !== ''; }));
            if (!$items) return '';
            $height = in_array($d['height'], ['short', 'normal', 'tall'], true) ? $d['height'] : 'normal';
            $html = '<div class="ihub-slider h-' . $height . ' align-' . ($d['align'] === 'center' ? 'center' : 'left') . '" data-ihub-slider data-autoplay="' . (!empty($d['autoplay']) ? '1' : '0') . '" data-interval="' . max(3, min(12, (int) $d['interval'])) . '" aria-roledescription="carousel"><div class="ihub-slides">';
            foreach ($items as $i => $item) {
                $bg = !empty($item['image']) ? ' style="background-image:url(&quot;' . esc_url($item['image']) . '&quot;)"' : '';
                $html .= '<div class="ihub-slide' . ($i === 0 ? ' is-active' : '') . '"' . $bg . ' role="group" aria-roledescription="slide" aria-label="' . esc_attr(ihub_t('ui.slide') . ' ' . ($i + 1) . '/' . count($items)) . '"' . ($i ? ' aria-hidden="true"' : '') . '><div class="container ihub-slide-body">';
                if (ihub_tx($item['title'] ?? '') !== '') $html .= '<h2>' . esc_html(ihub_tx($item['title'])) . '</h2>';
                if (ihub_tx($item['text'] ?? '') !== '') $html .= '<p>' . esc_html(ihub_tx($item['text'])) . '</p>';
                if (!empty($item['url']) && ihub_tx($item['buttonText'] ?? '') !== '') $html .= ihub_link($item['url'], esc_html(ihub_tx($item['buttonText'])), 'button button-coral');
                $html .= '</div></div>';
            }
            $html .= '</div>';
            if (count($items) > 1) {
                $html .= '<button type="button" class="ihub-slider-arrow prev" data-ihub-prev aria-label="' . esc_attr(ihub_t('ui.prevSlide')) . '">‹</button><button type="button" class="ihub-slider-arrow next" data-ihub-next aria-label="' . esc_attr(ihub_t('ui.nextSlide')) . '">›</button><div class="ihub-slider-dots">';
                foreach ($items as $i => $item) $html .= '<button type="button" data-ihub-dot="' . $i . '"' . ($i === 0 ? ' class="active" aria-current="true"' : '') . ' aria-label="' . esc_attr(ihub_t('ui.slide') . ' ' . ($i + 1)) . '"></button>';
                $html .= '</div>';
            }
            return $html . '</div>';
        case 'stats':
            $items = is_array($d['items']) ? $d['items'] : [];
            if (!$items) return '';
            $html = '<div class="container">' . ihub_block_heading($d['kicker'], $d['title'], true) . '<div class="ihub-stats cols-' . min(4, max(2, count($items))) . '">';
            foreach ($items as $item) {
                $number = (string) ($item['number'] ?? '');
                $plain = str_replace(',', '', $number);
                $html .= '<div class="ihub-stat"><strong><span' . (is_numeric($plain) ? ' data-ihub-count="' . esc_attr($plain) . '"' : '') . '>' . esc_html($number) . '</span>' . esc_html(ihub_tx($item['suffix'] ?? '')) . '</strong><span>' . esc_html(ihub_tx($item['label'] ?? '')) . '</span></div>';
            }
            return $html . '</div></div>';
        case 'faq':
            $items = array_values(array_filter(is_array($d['items']) ? $d['items'] : [], function ($i) { return ihub_tx($i['q'] ?? '') !== ''; }));
            if (!$items) return '';
            $html = '<div class="container pb-narrow">' . ihub_block_heading($d['kicker'], $d['title'], true) . '<div class="ihub-faq">';
            $schema = [];
            foreach ($items as $i => $item) {
                $q = ihub_tx($item['q']); $a = ihub_tx($item['a'] ?? '');
                $html .= '<details class="ihub-faq-item"' . ($i === 0 ? ' open' : '') . '><summary>' . esc_html($q) . '</summary><div class="ihub-faq-answer">' . nl2br(esc_html($a)) . '</div></details>';
                $schema[] = ['@type' => 'Question', 'name' => $q, 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $a]];
            }
            $html .= '</div></div>';
            if (!(defined('REST_REQUEST') && REST_REQUEST)) $html .= '<script type="application/ld+json">' . wp_json_encode(['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $schema], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . '</script>';
            return $html;
        case 'steps':
            $items = is_array($d['items']) ? $d['items'] : [];
            if (!$items) return '';
            $html = '<div class="container">' . ihub_block_heading($d['kicker'], $d['title'], true) . '<ol class="ihub-steps cols-' . min(4, max(2, count($items))) . '">';
            foreach ($items as $i => $item) $html .= '<li class="ihub-step"><span class="ihub-step-icon">' . ihub_icon($item['icon'] ?? 'plus') . '<b>' . ($i + 1) . '</b></span><h3>' . esc_html(ihub_tx($item['title'] ?? '')) . '</h3>' . (ihub_tx($item['text'] ?? '') !== '' ? '<p>' . esc_html(ihub_tx($item['text'])) . '</p>' : '') . '</li>';
            return $html . '</ol></div>';
        case 'video':
            $src = ihub_video_embed_src($d['url']);
            if (!$src) return '';
            $title = ihub_tx($d['title']);
            $html = '<div class="container pb-narrow">' . ($title !== '' ? '<div class="pb-heading"><h2>' . esc_html($title) . '</h2></div>' : '') . '<figure class="ihub-video"><div class="ihub-video-frame">' . ihub_consent_iframe($src, $title ?: 'Video', 'video', 'allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" allowfullscreen') . '</div>';
            if (ihub_tx($d['caption']) !== '') $html .= '<figcaption>' . esc_html(ihub_tx($d['caption'])) . '</figcaption>';
            return $html . '</figure></div>';
        case 'team':
            if (ihub_uses('schedule') && function_exists('idev_cs_render_team')) {
                // Specialty tabs, photos and profiles from iDev Clinic Schedule.
                return '<div class="container">' . ihub_block_heading($d['kicker'], $d['title']) . idev_cs_render_team(['kind' => $d['kind'], 'columns' => max(2, min(4, (int) $d['columns'])), 'bio' => !empty($d['showBio']), 'schedule_link' => !empty($d['showSchedule']), 'tabs' => true]) . '</div>';
            }
            $people = array_values(array_filter(ihub_get_providers(), function ($p) use ($d) { return $d['kind'] === 'all' || $p['kind'] === $d['kind']; }));
            if (!$people) return '';
            $schedule = ihub_schedule_page_url();
            $html = '<div class="container">' . ihub_block_heading($d['kicker'], $d['title']) . '<div class="ihub-team cols-' . max(2, min(4, (int) $d['columns'])) . '">';
            foreach ($people as $p) {
                $photo = $p['photo_large'] ? '<img src="' . esc_url($p['photo_large']) . '" alt="" loading="lazy">' : '<span class="ihub-team-placeholder' . ($p['kind'] === 'clinic' ? ' is-clinic' : '') . '">' . ihub_icon($p['kind'] === 'clinic' ? 'plus' : 'emergency') . '</span>';
                $specialty = ihub_pick($p['specialty'], $p['specialty_en']);
                $bio = ihub_pick($p['bio'], $p['bio_en']);
                $html .= '<article class="ihub-team-card"><div class="ihub-team-photo">' . $photo . '</div><div class="ihub-team-body"><h3>' . esc_html(ihub_pick($p['name'], $p['name_en'])) . '</h3>' . ($specialty !== '' ? '<span class="ihub-team-specialty">' . esc_html($specialty) . '</span>' : '');
                if (!empty($d['showBio']) && $bio !== '') $html .= '<p>' . nl2br(esc_html($bio)) . '</p>';
                if (!empty($d['showSchedule']) && $p['slots']) $html .= '<a class="text-link" href="' . esc_url(add_query_arg('provider', $p['id'], $schedule)) . '">' . esc_html(ihub_t('ui.viewSchedule')) . ' →</a>';
                $html .= '</div></article>';
            }
            return $html . '</div></div>';
        case 'logos':
            $items = array_values(array_filter(is_array($d['items']) ? $d['items'] : [], function ($i) { return !empty($i['image']) || ihub_tx($i['name'] ?? '') !== ''; }));
            if (!$items) return '';
            $html = '<div class="container">' . ihub_block_heading($d['kicker'], $d['title'], true) . '<ul class="ihub-logos cols-' . max(2, min(6, (int) $d['columns'])) . (!empty($d['grayscale']) ? ' is-gray' : '') . '">';
            foreach ($items as $item) {
                $name = ihub_tx($item['name'] ?? '');
                $inner = (!empty($item['image']) ? '<img src="' . esc_url($item['image']) . '" alt="' . esc_attr($name) . '" loading="lazy">' : '') . ($name !== '' ? '<span>' . esc_html($name) . '</span>' : '');
                $html .= '<li>' . (!empty($item['url']) ? ihub_link($item['url'], $inner) : '<div>' . $inner . '</div>') . '</li>';
            }
            return $html . '</ul></div>';
        case 'registration':
            $html = '<div class="container pb-narrow">' . ihub_block_heading(ihub_bt(), $d['title']);
            if (ihub_tx($d['text']) !== '') $html .= '<p class="pb-lead">' . esc_html(ihub_tx($d['text'])) . '</p>';
            return $html . ihub_render_registration_form() . '</div>';
        case 'spacer':
            return '<div class="container pb-spacer size-' . (in_array($d['size'], ['small', 'medium', 'large'], true) ? $d['size'] : 'medium') . '">' . (!empty($d['line']) ? '<hr>' : '') . '</div>';
    }
    return '';
}

/** YouTube / Vimeo link → privacy-friendly embed address, or '' when not recognised. */
function ihub_video_embed_src($url) {
    $url = trim((string) $url);
    if (preg_match('#(?:youtube\.com/(?:watch\?(?:.*&)?v=|embed/|shorts/|live/)|youtu\.be/)([\w-]{11})#', $url, $m)) return 'https://www.youtube-nocookie.com/embed/' . $m[1] . '?rel=0';
    if (preg_match('#vimeo\.com/(?:video/)?(\d+)#', $url, $m)) return 'https://player.vimeo.com/video/' . $m[1] . '?dnt=1';
    return '';
}

/** Block markup for one block (used by the importer and the default home page). */
function ihub_block_markup($type, $data, $settings = []) {
    $def = ihub_block_types()[$type];
    $attrs = ['data' => $data, 'settings' => array_merge(ihub_block_settings_defaults($type), $settings)];
    // Same escaping as the block editor: no "--" (would end the HTML comment), no < > &.
    $json = str_replace('--', '\\u002d\\u002d', wp_json_encode($attrs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP));
    return '<!-- wp:idevapp/' . $def['slug'] . ' ' . $json . ' /-->';
}

/** The old built-in home page as blocks: hero with status, service cards, news, contact band. */
function ihub_default_home_blocks() {
    $s = ihub_settings();
    $hero = ['eyebrow' => ihub_bt('PRIMARY & EMERGENCY CARE', 'PRIMARY & EMERGENCY CARE'), 'title' => ihub_bt($s['hero_title'], $s['hero_title_en']), 'highlight' => ihub_bt($s['hero_highlight'], $s['hero_highlight_en']), 'text' => ihub_bt($s['hero_text'], $s['hero_text_en']), 'image' => '',
        'showEmergency' => true, 'showRegister' => true, 'showAppointment' => true, 'showStatus' => true, 'status' => [
            ['label' => 'General Clinic', 'auto' => true, 'text' => ihub_bt('เปิดให้บริการตามปกติ (Open)', 'Open as usual'), 'icon' => 'plus', 'tone' => 'green'],
            ['label' => 'Emergency Unit', 'text' => ihub_bt('สแตนด์บายตลอด 24 ชั่วโมง (24/7)', 'On standby 24/7'), 'icon' => 'emergency', 'tone' => 'pink'],
            ['label' => 'X-Ray & CT Scan', 'text' => ihub_bt('พร้อมให้บริการ (Available)', 'Available'), 'icon' => 'xray', 'tone' => 'blue']]];
    $cards = ['kicker' => ihub_bt('OUR SERVICES', 'OUR SERVICES'), 'title' => ihub_bt('ดูแลสุขภาพครบวงจร', 'Comprehensive health care'), 'columns' => 4, 'items' => [
        ['icon' => 'plus', 'tone' => 'mint', 'title' => ihub_bt('คลินิกเวชกรรมทั่วไป', 'General medical clinic'), 'text' => ihub_bt('ตรวจรักษาโรคทั่วไปโดยทีมแพทย์และบุคลากรผู้เชี่ยวชาญ', 'Diagnosis and treatment of common illnesses by our doctors and medical staff.'), 'linkText' => ihub_bt('รายละเอียดบริการ', 'Service details'), 'url' => '/services'],
        ['icon' => 'emergency', 'tone' => 'rose', 'title' => ihub_bt('หน่วยฉุกเฉิน 24 ชั่วโมง', '24-hour emergency unit'), 'text' => ihub_bt('ดูแลอุบัติเหตุและเหตุฉุกเฉิน พร้อมรถพยาบาลตลอดเวลา', 'Accident and emergency care with an ambulance on call at all times.'), 'linkText' => ihub_bt('ติดต่อเรา', 'Contact us'), 'url' => '/contact'],
        ['icon' => 'xray', 'tone' => 'sky', 'title' => ihub_bt('เอกซเรย์และ CT Scan', 'X-ray and CT scan'), 'text' => ihub_bt('บริการตรวจวินิจฉัยด้วยอุปกรณ์ทางการแพทย์ที่ทันสมัย', 'Diagnostic imaging with modern medical equipment.'), 'linkText' => ihub_bt('รายละเอียดบริการ', 'Service details'), 'url' => '/services'],
        ['icon' => 'travel', 'tone' => 'lavender', 'title' => ihub_bt('คลินิกนักเดินทาง', 'Travel clinic'), 'text' => ihub_bt('ให้คำแนะนำด้านสุขภาพและการเตรียมตัวก่อนออกเดินทาง', 'Health advice and preparation before your trip.'), 'linkText' => ihub_bt('รายละเอียดบริการ', 'Service details'), 'url' => '/travel-clinic']]];
    return implode("\n\n", [
        ihub_block_markup('hero', $hero),
        ihub_block_markup('cards', $cards),
        ihub_block_markup('news', ihub_block_types()['news']['data'], ['background' => 'light']),
        ihub_block_markup('cta', ihub_block_types()['cta']['data'], ['background' => 'dark']),
    ]);
}
