<?php
/**
 * Users and permissions (RBAC): roles made for the jobs at the medical center.
 * - roles: create, edit, copy, delete; each role is a set of permissions grouped by system
 * - users: give each person one or more roles
 * - suggested roles for the usual jobs; a change log
 * Menu "ผู้ใช้และสิทธิ์" (also in program mode). Roles: manage_options. Users: promote_users.
 */
defined('ABSPATH') || exit;

/** Permissions people can give, grouped by system: [group => [cap => [label, help]]]. */
function ihub_rbac_caps() {
    $g = [
        'นัดหมาย' => [
            'idev_appt_doctor' => ['นัดหมายของตัวเอง (แพทย์)', 'เห็นและจัดการนัดของแพทย์/คลินิกที่ผูกกับบัญชีนี้'],
            'idev_appt_manage' => ['นัดหมายของทุกแพทย์และคลินิก', 'ยืนยัน เลื่อน ยกเลิก และเพิ่มนัดให้ทุกคน'],
        ],
        'ลงทะเบียนผู้ป่วย' => [
            'idev_medreg' => ['รายการลงทะเบียนผู้ป่วยใหม่', 'ดูข้อมูลผู้ป่วย ตรวจเอกสาร ออก HN และส่งบัตรผู้ป่วย'],
        ],
        'ข่าวสาร ตารางออกตรวจ และเครื่องมือเว็บไซต์' => [
            'edit_posts' => ['เขียนข่าว และแก้ตารางออกตรวจ / แถบประกาศ / Popup', 'สิทธิ์พื้นฐานของงานเนื้อหา'],
            'publish_posts' => ['เผยแพร่ข่าว', 'ถ้าไม่ให้ ข่าวจะรอผู้มีสิทธิ์อนุมัติ'],
            'edit_published_posts' => ['แก้ข่าวที่เผยแพร่แล้ว', ''],
            'edit_others_posts' => ['แก้ข่าวและตารางของคนอื่น', ''],
            'delete_posts' => ['ลบข่าวของตัวเอง', ''],
            'delete_others_posts' => ['ลบข่าวของคนอื่น', ''],
            'upload_files' => ['อัปโหลดรูปและไฟล์', 'คลังสื่อ'],
        ],
        'หน้าเว็บไซต์' => [
            'edit_pages' => ['แก้หน้าเว็บ', ''],
            'publish_pages' => ['เผยแพร่หน้าเว็บ', ''],
            'edit_others_pages' => ['แก้หน้าเว็บของคนอื่น', ''],
            'edit_published_pages' => ['แก้หน้าที่เผยแพร่แล้ว', ''],
            'delete_pages' => ['ลบหน้าเว็บ', ''],
        ],
        'ผู้ใช้และระบบ' => [
            'list_users' => ['ดูรายชื่อผู้ใช้', ''],
            'create_users' => ['เพิ่มผู้ใช้', ''],
            'edit_users' => ['แก้ข้อมูลผู้ใช้', ''],
            'promote_users' => ['กำหนดบทบาทให้ผู้ใช้', 'หน้า “ผู้ใช้และสิทธิ์” แท็บผู้ใช้'],
            'delete_users' => ['ลบผู้ใช้', ''],
            'manage_options' => ['ตั้งค่าระบบทั้งหมด (ผู้ดูแลระบบ)', 'ตั้งค่าเว็บไซต์ นัดหมาย ลงทะเบียน และแก้บทบาท — ให้เฉพาะคนที่ไว้ใจได้'],
        ],
    ];
    return apply_filters('ihub_rbac_caps', $g);
}
function ihub_rbac_cap_list() { $all = []; foreach (ihub_rbac_caps() as $caps) $all += $caps; return $all; }

/** Suggested roles for the usual jobs. */
function ihub_rbac_presets() {
    $content = ['edit_posts', 'publish_posts', 'edit_published_posts', 'delete_posts', 'upload_files'];
    return [
        'ihub_doctor' => ['แพทย์', ['idev_appt_doctor']],
        'ihub_frontdesk' => ['เจ้าหน้าที่นัดหมาย / เวชระเบียน', ['idev_appt_manage', 'idev_medreg']],
        'ihub_pr' => ['ประชาสัมพันธ์ (ข่าวและประกาศ)', $content],
        'ihub_web' => ['ผู้ดูแลเนื้อหาเว็บไซต์', array_merge($content, ['edit_others_posts', 'delete_others_posts', 'edit_pages', 'publish_pages', 'edit_others_pages', 'edit_published_pages', 'delete_pages'])],
        'ihub_news_admin' => ['ผู้ดูแลข่าวประกาศ (อนุมัติข่าว)', array_merge($content, ['edit_others_posts', 'delete_others_posts', 'ihub_news_approve'])],
        'ihub_manager' => ['หัวหน้างาน', array_merge($content, ['edit_others_posts', 'idev_appt_manage', 'idev_medreg', 'list_users', 'promote_users'])],
    ];
}

function ihub_rbac_locked($role) { return $role === 'administrator'; }
function ihub_rbac_builtin($role) { return in_array($role, ['administrator', 'editor', 'author', 'contributor', 'subscriber'], true); }

function ihub_rbac_log($text) {
    $log = get_option('ihub_rbac_log', []);
    $log = is_array($log) ? $log : [];
    array_unshift($log, [current_time('mysql'), wp_get_current_user()->display_name, $text]);
    update_option('ihub_rbac_log', array_slice($log, 0, 100), false);
}

/** Roles that can be given in the users tab (administrator only by people who can manage everything). */
function ihub_rbac_assignable() {
    $roles = wp_roles()->get_names();
    if (!current_user_can('manage_options')) unset($roles['administrator']);
    return $roles;
}

add_action('admin_menu', function () {
    add_menu_page('ผู้ใช้และสิทธิ์', 'ผู้ใช้และสิทธิ์', 'promote_users', 'ihub-access', 'ihub_rbac_page', 'dashicons-shield', 70);
});

/* ---------- Saving ---------- */

add_action('admin_post_ihub_rbac', function () {
    if (!check_admin_referer('ihub_rbac')) wp_die('Forbidden', 403);
    $do = sanitize_key($_POST['do'] ?? '');
    $back = admin_url('admin.php?page=ihub-access');
    $msg = '';
    if (in_array($do, ['save_role', 'delete_role', 'presets'], true) && !current_user_can('manage_options')) wp_die('ไม่มีสิทธิ์', 403);
    if ($do === 'save_role') {
        $slug = sanitize_key($_POST['role'] ?? '');
        $name = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
        if ($name === '') { wp_safe_redirect(add_query_arg(['tab' => 'roles', 'edit' => $slug ?: 'new', 'err' => 'name'], $back)); exit; }
        if (ihub_rbac_locked($slug)) wp_die('บทบาทผู้ดูแลระบบแก้ไม่ได้', 403);
        $want = array_intersect(array_map('sanitize_key', (array) ($_POST['caps'] ?? [])), array_keys(ihub_rbac_cap_list()));
        $new = !$slug || !get_role($slug);
        if ($new) {
            $slug = 'ihub_' . (sanitize_key(remove_accents($name)) ?: 'role_' . wp_generate_password(6, false, false));
            while (get_role($slug)) $slug .= '_2';
            add_role($slug, $name, ['read' => true]);
            ihub_rbac_log('สร้างบทบาท “' . $name . '”');
        } else {
            wp_roles()->roles[$slug]['name'] = $name;
            wp_roles()->role_names[$slug] = $name;
            update_option(wp_roles()->role_key, wp_roles()->roles);
        }
        $role = get_role($slug);
        $before = array_keys(array_filter($role->capabilities));
        foreach (array_keys(ihub_rbac_cap_list()) as $cap) {
            if (in_array($cap, $want, true)) $role->add_cap($cap); elseif ($role->has_cap($cap)) $role->remove_cap($cap);
        }
        $role->add_cap('read');
        $added = array_diff($want, $before);
        $removed = array_intersect(array_diff(array_keys(ihub_rbac_cap_list()), $want), $before);
        if (!$new && ($added || $removed)) ihub_rbac_log('แก้บทบาท “' . $name . '”' . ($added ? ' · เพิ่ม: ' . implode(', ', $added) : '') . ($removed ? ' · เอาออก: ' . implode(', ', $removed) : ''));
        $msg = 'saved';
    } elseif ($do === 'delete_role') {
        $slug = sanitize_key($_POST['role'] ?? '');
        $to = sanitize_key($_POST['move_to'] ?? 'subscriber');
        if (ihub_rbac_builtin($slug) || !get_role($slug) || !get_role($to) || $to === $slug) wp_die('ลบบทบาทนี้ไม่ได้', 400);
        $name = wp_roles()->role_names[$slug] ?? $slug;
        foreach (get_users(['role' => $slug, 'fields' => 'ID']) as $uid) { $u = new WP_User($uid); $u->remove_role($slug); if (!$u->roles) $u->add_role($to); }
        remove_role($slug);
        ihub_rbac_log('ลบบทบาท “' . $name . '” (ย้ายผู้ใช้ไป ' . (wp_roles()->role_names[$to] ?? $to) . ')');
        $msg = 'deleted';
    } elseif ($do === 'presets') {
        $n = 0;
        foreach (ihub_rbac_presets() as $slug => [$name, $caps]) {
            if (get_role($slug)) continue;
            add_role($slug, $name, array_fill_keys(array_merge(['read'], $caps), true));
            $n++;
        }
        if ($n) ihub_rbac_log('สร้างบทบาทแนะนำ ' . $n . ' บทบาท');
        $msg = 'presets';
    } elseif ($do === 'user_roles') {
        if (!current_user_can('promote_users')) wp_die('ไม่มีสิทธิ์', 403);
        $uid = (int) ($_POST['user'] ?? 0);
        $user = get_userdata($uid);
        if (!$user || !current_user_can('promote_user', $uid)) wp_die('ไม่มีสิทธิ์', 403);
        $assignable = ihub_rbac_assignable();
        $want = array_values(array_intersect(array_map('sanitize_key', (array) ($_POST['roles'] ?? [])), array_keys($assignable)));
        if (!$want) { wp_safe_redirect(add_query_arg(['tab' => 'users', 'err' => 'norole'], $back)); exit; }
        if ($uid === get_current_user_id() && in_array('administrator', (array) $user->roles, true) && !in_array('administrator', $want, true)) { wp_safe_redirect(add_query_arg(['tab' => 'users', 'err' => 'self'], $back)); exit; }
        if (!current_user_can('manage_options') && in_array('administrator', (array) $user->roles, true)) wp_die('ไม่มีสิทธิ์', 403);
        $old = (array) $user->roles;
        foreach ($old as $r) if (!in_array($r, $want, true) && isset($assignable[$r])) $user->remove_role($r);
        foreach ($want as $r) if (!in_array($r, $old, true)) $user->add_role($r);
        if ($old !== $want) ihub_rbac_log('ผู้ใช้ “' . $user->display_name . '”: ' . implode(', ', array_map(function ($r) use ($assignable) { return $assignable[$r] ?? $r; }, $want)));
        $msg = 'user';
        $back = add_query_arg('tab', 'users', $back);
    }
    wp_safe_redirect(add_query_arg('done', $msg, $back));
    exit;
});

/* ---------- Page ---------- */

function ihub_rbac_page() {
    if (!current_user_can('promote_users')) wp_die('ไม่มีสิทธิ์');
    $can_roles = current_user_can('manage_options');
    $tab = sanitize_key($_GET['tab'] ?? ($can_roles ? 'roles' : 'users')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (!$can_roles) $tab = $tab === 'log' ? 'log' : 'users';
    $done = sanitize_key($_GET['done'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $err = sanitize_key($_GET['err'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $url = function ($args) { return esc_url(add_query_arg($args, admin_url('admin.php?page=ihub-access'))); };
    echo '<div class="wrap ihub-rbac"><h1>ผู้ใช้และสิทธิ์</h1><p class="description">กำหนดบทบาทตามหน้าที่งาน (Role-Based Access Control) แล้วให้แต่ละคนถือบทบาทที่เหมาะกับงาน · คนหนึ่งมีได้หลายบทบาท สิทธิ์จะรวมกัน</p>';
    $msgs = ['saved' => 'บันทึกบทบาทแล้ว', 'deleted' => 'ลบบทบาทแล้ว', 'presets' => 'สร้างบทบาทแนะนำแล้ว', 'user' => 'บันทึกบทบาทของผู้ใช้แล้ว'];
    $errs = ['name' => 'กรุณาตั้งชื่อบทบาท', 'norole' => 'ผู้ใช้ต้องมีอย่างน้อย 1 บทบาท', 'self' => 'เอาสิทธิ์ผู้ดูแลระบบออกจากบัญชีตัวเองไม่ได้ (กันล็อกตัวเองออก)'];
    if (isset($msgs[$done])) echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($msgs[$done]) . '</p></div>';
    if (isset($errs[$err])) echo '<div class="notice notice-error"><p>' . esc_html($errs[$err]) . '</p></div>';
    echo '<nav class="nav-tab-wrapper">';
    if ($can_roles) echo '<a class="nav-tab' . ($tab === 'roles' ? ' nav-tab-active' : '') . '" href="' . $url(['tab' => 'roles']) . '">บทบาทและสิทธิ์</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $url escapes
    echo '<a class="nav-tab' . ($tab === 'users' ? ' nav-tab-active' : '') . '" href="' . $url(['tab' => 'users']) . '">ผู้ใช้</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<a class="nav-tab' . ($tab === 'log' ? ' nav-tab-active' : '') . '" href="' . $url(['tab' => 'log']) . '">ประวัติการเปลี่ยนแปลง</a></nav>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if ($tab === 'roles') ihub_rbac_roles_tab($url);
    elseif ($tab === 'log') ihub_rbac_log_tab();
    else ihub_rbac_users_tab();
    echo '</div>';
}

function ihub_rbac_form_open($do) {
    return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="ihub_rbac"><input type="hidden" name="do" value="' . esc_attr($do) . '">' . wp_nonce_field('ihub_rbac', '_wpnonce', true, false);
}

function ihub_rbac_roles_tab($url) {
    $edit = sanitize_key($_GET['edit'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $copy = sanitize_key($_GET['copy'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $roles = wp_roles()->roles;
    $counts = count_users()['avail_roles'] ?? [];
    $labels = ihub_rbac_cap_list();
    if ($edit || $copy) {
        $slug = $edit === 'new' ? '' : $edit;
        $src = $copy ?: $slug;
        $caps = $src && isset($roles[$src]) ? array_keys(array_filter($roles[$src]['capabilities'])) : ['read'];
        $name = $slug && isset($roles[$slug]) ? translate_user_role($roles[$slug]['name']) : ($copy && isset($roles[$copy]) ? translate_user_role($roles[$copy]['name']) . ' (สำเนา)' : '');
        if (ihub_rbac_locked($slug)) { echo '<p>บทบาทผู้ดูแลระบบมีทุกสิทธิ์และแก้ไม่ได้</p>'; return; }
        echo ihub_rbac_form_open('save_role') . '<input type="hidden" name="role" value="' . esc_attr($slug) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts
        echo '<div class="ihub-rbac-edit"><label class="ihub-rbac-name"><span>ชื่อบทบาท</span><input name="name" required value="' . esc_attr($name) . '" placeholder="เช่น พยาบาลคัดกรอง"></label>';
        foreach (ihub_rbac_caps() as $group => $items) {
            echo '<fieldset class="ihub-rbac-group"><legend>' . esc_html($group) . ' <button type="button" class="button-link" data-all>เลือกทั้งหมด</button></legend>';
            foreach ($items as $cap => [$label, $help]) {
                echo '<label class="ihub-rbac-cap' . ($cap === 'manage_options' ? ' danger' : '') . '"><input type="checkbox" name="caps[]" value="' . esc_attr($cap) . '"' . checked(in_array($cap, $caps, true), true, false) . '><span><b>' . esc_html($label) . '</b>' . ($help ? '<small>' . esc_html($help) . '</small>' : '') . '<code>' . esc_html($cap) . '</code></span></label>';
            }
            echo '</fieldset>';
        }
        $other = array_diff($caps, array_keys($labels), ['read']);
        if ($other) echo '<p class="description">สิทธิ์อื่นที่บทบาทนี้มีอยู่ (ไม่เปลี่ยน): <code>' . esc_html(implode(', ', array_slice($other, 0, 30))) . (count($other) > 30 ? ' …' : '') . '</code></p>';
        echo '<p class="ihub-rbac-actions"><button class="button button-primary button-large">บันทึกบทบาท</button> <a class="button button-large" href="' . $url(['tab' => 'roles']) . '">ยกเลิก</a></p></div></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '<script>document.querySelectorAll(".ihub-rbac-group [data-all]").forEach(function(b){b.addEventListener("click",function(){var c=b.closest("fieldset").querySelectorAll("input[type=checkbox]"),on=[].some.call(c,function(x){return !x.checked});c.forEach(function(x){x.checked=on})})})</script>';
        return;
    }
    $missing = array_filter(array_keys(ihub_rbac_presets()), function ($s) use ($roles) { return !isset($roles[$s]); });
    echo '<p class="ihub-rbac-top"><a class="button button-primary" href="' . $url(['tab' => 'roles', 'edit' => 'new']) . '">＋ เพิ่มบทบาท</a> '; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if ($missing) echo ihub_rbac_form_open('presets') . '<button class="button">สร้างบทบาทแนะนำ (' . count($missing) . ')</button><span class="description"> แพทย์ · เจ้าหน้าที่นัดหมาย/เวชระเบียน · ประชาสัมพันธ์ · ผู้ดูแลข่าวประกาศ · ผู้ดูแลเนื้อหาเว็บ · หัวหน้างาน</span></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</p><div class="ihub-rbac-grid">';
    uksort($roles, function ($a, $b) { return (ihub_rbac_builtin($a) <=> ihub_rbac_builtin($b)) ?: strcmp($a, $b); });
    $names = wp_roles()->get_names();
    foreach ($roles as $slug => $r) {
        $caps = array_keys(array_filter($r['capabilities']));
        $chips = array_values(array_intersect_key($labels, array_flip($caps)));
        $n = (int) ($counts[$slug] ?? 0);
        echo '<div class="ihub-rbac-card' . (ihub_rbac_locked($slug) ? ' locked' : '') . '"><div class="hd"><b>' . esc_html(translate_user_role($r['name'])) . '</b><span class="n">' . (int) $n . ' คน</span></div><code>' . esc_html($slug) . '</code>' . (ihub_rbac_builtin($slug) ? '<span class="wp">บทบาทของ WordPress</span>' : '');
        if (ihub_rbac_locked($slug)) echo '<p class="all">ทุกสิทธิ์</p>';
        else echo '<ul>' . ($chips ? implode('', array_map(function ($c) { return '<li>' . esc_html($c[0]) . '</li>'; }, array_slice($chips, 0, 6))) . (count($chips) > 6 ? '<li class="more">+ อีก ' . (count($chips) - 6) . '</li>' : '') : '<li class="none">ไม่มีสิทธิ์ในระบบ (อ่านอย่างเดียว)</li>') . '</ul>';
        echo '<div class="ft">';
        if (!ihub_rbac_locked($slug)) echo '<a class="button button-small" href="' . $url(['tab' => 'roles', 'edit' => $slug]) . '">แก้ไข</a> '; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '<a class="button button-small" href="' . $url(['tab' => 'roles', 'copy' => $slug, 'edit' => 'new']) . '">สำเนา</a> '; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        if (!ihub_rbac_builtin($slug)) {
            echo ihub_rbac_form_open('delete_role') . '<input type="hidden" name="role" value="' . esc_attr($slug) . '"><select name="move_to" title="ผู้ใช้ในบทบาทนี้จะย้ายไปที่">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            foreach ($names as $k => $l) if ($k !== $slug && $k !== 'administrator') echo '<option value="' . esc_attr($k) . '"' . selected($k, 'subscriber', false) . '>ย้ายผู้ใช้ไป: ' . esc_html(translate_user_role($l)) . '</option>';
            echo '</select> <button class="button button-small button-link-delete" onclick="return confirm(\'ลบบทบาทนี้?\')">ลบ</button></form>';
        }
        echo '</div></div>';
    }
    echo '</div>';
}

function ihub_rbac_users_tab() {
    $assignable = ihub_rbac_assignable();
    $q = sanitize_text_field(wp_unslash($_GET['s'] ?? '')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $users = get_users(['number' => 200, 'orderby' => 'display_name', 'search' => $q !== '' ? '*' . $q . '*' : '']);
    echo '<form class="ihub-rbac-search" method="get"><input type="hidden" name="page" value="ihub-access"><input type="hidden" name="tab" value="users"><input type="search" name="s" value="' . esc_attr($q) . '" placeholder="ค้นหาชื่อ อีเมล"> <button class="button">ค้นหา</button>';
    if (current_user_can('create_users')) echo ' <a class="button button-primary" href="' . esc_url(admin_url('user-new.php')) . '">＋ เพิ่มผู้ใช้</a>';
    echo '</form><table class="widefat striped ihub-rbac-users"><thead><tr><th style="width:32%">ผู้ใช้</th><th>บทบาท (เลือกได้หลายบทบาท)</th></tr></thead><tbody>';
    foreach ($users as $u) {
        $mine = $u->ID === get_current_user_id();
        $locked = !current_user_can('promote_user', $u->ID) || (!current_user_can('manage_options') && in_array('administrator', (array) $u->roles, true));
        echo '<tr><td><b>' . esc_html($u->display_name) . '</b>' . ($mine ? ' <span class="ihub-rbac-me">คุณ</span>' : '') . '<br><small>' . esc_html($u->user_login . ' · ' . $u->user_email) . '</small>';
        if (current_user_can('edit_user', $u->ID)) echo '<br><a href="' . esc_url(get_edit_user_link($u->ID)) . '">แก้ข้อมูล / รหัสผ่าน</a>';
        echo '</td><td>';
        if ($locked) { echo esc_html(implode(', ', array_map(function ($r) { return translate_user_role(wp_roles()->role_names[$r] ?? $r); }, (array) $u->roles))) . '</td></tr>'; continue; }
        echo ihub_rbac_form_open('user_roles') . '<input type="hidden" name="user" value="' . (int) $u->ID . '"><div class="ihub-rbac-roles">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        foreach ($assignable as $k => $l) echo '<label><input type="checkbox" name="roles[]" value="' . esc_attr($k) . '"' . checked(in_array($k, (array) $u->roles, true), true, false) . '> ' . esc_html(translate_user_role($l)) . '</label>';
        echo '</div><button class="button button-small ihub-rbac-save">บันทึก</button></form></td></tr>';
    }
    if (!$users) echo '<tr><td colspan="2">ไม่พบผู้ใช้</td></tr>';
    echo '</tbody></table>';
}

function ihub_rbac_log_tab() {
    $log = get_option('ihub_rbac_log', []);
    echo '<table class="widefat striped"><thead><tr><th style="width:170px">เวลา</th><th style="width:160px">โดย</th><th>รายการ</th></tr></thead><tbody>';
    foreach (is_array($log) ? $log : [] as $l) echo '<tr><td>' . esc_html($l[0]) . '</td><td>' . esc_html($l[1]) . '</td><td>' . esc_html($l[2]) . '</td></tr>';
    if (!$log) echo '<tr><td colspan="3">ยังไม่มีการเปลี่ยนแปลง</td></tr>';
    echo '</tbody></table>';
}

add_action('admin_enqueue_scripts', function () {
    if (($_GET['page'] ?? '') !== 'ihub-access') return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    wp_register_style('ihub-rbac', false, [], IHUB_VERSION);
    wp_enqueue_style('ihub-rbac');
    wp_add_inline_style('ihub-rbac', '
.ihub-rbac .nav-tab-wrapper{margin-bottom:16px}
.ihub-rbac-top{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.ihub-rbac-top form{display:inline-flex;gap:8px;align-items:center}
.ihub-rbac-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;margin-top:10px}
.ihub-rbac-card{background:#fff;border:1px solid #dcdfe4;border-radius:14px;padding:16px;display:flex;flex-direction:column;gap:6px}
.ihub-rbac-card.locked{background:#f8fafc}
.ihub-rbac-card .hd{display:flex;justify-content:space-between;align-items:center;gap:8px}.ihub-rbac-card .hd b{font-size:15px}
.ihub-rbac-card .n{background:#e7f6f3;color:#0f766e;border-radius:99px;padding:1px 10px;font-weight:600;font-size:12px;white-space:nowrap}
.ihub-rbac-card code{font-size:11px;align-self:flex-start}.ihub-rbac-card .wp{font-size:11px;color:#64748b}
.ihub-rbac-card ul{margin:4px 0;display:flex;flex-wrap:wrap;gap:5px}.ihub-rbac-card li{margin:0;background:#f1f5f9;border-radius:6px;padding:2px 8px;font-size:12px}
.ihub-rbac-card li.more{background:none;color:#64748b}.ihub-rbac-card li.none{background:none;color:#94a3b8}.ihub-rbac-card .all{margin:4px 0;color:#0f766e;font-weight:600}
.ihub-rbac-card .ft{margin-top:auto;padding-top:8px;border-top:1px solid #eef1f3;display:flex;gap:6px;flex-wrap:wrap;align-items:center}.ihub-rbac-card .ft form{display:inline-flex;gap:4px;align-items:center}.ihub-rbac-card .ft select{max-width:170px;font-size:12px;min-height:28px}
.ihub-rbac-edit{max-width:900px}.ihub-rbac-name{display:flex;flex-direction:column;gap:4px;max-width:420px;margin-bottom:14px;font-weight:600}.ihub-rbac-name input{font-size:16px;padding:6px 10px}
.ihub-rbac-group{background:#fff;border:1px solid #dcdfe4;border-radius:12px;padding:6px 16px 12px;margin:0 0 14px}
.ihub-rbac-group legend{font-weight:700;font-size:14px;padding:0 6px}.ihub-rbac-group legend .button-link{font-weight:400;font-size:12px;margin-left:8px}
.ihub-rbac-cap{display:flex;gap:10px;align-items:flex-start;padding:8px 0;border-bottom:1px solid #f1f3f5}.ihub-rbac-cap:last-child{border-bottom:0}
.ihub-rbac-cap input{margin-top:3px}.ihub-rbac-cap span{display:flex;flex-direction:column;gap:1px}.ihub-rbac-cap small{color:#64748b}.ihub-rbac-cap code{font-size:10.5px;color:#94a3b8;background:none;padding:0}
.ihub-rbac-cap.danger b{color:#b91c1c}
.ihub-rbac-search{margin:0 0 12px}.ihub-rbac-users td{vertical-align:top}
.ihub-rbac-roles{display:flex;flex-wrap:wrap;gap:6px 14px;margin-bottom:8px}.ihub-rbac-roles label{white-space:nowrap}
.ihub-rbac-me{background:#e7f6f3;color:#0f766e;border-radius:99px;padding:0 8px;font-size:11px;font-weight:600}
');
});
