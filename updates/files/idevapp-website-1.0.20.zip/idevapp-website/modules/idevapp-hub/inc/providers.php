<?php
/** Doctors and clinics (ตารางออกตรวจ) with their clinic times, plus schedule templates. */
defined('ABSPATH') || exit;

function ihub_register_post_types() {
    $common = ['public' => false, 'show_ui' => true, 'show_in_menu' => 'idevapp-hub', 'show_in_rest' => false, 'map_meta_cap' => true, 'capability_type' => 'post'];
    // Parts handled by iDev plugins keep their old post types registered (hidden), so nothing is lost if the iDev plugin is turned off again.
    if (ihub_uses('schedule')) $common_p = ['show_ui' => false] + $common; else $common_p = $common;
    if (ihub_uses('ticker')) $common_n = ['show_ui' => false] + $common; else $common_n = $common;
    if (ihub_uses('popup')) $common_u = ['show_ui' => false] + $common; else $common_u = $common;
    register_post_type('ihub_provider', $common_p + [
        'labels' => ['name' => 'แพทย์ / คลินิก', 'singular_name' => 'แพทย์ / คลินิก', 'add_new' => 'เพิ่มแพทย์/คลินิก', 'add_new_item' => 'เพิ่มแพทย์หรือคลินิก', 'edit_item' => 'แก้ไขแพทย์/คลินิก', 'all_items' => 'ตารางออกตรวจ', 'menu_name' => 'ตารางออกตรวจ', 'search_items' => 'ค้นหา', 'not_found' => 'ยังไม่มีรายการ'],
        'supports' => ['title', 'thumbnail', 'page-attributes'],
    ]);
    register_post_type('ihub_notice', $common_n + [
        'labels' => ['name' => 'ประกาศ (แถบด้านบน)', 'singular_name' => 'ประกาศ', 'add_new' => 'เพิ่มประกาศ', 'add_new_item' => 'เพิ่มประกาศ', 'edit_item' => 'แก้ไขประกาศ', 'all_items' => 'ประกาศวิ่ง', 'menu_name' => 'ประกาศวิ่ง', 'not_found' => 'ยังไม่มีประกาศ'],
        'supports' => ['title'],
    ]);
    register_post_type('ihub_popup', $common_u + [
        'labels' => ['name' => 'Popup ประกาศสำคัญ', 'singular_name' => 'Popup', 'add_new' => 'เพิ่ม Popup', 'add_new_item' => 'เพิ่ม Popup', 'edit_item' => 'แก้ไข Popup', 'all_items' => 'Popup', 'menu_name' => 'Popup', 'not_found' => 'ยังไม่มี Popup'],
        'supports' => ['title', 'thumbnail', 'page-attributes'],
    ]);
}
add_action('init', 'ihub_register_post_types');

function ihub_provider_from_post($post) {
    $meta = function ($key) use ($post) { return (string) get_post_meta($post->ID, "ihub_{$key}", true); };
    $slots = json_decode($meta('slots') ?: '[]', true);
    $kind = $meta('kind') === 'clinic' ? 'clinic' : 'doctor';
    return [
        'id' => $post->ID, 'kind' => $kind, 'booking_url' => $meta('booking_url'), 'name' => $post->post_title, 'name_en' => $meta('name_en'),
        'specialty' => $meta('specialty'), 'specialty_en' => $meta('specialty_en'), 'note' => $meta('note'), 'note_en' => $meta('note_en'),
        'photo_url' => (string) get_the_post_thumbnail_url($post, 'thumbnail'), 'photo_large' => (string) get_the_post_thumbnail_url($post, 'large'),
        'bio' => $meta('bio'), 'bio_en' => $meta('bio_en'), 'slots' => is_array($slots) ? $slots : [],
    ];
}

/** Published doctors/clinics in display order. */
function ihub_get_providers($include_hidden = false) {
    if (ihub_uses('schedule') && function_exists('idev_cs_providers')) return array_map(function ($p) { return $p + ['photo_url' => $p['photo']]; }, idev_cs_providers($include_hidden));
    $posts = get_posts(['post_type' => 'ihub_provider', 'post_status' => $include_hidden ? ['publish', 'draft', 'pending', 'private'] : 'publish', 'numberposts' => -1, 'orderby' => ['menu_order' => 'ASC', 'title' => 'ASC'], 'suppress_filters' => false]);
    return array_map('ihub_provider_from_post', $posts);
}

function ihub_templates() {
    $list = get_option('ihub_schedule_templates', []);
    return is_array($list) ? array_values($list) : [];
}

/* ---------- Edit screen ---------- */

add_action('add_meta_boxes_ihub_provider', function () {
    add_meta_box('ihub_provider_box', 'ข้อมูลและเวลาออกตรวจ', 'ihub_provider_box', 'ihub_provider', 'normal', 'high');
});

add_filter('enter_title_here', function ($text, $post) {
    if ($post->post_type === 'ihub_provider') return 'ชื่อแพทย์ / คลินิก (ไทย) เช่น นพ.สมชาย ใจดี หรือ คลินิกฝากครรภ์';
    if ($post->post_type === 'ihub_popup') return 'หัวข้อ Popup (ไทย)';
    if ($post->post_type === 'ihub_notice') return 'ป้ายหัวข้อ เช่น ประกาศสำคัญ';
    return $text;
}, 10, 2);

add_filter('admin_post_thumbnail_html', function ($html, $post_id) {
    $type = get_post_type($post_id);
    if ($type === 'ihub_provider') return '<p class="description">รูปถ่ายแพทย์ / โลโก้คลินิก (ถ้ามี)</p>' . $html;
    if ($type === 'ihub_popup') return '<p class="description">รูปใน Popup (ถ้ามี)</p>' . $html;
    return $html;
}, 10, 2);

function ihub_provider_box($post) {
    $p = ihub_provider_from_post($post);
    wp_nonce_field('ihub_provider_save', 'ihub_provider_nonce');
    $field = function ($key, $label, $placeholder = '', $type = 'text') use ($p) {
        return '<label>' . esc_html($label) . '<input type="' . $type . '" name="ah[' . $key . ']" value="' . esc_attr($p[$key]) . '" placeholder="' . esc_attr($placeholder) . '"></label>';
    };
    echo '<div class="ihub-admin ihub-provider">';
    echo '<fieldset class="ihub-kind"><legend>ประเภท</legend>';
    echo '<label class="ihub-kind-option"><input type="radio" name="ah[kind]" value="doctor"' . checked($p['kind'], 'doctor', false) . '><span><strong>👩‍⚕️ แพทย์</strong><small>แสดงชื่อแพทย์และสาขา</small></span></label>';
    echo '<label class="ihub-kind-option"><input type="radio" name="ah[kind]" value="clinic"' . checked($p['kind'], 'clinic', false) . '><span><strong>🏥 คลินิก / แผนก</strong><small>เช่น คลินิกฝากครรภ์ คลินิกเด็กดี</small></span></label></fieldset>';
    echo '<div class="ihub-grid2">' . $field('name_en', 'Name (English)', 'Dr. Somchai / Antenatal clinic') . '<span></span>';
    echo $field('specialty', 'สาขา / รายละเอียด', 'เช่น อายุรกรรม, ชั้น 2 อาคาร A') . $field('specialty_en', 'Specialty (English)');
    echo $field('note', 'หมายเหตุ (ถ้ามี)', 'เช่น รับนัดล่วงหน้าเท่านั้น') . $field('note_en', 'Note (English)') . '</div>';
    echo '<div class="ihub-grid2"><label>ประวัติ / ความเชี่ยวชาญ (แสดงในบล็อก “ทีมแพทย์”)<textarea name="ah[bio]" rows="3" placeholder="เช่น วุฒิบัตรอายุรศาสตร์ ประสบการณ์ 10 ปี">' . esc_textarea($p['bio']) . '</textarea></label><label>Profile (English)<textarea name="ah[bio_en]" rows="3">' . esc_textarea($p['bio_en']) . '</textarea></label></div>';
    echo '<label class="ihub-wide">ลิงก์ระบบจองนัด (ถ้าเว้นว่าง ใช้ลิงก์นัดหมายจากหน้าตั้งค่า)<input type="url" name="ah[booking_url]" value="' . esc_attr($p['booking_url']) . '" placeholder="https://..."><small>ผู้เข้าชมกดเวลาออกตรวจในตารางแล้วจะไปที่ลิงก์นี้</small></label>';
    echo '<h3>เวลาออกตรวจ</h3><p class="description">ตั้งได้ทั้งทุกสัปดาห์ ทุกเดือน (เช่น พุธที่ 1 และ 3 หรือทุกวันที่ 15) ทุกปี หรือเฉพาะวันที่ และกำหนดช่วงวันที่มีผลได้ · ซ่อนจากตาราง: เปลี่ยนสถานะเป็น “ฉบับร่าง” · ลำดับ: “คุณลักษณะ → ลำดับ”</p>';
    $sources = [];
    foreach (ihub_get_providers(true) as $other) if ($other['id'] !== $post->ID && $other['slots']) $sources[] = ['id' => $other['id'], 'name' => $other['name'], 'slots' => $other['slots']];
    echo '<div id="ihub-slots" data-slots="' . esc_attr(wp_json_encode($p['slots'])) . '" data-templates="' . esc_attr(wp_json_encode(ihub_templates())) . '" data-sources="' . esc_attr(wp_json_encode($sources)) . '"></div>';
    echo '<input type="hidden" name="ah[slots]" id="ihub-slots-input" value="' . esc_attr(wp_json_encode($p['slots'])) . '">';
    echo '</div>';
}

add_action('save_post_ihub_provider', function ($post_id) {
    if (!isset($_POST['ihub_provider_nonce']) || !wp_verify_nonce(sanitize_key($_POST['ihub_provider_nonce']), 'ihub_provider_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    $in = isset($_POST['ah']) && is_array($_POST['ah']) ? wp_unslash($_POST['ah']) : [];
    update_post_meta($post_id, 'ihub_kind', ($in['kind'] ?? '') === 'clinic' ? 'clinic' : 'doctor');
    foreach (['name_en', 'specialty', 'specialty_en', 'note', 'note_en'] as $key) update_post_meta($post_id, "ihub_{$key}", sanitize_text_field($in[$key] ?? ''));
    foreach (['bio', 'bio_en'] as $key) update_post_meta($post_id, "ihub_{$key}", sanitize_textarea_field($in[$key] ?? ''));
    update_post_meta($post_id, 'ihub_booking_url', esc_url_raw(trim($in['booking_url'] ?? ''), ['http', 'https']));
    $slots = ihub_clean_slots(json_decode((string) ($in['slots'] ?? '[]'), true));
    update_post_meta($post_id, 'ihub_slots', wp_slash(wp_json_encode($slots, JSON_UNESCAPED_UNICODE)));
});

/* ---------- Templates (AJAX from the slots editor) ---------- */

add_action('wp_ajax_ihub_template', function () {
    check_ajax_referer('ihub_slots', 'nonce');
    if (!current_user_can('edit_posts')) wp_send_json_error('ไม่มีสิทธิ์', 403);
    $templates = ihub_templates();
    if (($_POST['do'] ?? '') === 'delete') {
        $id = sanitize_key($_POST['id'] ?? '');
        $templates = array_values(array_filter($templates, function ($t) use ($id) { return $t['id'] !== $id; }));
    } else {
        $name = mb_substr(sanitize_text_field(wp_unslash($_POST['name'] ?? '')), 0, 100);
        $slots = ihub_clean_slots(json_decode(wp_unslash($_POST['slots'] ?? '[]'), true));
        if ($name === '' || !$slots) wp_send_json_error('ตั้งชื่อ และต้องมีเวลาอย่างน้อย 1 ช่วงที่ถูกต้อง');
        $templates[] = ['id' => substr(md5(uniqid('', true)), 0, 10), 'name' => $name, 'slots' => $slots];
    }
    update_option('ihub_schedule_templates', $templates, false);
    wp_send_json_success($templates);
});

/* ---------- List screen ---------- */

add_filter('manage_ihub_provider_posts_columns', function ($columns) {
    return ['cb' => $columns['cb'], 'title' => 'ชื่อ', 'ihub_kind' => 'ประเภท', 'ihub_slots' => 'เวลาออกตรวจ', 'ihub_order' => 'ลำดับ', 'date' => $columns['date']];
});
add_action('manage_ihub_provider_posts_custom_column', function ($column, $post_id) {
    $p = ihub_provider_from_post(get_post($post_id));
    if ($column === 'ihub_kind') echo $p['kind'] === 'clinic' ? '🏥 คลินิก' : '👩‍⚕️ แพทย์';
    if ($column === 'ihub_slots') echo $p['slots'] ? count($p['slots']) . ' ช่วง' : '<span style="color:#b32d2e">ยังไม่มีเวลา</span>';
    if ($column === 'ihub_order') echo (int) get_post_field('menu_order', $post_id);
}, 10, 2);

add_filter('post_row_actions', function ($actions, $post) {
    if ($post->post_type === 'ihub_provider' && current_user_can('edit_post', $post->ID)) {
        $url = wp_nonce_url(admin_url('admin-post.php?action=ihub_duplicate_provider&id=' . $post->ID), 'ihub_duplicate_' . $post->ID);
        $actions['ihub_duplicate'] = '<a href="' . esc_url($url) . '">ทำสำเนา (พร้อมเวลา)</a>';
    }
    return $actions;
}, 10, 2);

add_action('admin_post_ihub_duplicate_provider', function () {
    $id = (int) ($_GET['id'] ?? 0);
    if (!current_user_can('edit_post', $id) || !check_admin_referer('ihub_duplicate_' . $id)) wp_die('ไม่มีสิทธิ์');
    $source = get_post($id);
    $copy = wp_insert_post(['post_type' => 'ihub_provider', 'post_status' => 'draft', 'post_title' => $source->post_title . ' (สำเนา)', 'menu_order' => $source->menu_order]);
    foreach (get_post_meta($id) as $key => $values) if (strpos($key, 'ihub_') === 0 || $key === '_thumbnail_id') update_post_meta($copy, $key, wp_slash(maybe_unserialize($values[0])));
    wp_safe_redirect(admin_url("post.php?post={$copy}&action=edit&ihub_copied=1"));
    exit;
});

add_action('admin_notices', function () {
    if (isset($_GET['ihub_copied'])) echo '<div class="notice notice-success"><p>ทำสำเนาแล้ว (ยังเป็นฉบับร่าง) แก้ชื่อและเวลาแล้วกด “เผยแพร่”</p></div>';
});

/* ---------- Admin assets ---------- */

add_action('admin_enqueue_scripts', function ($hook) {
    wp_enqueue_style('ihub-admin', IHUB_URL . 'assets/admin.css', [], IHUB_VERSION);
    $screen = get_current_screen();
    if ($screen && $screen->post_type === 'ihub_provider' && in_array($hook, ['post.php', 'post-new.php'], true)) {
        wp_enqueue_script('ihub-slots', IHUB_URL . 'assets/slots.js', [], IHUB_VERSION, true);
        wp_localize_script('ihub-slots', 'IHUB_SLOTS', ['ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('ihub_slots')]);
    }
    wp_enqueue_script('ihub-admin', IHUB_URL . 'assets/admin.js', ['jquery'], IHUB_VERSION, true);
});
