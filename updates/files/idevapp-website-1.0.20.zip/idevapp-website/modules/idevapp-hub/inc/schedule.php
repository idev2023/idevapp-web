<?php
/** Clinic schedule: recurrence rules and the public month / week / day views. */
defined('ABSPATH') || exit;

function ihub_recurrences() {
    return ['weekly' => 'ทุกสัปดาห์', 'monthly_week' => 'ทุกเดือน (เลือกสัปดาห์ที่)', 'monthly_day' => 'ทุกเดือน (เลือกวันที่)', 'yearly' => 'ทุกปี (วันและเดือน)', 'date' => 'เฉพาะวันที่'];
}

function ihub_parse_date($date) {
    return new DateTimeImmutable($date . ' 00:00:00', new DateTimeZone('UTC'));
}
function ihub_add_days($date, $days) {
    return ihub_parse_date($date)->modify(($days >= 0 ? '+' : '') . (int) $days . ' days')->format('Y-m-d');
}
function ihub_iso_weekday($date) {
    return (int) ihub_parse_date($date)->format('N');
}
function ihub_monday_of($date) {
    return ihub_add_days($date, 1 - ihub_iso_weekday($date));
}
function ihub_today() {
    return (new DateTimeImmutable('now', new DateTimeZone('Asia/Bangkok')))->format('Y-m-d');
}
function ihub_is_valid_date($value) {
    if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) return false;
    [$y, $m, $d] = array_map('intval', explode('-', $value));
    return checkdate($m, $d, $y);
}

/** Does this slot take place on the given date? */
function ihub_occurs_on($slot, $date) {
    if (!empty($slot['valid_from']) && $date < $slot['valid_from']) return false;
    if (!empty($slot['valid_until']) && $date > $slot['valid_until']) return false;
    [, $month, $day] = ihub_date_parts($date);
    $weekday = ihub_iso_weekday($date);
    switch ($slot['recurrence'] ?? 'weekly') {
        case 'weekly': return $weekday === (int) $slot['weekday'];
        case 'monthly_week':
            if ($weekday !== (int) $slot['weekday']) return false;
            if ((int) $slot['week_of_month'] === 5) return (int) ihub_parse_date(ihub_add_days($date, 7))->format('n') !== $month;
            return (int) ceil($day / 7) === (int) $slot['week_of_month'];
        case 'monthly_day': return $day === (int) $slot['day_of_month'];
        case 'yearly': return $day === (int) $slot['day_of_month'] && $month === (int) $slot['month_of_year'];
        case 'date': return ($slot['on_date'] ?? '') === $date;
    }
    return false;
}

/** Validates one slot (from the editor, a template or the importer); returns null when unusable. */
function ihub_clean_slot($raw) {
    $v = is_array($raw) ? $raw : [];
    $time = '/^([01]\d|2[0-3]):[0-5]\d$/';
    $start = substr((string) ($v['start_time'] ?? ''), 0, 5);
    $end = substr((string) ($v['end_time'] ?? ''), 0, 5);
    if (!preg_match($time, $start) || !preg_match($time, $end) || $end <= $start) return null;
    $recurrence = array_key_exists($v['recurrence'] ?? '', ihub_recurrences()) ? $v['recurrence'] : 'weekly';
    $int = function ($value, $min, $max) { return (is_numeric($value) && (int) $value == $value && $value >= $min && $value <= $max) ? (int) $value : null; };
    $date = function ($value) { return ihub_is_valid_date($value) ? $value : null; };
    $slot = [
        'recurrence' => $recurrence, 'weekday' => $int($v['weekday'] ?? null, 1, 7), 'week_of_month' => $int($v['week_of_month'] ?? null, 1, 5),
        'day_of_month' => $int($v['day_of_month'] ?? null, 1, 31), 'month_of_year' => $int($v['month_of_year'] ?? null, 1, 12),
        'on_date' => $date($v['on_date'] ?? null), 'valid_from' => $date($v['valid_from'] ?? null), 'valid_until' => $date($v['valid_until'] ?? null),
        'start_time' => $start, 'end_time' => $end,
        'note' => mb_substr(sanitize_text_field((string) ($v['note'] ?? '')), 0, 120), 'note_en' => mb_substr(sanitize_text_field((string) ($v['note_en'] ?? '')), 0, 120),
    ];
    if (in_array($recurrence, ['weekly', 'monthly_week'], true) && !$slot['weekday']) return null;
    if ($recurrence === 'monthly_week' && !$slot['week_of_month']) return null;
    if (in_array($recurrence, ['monthly_day', 'yearly'], true) && !$slot['day_of_month']) return null;
    if ($recurrence === 'yearly' && !$slot['month_of_year']) return null;
    if ($recurrence === 'date' && !$slot['on_date']) return null;
    if ($slot['valid_from'] && $slot['valid_until'] && $slot['valid_until'] < $slot['valid_from']) return null;
    return $slot;
}

function ihub_clean_slots($list) {
    if (!is_array($list)) return [];
    $slots = array_values(array_filter(array_map('ihub_clean_slot', array_slice($list, 0, 100))));
    usort($slots, function ($a, $b) { return strcmp($a['start_time'], $b['start_time']); });
    return $slots;
}

/* ---------- Public view ---------- */

function ihub_month_start($date) { return substr($date, 0, 7) . '-01'; }
function ihub_shift_month($date, $step) {
    return ihub_parse_date(ihub_month_start($date))->modify(($step >= 0 ? '+' : '') . (int) $step . ' month')->format('Y-m-d');
}

/**
 * Clinic schedule as a month calendar, a week table or a single day. Holidays that close clinics replace the times;
 * each time links to the booking system (per doctor/clinic, or the appointment link from the settings).
 * $args: view (month|week|day), date (YYYY-MM-DD), kind (doctor|clinic), base_url, navigation (bool)
 */
function ihub_render_schedule($args = []) {
    if (ihub_uses('schedule') && function_exists('idev_cs_render_schedule')) return idev_cs_render_schedule($args);
    $lang = ihub_lang();
    $d = ihub_t('doctors');
    $today = ihub_today();
    $view = in_array($args['view'] ?? '', ['month', 'week', 'day'], true) ? $args['view'] : 'week';
    $default_view = in_array($args['default_view'] ?? '', ['month', 'week', 'day'], true) ? $args['default_view'] : 'week';
    $anchor = ihub_is_valid_date($args['date'] ?? '') ? $args['date'] : $today;
    $filter = in_array($args['kind'] ?? '', ['doctor', 'clinic'], true) ? $args['kind'] : '';
    $navigation = !isset($args['navigation']) || $args['navigation'];
    $only = (int) ($args['provider'] ?? 0);
    $base = $args['base_url'] ?? get_permalink();
    $GLOBALS['ihub_schedule_provider'] = (int) ($args['provider'] ?? 0);

    if ($view === 'day') $dates = [$anchor];
    elseif ($view === 'week') { $monday = ihub_monday_of($anchor); $dates = []; for ($i = 0; $i < 7; $i++) $dates[] = ihub_add_days($monday, $i); }
    else {
        $first = ihub_month_start($anchor);
        $last = ihub_add_days(ihub_shift_month($anchor, 1), -1);
        $dates = [];
        for ($day = ihub_monday_of($first), $end = ihub_add_days(ihub_monday_of($last), 6); $day <= $end; $day = ihub_add_days($day, 1)) $dates[] = $day;
    }
    ihub_ensure_holiday_years(array_map(function ($date) { return (int) substr($date, 0, 4); }, $dates));
    $all = ihub_get_providers();
    $providers = $filter ? array_values(array_filter($all, function ($p) use ($filter) { return $p['kind'] === $filter; })) : $all;
    $single = null;
    if ($only) foreach ($all as $p) if ((int) $p['id'] === $only) $single = $p;
    if ($single) $providers = [$single];
    $holiday_on = [];
    foreach (ihub_get_holidays($dates[0], end($dates)) as $holiday) $holiday_on[$holiday['holiday_date']][] = $holiday;
    $closed = function ($date) use ($holiday_on) {
        foreach ($holiday_on[$date] ?? [] as $holiday) if ($holiday['closes_clinics']) return $holiday;
        return null;
    };
    $entries_on = function ($date, $list = null) use ($providers, $closed) {
        if ($closed($date)) return [];
        $entries = [];
        foreach ($list ?? $providers as $provider) foreach ($provider['slots'] as $slot) if (ihub_occurs_on($slot, $date)) $entries[] = ['provider' => $provider, 'slot' => $slot];
        usort($entries, function ($a, $b) { return strcmp($a['slot']['start_time'], $b['slot']['start_time']); });
        return $entries;
    };
    $appointment = ihub_setting('appointment_url');
    $name = function ($p) { return ihub_pick($p['name'], $p['name_en']); };
    $href = function ($changes) use ($view, $anchor, $filter, $today, $base, $default_view) {
        $v = $changes['view'] ?? $view; $dt = $changes['date'] ?? $anchor; $k = $changes['kind'] ?? $filter;
        $url = remove_query_arg(['view', 'date', 'kind', 'week', 'provider'], $base);
        $query = [];
        if (!empty($changes['provider_keep']) || (!array_key_exists('kind', $changes) && $GLOBALS['ihub_schedule_provider'])) $query['provider'] = $GLOBALS['ihub_schedule_provider'];
        if ($v !== $default_view) $query['view'] = $v;
        if ($dt !== $today) $query['date'] = $dt;
        if ($k) $query['kind'] = $k;
        return esc_url($query ? add_query_arg($query, $url) : $url);
    };
    $step = function ($direction) use ($view, $anchor) {
        if ($view === 'day') return ihub_add_days($anchor, $direction);
        if ($view === 'week') return ihub_add_days($anchor, $direction * 7);
        return ihub_shift_month($anchor, $direction);
    };
    $time_chip = function ($entry) use ($appointment, $d, $name) {
        $url = $entry['provider']['booking_url'] ?: $appointment;
        $slot = $entry['slot'];
        $note = ihub_pick($slot['note'], $slot['note_en']);
        $body = esc_html($slot['start_time'] . '–' . $slot['end_time']) . ($note !== '' ? '<small>' . esc_html($note) . '</small>' : '');
        if ($url) return '<a class="time-chip is-link" href="' . esc_url($url) . '" target="_blank" rel="noopener noreferrer" title="' . esc_attr($d['book'] . ': ' . $name($entry['provider'])) . '">' . $body . '<span class="chip-book">' . esc_html($d['book']) . ' ↗</span></a>';
        return '<span class="time-chip">' . $body . '</span>';
    };
    $holiday_tag = function ($date) use ($holiday_on, $d) {
        $html = '';
        foreach ($holiday_on[$date] ?? [] as $h) $html .= '<span class="holiday-chip' . ($h['closes_clinics'] ? ' is-closed' : '') . '">' . ($h['closes_clinics'] ? esc_html($d['closed']) . ' · ' : '') . esc_html(ihub_pick($h['name'], $h['name_en'])) . '</span>';
        return $html;
    };
    $avatar = function ($p) {
        if ($p['photo_url']) return '<img src="' . esc_url($p['photo_url']) . '" alt="">';
        return '<span class="doctor-avatar' . ($p['kind'] === 'clinic' ? ' is-clinic' : '') . '">' . ihub_icon($p['kind'] === 'clinic' ? 'plus' : 'emergency') . '</span>';
    };
    $day_name = function ($date) use ($d) { return $d['days'][ihub_iso_weekday($date) - 1]; };
    $day_card = function ($date, $large = false) use ($entries_on, $closed, $today, $d, $holiday_tag, $time_chip, $avatar, $name, $day_name) {
        $entries = $entries_on($date);
        $html = '<section class="schedule-day' . ($date === $today ? ' is-today' : '') . ($large ? ' is-large' : '') . ($closed($date) ? ' is-holiday' : '') . '">';
        $html .= '<h2>' . esc_html($day_name($date)) . ' <small>' . esc_html(ihub_format_short($date)) . '</small>' . ($date === $today ? '<span class="badge published">' . esc_html($d['today']) . '</span>' : '') . '</h2>';
        $html .= $holiday_tag($date);
        if (!$closed($date)) {
            if ($entries) {
                $html .= '<ul>';
                foreach ($entries as $entry) {
                    $p = $entry['provider'];
                    $specialty = ihub_pick($p['specialty'], $p['specialty_en']);
                    $html .= '<li>' . $time_chip($entry) . '<span class="day-provider">' . ($large ? $avatar($p) : '') . '<span><strong>' . esc_html($name($p)) . '</strong>' . ($specialty !== '' ? '<small>' . esc_html($specialty) . '</small>' : '') . '</span></span></li>';
                }
                $html .= '</ul>';
            } else $html .= '<p class="no-slot">' . esc_html($large ? $d['noneDay'] : $d['noDoctor']) . '</p>';
        }
        return $html . '</section>';
    };

    if (!$all) {
        $phone = ihub_setting('phone');
        return '<div class="empty-news"><span>' . ihub_icon('clock') . '</span><div><strong>' . esc_html($d['empty']) . '</strong><p><a href="tel:' . esc_attr($phone) . '">' . esc_html($d['call'] . ' ' . $phone) . '</a></p></div></div>';
    }

    if ($view === 'day') $title = ihub_format_day($anchor, $lang, true);
    elseif ($view === 'week') $title = ihub_format_day($dates[0], $lang) . ' – ' . ihub_format_day($dates[6], $lang);
    else $title = ihub_format_month($anchor, $lang);
    $is_current = $view === 'day' ? $anchor === $today : ($view === 'week' ? ihub_monday_of($anchor) === ihub_monday_of($today) : ihub_month_start($anchor) === ihub_month_start($today));
    $kinds = array_unique(array_column($all, 'kind'));
    $has_kinds = in_array('clinic', $kinds, true) && in_array('doctor', $kinds, true);

    $html = '<div class="schedule view-' . $view . '">';
    if ($single) $html .= '<div class="schedule-single"><strong>' . esc_html(str_replace('{name}', $name($single), ihub_t('ui.scheduleOf'))) . '</strong> <a class="text-link" href="' . $href(['kind' => '']) . '">' . esc_html(ihub_t('ui.showAll')) . ' →</a></div>';
    if ($navigation) {
        $html .= '<div class="schedule-toolbar"><div class="schedule-views" role="group" aria-label="' . esc_attr($d['viewAs']) . '">';
        foreach (['month' => $d['month'], 'week' => $d['week'], 'day' => $d['day']] as $v => $label) $html .= '<a href="' . $href(['view' => $v]) . '"' . ($view === $v ? ' class="active" aria-current="page"' : '') . '>' . esc_html($label) . '</a>';
        $html .= '</div>';
        if ($has_kinds) {
            $html .= '<nav class="news-tabs schedule-kinds" aria-label="' . esc_attr($d['name']) . '">';
            foreach (['' => $d['all'], 'doctor' => $d['doctors'], 'clinic' => $d['clinics']] as $value => $label) $html .= '<a href="' . $href(['kind' => $value]) . '"' . ($filter === $value ? ' class="active"' : '') . '>' . esc_html($label) . '</a>';
            $html .= '</nav>';
        }
        $html .= '<div class="schedule-weeknav"><a href="' . $href(['date' => $step(-1)]) . '">' . esc_html($d['previous']) . '</a><strong>' . esc_html($title) . '</strong>' . ($is_current ? '' : '<a href="' . $href(['date' => $today]) . '">' . esc_html($d['today']) . '</a>') . '<a href="' . $href(['date' => $step(1)]) . '">' . esc_html($d['following']) . '</a></div></div>';
    }
    if ($appointment || array_filter(array_column($providers, 'booking_url'))) $html .= '<p class="schedule-hint">' . esc_html($d['bookHint']) . '</p>';

    if ($view === 'month') {
        $html .= '<div class="month-calendar"><div class="month-head">';
        foreach ($d['daysShort'] as $day) $html .= '<span>' . esc_html($day) . '</span>';
        $html .= '</div><div class="month-grid">';
        foreach ($dates as $date) {
            $entries = $entries_on($date);
            $in_month = substr($date, 0, 7) === substr($anchor, 0, 7);
            $html .= '<div class="month-cell' . ($in_month ? '' : ' is-outside') . ($date === $today ? ' is-today' : '') . ($closed($date) ? ' is-holiday' : '') . '">';
            $html .= '<a class="month-day" href="' . $href(['view' => 'day', 'date' => $date]) . '"><strong>' . (int) substr($date, 8, 2) . '</strong>' . ($entries ? '<span class="month-count">' . count($entries) . '</span>' : '') . '</a>';
            $html .= $holiday_tag($date) . '<ul>';
            foreach (array_slice($entries, 0, 3) as $entry) $html .= '<li><span>' . esc_html($entry['slot']['start_time']) . '</span> ' . esc_html($name($entry['provider'])) . '</li>';
            $html .= '</ul>';
            if (count($entries) > 3) $html .= '<a class="month-more" href="' . $href(['view' => 'day', 'date' => $date]) . '">+' . (count($entries) - 3) . ' ' . esc_html($d['more']) . '</a>';
            $html .= '</div>';
        }
        $html .= '</div></div>';
    } elseif ($view === 'week') {
        $html .= '<div class="schedule-table-wrap"><table class="schedule-table"><thead><tr><th>' . esc_html($d['name']) . '</th>';
        foreach ($dates as $date) {
            $class = trim(($date === $today ? 'is-today' : '') . ($closed($date) ? ' is-holiday' : ''));
            $html .= '<th' . ($class ? ' class="' . $class . '"' : '') . '><a href="' . $href(['view' => 'day', 'date' => $date]) . '">' . esc_html($day_name($date)) . '<small>' . esc_html(ihub_format_short($date)) . ($date === $today ? ' · ' . esc_html($d['today']) : '') . '</small></a>' . $holiday_tag($date) . '</th>';
        }
        $html .= '</tr></thead><tbody>';
        foreach ($providers as $p) {
            $specialty = ihub_pick($p['specialty'], $p['specialty_en']);
            $note = ihub_pick($p['note'], $p['note_en']);
            $html .= '<tr><th scope="row"><div class="doctor-cell">' . $avatar($p) . '<span><strong>' . esc_html($name($p)) . '</strong>' . ($specialty !== '' ? '<small>' . esc_html($specialty) . '</small>' : '') . ($note !== '' ? '<em>' . esc_html($note) . '</em>' : '') . '</span></div></th>';
            foreach ($dates as $date) {
                $class = trim(($date === $today ? 'is-today' : '') . ($closed($date) ? ' is-holiday' : ''));
                $html .= '<td' . ($class ? ' class="' . $class . '"' : '') . '>';
                if ($closed($date)) $html .= '<span class="no-slot">' . esc_html($d['closed']) . '</span>';
                else {
                    $entries = $entries_on($date, [$p]);
                    $html .= $entries ? implode('', array_map($time_chip, $entries)) : '<span class="no-slot">—</span>';
                }
                $html .= '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</tbody></table></div><div class="schedule-days">';
        $index = array_search($today, $dates, true);
        $ordered = $index === false ? $dates : array_merge(array_slice($dates, $index), array_slice($dates, 0, $index));
        foreach ($ordered as $date) $html .= $day_card($date);
        $html .= '</div>';
    } else {
        $html .= $day_card($anchor, true);
    }
    return $html . '</div>';
}

/** [idevapp_schedule view="week" navigation="1"] — reads ?view= &date= &kind= from the address. */
add_shortcode('idevapp_schedule', function ($atts) {
    $atts = shortcode_atts(['view' => 'week', 'navigation' => '1'], $atts);
    $navigation = $atts['navigation'] !== '0';
    return ihub_render_schedule([
        'view' => $navigation && isset($_GET['view']) ? sanitize_key($_GET['view']) : $atts['view'],
        'default_view' => $atts['view'],
        'date' => $navigation && isset($_GET['date']) ? sanitize_text_field(wp_unslash($_GET['date'])) : (isset($_GET['week']) ? sanitize_text_field(wp_unslash($_GET['week'])) : ''),
        'kind' => $navigation && isset($_GET['kind']) ? sanitize_key($_GET['kind']) : '',
        'provider' => $navigation && isset($_GET['provider']) ? (int) $_GET['provider'] : 0,
        'navigation' => $navigation,
    ]);
});
