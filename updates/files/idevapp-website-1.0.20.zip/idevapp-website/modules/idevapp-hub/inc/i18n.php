<?php
/** Two languages (TH/EN). The visitor's choice is kept in the "lang" cookie, like the old site. */
defined('ABSPATH') || exit;

function ihub_messages() {
    static $messages = null;
    if ($messages === null) $messages = json_decode(file_get_contents(__DIR__ . '/messages.json'), true);
    return $messages;
}

/** Current visitor language: "th" or "en". The block editor preview can force one with ihub_set_lang(). */
function ihub_lang() {
    global $ihub_forced_lang;
    if ($ihub_forced_lang) return $ihub_forced_lang;
    if (is_admin() && !wp_doing_ajax()) return 'th';
    if (ihub_uses('bilingual') && function_exists('idev_bilingual_lang')) return idev_bilingual_lang() === 'en' ? 'en' : 'th';
    return (isset($_COOKIE['lang']) && $_COOKIE['lang'] === 'en') ? 'en' : 'th';
}

function ihub_set_lang($lang) {
    global $ihub_forced_lang;
    $ihub_forced_lang = in_array($lang, ['th', 'en'], true) ? $lang : null;
}

/** Message by dot path, e.g. ihub_t('home.emergencyCall'). Arrays are returned as arrays. */
function ihub_t($path, $lang = null) {
    $value = ihub_messages()[$lang ?: ihub_lang()];
    foreach (explode('.', $path) as $key) {
        if (!is_array($value) || !array_key_exists($key, $value)) return '';
        $value = $value[$key];
    }
    return $value;
}

/** English text when English is chosen and filled in, otherwise Thai. */
function ihub_pick($th, $en, $lang = null) {
    $lang = $lang ?: ihub_lang();
    return ($lang === 'en' && is_string($en) && trim($en) !== '') ? $en : (string) $th;
}

/** {th, en} array (block data) resolved to the current language. */
function ihub_tx($value, $lang = null) {
    if (!is_array($value)) return (string) $value;
    return ihub_pick($value['th'] ?? '', $value['en'] ?? '', $lang);
}

/** URL that switches the language and comes back to the current page. */
function ihub_lang_url($lang) {
    return function_exists('idev_bilingual_url') && ihub_uses('bilingual') ? idev_bilingual_url($lang) : add_query_arg('lang', $lang);
}

function ihub_en_meta($post_id, $key) {
    if (ihub_uses('bilingual')) { $v = (string) get_post_meta($post_id, "_idev_{$key}_en", true); if ($v !== '') return $v; }
    return (string) get_post_meta($post_id, "ihub_{$key}_en", true);
}

/** Category name in the current language (term meta ihub_name_en). */
function ihub_term_name($term) {
    if (!$term) return '';
    $en = ihub_uses('bilingual') ? (string) get_term_meta($term->term_id, 'idev_name_en', true) : '';
    return ihub_pick($term->name, $en !== '' ? $en : (string) get_term_meta($term->term_id, 'ihub_name_en', true));
}

/* Visitor-facing language switching. iDev Bilingual does all of this when it is active. */
if (!ihub_uses('bilingual')) :

// ?lang=en / ?lang=th sets the cookie and reloads the same page without the parameter.
add_action('template_redirect', function () {
    if (!isset($_GET['lang']) || !in_array($_GET['lang'], ['th', 'en'], true)) return;
    $lang = sanitize_key($_GET['lang']);
    setcookie('lang', $lang, ['expires' => time() + YEAR_IN_SECONDS, 'path' => COOKIEPATH ?: '/', 'samesite' => 'Lax', 'secure' => is_ssl()]);
    $_COOKIE['lang'] = $lang;
    nocache_headers();
    wp_safe_redirect(remove_query_arg('lang'));
    exit;
}, 1);

// Pages differ per language cookie: tell caches.
add_action('send_headers', function () {
    if (!is_admin()) header('Vary: Cookie', false);
});

add_filter('language_attributes', function ($output) {
    if (is_admin()) return $output;
    return preg_replace('/lang="[^"]*"/', 'lang="' . ihub_lang() . '"', $output);
});

// Site name and tagline follow the language (Settings → ตั้งค่าเว็บไซต์).
foreach (['blogname' => 'site_name', 'blogdescription' => 'site_tagline'] as $ihub_option => $ihub_key) {
    add_filter("option_{$ihub_option}", function ($value) use ($ihub_key) {
        if (is_admin() || ihub_lang() !== 'en') return $value;
        $en = ihub_setting($ihub_key . '_en');
        return $en !== '' ? $en : $value;
    });
}

/* ---------- English versions of posts and pages (meta box "ภาษาอังกฤษ") ---------- */


add_filter('the_title', function ($title, $post_id = 0) {
    if (is_admin() || !$post_id || ihub_lang() !== 'en') return $title;
    $en = ihub_en_meta($post_id, 'title');
    return $en !== '' ? esc_html($en) : $title;
}, 10, 2);

add_filter('single_post_title', function ($title, $post) {
    if (ihub_lang() !== 'en' || !$post) return $title;
    $en = ihub_en_meta($post->ID, 'title');
    return $en !== '' ? $en : $title;
}, 10, 2);

add_filter('get_the_excerpt', function ($excerpt, $post) {
    if (is_admin() || ihub_lang() !== 'en' || !$post) return $excerpt;
    $en = ihub_en_meta($post->ID, 'excerpt');
    return $en !== '' ? $en : $excerpt;
}, 10, 2);

// Whole content swapped before blocks/shortcodes run, when an English body was written.
add_filter('the_content', function ($content) {
    if (is_admin() || ihub_lang() !== 'en') return $content;
    $post = get_post();
    if (!$post || !in_the_loop()) return $content;
    $en = ihub_en_meta($post->ID, 'content');
    return trim($en) !== '' ? $en : $content;
}, 1);



/* ---------- Menu labels in English ---------- */

add_action('wp_nav_menu_item_custom_fields', function ($item_id) {
    $value = get_post_meta($item_id, '_ihub_label_en', true);
    echo '<p class="description description-wide"><label>ชื่อเมนูภาษาอังกฤษ (English label)<br><input type="text" class="widefat" name="ihub_label_en[' . (int) $item_id . ']" value="' . esc_attr($value) . '"></label></p>';
});
add_action('wp_update_nav_menu_item', function ($menu_id, $item_id) {
    if (!isset($_POST['ihub_label_en'][$item_id])) return;
    update_post_meta($item_id, '_ihub_label_en', sanitize_text_field(wp_unslash($_POST['ihub_label_en'][$item_id])));
}, 10, 2);
add_filter('wp_nav_menu_objects', function ($items) {
    if (ihub_lang() !== 'en') return $items;
    foreach ($items as $item) {
        $en = get_post_meta($item->ID, '_ihub_label_en', true);
        if ($en !== '') $item->title = $en;
    }
    return $items;
});

endif;

// Pages built from iDevApp blocks are already bilingual: an old separate English body
// (written before the blocks) must not replace them, so EN shows the same layout as TH.
add_filter('the_content', function ($content) {
    if (is_admin() || ihub_lang() !== 'en') return $content;
    $post = get_post();
    if (!$post || !in_the_loop()) return $content;
    $main = (string) $post->post_content;
    if (strpos($main, '<!-- wp:idevapp/') !== false && strpos($content, '<!-- wp:idevapp/') === false) return $main;
    return $content;
}, 2);
