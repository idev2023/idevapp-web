<?php
/** Posts and pages: English version, page options (layout, title, map, contact), news display style, attachments. */
defined('ABSPATH') || exit;

add_action('init', function () {
    add_post_type_support('page', 'excerpt');
});

function ihub_page_layouts() {
    return ['standard' => 'มาตรฐาน', 'cards' => 'การ์ด (แยกตามหัวข้อ H3)', 'sidebar' => 'มีแถบข้าง (ข้อมูลติดต่อ)', 'full' => 'เต็มความกว้าง', 'banner' => 'แบนเนอร์ภาพใหญ่ด้านบน'];
}

/** Page options with defaults. */
function ihub_page_options($post_id) {
    $get = function ($key, $default) use ($post_id) {
        $value = get_post_meta($post_id, "ihub_{$key}", true);
        return $value === '' ? $default : $value;
    };
    return [
        'layout' => array_key_exists($get('layout', 'standard'), ihub_page_layouts()) ? $get('layout', 'standard') : 'standard',
        'show_title' => $get('show_title', '1') === '1',
        'show_map' => $get('show_map', '0') === '1',
        'show_contact' => $get('show_contact', '1') === '1',
    ];
}

add_action('add_meta_boxes', function () {
    if (!ihub_uses('bilingual')) foreach (['post', 'page'] as $type) add_meta_box('ihub_english', 'ภาษาอังกฤษ (English version)', 'ihub_english_box', $type, 'normal', 'high');
    add_meta_box('ihub_page_options', 'ตั้งค่าหน้า', 'ihub_page_options_box', 'page', 'side', 'high');
    add_meta_box('ihub_post_options', 'การแสดงข่าว', 'ihub_post_options_box', 'post', 'side', 'high');
    if (!ihub_uses('attachments')) add_meta_box('ihub_attachments', 'เอกสารแนบ (PDF, Word, Excel, PowerPoint)', 'ihub_attachments_box', 'post', 'normal', 'default');
});

function ihub_english_box($post) {
    wp_nonce_field('ihub_content_save', 'ihub_content_nonce');
    echo '<div class="ihub-admin"><p class="description">เว้นว่างได้ — ผู้ชมที่เลือก EN จะเห็นภาษาไทยแทนส่วนที่ไม่ได้กรอก · บล็อก “iDevApp” ในหน้ามีช่องภาษาอังกฤษในตัว</p>';
    echo '<label class="ihub-wide">Title (English)<input name="ah[title_en]" value="' . esc_attr(ihub_en_meta($post->ID, 'title')) . '"></label>';
    echo '<label class="ihub-wide">' . ($post->post_type === 'page' ? 'Summary under the title (English)' : 'Excerpt (English)') . '<textarea name="ah[excerpt_en]" rows="2">' . esc_textarea(ihub_en_meta($post->ID, 'excerpt')) . '</textarea></label>';
    echo '<p><strong>Content (English)</strong> — ใช้แทนเนื้อหาหลักทั้งหมดเมื่อผู้ชมเลือก EN</p>';
    wp_editor(ihub_en_meta($post->ID, 'content'), 'ihub_content_en', ['textarea_name' => 'ah[content_en]', 'textarea_rows' => 10, 'media_buttons' => true]);
    echo '</div>';
}

function ihub_page_options_box($post) {
    $o = ihub_page_options($post->ID);
    echo '<div class="ihub-admin ihub-side">';
    echo '<label>รูปแบบหน้า<select name="ah[layout]">';
    foreach (ihub_page_layouts() as $value => $label) echo '<option value="' . $value . '"' . selected($o['layout'], $value, false) . '>' . esc_html($label) . '</option>';
    echo '</select></label>';
    echo '<label class="ihub-check"><input type="checkbox" name="ah[show_title]" value="1"' . checked($o['show_title'], true, false) . '> แสดงแถบหัวข้อหน้า</label>';
    echo '<label class="ihub-check"><input type="checkbox" name="ah[show_map]" value="1"' . checked($o['show_map'], true, false) . '> แสดง Google Map</label>';
    echo '<label class="ihub-check"><input type="checkbox" name="ah[show_contact]" value="1"' . checked($o['show_contact'], true, false) . '> แสดงกล่อง “ติดต่อเรา” ท้ายหน้า</label>';
    echo '<p class="description">คำโปรยใต้หัวข้อ = ช่อง “ข้อความสรุป” (Excerpt) · ภาพแบนเนอร์/ภาพประกอบ = “รูปภาพประจำหน้า” · หน้าที่สร้างด้วยบล็อก iDevApp ใช้รูปแบบ “เต็มความกว้าง” จะสวยที่สุด</p></div>';
}

function ihub_post_options_box($post) {
    $style = get_post_meta($post->ID, 'ihub_display_style', true) ?: 'card';
    echo '<div class="ihub-admin ihub-side"><label>รูปแบบการแสดง<select name="ah[display_style]">';
    foreach (['card' => 'การ์ดข่าว', 'featured' => 'ข่าวเด่น (ภาพใหญ่)', 'compact' => 'รายการย่อ'] as $value => $label) echo '<option value="' . $value . '"' . selected($style, $value, false) . '>' . esc_html($label) . '</option>';
    echo '</select></label><p class="description">ภาพข่าว = “รูปภาพประจำเรื่อง” · คำโปรย = “ข้อความสรุป”</p></div>';
}

function ihub_get_attachments($post_id) {
    $list = json_decode((string) get_post_meta($post_id, 'ihub_attachments', true), true);
    $files = [];
    foreach (is_array($list) ? $list : [] as $item) {
        $id = (int) ($item['id'] ?? 0);
        $path = $id ? get_attached_file($id) : '';
        if (!$path) continue;
        $files[] = ['id' => $id, 'label' => (string) ($item['label'] ?? ''), 'url' => wp_get_attachment_url($id), 'name' => wp_basename($path), 'title' => get_the_title($id), 'size' => file_exists($path) ? filesize($path) : 0, 'ext' => strtolower(pathinfo($path, PATHINFO_EXTENSION))];
    }
    return $files;
}

function ihub_attachments_box($post) {
    wp_enqueue_media();
    $files = ihub_get_attachments($post->ID);
    echo '<div class="ihub-admin" id="ihub-attachments" data-files="' . esc_attr(wp_json_encode($files)) . '"></div>';
    echo '<input type="hidden" name="ah[attachments]" id="ihub-attachments-input" value="' . esc_attr(wp_json_encode(array_map(function ($f) { return ['id' => $f['id'], 'label' => $f['label']]; }, $files))) . '">';
}

add_action('save_post', function ($post_id, $post) {
    if (!in_array($post->post_type, ['post', 'page'], true)) return;
    if (!isset($_POST['ihub_content_nonce']) || !wp_verify_nonce(sanitize_key($_POST['ihub_content_nonce']), 'ihub_content_save')) return;
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $post_id)) return;
    $in = isset($_POST['ah']) && is_array($_POST['ah']) ? wp_unslash($_POST['ah']) : [];
    if (isset($in['title_en'])) { // English box is shown (not handed to iDev Bilingual)
        update_post_meta($post_id, 'ihub_title_en', sanitize_text_field($in['title_en'] ?? ''));
        update_post_meta($post_id, 'ihub_excerpt_en', sanitize_textarea_field($in['excerpt_en'] ?? ''));
        update_post_meta($post_id, 'ihub_content_en', wp_slash(wp_kses_post($in['content_en'] ?? '')));
    }
    if ($post->post_type === 'page') {
        update_post_meta($post_id, 'ihub_layout', array_key_exists($in['layout'] ?? '', ihub_page_layouts()) ? $in['layout'] : 'standard');
        foreach (['show_title', 'show_map', 'show_contact'] as $key) update_post_meta($post_id, "ihub_{$key}", empty($in[$key]) ? '0' : '1');
    } else {
        update_post_meta($post_id, 'ihub_display_style', in_array($in['display_style'] ?? '', ['card', 'featured', 'compact'], true) ? $in['display_style'] : 'card');
        if (!isset($in['attachments'])) return; // handled by iDev Post Attachments
        $list = json_decode((string) ($in['attachments'] ?? '[]'), true);
        $clean = [];
        foreach (is_array($list) ? $list : [] as $item) {
            $id = (int) ($item['id'] ?? 0);
            if ($id && get_post_type($id) === 'attachment') $clean[] = ['id' => $id, 'label' => mb_substr(sanitize_text_field($item['label'] ?? ''), 0, 200)];
        }
        update_post_meta($post_id, 'ihub_attachments', wp_slash(wp_json_encode($clean, JSON_UNESCAPED_UNICODE)));
    }
}, 10, 2);

add_action('admin_enqueue_scripts', function ($hook) {
    $screen = get_current_screen();
    if ($screen && $screen->post_type === 'post' && in_array($hook, ['post.php', 'post-new.php'], true) && !ihub_uses('attachments')) {
        wp_enqueue_script('ihub-attachments', IHUB_URL . 'assets/attachments.js', ['jquery'], IHUB_VERSION, true);
    }
});

/** File list under a news article. */
function ihub_render_attachments($post_id) {
    if (ihub_uses('attachments') && function_exists('idev_attachments_render')) return idev_attachments_render($post_id);
    $files = ihub_get_attachments($post_id);
    if (!$files) return '';
    $labels = ['pdf' => 'PDF', 'doc' => 'Word', 'docx' => 'Word', 'xls' => 'Excel', 'xlsx' => 'Excel', 'ppt' => 'PowerPoint', 'pptx' => 'PowerPoint'];
    $html = '<section class="attachment-list"><h2>' . esc_html(ihub_t('newsExtra.attachments')) . '</h2><ul>';
    foreach ($files as $file) {
        $ext = $file['ext'];
        $name = $file['label'] ?: ($file['title'] ?: $file['name']);
        $html .= '<li><a href="' . esc_url($file['url']) . '"' . ($ext === 'pdf' ? ' target="_blank" rel="noopener"' : ' download="' . esc_attr($file['name']) . '"') . '><span class="file-badge file-' . esc_attr($ext) . '">' . esc_html(strtoupper($ext)) . '</span><span class="attachment-name">' . esc_html($name) . '<small>' . esc_html(($labels[$ext] ?? strtoupper($ext)) . ' · ' . ihub_format_bytes($file['size'])) . '</small></span><span class="attachment-action">' . esc_html(ihub_t('newsExtra.download')) . ' ↓</span></a></li>';
    }
    return $html . '</ul></section>';
}
