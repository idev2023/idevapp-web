<?php
/**
 * News announcements: one template for every news item (category · title · summary · details · cover · attachments)
 * and approval. Nothing is shown on the website until a news approver (cap ihub_news_approve) approves it.
 * Page "ประกาศข่าว" (edit_posts): write, my news, waiting for approval (approvers).
 * Each category can have its own starting text for the details (Posts → Categories → edit).
 */
defined('ABSPATH') || exit;

function ihub_news_can_approve($user_id = null) { return $user_id ? user_can($user_id, 'ihub_news_approve') : current_user_can('ihub_news_approve'); }

/* Administrators approve by default (added once). */
add_action('admin_init', function () {
    if (get_option('ihub_news_cap_v') === '1') return;
    $admin = get_role('administrator');
    if ($admin) $admin->add_cap('ihub_news_approve');
    update_option('ihub_news_cap_v', '1');
});
add_filter('ihub_rbac_caps', function ($g) {
    $k = 'ข่าวสาร ตารางออกตรวจ และเครื่องมือเว็บไซต์';
    if (isset($g[$k])) {
        $g[$k] = ['ihub_news_approve' => ['อนุมัติข่าวประกาศ (ผู้ดูแลข่าว)', 'ข่าวจะแสดงบนเว็บเมื่อผู้มีสิทธิ์นี้อนุมัติเท่านั้น']] + $g[$k];
        if (isset($g[$k]['publish_posts'])) $g[$k]['publish_posts'] = ['ส่งข่าวขออนุมัติได้เอง', 'ข่าวยังต้องผ่านการอนุมัติก่อนแสดง'];
    }
    return $g;
});

/* Every news item written by someone without approval rights waits for approval — also edits of published news. */
add_filter('wp_insert_post_data', function ($data, $postarr) {
    if (($data['post_type'] ?? '') !== 'post' || !get_current_user_id() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) return $data;
    if (in_array($data['post_status'], ['publish', 'future'], true) && !ihub_news_can_approve()) {
        $data['post_status'] = 'pending';
    }
    return $data;
}, 20, 2);
add_action('transition_post_status', function ($new, $old, $post) {
    if ($post->post_type !== 'post' || $new === $old) return;
    if ($new === 'pending') {
        update_post_meta($post->ID, '_ihub_news_sent', current_time('mysql'));
        delete_post_meta($post->ID, '_ihub_news_note');
        $to = array_values(array_filter(array_map('strval', (array) get_users(['capability' => 'ihub_news_approve', 'fields' => 'user_email'])), 'is_email'));
        foreach (array_slice($to, 0, 20) as $addr) wp_mail($addr, '[ข่าวรออนุมัติ] ' . $post->post_title, "มีข่าวรออนุมัติ: {$post->post_title}\nโดย " . get_the_author_meta('display_name', $post->post_author) . "\n\nตรวจและอนุมัติ: " . admin_url('admin.php?page=ihub-news&tab=review'));
    }
}, 10, 3);

/* ---------- menu ---------- */

function ihub_news_pending_count() {
    $c = wp_count_posts('post');
    return (int) ($c->pending ?? 0);
}
add_action('admin_menu', function () {
    $n = ihub_news_can_approve() ? ihub_news_pending_count() : 0;
    add_menu_page('ประกาศข่าว', 'ประกาศข่าว' . ($n ? ' <span class="awaiting-mod">' . $n . '</span>' : ''), 'edit_posts', 'ihub-news', 'ihub_news_page', 'dashicons-megaphone', 3);
});

/* ---------- category templates ---------- */

function ihub_news_default_template() {
    return '<h3>รายละเอียด</h3><p>…</p><h3>วัน เวลา และสถานที่</h3><p>…</p><h3>ติดต่อสอบถาม</h3><p>โทร …</p>';
}
add_action('category_edit_form_fields', function ($term) {
    echo '<tr class="form-field"><th scope="row"><label>แม่แบบเนื้อหาข่าว</label></th><td>';
    wp_editor((string) get_term_meta($term->term_id, 'ihub_news_template', true), 'ihub_news_template', ['textarea_name' => 'ihub_news_template', 'textarea_rows' => 8, 'media_buttons' => false]);
    echo '<p class="description">ข้อความเริ่มต้นของ “รายละเอียด” เมื่อเขียนประกาศในหมวดนี้ (หน้า ประกาศข่าว)</p></td></tr>';
});
add_action('edited_category', function ($term_id) {
    if (!current_user_can('manage_categories') || !isset($_POST['ihub_news_template'])) return; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- term edit screen checks its own nonce
    update_term_meta($term_id, 'ihub_news_template', wp_kses_post(wp_unslash($_POST['ihub_news_template']))); // phpcs:ignore WordPress.Security.NonceVerification.Missing
});

/* ---------- saving ---------- */

function ihub_news_attach_key() { return ihub_uses('attachments') ? '_idev_attachments' : 'ihub_attachments'; }
function ihub_news_get_files($post_id) {
    $list = json_decode((string) get_post_meta($post_id, ihub_news_attach_key(), true), true);
    $out = [];
    foreach (is_array($list) ? $list : [] as $f) { $id = (int) ($f['id'] ?? 0); if ($id && get_post_type($id) === 'attachment') $out[] = ['id' => $id, 'label' => (string) ($f['label'] ?? ''), 'name' => wp_basename((string) get_attached_file($id))]; }
    return $out;
}

add_action('admin_post_ihub_news_save', function () {
    if (!current_user_can('edit_posts') || !check_admin_referer('ihub_news_save')) wp_die('ไม่มีสิทธิ์', 403);
    $id = (int) ($_POST['post_id'] ?? 0);
    if ($id && (!current_user_can('edit_post', $id) || get_post_type($id) !== 'post')) wp_die('ไม่มีสิทธิ์', 403);
    $title = sanitize_text_field(wp_unslash($_POST['title'] ?? ''));
    $cat = (int) ($_POST['cat'] ?? 0);
    $back = admin_url('admin.php?page=ihub-news');
    if ($title === '' || !$cat || !term_exists($cat, 'category')) { wp_safe_redirect(add_query_arg(['tab' => 'write', 'post' => $id, 'err' => 'need'], $back)); exit; }
    $send = ($_POST['go'] ?? '') === 'send';
    $status = $send ? (ihub_news_can_approve() && ($_POST['go_publish'] ?? '') === '1' ? 'publish' : 'pending') : 'draft';
    $arr = ['post_type' => 'post', 'post_title' => $title, 'post_excerpt' => sanitize_textarea_field(wp_unslash($_POST['summary'] ?? '')), 'post_content' => wp_kses_post(wp_unslash($_POST['details'] ?? '')), 'post_status' => $status, 'post_category' => [$cat]];
    if ($id) { $arr['ID'] = $id; $id = wp_update_post(wp_slash($arr), true); } else { $id = wp_insert_post(wp_slash($arr), true); }
    if (is_wp_error($id)) wp_die(esc_html($id->get_error_message()));
    $cover = (int) ($_POST['cover'] ?? 0);
    if ($cover && get_post_type($cover) === 'attachment') set_post_thumbnail($id, $cover); elseif (!$cover) delete_post_thumbnail($id);
    $files = [];
    foreach (array_map('intval', (array) ($_POST['files'] ?? [])) as $i => $fid) {
        if ($fid && get_post_type($fid) === 'attachment') $files[] = ['id' => $fid, 'label' => mb_substr(sanitize_text_field(wp_unslash($_POST['file_labels'][$i] ?? '')), 0, 200), 'label_en' => ''];
    }
    update_post_meta($id, ihub_news_attach_key(), wp_slash(wp_json_encode($files, JSON_UNESCAPED_UNICODE)));
    $real = get_post_status($id);
    wp_safe_redirect(add_query_arg(['tab' => 'mine', 'done' => $real === 'publish' ? 'published' : ($real === 'pending' ? 'sent' : 'draft')], $back));
    exit;
});

add_action('admin_post_ihub_news_review', function () {
    $id = (int) ($_POST['post_id'] ?? 0);
    if (!ihub_news_can_approve() || !check_admin_referer('ihub_news_review_' . $id) || get_post_type($id) !== 'post') wp_die('ไม่มีสิทธิ์', 403);
    $post = get_post($id);
    $author = get_userdata($post->post_author);
    $me = wp_get_current_user()->display_name;
    if (($_POST['decision'] ?? '') === 'approve') {
        wp_update_post(['ID' => $id, 'post_status' => 'publish']);
        update_post_meta($id, '_ihub_news_approved', ['by' => $me, 'at' => current_time('mysql')]);
        if ($author && $author->user_email) wp_mail($author->user_email, '[อนุมัติแล้ว] ' . $post->post_title, "ข่าว “{$post->post_title}” ได้รับการอนุมัติและแสดงบนเว็บแล้ว\n" . get_permalink($id));
        $done = 'approved';
    } else {
        $note = sanitize_textarea_field(wp_unslash($_POST['note'] ?? ''));
        wp_update_post(['ID' => $id, 'post_status' => 'draft']);
        update_post_meta($id, '_ihub_news_note', ['by' => $me, 'at' => current_time('mysql'), 'text' => $note]);
        if ($author && $author->user_email) wp_mail($author->user_email, '[ส่งกลับแก้ไข] ' . $post->post_title, "ข่าว “{$post->post_title}” ถูกส่งกลับให้แก้ไข\n\n{$note}\n\nแก้ไข: " . admin_url('admin.php?page=ihub-news&tab=write&post=' . $id));
        $done = 'returned';
    }
    wp_safe_redirect(admin_url('admin.php?page=ihub-news&tab=review&done=' . $done));
    exit;
});

/* ---------- page ---------- */

function ihub_news_page() {
    if (!current_user_can('edit_posts')) wp_die('ไม่มีสิทธิ์');
    $approver = ihub_news_can_approve();
    $tab = sanitize_key($_GET['tab'] ?? ($approver && ihub_news_pending_count() ? 'review' : 'write')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $u = function ($args) { return esc_url(add_query_arg($args, admin_url('admin.php?page=ihub-news'))); };
    $done = sanitize_key($_GET['done'] ?? ''); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $msgs = ['sent' => 'ส่งข่าวขออนุมัติแล้ว — จะแสดงบนเว็บเมื่อผู้ดูแลข่าวอนุมัติ', 'draft' => 'บันทึกร่างแล้ว', 'published' => 'เผยแพร่แล้ว', 'approved' => 'อนุมัติแล้ว ข่าวแสดงบนเว็บ', 'returned' => 'ส่งกลับให้ผู้เขียนแก้ไขแล้ว'];
    echo '<div class="wrap ihub-news"><h1>ประกาศข่าว</h1><p class="description">ทุกข่าวใช้แบบเดียวกัน: หมวดข่าว · หัวเรื่อง · เนื้อหาย่อย · รายละเอียด · ไฟล์แนบ — ข่าวจะแสดงบนเว็บเมื่อผู้ดูแลข่าวประกาศอนุมัติแล้วเท่านั้น</p>';
    if (isset($msgs[$done])) echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($msgs[$done]) . '</p></div>';
    if (($_GET['err'] ?? '') === 'need') echo '<div class="notice notice-error"><p>กรุณาเลือกหมวดข่าวและใส่หัวเรื่อง</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $n = ihub_news_pending_count();
    echo '<nav class="nav-tab-wrapper"><a class="nav-tab' . ($tab === 'write' ? ' nav-tab-active' : '') . '" href="' . $u(['tab' => 'write']) . '">✎ เขียนประกาศ</a><a class="nav-tab' . ($tab === 'mine' ? ' nav-tab-active' : '') . '" href="' . $u(['tab' => 'mine']) . '">ข่าวของฉัน</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if ($approver) echo '<a class="nav-tab' . ($tab === 'review' ? ' nav-tab-active' : '') . '" href="' . $u(['tab' => 'review']) . '">รออนุมัติ' . ($n ? ' <span class="ihub-badge">' . $n . '</span>' : '') . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</nav>';
    if ($tab === 'review' && $approver) ihub_news_review_tab();
    elseif ($tab === 'mine') ihub_news_mine_tab($u);
    else ihub_news_form();
    echo '</div>';
}

function ihub_news_form() {
    $id = (int) ($_GET['post'] ?? 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $post = $id ? get_post($id) : null;
    if ($post && ($post->post_type !== 'post' || !current_user_can('edit_post', $id))) $post = null;
    $cats = get_terms(['taxonomy' => 'category', 'hide_empty' => false]);
    $cur = $post ? (int) (wp_get_post_categories($post->ID)[0] ?? 0) : 0;
    $note = $post ? get_post_meta($post->ID, '_ihub_news_note', true) : null;
    $tpl = [];
    foreach ($cats as $c) { $t = (string) get_term_meta($c->term_id, 'ihub_news_template', true); $tpl[$c->term_id] = $t !== '' ? $t : ihub_news_default_template(); }
    $cover = $post ? (int) get_post_thumbnail_id($post->ID) : 0;
    $files = $post ? ihub_news_get_files($post->ID) : [];
    $media = current_user_can('upload_files');
    if ($media) wp_enqueue_media();
    if (is_array($note) && ($note['text'] ?? '') !== '' && $post->post_status === 'draft') echo '<div class="notice notice-warning"><p><b>ผู้ดูแลข่าวส่งกลับให้แก้ไข</b> (' . esc_html($note['by'] . ' · ' . $note['at']) . '): ' . esc_html($note['text']) . '</p></div>';
    if ($post && $post->post_status === 'publish' && !ihub_news_can_approve()) echo '<div class="notice notice-info"><p>ข่าวนี้แสดงบนเว็บอยู่ ถ้าแก้ไขแล้วส่ง จะต้องรออนุมัติใหม่ก่อนแสดง</p></div>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="ihub-news-form">' . wp_nonce_field('ihub_news_save', '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_news_save"><input type="hidden" name="post_id" value="' . (int) ($post->ID ?? 0) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div class="ihub-nf-main"><div class="ihub-nf-card"><span class="ihub-nf-step">1</span><label>หมวดข่าว *<select name="cat" id="ihub-news-cat" required><option value="">— เลือกหมวด —</option>';
    foreach ($cats as $c) echo '<option value="' . (int) $c->term_id . '"' . selected($cur, $c->term_id, false) . '>' . esc_html($c->name) . '</option>';
    echo '</select></label></div>';
    echo '<div class="ihub-nf-card"><span class="ihub-nf-step">2</span><label>หัวเรื่อง *<input name="title" required maxlength="200" value="' . esc_attr($post->post_title ?? '') . '" placeholder="เช่น ประกาศวันหยุดคลินิก วันที่ …" class="ihub-nf-title"></label>';
    echo '<label>เนื้อหาย่อย (สรุปสั้น ๆ แสดงใต้หัวเรื่องและในการ์ดข่าว)<textarea name="summary" rows="3" maxlength="400">' . esc_textarea($post->post_excerpt ?? '') . '</textarea></label></div>';
    echo '<div class="ihub-nf-card"><span class="ihub-nf-step">3</span><b>รายละเอียด</b> <button type="button" class="button button-small" id="ihub-news-tpl">ใส่แม่แบบของหมวดนี้</button>';
    wp_editor($post->post_content ?? '', 'ihub_news_details', ['textarea_name' => 'details', 'textarea_rows' => 14, 'media_buttons' => $media]);
    echo '</div></div><div class="ihub-nf-side">';
    if ($media) {
        echo '<div class="ihub-nf-card"><b>รูปหน้าปก</b><div id="ihub-news-cover-prev" class="ihub-nf-cover">' . ($cover ? wp_get_attachment_image($cover, 'medium') : '<span>ยังไม่มีรูป</span>') . '</div><input type="hidden" name="cover" id="ihub-news-cover" value="' . (int) $cover . '"><button type="button" class="button" id="ihub-news-cover-pick">เลือกรูป</button> <button type="button" class="button-link" id="ihub-news-cover-clear">นำออก</button></div>';
        echo '<div class="ihub-nf-card"><b>ไฟล์แนบ</b> <small>(PDF, Word, Excel, รูป)</small><ul id="ihub-news-files">';
        foreach ($files as $f) echo '<li><input type="hidden" name="files[]" value="' . (int) $f['id'] . '"><span class="fn">' . esc_html($f['name']) . '</span><input name="file_labels[]" value="' . esc_attr($f['label']) . '" placeholder="ชื่อที่แสดง"><button type="button" class="button-link-delete" data-rm>ลบ</button></li>';
        echo '</ul><button type="button" class="button" id="ihub-news-file-add">＋ แนบไฟล์</button></div>';
    }
    echo '<div class="ihub-nf-card ihub-nf-send"><button class="button button-large" name="go" value="draft">บันทึกร่าง</button><button class="button button-primary button-large" name="go" value="send">' . (ihub_news_can_approve() ? 'บันทึกและเผยแพร่' : 'ส่งขออนุมัติ') . '</button>' . (ihub_news_can_approve() ? '<input type="hidden" name="go_publish" value="1">' : '') . '<p class="description">' . (ihub_news_can_approve() ? 'คุณเป็นผู้ดูแลข่าว: ข่าวของคุณเผยแพร่ได้ทันที' : 'ข่าวจะยังไม่แสดงบนเว็บจนกว่าผู้ดูแลข่าวจะอนุมัติ') . '</p></div></div></form>';
    $js = 'var T=' . wp_json_encode($tpl) . ';(function($){var ed=function(){return window.tinymce&&tinymce.get("ihub_news_details")};function put(h){var e=ed();if(e&&!e.isHidden()){e.setContent(h)}else{$("#ihub_news_details").val(h)}}function cur(){var e=ed();return (e&&!e.isHidden()?e.getContent():$("#ihub_news_details").val())||""}'
        . '$("#ihub-news-cat").on("change",function(){var t=T[this.value];if(t&&cur().replace(/<[^>]*>|&nbsp;|\\s/g,"")==="")put(t)});$("#ihub-news-tpl").on("click",function(){var t=T[$("#ihub-news-cat").val()];if(!t){alert("เลือกหมวดข่าวก่อน");return}if(cur().replace(/<[^>]*>|&nbsp;|\\s/g,"")===""||confirm("แทนที่รายละเอียดเดิมด้วยแม่แบบ?"))put(t)});'
        . 'if(!window.wp||!wp.media)return;$("#ihub-news-cover-pick").on("click",function(){var f=wp.media({title:"รูปหน้าปก",multiple:false,library:{type:"image"}});f.on("select",function(){var a=f.state().get("selection").first().toJSON();$("#ihub-news-cover").val(a.id);$("#ihub-news-cover-prev").html("<img src=\'"+((a.sizes&&a.sizes.medium)||a).url+"\' alt=\'\'>")});f.open()});$("#ihub-news-cover-clear").on("click",function(){$("#ihub-news-cover").val("");$("#ihub-news-cover-prev").html("<span>ยังไม่มีรูป</span>")});'
        . '$("#ihub-news-file-add").on("click",function(){var f=wp.media({title:"แนบไฟล์",multiple:true});f.on("select",function(){f.state().get("selection").each(function(m){var a=m.toJSON();var li=$("<li><input type=hidden name=files[]><span class=fn></span><input name=file_labels[] placeholder=\'ชื่อที่แสดง\'><button type=button class=button-link-delete data-rm>ลบ</button></li>");li.find("input[type=hidden]").val(a.id);li.find(".fn").text(a.filename||a.title);li.find("input[name^=file_labels]").val(a.title);$("#ihub-news-files").append(li)})});f.open()});$("#ihub-news-files").on("click","[data-rm]",function(){$(this).closest("li").remove()});})(jQuery);';
    // printed after the editor and the media library scripts (jQuery is loaded in the admin header)
    add_action('admin_print_footer_scripts', function () use ($js) { echo '<script>jQuery(function(){' . $js . '});</script>'; }, 99); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed script, data JSON-encoded
}

function ihub_news_status_chip($p) {
    $map = ['publish' => ['แสดงบนเว็บ', 'ok'], 'pending' => ['รออนุมัติ', 'wait'], 'draft' => ['ร่าง', ''], 'future' => ['ตั้งเวลา', 'ok']];
    $note = get_post_meta($p->ID, '_ihub_news_note', true);
    if ($p->post_status === 'draft' && is_array($note)) return '<span class="ihub-chip back">ส่งกลับแก้ไข</span>';
    [$l, $c] = $map[$p->post_status] ?? [$p->post_status, ''];
    return '<span class="ihub-chip ' . $c . '">' . esc_html($l) . '</span>';
}

function ihub_news_mine_tab($u) {
    $q = ['post_type' => 'post', 'post_status' => ['draft', 'pending', 'publish', 'future'], 'numberposts' => 50, 'orderby' => 'modified'];
    if (!current_user_can('edit_others_posts')) $q['author'] = get_current_user_id();
    $posts = get_posts($q);
    echo '<table class="widefat striped ihub-news-list"><thead><tr><th>หัวเรื่อง</th><th>หมวด</th><th>สถานะ</th><th>แก้ไขล่าสุด</th><th></th></tr></thead><tbody>';
    foreach ($posts as $p) {
        $cat = get_the_category($p->ID);
        echo '<tr><td><b>' . esc_html($p->post_title) . '</b><br><small>' . esc_html(get_the_author_meta('display_name', $p->post_author)) . '</small></td><td>' . esc_html($cat ? $cat[0]->name : '') . '</td><td>' . ihub_news_status_chip($p) . '</td><td>' . esc_html(get_the_modified_date('j M Y H:i', $p)) . '</td><td>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        if (current_user_can('edit_post', $p->ID)) echo '<a class="button button-small" href="' . $u(['tab' => 'write', 'post' => $p->ID]) . '">แก้ไข</a> '; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '<a class="button button-small" href="' . esc_url($p->post_status === 'publish' ? get_permalink($p) : get_preview_post_link($p)) . '" target="_blank">ดู</a></td></tr>';
    }
    if (!$posts) echo '<tr><td colspan="5">ยังไม่มีข่าว</td></tr>';
    echo '</tbody></table>';
}

function ihub_news_review_tab() {
    $posts = get_posts(['post_type' => 'post', 'post_status' => 'pending', 'numberposts' => 50, 'orderby' => 'date', 'order' => 'ASC']);
    if (!$posts) { echo '<p>ไม่มีข่าวรออนุมัติ 👍</p>'; return; }
    foreach ($posts as $p) {
        $cat = get_the_category($p->ID);
        $files = ihub_news_get_files($p->ID);
        echo '<div class="ihub-review"><div class="ihub-review-main">' . (has_post_thumbnail($p) ? get_the_post_thumbnail($p, 'medium', ['class' => 'ihub-review-img']) : '') . '<div><span class="ihub-chip">' . esc_html($cat ? $cat[0]->name : '') . '</span><h2>' . esc_html($p->post_title) . '</h2><p class="sum">' . esc_html($p->post_excerpt) . '</p>';
        echo '<details><summary>อ่านรายละเอียด</summary><div class="ihub-review-body">' . wp_kses_post(wpautop($p->post_content)) . '</div></details>';
        if ($files) echo '<p class="files">📎 ' . esc_html(implode(' · ', array_map(function ($f) { return $f['label'] ?: $f['name']; }, $files))) . '</p>';
        echo '<small>โดย ' . esc_html(get_the_author_meta('display_name', $p->post_author)) . ' · ส่งเมื่อ ' . esc_html((string) get_post_meta($p->ID, '_ihub_news_sent', true) ?: get_the_modified_date('j M Y H:i', $p)) . ' · <a href="' . esc_url(get_preview_post_link($p)) . '" target="_blank">ดูตัวอย่างบนเว็บ</a></small></div></div>';
        $form = function ($decision, $label, $class, $extra = '') use ($p) { return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('ihub_news_review_' . $p->ID, '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_news_review"><input type="hidden" name="post_id" value="' . (int) $p->ID . '"><input type="hidden" name="decision" value="' . $decision . '">' . $extra . '<button class="button ' . $class . '">' . $label . '</button></form>'; };
        echo '<div class="ihub-review-act">' . $form('approve', '✓ อนุมัติ แสดงบนเว็บ', 'button-primary button-large') . $form('return', 'ส่งกลับแก้ไข', '', '<textarea name="note" rows="2" placeholder="บอกผู้เขียนว่าต้องแก้อะไร" required></textarea>') . '<a class="button-link" href="' . esc_url(admin_url('admin.php?page=ihub-news&tab=write&post=' . $p->ID)) . '">แก้เองก่อนอนุมัติ</a></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
}

add_action('admin_enqueue_scripts', function () {
    if (($_GET['page'] ?? '') !== 'ihub-news') return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    wp_register_style('ihub-news', false, [], IHUB_VERSION);
    wp_enqueue_style('ihub-news');
    wp_add_inline_style('ihub-news', '.ihub-news{max-width:1200px}.ihub-news .nav-tab-wrapper{margin-bottom:16px}.ihub-badge{background:#f47b20;color:#fff;border-radius:99px;padding:0 7px;font-size:11px;margin-left:4px}
.ihub-news-form{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:18px;align-items:start}@media(max-width:1000px){.ihub-news-form{grid-template-columns:minmax(0,1fr)}}
.ihub-nf-card{position:relative;background:#fff;border:1px solid #e2e6ea;border-radius:14px;padding:16px 18px;margin-bottom:14px}
.ihub-nf-card label{display:flex;flex-direction:column;gap:6px;font-weight:600;margin-bottom:10px}.ihub-nf-card input,.ihub-nf-card select,.ihub-nf-card textarea{font-weight:400;font-size:15px}
.ihub-nf-title{font-size:20px!important;padding:8px 10px!important;font-weight:700!important}
.ihub-nf-step{position:absolute;left:-12px;top:14px;width:24px;height:24px;border-radius:50%;background:#16857c;color:#fff;font-weight:700;display:grid;place-items:center;font-size:13px}
.ihub-nf-cover{margin:10px 0;border:1px dashed #cbd5e1;border-radius:10px;min-height:120px;display:grid;place-items:center;overflow:hidden;color:#94a3b8}.ihub-nf-cover img{width:100%;height:auto;display:block}
#ihub-news-files{margin:10px 0}#ihub-news-files li{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:4px;padding:8px 0;border-bottom:1px solid #eef1f3}#ihub-news-files .fn{font-size:12px;color:#475569;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;grid-column:1/-1}#ihub-news-files input{width:100%}
.ihub-nf-send{display:flex;flex-direction:column;gap:8px}.ihub-nf-send .button{justify-content:center;text-align:center}
.ihub-chip{display:inline-block;background:#f1f5f9;border-radius:99px;padding:1px 10px;font-size:12px;font-weight:700;color:#334155}.ihub-chip.ok{background:#dcfce7;color:#166534}.ihub-chip.wait{background:#fef3c7;color:#92400e}.ihub-chip.back{background:#fee2e2;color:#991b1b}
.ihub-review{background:#fff;border:1px solid #e2e6ea;border-left:5px solid #f59e0b;border-radius:14px;padding:16px 18px;margin-bottom:14px;display:grid;grid-template-columns:minmax(0,1fr) 300px;gap:18px}@media(max-width:1000px){.ihub-review{grid-template-columns:minmax(0,1fr)}}
.ihub-review-main{display:flex;gap:14px}.ihub-review-img{width:160px;height:110px;object-fit:cover;border-radius:10px;flex:none}.ihub-review h2{margin:6px 0 4px;font-size:18px}.ihub-review .sum{margin:0 0 8px;color:#475569}.ihub-review-body{background:#f8fafc;border-radius:10px;padding:8px 14px;margin:8px 0}
.ihub-review-act{display:flex;flex-direction:column;gap:10px}.ihub-review-act form{display:flex;flex-direction:column;gap:6px}.ihub-review-act .button-large{width:100%;justify-content:center}');
});
