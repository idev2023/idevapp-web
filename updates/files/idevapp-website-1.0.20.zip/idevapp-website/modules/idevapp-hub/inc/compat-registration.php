<?php
/** New-patient registration is run by iDev Patient Registration (records were copied there; old connector addresses keep working). */
defined('ABSPATH') || exit;
function ihub_reg_install() {}
function ihub_render_registration_form() { return function_exists('idev_patient_registration_form') ? idev_patient_registration_form() : ''; }
