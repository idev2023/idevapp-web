<?php
/**
 * New patient registration: consent (PDPA/GDPR) → ID card / passport photo → details → staff review →
 * HOSxP (through the connector inside the hospital, which pulls approved records) → patient card by e-mail.
 * Personal data is encrypted at rest (libsodium); ID photos are encrypted and kept outside the web root when possible.
 */
defined('ABSPATH') || exit;

define('IHUB_REG_STATUSES', ['pending' => 'รอตรวจสอบ', 'approved' => 'อนุมัติแล้ว รอส่งเข้า HOSxP', 'synced' => 'ได้ HN แล้ว', 'error' => 'ส่งเข้า HOSxP ไม่สำเร็จ', 'rejected' => 'ไม่อนุมัติ']);

function ihub_reg_table() { global $wpdb; return $wpdb->prefix . 'ihub_registrations'; }

function ihub_reg_install() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $table = ihub_reg_table();
    dbDelta("CREATE TABLE {$table} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  ref varchar(24) NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'pending',
  doc_type varchar(12) NOT NULL DEFAULT 'thai_id',
  search_key char(64) NOT NULL DEFAULT '',
  data longtext NOT NULL,
  photo varchar(120) NOT NULL DEFAULT '',
  hn varchar(20) NOT NULL DEFAULT '',
  message text NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  synced_at datetime NULL,
  emailed_at datetime NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY ref (ref),
  KEY status (status),
  KEY search_key (search_key)
) {$wpdb->get_charset_collate()};");
    // Staff role that can only work on registrations.
    if (!get_role('ihub_registrar')) add_role('ihub_registrar', 'เจ้าหน้าที่เวชระเบียน', ['read' => true, 'ihub_registrations' => true]);
    foreach (['administrator'] as $role) { $r = get_role($role); if ($r && !$r->has_cap('ihub_registrations')) $r->add_cap('ihub_registrations'); }
    if (!wp_next_scheduled('ihub_reg_cleanup')) wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'ihub_reg_cleanup');
}

/* ---------- Encryption ---------- */

function ihub_reg_key() {
    if (defined('IHUB_REG_KEY') && preg_match('/^[0-9a-f]{64}$/i', IHUB_REG_KEY)) return hex2bin(IHUB_REG_KEY);
    // Derived from secrets in wp-config.php (not stored in the database). Changing these keys makes old records unreadable.
    return hash('sha256', 'ihub-registration|' . (defined('AUTH_KEY') ? AUTH_KEY : '') . '|' . (defined('SECURE_AUTH_KEY') ? SECURE_AUTH_KEY : ''), true);
}
function ihub_reg_encrypt($plain) {
    $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
    return base64_encode($nonce . sodium_crypto_secretbox($plain, $nonce, ihub_reg_key()));
}
function ihub_reg_decrypt($cipher) {
    $raw = base64_decode((string) $cipher, true);
    if ($raw === false || strlen($raw) < SODIUM_CRYPTO_SECRETBOX_NONCEBYTES + SODIUM_CRYPTO_SECRETBOX_MACBYTES) return null;
    $plain = sodium_crypto_secretbox_open(substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), ihub_reg_key());
    return $plain === false ? null : $plain;
}
/** Keyed hash of the ID / passport number, to find duplicates without storing the number in clear. */
function ihub_reg_search_key($doc_type, $number) {
    return hash_hmac('sha256', $doc_type . '|' . strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string) $number)), ihub_reg_key());
}

/** Folder for encrypted ID photos: outside the web root when possible. */
function ihub_reg_private_dir() {
    $candidates = [dirname(untrailingslashit(ABSPATH)) . '/idevapp-private'];
    $secret = get_option('ihub_reg_dir_secret');
    if (!$secret) { $secret = wp_generate_password(20, false); update_option('ihub_reg_dir_secret', $secret, false); }
    $candidates[] = wp_get_upload_dir()['basedir'] . '/idevapp-private-' . strtolower($secret);
    foreach ($candidates as $dir) {
        if (!is_dir($dir)) @wp_mkdir_p($dir);
        if (is_dir($dir) && is_writable($dir)) {
            if (!file_exists("$dir/index.php")) @file_put_contents("$dir/index.php", "<?php // Silence\n");
            if (!file_exists("$dir/.htaccess")) @file_put_contents("$dir/.htaccess", "Require all denied\nDeny from all\n");
            return $dir;
        }
    }
    return '';
}

/* ---------- Records ---------- */

function ihub_reg_get($id) {
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . ihub_reg_table() . ' WHERE id=%d', $id), ARRAY_A);
    if (!$row) return null;
    $row['person'] = json_decode((string) ihub_reg_decrypt($row['data']), true) ?: [];
    return $row;
}

function ihub_reg_save_person($id, $person, $extra = [], $touch = true) {
    global $wpdb;
    $fields = ['data' => ihub_reg_encrypt(wp_json_encode($person, JSON_UNESCAPED_UNICODE))] + ($touch ? ['updated_at' => current_time('mysql', true)] : []) + $extra;
    $wpdb->update(ihub_reg_table(), $fields, ['id' => (int) $id]);
}

function ihub_reg_log(&$person, $text) {
    $user = wp_get_current_user();
    $person['_log'][] = [gmdate('c'), $user && $user->ID ? $user->user_login : 'system', $text];
}

function ihub_reg_name($person) {
    return trim(($person['prefix'] ?? '') . ' ' . ($person['first_name'] ?? '') . ' ' . ($person['last_name'] ?? ''));
}

/** "เรียน คุณสมชาย ใจดี" / "เรียน นาย สมชาย ใจดี" (no "คุณ" before a title). */
function ihub_reg_salutation($person, $en) {
    if ($en) return 'Dear ' . ihub_reg_name($person) . ',';
    return 'เรียน ' . (($person['prefix'] ?? '') !== '' ? ihub_reg_name($person) : 'คุณ' . ihub_reg_name($person));
}

/* ---------- Validation ---------- */

function ihub_valid_thai_id($cid) {
    if (!preg_match('/^\d{13}$/', $cid)) return false;
    $sum = 0;
    for ($i = 0; $i < 12; $i++) $sum += (int) $cid[$i] * (13 - $i);
    return (11 - $sum % 11) % 10 === (int) $cid[12];
}

/** Cleans the submitted form; returns [person, errors]. */
function ihub_reg_clean($in) {
    $text = function ($key, $max = 120) use ($in) { return mb_substr(trim(sanitize_text_field(wp_unslash($in[$key] ?? ''))), 0, $max); };
    $p = [];
    $errors = [];
    $p['doc_type'] = ($in['doc_type'] ?? '') === 'passport' ? 'passport' : 'thai_id';
    if ($p['doc_type'] === 'thai_id') {
        $p['cid'] = preg_replace('/\D/', '', $text('cid', 20));
        if (!ihub_valid_thai_id($p['cid'])) $errors['cid'] = 'เลขประจำตัวประชาชนไม่ถูกต้อง';
        $p['passport_no'] = '';
        $p['nationality'] = 'THA';
    } else {
        $p['passport_no'] = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $text('passport_no', 20)));
        if (strlen($p['passport_no']) < 5) $errors['passport_no'] = 'Passport number is required';
        $p['nationality'] = strtoupper(preg_replace('/[^A-Za-z]/', '', $text('nationality', 3)));
        if (strlen($p['nationality']) !== 3) $errors['nationality'] = 'Nationality is required';
        $p['cid'] = '';
    }
    foreach (['prefix' => 20, 'first_name' => 100, 'last_name' => 100, 'first_name_en' => 100, 'last_name_en' => 100] as $key => $max) $p[$key] = $text($key, $max);
    if ($p['first_name'] === '') $errors['first_name'] = 'กรุณากรอกชื่อ / First name is required';
    if ($p['last_name'] === '') $errors['last_name'] = 'กรุณากรอกนามสกุล / Last name is required';
    $p['sex'] = in_array($in['sex'] ?? '', ['male', 'female'], true) ? $in['sex'] : '';
    if ($p['sex'] === '') $errors['sex'] = 'กรุณาเลือกเพศ / Please choose';
    $p['birthdate'] = $text('birthdate', 10);
    if (!ihub_is_valid_date($p['birthdate']) || $p['birthdate'] > ihub_today() || $p['birthdate'] < '1900-01-01') $errors['birthdate'] = 'วันเกิดไม่ถูกต้อง / Invalid date of birth';
    $p['phone'] = preg_replace('/[^\d+]/', '', $text('phone', 20));
    if (strlen(preg_replace('/\D/', '', $p['phone'])) < 9) $errors['phone'] = 'เบอร์โทรไม่ถูกต้อง / Invalid phone number';
    $p['email'] = sanitize_email(wp_unslash($in['email'] ?? ''));
    if (!is_email($p['email'])) $errors['email'] = 'อีเมลไม่ถูกต้อง / Invalid e-mail';
    $p['address'] = mb_substr(trim(sanitize_textarea_field(wp_unslash($in['address'] ?? ''))), 0, 500);
    if (mb_strlen($p['address']) < 5) $errors['address'] = 'กรุณากรอกที่อยู่ / Address is required';
    $lat = $in['lat'] ?? ''; $lng = $in['lng'] ?? '';
    $p['lat'] = is_numeric($lat) && abs((float) $lat) <= 90 ? round((float) $lat, 6) : null;
    $p['lng'] = is_numeric($lng) && abs((float) $lng) <= 180 ? round((float) $lng, 6) : null;
    $p['drug_allergy'] = $text('drug_allergy', 300);
    $p['emergency_name'] = $text('emergency_name', 120);
    $p['emergency_phone'] = preg_replace('/[^\d+]/', '', $text('emergency_phone', 20));
    $p['lang'] = ($in['lang'] ?? '') === 'en' ? 'en' : 'th';
    return [$p, $errors];
}

/* ---------- Public submission (REST) ---------- */

add_action('rest_api_init', function () {
    register_rest_route('idevapp/v1', '/register', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'ihub_reg_submit']);
    $token = function ($request) { return ihub_reg_check_token($request); };
    register_rest_route('idevapp/v1', '/hosxp/ping', ['methods' => 'GET', 'permission_callback' => $token, 'callback' => function () { update_option('ihub_reg_connector_seen', time(), false); return ['ok' => true, 'site' => home_url('/')]; }]);
    register_rest_route('idevapp/v1', '/hosxp/queue', ['methods' => 'GET', 'permission_callback' => $token, 'callback' => 'ihub_reg_queue']);
    register_rest_route('idevapp/v1', '/hosxp/result', ['methods' => 'POST', 'permission_callback' => $token, 'callback' => 'ihub_reg_result']);
});

function ihub_reg_client_ip() {
    foreach (['HTTP_CF_CONNECTING_IP', 'REMOTE_ADDR'] as $key) if (!empty($_SERVER[$key])) return sanitize_text_field(wp_unslash($_SERVER[$key]));
    return '';
}

function ihub_reg_submit(WP_REST_Request $request) {
    global $wpdb;
    $in = $request->get_body_params();
    $lang = ($in['lang'] ?? '') === 'en' ? 'en' : 'th';
    $msg = function ($th, $en) use ($lang) { return $lang === 'en' ? $en : $th; };
    if (!empty($in['website'])) return new WP_REST_Response(['ok' => true, 'ref' => 'REG-0'], 200); // honeypot
    if (empty($in['consent_pdpa'])) return new WP_REST_Response(['ok' => false, 'errors' => ['consent' => $msg('กรุณายอมรับนโยบายความเป็นส่วนตัวก่อน', 'Please accept the privacy notice first')]], 400);
    // Rate limit: 5 submissions per hour per network address.
    $ip_key = 'ihub_reg_rate_' . md5(ihub_reg_client_ip());
    $count = (int) get_transient($ip_key);
    if ($count >= 5) return new WP_REST_Response(['ok' => false, 'errors' => ['form' => $msg('ส่งข้อมูลบ่อยเกินไป กรุณาลองใหม่ภายหลัง หรือโทรติดต่อเจ้าหน้าที่', 'Too many attempts. Please try again later or call us.')]], 429);
    [$person, $errors] = ihub_reg_clean($in);
    $files = $request->get_file_params();
    $photo = $files['photo'] ?? null;
    if (!$photo || !empty($photo['error']) || !is_uploaded_file($photo['tmp_name'])) $errors['photo'] = $msg('กรุณาถ่ายรูปบัตรประชาชนหรือพาสปอร์ต', 'Please take a photo of your ID card or passport');
    elseif ($photo['size'] > 12 * 1048576) $errors['photo'] = $msg('รูปใหญ่เกินไป', 'The photo is too large');
    if ($errors) return new WP_REST_Response(['ok' => false, 'errors' => $errors], 400);
    $number = $person['doc_type'] === 'thai_id' ? $person['cid'] : $person['passport_no'];
    $search = ihub_reg_search_key($person['doc_type'], $number);
    $open = $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . ihub_reg_table() . " WHERE search_key=%s AND status IN ('pending','approved')", $search));
    if ($open) return new WP_REST_Response(['ok' => false, 'errors' => ['form' => $msg('เลขบัตรนี้ส่งข้อมูลลงทะเบียนแล้ว อยู่ระหว่างตรวจสอบ หากต้องการแก้ไขกรุณาโทรติดต่อเจ้าหน้าที่', 'This ID has already been submitted and is being reviewed. Please call us if you need to change it.')]], 409);
    // Re-encode the photo (removes EXIF incl. location), shrink, encrypt, store privately.
    $stored = ihub_reg_store_photo($photo['tmp_name']);
    if (!$stored) return new WP_REST_Response(['ok' => false, 'errors' => ['photo' => $msg('อ่านไฟล์รูปไม่ได้ กรุณาถ่ายใหม่ (JPG/PNG)', 'Could not read the photo. Please try again (JPG/PNG).')]], 400);
    $person['consent'] = ['pdpa' => true, 'version' => ihub_reg_setting('consent_version'), 'at' => gmdate('c'), 'ip_hash' => hash('sha256', ihub_reg_client_ip() . wp_salt('nonce')), 'user_agent' => mb_substr(sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? '')), 0, 200)];
    $person['_log'] = [[gmdate('c'), 'patient', 'ส่งข้อมูลลงทะเบียน']];
    $now = current_time('mysql', true);
    $ref = 'REG-' . wp_date('ymd') . '-' . strtoupper(wp_generate_password(5, false));
    $wpdb->insert(ihub_reg_table(), ['ref' => $ref, 'status' => 'pending', 'doc_type' => $person['doc_type'], 'search_key' => $search, 'data' => ihub_reg_encrypt(wp_json_encode($person, JSON_UNESCAPED_UNICODE)), 'photo' => $stored, 'created_at' => $now, 'updated_at' => $now]);
    set_transient($ip_key, $count + 1, HOUR_IN_SECONDS);
    ihub_reg_mail_received($person, $ref);
    return new WP_REST_Response(['ok' => true, 'ref' => $ref], 200);
}

function ihub_reg_store_photo($tmp) {
    $info = @getimagesize($tmp);
    if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)) return '';
    $src = $info[2] === IMAGETYPE_PNG ? @imagecreatefrompng($tmp) : ($info[2] === IMAGETYPE_WEBP ? @imagecreatefromwebp($tmp) : @imagecreatefromjpeg($tmp));
    if (!$src) return '';
    $w = imagesx($src); $h = imagesy($src);
    $scale = min(1, 1800 / max($w, $h));
    $dst = imagecreatetruecolor(max(1, (int) ($w * $scale)), max(1, (int) ($h * $scale)));
    imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
    imagecopyresampled($dst, $src, 0, 0, 0, 0, imagesx($dst), imagesy($dst), $w, $h);
    ob_start(); imagejpeg($dst, null, 85); $jpeg = ob_get_clean();
    imagedestroy($src); imagedestroy($dst);
    $dir = ihub_reg_private_dir();
    if (!$dir) return '';
    $name = bin2hex(random_bytes(16)) . '.bin';
    return file_put_contents("$dir/$name", ihub_reg_encrypt($jpeg)) ? $name : '';
}

function ihub_reg_photo_bytes($name) {
    if (!preg_match('/^[0-9a-f]{32}\.bin$/', (string) $name)) return null;
    $dir = ihub_reg_private_dir();
    $path = "$dir/$name";
    return is_file($path) ? ihub_reg_decrypt(file_get_contents($path)) : null;
}

function ihub_reg_delete_photo($row) {
    if (!preg_match('/^[0-9a-f]{32}\.bin$/', (string) $row['photo'])) return;
    $path = ihub_reg_private_dir() . '/' . $row['photo'];
    if (is_file($path)) @unlink($path);
    global $wpdb;
    $wpdb->update(ihub_reg_table(), ['photo' => ''], ['id' => (int) $row['id']]);
}

/* ---------- Connector API (inside the hospital) ---------- */

function ihub_reg_check_token(WP_REST_Request $request) {
    $hash = get_option('ihub_reg_token_hash');
    $header = $request->get_header('authorization');
    if (!$hash || !$header || stripos($header, 'Bearer ') !== 0) return new WP_Error('ihub_forbidden', 'Invalid token', ['status' => 401]);
    if (!hash_equals($hash, hash('sha256', trim(substr($header, 7))))) return new WP_Error('ihub_forbidden', 'Invalid token', ['status' => 401]);
    $allow = trim((string) ihub_reg_setting('connector_ips'));
    if ($allow !== '' && !in_array(ihub_reg_client_ip(), array_map('trim', preg_split('/[\s,]+/', $allow)), true)) return new WP_Error('ihub_forbidden', 'IP not allowed', ['status' => 403]);
    return true;
}

function ihub_reg_queue() {
    global $wpdb;
    update_option('ihub_reg_connector_seen', time(), false);
    $rows = $wpdb->get_results('SELECT id FROM ' . ihub_reg_table() . " WHERE status='approved' ORDER BY id LIMIT 20", ARRAY_A);
    $items = [];
    foreach ($rows as $row) {
        $r = ihub_reg_get($row['id']);
        $p = $r['person'];
        unset($p['_log'], $p['consent']);
        $items[] = ['id' => (int) $r['id'], 'ref' => $r['ref'], 'person' => $p];
    }
    return ['items' => $items];
}

function ihub_reg_result(WP_REST_Request $request) {
    $id = (int) $request->get_param('id');
    $status = sanitize_key($request->get_param('status'));
    $row = ihub_reg_get($id);
    if (!$row || $row['status'] !== 'approved') return new WP_REST_Response(['ok' => false, 'error' => 'not in queue'], 404);
    $person = $row['person'];
    $message = mb_substr(sanitize_text_field((string) $request->get_param('message')), 0, 500);
    if (in_array($status, ['created', 'existing'], true)) {
        $hn = preg_replace('/[^0-9A-Za-z-]/', '', (string) $request->get_param('hn'));
        if ($hn === '') return new WP_REST_Response(['ok' => false, 'error' => 'hn required'], 400);
        ihub_reg_log($person, ($status === 'existing' ? 'HOSxP: พบผู้ป่วยเดิม HN ' : 'HOSxP: สร้างผู้ป่วยใหม่ HN ') . $hn);
        ihub_reg_save_person($id, $person, ['status' => 'synced', 'hn' => $hn, 'message' => $status === 'existing' ? 'มีประวัติใน HOSxP อยู่แล้ว (ใช้ HN เดิม)' : $message, 'synced_at' => current_time('mysql', true)]);
        ihub_reg_mail_card($id);
        return ['ok' => true];
    }
    ihub_reg_log($person, 'HOSxP error: ' . $message);
    ihub_reg_save_person($id, $person, ['status' => 'error', 'message' => $message]);
    return ['ok' => true];
}

/* ---------- E-mails ---------- */

function ihub_reg_mail_wrap($title, $body_html) {
    $site = ihub_site_local('th');
    return '<div style="font-family:Tahoma,Arial,sans-serif;background:#f3f7f7;padding:24px"><div style="max-width:560px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden;border:1px solid #e3ecec">'
        . '<div style="background:#0e3540;color:#fff;padding:18px 22px"><strong style="font-size:17px">' . esc_html($site['name']) . '</strong><br><span style="color:#9fd8d2;font-size:12px">' . esc_html(ihub_setting('site_name_en')) . '</span></div>'
        . '<div style="padding:22px;color:#172737;font-size:15px;line-height:1.7"><h2 style="margin:0 0 12px;font-size:19px">' . esc_html($title) . '</h2>' . $body_html . '</div>'
        . '<div style="padding:14px 22px;background:#f7f9f9;color:#70808d;font-size:12px">' . esc_html($site['address']) . ' · ' . esc_html(ihub_setting('phone')) . '</div></div></div>';
}

function ihub_reg_send($to, $subject, $html, $attachments_cb = null) {
    $headers = ['Content-Type: text/html; charset=UTF-8'];
    if ($attachments_cb) add_action('phpmailer_init', $attachments_cb);
    $ok = wp_mail($to, $subject, $html, $headers);
    if ($attachments_cb) remove_action('phpmailer_init', $attachments_cb);
    return $ok;
}

function ihub_reg_mail_received($person, $ref) {
    $en = ($person['lang'] ?? 'th') === 'en';
    $body = $en
        ? '<p>' . esc_html(ihub_reg_salutation($person, true)) . '</p><p>We have received your registration. Reference: <strong>' . esc_html($ref) . '</strong></p><p>Our staff will check your details. When your hospital number (HN) is ready, we will e-mail your patient card to this address.</p>'
        : '<p>' . esc_html(ihub_reg_salutation($person, false)) . '</p><p>สถานพยาบาลได้รับข้อมูลลงทะเบียนของท่านแล้ว เลขอ้างอิง <strong>' . esc_html($ref) . '</strong></p><p>เจ้าหน้าที่จะตรวจสอบข้อมูล เมื่อได้เลขประจำตัวผู้ป่วย (HN) แล้ว ระบบจะส่งบัตรคนไข้มาที่อีเมลนี้</p>';
    ihub_reg_send($person['email'], ($en ? 'Registration received ' : 'ได้รับข้อมูลลงทะเบียนแล้ว ') . $ref, ihub_reg_mail_wrap($en ? 'Registration received' : 'ได้รับข้อมูลลงทะเบียนแล้ว', $body));
    $staff = ihub_reg_setting('staff_email');
    if ($staff && is_email($staff)) ihub_reg_send($staff, 'มีผู้ลงทะเบียนผู้ป่วยใหม่ ' . $ref, ihub_reg_mail_wrap('มีผู้ลงทะเบียนผู้ป่วยใหม่', '<p>เลขอ้างอิง <strong>' . esc_html($ref) . '</strong></p><p><a href="' . esc_url(admin_url('admin.php?page=ihub-registrations')) . '">เปิดหลังบ้านเพื่อตรวจสอบ</a></p>'));
}

/** Patient card with HN and barcode. */
function ihub_reg_mail_card($id) {
    global $wpdb;
    $row = ihub_reg_get($id);
    if (!$row || $row['hn'] === '' || !is_email($row['person']['email'] ?? '')) return false;
    $p = $row['person'];
    $en = ($p['lang'] ?? 'th') === 'en';
    $barcode = ihub_code128_png($row['hn']);
    $cid = 'hn-barcode-' . $row['id'];
    $site = ihub_site_local($en ? 'en' : 'th');
    $name_en = trim(($p['first_name_en'] ?? '') . ' ' . ($p['last_name_en'] ?? ''));
    $card = '<div style="border-radius:16px;background:linear-gradient(135deg,#169c91,#0e3540);color:#fff;padding:20px 22px;margin:8px 0 18px">'
        . '<div style="font-size:12px;letter-spacing:.08em;color:#bfeee8">' . ($en ? 'PATIENT CARD' : 'บัตรประจำตัวผู้ป่วย · PATIENT CARD') . '</div>'
        . '<div style="font-size:13px;margin-top:2px">' . esc_html($site['name']) . '</div>'
        . '<div style="font-size:21px;font-weight:bold;margin:14px 0 2px">' . esc_html(ihub_reg_name($p)) . '</div>'
        . ($name_en !== '' && $name_en !== trim($p['first_name'] . ' ' . $p['last_name']) ? '<div style="font-size:13px;color:#d7f3ef">' . esc_html($name_en) . '</div>' : '')
        . '<table style="margin-top:12px;color:#fff;font-size:13px" cellpadding="0" cellspacing="0"><tr><td style="padding-right:24px"><span style="color:#bfeee8">HN</span><br><strong style="font-size:26px;letter-spacing:.04em">' . esc_html($row['hn']) . '</strong></td>'
        . '<td><span style="color:#bfeee8">' . ($en ? 'Date of birth' : 'วันเกิด') . '</span><br><strong>' . esc_html(ihub_format_day($p['birthdate'], $en ? 'en' : 'th')) . '</strong></td></tr></table>'
        . '<div style="background:#fff;border-radius:10px;padding:10px;margin-top:14px;text-align:center"><img src="cid:' . $cid . '" alt="HN ' . esc_attr($row['hn']) . '" style="max-width:100%;height:60px"></div></div>';
    $body = $en
        ? '<p>' . esc_html(ihub_reg_salutation($p, true)) . '</p><p>Your registration is complete. Please keep this patient card and show it (on your phone is fine) at the registration desk, together with your passport.</p>' . $card
        : '<p>' . esc_html(ihub_reg_salutation($p, false)) . '</p><p>การลงทะเบียนผู้ป่วยใหม่เสร็จสมบูรณ์ กรุณาเก็บบัตรนี้ไว้ และแสดง (บนมือถือได้) พร้อมบัตรประชาชนที่จุดลงทะเบียนเมื่อมารับบริการ</p>' . $card;
    $note = ihub_pick(ihub_reg_setting('card_note'), ihub_reg_setting('card_note_en'), $en ? 'en' : 'th');
    if ($note !== '') $body .= '<p style="color:#70808d;font-size:13px">' . nl2br(esc_html($note)) . '</p>';
    $attach = function ($mailer) use ($barcode, $cid) { $mailer->addStringEmbeddedImage($barcode, $cid, 'hn.png', 'base64', 'image/png'); };
    $ok = ihub_reg_send($p['email'], ($en ? 'Your patient card – HN ' : 'บัตรคนไข้ของท่าน HN ') . $row['hn'], ihub_reg_mail_wrap($en ? 'Your patient card' : 'บัตรคนไข้ของท่าน', $body), $attach);
    if ($ok) $wpdb->update(ihub_reg_table(), ['emailed_at' => current_time('mysql', true)], ['id' => (int) $id]);
    return $ok;
}

/* ---------- Clean-up: delete ID photos and old rejected records ---------- */

add_action('ihub_reg_cleanup', 'ihub_reg_cleanup');
function ihub_reg_cleanup() {
    global $wpdb;
    $table = ihub_reg_table();
    $days = max(0, (int) ihub_reg_setting('photo_days'));
    $cut = gmdate('Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS);
    foreach ($wpdb->get_results($wpdb->prepare("SELECT id, photo FROM {$table} WHERE photo<>'' AND ((status='synced' AND synced_at < %s) OR (status='rejected' AND updated_at < %s))", $cut, $cut), ARRAY_A) as $row) ihub_reg_delete_photo($row);
    $reject_days = max(1, (int) ihub_reg_setting('rejected_days'));
    $cut = gmdate('Y-m-d H:i:s', time() - $reject_days * DAY_IN_SECONDS);
    $wpdb->query($wpdb->prepare("DELETE FROM {$table} WHERE status='rejected' AND updated_at < %s", $cut));
}

/* ---------- Settings ---------- */

function ihub_reg_setting_defaults() {
    return [
        'enabled' => 'true', 'ocr' => 'true', 'staff_email' => '', 'photo_days' => '30', 'rejected_days' => '90', 'connector_ips' => '',
        'consent_version' => '1',
        'consent_text' => "สถานพยาบาล (ผู้ควบคุมข้อมูลส่วนบุคคล) จะเก็บรวบรวม ใช้ และเปิดเผยข้อมูลของท่าน ได้แก่ ชื่อ-นามสกุล เพศ วันเกิด เลขประจำตัวประชาชนหรือหนังสือเดินทาง รูปถ่ายบัตร เบอร์โทร อีเมล ที่อยู่และพิกัด (ถ้าท่านเลือกแชร์) ประวัติแพ้ยา และผู้ติดต่อฉุกเฉิน เพื่อการลงทะเบียนเป็นผู้ป่วย การบันทึกเวชระเบียน การติดต่อ และการให้บริการทางการแพทย์ ตามพระราชบัญญัติคุ้มครองข้อมูลส่วนบุคคล พ.ศ. 2562 (PDPA)\n\nข้อมูลจะถูกเข้ารหัสและเข้าถึงได้เฉพาะเจ้าหน้าที่ที่เกี่ยวข้อง รูปถ่ายบัตรจะถูกลบหลังลงทะเบียนเสร็จ เวชระเบียนจะถูกเก็บตามระยะเวลาที่กฎหมายกำหนด ท่านมีสิทธิขอเข้าถึง แก้ไข ลบ หรือคัดค้านการประมวลผลข้อมูล โดยติดต่อเจ้าหน้าที่คุ้มครองข้อมูลส่วนบุคคลของสถานพยาบาล",
        'consent_text_en' => "The health facility (the data controller) collects, uses and discloses your personal data — name, sex, date of birth, national ID or passport number, a photo of your ID document, phone number, e-mail, address and location (if you choose to share it), drug allergies and emergency contact — to register you as a patient, keep your medical record, contact you and provide medical care, under Thailand's Personal Data Protection Act B.E. 2562 (PDPA) and, where it applies, the EU General Data Protection Regulation (GDPR). Health data is processed on the basis of your explicit consent and for medical care.\n\nYour data is encrypted and only authorised staff can access it. The ID photo is deleted after registration is complete; medical records are kept for the period required by law. You have the right to access, correct, delete, restrict or object to the processing of your data, to data portability, to withdraw consent, and to complain to the supervisory authority. Contact our Data Protection Officer.",
        'dpo_contact' => '',
        'card_note' => '', 'card_note_en' => '',
    ];
}
function ihub_reg_setting($key) {
    $saved = get_option('ihub_reg_settings', []);
    $all = array_merge(ihub_reg_setting_defaults(), is_array($saved) ? $saved : []);
    return isset($all[$key]) ? (string) $all[$key] : '';
}

add_action('plugins_loaded', function () {
    if (get_option('ihub_reg_db_version') !== IHUB_VERSION) { ihub_reg_install(); update_option('ihub_reg_db_version', IHUB_VERSION); }
});
