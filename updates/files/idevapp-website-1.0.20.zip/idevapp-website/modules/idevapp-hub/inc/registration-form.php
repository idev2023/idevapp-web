<?php
/** Public registration form (block "ลงทะเบียนผู้ป่วยใหม่" and shortcode [idevapp_registration]). */
defined('ABSPATH') || exit;

function ihub_render_registration_form() {
    $r = ihub_t('reg');
    if (ihub_reg_setting('enabled') !== 'true') return '<div class="ihub-reg"><p class="ihub-reg-closed">' . esc_html($r['closed']) . '</p></div>';
    $lang = ihub_lang();
    wp_enqueue_script('ihub-idparse', IHUB_URL . 'assets/idparse.js', [], IHUB_VERSION, true);
    wp_enqueue_script('ihub-registration', IHUB_URL . 'assets/registration.js', ['ihub-idparse'], IHUB_VERSION, true);
    $config = [
        'rest' => esc_url_raw(rest_url('idevapp/v1/register')), 'lang' => $lang, 'ocr' => ihub_reg_setting('ocr') === 'true',
        'tesseract' => 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js', 't' => $r,
    ];
    $consent = ihub_pick(ihub_reg_setting('consent_text'), ihub_reg_setting('consent_text_en'));
    $privacy = ihub_setting('privacy_url') ?: (get_privacy_policy_url() ?: '');
    $field = function ($name, $label, $type = 'text', $attrs = '', $hint = '') {
        return '<label class="ihub-reg-field" data-field="' . esc_attr($name) . '"><span>' . esc_html($label) . '</span><input type="' . $type . '" name="' . esc_attr($name) . '" ' . $attrs . '>' . ($hint ? '<small>' . esc_html($hint) . '</small>' : '') . '<em class="ihub-reg-error" hidden></em></label>';
    };
    $prefixes = $lang === 'en' ? ['Mr', 'Mrs', 'Ms', 'Miss', 'Master', 'นาย', 'นาง', 'นางสาว'] : ['นาย', 'นาง', 'นางสาว', 'เด็กชาย', 'เด็กหญิง', 'Mr', 'Mrs', 'Ms', 'Miss'];
    $countries = ['THA' => 'Thailand', 'GBR' => 'United Kingdom', 'DEU' => 'Germany', 'RUS' => 'Russia', 'CHN' => 'China', 'USA' => 'United States', 'FRA' => 'France', 'SWE' => 'Sweden', 'NLD' => 'Netherlands', 'AUS' => 'Australia', 'IND' => 'India', 'ITA' => 'Italy', 'CHE' => 'Switzerland', 'AUT' => 'Austria', 'DNK' => 'Denmark', 'NOR' => 'Norway', 'FIN' => 'Finland', 'BEL' => 'Belgium', 'ESP' => 'Spain', 'POL' => 'Poland', 'ISR' => 'Israel', 'JPN' => 'Japan', 'KOR' => 'South Korea', 'SGP' => 'Singapore', 'MYS' => 'Malaysia', 'MMR' => 'Myanmar', 'KHM' => 'Cambodia', 'LAO' => 'Laos', 'VNM' => 'Vietnam', 'CAN' => 'Canada', 'NZL' => 'New Zealand', 'IRL' => 'Ireland', 'CZE' => 'Czechia', 'KAZ' => 'Kazakhstan', 'UKR' => 'Ukraine', 'D' => 'Germany (D)'];
    ob_start(); ?>
<div class="ihub-reg" data-ihub-reg="<?php echo esc_attr(wp_json_encode($config, JSON_UNESCAPED_UNICODE)); ?>">
  <ol class="ihub-reg-steps" aria-hidden="true"><?php foreach ($r['steps'] as $i => $step) echo '<li' . ($i === 0 ? ' class="active"' : '') . '><b>' . ($i + 1) . '</b><span>' . esc_html($step) . '</span></li>'; ?></ol>
  <form class="ihub-reg-form" novalidate>
    <input type="text" name="website" class="ihub-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
    <input type="hidden" name="lang" value="<?php echo esc_attr($lang); ?>">
    <section class="ihub-reg-step is-active" data-step="0">
      <h2><?php echo esc_html($r['consentTitle']); ?></h2>
      <div class="ihub-reg-consent" tabindex="0"><?php echo wpautop(esc_html($consent)); ?>
        <?php if (ihub_reg_setting('dpo_contact')) echo '<p><strong>' . esc_html($r['dpo']) . ':</strong> ' . nl2br(esc_html(ihub_reg_setting('dpo_contact'))) . '</p>'; ?>
        <?php if ($privacy) echo '<p><a href="' . esc_url($privacy) . '" target="_blank" rel="noopener">' . esc_html($r['privacy']) . ' ↗</a></p>'; ?>
      </div>
      <label class="ihub-reg-check"><input type="checkbox" name="consent_pdpa" value="1"> <span><?php echo esc_html($r['consentCheck']); ?></span></label>
      <em class="ihub-reg-error" data-error="consent" hidden></em>
    </section>
    <section class="ihub-reg-step" data-step="1" hidden>
      <h2><?php echo esc_html($r['steps'][1]); ?></h2>
      <fieldset class="ihub-reg-choice"><legend><?php echo esc_html($r['docType']); ?></legend>
        <label><input type="radio" name="doc_type" value="thai_id"<?php checked($lang, 'th'); ?>> <span>🪪 <?php echo esc_html($r['thaiId']); ?></span></label>
        <label><input type="radio" name="doc_type" value="passport"<?php checked($lang, 'en'); ?>> <span>🛂 <?php echo esc_html($r['passport']); ?></span></label>
      </fieldset>
      <div class="ihub-reg-photo">
        <input type="file" id="ihub-reg-file" accept="image/*" capture="environment" hidden>
        <label for="ihub-reg-file" class="button button-teal ihub-reg-shoot">📷 <?php echo esc_html($r['takePhoto']); ?></label>
        <p class="ihub-reg-hint"><?php echo esc_html($r['photoHint']); ?></p>
        <img class="ihub-reg-preview" alt="" hidden>
        <div class="ihub-reg-ocr" role="status" aria-live="polite" hidden><span class="ihub-reg-bar"><i></i></span><span class="ihub-reg-ocr-text"></span></div>
        <em class="ihub-reg-error" data-error="photo" hidden></em>
      </div>
    </section>
    <section class="ihub-reg-step" data-step="2" hidden>
      <h2><?php echo esc_html($r['steps'][2]); ?></h2>
      <div class="ihub-reg-grid">
        <div class="ihub-reg-doc ihub-reg-doc-thai_id"><?php echo $field('cid', $r['cid'], 'text', 'inputmode="numeric" autocomplete="off" maxlength="17"'); ?></div>
        <div class="ihub-reg-doc ihub-reg-doc-passport"><?php echo $field('passport_no', $r['passportNo'], 'text', 'autocomplete="off" autocapitalize="characters" maxlength="20"'); ?></div>
        <div class="ihub-reg-doc ihub-reg-doc-passport"><?php echo $field('nationality', $r['nationality'], 'text', 'list="ihub-reg-countries" maxlength="3" autocapitalize="characters"'); ?></div>
        <?php echo $field('prefix', $r['prefix'], 'text', 'list="ihub-reg-prefixes"'); ?>
        <fieldset class="ihub-reg-field ihub-reg-sex" data-field="sex"><span><?php echo esc_html($r['sex']); ?></span><div><label><input type="radio" name="sex" value="male"> <?php echo esc_html($r['male']); ?></label><label><input type="radio" name="sex" value="female"> <?php echo esc_html($r['female']); ?></label></div><em class="ihub-reg-error" hidden></em></fieldset>
        <?php echo $field('first_name', $r['firstName'], 'text', 'autocomplete="given-name"') . $field('last_name', $r['lastName'], 'text', 'autocomplete="family-name"'); ?>
        <?php echo $field('first_name_en', $r['firstNameEn']) . $field('last_name_en', $r['lastNameEn']); ?>
        <?php echo $field('birthdate', $r['birthdate'], 'date', 'max="' . esc_attr(ihub_today()) . '" min="1900-01-01" autocomplete="bday"'); ?>
      </div>
      <datalist id="ihub-reg-prefixes"><?php foreach ($prefixes as $p) echo '<option value="' . esc_attr($p) . '">'; ?></datalist>
      <datalist id="ihub-reg-countries"><?php foreach ($countries as $code => $name) if (strlen($code) === 3) echo '<option value="' . esc_attr($code) . '">' . esc_html($name) . '</option>'; ?></datalist>
    </section>
    <section class="ihub-reg-step" data-step="3" hidden>
      <h2><?php echo esc_html($r['steps'][3]); ?></h2>
      <div class="ihub-reg-grid">
        <?php echo $field('phone', $r['phone'], 'tel', 'autocomplete="tel" inputmode="tel"') . $field('email', $r['email'], 'email', 'autocomplete="email"'); ?>
      </div>
      <label class="ihub-reg-field" data-field="address"><span><?php echo esc_html($r['address']); ?></span><textarea name="address" rows="3" autocomplete="street-address"></textarea><em class="ihub-reg-error" hidden></em></label>
      <div class="ihub-reg-gps"><button type="button" class="button button-white" data-ihub-gps>📍 <?php echo esc_html($r['gps']); ?></button><span class="ihub-reg-gps-status"></span><input type="hidden" name="lat"><input type="hidden" name="lng"><small><?php echo esc_html($r['gpsHint']); ?></small></div>
      <?php echo $field('drug_allergy', $r['allergy'], 'text', '', $r['allergyHint']); ?>
      <div class="ihub-reg-grid"><?php echo $field('emergency_name', $r['emergencyName']) . $field('emergency_phone', $r['emergencyPhone'], 'tel', 'inputmode="tel"'); ?></div>
    </section>
    <section class="ihub-reg-step" data-step="4" hidden>
      <h2><?php echo esc_html($r['review']); ?></h2>
      <dl class="ihub-reg-review"></dl>
      <em class="ihub-reg-error" data-error="form" hidden></em>
    </section>
    <div class="ihub-reg-nav">
      <button type="button" class="button button-white" data-ihub-back hidden>← <?php echo esc_html($r['back']); ?></button>
      <button type="button" class="button button-teal" data-ihub-next><?php echo esc_html($r['next']); ?> →</button>
      <button type="submit" class="button button-coral" data-ihub-submit hidden><?php echo esc_html($r['submit']); ?></button>
    </div>
  </form>
  <div class="ihub-reg-done" hidden><div class="ihub-reg-done-icon">✓</div><h2><?php echo esc_html($r['doneTitle']); ?></h2><p class="ihub-reg-done-text"></p></div>
</div>
<?php
    return ob_get_clean();
}

add_shortcode('idevapp_registration', 'ihub_render_registration_form');
