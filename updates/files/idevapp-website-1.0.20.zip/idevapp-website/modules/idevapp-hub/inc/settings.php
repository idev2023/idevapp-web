<?php
/** Site settings (เมนู ศูนย์บริการ → ตั้งค่าเว็บไซต์), same keys as the old site_settings table. */
defined('ABSPATH') || exit;

function ihub_setting_defaults() {
    return [
        'site_name' => (string) get_option('blogname'), 'site_name_en' => '',
        'site_tagline' => (string) get_option('blogdescription'), 'site_tagline_en' => '',
        'phone' => '',
        'seo_on' => 'true', 'seo_autofill' => 'true', 'seo_org_type' => 'MedicalClinic', 'seo_home_title' => '', 'seo_home_title_en' => '', 'seo_home_desc' => '', 'seo_home_desc_en' => '',
        'seo_city' => '', 'seo_province' => '', 'seo_postcode' => '', 'seo_geo' => '', 'seo_image' => '', 'seo_same_as' => '', 'seo_google' => '', 'seo_bing' => '',
        'address' => '', 'address_en' => '',
        'registration_url' => '', 'appointment_url' => '',
        'mourning_mode' => 'false', 'map_query' => '', 'map_on_contact' => 'true',
        'hero_title' => (string) get_option('blogname'), 'hero_title_en' => '',
        'hero_highlight' => '', 'hero_highlight_en' => '',
        'hero_text' => 'บริการดูแลรักษาพยาบาลด้วยมาตรฐานวิชาชีพ พร้อมทีมแพทย์และพยาบาลที่ใส่ใจทุกขั้นตอน',
        'hero_text_en' => 'Professional medical care with a caring team of doctors and nurses.',
        // 1.1: contact shortcuts, opening hours, privacy, images
        'line_url' => '', 'quickbar' => 'true', 'back_to_top' => 'true', 'font_tools' => 'true',
        'hours' => '', 'emergency_24h' => 'true',
        'cookie_banner' => 'true', 'cookie_text' => 'เว็บไซต์นี้ใช้คุกกี้ที่จำเป็นต่อการทำงาน และคุกกี้จากบริการภายนอก (Google Maps, YouTube) เมื่อคุณยินยอม',
        'cookie_text_en' => 'This website uses cookies that are needed for it to work, and cookies from external services (Google Maps, YouTube) when you agree.',
        'privacy_url' => '',
        // 1.3.5: back office in program mode
        'appmode' => 'true', 'appmode_posts' => 'false', 'appmode_pages' => 'false', 'appmode_media' => 'false', 'appmode_hub' => 'false',
        'img_ratio_news' => '16/10', 'img_ratio_gallery' => '4/3', 'img_ratio_team' => '1/1', 'img_ratio_article' => '16/9', 'img_position' => 'center',
    ];
}

function ihub_settings() {
    static $cache = null;
    if ($cache === null || did_action('update_option_ihub_settings')) {
        $saved = get_option('ihub_settings', []);
        $cache = array_merge(ihub_setting_defaults(), is_array($saved) ? $saved : []);
    }
    return $cache;
}

function ihub_setting($key) {
    $all = ihub_settings();
    $v = isset($all[$key]) ? (string) $all[$key] : '';
    // Empty booking / registration link: use the iDev Appointments pages when that plugin is active.
    if ($v === '' && $key === 'appointment_url' && function_exists('idev_appt_booking_url')) $v = (string) idev_appt_booking_url();
    if ($v === '' && $key === 'registration_url' && function_exists('idev_appt_register_url')) $v = (string) idev_appt_register_url();
    return $v;
}

/** Settings resolved to the visitor's language. */
function ihub_site_local($lang = null) {
    $s = ihub_settings();
    return [
        'name' => ihub_pick($s['site_name'], $s['site_name_en'], $lang),
        'tagline' => ihub_pick($s['site_tagline'], $s['site_tagline_en'], $lang),
        'address' => ihub_pick($s['address'], $s['address_en'], $lang),
    ];
}

function ihub_ratio_options($with_original) {
    $list = [['16/9', '16:9 แนวนอนกว้าง'], ['16/10', '16:10'], ['3/2', '3:2'], ['4/3', '4:3'], ['1/1', '1:1 สี่เหลี่ยมจัตุรัส'], ['3/4', '3:4 แนวตั้ง']];
    if ($with_original) $list[] = ['auto', 'ตามรูปต้นฉบับ (ไม่ตัด)'];
    return $list;
}

/** Opening hours: 7 rows (1 = Monday) with open/close times. */
function ihub_hours() {
    $saved = json_decode(ihub_setting('hours'), true);
    $hours = [];
    for ($day = 1; $day <= 7; $day++) {
        $row = is_array($saved) && isset($saved[$day - 1]) && is_array($saved[$day - 1]) ? $saved[$day - 1] : [];
        $hours[$day] = ['closed' => !empty($row['closed']), 'open' => preg_match('/^\d{2}:\d{2}$/', $row['open'] ?? '') ? $row['open'] : '08:00', 'close' => preg_match('/^\d{2}:\d{2}$/', $row['close'] ?? '') ? $row['close'] : '20:00'];
    }
    return $hours;
}

add_action('admin_menu', function () {
    add_menu_page('ศูนย์บริการ', 'ศูนย์บริการ', 'edit_posts', 'idevapp-hub', 'ihub_render_settings_page', 'dashicons-plus-alt', 3);
    add_submenu_page('idevapp-hub', 'ตั้งค่าเว็บไซต์', 'ตั้งค่าเว็บไซต์', 'manage_options', 'idevapp-hub', 'ihub_render_settings_page');
});

function ihub_settings_fields() {
    return [
        'ข้อมูลเว็บไซต์' => [
            ['site_name', 'ชื่อเว็บไซต์ (ไทย)'], ['site_name_en', 'Site name (English)'],
            ['site_tagline', 'คำโปรย (ไทย)'], ['site_tagline_en', 'Tagline (English)'],
            ['phone', 'เบอร์โทร / ฉุกเฉิน'],
            ['address', 'ที่อยู่ (ไทย)', 'textarea'], ['address_en', 'Address (English)', 'textarea'],
        ],
        'ลิงก์ระบบเดิม (ลงทะเบียน / นัดหมาย)' => [
            ['registration_url', 'ลิงก์ระบบลงทะเบียนผู้ป่วยใหม่', 'url', 'ปุ่ม “ลงทะเบียนผู้ป่วยใหม่” และ /register จะไปที่ลิงก์นี้'],
            ['appointment_url', 'ลิงก์ระบบนัดหมาย', 'url', 'ปุ่ม “นัดหมาย” /appointment และเวลาในตารางออกตรวจ (ถ้าแพทย์ไม่มีลิงก์ของตัวเอง)'],
        ],
        'ปุ่มลัดและการใช้งาน' => [
            ['line_url', 'ลิงก์ LINE Official Account', 'url', 'เช่น https://lin.ee/xxxx หรือ https://line.me/R/ti/p/@xxxx (เว้นว่าง = ไม่แสดงปุ่ม LINE)'],
            ['quickbar', 'แถบปุ่มลัดด้านล่างจอมือถือ (โทร · นัดหมาย · นำทาง · LINE)', 'checkbox'],
            ['back_to_top', 'ปุ่มกลับขึ้นบนสุด', 'checkbox'],
            ['font_tools', 'ปุ่มปรับขนาดตัวอักษร A- A A+', 'checkbox'],
        ],
        'เวลาทำการ (ใช้คำนวณสถานะ “เปิดอยู่ / ปิดแล้ว” อัตโนมัติ)' => [
            ['hours', 'เวลาทำการคลินิก', 'hours', 'วันหยุดประจำปีที่ติ๊ก “ปิดคลินิก” จะแสดงเป็นวันหยุดอัตโนมัติ · ใช้ในการ์ดสถานะของแบนเนอร์หลัก (เปิด “สถานะอัตโนมัติ” ที่การ์ด) และข้อมูลสำหรับ Google'],
            ['emergency_24h', 'หน่วยฉุกเฉินเปิด 24 ชั่วโมง (แสดงต่อท้ายตอนคลินิกปิด)', 'checkbox'],
        ],
        'รูปภาพ (ให้ทุกรูปแสดงสัดส่วนเดียวกัน ไม่ว่ารูปต้นฉบับขนาดไหน)' => [
            ['img_ratio_news', 'รูปในการ์ดข่าว', 'select', '', ihub_ratio_options(false)],
            ['img_ratio_article', 'รูปหลักในหน้าข่าว/หน้าเพจ', 'select', '', ihub_ratio_options(true)],
            ['img_ratio_gallery', 'รูปในแกลเลอรีและบล็อกรูป+ข้อความ', 'select', '', ihub_ratio_options(true)],
            ['img_ratio_team', 'รูปแพทย์ (ทีมแพทย์)', 'select', '', ihub_ratio_options(false)],
            ['img_position', 'ถ้าต้องตัดขอบ ให้เก็บส่วนไหนของรูปไว้', 'select', 'รูปคน/หน้าตรง แนะนำ “ด้านบน” จะไม่ตัดศีรษะ', [['center', 'ตรงกลาง'], ['top', 'ด้านบน'], ['bottom', 'ด้านล่าง']]],
        ],
        'SEO — ให้ Google ค้นเจอ' => [
            ['seo_on', 'เปิดระบบ SEO (คำอธิบาย แผนผังเว็บ ข้อมูลโครงสร้างสำหรับ Google)', 'checkbox', 'ปิดตัวเองอัตโนมัติถ้าติดตั้ง Yoast / Rank Math / SEOPress / All in One SEO'],
            ['seo_autofill', 'เติมข้อมูล SEO ให้อัตโนมัติเมื่อบันทึกหน้า/ข่าว (เฉพาะช่องที่ว่าง)', 'checkbox'],
            ['seo_org_type', 'ประเภทหน่วยงาน', 'select', 'ใช้บอก Google ว่าเว็บนี้คือหน่วยงานแบบไหน', [['MedicalClinic', 'คลินิก / สถานพยาบาล'], ['Hospital', 'โรงพยาบาล'], ['GovernmentOrganization', 'หน่วยงานราชการ'], ['Organization', 'องค์กรทั่วไป']]],
            ['seo_home_title', 'หัวเรื่องหน้าแรกบน Google (ไทย)', 'text', 'เช่น โรงพยาบาลของคุณ | บริการสุขภาพ อำเภอ จังหวัด'], ['seo_home_title_en', 'Home title on Google (English)'],
            ['seo_home_desc', 'คำอธิบายหน้าแรก (ไทย, 50–160 ตัวอักษร)', 'textarea'], ['seo_home_desc_en', 'Home description (English)', 'textarea'],
            ['seo_city', 'อำเภอ / เมือง'], ['seo_province', 'จังหวัด'], ['seo_postcode', 'รหัสไปรษณีย์'],
            ['seo_geo', 'พิกัด (ละติจูด, ลองจิจูด)', 'text', 'เช่น 8.6446, 98.2536 — คัดลอกจาก Google Maps (คลิกขวาที่หมุด)'],
            ['seo_image', 'รูปแชร์หลัก (ลิงก์รูป 1200×630)', 'url'],
            ['seo_same_as', 'ลิงก์โซเชียลของหน่วยงาน (Facebook, YouTube, Google Maps … คั่นด้วยเว้นวรรค)', 'textarea'],
            ['seo_google', 'รหัสยืนยัน Google Search Console', 'text', 'ค่า content ของแท็ก google-site-verification (ใส่เฉพาะรหัส)'],
            ['seo_bing', 'รหัสยืนยัน Bing Webmaster'],
        ],
        'คุกกี้และความเป็นส่วนตัว (PDPA)' => [
            ['cookie_banner', 'แสดงแบนเนอร์ขอความยินยอมคุกกี้', 'checkbox', 'ถ้าผู้ชมเลือก “เฉพาะที่จำเป็น” แผนที่ Google และวิดีโอ YouTube จะโหลดเมื่อกดดูเท่านั้น'],
            ['cookie_text', 'ข้อความ (ไทย)', 'textarea'], ['cookie_text_en', 'Text (English)', 'textarea'],
            ['privacy_url', 'ลิงก์นโยบายความเป็นส่วนตัว', 'url'],
        ],
        'แผนที่' => [
            ['map_query', 'Google Map', 'textarea', 'วางโค้ด iframe จาก Google Maps → แชร์ → ฝังแผนที่ หรือลิงก์ google.com/maps หรือที่อยู่ / พิกัด (ลิงก์ย่อ maps.app.goo.gl ฝังไม่ได้)'],
            ['map_on_contact', 'แสดงแผนที่ในหน้าติดต่อเรา', 'checkbox'],
        ],
        'หลังบ้านแบบโปรแกรม' => [
            ['appmode', 'เปิดหลังบ้านแบบโปรแกรม', 'checkbox', 'เมนูด้านซ้ายแสดงเฉพาะระบบ iDev (นัดหมาย ลงทะเบียน ตารางออกตรวจ …) หน้าตาเหมือนใช้โปรแกรม · เจ้าหน้าที่ใช้โหมดนี้เสมอ ผู้ดูแลระบบสลับไป “หน้า WordPress” ได้จากแถบด้านบน'],
            ['appmode_posts', 'ผู้ดูแลระบบเห็นเมนู “เรื่อง/ข่าว” ในโหมดโปรแกรม (เจ้าหน้าที่: ตามสิทธิ์ของบทบาท)', 'checkbox'],
            ['appmode_pages', 'ผู้ดูแลระบบเห็นเมนู “หน้าเว็บ” ในโหมดโปรแกรม', 'checkbox'],
            ['appmode_media', 'ผู้ดูแลระบบเห็นเมนู “สื่อ” ในโหมดโปรแกรม', 'checkbox'],
            ['appmode_hub', 'ให้เห็นเมนู “ศูนย์บริการ” ด้วย', 'checkbox'],
        ],
        'โหมดไว้ทุกข์' => [
            ['mourning_mode', 'แสดงเว็บเป็นขาวดำ', 'checkbox'],
        ],
    ];
}

function ihub_render_settings_page() {
    if (!current_user_can('manage_options')) wp_die('ไม่มีสิทธิ์');
    $saved = false;
    if (isset($_POST['ihub_settings_nonce']) && wp_verify_nonce(sanitize_key($_POST['ihub_settings_nonce']), 'ihub_settings')) {
        $values = get_option('ihub_settings', []);
        $values = is_array($values) ? $values : [];
        foreach (ihub_settings_fields() as $fields) {
            foreach ($fields as $field) {
                [$key, , $type] = array_pad($field, 3, 'text');
                $raw = isset($_POST['ah'][$key]) ? wp_unslash($_POST['ah'][$key]) : '';
                if ($type === 'hours') {
                    $rows = [];
                    for ($day = 1; $day <= 7; $day++) {
                        $row = isset($_POST['ihub_hours'][$day]) && is_array($_POST['ihub_hours'][$day]) ? wp_unslash($_POST['ihub_hours'][$day]) : [];
                        $time = function ($v, $d) { return preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', (string) $v) ? $v : $d; };
                        $rows[] = ['closed' => !empty($row['closed']), 'open' => $time($row['open'] ?? '', '08:00'), 'close' => $time($row['close'] ?? '', '20:00')];
                    }
                    $values[$key] = wp_json_encode($rows);
                }
                elseif ($type === 'select') { $options = array_column($field[4] ?? [], 0); $values[$key] = in_array($raw, $options, true) ? $raw : ihub_setting_defaults()[$key]; }
                elseif ($type === 'checkbox') $values[$key] = $raw ? 'true' : 'false';
                elseif ($type === 'url') $values[$key] = esc_url_raw(trim($raw), ['http', 'https']);
                elseif ($key === 'map_query') $values[$key] = substr(trim($raw), 0, 2000); // only ever used through ihub_map_embed_src(), which allows Google hosts only
                elseif ($type === 'textarea') $values[$key] = sanitize_textarea_field($raw);
                else $values[$key] = sanitize_text_field($raw);
            }
        }
        if (isset($values['map_query']) && $values['map_query'] !== '' && !ihub_map_embed_src($values['map_query'])) $map_error = true;
        update_option('ihub_settings', $values);
        $saved = true;
    }
    $s = ihub_settings();
    echo '<div class="wrap ihub-admin"><h1>ตั้งค่าเว็บไซต์</h1>';
    if ($saved) echo '<div class="notice notice-success"><p>บันทึกแล้ว</p></div>';
    if (!empty($map_error)) echo '<div class="notice notice-warning"><p>แผนที่: ลิงก์นี้ฝังไม่ได้ ใช้โค้ด “ฝังแผนที่” จาก Google Maps แทน</p></div>';
    echo '<form method="post">';
    wp_nonce_field('ihub_settings', 'ihub_settings_nonce');
    foreach (ihub_settings_fields() as $section => $fields) {
        echo '<h2>' . esc_html($section) . '</h2><table class="form-table" role="presentation">';
        foreach ($fields as $field) {
            [$key, $label, $type, $help] = array_pad($field, 4, '');
            $type = $type ?: 'text';
            $name = 'ah[' . esc_attr($key) . ']';
            echo '<tr><th scope="row"><label for="ihub-' . esc_attr($key) . '">' . esc_html($label) . '</label></th><td>';
            if ($type === 'hours') {
                $days = ihub_t('doctors.days', 'th');
                echo '<table class="ihub-hours"><tbody>';
                foreach (ihub_hours() as $day => $row) {
                    echo '<tr><th>' . esc_html($days[$day - 1]) . '</th><td><input type="time" name="ihub_hours[' . $day . '][open]" value="' . esc_attr($row['open']) . '"> – <input type="time" name="ihub_hours[' . $day . '][close]" value="' . esc_attr($row['close']) . '"></td><td><label><input type="checkbox" name="ihub_hours[' . $day . '][closed]" value="1"' . checked($row['closed'], true, false) . '> ปิดทั้งวัน</label></td></tr>';
                }
                echo '</tbody></table>';
            }
            elseif ($type === 'select') {
                echo '<select id="ihub-' . esc_attr($key) . '" name="' . $name . '">';
                foreach ($field[4] as [$value, $text]) echo '<option value="' . esc_attr($value) . '"' . selected($s[$key], $value, false) . '>' . esc_html($text) . '</option>';
                echo '</select>';
            }
            elseif ($type === 'checkbox') echo '<label><input type="checkbox" id="ihub-' . esc_attr($key) . '" name="' . $name . '" value="1"' . checked($s[$key], 'true', false) . '> เปิด</label>';
            elseif ($type === 'textarea') echo '<textarea class="large-text" rows="3" id="ihub-' . esc_attr($key) . '" name="' . $name . '">' . esc_textarea($s[$key]) . '</textarea>';
            else echo '<input class="regular-text" type="' . ($type === 'url' ? 'url' : 'text') . '" id="ihub-' . esc_attr($key) . '" name="' . $name . '" value="' . esc_attr($s[$key]) . '">';
            if ($help) echo '<p class="description">' . esc_html($help) . '</p>';
            echo '</td></tr>';
        }
        echo '</table>';
    }
    submit_button('บันทึก');
    echo '</form></div>';
}

// Old addresses /register and /appointment keep working (the systems themselves already exist elsewhere).
add_action('template_redirect', function () {
    if (!is_404()) return;
    $path = trim((string) wp_parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
    $targets = ['register' => 'registration_url', 'appointment' => 'appointment_url'];
    if (isset($targets[$path])) {
        $url = ihub_setting($targets[$path]);
        wp_redirect($url && preg_match('#^https?://#i', $url) ? $url : home_url('/'));
        exit;
    }
});

/* ---------- Ready-made pages (Settings page buttons) ---------- */

function ihub_starter_pages() {
    return [
        'register' => ['ลงทะเบียนผู้ป่วยใหม่', 'New Patient Registration', 'ลงทะเบียนล่วงหน้าออนไลน์ รับบัตรคนไข้ทางอีเมล ไม่ต้องรอคิวลงทะเบียนเมื่อมาถึง', 'Register online and get your patient card by e-mail — no waiting at registration.', function () {
            return ihub_block_markup('registration', ['title' => ihub_bt(), 'text' => ihub_bt()]);
        }],
        'team' => ['ทีมแพทย์', 'Our Doctors', 'ทีมแพทย์และผู้เชี่ยวชาญของสถานพยาบาล', 'Meet the doctors and specialists of our medical center', function () {
            return ihub_block_markup('team', ihub_block_types()['team']['data']) . "\n\n" . ihub_block_markup('cta', ihub_block_types()['cta']['data'], ['background' => 'dark']);
        }],
        'faq' => ['คำถามพบบ่อย', 'FAQ', 'คำตอบสำหรับคำถามที่ผู้ป่วยถามบ่อย', 'Answers to questions patients often ask', function () {
            $faq = ihub_block_types()['faq']['data'];
            $faq['items'] = [
                ['q' => ihub_bt('ต้องนัดล่วงหน้าหรือไม่?', 'Do I need an appointment?'), 'a' => ihub_bt('คลินิกทั่วไปเข้ารับบริการได้เลย หากต้องการพบแพทย์เฉพาะทางแนะนำให้นัดล่วงหน้า', 'Walk-ins are welcome at the general clinic. Please book ahead to see a specialist.')],
                ['q' => ihub_bt('ต้องเตรียมเอกสารอะไรบ้าง?', 'What should I bring?'), 'a' => ihub_bt('บัตรประชาชน หรือพาสปอร์ตสำหรับชาวต่างชาติ และบัตรประกัน (ถ้ามี)', 'Your ID card or passport, and your insurance card if you have one.')],
                ['q' => ihub_bt('รับประกันการเดินทาง/ประกันต่างประเทศหรือไม่?', 'Do you accept travel insurance?'), 'a' => ihub_bt('รับ กรุณาแจ้งเจ้าหน้าที่และแสดงกรมธรรม์เมื่อลงทะเบียน', 'Yes. Please show your policy at registration.')],
                ['q' => ihub_bt('หน่วยฉุกเฉินเปิดกี่โมง?', 'When is the emergency unit open?'), 'a' => ihub_bt('เปิดตลอด 24 ชั่วโมง ทุกวัน', 'Open 24 hours a day, every day.')],
            ];
            return ihub_block_markup('faq', $faq) . "\n\n" . ihub_block_markup('steps', ihub_block_types()['steps']['data'], ['background' => 'light']) . "\n\n" . ihub_block_markup('cta', ihub_block_types()['cta']['data'], ['background' => 'dark']);
        }],
        'coverage' => ['สิทธิการรักษาและประกัน', 'Coverage & Insurance', 'สิทธิการรักษาที่ใช้ได้ วิธีใช้สิทธิ และเอกสารที่ต้องเตรียม', 'The health coverage we accept, how to use it and what to bring', function () {
            $card = function ($icon, $tone, $th, $en, $tth, $ten, $lth = '', $len = '', $url = '') {
                return ['icon' => $icon, 'tone' => $tone, 'image' => '', 'imageMode' => 'cover', 'title' => ihub_bt($th, $en), 'text' => ihub_bt($tth, $ten), 'linkText' => ihub_bt($lth, $len), 'url' => $url];
            };
            $cards = ['kicker' => ihub_bt('COVERAGE', 'COVERAGE'), 'title' => ihub_bt('สิทธิการรักษาที่ใช้ได้', 'Coverage we accept'), 'columns' => 3, 'iconStyle' => 'soft', 'iconSize' => 'large', 'align' => 'left', 'items' => [
                $card('idcard', 'mint', 'บัตรทอง (สปสช.)', 'Universal Coverage (UC)', 'ใช้สิทธิได้ตามเงื่อนไขของ สปสช. ยื่นบัตรประชาชนที่จุดลงทะเบียนเพื่อตรวจสอบสิทธิ', 'For Thai citizens under the National Health Security Office (NHSO) scheme. Show your Thai ID card at registration.'),
                $card('users', 'sky', 'ประกันสังคม', 'Social Security', 'ผู้ประกันตนใช้สิทธิได้ตามเงื่อนไขของสำนักงานประกันสังคม ยื่นบัตรประชาชนเพื่อตรวจสอบสิทธิ', 'For insured workers, under the conditions of the Social Security Office. Show your Thai ID card at registration.'),
                $card('shield', 'indigo', 'ข้าราชการ / รัฐวิสาหกิจ', 'Civil servants & state enterprises', 'เบิกจ่ายตรงได้ตามระเบียบของกรมบัญชีกลาง ใช้บัตรประชาชนของผู้มีสิทธิ', 'Direct billing under the Comptroller General’s Department rules. Show the ID card of the person entitled.'),
                $card('travel', 'teal', 'ประกันการเดินทาง', 'Travel insurance', 'แสดงพาสปอร์ตและกรมธรรม์เมื่อลงทะเบียน ขอใบรับรองแพทย์และใบเสร็จสำหรับเคลมประกันได้', 'Show your passport and policy at registration. We issue the medical certificate and receipt you need for your claim.'),
                $card('card', 'lavender', 'ประกันสุขภาพเอกชน', 'Private health insurance', 'สอบถามเจ้าหน้าที่ว่ารับวางบิลกับบริษัทของคุณหรือไม่ หากไม่รับ ชำระเงินแล้วนำเอกสารไปเบิกกับบริษัทประกัน', 'Ask our staff whether we can bill your insurer directly. If not, pay here and claim with the documents we give you.'),
                $card('star', 'amber', 'ชำระเงินเอง', 'Self-pay', 'คนไทยและชาวต่างชาติที่ไม่มีสิทธิหรือประกัน ชำระตามอัตราค่าบริการของสถานพยาบาล', 'Patients without coverage pay our standard rates.', 'ดูอัตราค่าบริการ', 'See our rates', '/pricing/'),
            ]];
            $steps = ['kicker' => ihub_bt('HOW TO USE YOUR COVERAGE', 'HOW TO USE YOUR COVERAGE'), 'title' => ihub_bt('ขั้นตอนการใช้สิทธิ', 'Using your coverage, step by step'), 'items' => [
                ['icon' => 'idcard', 'title' => ihub_bt('เตรียมบัตร', 'Bring your card'), 'text' => ihub_bt('บัตรประชาชน หรือพาสปอร์ตสำหรับชาวต่างชาติ และบัตรประกันหรือกรมธรรม์ (ถ้ามี)', 'Your Thai ID card or passport, and your insurance card or policy if you have one')],
                ['icon' => 'chat', 'title' => ihub_bt('แจ้งสิทธิที่จุดลงทะเบียน', 'Tell us at registration'), 'text' => ihub_bt('บอกเจ้าหน้าที่ว่าต้องการใช้สิทธิหรือประกันใด', 'Let our staff know which coverage or insurance you want to use')],
                ['icon' => 'shield', 'title' => ihub_bt('ตรวจสอบสิทธิ', 'We check your coverage'), 'text' => ihub_bt('เจ้าหน้าที่ตรวจสอบสิทธิและแจ้งค่าใช้จ่ายส่วนที่ต้องชำระเอง (ถ้ามี)', 'We check your cover and tell you about any part you need to pay yourself')],
                ['icon' => 'stethoscope', 'title' => ihub_bt('รับบริการและเอกสาร', 'Treatment and documents'), 'text' => ihub_bt('พบแพทย์ รับยา และรับใบเสร็จ / ใบรับรองแพทย์สำหรับเบิก', 'See the doctor, collect your medicine and get your receipt and certificate for claims')],
            ]];
            $faq = ['kicker' => ihub_bt('FAQ', 'FAQ'), 'title' => ihub_bt('คำถามเรื่องสิทธิการรักษา', 'Questions about coverage'), 'items' => [
                ['q' => ihub_bt('ไม่แน่ใจว่าตัวเองมีสิทธิอะไร ตรวจสอบได้อย่างไร?', 'How can I check which coverage I have?'), 'a' => ihub_bt('สิทธิบัตรทองตรวจสอบได้ที่สายด่วน สปสช. 1330 สิทธิประกันสังคมที่สายด่วน 1506 หรือสอบถามเจ้าหน้าที่ที่จุดลงทะเบียนได้เลย', 'Thai citizens can call the NHSO hotline 1330 (Universal Coverage) or the Social Security hotline 1506, or simply ask our registration staff.')],
                ['q' => ihub_bt('ต้องการเอกสารไปเบิกกับบริษัทประกัน ต้องทำอย่างไร?', 'What documents do I need for an insurance claim?'), 'a' => ihub_bt('แจ้งเจ้าหน้าที่ตอนลงทะเบียนหรือก่อนชำระเงิน เพื่อขอใบเสร็จรับเงินและใบรับรองแพทย์ (มีค่าใบรับรองแพทย์ตามอัตราของสถานพยาบาล)', 'Tell our staff at registration or before you pay, and ask for an itemised receipt and a medical certificate (the certificate has a fee).')],
                ['q' => ihub_bt('ชาวต่างชาติที่ไม่มีประกันรับบริการได้หรือไม่?', 'Can foreigners without insurance be treated?'), 'a' => ihub_bt('ได้ ชำระค่าบริการตามอัตราสำหรับชาวต่างชาติ ดูรายละเอียดได้ที่หน้าอัตราค่าบริการ', 'Yes. You pay our rates for foreign patients, shown on our rates page.')],
                ['q' => ihub_bt('กรณีฉุกเฉินต้องเตรียมเอกสารก่อนหรือไม่?', 'In an emergency, do I need my documents first?'), 'a' => ihub_bt('ไม่ต้อง ผู้ป่วยฉุกเฉินได้รับการรักษาก่อน แล้วค่อยตรวจสอบสิทธิภายหลัง', 'No. Emergency patients are treated first; we check coverage afterwards.')],
            ]];
            $cta = ['kicker' => ihub_bt('NOT SURE?', 'NOT SURE?'), 'title' => ihub_bt('ไม่แน่ใจเรื่องสิทธิ? สอบถามเราได้', 'Not sure about your coverage? Ask us'), 'text' => ihub_bt('เจ้าหน้าที่ช่วยตรวจสอบสิทธิให้ก่อนเข้ารับบริการ', 'Our staff can check your coverage before your visit'), 'buttonText' => ihub_bt('ดูอัตราค่าบริการ', 'See our rates'), 'url' => '/pricing/', 'phoneButton' => true];
            return implode("\n\n", [
                ihub_block_markup('cards', $cards),
                ihub_block_markup('steps', $steps, ['background' => 'light']),
                ihub_block_markup('faq', $faq),
                ihub_block_markup('cta', $cta, ['background' => 'dark']),
            ]);
        }],
        'services' => ['บริการทางการแพทย์', 'Medical Services', 'บริการสุขภาพสำหรับประชาชนและผู้มาเยือน', 'Health care for the community and its visitors', function () {
            $u = function ($f) { return ''; };
            $mt = function ($img, $th, $en, $hth, $hen, $bg, $sp) {
                return ihub_block_markup('mediaText', ['image' => $img, 'title' => ihub_bt($th, $en), 'html' => ihub_bt($hth, $hen), 'imageSide' => 'left'], ['background' => $bg, 'spacing' => $sp]);
            };
            return implode("\n\n", [
                $mt($u('1.jpg'), 'คลินิกเวชกรรมทั่วไป', 'General Medical Clinic',
                    '<ul><li>การวินิจฉัยและการรักษาโรคทั่วไปโดยแพทย์เวชปฏิบัติทั่วไป (แพทย์ GP)</li><li>หากจำเป็นต้องปรึกษาแพทย์เฉพาะทางหรือนัดหมายเพิ่มเติม จะส่งตัวไปยังโรงพยาบาลแม่ข่าย</li><li>ทั้งนี้ ไม่มีบริการตรวจสิ่งส่งตรวจทางห้องปฏิบัติการ (แล็บ)</li></ul>',
                    '<ul><li>Diagnosis and treatment of common illnesses by general practitioners (GP)</li><li>If you need a specialist or a further appointment, we refer you to our partner hospital</li><li>Please note: laboratory testing is not available here</li></ul>', 'white', 'none'),
                $mt($u('22.jpg'), 'หน่วยฉุกเฉิน 24 ชั่วโมง', '24-Hour Emergency Unit',
                    '<ul><li>หน่วยแพทย์ฉุกเฉินและอุบัติเหตุ (24 ชั่วโมง)</li><li>บริการรถพยาบาลฉุกเฉิน (รวมถึงการส่งต่อผู้ป่วย)</li></ul>',
                    '<ul><li>Emergency and accident medical unit (24 hours)</li><li>Emergency ambulance service (including patient transfer)</li></ul>', 'light', 'none'),
                $mt($u('33.jpg'), 'เอกซเรย์และ CT Scan', 'X-ray and CT Scan',
                    '<ul><li>Plain Films X-Ray (Chest, Skull, Extremities)</li><li>CT-Scan non-contrast (Brain, C-spine, Facial Bone)</li></ul>',
                    '<ul><li>Plain Films X-Ray (Chest, Skull, Extremities)</li><li>CT-Scan non-contrast (Brain, C-spine, Facial Bone)</li></ul>', 'white', 'none'),
                $mt($u('44.jpg'), 'คลินิกนักเดินทาง (เปิดบริการเร็ว ๆ นี้)', 'Travel Clinic (Opening Soon)',
                    '<p><strong>“เตรียมพร้อมสุขภาพ ก่อนออกเดินทางสู่ทุกจุดหมายทั่วโลก”</strong></p><p>ให้บริการปรึกษา ป้องกัน และดูแลสุขภาพนักเดินทางครบวงจร โดยทีมแพทย์ผู้เชี่ยวชาญ</p><p><strong>บริการของเรา:</strong></p><ol><li><strong>บริการฉีดวัคซีนป้องกันโรคสำหรับนักเดินทาง (Vaccinations):</strong><ul><li>วัคซีนป้องกันไข้เลือดออก (<em>Qdenga</em>)</li><li>วัคซีนไข้หวัดใหญ่ตามฤดูกาล (<em>Influenza</em>)</li><li>วัคซีนป้องกันปอดบวมและติดเชื้อในกระแสเลือด (<em>PCV20</em> สำหรับผู้สูงอายุ 50 ปีขึ้นไป)</li><li>วัคซีนป้องกันตับอักเสบเอ (<em>Avaxim 160 U</em>)</li></ul></li><li><strong>บริการจ่ายยาป้องกันเฉพาะทาง (Travel Medications):</strong><ul><li>ยาป้องกันภาวะลิ่มเลือดอุดตันในหลอดเลือดดำจากการเดินทางระยะยาว (<em>Enoxaparin injection</em>)</li><li>ยาป้องกันและยาฉุกเฉินก่อน-หลังสัมผัสเชื้อ HIV (<em>PrEP / PEP</em>)</li><li>ยาป้องกันภาวะแพ้ความกดอากาศสูง / โรคแพ้ที่สูง (<em>Acetazolamide</em>)</li></ul></li><li><strong>ตรวจประเมินและออกใบรับรองความพร้อมในการเดินทางทางอากาศ (Fit to Fly Evaluation &amp; Certificate)</strong></li></ol>',
                    '<p><strong>“Get healthy and ready before you travel to any destination in the world”</strong></p><p>Complete travel health consultation, prevention and care by our team of doctors.</p><p><strong>Our services:</strong></p><ol><li><strong>Travel vaccinations:</strong><ul><li>Dengue vaccine (<em>Qdenga</em>)</li><li>Seasonal influenza vaccine (<em>Influenza</em>)</li><li>Pneumonia and bloodstream infection vaccine (<em>PCV20</em>, for adults aged 50 and over)</li><li>Hepatitis A vaccine (<em>Avaxim 160 U</em>)</li></ul></li><li><strong>Travel medications:</strong><ul><li>Prevention of blood clots in the veins on long journeys (<em>Enoxaparin injection</em>)</li><li>HIV prevention and emergency medication before and after exposure (<em>PrEP / PEP</em>)</li><li>Prevention of altitude sickness (<em>Acetazolamide</em>)</li></ul></li><li><strong>Fit to Fly evaluation &amp; certificate</strong></li></ol>', 'dark', 'normal'),
                $mt($u('jpg.webp'), 'คลินิกทันตกรรม', 'Dental Clinic',
                    '<p>คลินิกทันตกรรม เปิดให้บริการดูแลรักษาและส่งเสริมสุขภาพช่องปากแก่ประชาชนในพื้นที่ ตลอดจนนักท่องเที่ยวทั้งชาวไทยและชาวต่างชาติอย่างเป็นทางการ โดยมุ่งเน้นการให้บริการทางทันตกรรมที่มีมาตรฐาน สะอาด ปลอดภัย และใส่ใจในทุกรายละเอียด</p><p><strong>ขอบเขตการให้บริการทางทันตกรรม:</strong></p><ul><li><strong>ทันตกรรมป้องกันและบูรณะ:</strong> บริการตรวจสุขภาพช่องปากประจำปี, ขูดหินปูน, ขัดฟัน, อุดฟัน และถอนฟัน</li><li><strong>ทันตกรรมเพื่อความงาม:</strong> บริการฟอกสีฟัน (Teeth Whitening) และงานตกแต่งรอยยิ้มด้วยวีเนียร์ (Veneers)</li><li><strong>ทันตกรรมเฉพาะทาง:</strong> การรักษาคลองรากฟัน, การผ่าฟันคุด, การทำครอบฟัน และฟันเทียม</li><li><strong>การดูแลทันตกรรมฉุกเฉิน (Emergency Dental Care):</strong> รองรับการบรรเทาอาการปวดฟันกะทันหัน และอุบัติเหตุทางฟัน</li></ul><p><strong>กำหนดเวลาเปิดทำการ:</strong></p><ul><li><strong>วันทำการ:</strong> เปิดให้บริการทุกวันอังคาร ถึง วันศุกร์</li><li><strong>เวลาทำการ:</strong> 09.30 น. – 15.00 น. <em>(ปิดทำการวันเสาร์ – วันจันทร์ และวันหยุดนักขัตฤกษ์)</em></li></ul>',
                    '<p>Dental Clinic is now officially open, providing dental treatment and oral health care for local residents as well as Thai and international visitors. We focus on dental care that is up to standard, clean, safe and attentive to every detail.</p><p><strong>Dental services:</strong></p><ul><li><strong>Preventive and restorative dentistry:</strong> annual dental check-ups, scaling, polishing, fillings and extractions</li><li><strong>Cosmetic dentistry:</strong> teeth whitening and smile makeovers with veneers</li><li><strong>Specialist dentistry:</strong> root canal treatment, wisdom tooth surgery, crowns and dentures</li><li><strong>Emergency dental care:</strong> relief of sudden toothache and treatment of dental injuries</li></ul><p><strong>Opening hours:</strong></p><ul><li><strong>Days:</strong> Tuesday to Friday</li><li><strong>Hours:</strong> 09:30 – 15:00 <em>(closed Saturday to Monday and on public holidays)</em></li></ul>', 'light', 'small'),
            ]);
        }],
        'rates' => ['อัตราค่าบริการทางการแพทย์', 'Medical Service Rates', 'อัตราค่าบริการเริ่มต้นและค่าบริการทางรังสีวิทยา สำหรับคนไทยและชาวต่างชาติ', 'Starting rates and radiology fees for Thai and foreign patients', function () {
            $d = ihub_block_types()['rates']['data'];
            $d = array_merge($d, [
                'kicker' => ihub_bt('SERVICE RATES', 'SERVICE RATES'), 'title' => ihub_bt('อัตราค่าบริการทางการแพทย์', 'Medical Service Rates'),
                'text' => ihub_bt('อัตราค่าบริการเริ่มต้นโดยประมาณ', 'Estimated starting rates'),
                'image' => '',
                'officeLabel' => ihub_bt('ในเวลาราชการ', 'Official hours'), 'afterLabel' => ihub_bt('นอกเวลาราชการ', 'After hours'),
                'thaiOffice' => '120', 'thaiAfter' => '120', 'foreignOffice' => '1640', 'foreignAfter' => '1900',
                'includesThai' => ihub_bt('ค่าบริการทางการพยาบาล', 'Nursing service fee'),
                'includesForeign' => ihub_bt("ค่าลงทะเบียน\nค่าแพทย์\nค่าใบรับรองแพทย์", "Registration fee\nDoctor fee\nMedical certificate fee"),
                'notice' => ihub_bt('ราคานี้เป็นราคาประมาณการเบื้องต้น ไม่รวมค่ายา เวชภัณฑ์ทางการแพทย์ และค่าบริการทางรังสีวิทยา', 'Prices are preliminary estimates, EXCLUDING medications, medical supplies and radiology fees.'),
                'listTitle' => ihub_bt('🩻 ค่าบริการทางรังสีวิทยา', '🩻 Radiology fees'), 'listSub' => ihub_bt('Radiology Examination Fees', 'Starting prices'),
                'items' => [
                    ['name' => ihub_bt('Plain Films', 'Plain Films'), 'thai' => '250', 'foreign' => '500'],
                    ['name' => ihub_bt('X-ray Portable', 'X-ray Portable'), 'thai' => '600', 'foreign' => '1200'],
                    ['name' => ihub_bt('CT Scan Brain', 'CT Scan Brain'), 'thai' => '3500', 'foreign' => '7000'],
                    ['name' => ihub_bt('CT C-spine', 'CT C-spine'), 'thai' => '6000', 'foreign' => '12000'],
                    ['name' => ihub_bt('CT Facial bone', 'CT Facial bone'), 'thai' => '6000', 'foreign' => '12000'],
                ],
                'addonName' => ihub_bt('3-D reconstruction', '3-D reconstruction'), 'addonNote' => ihub_bt('หากรังสีแพทย์มีคำสั่งตรวจเพิ่มเติม', 'If requested by the radiologist'), 'addonPrice' => '2000',
            ]);
            return ihub_block_markup('rates', $d);
        }],
        'travel-clinic' => ['คลินิกนักเดินทาง', 'Travel Clinic', 'ให้คำปรึกษาสุขภาพก่อนเดินทาง ฉีดวัคซีน และออกใบรับรองแพทย์มาตรฐานสากล', 'Pre-travel health advice, travel vaccines and international medical certificates', function () {
            $d = array_merge(ihub_block_types()['feature']['data'], [
                'badge' => ihub_bt('เปิดให้บริการเร็ว ๆ นี้ • OPENING SOON', 'OPENING SOON'), 'badgeTone' => 'amber',
                'title' => ihub_bt('คลินิกนักเดินทาง (Travel Clinic)', 'Travel Clinic'),
                'text' => ihub_bt('เตรียมพบกับบริการให้คำปรึกษาด้านสุขภาพก่อนเดินทาง ฉีดวัคซีน และออกใบรับรองแพทย์มาตรฐานสากล ', 'Get ready for expert pre-travel health consultations, destination vaccinations and international medical certificates.'),
                'image' => '',
                'button1Text' => ihub_bt('สอบถามข้อมูลเพิ่มเติมผ่าน LINE', 'Inquire via LINE'), 'button2Text' => ihub_bt('ติดต่อสถานพยาบาล', 'Contact the medical center'),
                'whyTitle' => ihub_bt('ทำไมต้องรับบริการที่คลินิกนักเดินทางของเรา?', 'Why choose our Travel Clinic?'),
                'why' => [
                    ['emoji' => '🌍', 'title' => ihub_bt('วัคซีนมาตรฐานสากล', 'WHO-standard vaccines'), 'text' => ihub_bt('ครอบคลุมวัคซีนที่จำเป็นตามข้อกำหนดของ WHO และประเทศจุดหมายปลายทาง', 'Travel vaccines that follow WHO guidelines and the rules of your destination.')],
                    ['emoji' => '🩺', 'title' => ihub_bt('ปรึกษาแพทย์', 'Doctor consultation'), 'text' => ihub_bt('ประเมินความเสี่ยงรายบุคคลตามเส้นทาง กิจกรรม (เช่น ดำน้ำ เดินป่า) และสุขภาพ', 'A personal risk assessment for your route, activities (diving, trekking) and health.')],
                    ['emoji' => '📜', 'title' => ihub_bt('ใบรับรองแพทย์สากล', 'International certificates'), 'text' => ihub_bt('บริการออกสมุดวัคซีนเล่มเหลือง (ICV) และใบรับรองแพทย์ภาษาอังกฤษ', 'Yellow fever vaccination booklets (ICV) and medical certificates in English.')],
                ],
                'servicesTitle' => ihub_bt('บริการที่เราเตรียมพร้อมให้คุณ', 'Upcoming services'),
                'services' => [
                    ['emoji' => '💉', 'title' => ihub_bt('ฉีดวัคซีนป้องกันโรคก่อนเดินทาง (Travel Vaccinations)', 'Travel vaccinations'), 'text' => ihub_bt('วัคซีนไข้เหลือง (Yellow Fever), ตับอักเสบ เอ/บี (Hepatitis A/B), พิษสุนัขบ้า (Rabies), ไทฟอยด์ (Typhoid), บาดทะยัก และไข้หวัดใหญ่', 'Yellow fever, hepatitis A/B, rabies, typhoid, tetanus and influenza.')],
                    ['emoji' => '💊', 'title' => ihub_bt('ยาและเวชภัณฑ์สำหรับการเดินทาง (Travel Medications)', 'Travel medications'), 'text' => ihub_bt('ยาป้องกันมาลาเรีย (Malaria Prophylaxis), ยาป้องกันอาการเมาเรือ/เมารถ (Motion Sickness) และชุดยาพกพาฉุกเฉิน', 'Malaria prophylaxis, motion sickness medicine and travel first-aid kits.')],
                    ['emoji' => '📋', 'title' => ihub_bt('ตรวจสุขภาพและใบรับรองแพทย์ (Medical Certificates)', 'Health checks and medical certificates'), 'text' => ihub_bt('ใบรับรองแพทย์อนุญาตให้เดินทางโดยเครื่องบิน (Fitness to Fly), ใบรับรองแพทย์สำหรับกิจกรรมทางน้ำ/ดำน้ำ และสมัครงาน', 'Fitness-to-fly certificates, diving / water-sport medicals and job applications.')],
                ],
                'noticeTitle' => ihub_bt('แจ้งกำหนดการเปิดให้บริการ', 'Opening schedule'),
                'notice' => ihub_bt('คลินิกนักเดินทางของเรา อยู่ระหว่างการเตรียมความพร้อมขั้นสุดท้าย หากต้องการสอบถามหรือสำรองคิวล่วงหน้า ติดต่อเจ้าหน้าที่ผ่านช่องทางออนไลน์ได้ทันที', 'The Travel Clinic is in its final preparations. To ask questions or reserve a slot in advance, contact our staff online any time.'),
            ]);
            return ihub_block_markup('feature', $d);
        }],
    ];
}

add_action('admin_post_ihub_starter_page', function () {
    if (!current_user_can('publish_pages') || !check_admin_referer('ihub_starter_page')) wp_die('ไม่มีสิทธิ์');
    $key = sanitize_key($_POST['page'] ?? '');
    $pages = ihub_starter_pages();
    if (!isset($pages[$key])) wp_die('ไม่พบแบบหน้า');
    [$title, $title_en, $summary, $summary_en, $content] = $pages[$key];
    $target = (int) ($_POST['target'] ?? 0);
    if ($target) {
        // Replace the content of an existing page. WordPress keeps the old content as a revision.
        $page = get_post($target);
        if (!$page || $page->post_type !== 'page' || !current_user_can('edit_page', $target)) wp_die('ไม่พบหน้านี้');
        wp_update_post(wp_slash(['ID' => $target, 'post_content' => $content()]));
        // The blocks carry their own English, so the old separate English body is cleared.
        foreach (['ihub_content_en', '_idev_content_en'] as $meta) delete_post_meta($target, $meta);
        update_post_meta($target, 'ihub_layout', 'full');
        if (strpos($content(), 'wp:idevapp/cta') !== false) update_post_meta($target, 'ihub_show_contact', '0'); // the page has its own contact bar
        wp_safe_redirect(add_query_arg('ihub_replaced', $target, admin_url('admin.php?page=idevapp-hub')));
        exit;
    }
    $id = wp_insert_post(wp_slash(['post_type' => 'page', 'post_status' => 'draft', 'post_title' => $title, 'post_name' => $key, 'post_excerpt' => $summary, 'post_content' => $content()]));
    if (!is_wp_error($id)) {
        update_post_meta($id, 'ihub_title_en', $title_en);
        update_post_meta($id, 'ihub_excerpt_en', $summary_en);
        update_post_meta($id, 'ihub_layout', 'full');
        update_post_meta($id, 'ihub_show_contact', '0');
        if ($key === 'register') {
            // The registration page is published right away and becomes the "New patient registration" link.
            wp_update_post(['ID' => $id, 'post_status' => 'publish']);
            $settings = get_option('ihub_settings', []);
            $settings['registration_url'] = get_permalink($id);
            update_option('ihub_settings', $settings);
        }
    }
    wp_safe_redirect(is_wp_error($id) ? admin_url('admin.php?page=idevapp-hub') : admin_url("post.php?post={$id}&action=edit"));
    exit;
});

add_action('admin_notices', function () {
    $screen = get_current_screen();
    if (!$screen || $screen->id !== 'toplevel_page_idevapp-hub') return;
    echo '<div class="notice notice-info"><p><strong>สร้างหน้าสำเร็จรูป</strong> (สร้างเป็นฉบับร่างให้แก้ไขก่อนเผยแพร่ แล้วเพิ่มในเมนูที่ Appearance → Menus): ';
    foreach (ihub_starter_pages() as $key => $page) {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="display:inline">' . wp_nonce_field('ihub_starter_page', '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_starter_page"><input type="hidden" name="page" value="' . esc_attr($key) . '"><button class="button">＋ ' . esc_html($page[0]) . '</button></form> ';
    }
    echo '</p>';
    if (!empty($_GET['ihub_replaced']) && ($done = get_post((int) $_GET['ihub_replaced']))) {
        echo '<p><strong>✓ ใส่แบบหน้าลงใน “' . esc_html($done->post_title) . '” แล้ว</strong> — <a href="' . esc_url(get_permalink($done)) . '" target="_blank">ดูหน้า</a> · <a href="' . esc_url(add_query_arg('lang', 'en', get_permalink($done))) . '" target="_blank">ดูภาษาอังกฤษ</a> · เนื้อหาเดิมกู้คืนได้ที่ “ประวัติการแก้ไข (Revisions)” ของหน้า</p>';
    }
    // Put a template into a page that already exists (keeps its address and menu link).
    $all = get_pages(['post_status' => 'publish,draft,private', 'sort_column' => 'post_title']);
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'แทนที่เนื้อหาเดิมของหน้าที่เลือกด้วยแบบหน้านี้? (เนื้อหาเดิมกู้คืนได้จาก Revisions)\')"><p><strong>ใส่แบบหน้าลงในหน้าที่มีอยู่แล้ว</strong> (ทั้งภาษาไทยและอังกฤษ ลิงก์และเมนูเหมือนเดิม): ' . wp_nonce_field('ihub_starter_page', '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_starter_page"><select name="page">';
    foreach (ihub_starter_pages() as $key => $page) echo '<option value="' . esc_attr($key) . '">' . esc_html($page[0]) . '</option>';
    echo '</select> → <select name="target" required><option value="">— เลือกหน้า —</option>';
    foreach ($all as $p) echo '<option value="' . (int) $p->ID . '">' . esc_html($p->post_title . ' (/' . $p->post_name . '/)') . '</option>';
    echo '</select> <button class="button button-primary">ใส่แบบหน้า</button></p></form></div>';
});
