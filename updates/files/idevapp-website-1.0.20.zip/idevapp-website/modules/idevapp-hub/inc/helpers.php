<?php
defined('ABSPATH') || exit;

/** Line icons used across the site (same set as the old site). */
/** Icons for blocks (stroke icons, 24×24). [key => [Thai name, SVG paths]] */
function ihub_icon_set() {
    return [
        'plus' => ['บวก / ทั่วไป', '<path d="M12 5v14M5 12h14"/>'],
        'emergency' => ['ฉุกเฉิน', '<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="M12 8v8M8 12h8"/>'],
        'ambulance' => ['รถพยาบาล', '<path d="M3 17V7a1 1 0 0 1 1-1h10v11M14 10h4l3 3v4h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/><path d="M8 9v4M6 11h4"/>'],
        'stethoscope' => ['ตรวจโรคทั่วไป', '<path d="M5 3v6a5 5 0 0 0 10 0V3M5 3H3M15 3h2"/><path d="M10 14v2a5 5 0 0 0 10 0v-3"/><circle cx="20" cy="11" r="2"/>'],
        'heart' => ['หัวใจ', '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8Z"/><path d="M3 12h4l2-3 3 6 2-3h4"/>'],
        'tooth' => ['ทันตกรรม', '<path d="M7 3c-2.5 0-4 2-4 4.5 0 3 1.5 4 2 7 .5 3 1 6.5 2.5 6.5S9.3 18 10 16c.5-1.3 1-2 2-2s1.5.7 2 2c.7 2 1 5 2.5 5s2-3.5 2.5-6.5c.5-3 2-4 2-7C21 5 19.5 3 17 3c-2 0-3 1-5 1S9 3 7 3Z"/>'],
        'baby' => ['แม่และเด็ก', '<circle cx="12" cy="8" r="5"/><path d="M9.5 8h.01M14.5 8h.01M10 10.5a3 3 0 0 0 4 0M5 21a7 7 0 0 1 14 0"/>'],
        'pregnant' => ['ฝากครรภ์', '<circle cx="11" cy="4" r="2"/><path d="M10 7c-2 1-2 4-2 6v8M12 21v-5h1a4 4 0 0 0 0-8h-1"/>'],
        'eye' => ['ตา', '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>'],
        'brain' => ['สมอง / ระบบประสาท', '<path d="M9 3a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 3 3h1V3H9ZM15 3a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-3 3h-1V3h1Z"/>'],
        'bone' => ['กระดูกและข้อ', '<path d="M17 10c.7.7 1.7 1 2.8.7a2.5 2.5 0 1 0-2-3.5 2.5 2.5 0 1 0-3.5-2C14 6.3 14.3 7.3 15 8L8 15c-.7-.7-1.7-1-2.8-.7a2.5 2.5 0 1 0 2 3.5 2.5 2.5 0 1 0 3.5 2c.3-1.1 0-2.1-.7-2.8l7-7Z"/>'],
        'lungs' => ['ปอด / ทางเดินหายใจ', '<path d="M12 3v9M12 12l-3-3M12 12l3-3"/><path d="M8 8c-3 0-5 5-5 9 0 2 1 3 3 3s3-1 3-3v-7M16 8c3 0 5 5 5 9 0 2-1 3-3 3s-3-1-3-3v-7"/>'],
        'xray' => ['เอกซเรย์', '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M12 6v12M9 8h6M8 11h8M9 14h6M10 17h4"/>'],
        'lab' => ['ห้องปฏิบัติการ', '<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4a2 2 0 0 0 1.8-3l-5-9V3"/><path d="M7 15h10"/>'],
        'microscope' => ['ตรวจวิเคราะห์', '<path d="M6 18h8M3 22h18M14 22a7 7 0 1 0 0-14h-1M9 14h2M9 12a2 2 0 0 1-2-2V6h6v4a2 2 0 0 1-2 2Z"/><path d="M12 6V3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3"/>'],
        'pill' => ['ยา / เภสัชกรรม', '<path d="M10.5 20.5 3.5 13.5a5 5 0 0 1 7-7l7 7a5 5 0 0 1-7 7Z"/><path d="m8.5 8.5 7 7"/>'],
        'syringe' => ['วัคซีน / ฉีดยา', '<path d="m18 2 4 4M17 7l3-3M19 9 8.7 19.3a2.4 2.4 0 0 1-3.4 0l-.6-.6a2.4 2.4 0 0 1 0-3.4L15 5M9 11l4 4M5 19l-3 3M14 4l6 6"/>'],
        'bandage' => ['ทำแผล', '<rect x="2" y="8" width="20" height="8" rx="4" transform="rotate(-45 12 12)"/><path d="M10 10h.01M14 14h.01M10 14h.01M14 10h.01"/>'],
        'bed' => ['ผู้ป่วยใน / ห้องพัก', '<path d="M2 20V6M2 16h20v4M22 16v-4a3 3 0 0 0-3-3h-8v7"/><circle cx="6.5" cy="11.5" r="2"/>'],
        'wheelchair' => ['กายภาพบำบัด', '<circle cx="9" cy="4" r="2"/><path d="M9 7v6h6l3 6M9 9H6"/><path d="M14.5 17A5 5 0 1 1 7 11.5"/>'],
        'thermometer' => ['ไข้ / อายุรกรรม', '<path d="M14 14.8V4a2 2 0 0 0-4 0v10.8a4 4 0 1 0 4 0Z"/><path d="M12 9v7"/>'],
        'leaf' => ['แพทย์แผนไทย', '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 19 2c1 2 2 4.2 2 8 0 5.5-4.8 10-10 10Z"/><path d="M2 21c0-3 1.9-5.4 5.1-6"/>'],
        'apple' => ['โภชนาการ', '<path d="M12 6.5c-1-1-2.5-1.5-4-1.5-3 0-5 2.5-5 6 0 4.5 3 10 6 10 1 0 2-.5 3-.5s2 .5 3 .5c3 0 6-5.5 6-10 0-3.5-2-6-5-6-1.5 0-3 .5-4 1.5ZM12 6.5C12 4 13.5 2 15 2"/>'],
        'scale' => ['ตรวจสุขภาพ', '<path d="M3 21h18M12 3v18M5 7h14M5 7l-3 7a3 3 0 0 0 6 0L5 7ZM19 7l-3 7a3 3 0 0 0 6 0l-3-7Z"/>'],
        'shield' => ['ประกันสุขภาพ / ปลอดภัย', '<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/>'],
        'users' => ['ครอบครัว / ชุมชน', '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>'],
        'home' => ['เยี่ยมบ้าน', '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1V10Z"/>'],
        'travel' => ['เวชศาสตร์การเดินทาง', '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 3 2.5 15 0 18M12 3c-2.5 3-2.5 15 0 18"/>'],
        'calendar' => ['นัดหมาย', '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01"/>'],
        'clock' => ['เวลาทำการ', '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'],
        'phone' => ['โทรศัพท์', '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.4 19.4 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8 8.9a16 16 0 0 0 6 6l1.2-1.3a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.8 2.1Z"/>'],
        'pin' => ['สถานที่', '<path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>'],
        'megaphone' => ['ประกาศ', '<path d="m3 11 18-5v12L3 14v-3Z"/><path d="M11 16.5 13 22H8l-1.5-7.5M21 10v4"/>'],
        'news' => ['ข่าว', '<path d="M5 4h14a2 2 0 0 1 2 2v14H5a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3Z"/><path d="M7 8h10M7 12h10M7 16h6"/>'],
        'idcard' => ['ทำบัตร / ลงทะเบียน', '<rect x="2" y="5" width="20" height="14" rx="2"/><circle cx="8" cy="11" r="2.2"/><path d="M4.8 16.5c.6-1.6 1.8-2.4 3.2-2.4s2.6.8 3.2 2.4M14 10h5M14 13.5h4"/>'],
        'card' => ['ชำระเงิน / สิทธิการรักษา', '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h4"/>'],
        'chat' => ['ปรึกษา / แชท', '<path d="M20 12c0 4-3.6 7-8 7-1.2 0-2.3-.2-3.3-.6L4 20l1.3-3.5C4.5 15.2 4 13.7 4 12c0-4 3.6-7 8-7s8 3 8 7Z"/>'],
        'video' => ['ปรึกษาออนไลน์', '<rect x="2" y="6" width="14" height="12" rx="2"/><path d="m16 10 6-3v10l-6-3"/>'],
        'smile' => ['สุขภาพจิต', '<circle cx="12" cy="12" r="9"/><path d="M8.5 14a4 4 0 0 0 7 0M9 9.5h.01M15 9.5h.01"/>'],
        'star' => ['บริการพิเศษ', '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9L12 3Z"/>'],
    ];
}
function ihub_icon($name) {
    $set = ihub_icon_set();
    $path = $set[$name][1] ?? $set['plus'][1];
    return '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
}
function ihub_icon_names() { return array_keys(ihub_icon_set()); }
function ihub_icon_options() { $o = []; foreach (ihub_icon_set() as $k => $v) $o[] = [$k, $v[0]]; return $o; }
/** Colours for icons (cards, status). */
function ihub_tones() {
    return ['mint' => 'เขียวมิ้นต์', 'teal' => 'เขียวน้ำทะเล', 'green' => 'เขียว', 'sky' => 'ฟ้า', 'blue' => 'น้ำเงิน', 'indigo' => 'คราม', 'lavender' => 'ม่วง', 'pink' => 'ชมพู', 'rose' => 'กุหลาบ', 'red' => 'แดง', 'orange' => 'ส้ม', 'amber' => 'เหลืองทอง'];
}

/* ---------- Dates (YYYY-MM-DD strings, calculated in UTC so a time zone never shifts a day) ---------- */

function ihub_months($lang, $long = false) {
    if ($lang === 'en') return $long ? ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] : ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return $long ? ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'] : ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
}

function ihub_date_parts($date) {
    [$y, $m, $d] = array_map('intval', explode('-', $date));
    return [$y, $m, $d];
}

/** "5 ธ.ค. 2569" / "5 Dec 2026"; with weekday "ส. 5 ธ.ค. 2569" / "Sat, 5 Dec 2026". */
function ihub_format_day($date, $lang = null, $weekday = false) {
    $lang = $lang ?: ihub_lang();
    [$y, $m, $d] = ihub_date_parts($date);
    $text = $d . ' ' . ihub_months($lang)[$m - 1] . ' ' . ($lang === 'en' ? $y : $y + 543);
    if (!$weekday) return $text;
    $short = ihub_t('doctors.daysShort', $lang)[ihub_iso_weekday($date) - 1];
    return $lang === 'en' ? "{$short}, {$text}" : "{$short} {$text}";
}

/** "5 ธ.ค." / "5 Dec" */
function ihub_format_short($date, $lang = null) {
    $lang = $lang ?: ihub_lang();
    [, $m, $d] = ihub_date_parts($date);
    return $d . ' ' . ihub_months($lang)[$m - 1];
}

/** "ธันวาคม 2569" / "December 2026" */
function ihub_format_month($date, $lang = null) {
    $lang = $lang ?: ihub_lang();
    [$y, $m] = ihub_date_parts($date);
    return ihub_months($lang, true)[$m - 1] . ' ' . ($lang === 'en' ? $y : $y + 543);
}

/** Long date for news: "24 ตุลาคม 2569" / "24 October 2026" (Bangkok time). */
function ihub_format_post_date($post = null, $lang = null) {
    $lang = $lang ?: ihub_lang();
    $date = get_post_datetime($post, 'date', 'local');
    if (!$date) return '';
    $date = $date->setTimezone(new DateTimeZone('Asia/Bangkok'));
    $y = (int) $date->format('Y');
    return (int) $date->format('j') . ' ' . ihub_months($lang, true)[(int) $date->format('n') - 1] . ' ' . ($lang === 'en' ? $y : $y + 543);
}

/** "2026-12-05 14:30[:00]" → "5 ธ.ค. 2569 14:30" / "5 Dec 2026 14:30". */
function ihub_format_datetime($value, $lang = null) {
    $value = (string) $value;
    if (!preg_match('/^(\d{4}-\d{2}-\d{2})(?:[ T](\d{2}:\d{2}))?/', $value, $m)) return $value;
    return ihub_format_day($m[1], $lang) . (isset($m[2]) ? ' ' . $m[2] : '');
}

/* ---------- Year in WordPress dates: พ.ศ. on Thai pages, ค.ศ. on English pages ----------
 * Same rule as the iDevApp plugins (whichever loads first does it, once): dates WordPress formats for people
 * ("j F Y", "d/m/Y") show the Buddhist year and Thai month names in Thai; machine formats, REST, feeds, cron and WP-CLI stay ค.ศ.
 */
if (!defined('IDEV_BE_DATES')) {
    define('IDEV_BE_DATES', 1);
    add_filter('wp_date', function ($date, $format, $timestamp, $timezone) {
        static $busy = false;
        if ($busy) return $date;
        $plain = preg_replace('/\\\\./s', '', (string) $format);
        if (!preg_match('/[Yy]/', $plain) || preg_match('/[Yy]-[mn]|[Yy][mn]/', $plain)) return $date;
        if (!preg_match('/[FMlD]/', $plain) && !(preg_match('/[dj]/', $plain) && preg_match('/[mn]/', $plain) && preg_match('#[/. ]#', $plain))) return $date;
        if ((defined('REST_REQUEST') && REST_REQUEST) || (defined('WP_CLI') && WP_CLI) || wp_doing_cron()) return $date;
        if (did_action('wp') && is_feed()) return $date;
        if (!apply_filters('idev_buddhist_year', true)) return $date;
        $lang = function_exists('ihub_lang') ? ihub_lang() : (function_exists('idev_lang') ? idev_lang() : (strpos(determine_locale(), 'th') === 0 ? 'th' : 'en'));
        if ($lang !== 'th') return $date;
        $tz = $timezone instanceof DateTimeZone ? $timezone : wp_timezone();
        $dt = (new DateTimeImmutable('@' . (int) $timestamp))->setTimezone($tz);
        if ($format === 'F j, Y') $format = 'j F Y'; // the English default reads day-first in Thai
        $year = (string) ((int) $dt->format('Y') + 543);
        $mi = (int) $dt->format('n') - 1; $wi = (int) $dt->format('N') - 1;
        $days = ['จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์', 'อาทิตย์']; $dshort = ['จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.', 'อา.'];
        $map = ['Y' => $year, 'y' => substr($year, -2), 'F' => ihub_months('th', true)[$mi], 'M' => ihub_months('th')[$mi], 'l' => 'วัน' . $days[$wi], 'D' => $dshort[$wi]];
        $lit = function ($s) { $o = ''; foreach (preg_split('//u', (string) $s, -1, PREG_SPLIT_NO_EMPTY) as $ch) $o .= '\\' . $ch; return $o; };
        $f = ''; $len = strlen($format);
        for ($i = 0; $i < $len; $i++) {
            $c = $format[$i];
            if ($c === '\\') { $f .= $c . ($format[$i + 1] ?? ''); $i++; continue; }
            $f .= isset($map[$c]) ? $lit($map[$c]) : $c;
        }
        $busy = true;
        $out = wp_date($f, $timestamp, $tz);
        $busy = false;
        return $out === false ? $date : $out;
    }, 10, 4);
}

/* ---------- Links ---------- */

/** Site path ("/news"), http(s), tel:, mailto: or #anchor; anything else becomes empty. */
function ihub_safe_url($url) {
    $url = trim((string) $url);
    if ($url === '') return '';
    if ($url[0] === '/' && substr($url, 0, 2) !== '//' && substr($url, 0, 2) !== '/\\') return $url;
    if (preg_match('/^(tel|mailto):[^\s<>"]+$/i', $url)) return $url;
    if (preg_match('/^#[\w-]+$/', $url)) return $url;
    return preg_match('#^https?://#i', $url) ? esc_url_raw($url) : '';
}

/** Turns a site path into a full URL of this site; other URLs are returned as they are. */
function ihub_href($url) {
    $url = ihub_safe_url($url);
    if ($url !== '' && $url[0] === '/') return home_url($url);
    return $url;
}

function ihub_link($url, $html, $class = '') {
    $href = ihub_href($url);
    if ($href === '') return '';
    $external = preg_match('#^https?://#i', $href) && strpos($href, home_url()) !== 0;
    return '<a' . ($class ? ' class="' . esc_attr($class) . '"' : '') . ' href="' . esc_url($href) . '"' . ($external ? ' target="_blank" rel="noopener noreferrer"' : '') . '>' . $html . '</a>';
}

function ihub_format_bytes($bytes) {
    $bytes = (int) $bytes;
    if ($bytes >= 1048576) return number_format($bytes / 1048576, 1) . ' MB';
    return max(1, (int) round($bytes / 1024)) . ' KB';
}
