<?php
/** "Open now / Closed" from the opening hours (Settings) and holidays that close clinics. */
defined('ABSPATH') || exit;

/** ['state' => open|closed|holiday, 'text' => …] in the current language. */
function ihub_open_status($lang = null) {
    if (ihub_uses('schedule') && function_exists('idev_cs_open_status')) return idev_cs_open_status($lang ?: ihub_lang());
    $lang = $lang ?: ihub_lang();
    $now = new DateTimeImmutable('now', new DateTimeZone('Asia/Bangkok'));
    $today = $now->format('Y-m-d');
    $time = $now->format('H:i');
    $hours = ihub_hours();
    $u = function ($key, $vars = []) use ($lang) {
        $text = ihub_t("ui.{$key}", $lang);
        foreach ($vars as $k => $v) $text = str_replace('{' . $k . '}', $v, $text);
        return $text;
    };
    ihub_ensure_holiday_years([(int) substr($today, 0, 4), (int) substr(ihub_add_days($today, 14), 0, 4)]);
    $holidays = [];
    foreach (ihub_get_holidays($today, ihub_add_days($today, 14)) as $h) if ($h['closes_clinics']) $holidays[$h['holiday_date']] = $h;
    $emergency = ihub_setting('emergency_24h') === 'true' ? ' · ' . $u('emergency24') : '';
    $is_open_day = function ($date) use ($hours, $holidays) { $row = $hours[ihub_iso_weekday($date)]; return !$row['closed'] && !isset($holidays[$date]) && $row['close'] > $row['open']; };
    $next_open = function () use ($today, $hours, $is_open_day, $u, $lang) {
        for ($i = 1; $i <= 14; $i++) {
            $date = ihub_add_days($today, $i);
            if (!$is_open_day($date)) continue;
            $open = $hours[ihub_iso_weekday($date)]['open'];
            return $i === 1 ? $u('opensTomorrow', ['time' => $open]) : $u('opensOn', ['day' => ihub_t('doctors.days', $lang)[ihub_iso_weekday($date) - 1], 'time' => $open]);
        }
        return '';
    };
    if (isset($holidays[$today])) {
        return ['state' => 'holiday', 'text' => $u('holiday') . ' · ' . ihub_pick($holidays[$today]['name'], $holidays[$today]['name_en'], $lang) . $emergency];
    }
    $row = $hours[ihub_iso_weekday($today)];
    if ($is_open_day($today) && $time >= $row['open'] && $time < $row['close']) {
        return ['state' => 'open', 'text' => $u('openNow') . ' · ' . $u('closesAt', ['time' => $row['close']])];
    }
    if ($is_open_day($today) && $time < $row['open']) {
        return ['state' => 'closed', 'text' => $u('closedNow') . ' · ' . $u('opensToday', ['time' => $row['open']]) . $emergency];
    }
    $next = $next_open();
    return ['state' => 'closed', 'text' => $u('closedNow') . ($next ? ' · ' . $next : '') . $emergency];
}

add_shortcode('idevapp_open_status', function () {
    $status = ihub_open_status();
    return '<span class="status-live is-' . esc_attr($status['state']) . '">' . esc_html($status['text']) . '</span>';
});
