<?php
/**
 * Module: ติดตั้ง SSL / HTTPS
 *  1. ดูสถานะใบรับรองที่เว็บใช้อยู่
 *  2. นำเข้าไฟล์ใบรับรอง (.crt / .pem / .cer + .key + CA bundle หรือ .pfx / .p12) → ตรวจว่าคีย์ตรงกัน โดเมนตรง ยังไม่หมดอายุ
 *     จัดเรียง chain ให้ แล้ว: ติดตั้งผ่าน cPanel (UAPI) · บันทึกไว้นอกโฟลเดอร์เว็บ · ดาวน์โหลดชุดไฟล์ที่จัดเรียงแล้ว
 *  3. เปลี่ยนเว็บเป็น HTTPS (ลิงก์ในเนื้อหา + บังคับ redirect) และย้อนกลับได้
 * The private key is never stored in the database and never sent anywhere except the server's own control panel.
 */
defined('ABSPATH') || exit;
if (defined('IDW_SSL_VERSION')) return;
define('IDW_SSL_VERSION', defined('IDW_VERSION') ? IDW_VERSION : '1.0.0');

/* ---------- certificate helpers ---------- */

/** The certificate a host is serving now: ['subject','issuer','san'[],'from','to','fingerprint'] or WP_Error. */
function idw_ssl_remote_cert($host, $port = 443) {
    if (!function_exists('openssl_x509_parse') || !$host) return new WP_Error('idw_ssl', 'เซิร์ฟเวอร์ไม่มี OpenSSL ของ PHP');
    $ctx = stream_context_create(['ssl' => ['capture_peer_cert' => true, 'verify_peer' => false, 'verify_peer_name' => false, 'SNI_enabled' => true, 'peer_name' => $host]]);
    $s = @stream_socket_client('ssl://' . $host . ':' . (int) $port, $errno, $err, 8, STREAM_CLIENT_CONNECT, $ctx); // phpcs:ignore
    if (!$s) return new WP_Error('idw_ssl', 'เชื่อมต่อ ' . $host . ':' . $port . ' ไม่ได้ (' . ($err ?: $errno) . ')');
    $p = stream_context_get_params($s);
    fclose($s);
    $c = $p['options']['ssl']['peer_certificate'] ?? null;
    return $c ? idw_ssl_info($c) : new WP_Error('idw_ssl', 'ไม่ได้รับใบรับรองจากเซิร์ฟเวอร์');
}

function idw_ssl_info($cert) {
    $i = openssl_x509_parse($cert);
    if (!$i) return new WP_Error('idw_ssl', 'อ่านใบรับรองไม่ได้');
    $san = [];
    foreach (explode(',', (string) ($i['extensions']['subjectAltName'] ?? '')) as $n) { $n = trim($n); if (stripos($n, 'DNS:') === 0) $san[] = strtolower(substr($n, 4)); }
    $cn = (string) ($i['subject']['CN'] ?? '');
    if (!$san && $cn) $san[] = strtolower($cn);
    $issuer = (string) ($i['issuer']['O'] ?? $i['issuer']['CN'] ?? '');
    $fp = function_exists('openssl_x509_fingerprint') ? (string) openssl_x509_fingerprint($cert, 'sha256') : '';
    return ['subject' => $cn, 'issuer' => $issuer, 'issuer_cn' => (string) ($i['issuer']['CN'] ?? ''), 'san' => $san, 'from' => (int) $i['validFrom_time_t'], 'to' => (int) $i['validTo_time_t'], 'fingerprint' => $fp, 'self' => ($i['subject'] ?? []) == ($i['issuer'] ?? []), 'ca' => !empty($i['extensions']['basicConstraints']) && stripos($i['extensions']['basicConstraints'], 'CA:TRUE') !== false, 'raw' => $i];
}

/** Does a name list cover a host (wildcards too)? */
function idw_ssl_covers($san, $host) {
    $host = strtolower($host);
    foreach ($san as $n) {
        if ($n === $host) return true;
        if (strpos($n, '*.') === 0 && substr_count($host, '.') >= 2 && substr($host, strpos($host, '.')) === substr($n, 1)) return true;
    }
    return false;
}

/** All PEM certificates in a text (DER is converted). */
function idw_ssl_pems($text) {
    $text = (string) $text;
    if (preg_match_all('/-----BEGIN CERTIFICATE-----.+?-----END CERTIFICATE-----/s', $text, $m)) return array_map('trim', $m[0]);
    if ($text !== '' && strpos($text, '-----BEGIN') === false) { // binary DER
        $pem = "-----BEGIN CERTIFICATE-----\n" . chunk_split(base64_encode($text), 64, "\n") . "-----END CERTIFICATE-----";
        if (@openssl_x509_read($pem)) return [$pem]; // phpcs:ignore
    }
    return [];
}

/**
 * Check and order an uploaded set. $in: cert, key, chain, pfx, pass (raw strings).
 * Returns ['ok' => bool, 'checks' => [[ok|warn|bad, text]], 'cert', 'key', 'chain' (ordered, PEM), 'info'].
 */
function idw_ssl_check($in, $host) {
    $out = ['ok' => false, 'checks' => [], 'cert' => '', 'key' => '', 'chain' => '', 'info' => null];
    $add = function ($s, $t) use (&$out) { $out['checks'][] = [$s, $t]; };
    if (!function_exists('openssl_x509_read')) { $add('bad', 'เซิร์ฟเวอร์ไม่มีส่วนขยาย OpenSSL ของ PHP — ให้ผู้ดูแลเซิร์ฟเวอร์เปิด php-openssl'); return $out; }
    $certs = [];
    $key = '';
    if ($in['pfx'] !== '') {
        $p12 = [];
        if (!openssl_pkcs12_read($in['pfx'], $p12, $in['pass'])) { $add('bad', 'เปิดไฟล์ .pfx / .p12 ไม่ได้ — รหัสผ่านไม่ถูกต้อง หรือไฟล์ใช้การเข้ารหัสแบบเก่าที่ OpenSSL 3 ไม่รองรับ (ลองแปลงเป็น .crt + .key)'); return $out; }
        $certs[] = trim($p12['cert']);
        foreach ((array) ($p12['extracerts'] ?? []) as $x) $certs = array_merge($certs, idw_ssl_pems($x));
        $key = (string) $p12['pkey'];
        $add('ok', 'เปิดไฟล์ PFX สำเร็จ (ใบรับรอง + คีย์' . (count($certs) > 1 ? ' + CA ' . (count($certs) - 1) . ' ใบ' : '') . ')');
    } else {
        $certs = idw_ssl_pems($in['cert']);
        // some CAs put the whole chain in the certificate file
        $certs = array_merge($certs, idw_ssl_pems($in['chain']));
        $key = trim((string) $in['key']);
    }
    if (!$certs) { $add('bad', 'ไม่พบใบรับรองในไฟล์ (ต้องเป็น .crt / .pem / .cer หรือ .pfx)'); return $out; }
    // the leaf = the certificate that matches the key (or the first non-CA one)
    $pkey = $key !== '' ? @openssl_pkey_get_private($key) : false; // phpcs:ignore
    if ($key !== '' && !$pkey) {
        if (strpos($key, 'ENCRYPTED') !== false) $add('bad', 'คีย์ส่วนตัวมีรหัสผ่าน — ถอดรหัสก่อน (openssl rsa -in key.key -out key-nopass.key) หรือใช้ไฟล์ .pfx พร้อมรหัสผ่าน');
        else $add('bad', 'อ่านคีย์ส่วนตัว (private key) ไม่ได้ — ต้องเป็นไฟล์ที่ขึ้นต้นด้วย -----BEGIN PRIVATE KEY----- หรือ -----BEGIN RSA PRIVATE KEY-----');
        return $out;
    }
    $leaf = null;
    foreach ($certs as $i => $c) if ($pkey && openssl_x509_check_private_key($c, $pkey)) { $leaf = $i; break; }
    if ($leaf === null) {
        foreach ($certs as $i => $c) { $inf = idw_ssl_info($c); if (!is_wp_error($inf) && !$inf['ca']) { $leaf = $i; break; } }
        if ($leaf === null) $leaf = 0;
        $add($pkey ? 'bad' : 'warn', $pkey ? 'คีย์ส่วนตัวไม่ตรงกับใบรับรอง — ใช้คีย์ที่สร้างพร้อม CSR ของใบรับรองนี้' : 'ยังไม่ได้ใส่คีย์ส่วนตัว — ติดตั้งไม่ได้จนกว่าจะมีคีย์ (ตรวจได้อย่างเดียว)');
    } else {
        $add('ok', 'คีย์ส่วนตัวตรงกับใบรับรอง');
    }
    $cert = $certs[$leaf];
    $info = idw_ssl_info($cert);
    $out['info'] = is_wp_error($info) ? null : $info;
    if (!$out['info']) { $add('bad', 'อ่านใบรับรองไม่ได้'); return $out; }
    $now = time();
    if ($info['to'] < $now) $add('bad', 'ใบรับรองหมดอายุแล้วเมื่อ ' . wp_date('j M Y', $info['to']));
    elseif ($info['from'] > $now) $add('warn', 'ใบรับรองเริ่มใช้ได้ ' . wp_date('j M Y H:i', $info['from']));
    else $add(($info['to'] - $now) < 21 * DAY_IN_SECONDS ? 'warn' : 'ok', 'ใช้ได้ถึง ' . wp_date('j M Y', $info['to']) . ' (อีก ' . (int) floor(($info['to'] - $now) / DAY_IN_SECONDS) . ' วัน)');
    $www = strpos($host, 'www.') === 0 ? substr($host, 4) : 'www.' . $host;
    if (idw_ssl_covers($info['san'], $host)) $add('ok', 'ครอบคลุมโดเมน ' . $host . (idw_ssl_covers($info['san'], $www) ? ' และ ' . $www : ''));
    else $add('bad', 'ใบรับรองออกให้ ' . implode(', ', array_slice($info['san'], 0, 5)) . ' — ไม่ตรงกับโดเมนของเว็บ ' . $host);
    if ($info['self']) $add('warn', 'เป็นใบรับรองที่ออกเอง (self-signed) เบราว์เซอร์จะเตือนว่าไม่ปลอดภัย');
    // order the chain: leaf → intermediate → … (root left out)
    $rest = array_values(array_diff_key($certs, [$leaf => 1]));
    $chain = [];
    $cur = $info;
    for ($n = 0; $n < 6; $n++) {
        $found = false;
        foreach ($rest as $k => $c) {
            $ci = idw_ssl_info($c);
            if (is_wp_error($ci)) continue;
            if (($ci['raw']['subject'] ?? null) == ($cur['raw']['issuer'] ?? [])) {
                if (!$ci['self']) $chain[] = $c;
                unset($rest[$k]);
                $cur = $ci;
                $found = true;
                break;
            }
        }
        if (!$found) break;
    }
    if (!$info['self']) {
        if ($chain) $add('ok', 'จัดเรียงใบรับรองตัวกลาง (CA bundle) แล้ว ' . count($chain) . ' ใบ');
        elseif (!$cur['self']) $add('warn', 'ไม่มีใบรับรองตัวกลาง (CA bundle) — มือถือบางรุ่นจะขึ้นเตือน ให้ดาวน์โหลด CA bundle จากผู้ออกใบรับรอง (' . $info['issuer'] . ')');
    }
    if ($pkey) {
        $d = openssl_pkey_get_details($pkey);
        $bits = (int) ($d['bits'] ?? 0);
        if ($d['type'] === OPENSSL_KEYTYPE_RSA && $bits < 2048) $add('bad', 'คีย์ RSA ขนาด ' . $bits . ' บิต สั้นเกินไป (ต้อง 2048 ขึ้นไป)');
        openssl_pkey_export($pkey, $key_pem);
        $out['key'] = trim($key_pem);
    }
    $out['cert'] = trim($cert);
    $out['chain'] = implode("\n", array_map('trim', $chain));
    $out['ok'] = !array_filter($out['checks'], function ($c) { return $c[0] === 'bad'; });
    return $out;
}

/* ---------- reading the upload ---------- */

function idw_ssl_upload_text($field, $paste) {
    $t = '';
    if (!empty($_FILES[$field]['tmp_name']) && is_uploaded_file($_FILES[$field]['tmp_name']) && (int) $_FILES[$field]['size'] < 200000) $t = (string) file_get_contents($_FILES[$field]['tmp_name']); // phpcs:ignore
    if ($t === '' && isset($_POST[$paste])) $t = trim(wp_unslash($_POST[$paste])); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- certificate text, checked by OpenSSL
    return $t;
}

/** Store only what is public (certificate, chain, result) for the page; the key never. */
function idw_ssl_set_result($r) {
    set_transient('idw_ssl_res_' . get_current_user_id(), $r, 30 * MINUTE_IN_SECONDS);
}

add_action('admin_post_idw_ssl_import', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_ssl_import')) wp_die('ไม่มีสิทธิ์', 403);
    $host = (string) wp_parse_url(home_url(), PHP_URL_HOST);
    $in = ['cert' => idw_ssl_upload_text('cert_file', 'cert_text'), 'key' => idw_ssl_upload_text('key_file', 'key_text'), 'chain' => idw_ssl_upload_text('chain_file', 'chain_text'), 'pfx' => '', 'pass' => (string) wp_unslash($_POST['pfx_pass'] ?? '')]; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
    if (!empty($_FILES['pfx_file']['tmp_name']) && is_uploaded_file($_FILES['pfx_file']['tmp_name'])) $in['pfx'] = (string) file_get_contents($_FILES['pfx_file']['tmp_name']); // phpcs:ignore
    $r = idw_ssl_check($in, $host);
    $do = sanitize_key($_POST['do'] ?? 'check');
    $msg = [];
    if ($r['ok'] && $r['key'] !== '') {
        if ($do === 'cpanel') {
            $res = idw_ssl_cpanel_install($r, $host, [
                'host' => sanitize_text_field(wp_unslash($_POST['cp_host'] ?? '')), 'port' => (int) ($_POST['cp_port'] ?? 2083),
                'user' => sanitize_user(wp_unslash($_POST['cp_user'] ?? '')), 'token' => preg_replace('/[^A-Za-z0-9]/', '', (string) wp_unslash($_POST['cp_token'] ?? '')), 'verify' => empty($_POST['cp_insecure']),
            ]);
            $msg[] = is_wp_error($res) ? ['bad', 'ติดตั้งผ่าน cPanel ไม่สำเร็จ: ' . $res->get_error_message()] : ['ok', $res];
        } elseif ($do === 'save') {
            $res = idw_ssl_save_files($r, $host);
            $msg[] = is_wp_error($res) ? ['bad', $res->get_error_message()] : ['ok', $res];
        } elseif ($do === 'download') {
            idw_ssl_download($r, $host); // exits
        }
    } elseif ($do !== 'check') {
        $msg[] = ['bad', 'ยังติดตั้งไม่ได้ — แก้ข้อที่ไม่ผ่านด้านล่างก่อน'];
    }
    $r['key'] = $r['key'] !== '' ? '1' : ''; // keep only "there was a key"
    unset($r['info']['raw']);
    $r['msg'] = $msg;
    $r['do'] = $do;
    idw_ssl_set_result($r);
    wp_safe_redirect(admin_url('admin.php?page=idw-ssl&tab=import&res=1'));
    exit;
});

/* cPanel UAPI SSL::install_ssl — the token is used once and not stored */
function idw_ssl_cpanel_install($r, $domain, $cp) {
    if ($cp['user'] === '' || $cp['token'] === '') return new WP_Error('idw_ssl', 'ใส่ชื่อผู้ใช้ cPanel และ API Token');
    $h = $cp['host'] !== '' ? preg_replace('#^https?://#', '', $cp['host']) : $domain;
    $h = preg_replace('#[:/].*$#', '', $h);
    $res = wp_remote_post('https://' . $h . ':' . ($cp['port'] ?: 2083) . '/execute/SSL/install_ssl', [
        'timeout' => 45, 'sslverify' => $cp['verify'],
        'headers' => ['Authorization' => 'cpanel ' . $cp['user'] . ':' . $cp['token']],
        'body' => ['domain' => $domain, 'cert' => $r['cert'], 'key' => $r['key'], 'cabundle' => $r['chain']],
    ]);
    if (is_wp_error($res)) return new WP_Error('idw_ssl', $res->get_error_message() . ($cp['verify'] ? ' (ถ้าใบรับรองของ cPanel เองไม่ถูกต้อง ให้ติ๊ก “ไม่ตรวจใบรับรองของ cPanel”)' : ''));
    $code = (int) wp_remote_retrieve_response_code($res);
    $j = json_decode((string) wp_remote_retrieve_body($res), true);
    if ($code === 401 || $code === 403) return new WP_Error('idw_ssl', 'cPanel ไม่ยอมรับชื่อผู้ใช้ / API Token (HTTP ' . $code . ')');
    if (!is_array($j)) return new WP_Error('idw_ssl', 'cPanel ตอบกลับไม่ถูกต้อง (HTTP ' . $code . ')');
    if (empty($j['status'])) return new WP_Error('idw_ssl', implode(' ', array_map('wp_strip_all_tags', (array) ($j['errors'] ?? ['ไม่ทราบสาเหตุ']))));
    if (function_exists('idw_sec_log')) idw_sec_log('setting', 'ติดตั้ง SSL ผ่าน cPanel: ' . $domain);
    return 'ติดตั้งใบรับรองบน cPanel สำเร็จ' . (!empty($j['messages']) ? ' — ' . wp_strip_all_tags(implode(' ', (array) $j['messages'])) : '') . ' · ต่อไปกด “เปลี่ยนเว็บเป็น HTTPS”';
}

/* Save next to (not inside) the web folder, readable only by the owner */
function idw_ssl_dir() { return trailingslashit(dirname(untrailingslashit(ABSPATH))) . 'idw-ssl'; }
function idw_ssl_save_files($r, $host) {
    $dir = idw_ssl_dir();
    if (!wp_mkdir_p($dir) || !wp_is_writable($dir)) return new WP_Error('idw_ssl', 'สร้างโฟลเดอร์ ' . $dir . ' ไม่ได้ (นอกโฟลเดอร์เว็บ) — ใช้ “ดาวน์โหลดชุดไฟล์” แทน');
    $base = $dir . '/' . sanitize_file_name($host);
    $files = [$base . '.crt' => $r['cert'] . "\n", $base . '.ca-bundle' => $r['chain'] . "\n", $base . '.fullchain.pem' => trim($r['cert'] . "\n" . $r['chain']) . "\n", $base . '.key' => $r['key'] . "\n"];
    foreach ($files as $f => $c) { if (file_put_contents($f, $c) === false) return new WP_Error('idw_ssl', 'เขียนไฟล์ไม่ได้: ' . $f); @chmod($f, 0600); } // phpcs:ignore
    @file_put_contents($dir . '/.htaccess', "Require all denied\n"); // phpcs:ignore
    update_option('idw_ssl_saved', ['dir' => $dir, 'host' => $host, 'to' => (int) (idw_ssl_info($r['cert'])['to'] ?? 0), 't' => time()], false);
    return 'บันทึกไฟล์ไว้ที่ ' . $dir . ' แล้ว (สิทธิ์ 0600) — ดูตัวอย่างการตั้งค่า Apache / Nginx ด้านล่าง';
}

function idw_ssl_download($r, $host) {
    if (!class_exists('ZipArchive')) wp_die('เซิร์ฟเวอร์ไม่มี ZipArchive');
    $tmp = wp_tempnam('ssl.zip');
    $z = new ZipArchive();
    $z->open($tmp, ZipArchive::OVERWRITE);
    $n = sanitize_file_name($host);
    $z->addFromString($n . '.crt', $r['cert'] . "\n");
    $z->addFromString($n . '.ca-bundle', $r['chain'] . "\n");
    $z->addFromString($n . '.fullchain.pem', trim($r['cert'] . "\n" . $r['chain']) . "\n");
    $z->addFromString($n . '.key', $r['key'] . "\n");
    $z->addFromString('README.txt', "ไฟล์ใบรับรองสำหรับ {$host} (จัดเรียงโดย iDevApp Website)\n\n{$n}.crt            ใบรับรอง\n{$n}.ca-bundle      ใบรับรองตัวกลาง (CA bundle)\n{$n}.fullchain.pem  ใบรับรอง + CA bundle (Nginx ssl_certificate)\n{$n}.key            คีย์ส่วนตัว — เก็บเป็นความลับ ห้ามส่งทางอีเมล / แชต\n");
    $z->close();
    nocache_headers();
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="ssl-' . $n . '.zip"');
    header('Content-Length: ' . filesize($tmp));
    readfile($tmp); // phpcs:ignore
    @unlink($tmp); // phpcs:ignore
    exit;
}

/* ---------- switch the website to HTTPS ---------- */

function idw_ssl_https_ready($host) {
    $r = wp_remote_get('https://' . $host . '/', ['timeout' => 10, 'redirection' => 3, 'sslverify' => true]);
    return is_wp_error($r) ? $r : true;
}

/** Replace http://host with https://host in posts and post meta. Returns rows changed. */
function idw_ssl_replace_links($from, $to) {
    global $wpdb;
    $n = (int) $wpdb->query($wpdb->prepare("UPDATE {$wpdb->posts} SET post_content = REPLACE(post_content, %s, %s) WHERE post_content LIKE %s", $from, $to, '%' . $wpdb->esc_like($from) . '%')); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    // serialized meta must not be touched with REPLACE (lengths change): only plain values
    $rows = $wpdb->get_results($wpdb->prepare("SELECT meta_id, meta_value FROM {$wpdb->postmeta} WHERE meta_value LIKE %s LIMIT 5000", '%' . $wpdb->esc_like($from) . '%')); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    foreach ($rows as $row) {
        if (is_serialized($row->meta_value)) continue;
        $wpdb->update($wpdb->postmeta, ['meta_value' => str_replace($from, $to, $row->meta_value)], ['meta_id' => $row->meta_id]); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $n++;
    }
    clean_post_cache(0);
    wp_cache_flush();
    return $n;
}

add_action('admin_post_idw_ssl_https', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_ssl_https')) wp_die('ไม่มีสิทธิ์', 403);
    $host = (string) wp_parse_url(home_url(), PHP_URL_HOST);
    $on = ($_POST['to'] ?? '') === 'https';
    if ($on) {
        $ok = idw_ssl_https_ready($host);
        if (is_wp_error($ok) && empty($_POST['force'])) {
            set_transient('idw_ssl_msg_' . get_current_user_id(), '!ยังเปิด https://' . $host . ' ไม่ได้หรือใบรับรองไม่ถูกต้อง (' . $ok->get_error_message() . ') — ติดตั้งใบรับรองให้เรียบร้อยก่อน เพื่อไม่ให้เข้าเว็บไม่ได้', 120);
            wp_safe_redirect(admin_url('admin.php?page=idw-ssl'));
            exit;
        }
        foreach (['home', 'siteurl'] as $o) update_option($o, preg_replace('#^http://#', 'https://', get_option($o)));
        $n = !empty($_POST['links']) ? idw_ssl_replace_links('http://' . $host, 'https://' . $host) : 0;
        update_option('idw_ssl_force', !empty($_POST['redirect']) ? '1' : '0');
        if (function_exists('idw_sec_log')) idw_sec_log('setting', 'เปลี่ยนเว็บเป็น HTTPS');
        $msg = 'เปลี่ยนเว็บเป็น HTTPS แล้ว' . ($n ? ' · แก้ลิงก์ในเนื้อหา ' . $n . ' รายการ' : '') . ' — อาจต้องล็อกอินใหม่';
        set_transient('idw_ssl_msg_' . get_current_user_id(), $msg, 120);
        wp_safe_redirect(set_url_scheme(admin_url('admin.php?page=idw-ssl'), 'https'));
        exit;
    }
    foreach (['home', 'siteurl'] as $o) update_option($o, preg_replace('#^https://#', 'http://', get_option($o)));
    update_option('idw_ssl_force', '0');
    if (!empty($_POST['links'])) idw_ssl_replace_links('https://' . $host, 'http://' . $host);
    set_transient('idw_ssl_msg_' . get_current_user_id(), 'กลับไปใช้ HTTP แล้ว', 120);
    wp_safe_redirect(set_url_scheme(admin_url('admin.php?page=idw-ssl'), 'http'));
    exit;
});

/* force HTTPS */
add_action('template_redirect', 'idw_ssl_force_redirect', 0);
add_action('admin_init', 'idw_ssl_force_redirect', 0);
add_action('login_init', 'idw_ssl_force_redirect', 0);
function idw_ssl_force_redirect() {
    if (is_ssl() || get_option('idw_ssl_force') !== '1' || strpos(home_url(), 'https://') !== 0 || wp_doing_cron() || (defined('WP_CLI') && WP_CLI) || wp_doing_ajax()) return;
    $uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
    wp_safe_redirect('https://' . wp_parse_url(home_url(), PHP_URL_HOST) . $uri, 301);
    exit;
}
/* links that are still http:// in content / widgets → https:// on output */
add_filter('the_content', 'idw_ssl_fix_output', 99);
add_filter('widget_text', 'idw_ssl_fix_output', 99);
function idw_ssl_fix_output($html) {
    if (!is_ssl() || get_option('idw_ssl_force') !== '1') return $html;
    $host = wp_parse_url(home_url(), PHP_URL_HOST);
    return str_replace(['http://' . $host, 'http:\/\/' . $host], ['https://' . $host, 'https:\/\/' . $host], $html);
}

/* ---------- page ---------- */

add_action('admin_menu', function () {
    add_submenu_page('idevapp', 'ติดตั้ง SSL / HTTPS', 'SSL / HTTPS', 'manage_options', 'idw-ssl', 'idw_ssl_page');
}, 21);
add_action('admin_enqueue_scripts', function () {
    if (($_GET['page'] ?? '') !== 'idw-ssl') return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    wp_enqueue_style('idw-admin');
    wp_enqueue_script('idw-admin');
    wp_add_inline_style('idw-admin', '.ssl-st{display:flex;gap:18px;align-items:center}.ssl-st .big{width:64px;height:64px;border-radius:18px;display:grid;place-items:center;flex:none}.ssl-st .big svg{width:32px;height:32px}.ssl-st.ok .big{background:#dcfce7;color:#16a34a}.ssl-st.bad .big{background:#fee2e2;color:#dc2626}.ssl-st.warn .big{background:#fef3c7;color:#d97706}.ssl-st h3{margin:0 0 4px;font-size:18px}.ssl-st p{margin:0;color:#64748b}.ssl-kv{display:grid;grid-template-columns:150px 1fr;gap:6px 14px;margin-top:14px;font-size:13.5px}.ssl-kv b{color:#334155}.ssl-kv code{word-break:break-all}.ssl-ways{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;margin:6px 0 14px}.ssl-way{border:2px solid #e2e8f0;border-radius:14px;padding:12px 14px;cursor:pointer;display:flex;gap:10px}.ssl-way:has(input:checked){border-color:#0f766e;background:#f3fbfa}.ssl-way b{display:block}.ssl-way small{color:#64748b}.ssl-files{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px}.ssl-drop{border:2px dashed #cbd5e1;border-radius:14px;padding:12px;display:flex;flex-direction:column;gap:6px}.ssl-drop textarea{font-family:monospace;font-size:11px;min-height:70px}.ssl-checks{list-style:none;margin:0;padding:0}.ssl-checks li{display:flex;gap:10px;padding:8px 0;border-bottom:1px solid #f1f5f9}.ssl-checks .i{width:22px;height:22px;border-radius:50%;display:grid;place-items:center;color:#fff;font-size:12px;font-weight:700;flex:none}.ssl-checks .ok .i{background:#16a34a}.ssl-checks .warn .i{background:#d97706}.ssl-checks .bad .i{background:#dc2626}.ssl-cp[hidden],.ssl-pfx[hidden],.ssl-pem[hidden]{display:none!important}pre.ssl-conf{background:#0f172a;color:#e2e8f0;border-radius:12px;padding:14px;overflow:auto;font-size:12.5px}');
    wp_add_inline_script('idw-admin', 'jQuery(function($){function s(){var w=$("input[name=do]:checked").val();$(".ssl-cp").prop("hidden",w!=="cpanel");var p=$("input[name=fmt]:checked").val();$(".ssl-pfx").prop("hidden",p!=="pfx");$(".ssl-pem").prop("hidden",p==="pfx");}$(document).on("change","input[name=do],input[name=fmt]",s);s();$(".ssl-drop input[type=file]").on("change",function(){var f=this.files[0],t=$(this).closest(".ssl-drop").find("textarea");if(!f||!t.length||f.size>200000)return;if(/\\.(pfx|p12|der)$/i.test(f.name))return;var r=new FileReader();r.onload=function(){if(/-----BEGIN/.test(r.result))t.val(r.result);};r.readAsText(f);});});');
});

function idw_ssl_page() {
    if (!current_user_can('manage_options')) wp_die('ไม่มีสิทธิ์');
    $host = (string) wp_parse_url(home_url(), PHP_URL_HOST);
    idw_open('ติดตั้ง SSL / HTTPS', 'นำเข้าไฟล์ใบรับรองที่ซื้อหรือได้รับมา ระบบจะตรวจ จัดเรียง และช่วยติดตั้ง แล้วเปลี่ยนทั้งเว็บเป็น HTTPS ให้ในคลิกเดียว');
    $msg = get_transient('idw_ssl_msg_' . get_current_user_id());
    if ($msg) { delete_transient('idw_ssl_msg_' . get_current_user_id()); idw_note(esc_html(ltrim($msg, '!')), strpos($msg, '!') === 0 ? 'err' : ''); }
    $https = strpos(home_url(), 'https://') === 0;
    $cert = idw_ssl_remote_cert($host);
    // 1. status
    if (is_wp_error($cert)) { $st = 'warn'; $title = 'ยังไม่พบใบรับรองบนเซิร์ฟเวอร์'; $sub = $cert->get_error_message(); }
    else {
        $days = (int) floor(($cert['to'] - time()) / DAY_IN_SECONDS);
        $match = idw_ssl_covers($cert['san'], $host);
        if (!$match) { $st = 'bad'; $title = 'ใบรับรองไม่ตรงกับโดเมน ' . $host; }
        elseif ($days < 0) { $st = 'bad'; $title = 'ใบรับรองหมดอายุแล้ว'; }
        elseif ($cert['self']) { $st = 'warn'; $title = 'ใบรับรองออกเอง (self-signed)'; }
        elseif ($days < 21) { $st = 'warn'; $title = 'ใบรับรองจะหมดอายุใน ' . $days . ' วัน'; }
        else { $st = 'ok'; $title = 'ใบรับรองใช้งานได้ อีก ' . $days . ' วัน'; }
        $sub = $https ? 'เว็บใช้ HTTPS แล้ว' : 'ใบรับรองพร้อม แต่เว็บยังใช้ http:// — กด “เปลี่ยนเว็บเป็น HTTPS” ด้านล่าง';
    }
    echo '<div class="idw-cols"><div><div class="idw-card"><div class="ssl-st ' . esc_attr($st) . '"><span class="big">' . idw_icon('lock') . '</span><div><h3>' . esc_html($title) . '</h3><p>' . esc_html($sub) . '</p></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if (!is_wp_error($cert)) echo '<div class="ssl-kv"><b>โดเมน</b><span>' . esc_html(implode(', ', array_slice($cert['san'], 0, 6))) . '</span><b>ออกโดย</b><span>' . esc_html(trim($cert['issuer'] . ' · ' . $cert['issuer_cn'], ' ·')) . '</span><b>ใช้ได้</b><span>' . esc_html(idw_dt($cert['from'], false) . ' – ' . idw_dt($cert['to'], false)) . '</span><b>SHA-256</b><code>' . esc_html(strtoupper(implode(':', str_split($cert['fingerprint'], 2)))) . '</code></div>';
    echo '</div>';
    idw_ssl_import_form($host);
    echo '</div><div>';
    // 3. HTTPS switch
    echo '<div class="idw-card"><h2>' . idw_icon('globe') . ($https ? 'เว็บใช้ HTTPS แล้ว' : 'เปลี่ยนเว็บเป็น HTTPS') . '</h2><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" data-busy="กำลังเปลี่ยน…">' . wp_nonce_field('idw_ssl_https', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_ssl_https">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if (!$https) {
        echo '<p class="d">ตรวจว่า https://' . esc_html($host) . ' เปิดได้และใบรับรองถูกต้องก่อนเปลี่ยน (กันเข้าเว็บไม่ได้)</p><input type="hidden" name="to" value="https"><div class="idw-opts"><label class="idw-opt"><input type="checkbox" name="links" value="1" checked><span><b>แก้ลิงก์ในเนื้อหา</b><small>http://' . esc_html($host) . ' → https://</small></span></label><label class="idw-opt"><input type="checkbox" name="redirect" value="1" checked><span><b>บังคับใช้ HTTPS</b><small>คนที่เข้า http:// จะถูกพาไป https:// อัตโนมัติ</small></span></label></div><p><button class="idw-btn pri" style="width:100%">' . idw_icon('lock') . 'เปลี่ยนเว็บเป็น HTTPS</button></p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    } else {
        echo '<p class="d">' . (get_option('idw_ssl_force') === '1' ? 'บังคับใช้ HTTPS อยู่' : 'ยังไม่บังคับ redirect จาก http://') . ' · ลิงก์ http:// ที่เหลือในเนื้อหาจะถูกแปลงเป็น https:// ตอนแสดงผล</p><input type="hidden" name="to" value="http"><label class="idw-opt"><input type="checkbox" name="links" value="1"><span><b>เปลี่ยนลิงก์ในเนื้อหากลับเป็น http://</b><small>ใช้เมื่อใบรับรองมีปัญหาและต้องย้อนกลับชั่วคราว</small></span></label><p><button class="idw-btn sm" onclick="return confirm(\'กลับไปใช้ HTTP?\')">กลับไปใช้ HTTP</button></p>';
    }
    echo '</form></div>';
    // snippets
    $saved = get_option('idw_ssl_saved');
    $dir = is_array($saved) ? $saved['dir'] : '/path/to/ssl';
    $n = sanitize_file_name($host);
    echo '<div class="idw-card"><h2>' . idw_icon('book') . 'ตั้งค่าเว็บเซิร์ฟเวอร์เอง</h2><p class="d">ถ้าไม่มี cPanel ให้ผู้ดูแลเซิร์ฟเวอร์ใช้ไฟล์ที่บันทึก / ดาวน์โหลดไว้</p><b>Apache</b><pre class="ssl-conf">SSLEngine on' . "\n" . 'SSLCertificateFile ' . esc_html($dir . '/' . $n) . '.crt' . "\n" . 'SSLCertificateKeyFile ' . esc_html($dir . '/' . $n) . '.key' . "\n" . 'SSLCertificateChainFile ' . esc_html($dir . '/' . $n) . '.ca-bundle</pre><b>Nginx</b><pre class="ssl-conf">ssl_certificate     ' . esc_html($dir . '/' . $n) . '.fullchain.pem;' . "\n" . 'ssl_certificate_key ' . esc_html($dir . '/' . $n) . '.key;' . "\n" . 'ssl_protocols TLSv1.2 TLSv1.3;</pre><p class="d" style="margin:0">Plesk / DirectAdmin / aaPanel: เมนู SSL ของโดเมน → วางเนื้อหาไฟล์ .crt .key และ .ca-bundle</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div></div>';
    idw_close();
}

function idw_ssl_import_form($host) {
    $res = get_transient('idw_ssl_res_' . get_current_user_id());
    if ($res && isset($_GET['res'])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        delete_transient('idw_ssl_res_' . get_current_user_id());
        echo '<div class="idw-card"><h2>' . idw_icon($res['ok'] ? 'check' : 'shield') . 'ผลการตรวจไฟล์ใบรับรอง</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        foreach ((array) $res['msg'] as [$s, $t]) idw_note(esc_html($t), $s === 'bad' ? 'err' : '');
        echo '<ul class="ssl-checks">';
        foreach ($res['checks'] as [$s, $t]) echo '<li class="' . esc_attr($s) . '"><span class="i">' . ($s === 'ok' ? '✓' : ($s === 'warn' ? '!' : '✕')) . '</span><span>' . esc_html($t) . '</span></li>';
        echo '</ul>';
        if (!empty($res['info'])) echo '<div class="ssl-kv"><b>ออกให้</b><span>' . esc_html(implode(', ', array_slice($res['info']['san'], 0, 6))) . '</span><b>ผู้ออก</b><span>' . esc_html($res['info']['issuer']) . '</span></div>';
        echo '</div>';
    }
    echo '<form method="post" enctype="multipart/form-data" action="' . esc_url(admin_url('admin-post.php')) . '" class="idw-card" data-busy="กำลังตรวจ…">' . wp_nonce_field('idw_ssl_import', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_ssl_import">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<h2>' . idw_icon('upload') . 'นำเข้าไฟล์ใบรับรอง</h2><p class="d">สำหรับโดเมน <b>' . esc_html($host) . '</b> · ไฟล์ถูกตรวจบนเซิร์ฟเวอร์ของคุณ คีย์ส่วนตัวไม่ถูกเก็บในฐานข้อมูล</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div class="ssl-ways"><label class="ssl-way"><input type="radio" name="fmt" value="pem" checked><span><b>ไฟล์แยก</b><small>.crt / .pem / .cer + .key + CA bundle</small></span></label><label class="ssl-way"><input type="radio" name="fmt" value="pfx"><span><b>ไฟล์เดียว .pfx / .p12</b><small>จาก Windows / IIS พร้อมรหัสผ่าน</small></span></label></div>';
    echo '<div class="ssl-files ssl-pem">';
    foreach ([['cert', 'ใบรับรอง (Certificate)', '.crt,.pem,.cer,.der', '-----BEGIN CERTIFICATE-----'], ['key', 'คีย์ส่วนตัว (Private key)', '.key,.pem', '-----BEGIN PRIVATE KEY-----'], ['chain', 'CA bundle / Intermediate (ถ้ามี)', '.crt,.pem,.ca-bundle,.cer', '-----BEGIN CERTIFICATE-----']] as [$k, $l, $acc, $ph]) {
        echo '<div class="ssl-drop"><b>' . esc_html($l) . '</b><input type="file" name="' . esc_attr($k) . '_file" accept="' . esc_attr($acc) . '"><small>หรือวางข้อความ</small><textarea name="' . esc_attr($k) . '_text" placeholder="' . esc_attr($ph) . '" class="idw-in" autocomplete="off" spellcheck="false"></textarea></div>';
    }
    echo '</div><div class="ssl-pfx idw-form" hidden><label class="idw-field">ไฟล์ .pfx / .p12<input type="file" name="pfx_file" accept=".pfx,.p12"></label><label class="idw-field">รหัสผ่านไฟล์<input type="password" name="pfx_pass" autocomplete="new-password"></label></div>';
    echo '<h3 style="margin:18px 0 8px">ทำอะไรต่อ</h3><div class="ssl-ways">';
    foreach ([['check', 'ตรวจอย่างเดียว', 'ดูว่าไฟล์ครบ ถูกต้อง ตรงโดเมน'], ['cpanel', 'ติดตั้งผ่าน cPanel', 'ใช้ API Token ของ cPanel (ใช้ครั้งเดียว ไม่บันทึก)'], ['save', 'บันทึกไว้บนเซิร์ฟเวอร์', 'โฟลเดอร์ idw-ssl นอกโฟลเดอร์เว็บ สำหรับตั้งค่า Apache / Nginx'], ['download', 'ดาวน์โหลดชุดไฟล์', 'zip ที่จัดเรียงแล้ว (.crt .ca-bundle fullchain .key)']] as $i => [$v, $t, $d]) {
        echo '<label class="ssl-way"><input type="radio" name="do" value="' . esc_attr($v) . '"' . checked($i, 0, false) . '><span><b>' . esc_html($t) . '</b><small>' . esc_html($d) . '</small></span></label>';
    }
    echo '</div><div class="ssl-cp idw-form" hidden><label class="idw-field">ที่อยู่ cPanel <small>เว้นว่าง = ' . esc_html($host) . '</small><input type="text" name="cp_host" placeholder="' . esc_attr($host) . '"></label><label class="idw-field">พอร์ต<input type="text" name="cp_port" value="2083"></label><label class="idw-field">ชื่อผู้ใช้ cPanel<input type="text" name="cp_user" autocomplete="off"></label><label class="idw-field">API Token <small>cPanel → Security → Manage API Tokens</small><input type="password" name="cp_token" autocomplete="new-password"></label><label class="full"><input type="checkbox" name="cp_insecure" value="1"> ไม่ตรวจใบรับรองของหน้า cPanel (ใช้เมื่อ cPanel ใช้ใบรับรองชั่วคราว)</label></div>';
    echo '<div class="idw-actions"><span class="sp"></span><button class="idw-btn pri lg">' . idw_icon('check') . 'ตรวจและดำเนินการ</button></div></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
