/* บล็อก “บริการทางการแพทย์” — การ์ดแก้ที่หน้า บริการทางการแพทย์ ในหลังบ้าน แถบขวาปรับการแสดงผลของบล็อกนี้ */
( function ( wp ) {
	var el = wp.element.createElement, be = wp.blockEditor, c = wp.components, SSR = wp.serverSideRender;
	var E = window.IDW_SVC_EDITOR || {}, admin = E.admin || 'admin.php?page=idw-services', sets = E.sets || [];
	wp.blocks.registerBlockType( 'idw/services', {
		apiVersion: 2,
		title: 'การ์ดบริการ',
		description: 'ชุดการ์ด (บริการทางการแพทย์ ลิงก์ด่วน ช่องทางติดต่อ …) — แก้การ์ดได้ที่เมนู การ์ดบริการ',
		category: 'widgets',
		icon: 'screenoptions',
		keywords: [ 'services', 'cards', 'บริการ', 'การ์ด', 'คลินิก', 'ลิงก์ด่วน', 'ติดต่อ' ],
		supports: { align: [ 'wide', 'full' ], html: false },
		attributes: {
			set: { type: 'string', default: '' },
			anchor: { type: 'string', default: '' },
			columns: { type: 'number', default: 0 },
			limit: { type: 'number', default: 0 },
			head: { type: 'boolean', default: true },
			bg: { type: 'string', default: '' },
			align: { type: 'string', default: 'wide' }
		},
		edit: function ( p ) {
			var a = p.attributes, set = p.setAttributes;
			return el( 'div', be.useBlockProps(),
				el( be.InspectorControls, null,
					el( c.PanelBody, { title: 'ชุดการ์ด', initialOpen: true },
						el( c.SelectControl, { label: 'แสดงชุด', value: a.set, options: [ { label: 'ชุดหลัก (บริการทางการแพทย์)', value: '' } ].concat( sets.map( function ( s ) { return { label: s.name + ' (' + s.n + ' การ์ด)', value: s.id }; } ) ), onChange: function ( v ) { set( { set: v } ); } } ),
						el( 'p', null, 'ไอคอน รูป สี ข้อความ และลิงก์ของการ์ดแก้ได้ที่เมนู การ์ดบริการ — ทุกหน้าที่ใช้ชุดเดียวกันเปลี่ยนตามพร้อมกัน' ),
						el( c.Button, { variant: 'primary', href: admin + ( a.set ? '&set=' + encodeURIComponent( a.set ) : '' ), target: '_blank' }, 'แก้ไขชุดนี้ ↗' )
					),
					el( c.PanelBody, { title: 'การแสดงผลในหน้านี้', initialOpen: true },
						el( c.ToggleControl, { label: 'แสดงหัวข้อ', checked: a.head, onChange: function ( v ) { set( { head: v } ); } } ),
						el( c.RangeControl, { label: 'จำนวนคอลัมน์ (0 = ตามที่ตั้งไว้)', min: 0, max: 6, value: a.columns, onChange: function ( v ) { set( { columns: v || 0 } ); } } ),
						el( c.RangeControl, { label: 'แสดงไม่เกิน (0 = ทั้งหมด)', min: 0, max: 24, value: a.limit, onChange: function ( v ) { set( { limit: v || 0 } ); } } ),
						el( c.SelectControl, { label: 'พื้นหลัง', value: a.bg, options: [ { label: 'ตามที่ตั้งไว้', value: '' }, { label: 'เทาอ่อน', value: 'light' }, { label: 'ขาว', value: 'white' }, { label: 'โปร่งใส', value: 'none' }, { label: 'สีหลักของเว็บ', value: 'brand' } ], onChange: function ( v ) { set( { bg: v } ); } } ),
						el( c.TextControl, { label: 'ชื่อจุดเชื่อมโยง (anchor) เช่น services', value: a.anchor, onChange: function ( v ) { set( { anchor: v.replace( /[^A-Za-z0-9_-]/g, '' ) } ); } } )
					)
				),
				el( c.Disabled, null, el( SSR, { block: 'idw/services', attributes: a } ) )
			);
		},
		save: function () { return null; }
	} );
} )( window.wp );
