<?php
/** หลังบ้าน: เมนู “การ์ดบริการ” — ชุดการ์ดหลายชุด แก้ไข ดูตัวอย่างสด สร้าง / ทำสำเนา / ลบชุด แปลงการ์ดของ Hub */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_menu_page( 'การ์ดบริการ', 'การ์ดบริการ', 'edit_pages', 'idw-services', 'idw_svc_page', 'dashicons-screenoptions', 22 );
} );
add_action( 'load-toplevel_page_idw-services', function () {
	global $title;
	$title = 'การ์ดบริการ'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- the program-mode menu may hide this item
} );

/** the set as the editor shows it: a schedule-based set lists its clinic cards */
function idw_svc_admin_set( $set ) {
	if ( 'clinics' === ( $set['source'] ?? '' ) ) {
		$set['items'] = array_values( idw_svc_clinic_items( $set ) );
	}
	return $set;
}

function idw_svc_current_id() {
	$id = sanitize_key( $_GET['set'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	return ( $id && idw_svc_get( $id ) ) ? $id : idw_svc_get( '' )['id'];
}

add_action( 'admin_enqueue_scripts', function () {
	if ( 'idw-services' !== ( $_GET['page'] ?? '' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	wp_enqueue_media();
	$deps = wp_style_is( 'idw-admin', 'registered' ) ? array( 'idw-admin', 'idw-services' ) : array( 'idw-services' );
	wp_enqueue_style( 'idw-services-admin', IDW_SVC_URL . 'assets/admin.css', $deps, IDW_SVC_VER );
	wp_enqueue_script( 'idw-services-admin', IDW_SVC_URL . 'assets/admin.js', array( 'jquery', 'jquery-ui-sortable' ), IDW_SVC_VER, true );
	$icons = array();
	foreach ( idw_svc_icon_set() as $k => $v ) {
		$icons[ $k ] = array( $v[0], $v[1] );
	}
	$id = idw_svc_current_id();
	$t  = idw_svc_templates();
	wp_localize_script( 'idw-services-admin', 'IDW_SVC', array(
		'data'     => idw_svc_admin_set( idw_svc_get( $id ) ),
		'cgroups'  => idw_svc_clinic_groups(),
		'defaults' => isset( $t[ $id ] ) ? idw_svc_from_template( $id, $id ) : null,
		'icons'    => $icons,
		'tones'    => idw_svc_tones(),
		'opts'     => idw_svc_options(),
		'ajax'     => admin_url( 'admin-ajax.php' ),
		'nonce'    => wp_create_nonce( 'idw_svc_preview' ),
		'home'     => home_url( '/' ),
	) );
} );

function idw_svc_check( $action ) {
	if ( ! current_user_can( 'edit_pages' ) || ! check_admin_referer( $action ) ) {
		wp_die( 'ไม่มีสิทธิ์', 403 );
	}
}
function idw_svc_back( $args ) {
	wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php?page=idw-services' ) ) );
	exit;
}

/* live preview: the same renderer as the site */
add_action( 'wp_ajax_idw_svc_preview', function () {
	if ( ! current_user_can( 'edit_pages' ) || ! check_ajax_referer( 'idw_svc_preview', 'nonce', false ) ) {
		wp_send_json_error( null, 403 );
	}
	$d = json_decode( wp_unslash( $_POST['data'] ?? '' ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- idw_svc_clean() sanitises every field
	if ( ! is_array( $d ) ) {
		wp_send_json_error();
	}
	$lang = 'en' === ( $_POST['lang'] ?? '' ) ? 'en' : 'th';
	$clean = idw_svc_clean( $d );
	$items = 'clinics' === $clean['source'] ? array_values( idw_svc_clinic_items( $clean ) ) : null; // the editor list follows the schedule
	$links = array();
	foreach ( (array) ( $items ? $items : ( $d['items'] ?? array() ) ) as $i => $it ) {
		$links[ $i ] = idw_svc_resolve( (string) ( $it['url'] ?? '' ) );
	}
	$more = idw_svc_resolve( (string) ( $d['more']['url'] ?? '' ) );
	wp_send_json_success( array( 'html' => idw_svc_render( array( 'lang' => $lang, 'align' => '', 'anchor' => 'svc-pv' ), $d ), 'links' => $links, 'more' => $more, 'items' => $items ) );
} );

add_action( 'admin_post_idw_svc_save', function () {
	idw_svc_check( 'idw_svc_save' );
	$d  = json_decode( wp_unslash( $_POST['data'] ?? '' ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- idw_svc_clean() sanitises every field
	$id = sanitize_key( $_POST['set'] ?? '' );
	if ( ! is_array( $d ) || ! $id ) {
		idw_svc_back( array( 'err' => 1 ) );
	}
	$d['id'] = $id;
	idw_svc_put( $d );
	$r = ! empty( $_POST['add_home'] ) ? idw_svc_add_to_home( $id ) : '';
	idw_svc_back( array( 'set' => $id, 'saved' => 1, 'home' => $r ) );
} );

add_action( 'admin_post_idw_svc_new', function () {
	idw_svc_check( 'idw_svc_new' );
	$tpl  = sanitize_key( $_POST['tpl'] ?? 'blank' );
	$name = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
	$src  = sanitize_key( $_POST['from'] ?? '' );
	if ( $src && idw_svc_get( $src ) ) {
		$set         = idw_svc_get( $src );
		$set['name'] = $name ? $name : $set['name'] . ' (สำเนา)';
	} else {
		$set = idw_svc_from_template( $tpl, 'x' );
		if ( $name ) {
			$set['name'] = $name;
		}
	}
	$set['id'] = idw_svc_new_id( $src ? $src : ( 'blank' === $tpl ? 'cards' : $tpl ) );
	$set       = idw_svc_put( $set );
	idw_svc_back( array( 'set' => $set['id'], 'created' => 1 ) );
} );

/** “match the clinics”: the services set follows the schedule (without SMC) and SMC gets its own set and section */
function idw_svc_clinic_banner( $sets ) {
	if ( ! idw_svc_has_clinics() || ! idw_svc_clinic_list() ) {
		return;
	}
	$svc = null;
	foreach ( $sets as $x ) {
		if ( 'services' === $x['id'] ) {
			$svc = $x;
		}
	}
	if ( ! $svc || 'clinics' === $svc['source'] ) {
		return;
	}
	$cg  = idw_svc_clinic_groups();
	$smc = array_sum( array_intersect_key( $cg, array_flip( array_filter( array_keys( $cg ), 'idw_svc_is_smc' ) ) ) );
	$all = array_sum( $cg );
	echo '<form class="idw-card svc-banner" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'idw_svc_clinic_setup' );
	echo '<input type="hidden" name="action" value="idw_svc_clinic_setup"><span class="dashicons dashicons-calendar-alt"></span><div><b>ตารางออกตรวจมี ' . (int) $all . ' คลินิก แต่การ์ด “' . esc_html( $svc['name'] ) . '” มี ' . (int) count( $svc['items'] ) . ' ใบที่กรอกเอง</b><span>ให้การ์ดตรงกับคลินิก (1 ใบต่อ 1 คลินิก ลิงก์ไปตารางของคลินิกนั้น อัปเดตเองเมื่อแก้ตารางออกตรวจ)' . ( $smc ? ' และแยกคลินิกพิเศษนอกเวลา (SMC) ' . (int) $smc . ' คลินิกเป็นอีกส่วนต่อจากบริการ' : '' ) . ' — การ์ดเดิมเก็บไว้เป็นชุด “บริการ (แบบเดิม)” ย้อนกลับได้</span></div><button class="idw-btn pri">ทำให้ตรงกับคลินิก</button></form>';
}
add_action( 'admin_post_idw_svc_clinic_setup', function () {
	idw_svc_check( 'idw_svc_clinic_setup' );
	$svc = idw_svc_get( 'services' );
	if ( $svc && 'clinics' !== $svc['source'] ) {
		$old         = $svc;
		$old['id']   = idw_svc_new_id( 'services-old' );
		$old['name'] = 'บริการ (แบบเดิม)';
		idw_svc_put( $old );
		$svc['source']  = 'clinics';
		$svc['exclude'] = array( '@smc' );
		$svc['groups']  = array();
		$svc['items']   = array();
		if ( empty( $svc['more']['url'] ) ) {
			$svc['more'] = array( 'url' => '{schedule}', 'label' => idw_svc_t2( 'ดูตารางออกตรวจทั้งหมด', 'Full clinic schedule' ) );
		}
		idw_svc_put( $svc );
	}
	$has_smc = (bool) array_filter( array_keys( idw_svc_clinic_groups() ), 'idw_svc_is_smc' );
	$r       = '';
	if ( $has_smc ) {
		if ( ! idw_svc_get( 'smc' ) ) {
			idw_svc_put( idw_svc_from_template( 'smc', 'smc' ) );
		}
		$r = idw_svc_add_to_home( 'smc' );
	}
	idw_svc_back( array( 'set' => 'services', 'saved' => 1, 'clinics' => 1, 'home' => $r ) );
} );

add_action( 'admin_post_idw_svc_delete', function () {
	idw_svc_check( 'idw_svc_delete' );
	$id   = sanitize_key( $_POST['set'] ?? '' );
	$sets = array_values( array_filter( idw_svc_sets(), function ( $s ) use ( $id ) {
		return $s['id'] !== $id;
	} ) );
	if ( $sets ) {
		idw_svc_store( $sets );
	}
	idw_svc_back( array( 'deleted' => 1 ) );
} );

add_action( 'admin_post_idw_svc_order', function () {
	idw_svc_check( 'idw_svc_order' );
	$order = array_map( 'sanitize_key', explode( ',', sanitize_text_field( wp_unslash( $_POST['order'] ?? '' ) ) ) );
	$sets  = idw_svc_sets();
	usort( $sets, function ( $a, $b ) use ( $order ) {
		return (int) array_search( $a['id'], $order, true ) - (int) array_search( $b['id'], $order, true );
	} );
	idw_svc_store( $sets );
	idw_svc_back( array( 'set' => sanitize_key( $_POST['set'] ?? '' ) ) );
} );

/** ชุดนี้ถูกใช้ในหน้าไหนบ้าง */
function idw_svc_used_in( $id ) {
	$out = array();
	foreach ( get_posts( array( 'post_type' => array( 'page', 'post' ), 'post_status' => array( 'publish', 'draft', 'private', 'future' ), 'numberposts' => 300, 's' => 'wp:idw/services', 'search_columns' => array( 'post_content' ) ) ) as $p ) {
		$found = false;
		$walk  = function ( $blocks ) use ( &$walk, &$found, $id ) {
			foreach ( $blocks as $b ) {
				$s = (string) ( $b['attrs']['set'] ?? '' );
				if ( 'idw/services' === $b['blockName'] && ( $s === $id || ( '' === $s && idw_svc_get( '' )['id'] === $id ) ) ) {
					$found = true;
				}
				$walk( $b['innerBlocks'] );
			}
		};
		$walk( parse_blocks( $p->post_content ) );
		if ( $found || preg_match( '/\[idw_(services|cards)[^\]]*set=["\']?' . preg_quote( $id, '/' ) . '\b/', $p->post_content ) ) {
			$out[] = $p;
		}
	}
	return $out;
}

function idw_svc_page() {
	$id   = idw_svc_current_id();
	$set  = idw_svc_get( $id );
	$sets = idw_svc_sets();
	$own  = function_exists( 'idw_open' );
	$q    = function ( $k ) {
		return sanitize_key( $_GET[ $k ] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	};
	if ( $own ) {
		idw_open( 'การ์ดบริการ', 'สร้างการ์ดได้หลายชุด — บริการทางการแพทย์ ลิงก์ด่วน ช่องทางติดต่อ หรือชุดอื่น ๆ ใส่ไอคอนหรือรูป ข้อความไทย / อังกฤษ และลิงก์ ใช้ได้กับทุกธีม' );
	} else {
		echo '<div class="wrap idw"><div class="idw-body"><h1>การ์ดบริการ</h1>';
	}
	$msg = array( 'added' => ' และใส่ลงหน้าแรกแล้ว', 'exists' => ' (หน้าแรกมีชุดนี้อยู่แล้ว)', 'nopage' => ' — แต่ยังไม่ได้ตั้งหน้าแรกเป็นหน้าเว็บ (การตั้งค่า → การอ่าน)' );
	if ( $q( 'saved' ) ) {
		echo '<div class="idw-note">บันทึกแล้ว' . esc_html( $msg[ $q( 'home' ) ] ?? '' ) . ' <a href="' . esc_url( home_url( '/' ) ) . '" target="_blank" rel="noopener">ดูหน้าเว็บ ↗</a></div>';
	} elseif ( $q( 'created' ) ) {
		echo '<div class="idw-note">สร้างชุด “' . esc_html( $set['name'] ) . '” แล้ว — แก้การ์ดด้านล่าง แล้วกดบันทึก</div>';
	} elseif ( $q( 'deleted' ) ) {
		echo '<div class="idw-note">ลบชุดการ์ดแล้ว</div>';
	} elseif ( '1' === $q( 'conv' ) ) {
		echo '<div class="idw-note">แปลงการ์ดของ Hub เป็นชุด “' . esc_html( $set['name'] ) . '” แล้ว หน้าเว็บนั้นใช้ชุดนี้แทนบล็อกเดิม</div>';
	}

	idw_svc_clinic_banner( $sets );

	/* set tabs */
	echo '<div class="svc-sets" id="svc-sets" data-order-nonce="' . esc_attr( wp_create_nonce( 'idw_svc_order' ) ) . '">';
	foreach ( $sets as $s ) {
		echo '<a class="svc-set' . ( $s['id'] === $id ? ' on' : '' ) . '" data-id="' . esc_attr( $s['id'] ) . '" href="' . esc_url( admin_url( 'admin.php?page=idw-services&set=' . rawurlencode( $s['id'] ) ) ) . '"><b>' . esc_html( $s['name'] ) . '</b><small>' . count( $s['items'] ) . ' การ์ด</small></a>';
	}
	echo '<button type="button" class="svc-set add" id="svc-new-btn"><span class="dashicons dashicons-plus-alt2"></span>สร้างชุดใหม่</button></div>';

	/* new set panel */
	echo '<form class="idw-card svc-new" id="svc-new" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" hidden>';
	wp_nonce_field( 'idw_svc_new' );
	echo '<input type="hidden" name="action" value="idw_svc_new"><h2>สร้างชุดการ์ดใหม่</h2><div class="svc-tpls">';
	$first = true;
	foreach ( idw_svc_templates() as $k => $t ) {
		echo '<label class="svc-tpl"><input type="radio" name="tpl" value="' . esc_attr( $k ) . '"' . checked( $first, true, false ) . '><span><b>' . esc_html( $t[0] ) . '</b><small>' . esc_html( $t[1] ) . '</small></span></label>';
		$first = false;
	}
	echo '</div><div class="svc-new-row"><label class="idw-field">ชื่อชุด (เห็นเฉพาะในหลังบ้าน)<input class="idw-in" name="name" placeholder="เช่น คลินิกพิเศษ, ศูนย์ความเป็นเลิศ"></label><button class="idw-btn pri">สร้างชุด</button><button type="button" class="idw-btn" id="svc-new-cancel">ยกเลิก</button></div></form>';

	/* editor */
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" id="svc-form">';
	wp_nonce_field( 'idw_svc_save' );
	echo '<input type="hidden" name="action" value="idw_svc_save"><input type="hidden" name="set" value="' . esc_attr( $id ) . '"><input type="hidden" name="data" id="svc-data">';

	echo '<div class="svc-top"><div class="idw-card svc-head"><div class="svc-name-row"><label class="idw-field">ชื่อชุด<input class="idw-in" data-o="name"></label>';
	echo '<div class="svc-code"><span>รหัสย่อ</span><code id="svc-code">[idw_services set="' . esc_html( $id ) . '"]</code><button type="button" class="svc-mini" id="svc-copy" title="คัดลอก"><span class="dashicons dashicons-admin-page"></span></button></div></div>';
	echo '<h2>หัวข้อส่วน</h2><div class="svc-lang-row">';
	foreach ( array( 'th' => 'ภาษาไทย', 'en' => 'English' ) as $l => $ln ) {
		echo '<div class="svc-lang"><span class="svc-lang-tag">' . esc_html( $ln ) . '</span>';
		echo '<label class="idw-field">ข้อความเล็กด้านบน<input class="idw-in" data-h="kicker" data-l="' . esc_attr( $l ) . '"></label>';
		echo '<label class="idw-field">หัวข้อ<input class="idw-in" data-h="title" data-l="' . esc_attr( $l ) . '"></label>';
		echo '<label class="idw-field">คำอธิบาย (ไม่บังคับ)<textarea class="idw-in" rows="2" data-h="lead" data-l="' . esc_attr( $l ) . '"></textarea></label></div>';
	}
	echo '</div><details class="svc-more-d"><summary>ปุ่ม “ดูทั้งหมด” ใต้การ์ด (ไม่บังคับ)</summary><div class="svc-3col"><label class="idw-field">ลิงก์<input class="idw-in" data-m="url" list="svc-pages" placeholder="/services/"></label><label class="idw-field">ข้อความปุ่ม (ไทย)<input class="idw-in" data-m="label" data-l="th" placeholder="ดูบริการทั้งหมด"></label><label class="idw-field">Button text (English)<input class="idw-in" data-m="label" data-l="en" placeholder="All services"></label></div></details></div>';

	if ( idw_svc_has_clinics() ) {
		$cg = idw_svc_clinic_groups();
		echo '<div class="idw-card svc-src"><h2>ที่มาของการ์ด</h2><div class="svc-seg" data-o="source"><button type="button" data-v="manual">กรอกเอง</button><button type="button" data-v="clinics">ดึงจากตารางออกตรวจ (' . (int) array_sum( $cg ) . ' คลินิก)</button></div>';
		echo '<div class="svc-src-clinics" id="svc-src-clinics"><p>การ์ด 1 ใบต่อ 1 คลินิก ชื่อ วัน-เวลา และลิงก์ไปตารางของคลินิกนั้นตามตารางออกตรวจเสมอ — เพิ่ม / ลบคลินิกที่ <a href="' . esc_url( admin_url( 'edit.php?post_type=idev_provider' ) ) . '">ตารางออกตรวจ</a> การ์ดเปลี่ยนตาม · แก้ไอคอน สี รูป ข้อความรายการ์ดได้</p><div class="svc-groups">';
		echo '<span class="svc-lbl">หมวดที่แสดง <small>(ไม่เลือก = ทุกหมวด)</small></span>';
		foreach ( $cg as $g => $n ) {
			echo '<label class="svc-gchk"><input type="checkbox" data-group="' . esc_attr( $g ) . '"> ' . esc_html( $g ) . ' <small>' . (int) $n . '</small>' . ( idw_svc_is_smc( $g ) ? ' <b class="svc-smc">SMC</b>' : '' ) . '</label>';
		}
		echo '<label class="svc-gchk svc-nosmc"><input type="checkbox" data-nosmc> ไม่รวมคลินิกพิเศษนอกเวลา (SMC) — แยกไปอีกชุด</label><label class="svc-gchk svc-onlysmc"><input type="checkbox" data-onlysmc> เฉพาะคลินิกพิเศษนอกเวลา (SMC)</label></div></div></div>';
	}
	echo '<div class="idw-card svc-side"><h2>รูปแบบ</h2>';
	echo '<label class="idw-field">จำนวนคอลัมน์ (จอคอมพิวเตอร์)<select class="idw-in" data-o="columns">';
	for ( $c = 1; $c <= 6; $c++ ) {
		echo '<option value="' . (int) $c . '">' . (int) $c . '</option>';
	}
	echo '</select><small>แท็บเล็ตไม่เกิน 3 · มือถือ 1–2 คอลัมน์อัตโนมัติ</small></label>';
	$labels = array( 'layout' => 'การจัดวาง', 'card' => 'กรอบการ์ด', 'style' => 'ไอคอน', 'size' => 'ขนาดไอคอน', 'bg' => 'พื้นหลังส่วน', 'ratio' => 'สัดส่วนรูปบนการ์ด', 'fit' => 'การแสดงรูป', 'tsize' => 'ขนาดตัวอักษร', 'radius' => 'มุมการ์ด' );
	foreach ( idw_svc_options() as $k => $vals ) {
		if ( 'ratio' === $k ) {
			echo '<h3 class="svc-sub">รูปในการ์ด</h3>';
		}
		if ( 'tsize' === $k ) {
			echo '<h3 class="svc-sub">ตัวอักษรและการ์ด</h3>';
		}
		echo '<div class="idw-field">' . esc_html( $labels[ $k ] ) . '<div class="svc-seg" data-o="' . esc_attr( $k ) . '">';
		foreach ( $vals as $v => $n ) {
			echo '<button type="button" data-v="' . esc_attr( $v ) . '">' . esc_html( $n ) . '</button>';
		}
		echo '</div></div>';
	}
	echo '<h3 class="svc-sub">สี <small>เว้นว่าง = ตามธีม</small></h3><div class="svc-colors">';
	foreach ( idw_svc_color_keys() as $k => $n ) {
		echo '<label class="svc-color"><span>' . esc_html( $n ) . '</span><span class="svc-color-in"><input type="color" data-c="' . esc_attr( $k ) . '"><button type="button" class="svc-mini" data-c-clear="' . esc_attr( $k ) . '" title="ใช้สีตามธีม"><span class="dashicons dashicons-image-rotate"></span></button></span></label>';
	}
	echo '</div>';
	$pid     = (int) get_option( 'page_on_front' );
	$on_home = false;
	if ( 'page' === get_option( 'show_on_front' ) && $pid ) {
		foreach ( idw_svc_used_in( $id ) as $p ) {
			$on_home = $on_home || $p->ID === $pid;
		}
	}
	$used = idw_svc_used_in( $id );
	echo '<div class="svc-use"><b>ใช้ชุดนี้บนหน้าเว็บ</b><span>ในตัวแก้ไขหน้า กด + แล้วค้นหา “การ์ดบริการ” เลือกชุดนี้ในแถบขวา หรือวางรหัสย่อด้านบน</span>';
	if ( $used ) {
		echo '<span class="svc-ok"><span class="dashicons dashicons-yes-alt"></span>ใช้อยู่ใน: ';
		$links = array();
		foreach ( array_slice( $used, 0, 6 ) as $p ) {
			$links[] = '<a href="' . esc_url( get_edit_post_link( $p ) ) . '">' . esc_html( get_the_title( $p ) ? get_the_title( $p ) : '(ไม่มีชื่อ)' ) . '</a>';
		}
		echo wp_kses_post( implode( ', ', $links ) ) . '</span>';
	}
	if ( ! $on_home ) {
		echo '<label class="svc-check"><input type="checkbox" name="add_home" value="1"> ใส่ลงหน้าแรกเมื่อบันทึก</label>';
	}
	echo '</div></div></div>';

	echo '<div class="svc-bar"><h2>การ์ด <small id="svc-count"></small></h2><span class="svc-hint"><span class="dashicons dashicons-move"></span>ลากเพื่อเรียงลำดับ</span>';
	echo '<button type="button" class="idw-btn" id="svc-expand">เปิด / ปิดทั้งหมด</button>';
	if ( isset( idw_svc_templates()[ $id ] ) ) {
		echo '<button type="button" class="idw-btn" id="svc-reset">คืนค่าเริ่มต้น</button>';
	}
	echo '<button type="button" class="idw-btn acc" id="svc-add"><span class="dashicons dashicons-plus-alt2"></span>เพิ่มการ์ด</button></div>';
	echo '<div class="svc-main"><div class="svc-list" id="svc-list"></div>';
	echo '<div class="svc-pv-wrap"><div class="svc-pv-head"><b>ตัวอย่าง</b><div class="svc-seg sm" id="svc-pv-size"><button type="button" data-v="desk" class="on">คอม</button><button type="button" data-v="tab">แท็บเล็ต</button><button type="button" data-v="phone">มือถือ</button></div><div class="svc-seg sm" id="svc-pv-lang"><button type="button" data-v="th" class="on">ไทย</button><button type="button" data-v="en">EN</button></div></div><div class="svc-pv" id="svc-pv"></div></div></div>';
	echo '<datalist id="svc-pages"><option value="/">หน้าแรก</option><option value="tel:1669">โทร 1669</option>';
	foreach ( get_pages( array( 'sort_column' => 'menu_order,post_title', 'number' => 200 ) ) as $p ) {
		echo '<option value="' . esc_attr( wp_make_link_relative( get_permalink( $p ) ) ) . '">' . esc_html( $p->post_title ) . '</option>';
	}
	echo '</datalist>';
	echo '<div class="svc-pop" id="svc-pop" hidden><input type="search" placeholder="ค้นหาไอคอน…" id="svc-pop-q"><div class="svc-pop-grid" id="svc-pop-grid"></div></div>';
	echo '<div class="idw-savebar"><span class="msg" id="svc-msg">ยังไม่มีการแก้ไข</span><a class="idw-btn link" href="' . esc_url( home_url( '/' ) ) . '" target="_blank" rel="noopener">ดูหน้าเว็บ ↗</a><button class="idw-btn pri" id="svc-save"><span class="dashicons dashicons-yes"></span>บันทึก</button></div></form>';

	/* set actions */
	echo '<div class="svc-foot"><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'idw_svc_new' );
	echo '<input type="hidden" name="action" value="idw_svc_new"><input type="hidden" name="from" value="' . esc_attr( $id ) . '"><button class="idw-btn"><span class="dashicons dashicons-admin-page"></span>ทำสำเนาชุดนี้</button></form>';
	if ( count( $sets ) > 1 ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" id="svc-del-form" data-used="' . count( $used ) . '">';
		wp_nonce_field( 'idw_svc_delete' );
		echo '<input type="hidden" name="action" value="idw_svc_delete"><input type="hidden" name="set" value="' . esc_attr( $id ) . '"><button class="idw-btn danger"><span class="dashicons dashicons-trash"></span>ลบชุดนี้</button></form>';
	}
	echo '</div>';

	/* Hub cards on this site */
	$hub = idw_svc_find_hub_cards();
	if ( $hub ) {
		echo '<div class="idw-card svc-hub"><h2>การ์ดบริการของ Hub ในเว็บนี้ <small>' . count( $hub ) . ' บล็อก</small></h2><p>บล็อกเหล่านี้ยังใช้ได้ตามเดิม — กด “แปลง” เพื่อย้ายมาแก้ที่หน้านี้ (ไอคอน รูป ข้อความ และลิงก์มาครบ) หน้าเว็บนั้นจะใช้ชุดการ์ดใหม่แทนบล็อกเดิม</p><div class="svc-hub-list">';
		foreach ( $hub as $h ) {
			list( $p, $path, $attrs ) = $h;
			$d     = (array) ( $attrs['data'] ?? array() );
			$title = is_array( $d['title'] ?? null ) ? ( $d['title']['th'] ?? '' ) : '';
			$imgs  = count( array_filter( (array) ( $d['items'] ?? array() ), function ( $i ) {
				return ! empty( $i['image'] );
			} ) );
			echo '<form class="svc-hub-row" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'idw_svc_convert' );
			echo '<input type="hidden" name="action" value="idw_svc_convert"><input type="hidden" name="post" value="' . (int) $p->ID . '"><input type="hidden" name="path" value="' . esc_attr( implode( '.', $path ) ) . '">';
			echo '<span><b>' . esc_html( $title ? $title : '(ไม่มีหัวข้อ)' ) . '</b><small>หน้า “' . esc_html( get_the_title( $p ) ) . '” · ' . count( (array) ( $d['items'] ?? array() ) ) . ' การ์ด' . ( $imgs ? ' · มีรูป ' . (int) $imgs : '' ) . '</small></span>';
			echo '<a class="idw-btn link" href="' . esc_url( get_edit_post_link( $p ) ) . '">เปิดหน้า</a><button class="idw-btn">แปลงเป็นชุดการ์ด</button></form>';
		}
		echo '</div></div>';
	}
	if ( $own ) {
		idw_close();
	} else {
		echo '</div></div>';
	}
}
