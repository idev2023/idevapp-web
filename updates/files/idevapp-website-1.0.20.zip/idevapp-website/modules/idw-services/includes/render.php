<?php
/** หน้าเว็บ: บล็อก idw/services · รหัสย่อ [idw_services] / [idw_cards] · ใส่ลงหน้าแรก */
defined( 'ABSPATH' ) || exit;

function idw_svc_lang() {
	if ( function_exists( 'idev_lang' ) ) {
		return idev_lang();
	}
	return 0 === strpos( determine_locale(), 'th' ) ? 'th' : 'en';
}
/** ข้อความตามภาษา (ภาษาอังกฤษว่างใช้ภาษาไทย) */
function idw_svc_t( $v, $lang = null ) {
	$lang = $lang ? $lang : idw_svc_lang();
	$v    = (array) $v;
	return 'en' === $lang && '' !== trim( (string) ( $v['en'] ?? '' ) ) ? $v['en'] : (string) ( $v['th'] ?? '' );
}
function idw_svc_icon( $name ) {
	$set = idw_svc_icon_set();
	return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . ( $set[ $name ][1] ?? $set['plus'][1] ) . '</svg>';
}
function idw_svc_href( $u ) {
	return idw_svc_resolve( $u )[0];
}
function idw_svc_external( $u ) {
	if ( 0 !== strpos( $u, 'http' ) ) {
		return false;
	}
	return wp_parse_url( $u, PHP_URL_HOST ) !== wp_parse_url( home_url(), PHP_URL_HOST );
}

add_action( 'init', function () {
	wp_register_style( 'idw-services', IDW_SVC_URL . 'assets/services.css', array(), IDW_SVC_VER );
	wp_register_script( 'idw-services-block', IDW_SVC_URL . 'assets/block.js', array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render' ), IDW_SVC_VER, true );
	register_block_type( 'idw/services', array(
		'api_version'     => 2,
		'title'           => 'การ์ดบริการ',
		'category'        => 'widgets',
		'icon'            => 'screenoptions',
		'editor_script'   => 'idw-services-block',
		'style'           => 'idw-services',
		'attributes'      => array(
			'set'       => array( 'type' => 'string', 'default' => '' ),
			'columns'   => array( 'type' => 'number', 'default' => 0 ),
			'limit'     => array( 'type' => 'number', 'default' => 0 ),
			'head'      => array( 'type' => 'boolean', 'default' => true ),
			'bg'        => array( 'type' => 'string', 'default' => '' ),
			'align'     => array( 'type' => 'string', 'default' => 'wide' ),
			'anchor'    => array( 'type' => 'string', 'default' => '' ),
			'className' => array( 'type' => 'string', 'default' => '' ),
		),
		'supports'        => array( 'align' => array( 'wide', 'full' ), 'html' => false ),
		'render_callback' => 'idw_svc_render',
	) );
	$sc = function ( $a ) {
		$a         = shortcode_atts( array( 'set' => '', 'columns' => 0, 'limit' => 0, 'head' => '1', 'bg' => '', 'title' => '', 'align' => 'wide', 'id' => '' ), $a, 'idw_services' );
		$a['head'] = ! in_array( strtolower( (string) $a['head'] ), array( '0', 'no', 'false' ), true );
		$a['anchor'] = $a['id'];
		return idw_svc_render( $a );
	};
	add_shortcode( 'idw_services', $sc );
	add_shortcode( 'idw_cards', $sc );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_add_inline_script( 'idw-services-block', 'window.IDW_SVC_EDITOR=' . wp_json_encode( array( 'admin' => admin_url( 'admin.php?page=idw-services' ), 'sets' => idw_svc_set_list() ) ) . ';', 'before' );
} );

/**
 * การ์ด · $a: set (id ของชุด), columns (0 = ตามชุด), limit, head, bg, title (แทนหัวข้อ), align, anchor, className
 * $set: ส่งข้อมูลชุดมาเอง (ตัวอย่างในหลังบ้าน)
 */
function idw_svc_render( $a = array(), $set = null ) {
	$a = wp_parse_args( (array) $a, array( 'set' => '', 'columns' => 0, 'limit' => 0, 'head' => true, 'bg' => '', 'title' => '', 'align' => 'wide', 'anchor' => '', 'className' => '', 'lang' => '' ) );
	$d = $set ? idw_svc_clean( $set ) : idw_svc_get( sanitize_key( (string) $a['set'] ) );
	if ( ! $d ) {
		return current_user_can( 'edit_posts' ) ? '<p class="idw-svc-empty">ไม่พบชุดการ์ด “' . esc_html( $a['set'] ) . '” — ดูชื่อชุดได้ที่เมนู การ์ดบริการ</p>' : '';
	}
	$lang = in_array( $a['lang'], array( 'th', 'en' ), true ) ? $a['lang'] : idw_svc_lang();
	$cols = (int) $a['columns'] ? max( 1, min( 6, (int) $a['columns'] ) ) : $d['columns'];
	$bg   = isset( idw_svc_options()['bg'][ $a['bg'] ] ) ? $a['bg'] : $d['bg'];
	$src  = 'clinics' === $d['source'] ? idw_svc_clinic_items( $d ) : $d['items'];
	$all  = array_values( array_filter( $src, function ( $i ) {
		return $i['on'] && '' !== trim( $i['title']['th'] . $i['title']['en'] . $i['image'] );
	} ) );
	if ( (int) $a['limit'] > 0 ) {
		$all = array_slice( $all, 0, (int) $a['limit'] );
	}
	if ( ! $all ) {
		return current_user_can( 'edit_posts' ) ? '<p class="idw-svc-empty">ชุด “' . esc_html( $d['name'] ) . '” ยังไม่มีการ์ดที่แสดง — เพิ่มได้ที่เมนู การ์ดบริการ</p>' : '';
	}
	wp_enqueue_style( 'idw-services' );
	$tones = idw_svc_tones();
	$cls   = 'idw-svc idw-svc--' . $d['style'] . ' idw-svc--l-' . $d['layout'] . ' idw-svc--c-' . $d['card'] . ' idw-svc--i-' . $d['size'] . ' idw-svc--bg-' . $bg . ' idw-svc--set-' . $d['id'];
	if ( in_array( $a['align'], array( 'wide', 'full' ), true ) ) {
		$cls .= ' align' . $a['align'];
	}
	if ( $a['className'] ) {
		$cls .= ' ' . implode( ' ', array_map( 'sanitize_html_class', preg_split( '/\s+/', (string) $a['className'] ) ) );
	}
	$anchor = sanitize_html_class( (string) $a['anchor'] );
	if ( ! $anchor && 'services' === $d['id'] ) {
		$anchor = 'services';
	}
	$cls  .= ' idw-svc--t-' . $d['tsize'] . ' idw-svc--fit-' . $d['fit'];
	$vars  = '--idw-svc-cols:' . (int) $cols . ';--idw-svc-r:' . (int) $d['radius'] . 'px;--idw-svc-ratio:' . ( 'auto' === $d['ratio'] ? 'auto' : $d['ratio'] );
	foreach ( $d['colors'] as $k => $c ) {
		if ( $c ) {
			$vars .= ';--idw-c-' . $k . ':' . $c;
		}
	}
	$h = '<section class="' . esc_attr( $cls ) . '"' . ( $anchor ? ' id="' . esc_attr( $anchor ) . '"' : '' ) . ' style="' . esc_attr( $vars ) . '"><div class="idw-svc__in">';
	if ( $a['head'] ) {
		$title = '' !== (string) $a['title'] ? (string) $a['title'] : idw_svc_t( $d['title'], $lang );
		$kick  = idw_svc_t( $d['kicker'], $lang );
		$lead  = idw_svc_t( $d['lead'], $lang );
		if ( $title || $kick ) {
			$h .= '<header class="idw-svc__head">' . ( $kick ? '<span class="idw-svc__kicker">' . esc_html( $kick ) . '</span>' : '' ) . ( $title ? '<h2 class="idw-svc__title">' . esc_html( $title ) . '</h2>' : '' ) . ( $lead ? '<p class="idw-svc__lead">' . esc_html( $lead ) . '</p>' : '' ) . '</header>';
		}
	}
	$h .= '<div class="idw-svc__grid">';
	foreach ( $all as $i ) {
		$h .= idw_svc_card( $i, $tones, $lang );
	}
	$h .= '</div>';
	$more = idw_svc_t( $d['more']['label'], $lang );
	if ( $d['more']['url'] && $more ) {
		$u  = idw_svc_href( $d['more']['url'] );
		$h .= '<div class="idw-svc__foot"><a class="idw-svc__btn" href="' . esc_url( $u ) . '"' . ( idw_svc_external( $u ) ? ' target="_blank" rel="noopener"' : '' ) . '>' . esc_html( $more ) . ' <span aria-hidden="true">→</span></a></div>';
	}
	return $h . '</div></section>';
}

function idw_svc_card( $i, $tones, $lang ) {
	$i = wp_parse_args( (array) $i, array( 'icon' => 'plus', 'tone' => 'mint', 'color' => '', 'image' => '', 'imageId' => 0, 'imageMode' => 'cover', 'pos' => 'center', 'title' => array(), 'text' => array(), 'url' => '', 'link' => array(), 'on' => true ) );
	$tone  = $tones[ $i['tone'] ] ?? $tones['mint'];
	$title = idw_svc_t( $i['title'], $lang );
	$link  = idw_svc_t( $i['link'], $lang );
	$url   = idw_svc_href( $i['url'] );
	$cover = $i['image'] && 'cover' === $i['imageMode'];
	$cls   = 'idw-svc__card' . ( $url ? ' has-link' : '' ) . ( $cover ? ' has-cover' : '' ) . ( ! $cover && ! $i['image'] && ! $i['icon'] ? ' no-ico' : '' );
	$style = $i['color'] ? '--tone:' . $i['color'] . ';--tone-bg:color-mix(in srgb,' . $i['color'] . ' 13%,#fff)' : '--tone:' . $tone[1] . ';--tone-bg:' . $tone[2];
	$pos   = 'center' === $i['pos'] ? '' : ' style="object-position:' . esc_attr( $i['pos'] ) . '"';
	$h     = '<article class="' . $cls . '" style="' . esc_attr( $style ) . '">';
	if ( $cover ) {
		$h .= '<span class="idw-svc__img"><img src="' . esc_url( $i['image'] ) . '" alt="" loading="lazy" decoding="async"' . $pos . '></span>';
	} elseif ( $i['image'] ) {
		$h .= '<span class="idw-svc__ico is-img"><img src="' . esc_url( $i['image'] ) . '" alt="" loading="lazy" decoding="async"></span>';
	} elseif ( $i['icon'] ) {
		$h .= '<span class="idw-svc__ico">' . idw_svc_icon( $i['icon'] ) . '</span>';
	}
	$h   .= '<div class="idw-svc__body">';
	$h   .= $title ? '<h3 class="idw-svc__name">' . esc_html( $title ) . '</h3>' : '';
	$text = idw_svc_t( $i['text'], $lang );
	if ( $text ) {
		$h .= '<p class="idw-svc__text">' . nl2br( esc_html( $text ) ) . '</p>';
	}
	if ( $url ) {
		$ext = idw_svc_external( $url ) ? ' target="_blank" rel="noopener"' : '';
		if ( $link ) {
			$h .= '<a class="idw-svc__more" href="' . esc_url( $url ) . '"' . $ext . '>' . esc_html( $link ) . ' <span aria-hidden="true">→</span></a>';
		} else {
			$h .= '<a class="idw-svc__more is-hidden" href="' . esc_url( $url ) . '"' . $ext . '><span class="screen-reader-text">' . esc_html( $title ? $title : ( 'en' === $lang ? 'Open' : 'เปิด' ) ) . '</span></a>';
		}
	}
	return $h . '</div></article>';
}

/* ---------- home page: put the block on the front page ---------- */

/** ใส่บล็อกชุดการ์ดลงหน้าแรก · คืน added | exists | nopage */
function idw_svc_add_to_home( $set = 'services' ) {
	$pid = (int) get_option( 'page_on_front' );
	if ( 'page' !== get_option( 'show_on_front' ) || ! $pid || ! get_post( $pid ) ) {
		return 'nopage';
	}
	$content = (string) get_post_field( 'post_content', $pid );
	$blocks  = parse_blocks( $content );
	foreach ( $blocks as $b ) {
		$has = (string) ( $b['attrs']['set'] ?? '' );
		if ( 'idw/services' === $b['blockName'] && ( $has === $set || ( '' === $has && 'services' === $set ) ) ) {
			return 'exists';
		}
	}
	$new = parse_blocks( '<!-- wp:idw/services ' . wp_json_encode( array( 'set' => $set, 'align' => 'wide' ) ) . ' /-->' );
	$at  = -1;
	foreach ( $blocks as $i => $b ) {
		$cls = (string) ( $b['attrs']['className'] ?? '' );
		/* a services section made before this module: the Hub cards block or the plain theme-1 section */
		if ( 'services' === $set && ( ( 'idevapp/cards' === $b['blockName'] && 'services' === ( $b['attrs']['settings']['anchor'] ?? '' ) ) || false !== strpos( $cls, 'hos-services' ) ) ) {
			if ( 'idevapp/cards' === $b['blockName'] && ! is_array( get_option( 'idw_services' ) ) ) {
				idw_svc_put( array_merge( idw_svc_hub_to_set( $b['attrs'] ), array( 'id' => 'services', 'name' => 'บริการทางการแพทย์' ) ) );
			}
			array_splice( $blocks, $i, 1, $new );
			$at = -2;
			break;
		}
		if ( 'services' !== $set && 'idw/services' === $b['blockName'] && in_array( (string) ( $b['attrs']['set'] ?? '' ), array( '', 'services' ), true ) ) {
			$at = $i + 1; // another set goes right after the services section
			break;
		}
		if ( false !== strpos( $cls, 'hos-quick-g' ) || 'idevapp/hero' === $b['blockName'] || 'idevapp/quicklinks' === $b['blockName'] ) {
			$at = $i + 1;
		}
	}
	if ( -2 !== $at ) {
		if ( $at < 0 ) {
			$at = min( 1, count( $blocks ) );
		}
		array_splice( $blocks, $at, 0, $new );
	}
	kses_remove_filters();
	wp_update_post( array( 'ID' => $pid, 'post_content' => wp_slash( serialize_blocks( $blocks ) ) ) );
	kses_init_filters();
	do_action( 'litespeed_purge_all' );
	return 'added';
}

/* theme แบบที่ 1: the home page gets the services block once (sites made before this module) */
add_action( 'admin_init', function () {
	if ( get_option( 'idw_svc_home_v1' ) || ! current_user_can( 'edit_pages' ) || 'idevapp-theme-1' !== get_stylesheet() ) {
		return;
	}
	update_option( 'idw_svc_home_v1', idw_svc_add_to_home(), false );
} );
