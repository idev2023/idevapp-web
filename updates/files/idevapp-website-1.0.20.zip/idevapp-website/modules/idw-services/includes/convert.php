<?php
/** แปลงบล็อก “การ์ดบริการ” ของ Hub (idevapp/cards) ในหน้าเว็บเป็นชุดการ์ดของโมดูลนี้ (รวมรูปของแต่ละการ์ด) */
defined( 'ABSPATH' ) || exit;

/** attrs ของบล็อก idevapp/cards → ข้อมูลชุด */
function idw_svc_hub_to_set( $attrs ) {
	$d  = (array) ( $attrs['data'] ?? array() );
	$st = (array) ( $attrs['settings'] ?? array() );
	$bg = (string) ( $st['background'] ?? '' );
	return array(
		'name'    => is_array( $d['title'] ?? null ) ? (string) ( $d['title']['th'] ?? '' ) : (string) ( $d['title'] ?? '' ),
		'kicker'  => $d['kicker'] ?? '',
		'title'   => $d['title'] ?? '',
		'columns' => (int) ( $d['columns'] ?? 3 ),
		'style'   => $d['iconStyle'] ?? 'soft',
		'size'    => array( 'large' => 'l', 'xl' => 'l' )[ $d['iconSize'] ?? '' ] ?? 'm',
		'layout'  => 'center' === ( $d['align'] ?? '' ) ? 'center' : 'stack',
		'card'    => 'border',
		'bg'      => in_array( $bg, array( 'light', 'white' ), true ) ? $bg : 'none',
		'items'   => (array) ( $d['items'] ?? array() ),
	);
}

/** ทุกบล็อก idevapp/cards ในหน้า / เรื่อง (รวมที่อยู่ในกลุ่ม) · [ [post, path, attrs] ] */
function idw_svc_find_hub_cards( $limit = 300 ) {
	$out   = array();
	$posts = get_posts( array( 'post_type' => array( 'page', 'post' ), 'post_status' => array( 'publish', 'draft', 'private', 'future', 'pending' ), 'numberposts' => $limit, 's' => 'wp:idevapp/cards', 'search_columns' => array( 'post_content' ) ) );
	foreach ( $posts as $p ) {
		if ( false === strpos( $p->post_content, 'wp:idevapp/cards' ) ) {
			continue;
		}
		$walk = function ( $blocks, $path ) use ( &$walk, &$out, $p ) {
			foreach ( $blocks as $i => $b ) {
				if ( 'idevapp/cards' === $b['blockName'] ) {
					$out[] = array( $p, array_merge( $path, array( $i ) ), $b['attrs'] );
				}
				if ( ! empty( $b['innerBlocks'] ) ) {
					$walk( $b['innerBlocks'], array_merge( $path, array( $i ) ) );
				}
			}
		};
		$walk( parse_blocks( $p->post_content ), array() );
	}
	return $out;
}

/** แทนบล็อกตาม path ด้วยบล็อกใหม่ (innerContent ของกลุ่มยังคงตำแหน่งเดิม) */
function idw_svc_replace_at( &$blocks, $path, $new ) {
	$i = array_shift( $path );
	if ( ! isset( $blocks[ $i ] ) ) {
		return false;
	}
	if ( ! $path ) {
		$blocks[ $i ] = $new;
		return true;
	}
	return idw_svc_replace_at( $blocks[ $i ]['innerBlocks'], $path, $new );
}

add_action( 'admin_post_idw_svc_convert', function () {
	$pid  = (int) ( $_POST['post'] ?? 0 );
	$path = array_map( 'intval', explode( '.', sanitize_text_field( wp_unslash( $_POST['path'] ?? '' ) ) ) );
	if ( ! $pid || ! current_user_can( 'edit_post', $pid ) || ! current_user_can( 'edit_pages' ) || ! check_admin_referer( 'idw_svc_convert' ) ) {
		wp_die( 'ไม่มีสิทธิ์', 403 );
	}
	$blocks = parse_blocks( (string) get_post_field( 'post_content', $pid ) );
	$b      = $blocks;
	foreach ( $path as $n => $i ) {
		$b = $n ? ( $b['innerBlocks'][ $i ] ?? null ) : ( $b[ $i ] ?? null );
		if ( ! $b ) {
			break;
		}
	}
	if ( ! $b || 'idevapp/cards' !== $b['blockName'] ) {
		wp_safe_redirect( admin_url( 'admin.php?page=idw-services&conv=missing' ) );
		exit;
	}
	$data = idw_svc_hub_to_set( $b['attrs'] );
	if ( '' === trim( $data['name'] ) ) {
		$data['name'] = get_the_title( $pid );
	}
	$data['id'] = idw_svc_new_id( 'services' === ( $b['attrs']['settings']['anchor'] ?? '' ) && ! idw_svc_get( 'services' ) ? 'services' : 'cards' );
	$set        = idw_svc_put( $data );
	$attrs      = array( 'set' => $set['id'], 'align' => 'wide' );
	if ( ! empty( $b['attrs']['settings']['anchor'] ) ) {
		$attrs['anchor'] = sanitize_html_class( $b['attrs']['settings']['anchor'] );
	}
	$new = parse_blocks( '<!-- wp:idw/services ' . wp_json_encode( $attrs ) . ' /-->' )[0];
	idw_svc_replace_at( $blocks, $path, $new );
	kses_remove_filters();
	wp_update_post( array( 'ID' => $pid, 'post_content' => wp_slash( serialize_blocks( $blocks ) ) ) );
	kses_init_filters();
	do_action( 'litespeed_purge_all' );
	wp_safe_redirect( admin_url( 'admin.php?page=idw-services&set=' . rawurlencode( $set['id'] ) . '&conv=1' ) );
	exit;
} );
