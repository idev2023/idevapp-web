<?php
/**
 * ลิงก์ของการ์ด: หาหน้าจริงในเว็บให้เอง กันลิงก์ไปหน้า 404
 *  - /doctor-schedule/ /appointment/ /registration/ /contact/ ที่ไม่มีหน้าชื่อนั้น → หาหน้าที่มีตารางแพทย์ / ฟอร์มนัดหมาย / ลงทะเบียน / ติดต่อ
 *  - หาไม่พบ: ตารางแพทย์ / นัดหมาย / ลงทะเบียน ไม่แสดงลิงก์ (ไม่ส่งผู้ชมไปหน้า 404) · อื่น ๆ แจ้งเตือนในหลังบ้าน
 */
defined( 'ABSPATH' ) || exit;

/** ชนิดของหน้าตาม slug ที่ใช้บ่อย */
function idw_svc_link_kinds() {
	return array(
		'schedule'     => array( 'slugs' => array( 'doctor-schedule', 'schedule', 'doctors-schedule', 'clinic-schedule' ), 'find' => array( 'hos_clinics', 'idev_schedule', 'wp:idev/schedule', 'wp:hos/clinics', 'idev_doctors', 'wp:idev/doctors', 'wp:idevapp/doctors' ), 'tpl' => 'page-templates/tpl-doctor-schedule.php', 'mod' => 'hos_schedule_url', 'drop' => true ),
		'appointment'  => array( 'slugs' => array( 'appointment', 'appointments', 'booking' ), 'find' => array( 'idev_booking', 'wp:idev/booking' ), 'drop' => true ),
		'registration' => array( 'slugs' => array( 'registration', 'register', 'patient-registration' ), 'find' => array( 'idev_patient_registration', 'wp:idev/patient-registration', 'wp:idevapp/registration' ), 'drop' => true ),
		'contact'      => array( 'slugs' => array( 'contact', 'contact-us', 'ติดต่อเรา' ), 'find' => array( 'wp:hos/map', 'wp:idevapp/map' ), 'drop' => false ),
	);
}

/** url ของหน้าชนิดนั้น ('' = ไม่มีในเว็บ) — จำไว้ 12 ชั่วโมง ล้างเมื่อบันทึกหน้า */
function idw_svc_kind_url( $kind ) {
	static $mem = array();
	if ( isset( $mem[ $kind ] ) ) {
		return $mem[ $kind ];
	}
	$cache = get_transient( 'idw_svc_kinds' );
	$cache = is_array( $cache ) ? $cache : array();
	if ( isset( $cache[ $kind ] ) ) {
		return $mem[ $kind ] = $cache[ $kind ];
	}
	$k   = idw_svc_link_kinds()[ $kind ] ?? null;
	$url = '';
	if ( $k ) {
		$page = null;
		if ( ! empty( $k['mod'] ) && get_theme_mod( $k['mod'] ) && 0 === strpos( (string) get_theme_mod( $k['mod'] ), '/' ) ) {
			$page = get_page_by_path( trim( (string) get_theme_mod( $k['mod'] ), '/' ) );
		}
		foreach ( $k['slugs'] as $s ) {
			$page = $page ? $page : get_page_by_path( $s );
		}
		if ( ! $page && ! empty( $k['tpl'] ) ) {
			$f    = get_pages( array( 'meta_key' => '_wp_page_template', 'meta_value' => $k['tpl'], 'number' => 1 ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
			$page = $f ? $f[0] : null;
		}
		if ( ! $page ) {
			global $wpdb;
			foreach ( $k['find'] as $needle ) {
				$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status = 'publish' AND post_content LIKE %s ORDER BY menu_order, ID LIMIT 1", '%' . $wpdb->esc_like( $needle ) . '%' ) );
				if ( $id ) {
					$page = get_post( $id );
					break;
				}
			}
		}
		$url = ( $page && 'publish' === $page->post_status ) ? get_permalink( $page ) : '';
	}
	$cache[ $kind ] = $url;
	set_transient( 'idw_svc_kinds', $cache, 12 * HOUR_IN_SECONDS );
	return $mem[ $kind ] = $url;
}
add_action( 'save_post_page', function () {
	delete_transient( 'idw_svc_kinds' );
} );
add_action( 'customize_save_after', function () {
	delete_transient( 'idw_svc_kinds' );
} );

/** ลิงก์ภายใน (/path/) มีหน้าจริงไหม */
function idw_svc_path_exists( $path ) {
	$path = '/' . trim( (string) $path, '/' );
	if ( '/' === $path ) {
		return true;
	}
	if ( get_page_by_path( trim( $path, '/' ), OBJECT, array( 'page', 'post' ) ) || url_to_postid( home_url( $path . '/' ) ) ) {
		return true;
	}
	$slug = basename( $path );
	if ( term_exists( urldecode( $slug ) ) || get_term_by( 'slug', $slug, 'category' ) ) {
		return true;
	}
	foreach ( get_post_types( array( 'public' => true, 'has_archive' => true ), 'objects' ) as $pt ) {
		$a = is_string( $pt->has_archive ) ? $pt->has_archive : ( $pt->rewrite['slug'] ?? $pt->name );
		if ( trim( $a, '/' ) === trim( $path, '/' ) ) {
			return true;
		}
	}
	return false;
}

/**
 * ลิงก์ที่ใช้จริง · คืน [url, สถานะ] สถานะ: ok | fixed (หาหน้าแทนให้) | dropped (ไม่แสดงลิงก์) | missing (ไม่พบหน้า — แจ้งในหลังบ้าน)
 * รองรับ {schedule} {appointment} {registration} {contact} ในลิงก์ด้วย
 */
function idw_svc_resolve( $u ) {
	$u = trim( (string) $u );
	if ( '' === $u ) {
		return array( '', 'ok' );
	}
	if ( preg_match( '/^\{(\w+)\}(.*)$/', $u, $m ) ) {
		$base = idw_svc_kind_url( $m[1] );
		return $base ? array( idw_svc_join( $base, $m[2] ), 'ok' ) : array( '', 'dropped' );
	}
	if ( '/' !== $u[0] || 0 === strpos( $u, '//' ) ) {
		return array( $u, 'ok' );
	}
	$parts = wp_parse_url( $u );
	$path  = $parts['path'] ?? '/';
	if ( idw_svc_path_exists( $path ) ) {
		return array( home_url( $u ), 'ok' );
	}
	$slug = strtolower( trim( $path, '/' ) );
	foreach ( idw_svc_link_kinds() as $kind => $k ) {
		if ( in_array( $slug, $k['slugs'], true ) ) {
			$base = idw_svc_kind_url( $kind );
			if ( $base ) {
				return array( idw_svc_join( $base, substr( $u, strlen( $path ) ) ), 'fixed' );
			}
			if ( $k['drop'] ) {
				return array( '', 'dropped' );
			}
		}
	}
	return array( home_url( $u ), 'missing' );
}
function idw_svc_join( $base, $rest ) {
	$rest = (string) $rest;
	if ( '' === $rest ) {
		return $base;
	}
	if ( '?' === $rest[0] ) {
		parse_str( substr( $rest, 1 ), $q );
		return add_query_arg( array_map( 'rawurlencode', $q ), $base );
	}
	return '#' === $rest[0] ? $base . $rest : trailingslashit( $base ) . ltrim( $rest, '/' );
}
