<?php
/**
 * การ์ดจากตารางออกตรวจ: ชุดการ์ดที่ตั้ง “ที่มา = ตารางออกตรวจ” สร้างการ์ด 1 ใบต่อ 1 คลินิกเอง
 * (ชื่อ เวลาออกตรวจ ลิงก์ไปตารางของคลินิกนั้น) — เพิ่ม / ลบคลินิกในตารางออกตรวจ การ์ดเปลี่ยนตาม
 * แยกตามหมวดได้ เช่น คลินิกพิเศษนอกเวลา (SMC) เป็นอีกชุดหนึ่ง · ไอคอน สี รูป และข้อความแก้รายการ์ดได้
 */
defined( 'ABSPATH' ) || exit;

function idw_svc_has_clinics() {
	return post_type_exists( 'idev_provider' );
}

/** คลินิกทั้งหมดที่เผยแพร่ เรียงตามตารางออกตรวจ: [ [id, name, name_en, group, slots, note, photo] ] */
function idw_svc_clinic_list() {
	static $list = null;
	if ( null !== $list ) {
		return $list;
	}
	$list = array();
	if ( ! idw_svc_has_clinics() ) {
		return $list;
	}
	foreach ( get_posts( array( 'post_type' => 'idev_provider', 'post_status' => 'publish', 'numberposts' => 500, 'orderby' => array( 'menu_order' => 'ASC', 'title' => 'ASC' ) ) ) as $p ) {
		$terms = taxonomy_exists( 'idev_specialty' ) ? get_the_terms( $p, 'idev_specialty' ) : false;
		$group = $terms && ! is_wp_error( $terms ) ? $terms[0]->name : (string) get_post_meta( $p->ID, '_idev_specialty', true );
		$slots = json_decode( (string) get_post_meta( $p->ID, '_idev_slots', true ), true );
		$list[] = array(
			'id'      => $p->ID,
			'name'    => get_the_title( $p ),
			'name_en' => (string) get_post_meta( $p->ID, '_idev_name_en', true ),
			'group'   => '' === trim( $group ) ? 'คลินิกเฉพาะทาง' : trim( $group ),
			'slots'   => is_array( $slots ) ? $slots : array(),
			'note'    => (string) get_post_meta( $p->ID, '_idev_note', true ),
		);
	}
	return $list;
}

/** หมวดของคลินิก (ตามลำดับที่พบ) พร้อมจำนวน */
function idw_svc_clinic_groups() {
	$g = array();
	foreach ( idw_svc_clinic_list() as $c ) {
		$g[ $c['group'] ] = ( $g[ $c['group'] ] ?? 0 ) + 1;
	}
	return $g;
}
/** หมวดคลินิกพิเศษนอกเวลา */
function idw_svc_is_smc( $group ) {
	return (bool) preg_match( '/SMC|พิเศษ.*นอกเวลา|special\s*medical/iu', (string) $group );
}

/** วัน-เวลาออกตรวจแบบสั้น เช่น “จ. พ. 08.30–12.00 น.” */
function idw_svc_clinic_time( $c, $lang = 'th' ) {
	if ( function_exists( 'hos_clinic_time_lines' ) ) {
		$lines = hos_clinic_time_lines( $c['slots'] );
		$out   = array();
		foreach ( array_slice( $lines, 0, 3 ) as $l ) {
			$out[] = trim( $l[0] . ' ' . $l[1] );
		}
		return implode( ' · ', $out ) . ( count( $lines ) > 3 ? ' …' : '' );
	}
	$dn  = 'en' === $lang ? array( 1 => 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun' ) : array( 1 => 'จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.', 'อา.' );
	$by  = array();
	foreach ( $c['slots'] as $s ) {
		if ( empty( $s['start_time'] ) || empty( $s['weekday'] ) ) {
			continue;
		}
		$t          = str_replace( ':', '.', $s['start_time'] ) . '–' . str_replace( ':', '.', (string) ( $s['end_time'] ?? '' ) );
		$by[ $t ][] = (int) $s['weekday'];
	}
	$out = array();
	foreach ( $by as $t => $days ) {
		$days = array_unique( $days );
		sort( $days );
		$out[] = implode( ' ', array_map( function ( $d ) use ( $dn ) { return $dn[ $d ] ?? ''; }, $days ) ) . ' ' . $t . ( 'en' === $lang ? '' : ' น.' );
	}
	return implode( ' · ', array_slice( $out, 0, 3 ) );
}

/** ไอคอนตามชื่อคลินิก */
function idw_svc_clinic_icon( $name, $group ) {
	$map = array(
		'tooth'       => 'ฟัน|ทันต|dental',
		'baby'        => 'เด็ก|กุมาร|ทารก|วัคซีน|well ?baby|pediat|paediat',
		'pregnant'    => 'ครรภ์|สูติ|นรีเวช|ANC|มารดา|วางแผนครอบครัว',
		'eye'         => 'ตา|จักษุ|eye',
		'bone'        => 'กระดูก|ศัลย|ortho|surg',
		'heart'       => 'หัวใจ|heart|cardio|ความดัน',
		'thermometer' => 'เบาหวาน|DM|อายุร|med|ไต|CKD|โรคเรื้อรัง|NCD',
		'lungs'       => 'ปอด|หอบ|ARI|COPD|asthma|ทางเดินหายใจ|วัณโรค|TB',
		'leaf'        => 'แผนไทย|สมุนไพร|นวด|thai',
		'wheelchair'  => 'กายภาพ|ฟื้นฟู|rehab|physio',
		'smile'       => 'จิต|ยาเสพติด|psych|สุขภาพจิต',
		'brain'       => 'สมอง|ประสาท|neuro',
		'pill'        => 'ยา|เภสัช|warfarin|pharm',
		'users'       => 'ผู้สูงอายุ|elderly|ครอบครัว',
		'bandage'     => 'แผล|wound|ทำแผล',
		'xray'        => 'X-?ray|เอกซเรย์|รังสี',
		'lab'         => 'แล็บ|ชันสูตร|lab',
		'star'        => 'SMC|พิเศษ',
		'clock'       => 'นอกเวลา',
	);
	foreach ( $map as $icon => $re ) {
		if ( preg_match( '/' . $re . '/iu', $name ) ) {
			return $icon;
		}
	}
	return idw_svc_is_smc( $group ) ? 'star' : ( preg_match( '/นอกเวลา/u', $group ) ? 'clock' : 'stethoscope' );
}

/** การ์ดที่สร้างจากคลินิกหนึ่ง */
function idw_svc_clinic_card( $c, $i ) {
	$tones = array( 'mint', 'sky', 'indigo', 'teal', 'orange', 'pink', 'blue', 'green', 'lavender', 'amber', 'rose' );
	$q     = '?clinic=' . rawurlencode( $c['name'] ) . '&provider=' . (int) $c['id'];
	return array(
		'pid'   => (int) $c['id'],
		'auto'  => 1,
		'group' => $c['group'],
		'icon'  => idw_svc_clinic_icon( $c['name'], $c['group'] ),
		'tone'  => idw_svc_is_smc( $c['group'] ) ? 'amber' : $tones[ $i % count( $tones ) ],
		'title' => array( 'th' => $c['name'], 'en' => $c['name_en'] ),
		'text'  => array( 'th' => trim( idw_svc_clinic_time( $c ) . ( $c['note'] ? ' · ' . $c['note'] : '' ), ' ·' ), 'en' => idw_svc_clinic_time( $c, 'en' ) ),
		'url'   => '{schedule}' . $q,
		'link'  => array( 'th' => 'ดูตารางออกตรวจ', 'en' => 'Clinic schedule' ),
		'on'    => true,
		'color' => '', 'image' => '', 'imageId' => 0, 'imageMode' => 'cover', 'pos' => 'center',
	);
}

/**
 * การ์ดของชุดที่ดึงจากตารางออกตรวจ: คลินิกในหมวดที่เลือก + สิ่งที่แก้ไว้รายการ์ด (เก็บตาม pid)
 * ชื่อ ข้อความ และลิงก์ตามตารางออกตรวจเสมอ เว้นแต่แก้เอง (title_custom / text_custom / url_custom)
 */
function idw_svc_clinic_items( $set ) {
	$groups = array_filter( (array) ( $set['groups'] ?? array() ) );
	$skip   = array_filter( (array) ( $set['exclude'] ?? array() ) );
	$gen    = array();
	$n      = 0;
	foreach ( idw_svc_clinic_list() as $c ) {
		$in = function ( $list ) use ( $c ) { // '@smc' = every group of after-hours special clinics
			return in_array( $c['group'], $list, true ) || ( in_array( '@smc', $list, true ) && idw_svc_is_smc( $c['group'] ) );
		};
		if ( ( $groups && ! $in( $groups ) ) || ( $skip && $in( $skip ) ) ) {
			continue;
		}
		$gen[ $c['id'] ] = idw_svc_clinic_card( $c, $n++ );
	}
	$out  = array();
	$used = array();
	foreach ( (array) ( $set['items'] ?? array() ) as $it ) {
		$pid = (int) ( $it['pid'] ?? 0 );
		if ( ! $pid ) {
			$out[] = $it; // a card added by hand stays where it is
			continue;
		}
		if ( ! isset( $gen[ $pid ] ) || isset( $used[ $pid ] ) ) {
			continue; // the clinic is gone (or not in the chosen groups)
		}
		$g = $gen[ $pid ];
		foreach ( array( 'title', 'text', 'url' ) as $k ) {
			if ( empty( $it[ $k . '_custom' ] ) ) {
				$it[ $k ] = $g[ $k ];
			}
		}
		$it['auto']  = 1;
		$it['group'] = $g['group'];
		$out[]       = $it;
		$used[ $pid ] = 1;
	}
	foreach ( $gen as $pid => $g ) {
		if ( ! isset( $used[ $pid ] ) ) {
			$out[] = $g; // a new clinic in the schedule
		}
	}
	return $out;
}
