<?php
/**
 * Plugin Name: การ์ดบริการ (บริการทางการแพทย์ / ลิงก์ด่วน / ช่องทางติดต่อ)
 * Description: สร้างชุดการ์ดได้หลายชุด เช่น บริการทางการแพทย์ ลิงก์ด่วน ช่องทางติดต่อ — ไอคอนหรือรูป สี ข้อความไทย / อังกฤษ ลิงก์ รูปแบบการ์ด แสดงด้วยบล็อก “การ์ดบริการ” หรือ [idw_services set="…"] ใช้ได้กับทุกธีม
 * Version: 1.0.0
 * Author: iDevApp
 * Author URI: https://idevapp.me/
 * Text Domain: idw-services
 *
 * ไม่ขึ้นกับธีมหรือโมดูลอื่น: ข้อมูลอยู่ใน option idw_services · CSS ของตัวเอง (คลาส .idw-svc) · ไอคอนของตัวเอง
 */
defined( 'ABSPATH' ) || exit;
if ( defined( 'IDW_SVC_VER' ) ) {
	return;
}
define( 'IDW_SVC_VER', defined( 'IDW_VERSION' ) ? IDW_VERSION : '1.0.0' );
define( 'IDW_SVC_URL', plugin_dir_url( __FILE__ ) );

require_once __DIR__ . '/includes/icons.php';
require_once __DIR__ . '/includes/data.php';
require_once __DIR__ . '/includes/links.php';
require_once __DIR__ . '/includes/clinics.php';
require_once __DIR__ . '/includes/render.php';
require_once __DIR__ . '/includes/convert.php';
if ( is_admin() ) {
	require_once __DIR__ . '/includes/admin.php';
}
