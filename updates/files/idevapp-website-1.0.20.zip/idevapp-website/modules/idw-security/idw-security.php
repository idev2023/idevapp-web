<?php
/**
 * Module: ตรวจความปลอดภัย
 * The admin presses "เริ่มตรวจ": the website is checked against the OWASP Top 10 (2025 edition) and known
 * vulnerabilities (CVE) of WordPress, the installed plugins and themes, and PHP. Every finding comes with
 * advice, and many with a one-click fix (the settings below). Nothing is scanned without the button.
 */
defined('ABSPATH') || exit;
if (defined('IDW_SEC_VERSION')) return;
define('IDW_SEC_VERSION', defined('IDW_VERSION') ? IDW_VERSION : '1.0.0');
define('IDW_SEC_DIR', plugin_dir_path(__FILE__));

require_once IDW_SEC_DIR . 'includes/scan.php';
require_once IDW_SEC_DIR . 'includes/twofa.php';
require_once IDW_SEC_DIR . 'includes/ncsa.php';
require_once IDW_SEC_DIR . 'includes/report.php';

/* ---------- hardening settings (each one can be switched on by a fix button or on the settings tab) ---------- */

function idw_sec_hardening_list() {
    return [
        'log' => ['บันทึกเหตุการณ์ความปลอดภัย', 'เก็บประวัติการเข้าสู่ระบบ ล็อกอินผิด การเปลี่ยนสิทธิ์ผู้ใช้ และการเปิด / ปิดปลั๊กอิน (90 วันล่าสุด)', 'A09'],
        'login_limit' => ['จำกัดการล็อกอินผิด', 'ล็อกอินผิด 5 ครั้งใน 15 นาที จาก IP เดียวกัน จะถูกพัก 15 นาที — กันการเดารหัสผ่าน', 'A07'],
        'headers' => ['ส่วนหัวความปลอดภัย (Security headers)', 'X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy และ HSTS เมื่อใช้ HTTPS', 'A02'],
        'xmlrpc' => ['ปิด XML-RPC', 'ช่องทางเก่าที่มักถูกใช้เดารหัสผ่านและโจมตีแบบ pingback (แอป WordPress บนมือถือรุ่นใหม่ไม่ต้องใช้)', 'A02'],
        'users_api' => ['ซ่อนรายชื่อผู้ใช้', 'ปิด /wp-json/wp/v2/users และ ?author= สำหรับคนที่ไม่ได้ล็อกอิน — ไม่ให้รู้ชื่อบัญชีสำหรับเดารหัส', 'A01'],
        'file_edit' => ['ปิดตัวแก้ไขไฟล์ธีม / ปลั๊กอินในหลังบ้าน', 'ถ้าบัญชีผู้ดูแลหลุด ผู้บุกรุกจะแก้โค้ดเว็บจากหลังบ้านไม่ได้', 'A01'],
        'unfiltered_html' => ['ห้ามคนที่ไม่ใช่ผู้ดูแลใส่สคริปต์', 'บรรณาธิการและผู้เขียนใส่ <script> / iframe อันตรายในเนื้อหาไม่ได้ (กัน Stored XSS)', 'A05'],
        'generator' => ['ซ่อนเวอร์ชัน WordPress', 'ไม่แสดงเวอร์ชันในหน้าเว็บและฟีด ลดข้อมูลที่ผู้โจมตีใช้เลือกช่องโหว่', 'A02'],
        'risky_uploads' => ['ปิดการอัปโหลดไฟล์ที่ฝังสคริปต์ได้', 'ไม่รับไฟล์ SVG, HTML/HTM, JS, XML, PHP และไฟล์โปรแกรมในคลังสื่อ แม้ปลั๊กอินหรือธีมอื่นจะเปิดให้อัปโหลดไว้ (ไฟล์ที่อัปโหลดไว้แล้วไม่ถูกลบ) — ใช้ PNG / JPG / WebP / PDF แทน', 'A05'],
        '2fa_force' => ['บังคับผู้ดูแลระบบใช้การยืนยันตัวตนสองขั้น (2FA)', 'ผู้ดูแลที่ยังไม่ตั้ง Google Authenticator จะถูกพาไปหน้าโปรไฟล์ให้ตั้งค่าก่อนใช้หลังบ้าน · ตั้งค่าเองได้ที่ ผู้ใช้ → โปรไฟล์ → “ยืนยันตัวตนสองขั้น”', 'A07'],
        'idle_logout' => ['ออกจากระบบอัตโนมัติเมื่อไม่ใช้งาน 15 นาที', 'ล็อกเซสชันตามมาตรฐานเว็บไซต์ สกมช. 2568 — ผู้ใช้ที่ไม่ขยับเมาส์ / พิมพ์ / ใช้งานเกิน 15 นาทีต้องเข้าสู่ระบบใหม่', 'สกมช.'],
        'inactive_lock' => ['ระงับบัญชีที่ไม่ได้ใช้งานเกิน 45 วัน', 'บัญชีที่ไม่ได้เข้าสู่ระบบเกิน 45 วันเข้าไม่ได้จนผู้ดูแลปลดระงับ (หน้าผู้ใช้) · นับตั้งแต่วันที่เปิด · ไม่ระงับผู้ดูแลระบบคนสุดท้าย', 'สกมช.'],
        'pw_policy' => ['นโยบายรหัสผ่านตามมาตรฐาน', 'ยาวอย่างน้อย 8 ตัว (รองรับ 64 ตัวขึ้นไป) ห้ามซ้ำ 5 ครั้งล่าสุด และไม่ให้ใช้รหัสผ่านที่เคยรั่วไหล (ตรวจแบบไม่ส่งรหัสผ่านออกไป — k-anonymity)', 'สกมช.'],
        'login_captcha' => ['ถามยืนยันว่าไม่ใช่โปรแกรมอัตโนมัติ (CAPTCHA)', 'หลังล็อกอินผิด 2 ครั้งจาก IP เดียวกัน หน้าเข้าสู่ระบบจะถามโจทย์บวกเลขก่อน', 'สกมช.'],
        'hide_login' => ['ซ่อนหน้าเข้าสู่ระบบ', 'wp-login.php และ /wp-admin ตอบ 404 กับคนที่ไม่ได้เข้าผ่านที่อยู่ลับ (ตั้งชื่อด้านล่าง) · ลิงก์รีเซ็ตรหัสผ่านทางอีเมลยังใช้ได้ · ฉุกเฉิน: ใส่ define( \'IDW_LOGIN_SLUG_OFF\', true ); ใน wp-config.php', 'สกมช.'],
        'hide_server' => ['ซ่อนข้อมูลเซิร์ฟเวอร์', 'ไม่ส่ง X-Powered-By (เวอร์ชัน PHP) และ X-Redirect-By', 'สกมช.'],
        'auto_scan' => ['ตรวจช่องโหว่อัตโนมัติทุก 30 วัน', 'ตรวจความปลอดภัยทั้งหมดทุก 30 วัน (มาตรฐานกำหนดไม่เกิน 90 วัน) และส่งอีเมลเมื่อพบความเสี่ยงสูง', 'สกมช.'],
        'app_passwords' => ['ปิด Application Passwords', 'รหัสผ่านสำหรับแอปภายนอกที่ใช้เข้า REST API แทนรหัสผ่านจริง — ปิดถ้าไม่ได้เชื่อมระบบอื่น', 'A07'],
    ];
}
function idw_sec_hard() {
    return wp_parse_args((array) get_option('idw_sec_hard', []), ['log' => '1', 'login_limit' => '1', 'headers' => '0', 'xmlrpc' => '0', 'users_api' => '0', 'file_edit' => '0', 'unfiltered_html' => '0', 'generator' => '0', 'app_passwords' => '0', 'risky_uploads' => '0', '2fa_force' => '0', 'idle_logout' => '0', 'inactive_lock' => '0', 'pw_policy' => '0', 'login_captcha' => '0', 'hide_login' => '0', 'hide_server' => '0', 'auto_scan' => '0']);
}
function idw_sec_on($k) { return (idw_sec_hard()[$k] ?? '0') === '1'; }
function idw_sec_set($k, $on) {
    $h = idw_sec_hard();
    if (!isset(idw_sec_hardening_list()[$k])) return;
    $h[$k] = $on ? '1' : '0';
    update_option('idw_sec_hard', $h);
}

/* security headers */
function idw_sec_send_headers() {
    if (!idw_sec_on('headers') || headers_sent()) return;
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(self), microphone=(), geolocation=(self), payment=()');
    if (is_ssl()) header('Strict-Transport-Security: max-age=31536000');
}
add_action('send_headers', 'idw_sec_send_headers');
add_action('admin_init', 'idw_sec_send_headers');
add_action('login_init', 'idw_sec_send_headers');

/* XML-RPC */
add_filter('xmlrpc_enabled', function ($on) { return idw_sec_on('xmlrpc') ? false : $on; });
add_filter('wp_headers', function ($h) { if (idw_sec_on('xmlrpc')) unset($h['X-Pingback']); return $h; });
add_filter('xmlrpc_methods', function ($m) { return idw_sec_on('xmlrpc') ? [] : $m; });
add_action('init', function () {
    if (idw_sec_on('xmlrpc') && defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) { status_header(403); exit('XML-RPC is disabled.'); }
}, 1);

/* user enumeration */
add_filter('rest_endpoints', function ($e) {
    if (!idw_sec_on('users_api') || is_user_logged_in()) return $e;
    foreach (array_keys($e) as $route) if (strpos($route, '/wp/v2/users') === 0) unset($e[$route]);
    return $e;
});
add_action('template_redirect', function () {
    if (idw_sec_on('users_api') && !is_user_logged_in() && (isset($_GET['author']) || is_author())) { wp_safe_redirect(home_url('/'), 301); exit; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended
}, 1);
add_filter('oembed_response_data', function ($d) { if (idw_sec_on('users_api')) { unset($d['author_name'], $d['author_url']); } return $d; });

/* capabilities */
add_filter('map_meta_cap', function ($caps, $cap, $user_id) {
    if (idw_sec_on('file_edit') && in_array($cap, ['edit_themes', 'edit_plugins', 'edit_files'], true)) return ['do_not_allow'];
    if (idw_sec_on('unfiltered_html') && $cap === 'unfiltered_html' && !user_can($user_id, 'manage_options')) return ['do_not_allow'];
    return $caps;
}, 10, 3);

/* version */
add_action('init', function () {
    if (!idw_sec_on('generator')) return;
    remove_action('wp_head', 'wp_generator');
    add_filter('the_generator', '__return_empty_string');
});

/* uploads that can carry scripts (SVG / HTML / JS …): removed from the allowed types, and refused by file name too */
function idw_sec_risky_ext() { return '/(^|\|)(svgz?|html?|xht|xhtml|js|mjs|xml|php\d?|phtml|phar|exe|bat|sh)(\||$)/i'; }
add_filter('upload_mimes', function ($m) {
    if (!idw_sec_on('risky_uploads')) return $m;
    foreach (array_keys($m) as $k) if (preg_match(idw_sec_risky_ext(), $k)) unset($m[$k]);
    return $m;
}, 9999);
add_filter('wp_check_filetype_and_ext', function ($d, $file, $name) {
    if (idw_sec_on('risky_uploads') && preg_match('/\.(svgz?|html?|xht|xhtml|js|mjs|xml|php\d?|phtml|phar|exe|bat|sh)$/i', (string) $name)) { $d['ext'] = false; $d['type'] = false; $d['proper_filename'] = false; }
    return $d;
}, 9999, 3);

/* application passwords */
add_filter('wp_is_application_passwords_available', function ($on) { return idw_sec_on('app_passwords') ? false : $on; });

/* ---------- login limiting ---------- */

function idw_sec_ip() {
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
}
function idw_sec_ip_key() { return 'idw_sec_f_' . md5(idw_sec_ip() . wp_salt('auth')); }
add_filter('authenticate', function ($user, $username) {
    if (!idw_sec_on('login_limit') || empty($username)) return $user;
    $f = get_transient(idw_sec_ip_key());
    if (is_array($f) && ($f['n'] ?? 0) >= 5 && ($f['until'] ?? 0) > time()) {
        $min = max(1, (int) ceil(($f['until'] - time()) / 60));
        return new WP_Error('idw_locked', sprintf('ล็อกอินผิดหลายครั้ง กรุณารอ %d นาทีแล้วลองใหม่ / Too many failed logins, try again in %d minutes.', $min, $min));
    }
    return $user;
}, 30, 2);
add_action('wp_login_failed', function ($username) {
    if (idw_sec_on('login_limit')) {
        $k = idw_sec_ip_key();
        $f = get_transient($k);
        $f = is_array($f) ? $f : ['n' => 0, 'until' => 0];
        $f['n']++;
        if ($f['n'] >= 5) $f['until'] = time() + 15 * MINUTE_IN_SECONDS;
        set_transient($k, $f, 15 * MINUTE_IN_SECONDS);
    }
    idw_sec_log('login_failed', 'ล็อกอินไม่สำเร็จ: ' . sanitize_user((string) $username));
});
add_action('wp_login', function ($login, $user) {
    delete_transient(idw_sec_ip_key());
    if (user_can($user, 'edit_posts')) idw_sec_log('login', 'เข้าสู่ระบบ: ' . $login);
}, 10, 2);

/* ---------- security log ---------- */

function idw_sec_log($type, $text) {
    if (!idw_sec_on('log')) return;
    $log = (array) get_option('idw_sec_log', []);
    array_unshift($log, ['t' => time(), 'type' => $type, 'text' => mb_substr($text, 0, 200), 'ip' => idw_sec_ip(), 'user' => get_current_user_id()]);
    $cut = time() - 90 * DAY_IN_SECONDS; // kept 90 days (มาตรฐานเว็บไซต์ สกมช. 5.6.9 / พ.ร.บ.คอมพิวเตอร์)
    $log = array_values(array_filter($log, function ($l) use ($cut) { return ($l['t'] ?? 0) >= $cut; }));
    update_option('idw_sec_log', array_slice($log, 0, 3000), false);
}
add_action('set_user_role', function ($uid, $role, $old) { idw_sec_log('role', 'เปลี่ยนสิทธิ์ผู้ใช้ #' . $uid . ': ' . implode(',', (array) $old) . ' → ' . $role); }, 10, 3);
add_action('user_register', function ($uid) { $u = get_userdata($uid); idw_sec_log('user', 'สร้างผู้ใช้ใหม่: ' . ($u ? $u->user_login . ' (' . implode(',', $u->roles) . ')' : '#' . $uid)); });
add_action('delete_user', function ($uid) { $u = get_userdata($uid); idw_sec_log('user', 'ลบผู้ใช้: ' . ($u ? $u->user_login : '#' . $uid)); });
add_action('activated_plugin', function ($p) { idw_sec_log('plugin', 'เปิดปลั๊กอิน: ' . $p); });
add_action('deactivated_plugin', function ($p) { idw_sec_log('plugin', 'ปิดปลั๊กอิน: ' . $p); });
add_action('switch_theme', function ($n) { idw_sec_log('theme', 'เปลี่ยนธีม: ' . $n); });
add_action('update_option_admin_email', function ($o, $n) { idw_sec_log('setting', 'เปลี่ยนอีเมลผู้ดูแล: ' . $o . ' → ' . $n); }, 10, 2);

/* ---------- fixes ---------- */

/** One-click fixes that are not a setting. key => [label, callback returning message or WP_Error] */
function idw_sec_actions() {
    return [
        'uploads_htaccess' => ['ป้องกันโฟลเดอร์อัปโหลด', 'idw_sec_fix_uploads'],
        'content_htaccess' => ['ซ่อนไฟล์ log และไฟล์สำรอง', 'idw_sec_fix_content'],
        'root_htaccess' => ['ปิดการเข้าถึงไฟล์ลับ (.git .env ไฟล์สำรอง)', 'idw_sec_fix_root'],
        'registration' => ['ปรับการสมัครสมาชิก', 'idw_sec_fix_registration'],
        'readme' => ['ลบไฟล์ที่บอกเวอร์ชัน', 'idw_sec_fix_readme'],
        'debug_log' => ['ย้ายไฟล์ debug.log', 'idw_sec_fix_debug_log'],
        'ncsa_cms' => ['เปิดการป้องกัน CMS ที่เหลือทั้งหมด', 'idw_sec_fix_ncsa_cms'],
    ];
}
function idw_sec_write($file, $content) {
    if (!wp_is_writable(dirname($file))) return new WP_Error('idw_sec', 'เขียนไฟล์ไม่ได้: ' . $file . ' — ให้ผู้ดูแลเซิร์ฟเวอร์เพิ่มให้ หรือปรับสิทธิ์โฟลเดอร์');
    $old = is_file($file) ? (string) file_get_contents($file) : '';
    if (strpos($old, '# BEGIN iDevApp Security') !== false) $old = preg_replace('/# BEGIN iDevApp Security.*?# END iDevApp Security\n?/s', '', $old);
    return file_put_contents($file, "# BEGIN iDevApp Security\n" . $content . "# END iDevApp Security\n" . $old) !== false ? true : new WP_Error('idw_sec', 'เขียนไฟล์ไม่สำเร็จ');
}
function idw_sec_fix_uploads() {
    $up = wp_get_upload_dir();
    $r = idw_sec_write(trailingslashit($up['basedir']) . '.htaccess', "Options -Indexes\n<FilesMatch \"\\.(php[0-9]?|phtml|phar|pl|py|cgi|sh)$\">\n  Require all denied\n</FilesMatch>\n");
    if (is_wp_error($r)) return $r;
    if (!is_file(trailingslashit($up['basedir']) . 'index.php')) @file_put_contents(trailingslashit($up['basedir']) . 'index.php', "<?php // Silence is golden.\n"); // phpcs:ignore
    return 'ปิดการรันสคริปต์และการแสดงรายชื่อไฟล์ในโฟลเดอร์อัปโหลดแล้ว (Apache / LiteSpeed) — ถ้าใช้ Nginx ดูคำแนะนำในรายงาน';
}
function idw_sec_fix_content() {
    $r = idw_sec_write(WP_CONTENT_DIR . '/.htaccess', "<FilesMatch \"\\.(log|sql|bak|old|orig|save|swp|zip|tar|gz)$\">\n  Require all denied\n</FilesMatch>\n");
    return is_wp_error($r) ? $r : 'ซ่อนไฟล์ .log .sql .bak และไฟล์สำรองใน wp-content แล้ว';
}
function idw_sec_fix_root() {
    $r = idw_sec_write(ABSPATH . '.htaccess', "RedirectMatch 404 /\\.(git|svn|hg|env)(/|$)\n<FilesMatch \"(^\\.|\\.(bak|old|orig|save|swp|sql|log|ini)$|~$)\">\n  Require all denied\n</FilesMatch>\n<Files \"wp-config.php\">\n  Require all denied\n</Files>\n");
    return is_wp_error($r) ? $r : 'ปิดการเข้าถึง .git .env ไฟล์สำรอง และ wp-config.php จากเว็บแล้ว (Apache / LiteSpeed) — ไฟล์ที่ไม่จำเป็นควรลบออกจากเซิร์ฟเวอร์ด้วย';
}
function idw_sec_fix_registration() {
    if (get_option('default_role') !== 'subscriber') update_option('default_role', 'subscriber');
    return 'สมาชิกใหม่จะได้สิทธิ์ “สมาชิก (Subscriber)” เท่านั้น';
}
function idw_sec_fix_readme() {
    $n = 0;
    foreach (['readme.html', 'license.txt', 'wp-config-sample.php'] as $f) if (is_file(ABSPATH . $f) && @unlink(ABSPATH . $f)) $n++; // phpcs:ignore
    return $n ? 'ลบแล้ว ' . $n . ' ไฟล์ (WordPress อาจสร้างกลับมาเมื่ออัปเดต — ตรวจซ้ำหลังอัปเดต)' : new WP_Error('idw_sec', 'ลบไม่ได้ ตรวจสิทธิ์ไฟล์');
}
function idw_sec_fix_debug_log() {
    $f = WP_CONTENT_DIR . '/debug.log';
    if (!is_file($f)) return 'ไม่พบไฟล์ debug.log';
    $dir = dirname(ABSPATH) . '/idw-private';
    if (wp_mkdir_p($dir) && @rename($f, $dir . '/debug-' . gmdate('Ymd-His') . '.log')) return 'ย้าย debug.log ออกจากโฟลเดอร์เว็บไปที่ ' . $dir . ' แล้ว — ปิด WP_DEBUG_LOG ใน wp-config.php หรือกำหนดที่เก็บ log นอกโฟลเดอร์เว็บ'; // phpcs:ignore
    return @unlink($f) ? 'ลบ debug.log แล้ว' : new WP_Error('idw_sec', 'ย้าย / ลบไม่ได้'); // phpcs:ignore
}

/** Run one fix · returns [message, ok]. Caches are emptied so the change shows at once. */
function idw_sec_do_fix($k) {
    $msg = '';
    if (!isset(idw_sec_hardening_list()[$k]) && !isset(idw_sec_actions()[$k])) return ['!ไม่รู้จักรายการนี้ — กดตรวจใหม่อีกครั้ง', false];
    // safety: remember the settings and the .htaccess files, check the site after the change and undo it if the site breaks
    $up = wp_upload_dir();
    $files = [ABSPATH . '.htaccess', WP_CONTENT_DIR . '/.htaccess', trailingslashit($up['basedir']) . '.htaccess'];
    $snap = ['opt' => get_option('idw_sec_hard'), 'files' => []];
    foreach ($files as $f) $snap['files'][$f] = file_exists($f) ? (string) file_get_contents($f) : null; // phpcs:ignore
    $before = function_exists('idw_site_health') ? idw_site_health() : null;
    if (isset(idw_sec_hardening_list()[$k])) { idw_sec_set($k, true); $msg = 'เปิด “' . idw_sec_hardening_list()[$k][0] . '” แล้ว' . ('hide_login' === $k ? ' — หน้าเข้าสู่ระบบใหม่: ' . home_url('/' . idw_sec_login_slug() . '/') . ' (จดไว้)' : ''); if (function_exists('idw_sec_snap_auto_before')) idw_sec_snap_auto_before(); }
    else { if (function_exists('idw_sec_snap_auto_before')) idw_sec_snap_auto_before(); $r = call_user_func(idw_sec_actions()[$k][1]); $msg = is_wp_error($r) ? '!' . $r->get_error_message() : (string) $r; }
    $ok = strpos($msg, '!') !== 0;
    if ($ok && $before !== false && function_exists('idw_site_health') && idw_site_health() === false) {
        update_option('idw_sec_hard', $snap['opt']);
        foreach ($snap['files'] as $f => $c) {
            if ($c === null) { if (file_exists($f)) @unlink($f); } // phpcs:ignore
            else file_put_contents($f, $c); // phpcs:ignore
        }
        idw_sec_purge();
        idw_sec_log('fix', 'แก้ไข ' . $k . ' ทำให้เว็บเปิดไม่ได้ — ย้อนกลับแล้ว');
        return ['!การแก้ไขนี้ทำให้เว็บเปิดไม่ได้บนเซิร์ฟเวอร์นี้ ระบบย้อนกลับให้แล้ว เว็บใช้งานได้ตามปกติ — ให้ผู้ดูแลเซิร์ฟเวอร์ตั้งค่านี้แทน', false];
    }
    $name = idw_sec_hardening_list()[$k][0] ?? (idw_sec_actions()[$k][0] ?? $k);
    idw_sec_log('fix', ($ok ? 'ดำเนินการ: ' : 'ไม่สำเร็จ: ') . $name . ($ok && $msg && strpos($msg, 'เปิด “') !== 0 ? ' — ' . wp_strip_all_tags($msg) : ''));
    if ($ok) {
        idw_sec_purge();
        $rep = get_option('idw_sec_report');
        if (is_array($rep)) {
            foreach ($rep['items'] as &$it) if (($it['fix'] ?? '') === $k) $it['fixed'] = 1;
            unset($it);
            update_option('idw_sec_report', $rep, false);
        }
    }
    return [$msg, $ok];
}
/** Empty page caches (LiteSpeed, W3TC, WP Super Cache, WP Rocket, object cache). */
function idw_sec_purge() {
    do_action('litespeed_purge_all');
    do_action('w3tc_flush_all');
    if (function_exists('wp_cache_clear_cache')) wp_cache_clear_cache();
    if (function_exists('rocket_clean_domain')) rocket_clean_domain();
    wp_cache_flush();
}
/** Check from the outside that a fix is really in effect · true / false / null (cannot tell from here). */
function idw_sec_verify($k) {
    require_once __DIR__ . '/includes/scan.php';
    $home = add_query_arg('idw_v', wp_rand(1000, 9999), home_url('/'));
    switch ($k) {
        case 'users_api':
            $u = idw_sec_probe(add_query_arg('idw_v', wp_rand(), rest_url('wp/v2/users')));
            if (!$u) return null;
            $j = json_decode($u['body'], true);
            return !($u['code'] === 200 && is_array($j) && $j);
        case 'xmlrpc':
            $x = idw_sec_probe(site_url('xmlrpc.php'), 'POST');
            return $x ? $x['code'] !== 200 : null;
        case 'headers':
            $f = idw_sec_probe($home);
            return $f ? !empty($f['headers']['x-content-type-options']) : null;
        case 'generator':
            $f = idw_sec_probe($home);
            return $f ? !preg_match('/<meta[^>]+generator[^>]+WordPress/i', $f['body']) : null;
        case 'readme':
            $p = idw_sec_probe(site_url('readme.html'));
            return $p ? $p['code'] !== 200 : null;
    }
    return null;
}
function idw_sec_why_not() {
    return 'บันทึกการตั้งค่าแล้ว แต่ตรวจจากภายนอกยังเห็นผลเดิม — มักเกิดจาก (1) แคชของโฮสต์หรือ CDN เช่น Cloudflare: ล้างแคชแล้วกดตรวจใหม่ (2) เซิร์ฟเวอร์ Nginx ไม่อ่านไฟล์ .htaccess: ให้ผู้ดูแลเซิร์ฟเวอร์ตั้งค่าแทน (3) ปลั๊กอินอื่นตั้งค่าซ้อนอยู่';
}

add_action('admin_post_idw_sec_fix', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_sec_fix')) wp_die('ไม่มีสิทธิ์', 403);
    list($msg) = idw_sec_do_fix(sanitize_key($_POST['fix'] ?? ''));
    set_transient('idw_sec_msg_' . get_current_user_id(), $msg, 120);
    wp_safe_redirect(admin_url('admin.php?page=idw-security&tab=' . sanitize_key($_POST['back'] ?? 'report')));
    exit;
});
/* the same fix by AJAX: the button shows the result in place and checks it from the outside */
add_action('wp_ajax_idw_sec_fix', function () {
    if (!current_user_can('manage_options') || !check_ajax_referer('idw_sec_fix', '_wpnonce', false)) wp_send_json_error(['msg' => 'ไม่มีสิทธิ์ หรือหน้านี้เปิดไว้นานเกินไป — โหลดหน้าใหม่แล้วลองอีกครั้ง'], 403);
    $k = sanitize_key($_POST['fix'] ?? '');
    list($msg, $ok) = idw_sec_do_fix($k);
    if (!$ok) wp_send_json_error(['msg' => ltrim($msg, '!')]);
    $v = idw_sec_verify($k);
    wp_send_json_success(['msg' => $msg, 'verified' => $v, 'note' => $v === false ? idw_sec_why_not() : '']);
});

/* ---------- new CVE: check now, twice a day, notice and e-mail ---------- */

function idw_sec_cve_opts() { return wp_parse_args((array) get_option('idw_sec_cve_opts', []), ['auto' => '1', 'mail' => '1']); }
function idw_sec_cve_schedule() {
    $on = idw_sec_cve_opts()['auto'] === '1';
    $next = wp_next_scheduled('idw_sec_cve_check');
    if ($on && !$next) wp_schedule_event(time() + HOUR_IN_SECONDS, 'twicedaily', 'idw_sec_cve_check');
    if (!$on && $next) wp_clear_scheduled_hook('idw_sec_cve_check');
}
add_action('admin_init', 'idw_sec_cve_schedule');
add_action('idw_sec_cve_check', function () {
    require_once __DIR__ . '/includes/scan.php';
    $r = idw_sec_cve_refresh(true);
    if ($r['error'] || !$r['new']) return;
    idw_sec_cve_found($r['new']);
});
/** remember new findings for the notice, and e-mail the site admin */
function idw_sec_cve_found($new) {
    $titles = array_map(function ($i) { return wp_strip_all_tags($i['title']) . ' — ' . wp_strip_all_tags($i['detail']); }, $new);
    update_option('idw_sec_cve_new', ['n' => count($new), 'time' => time(), 'titles' => array_slice($titles, 0, 10)], false);
    idw_sec_log('scan', 'พบช่องโหว่ใหม่ (CVE) ' . count($new) . ' รายการ');
    if (idw_sec_cve_opts()['mail'] === '1') {
        $body = "พบช่องโหว่ที่ประกาศใหม่ (CVE) ที่เกี่ยวกับเว็บ " . home_url('/') . " จำนวน " . count($new) . " รายการ:\n\n- " . implode("\n- ", array_slice($titles, 0, 10))
            . "\n\nดูรายละเอียดและวิธีแก้ไข: " . admin_url('admin.php?page=idw-security&tab=report') . "\n\nส่งโดย iDevApp Website · ปิดการแจ้งเตือนได้ที่ ตรวจความปลอดภัย › ตั้งค่าความปลอดภัย";
        wp_mail(get_option('admin_email'), '[' . wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES) . '] พบช่องโหว่ใหม่ ' . count($new) . ' รายการ', $body);
    }
}
add_action('admin_post_idw_sec_cve', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_sec_cve')) wp_die('ไม่มีสิทธิ์', 403);
    require_once __DIR__ . '/includes/scan.php';
    @set_time_limit(180); // phpcs:ignore
    $r = idw_sec_cve_refresh(true);
    if ($r['error']) $msg = '!ตรวจฐานข้อมูลช่องโหว่ไม่ได้: ' . $r['error'];
    elseif ($r['new']) { idw_sec_cve_found($r['new']); $msg = '!พบช่องโหว่ใหม่ ' . count($r['new']) . ' รายการ — ดูรายการที่มีป้าย “ใหม่” ด้านล่าง'; }
    else $msg = 'ดึงข้อมูล CVE ล่าสุดแล้ว — ' . ($r['total'] ? 'ไม่มีช่องโหว่ใหม่ (ยังมีรายการเดิม ' . $r['total'] . ' รายการที่ควรแก้)' : 'ไม่พบช่องโหว่ของ WordPress ปลั๊กอิน ธีม และ PHP ที่ใช้อยู่');
    idw_sec_log('scan', 'ตรวจ CVE ใหม่ทันที');
    set_transient('idw_sec_msg_' . get_current_user_id(), $msg, 120);
    wp_safe_redirect(admin_url('admin.php?page=idw-security&tab=report#cve'));
    exit;
});
/* notice in the back office until the report is opened */
add_action('admin_notices', function () {
    $n = get_option('idw_sec_cve_new');
    if (!is_array($n) || empty($n['n']) || !current_user_can('manage_options')) return;
    if (($_GET['page'] ?? '') === 'idw-security') { delete_option('idw_sec_cve_new'); return; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    echo '<div class="notice notice-error"><p><b>พบช่องโหว่ใหม่ (CVE) ' . (int) $n['n'] . ' รายการ</b> ที่เกี่ยวกับ WordPress ปลั๊กอิน ธีม หรือ PHP ที่เว็บนี้ใช้ — <a href="' . esc_url(admin_url('admin.php?page=idw-security&tab=report#cve')) . '">ดูรายการและวิธีแก้ไข</a></p></div>';
});
/** “check new CVE now” bar on the report */
function idw_sec_cve_bar($rep) {
    $t = (int) ($rep['cve_time'] ?? $rep['time'] ?? 0);
    $auto = idw_sec_cve_opts()['auto'] === '1';
    $next = wp_next_scheduled('idw_sec_cve_check');
    echo '<form id="cve" class="idw-card sec-cve" method="post" action="' . esc_url(admin_url('admin-post.php')) . '" data-busy="กำลังดึงข้อมูล CVE ล่าสุด… (ประมาณ 10–40 วินาที)">' . wp_nonce_field('idw_sec_cve', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_sec_cve">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div><b>ช่องโหว่ที่ประกาศแล้ว (CVE)</b><span>ข้อมูลล่าสุดเมื่อ ' . esc_html($t ? idw_dt($t) : '—') . ' · ' . ($auto ? 'ตรวจใหม่อัตโนมัติวันละ 2 ครั้ง' . ($next ? ' (ครั้งถัดไป ' . esc_html(idw_dt($next)) . ')' : '') : 'ปิดการตรวจอัตโนมัติอยู่') . ' · แหล่งข้อมูล WPVulnerability (CVE, Wordfence, Patchstack, WPScan)</span></div>';
    echo '<button class="idw-btn pri">' . idw_icon('refresh') . 'ตรวจ CVE ใหม่ตอนนี้</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

add_action('admin_post_idw_sec_settings', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_sec_settings')) wp_die('ไม่มีสิทธิ์', 403);
    $h = [];
    foreach (array_keys(idw_sec_hardening_list()) as $k) $h[$k] = empty($_POST['h'][$k]) ? '0' : '1';
    update_option('idw_sec_hard', $h);
    if (isset($_POST['login_slug'])) { $slug = sanitize_title(wp_unslash($_POST['login_slug'])); if ($slug && !in_array($slug, ['wp-admin', 'wp-login', 'login', 'admin'], true)) update_option('idw_sec_login_slug', $slug); }
    update_option('idw_sec_cve_opts', ['auto' => empty($_POST['cve_auto']) ? '0' : '1', 'mail' => empty($_POST['cve_mail']) ? '0' : '1']);
    idw_sec_cve_schedule();
    idw_sec_log('setting', 'บันทึกการตั้งค่าความปลอดภัย');
    set_transient('idw_sec_msg_' . get_current_user_id(), 'บันทึกแล้ว', 120);
    wp_safe_redirect(admin_url('admin.php?page=idw-security&tab=settings'));
    exit;
});

add_action('admin_post_idw_sec_scan', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_sec_scan')) wp_die('ไม่มีสิทธิ์', 403);
    @set_time_limit(180); // phpcs:ignore
    $rep = idw_sec_run_scan();
    update_option('idw_sec_report', $rep, false);
    idw_sec_log('scan', 'ตรวจความปลอดภัย คะแนน ' . $rep['score']);
    delete_transient('idw_sec_ncsa_auto');
    if (function_exists('idw_sec_snap_take')) idw_sec_snap_take(get_option('idw_sec_snaps') ? 'ผลการตรวจ' : 'ก่อนแก้ไข (ตรวจครั้งแรก)');
    wp_safe_redirect(admin_url('admin.php?page=idw-security&tab=report&scanned=1'));
    exit;
});

/* ---------- admin page ---------- */

add_action('admin_menu', function () {
    add_submenu_page('idevapp', 'ตรวจความปลอดภัย', 'ตรวจความปลอดภัย', 'manage_options', 'idw-security', 'idw_sec_page');
}, 20);
add_action('admin_enqueue_scripts', function () {
    if (($_GET['page'] ?? '') !== 'idw-security') return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    wp_enqueue_style('idw-admin');
    wp_enqueue_script('idw-admin');
    wp_enqueue_style('idw-sec', plugin_dir_url(__FILE__) . 'assets/security.css', ['idw-admin'], IDW_SEC_VERSION);
    wp_enqueue_script('idw-sec', plugin_dir_url(__FILE__) . 'assets/security.js', ['jquery'], IDW_SEC_VERSION, true);
    wp_localize_script('idw-sec', 'IDW_SEC', ['ajax' => admin_url('admin-ajax.php')]);
});

function idw_sec_owasp() {
    return [
        'A01' => ['การควบคุมสิทธิ์เข้าถึงบกพร่อง', 'Broken Access Control'],
        'A02' => ['การตั้งค่าระบบไม่ปลอดภัย', 'Security Misconfiguration'],
        'A03' => ['ซอฟต์แวร์ / ส่วนประกอบมีช่องโหว่', 'Software Supply Chain Failures'],
        'A04' => ['การเข้ารหัสบกพร่อง', 'Cryptographic Failures'],
        'A05' => ['การแทรกคำสั่ง (Injection / XSS)', 'Injection'],
        'A06' => ['การออกแบบไม่ปลอดภัย', 'Insecure Design'],
        'A07' => ['การยืนยันตัวตนบกพร่อง', 'Authentication Failures'],
        'A08' => ['ความถูกต้องของซอฟต์แวร์และข้อมูล', 'Software or Data Integrity Failures'],
        'A09' => ['การบันทึกและแจ้งเตือนเหตุการณ์', 'Security Logging and Alerting Failures'],
        'A10' => ['การจัดการข้อผิดพลาดไม่เหมาะสม', 'Mishandling of Exceptional Conditions'],
    ];
}
function idw_sec_sev() {
    return ['critical' => ['วิกฤต', 'bad', 30], 'high' => ['สูง', 'bad', 15], 'medium' => ['ปานกลาง', 'warn', 6], 'low' => ['ต่ำ', 'info', 2], 'info' => ['แนะนำ', '', 0], 'ok' => ['ผ่าน', 'ok', 0]];
}

function idw_sec_page() {
    if (!current_user_can('manage_options')) wp_die('ไม่มีสิทธิ์');
    $tab = sanitize_key($_GET['tab'] ?? 'report'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $rep = get_option('idw_sec_report');
    $scan = '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" data-busy="กำลังตรวจ… (ประมาณ 10–60 วินาที)" style="display:inline">' . wp_nonce_field('idw_sec_scan', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_sec_scan"><button class="idw-btn acc lg">' . idw_icon('shield') . ($rep ? 'ตรวจอีกครั้ง' : 'เริ่มตรวจความปลอดภัย') . '</button></form>';
    idw_open('ตรวจความปลอดภัย', 'ตรวจตาม OWASP Top 10 ฉบับปี 2025 และช่องโหว่ที่มีรหัส CVE ของ WordPress ปลั๊กอิน ธีม และ PHP — ตรวจเมื่อกดปุ่มเท่านั้น พร้อมคำแนะนำและปุ่มแก้ไข', $scan);
    $msg = get_transient('idw_sec_msg_' . get_current_user_id());
    if ($msg) { delete_transient('idw_sec_msg_' . get_current_user_id()); idw_note(esc_html(ltrim($msg, '!')), strpos($msg, '!') === 0 ? 'err' : ''); }
    echo '<nav class="idw-subtabs">';
    foreach (['report' => 'ผลการตรวจ (OWASP)', 'ncsa' => 'มาตรฐาน สกมช. 2568', 'export' => 'ส่งออกรายงาน', 'settings' => 'ตั้งค่าความปลอดภัย', 'log' => 'บันทึกเหตุการณ์'] as $k => $l) echo '<a class="' . ($k === $tab ? 'on' : '') . '" href="' . esc_url(admin_url('admin.php?page=idw-security&tab=' . $k)) . '">' . esc_html($l) . '</a>';
    echo '</nav>';
    if ($tab === 'settings') idw_sec_tab_settings();
    elseif ($tab === 'ncsa') idw_sec_tab_ncsa();
    elseif ($tab === 'export') idw_sec_tab_export();
    elseif ($tab === 'log') idw_sec_tab_log();
    else idw_sec_tab_report($rep);
    idw_close();
}

function idw_sec_fix_button($key, $back = 'report') {
    $label = isset(idw_sec_hardening_list()[$key]) ? 'เปิดการป้องกันนี้' : (idw_sec_actions()[$key][0] ?? 'แก้ไข');
    return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="fx">' . wp_nonce_field('idw_sec_fix', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_sec_fix"><input type="hidden" name="fix" value="' . esc_attr($key) . '"><input type="hidden" name="back" value="' . esc_attr($back) . '"><button class="idw-btn pri sm">' . idw_icon('wand') . esc_html($label) . '</button></form>';
}

function idw_sec_tab_report($rep) {
    if (!is_array($rep)) {
        echo '<div class="idw-card idw-empty" style="padding:50px 20px">' . idw_icon('shield') . '<h2 style="justify-content:center">ยังไม่ได้ตรวจ</h2><p>กด “เริ่มตรวจความปลอดภัย” ด้านบน ระบบจะตรวจการตั้งค่า ไฟล์ที่เปิดเผย เวอร์ชันซอฟต์แวร์ และช่องโหว่ที่ประกาศแล้ว (CVE)<br>ไม่มีการเปลี่ยนแปลงเว็บระหว่างตรวจ</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        return;
    }
    $sev = idw_sec_sev();
    $items = $rep['items'];
    $fails = array_filter($items, function ($i) { return $i['sev'] !== 'ok' && empty($i['fixed']); });
    $score = (int) $rep['score'];
    $grade = $score >= 90 ? ['A', 'ok', 'ดีมาก'] : ($score >= 75 ? ['B', 'ok', 'ดี'] : ($score >= 60 ? ['C', 'warn', 'พอใช้ ควรปรับปรุง'] : ['D', 'bad', 'มีความเสี่ยง ควรแก้ไขโดยเร็ว']));
    $count = ['critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0];
    foreach ($fails as $f) if (isset($count[$f['sev']])) $count[$f['sev']]++;
    echo '<div class="sec-top"><div class="idw-card sec-score g-' . esc_attr($grade[1]) . '"><div class="ring" style="--p:' . (int) $score . '"><b>' . (int) $score . '</b><span>/100</span></div><div><div class="grade">ระดับ ' . esc_html($grade[0]) . '</div><p>' . esc_html($grade[2]) . '</p><small>ตรวจเมื่อ ' . esc_html(idw_dt($rep['time'])) . ' · ' . count($items) . ' รายการ · OWASP Top 10:2025</small></div></div>';
    echo '<div class="sec-counts">';
    foreach ($count as $k => $n) echo '<div class="idw-stat"><span class="ic sev-' . esc_attr($k) . '">' . idw_icon('shield') . '</span><div><b>' . (int) $n . '</b><span>ความเสี่ยง' . esc_html($sev[$k][0]) . '</span></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div></div>';
    if (!empty($rep['cve_error'])) idw_note('ตรวจฐานข้อมูลช่องโหว่ (CVE) ไม่ได้: ' . esc_html($rep['cve_error']) . ' — ผลส่วนอื่นยังใช้ได้', 'warn');
    idw_sec_cve_bar($rep);
    // by OWASP category
    echo '<div class="sec-cats">';
    foreach (idw_sec_owasp() as $c => [$th, $en]) {
        $in = array_filter($items, function ($i) use ($c) { return $i['cat'] === $c; });
        $bad = array_filter($in, function ($i) { return $i['sev'] !== 'ok' && $i['sev'] !== 'info' && empty($i['fixed']); });
        $worst = 'ok';
        foreach ($bad as $b) if ($sev[$b['sev']][2] > $sev[$worst][2]) $worst = $b['sev'];
        echo '<a class="sec-cat s-' . esc_attr($worst) . '" href="#' . esc_attr($c) . '"><span class="c">' . esc_html($c) . '</span><b>' . esc_html($th) . '</b><small>' . esc_html($en) . '</small><span class="n">' . ($bad ? count($bad) . ' ประเด็น' : 'ผ่าน') . '</span></a>';
    }
    echo '</div>';
    foreach (idw_sec_owasp() as $c => [$th, $en]) {
        $in = array_values(array_filter($items, function ($i) use ($c) { return $i['cat'] === $c; }));
        if (!$in) continue;
        usort($in, function ($a, $b) use ($sev) { $fa = empty($a['fixed']) ? $sev[$a['sev']][2] : -1; $fb = empty($b['fixed']) ? $sev[$b['sev']][2] : -1; return $fb <=> $fa; });
        echo '<div class="idw-card sec-group" id="' . esc_attr($c) . '"><h2><span class="idw-chip">' . esc_html($c) . ':2025</span>' . esc_html($th) . ' <small>' . esc_html($en) . '</small></h2>';
        foreach ($in as $i) {
            $s = !empty($i['fixed']) ? 'ok' : $i['sev'];
            echo '<div class="sec-item s-' . esc_attr($s) . (!empty($i['new']) ? ' is-new' : '') . '"><span class="idw-chip ' . esc_attr($sev[$s][1]) . '">' . esc_html(!empty($i['fixed']) ? 'แก้แล้ว' : $sev[$s][0]) . '</span><div class="tx"><b>' . (!empty($i['new']) ? '<span class="sec-new">ใหม่</span> ' : '') . esc_html($i['title']) . '</b>';
            if (!empty($i['detail'])) echo '<p>' . wp_kses_post($i['detail']) . '</p>';
            if ($i['sev'] !== 'ok' && empty($i['fixed']) && !empty($i['how'])) echo '<p class="how">' . idw_icon('wand') . '<span>' . wp_kses_post($i['how']) . '</span></p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            if (!empty($i['refs'])) { echo '<p class="refs">'; foreach ($i['refs'] as $r) echo '<a href="' . esc_url($r[1]) . '" target="_blank" rel="noopener">' . esc_html($r[0]) . '</a>'; echo '</p>'; }
            echo '</div>';
            if ($i['sev'] !== 'ok' && empty($i['fixed'])) {
                if (!empty($i['fix'])) echo idw_sec_fix_button($i['fix']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                elseif (!empty($i['link'])) echo '<a class="idw-btn sm" href="' . esc_url($i['link'][1]) . '">' . esc_html($i['link'][0]) . '</a>';
            }
            echo '</div>';
        }
        echo '</div>';
    }
    echo '<p class="sec-note">ผลนี้เป็นการตรวจจากภายในเว็บ (configuration review) ไม่ใช่การทดสอบเจาะระบบ — ควรสำรองข้อมูลก่อนแก้ไข และตรวจซ้ำทุกครั้งหลังอัปเดต · ข้อมูลช่องโหว่จาก WPVulnerability (รวม CVE, Wordfence, Patchstack, WPScan)</p>';
}

function idw_sec_tab_settings() {
    $h = idw_sec_hard();
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('idw_sec_settings', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_sec_settings"><div class="idw-card"><h2>' . idw_icon('shield') . 'การป้องกัน</h2><p class="d">เปิดเฉพาะที่ไม่กระทบการใช้งานของหน่วยงาน — ทุกข้อปิดกลับได้</p><div class="idw-opts">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    foreach (idw_sec_hardening_list() as $k => [$t, $d, $c]) echo '<label class="idw-opt"><span class="idw-switch"><input type="checkbox" name="h[' . esc_attr($k) . ']" value="1"' . checked($h[$k], '1', false) . '><span></span></span><span><b>' . esc_html($t) . ' <span class="idw-chip">' . esc_html($c) . '</span></b><small>' . esc_html($d) . '</small></span></label>';
    $c = idw_sec_cve_opts();
    echo '</div><p style="margin:12px 0 0"><label><b>ที่อยู่หน้าเข้าสู่ระบบ (เมื่อเปิด “ซ่อนหน้าเข้าสู่ระบบ”)</b><br><code>' . esc_html(home_url('/')) . '</code><input type="text" name="login_slug" value="' . esc_attr(idw_sec_login_slug()) . '" class="idw-in" style="width:220px;display:inline-block" pattern="[a-z0-9-]+"><code>/</code></label><br><small class="d">ใช้ตัวอักษรอังกฤษพิมพ์เล็ก ตัวเลข และ - · จดที่อยู่นี้ไว้ เปลี่ยนแล้วที่อยู่เดิมใช้ไม่ได้</small></p>';
    echo '<h3 style="margin:18px 0 8px">ช่องโหว่ใหม่ (CVE)</h3><div class="idw-opts">';
    echo '<label class="idw-opt"><span class="idw-switch"><input type="checkbox" name="cve_auto" value="1"' . checked($c['auto'], '1', false) . '><span></span></span><span><b>ตรวจ CVE ใหม่อัตโนมัติวันละ 2 ครั้ง</b><small>ดึงรายการช่องโหว่ล่าสุดของ WordPress ปลั๊กอิน ธีม และ PHP ที่ใช้อยู่ — ไม่กระทบหน้าเว็บ</small></span></label>';
    echo '<label class="idw-opt"><span class="idw-switch"><input type="checkbox" name="cve_mail" value="1"' . checked($c['mail'], '1', false) . '><span></span></span><span><b>อีเมลแจ้งเมื่อพบช่องโหว่ใหม่</b><small>ส่งถึง ' . esc_html(get_option('admin_email')) . ' (อีเมลผู้ดูแลเว็บใน การตั้งค่า › ทั่วไป)</small></span></label>';
    echo '</div><p style="margin-top:16px"><button class="idw-btn pri">บันทึก</button></p></div></form>';
    echo '<div class="idw-card"><h2>' . idw_icon('wand') . 'แก้ไขไฟล์บนเซิร์ฟเวอร์</h2><p class="d">เขียนกฎลงไฟล์ .htaccess (ใช้กับ Apache / LiteSpeed) — ถ้าใช้ Nginx ให้ผู้ดูแลเซิร์ฟเวอร์ตั้งค่าตามคำแนะนำในรายงาน</p><div class="sec-actions">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    foreach (idw_sec_actions() as $k => [$l]) echo idw_sec_fix_button($k, 'settings'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div></div>';
}

function idw_sec_tab_log() {
    $log = (array) get_option('idw_sec_log', []);
    if (!idw_sec_on('log')) idw_note('การบันทึกเหตุการณ์ปิดอยู่ — เปิดได้ที่แท็บ “ตั้งค่าความปลอดภัย”', 'warn');
    if (!$log) { echo '<div class="idw-card idw-empty">' . idw_icon('list') . '<p>ยังไม่มีเหตุการณ์</p></div>'; return; } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $types = ['login_failed' => ['ล็อกอินผิด', 'warn'], 'login' => ['เข้าสู่ระบบ', 'ok'], 'role' => ['สิทธิ์', 'bad'], 'user' => ['ผู้ใช้', 'info'], 'plugin' => ['ปลั๊กอิน', 'info'], 'theme' => ['ธีม', 'info'], 'setting' => ['ตั้งค่า', ''], 'fix' => ['แก้ไข', 'ok'], 'scan' => ['ตรวจ', '']];
    echo '<table class="idw-table"><thead><tr><th>เวลา</th><th>ประเภท</th><th>รายละเอียด</th><th>IP</th></tr></thead><tbody>';
    foreach ($log as $l) {
        [$tl, $tc] = $types[$l['type']] ?? [$l['type'], ''];
        echo '<tr><td style="white-space:nowrap">' . esc_html(idw_dt($l['t'])) . '</td><td><span class="idw-chip ' . esc_attr($tc) . '">' . esc_html($tl) . '</span></td><td>' . esc_html($l['text']) . '</td><td><code>' . esc_html($l['ip']) . '</code></td></tr>';
    }
    echo '</tbody></table>';
}
