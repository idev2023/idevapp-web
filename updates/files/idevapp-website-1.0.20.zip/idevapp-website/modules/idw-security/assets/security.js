/* ตรวจความปลอดภัย: ปุ่มแก้ไขทำงานในหน้า แสดงผลทันที และบอกสาเหตุเมื่อเซิร์ฟเวอร์ไม่ยอมรับคำขอ */
jQuery(function ($) {
  var C = window.IDW_SEC || {};
  $(document).on('submit', 'form.fx', function (e) {
    if (!C.ajax) return; // no script data: normal form post
    e.preventDefault();
    var $f = $(this), $b = $f.find('button'), label = $b.html();
    $f.find('.fx-msg').remove();
    $b.prop('disabled', true).addClass('busy').text('กำลังแก้ไขและตรวจซ้ำ…');
    var data = $f.serializeArray().filter(function (x) { return x.name !== 'action'; });
    data.push({ name: 'action', value: 'idw_sec_fix' });
    $.ajax({ url: C.ajax, type: 'POST', data: $.param(data), timeout: 60000 }).done(function (r) {
      if (r && r.success) {
        var ok = r.data.verified !== false;
        $f.closest('.sec-item, .idw-card, li, tr, div').first().addClass(ok ? 'is-fixed' : '');
        $f.html('<span class="fx-msg ' + (ok ? 'ok' : 'warn') + '">' + (ok ? '✓ ' : '⚠ ') + $('<i>').text(r.data.msg).html() + (r.data.verified === true ? ' · ตรวจซ้ำแล้ว ใช้งานได้' : '') + (r.data.note ? '<br><small>' + $('<i>').text(r.data.note).html() + '</small>' : '') + '</span>');
      } else {
        fail((r && r.data && r.data.msg) || 'แก้ไขไม่สำเร็จ');
      }
    }).fail(function (x, st) {
      if (x.status === 403 || x.status === 406 || x.status === 501) fail('เซิร์ฟเวอร์ปฏิเสธคำขอ (HTTP ' + x.status + ') — มักเป็นไฟร์วอลล์ของโฮสต์ เช่น ModSecurity / Imunify360 บล็อกคำว่า xmlrpc, htaccess ในคำขอ: ให้โฮสต์อนุญาตหน้า wp-admin หรือปิดกฎนั้น แล้วลองใหม่ หรือเปิดที่แท็บ “ตั้งค่า”');
      else if (st === 'timeout') fail('เซิร์ฟเวอร์ตอบช้าเกินไป — ลองใหม่อีกครั้ง');
      else fail('เชื่อมต่อไม่ได้ (HTTP ' + (x.status || 0) + ') — ลองใหม่ หรือเปิดที่แท็บ “ตั้งค่า”');
    });
    function fail(m) { $b.prop('disabled', false).removeClass('busy').html(label); $f.append('<span class="fx-msg bad">' + $('<i>').text(m).html() + '</span>'); }
  });
});
