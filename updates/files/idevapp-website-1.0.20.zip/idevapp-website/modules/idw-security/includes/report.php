<?php
/**
 * ส่งออกผลการประเมินและการป้องกัน “ก่อนทำ / หลังทำ” สำหรับส่งตรวจแบบเป็นทางการ
 * - บันทึกผล (snapshot) อัตโนมัติ: ตรวจครั้งแรก และก่อนกดแก้ไขครั้งแรก · บันทึกเองได้ทุกเมื่อ
 * - รายงานรูปแบบหนังสือราชการ (A4) พิมพ์ / บันทึกเป็น PDF ได้ และไฟล์ CSV
 * เนื้อหา: สรุปก่อน–หลัง · การดำเนินการแก้ไข (จากบันทึกเหตุการณ์) · ผลตามมาตรฐาน สกมช. 2568 รายข้อ · OWASP Top 10:2025 · สิ่งที่ต้องทำต่อ · ช่องลงนาม
 */
defined('ABSPATH') || exit;

function idw_sec_snaps() { $s = get_option('idw_sec_snaps', []); return is_array($s) ? $s : []; }
function idw_sec_ncsa_flat($fresh = false) {
    $out = [];
    foreach (idw_sec_ncsa_items($fresh) as $sk => $sec) foreach ($sec[1] as $i) $out[] = ['sec' => $sec[0], 'id' => $i[0], 'title' => $i[1], 'st' => $i[2], 'detail' => wp_strip_all_tags((string) $i[3]), 'how' => wp_strip_all_tags((string) $i[6])];
    return $out;
}
/** Take a snapshot of the whole assessment now. */
function idw_sec_snap_take($label) {
    require_once dirname(__DIR__) . '/includes/scan.php';
    $rep = get_option('idw_sec_report');
    if (!is_array($rep) || $rep['time'] < time() - DAY_IN_SECONDS) { $rep = idw_sec_run_scan(); update_option('idw_sec_report', $rep, false); }
    $ncsa = idw_sec_ncsa_flat(true);
    $u = wp_get_current_user();
    $snap = ['t' => time(), 'label' => sanitize_text_field($label), 'by' => $u && $u->ID ? $u->display_name : 'ระบบ', 'score' => (int) $rep['score'], 'scan_t' => (int) $rep['time'],
        'owasp' => array_map(function ($i) { return ['cat' => $i['cat'], 'sev' => empty($i['fixed']) ? $i['sev'] : 'ok', 'title' => wp_strip_all_tags($i['title']), 'how' => wp_strip_all_tags((string) $i['how'])]; }, $rep['items']),
        'ncsa' => $ncsa, 'impact' => idw_sec_ncsa_manual()['impact'], 'hard' => idw_sec_hard()];
    $all = idw_sec_snaps(); $all[] = $snap;
    update_option('idw_sec_snaps', array_slice($all, -30), false);
    idw_sec_log('scan', 'บันทึกผลการประเมิน: ' . $snap['label']);
    return count(idw_sec_snaps()) - 1;
}
/** Before the first fix there is always a “before” record. */
function idw_sec_snap_auto_before() { if (!idw_sec_snaps()) { idw_sec_snap_take('ก่อนแก้ไข'); return true; } return false; }

function idw_sec_snap_sum($s) {
    $c = ['critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0];
    foreach ($s['owasp'] as $i) if (isset($c[$i['sev']])) $c[$i['sev']]++;
    $n = ['ok' => 0, 'bad' => 0, 'manual' => 0, 'all' => count($s['ncsa'])];
    foreach ($s['ncsa'] as $i) { if ('ok' === $i['st']) $n['ok']++; elseif ('manual' === $i['st']) $n['manual']++; else $n['bad']++; }
    return ['sev' => $c, 'ncsa' => $n, 'pct' => $n['all'] ? (int) round($n['ok'] / $n['all'] * 100) : 0];
}
function idw_sec_rep_info() {
    return wp_parse_args((array) get_option('idw_sec_rep_info', []), ['org' => wp_specialchars_decode(get_bloginfo('name')), 'unit' => '', 'doc' => '', 'assessor' => '', 'assessor_pos' => '', 'checker' => '', 'checker_pos' => '', 'head' => '', 'head_pos' => '']);
}

add_action('admin_post_idw_sec_snap', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_sec_snap')) wp_die('ไม่มีสิทธิ์', 403);
    if (isset($_POST['del'])) { $all = idw_sec_snaps(); unset($all[(int) $_POST['del']]); update_option('idw_sec_snaps', array_values($all), false); }
    else { @set_time_limit(180); idw_sec_snap_take(sanitize_text_field(wp_unslash($_POST['label'] ?? '')) ?: 'หลังแก้ไข'); } // phpcs:ignore
    wp_safe_redirect(admin_url('admin.php?page=idw-security&tab=export&saved=1')); exit;
});

function idw_sec_tab_export() {
    $snaps = idw_sec_snaps(); $info = idw_sec_rep_info();
    if (isset($_GET['saved'])) idw_note('บันทึกแล้ว'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    echo '<div class="idw-card"><h2>' . idw_icon('book') . 'ส่งออกผลการประเมินและการป้องกัน (ก่อน / หลัง)</h2><p class="d">รายงานสำหรับส่งผู้บริหาร หน่วยงานกำกับ หรือ สกมช. — เปรียบเทียบผลก่อนแก้ไขกับหลังแก้ไข พร้อมรายการที่ดำเนินการ ผลตามมาตรฐาน สกมช. 2568 รายข้อ และ OWASP Top 10:2025 · ระบบบันทึกผล “ก่อนแก้ไข” ให้อัตโนมัติเมื่อตรวจครั้งแรกหรือก่อนกดแก้ไขครั้งแรก</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="sec-snapnew" data-busy="กำลังตรวจและบันทึกผล…">' . wp_nonce_field('idw_sec_snap', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_sec_snap"><input type="text" name="label" class="idw-in" placeholder="ชื่อการบันทึก เช่น ก่อนแก้ไข / หลังแก้ไขรอบที่ 1" style="max-width:360px"> <button class="idw-btn pri">' . idw_icon('check') . 'บันทึกผลตอนนี้</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if ($snaps) {
        echo '<table class="idw-table" style="margin-top:14px"><thead><tr><th>วันเวลา</th><th>ชื่อ</th><th>คะแนน OWASP</th><th>มาตรฐาน สกมช.</th><th>ผู้บันทึก</th><th></th></tr></thead><tbody>';
        foreach ($snaps as $i => $s) { $m = idw_sec_snap_sum($s); echo '<tr><td>' . esc_html(idw_dt($s['t'])) . '</td><td>' . esc_html($s['label']) . '</td><td>' . (int) $s['score'] . '/100</td><td>' . (int) $m['pct'] . '% (' . (int) $m['ncsa']['ok'] . '/' . (int) $m['ncsa']['all'] . ')</td><td>' . esc_html($s['by']) . '</td><td><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'ลบผลที่บันทึกนี้?\')">' . wp_nonce_field('idw_sec_snap', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_sec_snap"><button class="idw-btn sm" name="del" value="' . (int) $i . '">ลบ</button></form></td></tr>'; } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '</tbody></table>';
    }
    echo '</div>';
    $opt = function ($sel) use ($snaps) { $h = ''; foreach ($snaps as $i => $s) $h .= '<option value="' . (int) $i . '"' . selected($sel, $i, false) . '>' . esc_html(idw_dt($s['t']) . ' · ' . $s['label'] . ' · ' . $s['score'] . '/100') . '</option>'; return $h; };
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" target="_blank" class="idw-card idw-form">' . wp_nonce_field('idw_sec_export', '_wpnonce', true, false) . '<input type="hidden" name="action" value="idw_sec_export">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<h2>' . idw_icon('upload') . 'ออกรายงาน</h2><div class="sec-repgrid">';
    echo '<label class="idw-field">ผลก่อนดำเนินการ<select name="b" class="idw-in">' . ($snaps ? $opt(0) : '<option value="">— ยังไม่มี (ใช้ผลปัจจุบัน) —</option>') . '</select></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label class="idw-field">ผลหลังดำเนินการ<select name="a" class="idw-in"><option value="now">ตรวจตอนนี้และใช้ผลล่าสุด</option>' . $opt(-1) . '</select></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    foreach (['org' => 'ชื่อหน่วยงาน', 'unit' => 'ส่วนงาน / กลุ่มงานที่รับผิดชอบ', 'doc' => 'เลขที่หนังสือ (ถ้ามี)', 'assessor' => 'ผู้ประเมิน (ชื่อ-สกุล)', 'assessor_pos' => 'ตำแหน่งผู้ประเมิน', 'checker' => 'ผู้ตรวจสอบ / หัวหน้างาน', 'checker_pos' => 'ตำแหน่งผู้ตรวจสอบ', 'head' => 'ผู้บริหารหน่วยงาน', 'head_pos' => 'ตำแหน่งผู้บริหาร'] as $k => $l) echo '<label class="idw-field">' . esc_html($l) . '<input type="text" name="info[' . esc_attr($k) . ']" value="' . esc_attr($info[$k]) . '" class="idw-in"></label>';
    echo '</div><p style="display:flex;gap:8px;flex-wrap:wrap"><button class="idw-btn pri" name="fmt" value="html">' . idw_icon('book') . 'เปิดรายงาน (พิมพ์ / บันทึกเป็น PDF)</button><button class="idw-btn" name="fmt" value="csv">' . idw_icon('upload') . 'ดาวน์โหลด CSV (Excel)</button></p><p class="d" style="margin:0">ในหน้ารายงาน กด “พิมพ์” แล้วเลือก “บันทึกเป็น PDF” ได้ — ขนาด A4</p></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<style>.sec-repgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px 14px;margin-bottom:12px}.sec-snapnew{display:flex;gap:8px;flex-wrap:wrap;align-items:center}</style>';
}

/** key that matches the same finding in two snapshots (titles may carry details after “:”) */
function idw_sec_okey($i) { return $i['cat'] . '|' . trim(preg_replace('/[:：(].*$/u', '', $i['title'])); }

add_action('admin_post_idw_sec_export', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_sec_export')) wp_die('ไม่มีสิทธิ์', 403);
    @set_time_limit(180); // phpcs:ignore
    $info = array_map('sanitize_text_field', array_intersect_key((array) wp_unslash($_POST['info'] ?? []), idw_sec_rep_info()));
    update_option('idw_sec_rep_info', $info + idw_sec_rep_info(), false);
    $info = idw_sec_rep_info();
    if ('now' === ($_POST['a'] ?? 'now') || !idw_sec_snaps()) { delete_transient('idw_sec_ncsa_auto'); require_once dirname(__DIR__) . '/includes/scan.php'; $r = idw_sec_run_scan(); update_option('idw_sec_report', $r, false); idw_sec_snap_take('หลังดำเนินการ (ออกรายงาน)'); }
    $snaps = idw_sec_snaps();
    $b = $snaps[(int) ($_POST['b'] ?? 0)] ?? $snaps[0];
    $a = ('now' === ($_POST['a'] ?? 'now')) ? end($snaps) : ($snaps[(int) $_POST['a']] ?? end($snaps));
    $sb = idw_sec_snap_sum($b); $sa = idw_sec_snap_sum($a);
    $bst = []; foreach ($b['ncsa'] as $i) $bst[$i['id']] = $i['st'];
    $stl = ['ok' => 'ผ่าน', 'warn' => 'ควรปรับปรุง', 'bad' => 'ไม่ผ่าน', 'manual' => 'รอยืนยัน'];
    $sevl = ['critical' => 'วิกฤต', 'high' => 'สูง', 'medium' => 'ปานกลาง', 'low' => 'ต่ำ', 'info' => 'แนะนำ', 'ok' => 'ผ่าน'];
    // what was done between the two records
    $acts = array_reverse(array_values(array_filter((array) get_option('idw_sec_log', []), function ($l) use ($b, $a) { return in_array($l['type'], ['fix', 'setting', 'user', 'plugin'], true) && $l['t'] >= $b['t'] - 60 && $l['t'] <= $a['t'] + 60; })));
    // OWASP: fixed / remaining
    $after = []; foreach ($a['owasp'] as $i) if ('ok' !== $i['sev'] && 'info' !== $i['sev']) $after[idw_sec_okey($i)] = $i;
    $fixed = array_values(array_filter($b['owasp'], function ($i) use ($after) { return !in_array($i['sev'], ['ok', 'info'], true) && !isset($after[idw_sec_okey($i)]); }));
    $host = (string) wp_parse_url(home_url(), PHP_URL_HOST);
    $imp = ['low' => 'ต่ำ', 'medium' => 'ปานกลาง', 'high' => 'สูง'][$a['impact'] ?? 'medium'] ?? 'ปานกลาง';
    $mon = ['', 'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];
    $d = function ($t) use ($mon) { return wp_date('j', $t) . ' ' . $mon[(int) wp_date('n', $t)] . ' ' . ((int) wp_date('Y', $t) + 543) . ' เวลา ' . wp_date('H:i', $t) . ' น.'; };

    if ('csv' === ($_POST['fmt'] ?? '')) {
        nocache_headers(); header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="security-report-' . $host . '-' . wp_date('Ymd') . '.csv"');
        $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF"); // phpcs:ignore
        fputcsv($o, ['รายงานผลการประเมินความมั่นคงปลอดภัยเว็บไซต์', $info['org'], home_url('/')]);
        fputcsv($o, ['ก่อน', $d($b['t']) . ' (' . $b['label'] . ')', 'หลัง', $d($a['t']) . ' (' . $a['label'] . ')']);
        fputcsv($o, ['คะแนน OWASP', $b['score'], $a['score']]); fputcsv($o, ['มาตรฐาน สกมช. ผ่าน (%)', $sb['pct'], $sa['pct']]); fputcsv($o, []);
        fputcsv($o, ['มาตรฐาน', 'หมวด', 'ข้อ', 'รายการ', 'ก่อน', 'หลัง', 'รายละเอียด / วิธีแก้']);
        foreach ($a['ncsa'] as $i) fputcsv($o, ['สกมช. 2568', $i['sec'], $i['id'], $i['title'], $stl[$bst[$i['id']] ?? ''] ?? '-', $stl[$i['st']], trim($i['detail'] . ('ok' !== $i['st'] ? ' · ' . $i['how'] : ''), ' ·')]);
        foreach ($fixed as $i) fputcsv($o, ['OWASP Top 10:2025', $i['cat'], '', $i['title'], $sevl[$i['sev']] ?? $i['sev'], 'แก้ไขแล้ว', '']);
        foreach ($after as $i) fputcsv($o, ['OWASP Top 10:2025', $i['cat'], '', $i['title'], '', $sevl[$i['sev']] ?? $i['sev'], $i['how']]);
        fputcsv($o, []); fputcsv($o, ['การดำเนินการ', 'วันเวลา', 'รายละเอียด']);
        foreach ($acts as $l) fputcsv($o, ['', $d($l['t']), $l['text']]);
        fclose($o); exit; // phpcs:ignore
    }
    $e = 'esc_html';
    $row = function ($cells, $tag = 'td') { return '<tr>' . implode('', array_map(function ($c) use ($tag) { return '<' . $tag . '>' . $c . '</' . $tag . '>'; }, $cells)) . '</tr>'; };
    $chip = function ($st) use ($stl) { return '<span class="st ' . esc_attr($st) . '">' . esc_html($stl[$st] ?? $st) . '</span>'; };
    $delta = function ($x, $y, $hi = true) { $v = $y - $x; return $v ? '<b class="' . (($v > 0) === $hi ? 'up' : 'dn') . '">' . ($v > 0 ? '+' : '') . $v . '</b>' : '—'; };
    nocache_headers(); header('Content-Type: text/html; charset=utf-8');
    ?><!doctype html><html lang="th"><head><meta charset="utf-8"><title><?php echo $e('รายงานความมั่นคงปลอดภัยเว็บไซต์ ' . $host); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;600;700&display=swap" rel="stylesheet">
    <style>@page{size:A4;margin:18mm 16mm}*{box-sizing:border-box}body{font-family:Sarabun,'TH Sarabun New',Tahoma,sans-serif;font-size:14px;color:#111;line-height:1.55;margin:0;background:#eee}.page{max-width:210mm;margin:16px auto;background:#fff;padding:18mm 16mm;box-shadow:0 2px 12px rgba(0,0,0,.15)}
    h1{font-size:21px;text-align:center;margin:0 0 4px}h2{font-size:16px;margin:22px 0 8px;padding-bottom:4px;border-bottom:2px solid #0b5d3f}h3{font-size:14.5px;margin:14px 0 6px}.c{text-align:center}.sub{text-align:center;color:#333;margin:0 0 14px}
    table{width:100%;border-collapse:collapse;margin:6px 0 10px;font-size:13px}th,td{border:1px solid #999;padding:5px 7px;vertical-align:top;text-align:left}th{background:#eef3f0}td.n,th.n{text-align:center;white-space:nowrap}
    .meta td:first-child{width:34%;background:#f7f9f8;font-weight:600}.st{display:inline-block;padding:0 7px;border-radius:4px;font-weight:600;font-size:12px;white-space:nowrap}.st.ok{background:#dff3e8;color:#0a6b47}.st.bad{background:#fde2e1;color:#a4231c}.st.warn{background:#fff1cf;color:#8a5a00}.st.manual{background:#e8eef9;color:#2b4c8c}
    b.up{color:#0a6b47}b.dn{color:#a4231c}.small{font-size:12px;color:#444}.sign{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-top:34px;text-align:center;break-inside:avoid}.sign div{padding-top:40px}.sign .ln{border-top:1px dotted #333;margin:0 10px 4px}
    .bar{position:sticky;top:0;background:#0b5d3f;color:#fff;padding:10px;text-align:center;font-family:system-ui}.bar button{font:inherit;padding:6px 16px;border-radius:6px;border:0;cursor:pointer;margin:0 4px}
    @media print{body{background:#fff}.page{margin:0;padding:0;box-shadow:none;max-width:none}.bar{display:none}h2{break-after:avoid}tr{break-inside:avoid}}</style></head><body>
    <div class="bar">รายงานพร้อมพิมพ์ — <button onclick="window.print()">พิมพ์ / บันทึกเป็น PDF</button><button onclick="window.close()">ปิด</button></div>
    <div class="page">
    <?php if ($info['doc']) echo '<p class="small" style="text-align:right;margin:0">ที่ ' . $e($info['doc']) . '</p>'; ?>
    <h1>รายงานผลการประเมินและการป้องกันความมั่นคงปลอดภัยเว็บไซต์</h1>
    <p class="sub">ตามมาตรฐานการรักษาความมั่นคงปลอดภัยสำหรับเว็บไซต์ พ.ศ. ๒๕๖๘ (ประกาศคณะกรรมการการรักษาความมั่นคงปลอดภัยไซเบอร์แห่งชาติ)<br>และแนวทาง OWASP Top 10:2025</p>
    <table class="meta"><?php
        echo $row(['หน่วยงาน', $e($info['org'])]) . ($info['unit'] ? $row(['ส่วนงานที่รับผิดชอบ', $e($info['unit'])]) : '') . $row(['เว็บไซต์', $e(home_url('/'))]) . $row(['ระดับผลกระทบของเว็บไซต์ (ตามมาตรฐาน)', $e($imp)])
            . $row(['ผลก่อนดำเนินการ', $e($d($b['t']) . ' — ' . $b['label'] . ' (บันทึกโดย ' . $b['by'] . ')')]) . $row(['ผลหลังดำเนินการ', $e($d($a['t']) . ' — ' . $a['label'] . ' (บันทึกโดย ' . $a['by'] . ')')]) . $row(['วันที่ออกรายงาน', $e($d(time()))]); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    ?></table>

    <h2>๑. สรุปผลการประเมิน</h2>
    <table><?php
        echo $row(['ตัวชี้วัด', 'ก่อนดำเนินการ', 'หลังดำเนินการ', 'เปลี่ยนแปลง'], 'th'); // phpcs:ignore
        echo $row(['คะแนนความปลอดภัย (OWASP Top 10:2025) เต็ม 100', '<span class="n">' . (int) $b['score'] . '</span>', (int) $a['score'], $delta($b['score'], $a['score'])]); // phpcs:ignore
        echo $row(['มาตรฐาน สกมช. ๒๕๖๘: ผ่าน (ข้อ / ร้อยละ)', (int) $sb['ncsa']['ok'] . '/' . (int) $sb['ncsa']['all'] . ' (' . (int) $sb['pct'] . '%)', (int) $sa['ncsa']['ok'] . '/' . (int) $sa['ncsa']['all'] . ' (' . (int) $sa['pct'] . '%)', $delta($sb['pct'], $sa['pct'])]); // phpcs:ignore
        echo $row(['มาตรฐาน สกมช.: ไม่ผ่าน / ควรปรับปรุง', (int) $sb['ncsa']['bad'], (int) $sa['ncsa']['bad'], $delta($sb['ncsa']['bad'], $sa['ncsa']['bad'], false)]); // phpcs:ignore
        echo $row(['มาตรฐาน สกมช.: รอยืนยันโดยผู้รับผิดชอบ (เอกสาร / การกำกับดูแล)', (int) $sb['ncsa']['manual'], (int) $sa['ncsa']['manual'], $delta($sb['ncsa']['manual'], $sa['ncsa']['manual'], false)]); // phpcs:ignore
        foreach (['critical', 'high', 'medium', 'low'] as $k) echo $row(['ความเสี่ยงระดับ' . $sevl[$k] . ' (OWASP)', (int) $sb['sev'][$k], (int) $sa['sev'][$k], $delta($sb['sev'][$k], $sa['sev'][$k], false)]); // phpcs:ignore
    ?></table>

    <h2>๒. การดำเนินการป้องกันและแก้ไข</h2>
    <?php if ($fixed) { echo '<h3>รายการความเสี่ยงที่แก้ไขแล้ว (' . count($fixed) . ' รายการ)</h3><table>' . $row(['ลำดับ', 'หมวด', 'รายการ', 'ระดับเดิม'], 'th'); foreach ($fixed as $n => $i) echo $row(['<span class="n">' . ($n + 1) . '</span>', $e($i['cat']), $e($i['title']), $e($sevl[$i['sev']] ?? $i['sev'])]); echo '</table>'; } // phpcs:ignore ?>
    <?php if ($acts) { echo '<h3>บันทึกการดำเนินการ (จากระบบบันทึกเหตุการณ์)</h3><table>' . $row(['วันเวลา', 'รายละเอียด'], 'th'); foreach ($acts as $l) echo $row([$e($d($l['t'])), $e($l['text'])]); echo '</table>'; } elseif (!$fixed) echo '<p>ไม่มีการเปลี่ยนแปลงระหว่างการบันทึกผลทั้งสองครั้ง</p>'; // phpcs:ignore ?>

    <h2>๓. ผลตามมาตรฐานการรักษาความมั่นคงปลอดภัยสำหรับเว็บไซต์ พ.ศ. ๒๕๖๘ รายข้อ</h2>
    <?php $cur = ''; echo '<table>' . $row(['ข้อ', 'รายการ', 'ก่อน', 'หลัง', 'หมายเหตุ'], 'th'); // phpcs:ignore
    foreach ($a['ncsa'] as $i) { if ($i['sec'] !== $cur) { $cur = $i['sec']; echo '<tr><th colspan="5">' . $e($cur) . '</th></tr>'; } echo $row(['<span class="n">' . $e($i['id']) . '</span>', $e($i['title']), isset($bst[$i['id']]) ? $chip($bst[$i['id']]) : '-', $chip($i['st']), $e(trim($i['detail'] . ('ok' !== $i['st'] && $i['how'] ? ' · ควรดำเนินการ: ' . $i['how'] : ''), ' ·'))]); } // phpcs:ignore
    echo '</table>'; ?>

    <h2>๔. สิ่งที่ต้องดำเนินการต่อ</h2>
    <?php $todo = array_filter($a['ncsa'], function ($i) { return 'ok' !== $i['st']; });
    if (!$todo && !$after) echo '<p>ผ่านครบทุกรายการ</p>'; else { echo '<table>' . $row(['ลำดับ', 'รายการ', 'แนวทางดำเนินการ'], 'th'); $n = 0; foreach ($todo as $i) echo $row(['<span class="n">' . (++$n) . '</span>', $e($i['id'] . ' ' . $i['title']), $e($i['how'] ?: 'ผู้รับผิดชอบดำเนินการและยืนยันในระบบ')]); foreach ($after as $i) echo $row(['<span class="n">' . (++$n) . '</span>', $e('OWASP ' . $i['cat'] . ' ' . $i['title'] . ' (ระดับ' . ($sevl[$i['sev']] ?? '') . ')'), $e($i['how'])]); echo '</table>'; } // phpcs:ignore ?>

    <p class="small">วิธีประเมิน: ตรวจอัตโนมัติจากภายในเว็บไซต์และจากภายนอก (การตั้งค่า WordPress ส่วนหัว HTTP โปรโตคอล TLS DNSSEC ไฟล์ที่เปิดเผย เวอร์ชันซอฟต์แวร์ และฐานข้อมูลช่องโหว่ CVE จาก WPVulnerability) ร่วมกับการยืนยันของผู้รับผิดชอบสำหรับข้อที่เป็นเอกสารและการกำกับดูแล · รายงานนี้ใช้ประกอบแบบประเมินตนเอง (ค๑) และรายงานผลการแก้ไข (ค๒) ตามมาตรฐาน</p>

    <div class="sign">
        <?php foreach ([['ผู้ประเมิน', 'assessor'], ['ผู้ตรวจสอบ', 'checker'], ['ผู้บริหารหน่วยงาน', 'head']] as $s) echo '<div><div class="ln"></div>(' . $e($info[$s[1]] ?: '..............................................') . ')<br>' . $e($info[$s[1] . '_pos'] ?: 'ตำแหน่ง ..............................') . '<br>' . $e($s[0]) . '<br>วันที่ ........ / ........ / ........</div>'; // phpcs:ignore ?>
    </div>
    <p class="small c" style="margin-top:26px">จัดทำโดยระบบตรวจความปลอดภัย iDevApp Website <?php echo $e(IDW_SEC_VERSION); ?> · <?php echo $e($host); ?></p>
    </div></body></html><?php
    exit;
});
