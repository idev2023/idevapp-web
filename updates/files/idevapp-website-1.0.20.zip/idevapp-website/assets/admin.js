/* iDevApp Website — back office */
jQuery(function ($) {
  // module toggles: card state, Pro needs its free module, count
  var $mods = $('.idw-mod[data-mod]');
  function sync() {
    $mods.each(function () { $(this).toggleClass('on', $(this).find('input').prop('checked')); });
    $('#idw-mod-count').text($mods.find('input:checked').length);
  }
  $mods.on('change', 'input', function () {
    var $card = $(this).closest('.idw-mod'), key = $card.data('mod'), on = this.checked;
    if (!on && $(this).data('theme-needs') && !window.confirm('ธีมที่ใช้อยู่ใช้ส่วนนี้ในการแสดงหน้าเว็บ ถ้าปิด บางหน้าอาจแสดงไม่ครบ — ปิดหรือไม่?')) { this.checked = true; return; }
    if (on) {
      String($card.data('needs') || '').split(',').filter(Boolean).forEach(function (k) { $('.idw-mod[data-mod="' + k + '"] input').prop('checked', true); });
    } else {
      $mods.filter(function () { return String($(this).data('needs') || '').split(',').indexOf(key) > -1; }).find('input').prop('checked', false);
    }
    sync();
  });
  sync();

  // logo picker
  $('.idw-logo-pick [data-pick]').on('click', function (e) {
    e.preventDefault();
    if (!window.wp || !wp.media) return;
    var $w = $(this).closest('.idw-logo-pick');
    var f = wp.media({ title: 'เลือกโลโก้', multiple: false, library: { type: 'image' } });
    f.on('select', function () {
      var a = f.state().get('selection').first().toJSON();
      $w.find('input[type=hidden]').val(a.id);
      $w.find('.pv').html('<img alt="" src="' + ((a.sizes && (a.sizes.thumbnail || a.sizes.medium)) || a).url + '">');
    });
    f.open();
  });
  $('.idw-logo-pick [data-clear]').on('click', function (e) {
    e.preventDefault();
    var $w = $(this).closest('.idw-logo-pick');
    $w.find('input[type=hidden]').val('');
    $w.find('.pv').html('โลโก้');
  });

  // theme choice cards in the wizard
  $('.idw-theme input[type=radio]').on('change', function () {
    $('.idw-theme').removeClass('cur');
    $(this).closest('.idw-theme').addClass('cur');
    $('[data-theme-submit]').prop('disabled', false);
  });

  // busy state on long actions
  $('form[data-busy]').on('submit', function () {
    var $b = $(this).find('button[type=submit],button:not([type])').last();
    $b.prop('disabled', true).data('t', $b.html()).html('<span class="spinner is-active" style="float:none;margin:0 6px 0 0"></span>' + ($(this).data('busy') || 'กำลังทำ…'));
  });

  // theme preview window: desktop / mobile screenshots, then a live preview with this site's content
  $(document).on('click', '[data-theme-preview]', function (e) {
    e.preventDefault(); e.stopPropagation();
    var d = $(this).data('themePreview') || {};
    var $m = $('<div class="idw-pv" role="dialog" aria-modal="true"><div class="idw-pv-box"><div class="idw-pv-head"><b></b><div class="idw-pv-seg"><button type="button" data-v="desktop" class="on">คอมพิวเตอร์</button><button type="button" data-v="mobile">มือถือ</button></div><a class="idw-btn pri sm idw-pv-live">ดูกับเนื้อหาจริงของเว็บนี้</a><button type="button" class="idw-pv-x" aria-label="ปิด">×</button></div><div class="idw-pv-body"><div class="idw-pv-frame"><div class="idw-pv-chrome"><i></i><i></i><i></i><span>ตัวอย่างหน้าแรก</span></div><div class="idw-pv-scroll"><img alt=""></div></div></div><p class="idw-pv-note">ภาพตัวอย่างใช้ข้อมูลสมมติ — “ดูกับเนื้อหาจริง” จะติดตั้งธีม (ยังไม่เปลี่ยน) แล้วเปิดหน้าปรับแต่งให้ดูกับข่าวและหน้าเว็บของคุณ ก่อนกดเผยแพร่</p></div></div>');
    $m.find('.idw-pv-head b').text(d.name || '');
    $m.find('.idw-pv-live').attr('href', d.live || '#');
    function view(v) { var src = v === 'mobile' && d.mobile ? d.mobile : d.desktop; $m.find('.idw-pv-frame').toggleClass('is-mobile', v === 'mobile' && !!d.mobile); $m.find('img').attr('src', src); $m.find('.idw-pv-scroll').scrollTop(0); $m.find('.idw-pv-seg button').removeClass('on').filter('[data-v=' + v + ']').addClass('on'); }
    if (!d.mobile) $m.find('.idw-pv-seg').hide();
    $m.on('click', '.idw-pv-seg button', function () { view($(this).data('v')); });
    function close() { $m.remove(); $(document).off('keydown.idwpv'); }
    $m.on('click', function (ev) { if (ev.target === $m[0]) close(); });
    $m.find('.idw-pv-x').on('click', close);
    $(document).on('keydown.idwpv', function (ev) { if (ev.key === 'Escape') close(); });
    $('body').append($m); view('desktop');
  });
});
