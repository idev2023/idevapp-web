<?php
/**
 * Setup wizard (iDevApp Website → ตั้งค่าเว็บไซต์): ข้อมูลเว็บไซต์ → เลือกแบบ → โมดูล → หน้าเว็บและหมวดข่าว → เสร็จ
 */
defined('ABSPATH') || exit;

function idw_setup_steps() {
    return ['info' => 'ข้อมูลเว็บไซต์', 'theme' => 'เลือกแบบเว็บไซต์', 'modules' => 'เลือกโมดูล', 'content' => 'หน้าเว็บและหมวดข่าว', 'done' => 'เสร็จแล้ว'];
}

add_action('admin_post_idw_setup', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('idw_setup')) wp_die('ไม่มีสิทธิ์', 403);
    $step = sanitize_key($_POST['step'] ?? '');
    $go = function ($next, $extra = []) { wp_safe_redirect(add_query_arg(array_merge(['step' => $next], $extra), admin_url('admin.php?page=idw-setup'))); exit; };
    if ($step === 'info') {
        $f = ['name', 'name_en', 'tagline', 'tagline_en', 'phone', 'email', 'address', 'address_en', 'line', 'facebook', 'hours', 'map'];
        $s = idw_site_info();
        foreach ($f as $k) {
            $v = wp_unslash($_POST[$k] ?? '');
            $s[$k] = in_array($k, ['line', 'facebook'], true) ? esc_url_raw(trim($v)) : (in_array($k, ['address', 'address_en'], true) ? sanitize_textarea_field($v) : sanitize_text_field($v));
        }
        $s['email'] = sanitize_email($s['email']);
        $logo = (int) ($_POST['logo'] ?? 0);
        $s['logo'] = $logo && get_post_type($logo) === 'attachment' ? $logo : 0;
        update_option('idw_site', $s, false);
        $col = sanitize_hex_color(wp_unslash($_POST['brand'] ?? ''));
        if (!empty($_POST['brand_on']) && $col) update_option('idw_brand_color', $col); elseif (empty($_POST['brand_on'])) delete_option('idw_brand_color');
        idw_apply_site_info();
        $go('theme', ['saved' => 1]);
    }
    if ($step === 'content') {
        $msgs = [];
        if (!empty($_POST['cats'])) { $n = idw_create_categories(); $msgs[] = 'หมวดข่าว ' . (int) $n . ' หมวดใหม่'; }
        if (!empty($_POST['pages'])) {
            $r = idw_create_pages(['style' => sanitize_key($_POST['style'] ?? ''), 'menu' => !empty($_POST['menu']), 'replace' => !empty($_POST['replace'])]);
            if (is_wp_error($r)) $go('content', ['err' => rawurlencode($r->get_error_message())]);
            $msgs[] = $r;
        }
        if (!empty($_POST['permalinks']) && get_option('permalink_structure') === '') { update_option('permalink_structure', '/%postname%/'); flush_rewrite_rules(false); $msgs[] = 'ลิงก์แบบอ่านง่าย'; }
        if (!empty($_POST['timezone']) && !get_option('timezone_string')) { update_option('timezone_string', 'Asia/Bangkok'); update_option('date_format', 'j F Y'); update_option('time_format', 'H:i'); update_option('WPLANG', get_option('WPLANG') ?: 'th'); $msgs[] = 'เขตเวลาประเทศไทย'; }
        $setup = (array) get_option('idw_setup', []);
        $setup['content'] = 1;
        $setup['done'] = time();
        update_option('idw_setup', $setup, false);
        set_transient('idw_setup_msg', implode(' · ', array_filter($msgs)), 300);
        $go('done');
    }
    $go('info');
});

function idw_page_setup() {
    if (!current_user_can('manage_options')) wp_die('ไม่มีสิทธิ์');
    $steps = idw_setup_steps();
    $step = sanitize_key($_GET['step'] ?? 'info'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (!isset($steps[$step])) $step = 'info';
    idw_open('ตั้งค่าเว็บไซต์', 'ตอบคำถามไม่กี่ข้อ ระบบจะติดตั้งธีม เปิดโมดูล และสร้างหน้าเว็บให้พร้อมใช้ — กลับมาแก้ภายหลังได้ทุกขั้น');
    $keys = array_keys($steps);
    $pos = array_search($step, $keys, true);
    echo '<ol class="idw-steps">';
    foreach ($keys as $i => $k) echo '<li class="' . ($i === $pos ? 'on' : ($i < $pos ? 'done' : '')) . '"><a href="' . esc_url(admin_url('admin.php?page=idw-setup&step=' . $k)) . '"><span class="n">' . ($i < $pos ? '✓' : $i + 1) . '</span><span class="l">' . esc_html($steps[$k]) . '</span></a></li>';
    echo '</ol>';
    if (!empty($_GET['err'])) idw_note(esc_html(wp_unslash($_GET['err'])), 'err'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
    call_user_func('idw_setup_' . $step);
    idw_close();
}

function idw_setup_form_open($step, $busy = '') {
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"' . ($busy ? ' data-busy="' . esc_attr($busy) . '"' : '') . '>';
    wp_nonce_field('idw_setup');
    echo '<input type="hidden" name="action" value="idw_setup"><input type="hidden" name="step" value="' . esc_attr($step) . '">';
}

function idw_setup_info() {
    $s = idw_site_info();
    $f = function ($k, $label, $type = 'text', $ph = '', $full = false, $hint = '') use ($s) {
        echo '<label class="idw-field' . ($full ? ' full' : '') . '">' . esc_html($label) . ($hint ? ' <small>' . esc_html($hint) . '</small>' : '');
        if ($type === 'textarea') echo '<textarea name="' . esc_attr($k) . '" rows="2" placeholder="' . esc_attr($ph) . '">' . esc_textarea($s[$k]) . '</textarea>';
        else echo '<input type="' . esc_attr($type) . '" name="' . esc_attr($k) . '" value="' . esc_attr($s[$k]) . '" placeholder="' . esc_attr($ph) . '">';
        echo '</label>';
    };
    idw_setup_form_open('info');
    echo '<div class="idw-card"><h2>' . idw_icon('building') . 'ชื่อและโลโก้</h2><p class="d">แสดงที่หัวเว็บ ท้ายเว็บ แท็บเบราว์เซอร์ และผลการค้นหา Google</p><div class="idw-form">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $f('name', 'ชื่อหน่วยงาน *', 'text', 'เช่น โรงพยาบาลตัวอย่าง');
    $f('name_en', 'ชื่อภาษาอังกฤษ', 'text', 'e.g. Example Hospital');
    $f('tagline', 'คำโปรย / สังกัด', 'text', 'เช่น สังกัดกระทรวงสาธารณสุข');
    $f('tagline_en', 'คำโปรยภาษาอังกฤษ', 'text', 'e.g. Ministry of Public Health');
    $logo = (int) $s['logo'];
    echo '<div class="idw-field full">โลโก้ <small>รูปสี่เหลี่ยมจัตุรัส พื้นโปร่งใส อย่างน้อย 256×256 px — ใช้เป็นไอคอนเว็บด้วย</small><div class="idw-logo-pick"><span class="pv">' . ($logo ? wp_get_attachment_image($logo, 'thumbnail') : 'โลโก้') . '</span><input type="hidden" name="logo" value="' . (int) $logo . '"><button type="button" class="idw-btn sm" data-pick>' . idw_icon('image') . 'เลือกรูป</button><button type="button" class="idw-btn sm link" data-clear>นำออก</button></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $bc = idw_brand_color();
    echo '<div class="idw-field full">สีหลักของเว็บ <small>ปุ่ม หัวข้อ และแถบเมนู — เปลี่ยนภายหลังได้ที่ หน้าตา → ปรับแต่ง</small><label style="display:flex;gap:10px;align-items:center;font-weight:400"><input type="checkbox" name="brand_on" value="1"' . checked((bool) $bc, true, false) . '> ใช้สีของหน่วยงาน <input type="color" name="brand" value="' . esc_attr($bc ?: '#0a7d55') . '" style="width:52px;height:36px;padding:0;border-radius:8px"></label></div>';
    echo '</div></div><div class="idw-card"><h2>' . idw_icon('phone') . 'ช่องทางติดต่อ</h2><p class="d">ใช้ในหน้าติดต่อเรา ท้ายเว็บ ปุ่มโทร และแผนที่</p><div class="idw-form">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $f('phone', 'เบอร์โทร', 'tel', '0 7600 0000');
    $f('email', 'อีเมล', 'email', 'info@example.go.th');
    $f('address', 'ที่อยู่', 'textarea', 'เลขที่ ถนน ตำบล อำเภอ จังหวัด รหัสไปรษณีย์', true);
    $f('address_en', 'ที่อยู่ภาษาอังกฤษ', 'textarea', '', true);
    $f('hours', 'เวลาทำการ', 'text', 'จันทร์–ศุกร์ 08:30–16:30 น.');
    $f('map', 'ชื่อสถานที่บน Google Maps', 'text', 'ชื่อตามที่ค้นใน Google Maps หรือพิกัด 8.0,98.0');
    $f('line', 'ลิงก์ LINE Official', 'url', 'https://lin.ee/…');
    $f('facebook', 'ลิงก์ Facebook', 'url', 'https://facebook.com/…');
    echo '</div></div><div class="idw-actions"><span class="sp"></span><button class="idw-btn pri lg">บันทึกแล้วไปขั้นต่อไป →</button></div></form>';
}

function idw_setup_theme() {
    if (!empty($_GET['saved'])) idw_note('บันทึกข้อมูลเว็บไซต์แล้ว'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $cur = get_stylesheet();
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" data-busy="กำลังติดตั้งธีม…">';
    wp_nonce_field('idw_theme');
    echo '<input type="hidden" name="action" value="idw_theme"><input type="hidden" name="do" value="use"><input type="hidden" name="back" value="idw-setup">';
    echo '<div class="idw-sec"><h2>เลือกแบบเว็บไซต์</h2><p class="d">ระบบจะติดตั้งธีม เปิดโมดูลที่ธีมต้องใช้ และใส่ชื่อ โลโก้ เบอร์โทร ที่อยู่ให้อัตโนมัติ — เปลี่ยนแบบภายหลังได้ ข้อมูลข่าวไม่หาย</p></div><div class="idw-themes">';
    foreach (idw_themes() as $slug => $t) {
        $is = $cur === $slug;
        echo '<label class="idw-theme' . ($is ? ' cur' : '') . '"><input type="radio" name="theme" value="' . esc_attr($slug) . '"' . checked($is, true, false) . '>' . ($is ? '<span class="badge idw-chip ok">ใช้อยู่</span>' : '') . '<span class="shot" style="background-image:url(' . esc_url(idw_theme_screenshot($slug)) . ')"></span><span class="in"><h3>' . esc_html($t['name']) . ' <span class="idw-chip">' . esc_html($t['title']) . '</span></h3><p>' . esc_html($t['desc']) . '</p><span class="tags">';
        foreach ($t['tags'] as $tag) echo '<span class="idw-chip info">' . esc_html($tag) . '</span>';
        echo '</span><span class="row">' . idw_theme_preview_button($slug, 'idw-setup') . '</span></span></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
    echo '</div><div class="idw-actions"><a class="idw-btn" href="' . esc_url(admin_url('admin.php?page=idw-setup&step=info')) . '">← ย้อนกลับ</a><span class="sp"></span>';
    echo '<a class="idw-btn link" href="' . esc_url(admin_url('admin.php?page=idw-setup&step=modules')) . '">' . (in_array($cur, IDW_THEMES, true) ? 'ใช้แบบเดิม ข้ามขั้นนี้' : 'ใช้ธีมปัจจุบัน (' . esc_html(wp_get_theme()->get('Name')) . ') ข้ามขั้นนี้') . '</a>';
    echo '<button class="idw-btn pri lg" data-theme-submit' . (in_array($cur, IDW_THEMES, true) ? '' : ' disabled') . '>ติดตั้งและใช้แบบที่เลือก →</button></div></form>';
}

function idw_setup_modules() {
    if (($_GET['done'] ?? '') === 'use') idw_note('ติดตั้งธีมและตั้งค่าเรียบร้อย — เลือกโมดูลที่ต้องการใช้ต่อได้เลย'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $theme = get_stylesheet();
    $t = idw_themes()[$theme] ?? null;
    $checked = idw_enabled_modules();
    $setup = (array) get_option('idw_setup', []);
    if ($t && empty($setup['modules'])) $checked = array_values(array_unique(array_merge($checked, $t['needs'], $t['suggest'])));
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" data-busy="กำลังบันทึก…">';
    wp_nonce_field('idw_modules');
    echo '<input type="hidden" name="action" value="idw_modules"><input type="hidden" name="back" value="setup">';
    idw_note('เปิดเฉพาะส่วนที่ใช้ — ' . ($t ? 'ส่วนที่แนะนำสำหรับ <b>' . esc_html($t['name']) . '</b> เลือกไว้ให้แล้ว · ' : '') . 'โมดูล Pro ทำงานเต็มรูปแบบเมื่อใส่ license');
    idw_module_toggles($checked, $t ? array_merge($t['needs'], $t['suggest']) : []);
    echo '<div class="idw-savebar"><a class="idw-btn" href="' . esc_url(admin_url('admin.php?page=idw-setup&step=theme')) . '">← ย้อนกลับ</a><span class="msg">เปิด <b id="idw-mod-count">' . count($checked) . '</b> โมดูล</span><button class="idw-btn pri">บันทึกแล้วไปขั้นต่อไป →</button></div></form>';
}

function idw_setup_content() {
    $theme = get_stylesheet();
    $ours = in_array($theme, IDW_THEMES, true) || function_exists('ihub_tpl_apply');
    $hubpages = $theme !== 'idevapp-theme-1' && function_exists('ihub_tpl_apply');
    idw_setup_form_open('content', 'กำลังสร้างหน้าเว็บ…');
    echo '<div class="idw-cols"><div><div class="idw-card"><h2>' . idw_icon('file') . 'หน้าเว็บ</h2><p class="d">' . ($ours ? 'สร้างหน้าแรกและหน้าที่เว็บหน่วยงานต้องมีจากแม่แบบ — แก้ข้อความและรูปได้ทุกส่วน' . (!in_array($theme, IDW_THEMES, true) ? ' (ใช้บล็อกของ iDevApp กับธีม ' . esc_html(wp_get_theme()->get('Name')) . ')' : '') : 'เปิดโมดูล “ศูนย์บริการ (Hub)” เพื่อสร้างหน้าเว็บสำเร็จรูปกับธีมนี้ หรือเลือกธีมแบบที่ 1 / แบบที่ 2') . '</p><div class="idw-opts">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<label class="idw-opt"><input type="checkbox" name="pages" value="1"' . ($ours ? ' checked' : ' disabled') . '><span><b>สร้างหน้าเว็บและตั้งหน้าแรก</b><small>' . ($theme === 'idevapp-theme-1' ? 'หน้าแรก เกี่ยวกับเรา วิสัยทัศน์ ผู้บริหาร หน่วยงาน คลินิก ติดต่อเรา และอื่น ๆ' : 'หน้าแรก บริการ นัดหมาย ตารางออกตรวจ ค่าบริการ คำถามพบบ่อย เกี่ยวกับเรา ITA ร้องเรียน ติดต่อเรา') . ' · หน้าที่มีอยู่แล้วจะไม่ถูกเขียนทับ</small></span></label>';
    if ($hubpages) {
        echo '<label class="idw-opt"><input type="radio" name="style" value="gov_service" checked><span><b>เน้นบริการ</b><small>โรงพยาบาล ศูนย์การแพทย์ คลินิก หน่วยบริการประชาชน</small></span></label>';
        echo '<label class="idw-opt"><input type="radio" name="style" value="gov_news"><span><b>เน้นข่าวสาร</b><small>หน่วยงานที่สื่อสารข่าว ประกาศ จัดซื้อจัดจ้าง และ ITA เป็นหลัก</small></span></label>';
        echo '<label class="idw-opt"><input type="checkbox" name="menu" value="1" checked><span><b>สร้างเมนูหลักให้</b><small>แก้ไขได้ที่ หน้าตา → เมนู</small></span></label>';
    }
    if ($theme === 'idevapp-theme-1') echo '<label class="idw-opt"><input type="checkbox" name="replace" value="1"><span><b>เขียนทับหน้าที่สร้างไว้ก่อนแล้ว</b><small>ใช้เมื่อต้องการเริ่มเนื้อหาของธีมใหม่ทั้งหมด</small></span></label>';
    echo '</div></div></div><div><div class="idw-card"><h2>' . idw_icon('news') . 'หมวดข่าว</h2><p class="d">พร้อมแม่แบบเนื้อหาของแต่ละหมวด ใช้กับหน้า “ประกาศข่าว”</p><label class="idw-opt"><input type="checkbox" name="cats" value="1" checked><span><b>สร้างหมวดข่าว</b><small>' . esc_html(implode(' · ', array_column(idw_news_categories(), 0))) . '</small></span></label></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div class="idw-card"><h2>' . idw_icon('gear') . 'ค่าพื้นฐาน</h2><p class="d">แนะนำสำหรับเว็บใหม่</p><div class="idw-opts">';
    echo '<label class="idw-opt"><input type="checkbox" name="permalinks" value="1"' . (get_option('permalink_structure') === '' ? ' checked' : ' disabled') . '><span><b>ลิงก์แบบอ่านง่าย</b><small>' . (get_option('permalink_structure') === '' ? 'เช่น /ติดต่อเรา/ แทน ?p=123' : 'ตั้งไว้แล้ว') . '</small></span></label>';
    echo '<label class="idw-opt"><input type="checkbox" name="timezone" value="1"' . (get_option('timezone_string') ? ' disabled' : ' checked') . '><span><b>เขตเวลาและวันที่แบบไทย</b><small>' . (get_option('timezone_string') ? 'ตั้งไว้แล้ว: ' . esc_html(get_option('timezone_string')) : 'Asia/Bangkok · วันที่ พ.ศ. · เวลา 24 ชม.') . '</small></span></label></div></div></div></div>';
    echo '<div class="idw-actions"><a class="idw-btn" href="' . esc_url(admin_url('admin.php?page=idw-setup&step=modules')) . '">← ย้อนกลับ</a><span class="sp"></span><button class="idw-btn pri lg">สร้างให้เลย →</button></div></form>';
}

function idw_setup_done() {
    $msg = get_transient('idw_setup_msg');
    if ($msg) { delete_transient('idw_setup_msg'); idw_note('เรียบร้อย: ' . esc_html($msg)); }
    echo '<div class="idw-card" style="text-align:center;padding:40px 24px"><div style="width:72px;height:72px;margin:0 auto 14px;border-radius:50%;background:#dcfce7;color:#16a34a;display:grid;place-items:center">' . idw_icon('check') . '</div><h2 style="justify-content:center;font-size:24px">เว็บไซต์พร้อมใช้งานแล้ว</h2><p class="d" style="font-size:15px">ต่อไปลองเขียนประกาศข่าวแรก หรือปรับสี ฟอนต์ และรูปหน้าแรกให้เป็นของหน่วยงาน</p><p style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:18px">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo idw_btn('ดูหน้าเว็บ', home_url('/'), 'pri lg', 'external', ' target="_blank" rel="noopener"'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    if (idw_module_on('announcements')) echo idw_btn('เขียนประกาศข่าว', admin_url('admin.php?page=idw-news&tab=write'), 'acc lg', 'megaphone'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo idw_btn('ปรับแต่งหน้าตา', admin_url('customize.php'), 'lg', 'palette') . idw_btn('ไปที่แดชบอร์ด', admin_url('admin.php?page=idevapp'), 'lg link') . '</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '<div class="idw-grid">';
    $tips = [['palette', 'สีและฟอนต์', 'หน้าตา → ปรับแต่ง เลือกชุดสีและฟอนต์ของหน่วยงาน', admin_url('customize.php')], ['toggle', 'เปิด / ปิดโมดูล', 'เพิ่มนัดหมาย ลงทะเบียน หรือแผนผังองค์กรภายหลังได้', admin_url('admin.php?page=idw-modules')], ['refresh', 'อัปเดตอัตโนมัติ', 'ระบบอัปเดตตัวเองจาก iDevApp ภายใน 12 ชั่วโมง', admin_url('admin.php?page=idw-updates')]];
    foreach ($tips as [$ic, $t, $d, $u]) echo '<a class="idw-mod on" style="text-decoration:none;color:inherit" href="' . esc_url($u) . '"><span class="ic">' . idw_icon($ic) . '</span><span class="tx"><b>' . esc_html($t) . '</b><p>' . esc_html($d) . '</p></span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</div>';
}
