<?php
/**
 * Themes that come with this plugin (themes/<slug>.zip): install, switch on and set up.
 *  แบบที่ 1 (idevapp-theme-1): hospital website made from WordPress blocks, uses the "ระบบเว็บโรงพยาบาล" module.
 *  แบบที่ 2 (idevapp-theme-2): medical centre / clinic website made from the Hub blocks, uses the "ศูนย์บริการ (Hub)" module.
 */
defined('ABSPATH') || exit;

function idw_themes() {
    return [
        'idevapp-theme-1' => [
            'name' => 'แบบที่ 1', 'title' => 'เว็บโรงพยาบาล / หน่วยงานราชการ',
            'desc' => 'หน้าแรกพร้อมข่าวแยกหมวด (ประชาสัมพันธ์ จัดซื้อจัดจ้าง ราคากลาง รับสมัครงาน) ITA เมนูใหญ่ ตารางแพทย์ และหน้าเว็บมาตรฐานโรงพยาบาลรัฐ แก้ไขได้ตรงหน้าด้วยบล็อก',
            'needs' => ['hospital', 'hub', 'services'], 'suggest' => ['schedule', 'campus-map', 'org-chart'],
            'tags' => ['ข่าวแยกหมวด', 'จัดซื้อจัดจ้าง / ITA', 'เมนูใหญ่', 'หน้าเว็บสำเร็จรูป'],
        ],
        'idevapp-theme-2' => [
            'name' => 'แบบที่ 2', 'title' => 'ศูนย์การแพทย์ / คลินิก / หน่วยบริการ',
            'desc' => 'หน้าแรกเน้นบริการ ปุ่มนัดหมาย ลงทะเบียน สถานะเปิด-ปิด ทีมแพทย์ อัตราค่าบริการ และคำถามพบบ่อย ออกแบบหน้าด้วยบล็อกของ Hub สองภาษาในตัว',
            'needs' => ['hub'], 'suggest' => ['schedule', 'appointments', 'registration'],
            'tags' => ['เน้นบริการ', 'นัดหมาย / ลงทะเบียน', 'สองภาษา', 'บล็อกออกแบบหน้า'],
        ],
    ];
}

/** Modules the active theme cannot work without. */
function idw_theme_needs() {
    $t = idw_themes()[get_stylesheet()] ?? null;
    return $t ? $t['needs'] : [];
}

function idw_theme_zip($slug) { return IDW_DIR . 'themes/' . $slug . '.zip'; }
function idw_theme_screenshot($slug) { return IDW_URL . 'themes/' . $slug . '.png'; }
function idw_theme_preview_urls($slug) {
    $u = [];
    foreach (['desktop' => '-preview.jpg', 'mobile' => '-mobile.jpg'] as $k => $suf) if (is_file(IDW_DIR . 'themes/' . $slug . $suf)) $u[$k] = IDW_URL . 'themes/' . $slug . $suf;
    return $u;
}
/** "ดูตัวอย่าง" button + data for the preview window (assets/admin.js). */
function idw_theme_preview_button($slug, $back) {
    $t = idw_themes()[$slug];
    $p = idw_theme_preview_urls($slug);
    $live = wp_nonce_url(admin_url('admin-post.php?action=idw_theme_preview&theme=' . $slug . '&back=' . $back), 'idw_theme_preview');
    return '<button type="button" class="idw-btn" data-theme-preview="' . esc_attr(wp_json_encode(['name' => $t['name'] . ' · ' . $t['title'], 'desktop' => $p['desktop'] ?? idw_theme_screenshot($slug), 'mobile' => $p['mobile'] ?? '', 'live' => $live, 'slug' => $slug])) . '">' . idw_icon('eye') . 'ดูตัวอย่าง</button>';
}
add_action('admin_post_idw_theme_preview', function () {
    if (!current_user_can('switch_themes') || !check_admin_referer('idw_theme_preview')) wp_die('ไม่มีสิทธิ์', 403);
    $slug = sanitize_key($_GET['theme'] ?? '');
    $back = sanitize_key($_GET['back'] ?? 'idw-themes');
    $r = idw_install_theme($slug);
    if (is_wp_error($r)) { wp_safe_redirect(add_query_arg('err', rawurlencode($r->get_error_message()), admin_url('admin.php?page=' . ($back === 'idw-setup' ? 'idw-setup&step=theme' : 'idw-themes')))); exit; }
    idw_enable_modules(idw_themes()[$slug]['needs'] ?? []);
    wp_safe_redirect(add_query_arg(['theme' => $slug, 'return' => rawurlencode(admin_url('admin.php?page=' . ($back === 'idw-setup' ? 'idw-setup&step=theme' : 'idw-themes')))], admin_url('customize.php')));
    exit;
});
function idw_theme_bundled_version($slug) {
    $f = IDW_DIR . 'themes/' . $slug . '.json';
    $j = is_file($f) ? json_decode((string) file_get_contents($f), true) : null;
    return (string) ($j['version'] ?? '');
}
/** '' = not installed */
function idw_theme_installed_version($slug) {
    $t = wp_get_theme($slug);
    return $t->exists() ? (string) $t->get('Version') : '';
}

/** Install (or update to) the theme that comes with this plugin. true or WP_Error. */
function idw_install_theme($slug) {
    if (!isset(idw_themes()[$slug])) return new WP_Error('idw_theme', 'ไม่พบธีม');
    if (!current_user_can('install_themes')) return new WP_Error('idw_theme', 'ไม่มีสิทธิ์ติดตั้งธีม');
    $have = idw_theme_installed_version($slug);
    $bundled = idw_theme_bundled_version($slug);
    if ($have !== '' && ($bundled === '' || version_compare($have, $bundled, '>='))) return true;
    $zip = idw_theme_zip($slug);
    if (!is_file($zip)) return new WP_Error('idw_theme', 'ไม่พบไฟล์ธีมในปลั๊กอิน');
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/misc.php';
    require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    // the upgrader deletes the package after unpacking: give it a copy
    $tmp = wp_tempnam($slug . '.zip');
    if (!$tmp || !copy($zip, $tmp)) return new WP_Error('idw_theme', 'คัดลอกไฟล์ธีมไม่ได้ (ตรวจสิทธิ์เขียนโฟลเดอร์ชั่วคราว)');
    $up = new Theme_Upgrader(new Automatic_Upgrader_Skin());
    $r = $up->install($tmp, ['overwrite_package' => true, 'clear_update_cache' => true]);
    if (is_file($tmp)) @unlink($tmp); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
    if (is_wp_error($r)) return $r;
    if (!$r) {
        $msg = method_exists($up->skin, 'get_upgrade_messages') ? implode(' ', (array) $up->skin->get_upgrade_messages()) : '';
        return new WP_Error('idw_theme', 'ติดตั้งธีมไม่สำเร็จ ' . $msg);
    }
    wp_clean_themes_cache();
    return true;
}

/** Install, switch on, switch on the modules it needs and set it up on the next page load. */
function idw_use_theme($slug) {
    $r = idw_install_theme($slug);
    if (is_wp_error($r)) return $r;
    $t = idw_themes()[$slug];
    idw_enable_modules($t['needs']);
    switch_theme($slug);
    update_option('idw_theme_setup', $slug, false); // the theme's own code is loaded on the next request
    $setup = (array) get_option('idw_setup', []);
    $setup['theme'] = $slug;
    update_option('idw_setup', $setup, false);
    return true;
}

/* Next page load after switching: the theme and its modules are loaded now. */
add_action('admin_init', function () {
    $slug = get_option('idw_theme_setup');
    if (!$slug || get_stylesheet() !== $slug) return;
    delete_option('idw_theme_setup');
    idw_apply_site_info();
}, 5);

/** Site details entered in the wizard → WordPress, the active theme and the Hub. */
function idw_site_info() {
    return wp_parse_args((array) get_option('idw_site', []), ['name' => get_option('blogname'), 'name_en' => '', 'tagline' => get_option('blogdescription'), 'tagline_en' => '', 'logo' => 0, 'phone' => '', 'email' => '', 'address' => '', 'address_en' => '', 'line' => '', 'facebook' => '', 'hours' => '', 'map' => '']);
}

function idw_apply_site_info() {
    $s = idw_site_info();
    if ($s['name'] !== '') update_option('blogname', $s['name']);
    update_option('blogdescription', $s['tagline']);
    $logo = (int) $s['logo'];
    if ($logo && get_post_type($logo) === 'attachment') {
        set_theme_mod('custom_logo', $logo);
        if (!get_option('site_icon')) update_option('site_icon', $logo);
    }
    $theme = get_stylesheet();
    if ($theme === 'idevapp-theme-1') {
        foreach (['hos_phone' => 'phone', 'hos_email' => 'email', 'hos_address' => 'address', 'hos_line' => 'line', 'hos_facebook' => 'facebook', 'hos_map_query' => 'map'] as $mod => $k) if ($s[$k] !== '') set_theme_mod($mod, $s[$k]);
        if ($s['hours'] !== '') set_theme_mod('hos_hours', $s['hours']);
        if ($s['tagline'] !== '') set_theme_mod('hos_tagline', $s['tagline']);
        set_theme_mod('hos_hero_eyebrow', $s['name']);
    }
    if (function_exists('ihub_settings')) {
        $h = (array) get_option('ihub_settings', []);
        $map = ['site_name' => 'name', 'site_name_en' => 'name_en', 'site_tagline' => 'tagline', 'site_tagline_en' => 'tagline_en', 'hero_title' => 'name', 'hero_title_en' => 'name_en', 'phone' => 'phone', 'address' => 'address', 'address_en' => 'address_en', 'line_url' => 'line', 'map_query' => 'map'];
        foreach ($map as $hk => $k) if ($s[$k] !== '') $h[$hk] = $s[$k];
        update_option('ihub_settings', $h);
    }
    // other modules that keep their own copy of the address / phone
    if (idw_module_on('maps') && ($s['address'] !== '' || $s['map'] !== '')) {
        $m = (array) get_option('idev_maps', []);
        if (empty($m['locations'])) { $m['locations'] = [['name' => $s['name'], 'name_en' => $s['name_en'], 'map' => $s['map'] !== '' ? $s['map'] : $s['address'], 'destination' => '', 'address' => $s['address'], 'address_en' => $s['address_en'], 'phone' => $s['phone']]]; update_option('idev_maps', $m); }
    }
}

/** News categories every theme here understands (theme 1 finds them by name, the Hub by slug). */
function idw_news_categories() {
    return [
        'news' => ['ข่าวประชาสัมพันธ์', '<h3>รายละเอียด</h3><p>…</p><h3>วัน เวลา และสถานที่</h3><p>…</p><h3>ติดต่อสอบถาม</h3><p>…</p>'],
        'activity' => ['ภาพกิจกรรม', '<h3>กิจกรรม</h3><p>…</p><h3>ภาพกิจกรรม</h3><p>…</p>'],
        'announcement' => ['ประกาศ', '<h3>เรื่อง</h3><p>…</p><h3>สาระสำคัญ</h3><p>…</p><p>ประกาศ ณ วันที่ …</p>'],
        'procurement' => ['จัดซื้อจัดจ้าง', '<h3>ประเภท</h3><p>แผน / ประกาศเชิญชวน / ผลการพิจารณา / สัญญา</p><h3>รายละเอียดโครงการ</h3><p>วงเงินงบประมาณ … บาท · วิธีจัดซื้อจัดจ้าง …</p>'],
        'bidding' => ['ประกาศประกวดราคา', '<h3>โครงการ</h3><p>…</p><h3>วงเงินงบประมาณ</h3><p>… บาท</p><h3>กำหนดยื่นข้อเสนอ</h3><p>…</p>'],
        'midprice' => ['ประกาศราคากลาง', '<h3>โครงการ</h3><p>…</p><h3>ราคากลาง</h3><p>… บาท</p>'],
        'results' => ['สรุปผลการจัดซื้อจัดจ้าง', '<h3>โครงการ</h3><p>…</p><h3>ผู้ได้รับการคัดเลือก</h3><p>…</p><h3>ราคาที่ตกลง</h3><p>… บาท</p>'],
        'jobs' => ['ข่าวรับสมัครงาน', '<h3>ตำแหน่งที่รับสมัคร</h3><p>…</p><h3>คุณสมบัติ</h3><ul><li>…</li></ul><h3>วันรับสมัคร</h3><p>…</p><h3>วิธีสมัคร</h3><p>…</p>'],
    ];
}

/** Create the news categories (with their article templates). Returns how many were new. */
function idw_create_categories() {
    $n = 0;
    foreach (idw_news_categories() as $slug => [$name, $tpl]) {
        $t = term_exists($slug, 'category');
        if (!$t) { $t = wp_insert_term($name, 'category', ['slug' => $slug]); if (!is_wp_error($t)) $n++; }
        if (is_wp_error($t) || !$t) continue;
        $tid = (int) (is_array($t) ? $t['term_id'] : $t);
        foreach (['idw_news_template', 'ihub_news_template'] as $meta) if (!get_term_meta($tid, $meta, true)) update_term_meta($tid, $meta, $tpl);
    }
    // the default "Uncategorized" becomes the general news category
    $default = (int) get_option('default_category');
    $news = get_term_by('slug', 'news', 'category');
    if ($news && $default && $default !== (int) $news->term_id) {
        $u = get_term($default, 'category');
        if ($u && !is_wp_error($u) && in_array($u->slug, ['uncategorized', 'ไม่มีหมวดหมู่'], true) && !$u->count) update_option('default_category', (int) $news->term_id);
    }
    return $n;
}

/** Pages of the active theme. $opts: style (theme 2 template gov_service|gov_news), menu, replace. Returns a message or WP_Error. */
function idw_create_pages($opts = []) {
    $theme = get_stylesheet();
    if ($theme === 'idevapp-theme-1') {
        if (!function_exists('hos_build_wysiwyg_pages')) return new WP_Error('idw_pages', 'เปิดโมดูล “ระบบเว็บโรงพยาบาล” ก่อน');
        $r = hos_build_wysiwyg_pages(!empty($opts['replace']));
        if (is_wp_error($r)) return $r;
        return 'สร้างหน้าเว็บของแบบที่ 1 แล้ว' . (is_array($r) && $r ? ' (' . count($r) . ' หน้า)' : '');
    }
    if ($theme === 'idevapp-theme-2' || function_exists('ihub_tpl_apply')) { // any other theme: the Hub blocks work everywhere
        if (!function_exists('ihub_tpl_apply')) return new WP_Error('idw_pages', 'เปิดโมดูล “ศูนย์บริการ (Hub)” ก่อน');
        $made = ihub_tpl_apply(in_array($opts['style'] ?? '', ['gov_service', 'gov_news'], true) ? $opts['style'] : 'gov_service', 'publish', true, !empty($opts['menu']));
        return is_wp_error($made) ? $made : 'สร้างหน้าเว็บแล้ว (' . (int) $made . ' หน้าใหม่)';
    }
    return new WP_Error('idw_pages', 'เปิดโมดูล “ศูนย์บริการ (Hub)” เพื่อสร้างหน้าเว็บสำเร็จรูปกับธีมนี้ หรือเลือกธีมแบบที่ 1 / แบบที่ 2');
}

add_action('admin_post_idw_theme', function () {
    if (!current_user_can('switch_themes') || !check_admin_referer('idw_theme')) wp_die('ไม่มีสิทธิ์', 403);
    $slug = sanitize_key($_POST['theme'] ?? '');
    $do = sanitize_key($_POST['do'] ?? 'use');
    $back = sanitize_key($_POST['back'] ?? 'idw-themes');
    if ($do === 'preview') {
        // live preview with this website's own content: install (not switch on), the modules it needs, then the Customizer
        $r = idw_install_theme($slug);
        if (!is_wp_error($r)) {
            idw_enable_modules(idw_themes()[$slug]['needs'] ?? []);
            wp_safe_redirect(add_query_arg(['theme' => $slug, 'return' => rawurlencode(admin_url('admin.php?page=' . ($back === 'idw-setup' ? 'idw-setup&step=theme' : 'idw-themes')))], admin_url('customize.php')));
            exit;
        }
    } else {
        $r = $do === 'install' ? idw_install_theme($slug) : idw_use_theme($slug);
    }
    $args = is_wp_error($r) ? ['err' => rawurlencode($r->get_error_message())] : ['done' => $do];
    if ($back === 'idw-setup') $args['step'] = is_wp_error($r) ? 'theme' : 'modules';
    wp_safe_redirect(add_query_arg($args, admin_url('admin.php?page=' . ($back === 'idw-setup' ? 'idw-setup' : 'idw-themes'))));
    exit;
});

/* ---------- brand colour (one colour → both themes; Customizer: สีหลักของเว็บ) ---------- */

function idw_brand_color() { return (string) sanitize_hex_color(get_option('idw_brand_color', '')); }
function idw_color_mix($hex, $to, $t) {
    $a = sscanf(ltrim($hex, '#'), '%02x%02x%02x');
    $b = sscanf(ltrim($to, '#'), '%02x%02x%02x');
    if (!$a || !$b || in_array(null, $a, true)) return $hex;
    return sprintf('#%02x%02x%02x', round($a[0] + ($b[0] - $a[0]) * $t), round($a[1] + ($b[1] - $a[1]) * $t), round($a[2] + ($b[2] - $a[2]) * $t));
}
add_action('wp_head', function () {
    $c = idw_brand_color();
    if (!$c) return;
    $d = idw_color_mix($c, '#000000', .28);
    $s = idw_color_mix($c, '#ffffff', .9);
    $l = idw_color_mix($c, '#ffffff', .35);
    $theme = get_stylesheet();
    echo '<style id="idw-brand-var">' . esc_html(":root{--idw-brand:{$c}}") . "</style>\n"; // modules (e.g. service cards) use it in every theme
    if (!in_array($theme, IDW_THEMES, true)) return; // other themes: only the iDevApp blocks use the colour (see the Hub module)
    $css = $theme === 'idevapp-theme-2'
        ? ":root{--teal:{$c};--teal-dark:{$d}}"
        : ":root{--g:{$c};--g-dark:{$d};--g-soft:{$s};--g-mint:{$l};--teal:{$c};--teal-dark:{$d}}";
    echo '<style id="idw-brand">' . esc_html($css) . "</style>\n";
}, 99);
add_action('customize_register', function ($wp) {
    $wp->add_section('idw_brand', ['title' => 'สีหลักของเว็บ', 'priority' => 25, 'description' => 'ธีมแบบที่ 1 / แบบที่ 2: สีของปุ่ม หัวข้อ แถบเมนู และการ์ด · ธีมอื่น: สีของบล็อก iDevApp — เว้นว่างเพื่อใช้สีเดิม']);
    $wp->add_setting('idw_brand_color', ['type' => 'option', 'default' => '', 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'refresh']);
    $wp->add_control(new WP_Customize_Color_Control($wp, 'idw_brand_color', ['label' => 'สีหลัก', 'section' => 'idw_brand']));
});
