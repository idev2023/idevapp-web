<?php
/**
 * Updates from GitHub (github.com/idev2023/idevapp-web): this plugin and the themes "แบบที่ 1" / "แบบที่ 2".
 * The plugin and the themes say "Update URI: https://github.com/idev2023/idevapp-web", so WordPress asks this file
 * (filters update_plugins_github.com / update_themes_github.com). The list of versions is updates/website.json
 * in that repository. Checked twice a day (so a new version installs within 12 hours) or with the button on
 * iDevApp Website → อัปเดต.
 */
defined('ABSPATH') || exit;

if (!defined('IDW_UPDATE_MANIFEST')) define('IDW_UPDATE_MANIFEST', 'https://raw.githubusercontent.com/idev2023/idevapp-web/main/updates/website.json');
define('IDW_THEMES', ['idevapp-theme-1', 'idevapp-theme-2']);

function idw_manifest($force = false) {
    $cached = get_site_transient('idw_manifest');
    if (!$force && is_array($cached)) return $cached;
    // a query string so the GitHub CDN does not hand back an old copy after a forced check
    $url = $force ? add_query_arg('t', time(), IDW_UPDATE_MANIFEST) : IDW_UPDATE_MANIFEST;
    $res = wp_remote_get($url, ['timeout' => 15, 'headers' => ['Accept' => 'application/json', 'Cache-Control' => 'no-cache'], 'user-agent' => 'iDevApp-Website/' . IDW_VERSION . '; ' . home_url('/')]);
    $code = is_wp_error($res) ? 0 : (int) wp_remote_retrieve_response_code($res);
    $data = $code === 200 ? json_decode(wp_remote_retrieve_body($res), true) : null;
    if (!is_array($data)) {
        $data = ['plugins' => [], 'themes' => [], 'error' => is_wp_error($res) ? $res->get_error_message() : 'HTTP ' . $code, 'checked' => time()];
        set_site_transient('idw_manifest', $data, HOUR_IN_SECONDS);
        return $data;
    }
    $data += ['plugins' => [], 'themes' => []];
    $data['checked'] = time();
    set_site_transient('idw_manifest', $data, 6 * HOUR_IN_SECONDS);
    return $data;
}

function idw_update_info($kind, $slug) {
    $i = idw_manifest()[$kind][$slug] ?? null;
    if (!is_array($i) || empty($i['version']) || empty($i['package'])) return null;
    $host = wp_parse_url($i['package'], PHP_URL_HOST);
    if (wp_parse_url($i['package'], PHP_URL_SCHEME) !== 'https' || !in_array($host, ['raw.githubusercontent.com', 'github.com', 'objects.githubusercontent.com', 'idevapp.me'], true)) return null;
    return $i;
}

add_filter('update_plugins_github.com', function ($update, $plugin_data, $plugin_file) {
    if ($plugin_file !== IDW_BASENAME) return $update;
    $i = idw_update_info('plugins', 'idevapp-website');
    if (!$i) return $update;
    return [
        'id' => 'github.com/idev2023/idevapp-web/idevapp-website', 'slug' => 'idevapp-website', 'plugin' => $plugin_file, 'version' => $i['version'],
        'url' => 'https://idevapp.me/', 'package' => $i['package'], 'tested' => $i['tested'] ?? '', 'requires' => $i['requires'] ?? '6.2', 'requires_php' => $i['requires_php'] ?? '7.4',
        'icons' => ['svg' => 'https://idevapp.me/favicon.svg'], 'autoupdate' => idw_auto_update_on(),
    ];
}, 10, 3);

add_filter('update_themes_github.com', function ($update, $theme_data, $stylesheet) {
    if (!in_array($stylesheet, IDW_THEMES, true)) return $update;
    $i = idw_update_info('themes', $stylesheet);
    if (!$i) return $update;
    return ['id' => 'github.com/idev2023/idevapp-web/' . $stylesheet, 'theme' => $stylesheet, 'version' => $i['version'], 'url' => 'https://idevapp.me/', 'package' => $i['package'], 'tested' => $i['tested'] ?? '', 'requires' => $i['requires'] ?? '', 'requires_php' => $i['requires_php'] ?? '', 'autoupdate' => idw_auto_update_on()];
}, 10, 3);

/* "View details" */
add_filter('plugins_api', function ($result, $action, $args) {
    if ($action !== 'plugin_information' || ($args->slug ?? '') !== 'idevapp-website') return $result;
    $i = idw_update_info('plugins', 'idevapp-website');
    if (!$i) return $result;
    return (object) [
        'name' => 'iDevApp Website', 'slug' => 'idevapp-website', 'version' => $i['version'], 'author' => '<a href="https://idevapp.me/">iDevApp</a>',
        'homepage' => 'https://idevapp.me/', 'requires' => $i['requires'] ?? '6.2', 'requires_php' => $i['requires_php'] ?? '7.4', 'tested' => $i['tested'] ?? '',
        'last_updated' => $i['date'] ?? '', 'download_link' => $i['package'],
        'sections' => ['description' => 'ระบบเว็บไซต์ครบชุดในปลั๊กอินเดียว โดย iDevApp', 'changelog' => wp_kses_post($i['changelog'] ?? '')],
    ];
}, 20, 3);

/* Automatic updates: on unless turned off on the อัปเดต page. */
function idw_auto_update_on() { return get_site_option('idw_auto_update', '1') === '1'; }
add_filter('auto_update_plugin', function ($update, $item) {
    return (($item->plugin ?? '') === IDW_BASENAME || ($item->slug ?? '') === 'idevapp-website') ? idw_auto_update_on() : $update;
}, 30, 2);
add_filter('auto_update_theme', function ($update, $item) {
    return in_array($item->theme ?? '', IDW_THEMES, true) ? idw_auto_update_on() : $update;
}, 30, 2);

/* Twice a day: fresh version list, then let WordPress install what is new. */
function idw_updater_schedule() {
    if (!wp_next_scheduled('idw_update_check')) wp_schedule_event(time() + 300, 'twicedaily', 'idw_update_check');
}
add_action('init', 'idw_updater_schedule');
add_action('idw_update_check', function () { idw_check_now(idw_auto_update_on()); });

/** Check GitHub now; with $install, install the new versions straight away. Returns what is new. */
function idw_check_now($install = false) {
    idw_manifest(true);
    if (!function_exists('wp_update_plugins')) require_once ABSPATH . 'wp-includes/update.php';
    delete_site_transient('update_plugins');
    delete_site_transient('update_themes');
    wp_update_plugins();
    wp_update_themes();
    $new = idw_pending_updates();
    if ($install && $new && function_exists('wp_maybe_auto_update')) wp_maybe_auto_update();
    update_site_option('idw_last_check', time());
    return $new;
}

/** [['kind' => plugin|theme, 'slug', 'name', 'from', 'to', 'url' (update now)]] */
function idw_pending_updates() {
    $out = [];
    $p = get_site_transient('update_plugins');
    if (isset($p->response[IDW_BASENAME])) {
        $out[] = ['kind' => 'plugin', 'slug' => 'idevapp-website', 'name' => 'iDevApp Website', 'from' => IDW_VERSION, 'to' => $p->response[IDW_BASENAME]->new_version ?? '',
            'url' => wp_nonce_url(self_admin_url('update.php?action=upgrade-plugin&plugin=' . rawurlencode(IDW_BASENAME)), 'upgrade-plugin_' . IDW_BASENAME)];
    }
    $t = get_site_transient('update_themes');
    foreach (IDW_THEMES as $slug) {
        if (empty($t->response[$slug])) continue;
        $theme = wp_get_theme($slug);
        $out[] = ['kind' => 'theme', 'slug' => $slug, 'name' => $theme->get('Name'), 'from' => $theme->get('Version'), 'to' => $t->response[$slug]['new_version'] ?? '',
            'url' => wp_nonce_url(self_admin_url('update.php?action=upgrade-theme&theme=' . rawurlencode($slug)), 'upgrade-theme_' . $slug)];
    }
    return $out;
}

add_action('admin_post_idw_check_updates', function () {
    if (!current_user_can('update_plugins') || !check_admin_referer('idw_check_updates')) wp_die('ไม่มีสิทธิ์', 403);
    $new = idw_check_now(false);
    wp_safe_redirect(admin_url('admin.php?page=idw-updates&checked=' . count($new)));
    exit;
});
add_action('admin_post_idw_auto_update', function () {
    if (!current_user_can('update_plugins') || !check_admin_referer('idw_auto_update')) wp_die('ไม่มีสิทธิ์', 403);
    update_site_option('idw_auto_update', ($_POST['on'] ?? '') === '1' ? '1' : '0');
    wp_safe_redirect(admin_url('admin.php?page=idw-updates&saved=1'));
    exit;
});
