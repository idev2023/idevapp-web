<?php
/**
 * อัปเดตอย่างปลอดภัย: ก่อนอัปเดตปลั๊กอิน / ธีมของ iDevApp จะสำรองเวอร์ชันเดิมไว้ หลังอัปเดตตรวจว่าเว็บยังเปิดได้
 * (หน้าเว็บและหลังบ้าน) ถ้าเว็บล่ม (HTTP 500 / critical error) จะย้อนกลับเป็นเวอร์ชันเดิมให้ทันที
 * ใช้ทั้งการอัปเดตอัตโนมัติ 12 ชั่วโมง และการกดอัปเดตเอง
 */
defined('ABSPATH') || exit;

function idw_safe_dir() { return trailingslashit(WP_CONTENT_DIR) . 'upgrade/idw-backup/'; }

/** Is this upgrade one of ours? → [kind, slug, path] */
function idw_safe_target($extra) {
    if (!empty($extra['plugin']) && $extra['plugin'] === IDW_BASENAME) return ['plugin', 'idevapp-website', WP_PLUGIN_DIR . '/' . dirname(IDW_BASENAME)];
    if (!empty($extra['theme']) && in_array($extra['theme'], IDW_THEMES, true)) return ['theme', $extra['theme'], get_theme_root($extra['theme']) . '/' . $extra['theme']];
    return null;
}

/** Can the site still open? true = yes · false = broken · null = cannot tell (loopback blocked) */
function idw_site_health() {
    // during a bulk update WordPress shows "maintenance" to every request — step it aside for the check only
    $mf = ABSPATH . '.maintenance';
    $moved = file_exists($mf) && @rename($mf, $mf . '.idw'); // phpcs:ignore
    try {
        return idw_site_health_probe();
    } finally {
        if ($moved) @rename($mf . '.idw', $mf); // phpcs:ignore
    }
}
function idw_site_health_probe() {
    $bad = false;
    $seen = false;
    foreach ([add_query_arg('idw_health', wp_rand(1000, 99999), home_url('/')), admin_url('admin-ajax.php?action=idw_health')] as $u) {
        $r = wp_remote_get($u, ['timeout' => 20, 'redirection' => 3, 'sslverify' => false, 'cookies' => [], 'headers' => ['Cache-Control' => 'no-cache']]);
        if (is_wp_error($r)) continue;
        $seen = true;
        $code = (int) wp_remote_retrieve_response_code($r);
        $body = (string) wp_remote_retrieve_body($r);
        if ($code >= 500 || stripos($body, 'critical error') !== false || preg_match('/Fatal error|Parse error/i', $body)) $bad = true;
    }
    return $seen ? !$bad : null;
}
add_action('wp_ajax_nopriv_idw_health', function () { wp_send_json_success('ok'); });
add_action('wp_ajax_idw_health', function () { wp_send_json_success('ok'); });

/* 1) before installing: keep a copy of the version now in use */
add_filter('upgrader_pre_install', function ($ok, $extra) {
    global $wp_filesystem;
    $t = idw_safe_target((array) $extra);
    if (!$t || is_wp_error($ok) || !$wp_filesystem || !is_dir($t[2])) return $ok;
    $dst = idw_safe_dir() . $t[1];
    if ($wp_filesystem->is_dir($dst)) $wp_filesystem->delete($dst, true);
    wp_mkdir_p($dst);
    $root = idw_safe_dir();
    if (!file_exists($root . '.htaccess')) @file_put_contents($root . '.htaccess', "Require all denied\nDeny from all\n"); // phpcs:ignore -- the copy is never served
    if (!file_exists($root . 'index.php')) @file_put_contents($root . 'index.php', "<?php // Silence\n"); // phpcs:ignore
    $c = copy_dir($t[2], $dst);
    $GLOBALS['idw_safe_backup'][$t[1]] = is_wp_error($c) ? '' : $dst;
    if (is_wp_error($c)) error_log('iDevApp safe update: backup failed — ' . $c->get_error_message()); // phpcs:ignore
    // before: the site must be healthy now, else a later failure is not caused by the update
    $GLOBALS['idw_safe_before'][$t[1]] = idw_site_health();
    return $ok;
}, 10, 2);

/* 2) after installing: check the site, put the old version back if it broke */
add_filter('upgrader_install_package_result', function ($result, $extra) {
    global $wp_filesystem;
    $t = idw_safe_target((array) $extra);
    if (!$t || is_wp_error($result)) return $result;
    $backup = $GLOBALS['idw_safe_backup'][$t[1]] ?? '';
    if (($GLOBALS['idw_safe_before'][$t[1]] ?? null) === false || !$backup) return $result; // was already broken / no copy
    if (function_exists('wp_opcache_invalidate_directory')) wp_opcache_invalidate_directory($t[2]);
    sleep(3); // PHP may keep the old code for a moment (opcache revalidate), then the new version is really in use
    $health = idw_site_health();
    if ($health === false) { sleep(3); $health = idw_site_health(); } // a second look before undoing anything
    if ($health !== false) {
        update_site_option('idw_safe_last', ['ok' => 1, 'slug' => $t[1], 'time' => time(), 'checked' => $health === true]);
        do_action('litespeed_purge_all'); // visitors get the new version at once
        if (function_exists('wp_cache_flush')) wp_cache_flush();
        return $result;
    }
    // broken: restore
    $dest = $t[2];
    if ($wp_filesystem && $wp_filesystem->is_dir($dest)) $wp_filesystem->delete($dest, true);
    wp_mkdir_p($dest);
    $c = copy_dir($backup, $dest);
    if (function_exists('wp_opcache_invalidate_directory')) wp_opcache_invalidate_directory($dest);
    update_site_option('idw_safe_last', ['ok' => 0, 'slug' => $t[1], 'time' => time(), 'restored' => !is_wp_error($c)]);
    if (function_exists('idw_sec_log')) idw_sec_log('update', 'อัปเดต ' . $t[1] . ' ทำให้เว็บเปิดไม่ได้ — ย้อนกลับเป็นเวอร์ชันเดิมแล้ว');
    return new WP_Error('idw_rollback', 'เวอร์ชันใหม่ทำให้เว็บเปิดไม่ได้บนเซิร์ฟเวอร์นี้ ระบบย้อนกลับเป็นเวอร์ชันเดิมให้แล้ว เว็บใช้งานได้ตามปกติ — แจ้ง iDevApp พร้อมเวอร์ชัน PHP ของเซิร์ฟเวอร์');
}, 20, 2);

/* notice after an automatic rollback */
add_action('admin_notices', function () {
    $l = get_site_option('idw_safe_last');
    if (!is_array($l) || !empty($l['ok']) || !empty($l['seen']) || !current_user_can('update_plugins')) return;
    echo '<div class="notice notice-warning is-dismissible"><p><b>iDevApp:</b> อัปเดต ' . esc_html($l['slug']) . ' เมื่อ ' . esc_html(wp_date('j M Y H:i', (int) $l['time'])) . ' ทำให้เว็บเปิดไม่ได้ ระบบ' . (!empty($l['restored']) ? 'ย้อนกลับเป็นเวอร์ชันเดิมให้แล้ว เว็บใช้งานได้ตามปกติ' : 'พยายามย้อนกลับแต่ไม่สำเร็จ — ติดตั้งไฟล์เดิมจาก wp-content/upgrade/idw-backup/') . '</p></div>';
    $l['seen'] = 1;
    update_site_option('idw_safe_last', $l);
});

/* do not offer an update this server cannot run */
add_filter('site_transient_update_plugins', function ($t) {
    if (is_object($t) && isset($t->response[IDW_BASENAME])) {
        $r = $t->response[IDW_BASENAME];
        $php = is_object($r) ? ($r->requires_php ?? '') : '';
        if ($php && version_compare(PHP_VERSION, $php, '<')) unset($t->response[IDW_BASENAME]);
    }
    return $t;
});
