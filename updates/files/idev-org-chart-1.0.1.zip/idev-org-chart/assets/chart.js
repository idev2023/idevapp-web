/* iDev Org Chart: open/close branches, centre wide charts. */
(function () {
  document.addEventListener('click', (e) => {
    const t = e.target.closest('.idev-oc-toggle');
    if (t) { const li = t.parentElement; const closed = li.classList.toggle('is-closed'); t.setAttribute('aria-expanded', closed ? 'false' : 'true'); return; }
    const b = e.target.closest('.idev-oc-tools [data-oc]');
    if (!b) return;
    const root = b.closest('.idev-oc');
    const close = b.dataset.oc === 'collapse';
    root.querySelectorAll('li.has-kids').forEach((li, i) => {
      const top = !li.parentElement.closest('li');
      li.classList.toggle('is-closed', close && !top);
      const tg = li.querySelector(':scope > .idev-oc-toggle'); if (tg) tg.setAttribute('aria-expanded', close && !top ? 'false' : 'true');
    });
  });
  /* Wide charts shrink to fit (down to 60%); beyond that they scroll sideways, centred. */
  function fit() {
    document.querySelectorAll('.idev-oc-scroll').forEach((s) => {
      const tree = s.querySelector('.idev-oc-tree');
      if (!tree) return;
      tree.style.zoom = '';
      if (getComputedStyle(tree).display !== 'flex') return; // phone list layout
      const need = tree.scrollWidth, have = s.clientWidth - 8;
      if (need > have) {
        const z = Math.max(0.6, have / need);
        if ('zoom' in tree.style) tree.style.zoom = z.toFixed(3);
      }
      if (s.scrollWidth > s.clientWidth) s.scrollLeft = (s.scrollWidth - s.clientWidth) / 2;
    });
  }
  let t;
  const later = () => { clearTimeout(t); t = setTimeout(fit, 120); };
  window.addEventListener('resize', later);
  document.addEventListener('click', (e) => { if (e.target.closest('.idev-oc-toggle,.idev-oc-tools')) setTimeout(fit, 0); });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fit); else fit();
  window.addEventListener('load', fit);
})();
