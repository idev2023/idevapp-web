/* iDev Org Chart editor: a tree of people/units with indent, reorder, "reports to", photos. */
(function ($) {
  const root = document.getElementById('idev-oc-editor');
  const input = document.getElementById('idev-oc-input');
  if (!root || !input) return;
  const T = (window.IDEV_OC && IDEV_OC.t) || {};
  let nodes = [];
  try { nodes = JSON.parse(root.dataset.nodes || '[]'); } catch (e) { nodes = []; }
  const open = new Set();
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const newId = () => 'n' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const byId = (id) => nodes.find((n) => n.id === id);
  const kids = (pid) => nodes.filter((n) => (n.parent || '') === pid);
  const sync = () => { input.value = JSON.stringify(nodes.map(({ photo_url, ...n }) => n)); };
  const descendants = (id) => { const out = []; kids(id).forEach((k) => { out.push(k.id); out.push(...descendants(k.id)); }); return out; };
  function ordered(pid = '', depth = 0, out = []) { kids(pid).forEach((n) => { out.push([n, depth]); ordered(n.id, depth + 1, out); }); return out; }

  function field(n, k, label, type) {
    const v = esc(n[k]);
    if (type === 'textarea') return `<label>${esc(label)}<textarea data-k="${k}" rows="2">${v}</textarea></label>`;
    return `<label>${esc(label)}<input data-k="${k}" value="${v}"${type === 'url' ? ' type="url" placeholder="https://"' : ''}></label>`;
  }
  function render() {
    sync();
    const list = ordered();
    let html = '<div class="idev-oc-ed-tools"><button type="button" class="button button-primary" data-act="add-top">＋ ' + esc(T.add_top) + '</button>'
      + (list.length ? ' <button type="button" class="button-link" data-act="open-all">' + esc(T.expand) + '</button> · <button type="button" class="button-link" data-act="close-all">' + esc(T.collapse) + '</button>' : '') + '</div>';
    if (!list.length) html += '<p class="idev-oc-ed-empty">' + esc(T.empty) + '</p>';
    html += '<ol class="idev-oc-ed">';
    list.forEach(([n, depth]) => {
      const sibs = kids(n.parent || '');
      const i = sibs.indexOf(n);
      const bad = new Set([n.id, ...descendants(n.id)]);
      const parents = '<option value="">' + esc(T.top) + '</option>' + ordered().filter(([p]) => !bad.has(p.id)).map(([p, d]) => `<option value="${esc(p.id)}"${p.id === n.parent ? ' selected' : ''}>${'— '.repeat(d)}${esc(p.name || p.role || T.untitled)}</option>`).join('');
      const isOpen = open.has(n.id);
      html += `<li class="idev-oc-ed-node${isOpen ? ' is-open' : ''}${n.assistant ? ' is-assistant' : ''}" data-id="${esc(n.id)}" style="--d:${depth}">
        <div class="idev-oc-ed-head">
          <button type="button" class="idev-oc-ed-sum" data-act="toggle" aria-expanded="${isOpen}">
            ${n.photo_url ? `<img src="${esc(n.photo_url)}" alt="">` : `<span class="idev-oc-ed-dot" style="background:${esc(n.color || '#c3c4c7')}"></span>`}
            <span><strong>${esc(n.name || T.untitled)}</strong><small>${esc(n.role)}${n.assistant ? ' · ' + esc(T.assistant) : ''}</small></span>
          </button>
          <span class="idev-oc-ed-btns">
            <button type="button" class="button button-small" data-act="add-child">＋ ${esc(T.add_child)}</button>
            <button type="button" class="button button-small" data-act="up" title="${esc(T.up)}"${i ? '' : ' disabled'}>↑</button>
            <button type="button" class="button button-small" data-act="down" title="${esc(T.down)}"${i < sibs.length - 1 ? '' : ' disabled'}>↓</button>
            <button type="button" class="button-link-delete" data-act="remove">${esc(T.remove)}</button>
          </span>
        </div>
        <div class="idev-oc-ed-body"${isOpen ? '' : ' hidden'}>
          <div class="idev-oc-ed-photo">${n.photo_url ? `<img src="${esc(n.photo_url)}" alt="">` : '<span class="idev-oc-ed-nophoto"></span>'}
            <button type="button" class="button" data-act="photo">${esc(T.pick)}</button>${n.photo ? ` <button type="button" class="button-link-delete" data-act="nophoto">${esc(T.nophoto)}</button>` : ''}</div>
          <div class="idev-oc-ed-grid">
            ${field(n, 'name', T.name)}${field(n, 'name_en', T.name_en)}
            ${field(n, 'role', T.role)}${field(n, 'role_en', T.role_en)}
            ${field(n, 'note', T.note)}${field(n, 'note_en', T.note_en)}
            ${field(n, 'link', T.link, 'url')}
            <label>${esc(T.under)}<select data-k="parent">${parents}</select></label>
            <label>${esc(T.color)}<span class="idev-oc-ed-color"><input type="color" data-k="color" value="${esc(n.color || '#0f766e')}"${n.color ? '' : ' data-unset="1"'}> <button type="button" class="button-link" data-act="nocolor">↺</button></span></label>
            <label class="idev-oc-ed-check"><input type="checkbox" data-k="assistant"${n.assistant ? ' checked' : ''}> ${esc(T.assistant)}</label>
          </div>
        </div></li>`;
    });
    root.innerHTML = html + '</ol>';
  }
  function add(parent) {
    const n = { id: newId(), parent, name: '', name_en: '', role: '', role_en: '', note: '', note_en: '', photo: 0, photo_url: '', color: '', link: '', assistant: 0 };
    // insert after the last sibling so order stays natural
    nodes.push(n);
    open.add(n.id);
    render();
    const el = root.querySelector(`[data-id="${n.id}"] input[data-k="name"]`); if (el) el.focus();
  }
  function move(n, dir) {
    const sibs = kids(n.parent || '');
    const j = sibs.indexOf(n) + dir;
    if (j < 0 || j >= sibs.length) return;
    const a = nodes.indexOf(n), b = nodes.indexOf(sibs[j]);
    [nodes[a], nodes[b]] = [nodes[b], nodes[a]];
  }
  root.addEventListener('input', (e) => {
    const k = e.target.dataset.k; if (!k) return;
    const n = byId(e.target.closest('[data-id]').dataset.id);
    if (k === 'assistant') n.assistant = e.target.checked ? 1 : 0;
    else if (k === 'color') { n.color = e.target.value; e.target.removeAttribute('data-unset'); }
    else if (k === 'parent') { n.parent = e.target.value; render(); return; }
    else n[k] = e.target.value;
    if (k === 'name' || k === 'role') { const h = e.target.closest('li').querySelector('.idev-oc-ed-sum'); h.querySelector('strong').textContent = n.name || T.untitled; h.querySelector('small').textContent = n.role; }
    sync();
  });
  root.addEventListener('change', (e) => { if (e.target.dataset.k === 'parent' || e.target.dataset.k === 'assistant') { const n = byId(e.target.closest('[data-id]').dataset.id); if (e.target.dataset.k === 'parent') n.parent = e.target.value; render(); } });
  root.addEventListener('click', (e) => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    e.preventDefault();
    const act = b.dataset.act;
    if (act === 'add-top') return add('');
    if (act === 'open-all') { nodes.forEach((n) => open.add(n.id)); return render(); }
    if (act === 'close-all') { open.clear(); return render(); }
    const n = byId(b.closest('[data-id]').dataset.id);
    if (act === 'toggle') { open.has(n.id) ? open.delete(n.id) : open.add(n.id); return render(); }
    if (act === 'add-child') return add(n.id);
    if (act === 'up' || act === 'down') { move(n, act === 'up' ? -1 : 1); return render(); }
    if (act === 'remove') { if (!confirm(T.confirm)) return; const gone = new Set([n.id, ...descendants(n.id)]); nodes = nodes.filter((x) => !gone.has(x.id)); return render(); }
    if (act === 'nocolor') { n.color = ''; return render(); }
    if (act === 'nophoto') { n.photo = 0; n.photo_url = ''; return render(); }
    if (act === 'photo') {
      const frame = wp.media({ title: T.pick, multiple: false, library: { type: 'image' } });
      frame.on('select', () => { const a = frame.state().get('selection').first().toJSON(); n.photo = a.id; n.photo_url = (a.sizes && (a.sizes.thumbnail || a.sizes.medium || a.sizes.full) || a).url; render(); });
      frame.open();
    }
  });
  render();
})(jQuery);
