<?php
defined('WP_UNINSTALL_PLUGIN') || exit;
// Charts are your content: they stay unless you delete them under iDevApp → Org charts.
