<?php
defined('ABSPATH') || exit;

function idev_oc_meta($id, $k, $default = '') { $v = get_post_meta($id, "_idev_{$k}", true); return $v === '' ? $default : $v; }
function idev_oc_styles() { return ['people' => __('People (photo cards)', 'idev-org-chart'), 'units' => __('Units (coloured boxes)', 'idev-org-chart'), 'compact' => __('Compact (name and position only)', 'idev-org-chart')]; }

add_action('init', function () {
    load_plugin_textdomain('idev-org-chart', false, dirname(plugin_basename(IDEV_OC_FILE)) . '/languages');
    register_post_type('idev_orgchart', [
        'labels' => ['name' => __('Org charts', 'idev-org-chart'), 'singular_name' => __('Org chart', 'idev-org-chart'), 'add_new' => __('Add chart', 'idev-org-chart'), 'add_new_item' => __('Add org chart', 'idev-org-chart'), 'edit_item' => __('Edit org chart', 'idev-org-chart'), 'all_items' => __('Org charts', 'idev-org-chart'), 'not_found' => __('No charts yet', 'idev-org-chart')],
        'public' => false, 'show_ui' => true, 'show_in_menu' => 'idevapp', 'supports' => ['title'], 'map_meta_cap' => true,
    ]);
    wp_register_style('idev-oc', plugins_url('assets/chart.css', IDEV_OC_FILE), [], IDEV_OC_VERSION);
    wp_register_script('idev-oc', plugins_url('assets/chart.js', IDEV_OC_FILE), [], IDEV_OC_VERSION, true);
    idev_register_plugin('idev-org-chart', ['name' => 'iDev Org Chart', 'version' => IDEV_OC_VERSION, 'description' => __('Executive and department charts.', 'idev-org-chart'), 'settings' => admin_url('edit.php?post_type=idev_orgchart'), 'docs' => 'https://idevapp.me/plugins/idev-org-chart']);
    $charts = ['0' => __('— choose —', 'idev-org-chart')];
    foreach (get_posts(['post_type' => 'idev_orgchart', 'numberposts' => 100, 'post_status' => 'publish']) as $c) $charts[(string) $c->ID] = $c->post_title;
    idev_register_block('idev/org-chart', __('Org chart', 'idev-org-chart'), 'networking', __('Executive or department chart.', 'idev-org-chart'), [
        'id' => ['select', __('Chart', 'idev-org-chart'), '0', $charts],
        'title' => ['toggle', __('Show chart name', 'idev-org-chart'), true],
    ], function ($a) { return idev_orgchart_render((int) $a['id'], ['title' => !empty($a['title'])]); });
});
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_OC_FILE, admin_url('edit.php?post_type=idev_orgchart'), 'https://idevapp.me/plugins/idev-org-chart'); });

/* ---------- Data ---------- */

/** Flat node list: id, parent, name, name_en, role, role_en, photo (attachment id), color, link, note, note_en. */
function idev_orgchart_nodes($chart_id) {
    $nodes = json_decode((string) get_post_meta($chart_id, '_idev_nodes', true), true);
    return is_array($nodes) ? array_values(array_filter($nodes, 'is_array')) : [];
}
function idev_oc_clean_nodes($list) {
    $clean = []; $ids = [];
    foreach ((array) $list as $n) {
        if (!is_array($n)) continue;
        $id = preg_replace('/[^a-z0-9]/', '', strtolower((string) ($n['id'] ?? '')));
        if ($id === '' || isset($ids[$id])) continue;
        $ids[$id] = true;
        $clean[] = [
            'id' => $id, 'parent' => preg_replace('/[^a-z0-9]/', '', strtolower((string) ($n['parent'] ?? ''))),
            'name' => mb_substr(sanitize_text_field($n['name'] ?? ''), 0, 150), 'name_en' => mb_substr(sanitize_text_field($n['name_en'] ?? ''), 0, 150),
            'role' => mb_substr(sanitize_text_field($n['role'] ?? ''), 0, 200), 'role_en' => mb_substr(sanitize_text_field($n['role_en'] ?? ''), 0, 200),
            'note' => mb_substr(sanitize_text_field($n['note'] ?? ''), 0, 300), 'note_en' => mb_substr(sanitize_text_field($n['note_en'] ?? ''), 0, 300),
            'photo' => (int) ($n['photo'] ?? 0), 'color' => sanitize_hex_color($n['color'] ?? '') ?: '', 'link' => idev_safe_url($n['link'] ?? ''),
            'assistant' => empty($n['assistant']) ? 0 : 1,
        ];
    }
    // Parents must exist and must not create loops.
    $byId = array_column($clean, null, 'id');
    foreach ($clean as &$n) {
        if (!isset($byId[$n['parent']]) || $n['parent'] === $n['id']) { $n['parent'] = ''; continue; }
        $seen = [$n['id'] => true]; $p = $n['parent'];
        while ($p !== '' && isset($byId[$p])) { if (isset($seen[$p])) { $n['parent'] = ''; break; } $seen[$p] = true; $p = $byId[$p]['parent']; }
    }
    return $clean;
}

/* ---------- Editor ---------- */

add_filter('enter_title_here', function ($t, $post) { return $post->post_type === 'idev_orgchart' ? __('Chart name, e.g. "Executive board"', 'idev-org-chart') : $t; }, 10, 2);
add_action('add_meta_boxes_idev_orgchart', function () {
    add_meta_box('idev_oc_nodes', __('People and units', 'idev-org-chart'), 'idev_oc_nodes_box', 'idev_orgchart', 'normal', 'high');
    add_meta_box('idev_oc_opts', __('Display', 'idev-org-chart'), 'idev_oc_opts_box', 'idev_orgchart', 'side');
    add_meta_box('idev_oc_preview', __('Preview', 'idev-org-chart'), function ($post) {
        echo $post->post_status === 'auto-draft' ? '<p>' . esc_html__('Save to see the preview.', 'idev-org-chart') . '</p>' : '<div class="idev-oc-adminpreview">' . wp_kses_post(idev_orgchart_render($post->ID, ['title' => false, 'preview' => true])) . '</div><p class="description">' . esc_html__('Shortcode:', 'idev-org-chart') . ' <code>[idev_orgchart id="' . (int) $post->ID . '"]</code></p>';
    }, 'idev_orgchart', 'normal');
});
function idev_oc_opts_box($post) {
    wp_nonce_field('idev_oc', 'idev_oc_nonce');
    $style = idev_oc_meta($post->ID, 'style', 'people');
    echo '<div class="idev-form"><label>' . esc_html__('Style', 'idev-org-chart') . '<select name="idev_oc[style]">';
    foreach (idev_oc_styles() as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($style, $k, false) . '>' . esc_html($l) . '</option>';
    echo '</select></label><label>' . esc_html__('Main colour', 'idev-org-chart') . '<input type="color" name="idev_oc[color]" value="' . esc_attr(idev_oc_meta($post->ID, 'color', '#0f766e')) . '"></label>';
    echo '<label>' . esc_html__('Open levels at start', 'idev-org-chart') . '<input type="number" min="1" max="10" name="idev_oc[depth]" value="' . esc_attr(idev_oc_meta($post->ID, 'depth', '3')) . '"><small>' . esc_html__('Deeper branches open with a + button.', 'idev-org-chart') . '</small></label>';
    echo '<label>' . esc_html__('On phones', 'idev-org-chart') . '<select name="idev_oc[mobile]"><option value="list"' . selected(idev_oc_meta($post->ID, 'mobile', 'list'), 'list', false) . '>' . esc_html__('List with lines (recommended)', 'idev-org-chart') . '</option><option value="scroll"' . selected(idev_oc_meta($post->ID, 'mobile', 'list'), 'scroll', false) . '>' . esc_html__('Same tree, scroll sideways', 'idev-org-chart') . '</option></select></label>';
    echo '<label class="idev-check"><input type="checkbox" name="idev_oc[wide]" value="1"' . checked(idev_oc_meta($post->ID, 'wide', '1'), '1', false) . '> ' . esc_html__('Wider than the text column', 'idev-org-chart') . '</label>';
    echo '<label>' . esc_html__('Chart name (English)', 'idev-org-chart') . '<input name="idev_oc[title_en]" value="' . esc_attr(idev_oc_meta($post->ID, 'title_en')) . '"></label></div>';
}
function idev_oc_nodes_box($post) {
    $nodes = idev_orgchart_nodes($post->ID);
    foreach ($nodes as &$n) { $n['photo_url'] = $n['photo'] ? (wp_get_attachment_image_url($n['photo'], 'thumbnail') ?: '') : ''; }
    echo '<div id="idev-oc-editor" data-nodes="' . esc_attr(wp_json_encode($nodes)) . '"></div><input type="hidden" name="idev_oc_nodes" id="idev-oc-input">';
}
add_action('admin_enqueue_scripts', function ($hook) {
    if (!in_array($hook, ['post.php', 'post-new.php'], true) || (get_current_screen()->post_type ?? '') !== 'idev_orgchart') return;
    wp_enqueue_media();
    wp_enqueue_style('idev-oc');
    wp_enqueue_script('idev-oc');
    wp_enqueue_style('idev-oc-admin', plugins_url('assets/admin.css', IDEV_OC_FILE), [], IDEV_OC_VERSION);
    wp_enqueue_script('idev-oc-admin', plugins_url('assets/admin.js', IDEV_OC_FILE), ['jquery'], IDEV_OC_VERSION, true);
    wp_localize_script('idev-oc-admin', 'IDEV_OC', ['t' => [
        'add_top' => __('Add top person / unit', 'idev-org-chart'), 'add_child' => __('Add below', 'idev-org-chart'), 'remove' => __('Delete', 'idev-org-chart'),
        'confirm' => __('Delete this item and everything below it?', 'idev-org-chart'), 'up' => __('Move up', 'idev-org-chart'), 'down' => __('Move down', 'idev-org-chart'),
        'name' => __('Name (Thai)', 'idev-org-chart'), 'name_en' => __('Name (English)', 'idev-org-chart'), 'role' => __('Position / unit (Thai)', 'idev-org-chart'), 'role_en' => __('Position / unit (English)', 'idev-org-chart'),
        'note' => __('Extra line (Thai)', 'idev-org-chart'), 'note_en' => __('Extra line (English)', 'idev-org-chart'), 'link' => __('Link (profile page)', 'idev-org-chart'),
        'photo' => __('Photo', 'idev-org-chart'), 'pick' => __('Choose photo', 'idev-org-chart'), 'nophoto' => __('Remove photo', 'idev-org-chart'),
        'color' => __('Box colour', 'idev-org-chart'), 'assistant' => __('Assistant / secretary (shown at the side)', 'idev-org-chart'),
        'under' => __('Reports to', 'idev-org-chart'), 'top' => __('— top level —', 'idev-org-chart'), 'empty' => __('Start with the top person or unit, then add the people below.', 'idev-org-chart'),
        'untitled' => __('(no name)', 'idev-org-chart'), 'more' => __('More', 'idev-org-chart'), 'expand' => __('Expand all', 'idev-org-chart'), 'collapse' => __('Collapse all', 'idev-org-chart'),
    ]]);
});
add_action('save_post_idev_orgchart', function ($id) {
    if (!isset($_POST['idev_oc_nonce']) || !wp_verify_nonce(sanitize_key($_POST['idev_oc_nonce']), 'idev_oc')) return;
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $id)) return;
    $in = isset($_POST['idev_oc']) ? map_deep(wp_unslash((array) $_POST['idev_oc']), 'sanitize_text_field') : [];
    update_post_meta($id, '_idev_style', array_key_exists($in['style'] ?? '', idev_oc_styles()) ? $in['style'] : 'people');
    update_post_meta($id, '_idev_color', sanitize_hex_color($in['color'] ?? '') ?: '#0f766e');
    update_post_meta($id, '_idev_depth', (string) max(1, min(10, (int) ($in['depth'] ?? 3))));
    update_post_meta($id, '_idev_mobile', ($in['mobile'] ?? '') === 'scroll' ? 'scroll' : 'list');
    update_post_meta($id, '_idev_wide', empty($in['wide']) ? '0' : '1');
    update_post_meta($id, '_idev_title_en', sanitize_text_field($in['title_en'] ?? ''));
    if (isset($_POST['idev_oc_nodes'])) {
        $nodes = json_decode(wp_unslash((string) $_POST['idev_oc_nodes']), true); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON, every field is sanitized in idev_oc_clean_nodes()
        if (is_array($nodes)) update_post_meta($id, '_idev_nodes', wp_slash(wp_json_encode(idev_oc_clean_nodes($nodes), JSON_UNESCAPED_UNICODE)));
    }
});
add_filter('manage_idev_orgchart_posts_columns', function ($c) { return ['cb' => $c['cb'], 'title' => $c['title'], 'idev_count' => __('Items', 'idev-org-chart'), 'idev_code' => __('Shortcode', 'idev-org-chart'), 'date' => $c['date']]; });
add_action('manage_idev_orgchart_posts_custom_column', function ($col, $id) {
    if ($col === 'idev_count') echo (int) count(idev_orgchart_nodes($id));
    if ($col === 'idev_code') echo '<code>[idev_orgchart id="' . (int) $id . '"]</code>';
}, 10, 2);

/* ---------- Output ---------- */

function idev_orgchart_render($chart_id, $args = []) {
    $chart = get_post($chart_id);
    if (!$chart || $chart->post_type !== 'idev_orgchart' || (empty($args['preview']) && $chart->post_status !== 'publish')) return '';
    $nodes = idev_orgchart_nodes($chart_id);
    if (!$nodes) return '';
    wp_enqueue_style('idev-oc');
    wp_enqueue_script('idev-oc');
    $kids = [];
    foreach ($nodes as $n) $kids[$n['parent']][] = $n;
    $style = idev_oc_meta($chart_id, 'style', 'people');
    $depth = (int) idev_oc_meta($chart_id, 'depth', '3');
    $title = idev_pick($chart->post_title, idev_oc_meta($chart_id, 'title_en'));
    $wide = idev_oc_meta($chart_id, 'wide', '1') === '1' && empty($args['preview']);
    $html = '<div class="idev-oc idev-oc-' . esc_attr($style) . ' idev-oc-m-' . esc_attr(idev_oc_meta($chart_id, 'mobile', 'list')) . ($wide ? ' idev-oc-wide alignwide' : '') . '" style="--idev-oc:' . esc_attr(idev_oc_meta($chart_id, 'color', '#0f766e')) . '">';
    if (($args['title'] ?? true) && $title !== '') $html .= '<h2 class="idev-oc-title">' . esc_html($title) . '</h2>';
    $html .= '<div class="idev-oc-tools"><button type="button" data-oc="expand">' . esc_html__('Expand all', 'idev-org-chart') . '</button><button type="button" data-oc="collapse">' . esc_html__('Collapse all', 'idev-org-chart') . '</button></div>';
    $html .= '<div class="idev-oc-scroll" tabindex="0" role="region" aria-label="' . esc_attr($title ?: __('Org chart', 'idev-org-chart')) . '"><ul class="idev-oc-tree">' . idev_oc_branch('', $kids, 1, $depth, $style) . '</ul></div></div>';
    return $html;
}
function idev_oc_branch($parent, $kids, $level, $depth, $style) {
    $out = '';
    foreach ($kids[$parent] ?? [] as $n) {
        if ($n['assistant'] && $parent !== '') continue; // rendered beside its manager
        $out .= idev_oc_node_li($n, $kids, $level, $depth, $style);
    }
    return $out;
}
function idev_oc_node_li($n, $kids, $level, $depth, $style) {
    $children = array_values(array_filter($kids[$n['id']] ?? [], function ($c) { return !$c['assistant']; }));
    $assistants = array_values(array_filter($kids[$n['id']] ?? [], function ($c) { return $c['assistant']; }));
    $open = $level < $depth;
    $li = '<li class="' . ($children ? 'has-kids' : '') . ($children && !$open ? ' is-closed' : '') . '">';
    $li .= '<div class="idev-oc-row">' . idev_oc_card($n, $style) . '</div>';
    if ($assistants) {
        $li .= '<div class="idev-oc-assist' . ($children ? ' has-stem' : '') . '"><span class="idev-oc-assist-pad"></span><span class="idev-oc-stem"></span><span class="idev-oc-assist-list">';
        foreach ($assistants as $a) $li .= '<span class="idev-oc-assistant">' . idev_oc_card($a, $style) . '</span>';
        $li .= '</span></div>';
    }
    if ($children) {
        /* translators: %d: number of people or units below this one */
        $li .= '<button type="button" class="idev-oc-toggle" aria-expanded="' . ($open ? 'true' : 'false') . '" aria-label="' . esc_attr(sprintf(__('Show or hide %d below', 'idev-org-chart'), count($children))) . '"><span class="idev-oc-plus">+' . count($children) . '</span><span class="idev-oc-minus">−</span></button>';
        $li .= '<ul>' . idev_oc_branch($n['id'], $kids, $level + 1, $depth, $style) . '</ul>';
    }
    return $li . '</li>';
}
function idev_oc_card($n, $style) {
    $name = idev_pick($n['name'], $n['name_en']);
    $role = idev_pick($n['role'], $n['role_en']);
    $note = idev_pick($n['note'], $n['note_en']);
    $photo = '';
    if ($style === 'people') {
        $img = $n['photo'] ? wp_get_attachment_image($n['photo'], 'medium', false, ['class' => 'idev-oc-photo', 'loading' => 'lazy', 'alt' => $name]) : '';
        $photo = $img ?: '<span class="idev-oc-photo idev-oc-initial" aria-hidden="true">' . esc_html(idev_oc_initial($name ?: $role)) . '</span>';
    }
    $tag = $n['link'] ? 'a' : 'div';
    $href = $n['link'] ? ' href="' . esc_url(idev_href($n['link'])) . '"' : '';
    $color = $n['color'] ? ' style="--idev-oc-node:' . esc_attr($n['color']) . '"' : '';
    $body = ($name !== '' ? '<strong>' . esc_html($name) . '</strong>' : '') . ($role !== '' ? '<span class="idev-oc-role">' . esc_html($role) . '</span>' : '') . ($note !== '' ? '<small>' . esc_html($note) . '</small>' : '');
    return '<' . $tag . $href . ' class="idev-oc-card"' . $color . '>' . $photo . '<span class="idev-oc-text">' . $body . '</span></' . $tag . '>';
}

add_shortcode('idev_orgchart', function ($a) { $a = shortcode_atts(['id' => 0, 'title' => 'yes'], $a); return idev_orgchart_render((int) $a['id'], ['title' => $a['title'] !== 'no']); });

/** First letter for a placeholder avatar: skips titles and Thai leading vowels (เ แ โ ใ ไ). */
function idev_oc_initial($text) {
    $t = preg_replace('/^(นางสาว|นาย|นาง|น\.ส\.|นพ\.|พญ\.|ทพญ\.|ทพ\.|ภก\.|ภญ\.|ดร\.|ผศ\.|รศ\.|ศ\.|Mrs?\.?|Ms\.?|Dr\.?|Prof\.?)\s*/u', '', trim((string) $text));
    $t = preg_replace('/^[เแโใไ]/u', '', $t);
    return mb_strtoupper(mb_substr($t, 0, 1)) ?: '?';
}
