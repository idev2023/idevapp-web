=== iDev Org Chart ===
Contributors: idevapp2023
Donate link: https://idevapp.me/
Tags: org chart, organization, executives
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Executive and department charts with photos, positions, colours, assistants and collapsible branches; a tree on computers and a clean list on phones.

== Description ==

Executive and department charts with photos, positions, colours, assistants and collapsible branches; a tree on computers and a clean list on phones.

= Features =

* Tree editor with photos and "reports to"
* People, units or compact style
* Shrinks to fit, list layout on phones
* Block and shortcode [idev_orgchart id=""]

Thai and English interface. Works with any theme. Part of the iDevApp plugin suite for hospitals and clinics — all iDev plugins appear under the **iDevApp** menu.

== Installation ==

1. Plugins → Add New → Upload Plugin, choose the zip, Install, Activate.
2. Open **iDevApp** in the admin menu for settings.

== Changelog ==

= 1.0.0 =
* First release.
