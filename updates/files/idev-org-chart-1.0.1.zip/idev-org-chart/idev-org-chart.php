<?php
/**
 * Plugin Name:       iDev Org Chart
 * Plugin URI:        https://idevapp.me/plugins/idev-org-chart
 * Description:       Organisation charts for executives, departments and committees: photos, positions, colours, collapsible branches, top-down tree on computers and a clean list on phones. Thai / English.
 * Version:           1.0.1
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-org-chart
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// Loaded once: the same plugin may also be inside an iDevApp package (I-Clinic / I-Drug) or a Pro version.
if (defined('IDEV_OC_VERSION')) return;

define('IDEV_OC_VERSION', '1.0.1');
define('IDEV_OC_FILE', __FILE__);
require_once __DIR__ . '/common/idev-common.php';
require_once __DIR__ . '/includes/chart.php';
