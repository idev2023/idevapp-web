<?php
/**
 * Records, validation, public submission, ID photos and e-mails. The HOSxP connector API is in iDev Patient Registration Pro.
 */
defined('ABSPATH') || exit;

function idev_medreg_table() { global $wpdb; return $wpdb->prefix . 'idev_medreg'; }

function idev_medreg_statuses() {
    return [
        'pending' => __('Waiting for review', 'idev-patient-registration'),
        'approved' => __('Approved, waiting for HOSxP', 'idev-patient-registration'),
        'synced' => __('HN issued', 'idev-patient-registration'),
        'error' => __('HOSxP could not save', 'idev-patient-registration'),
        'rejected' => __('Not approved', 'idev-patient-registration'),
    ];
}

function idev_medreg_install() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta('CREATE TABLE ' . idev_medreg_table() . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  ref varchar(24) NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'pending',
  doc_type varchar(12) NOT NULL DEFAULT 'thai_id',
  method varchar(12) NOT NULL DEFAULT 'photo',
  search_key char(64) NOT NULL DEFAULT '',
  data longtext NOT NULL,
  photo varchar(120) NOT NULL DEFAULT '',
  hn varchar(20) NOT NULL DEFAULT '',
  message text NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  synced_at datetime NULL,
  emailed_at datetime NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY ref (ref),
  KEY status (status),
  KEY search_key (search_key)
) " . $wpdb->get_charset_collate() . ';');
    if (!get_role('idev_registrar')) add_role('idev_registrar', __('Medical records staff', 'idev-patient-registration'), ['read' => true, 'idev_medreg' => true]);
    $admin = get_role('administrator');
    if ($admin && !$admin->has_cap('idev_medreg')) $admin->add_cap('idev_medreg');
    // Andaman Hub staff role keeps working.
    $old = get_role('ah_registrar');
    if ($old && !$old->has_cap('idev_medreg')) $old->add_cap('idev_medreg');
    if (!wp_next_scheduled('idev_medreg_cleanup')) wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'idev_medreg_cleanup');
    update_option('idev_medreg_db', IDEV_MEDREG_VERSION, false);
}
add_action('plugins_loaded', function () { if (get_option('idev_medreg_db') !== IDEV_MEDREG_VERSION) idev_medreg_install(); });

add_action('init', function () {
    load_plugin_textdomain('idev-patient-registration', false, dirname(plugin_basename(IDEV_MEDREG_FILE)) . '/languages');
    idev_register_plugin('idev-patient-registration', ['name' => 'iDev Patient Registration', 'version' => IDEV_MEDREG_VERSION, 'description' => __('Online new-patient registration with HOSxP and patient cards.', 'idev-patient-registration'), 'settings' => admin_url('admin.php?page=idev-medreg-settings'), 'docs' => 'https://idevapp.me/plugins/idev-patient-registration']);
});
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_MEDREG_FILE, admin_url('admin.php?page=idev-medreg-settings'), 'https://idevapp.me/plugins/idev-patient-registration'); });

/* ---------- Records ---------- */

function idev_medreg_get($id) {
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_medreg_table() . ' WHERE id=%d', $id), ARRAY_A);
    if (!$row) return null;
    $plain = idev_medreg_decrypt($row['data']);
    $row['readable'] = $plain !== null;
    $row['person'] = $plain !== null ? (json_decode($plain, true) ?: []) : [];
    return $row;
}
function idev_medreg_save_person($id, $person, $extra = [], $touch = true) {
    global $wpdb;
    $fields = ['data' => idev_medreg_encrypt(wp_json_encode($person, JSON_UNESCAPED_UNICODE))] + ($touch ? ['updated_at' => current_time('mysql', true)] : []) + $extra;
    $wpdb->update(idev_medreg_table(), $fields, ['id' => (int) $id]);
}
function idev_medreg_log(&$person, $text) {
    $user = wp_get_current_user();
    $person['_log'][] = [gmdate('c'), $user && $user->ID ? $user->user_login : 'system', $text];
}
function idev_medreg_name($p) { return trim(($p['prefix'] ?? '') . ' ' . ($p['first_name'] ?? '') . ' ' . ($p['last_name'] ?? '')); }
function idev_medreg_name_en($p) { return trim(($p['first_name_en'] ?? '') . ' ' . ($p['last_name_en'] ?? '')); }
function idev_medreg_salutation($p, $en) {
    if ($en) return sprintf('Dear %s,', idev_medreg_name_en($p) ?: idev_medreg_name($p));
    return 'เรียน ' . (($p['prefix'] ?? '') !== '' ? idev_medreg_name($p) : 'คุณ' . idev_medreg_name($p));
}

/* ---------- Validation ---------- */

function idev_valid_thai_id($cid) {
    if (!preg_match('/^\d{13}$/', (string) $cid)) return false;
    $sum = 0;
    for ($i = 0; $i < 12; $i++) $sum += (int) $cid[$i] * (13 - $i);
    return (11 - $sum % 11) % 10 === (int) $cid[12];
}
function idev_medreg_phone($raw) {
    $raw = trim((string) $raw);
    $plus = strpos($raw, '+') === 0 ? '+' : '';
    return $plus . preg_replace('/\D/', '', $raw);
}

/** Cleans submitted data; returns [person, errors]. $staff = edited in the back office (fewer required fields). */
function idev_medreg_clean($in, $staff = false) {
    $s = idev_medreg_settings();
    $en = ($in['lang'] ?? '') === 'en';
    $m = function ($th, $en_text) use ($en) { return $en ? $en_text : $th; };
    $text = function ($key, $max = 120) use ($in) { return mb_substr(trim(sanitize_text_field(wp_unslash($in[$key] ?? ''))), 0, $max); };
    $p = []; $e = [];
    $p['doc_type'] = ($in['doc_type'] ?? '') === 'passport' ? 'passport' : 'thai_id';
    $p['method'] = in_array($in['method'] ?? '', ['photo', 'manual'], true) ? $in['method'] : 'photo';
    if ($p['doc_type'] === 'thai_id') {
        $p['cid'] = preg_replace('/\D/', '', $text('cid', 20));
        if (!idev_valid_thai_id($p['cid'])) $e['cid'] = $m('เลขประจำตัวประชาชนไม่ถูกต้อง', 'Invalid Thai ID number');
        $p['passport_no'] = ''; $p['nationality'] = 'THA';
    } else {
        $p['passport_no'] = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', $text('passport_no', 20)));
        if (strlen($p['passport_no']) < 5) $e['passport_no'] = $m('กรุณากรอกเลขหนังสือเดินทาง', 'Passport number is required');
        $p['nationality'] = strtoupper(preg_replace('/[^A-Za-z]/', '', $text('nationality', 3)));
        if (strlen($p['nationality']) !== 3) $e['nationality'] = $m('กรุณาระบุสัญชาติ', 'Nationality is required');
        $p['cid'] = preg_replace('/\D/', '', $text('cid', 20));
        if ($p['cid'] !== '' && !idev_valid_thai_id($p['cid'])) $p['cid'] = '';
    }
    foreach (['prefix' => 30, 'first_name' => 100, 'last_name' => 100, 'first_name_en' => 100, 'last_name_en' => 100] as $k => $max) $p[$k] = $text($k, $max);
    if ($p['first_name'] === '') $e['first_name'] = $m('กรุณากรอกชื่อ', 'First name is required');
    if ($p['last_name'] === '') $e['last_name'] = $m('กรุณากรอกนามสกุล', 'Last name is required');
    $p['sex'] = in_array($in['sex'] ?? '', ['male', 'female'], true) ? $in['sex'] : '';
    if ($p['sex'] === '') $e['sex'] = $m('กรุณาเลือกเพศ', 'Please choose');
    $p['birthdate'] = $text('birthdate', 10);
    if (!idev_is_valid_date($p['birthdate']) || $p['birthdate'] > idev_today() || $p['birthdate'] < '1900-01-01') $e['birthdate'] = $m('วันเกิดไม่ถูกต้อง', 'Invalid date of birth');
    $p['phone'] = idev_medreg_phone($text('phone', 20));
    if (strlen(preg_replace('/\D/', '', $p['phone'])) < 9) $e['phone'] = $m('เบอร์โทรไม่ถูกต้อง', 'Invalid phone number');
    $p['email'] = sanitize_email(wp_unslash($in['email'] ?? ''));
    if ($p['email'] !== '' && !is_email($p['email'])) $e['email'] = $m('อีเมลไม่ถูกต้อง', 'Invalid e-mail');
    if ($p['email'] === '' && $s['require_email'] === '1' && !$staff) $e['email'] = $m('กรุณากรอกอีเมล (ใช้ส่งบัตรคนไข้)', 'E-mail is required (we send your patient card to it)');
    $p['line_id'] = mb_substr(preg_replace('/[^A-Za-z0-9._@\-]/', '', $text('line_id', 60)), 0, 40);
    $p['whatsapp'] = idev_medreg_phone($text('whatsapp', 20));
    if ($p['whatsapp'] !== '' && strlen(preg_replace('/\D/', '', $p['whatsapp'])) < 8) $e['whatsapp'] = $m('เบอร์ WhatsApp ไม่ถูกต้อง (ใส่รหัสประเทศ เช่น +66)', 'Invalid WhatsApp number (include the country code, e.g. +44)');
    $p['contact_pref'] = in_array($in['contact_pref'] ?? '', ['phone', 'email', 'line', 'whatsapp'], true) ? $in['contact_pref'] : '';
    $p['address'] = mb_substr(trim(sanitize_textarea_field(wp_unslash($in['address'] ?? ''))), 0, 500);
    if ($s['field_address'] === 'required' && mb_strlen($p['address']) < 5 && !$staff) $e['address'] = $m('กรุณากรอกที่อยู่', 'Address is required');
    $lat = $in['lat'] ?? ''; $lng = $in['lng'] ?? '';
    $p['lat'] = is_numeric($lat) && abs((float) $lat) <= 90 ? round((float) $lat, 6) : null;
    $p['lng'] = is_numeric($lng) && abs((float) $lng) <= 180 ? round((float) $lng, 6) : null;
    $p['drug_allergy'] = $text('drug_allergy', 300);
    $p['emergency_name'] = $text('emergency_name', 120);
    $p['emergency_phone'] = idev_medreg_phone($text('emergency_phone', 20));
    $p['lang'] = $en ? 'en' : 'th';
    return [$p, $e];
}

/* ---------- Public submission and connector API ---------- */

function idev_medreg_client_ip() {
    foreach (['HTTP_CF_CONNECTING_IP', 'REMOTE_ADDR'] as $k) if (!empty($_SERVER[$k])) return sanitize_text_field(wp_unslash($_SERVER[$k]));
    return '';
}

add_action('rest_api_init', function () {
    register_rest_route('idev-medreg/v1', '/register', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'idev_medreg_submit']);
    if (get_option('idev_medreg_compat_andaman')) register_rest_route('andaman/v1', '/register', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'idev_medreg_submit']); // forms set up for Andaman Hub keep working
});

/** True when an add-on (iDev Patient Registration Pro) sends approved registrations to the hospital system. */
function idev_medreg_connector_on() { return (bool) apply_filters('idev_medreg_connector_enabled', false); }

function idev_medreg_submit(WP_REST_Request $request) {
    global $wpdb;
    $s = idev_medreg_settings();
    $in = $request->get_body_params();
    $en = ($in['lang'] ?? '') === 'en';
    $m = function ($th, $en_text) use ($en) { return $en ? $en_text : $th; };
    if ($s['enabled'] !== '1') return new WP_REST_Response(['ok' => false, 'errors' => ['form' => $m('ปิดรับลงทะเบียนออนไลน์ชั่วคราว', 'Online registration is closed at the moment.')]], 403);
    if (!empty($in['website'])) return new WP_REST_Response(['ok' => true, 'ref' => 'REG-0'], 200); // honeypot
    if (empty($in['consent_pdpa'])) return new WP_REST_Response(['ok' => false, 'errors' => ['consent' => $m('กรุณายอมรับนโยบายความเป็นส่วนตัวก่อน', 'Please accept the privacy notice first')]], 400);
    $ip_key = 'idev_medreg_rate_' . md5(idev_medreg_client_ip());
    $count = (int) get_transient($ip_key);
    if ($count >= (int) $s['rate_limit']) return new WP_REST_Response(['ok' => false, 'errors' => ['form' => $m('ส่งข้อมูลบ่อยเกินไป กรุณาลองใหม่ภายหลัง หรือโทรติดต่อเจ้าหน้าที่', 'Too many attempts. Please try again later or call us.')]], 429);
    [$person, $errors] = idev_medreg_clean($in);
    $methods = idev_medreg_methods();
    $wants = $person['method'] === 'manual' ? 'manual' : ($person['doc_type'] === 'passport' ? 'passport' : 'thai_id');
    if (!in_array($wants, $methods, true)) $errors['form'] = $m('วิธีลงทะเบียนนี้ไม่เปิดใช้', 'This way of registering is not available');
    $photo = $request->get_file_params()['photo'] ?? null;
    $has_photo = $photo && empty($photo['error']) && is_uploaded_file($photo['tmp_name']);
    if ($person['method'] === 'photo' && !$has_photo) $errors['photo'] = $m('กรุณาถ่ายรูปบัตรประชาชนหรือหนังสือเดินทาง', 'Please take a photo of your ID card or passport');
    if ($has_photo && $photo['size'] > 12 * 1048576) $errors['photo'] = $m('รูปใหญ่เกินไป', 'The photo is too large');
    if ($errors) return new WP_REST_Response(['ok' => false, 'errors' => $errors], 400);
    $number = $person['doc_type'] === 'thai_id' ? $person['cid'] : $person['passport_no'];
    $search = idev_medreg_search_key($person['doc_type'], $number);
    $open = $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . idev_medreg_table() . " WHERE search_key=%s AND status IN ('pending','approved')", $search));
    if ($open) return new WP_REST_Response(['ok' => false, 'errors' => ['form' => $m('เลขบัตรนี้ส่งข้อมูลลงทะเบียนแล้ว อยู่ระหว่างตรวจสอบ หากต้องการแก้ไขกรุณาโทรติดต่อเจ้าหน้าที่', 'This ID has already been submitted and is being reviewed. Please call us if you need to change it.')]], 409);
    $stored = '';
    if ($has_photo) {
        $stored = idev_medreg_store_photo($photo['tmp_name']);
        if (!$stored) return new WP_REST_Response(['ok' => false, 'errors' => ['photo' => $m('อ่านไฟล์รูปไม่ได้ กรุณาถ่ายใหม่ (JPG/PNG)', 'Could not read the photo. Please try again (JPG/PNG).')]], 400);
    }
    $person['consent'] = ['pdpa' => true, 'gdpr' => true, 'version' => $s['consent_version'], 'at' => gmdate('c'), 'ip_hash' => hash_hmac('sha256', idev_medreg_client_ip(), wp_salt('nonce')), 'user_agent' => mb_substr(sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? '')), 0, 200)];
    if (!empty($in['consent_marketing'])) $person['consent']['news'] = true;
    $person['_log'] = [[gmdate('c'), 'patient', $person['method'] === 'manual' ? 'ส่งข้อมูลลงทะเบียน (กรอกเอง)' : 'ส่งข้อมูลลงทะเบียน (ถ่ายรูปเอกสาร)']];
    $now = current_time('mysql', true);
    $ref = 'REG-' . wp_date('ymd') . '-' . strtoupper(wp_generate_password(5, false));
    $wpdb->insert(idev_medreg_table(), ['ref' => $ref, 'status' => 'pending', 'doc_type' => $person['doc_type'], 'method' => $person['method'], 'search_key' => $search, 'data' => idev_medreg_encrypt(wp_json_encode($person, JSON_UNESCAPED_UNICODE)), 'photo' => $stored, 'created_at' => $now, 'updated_at' => $now]);
    $id = (int) $wpdb->insert_id;
    set_transient($ip_key, $count + 1, HOUR_IN_SECONDS);
    idev_medreg_mail_received($person, $ref);
    do_action('idev_medreg_submitted', $id, $ref, $person);
    /** Filter: add next_url / next_label to offer a next step (iDev Appointments: book now). */
    return new WP_REST_Response(apply_filters('idev_medreg_submit_response', ['ok' => true, 'ref' => $ref, 'email' => $person['email'] !== ''], $id), 200);
}

/**
 * Walk-in: a new patient registered at the counter by staff (no consent screen on the web; the patient signs at the
 * counter). Same record as an online registration, marked method "walkin". Returns [id, ref] or WP_Error with the field errors.
 */
function idev_medreg_create_walkin($in) {
    global $wpdb;
    if (!current_user_can('idev_medreg')) return new WP_Error('forbidden', 'Forbidden');
    $in['method'] = 'manual';
    [$person, $errors] = idev_medreg_clean($in, true);
    if ($errors) return new WP_Error('invalid', implode(' · ', $errors), $errors);
    $number = $person['doc_type'] === 'thai_id' ? $person['cid'] : $person['passport_no'];
    $search = idev_medreg_search_key($person['doc_type'], $number);
    $open = $wpdb->get_var($wpdb->prepare('SELECT ref FROM ' . idev_medreg_table() . " WHERE search_key=%s AND status IN ('pending','approved') LIMIT 1", $search));
    if ($open) return new WP_Error('duplicate', sprintf(__('This ID is already waiting for an HN (%s).', 'idev-patient-registration'), $open));
    $person['method'] = 'walkin';
    $person['consent'] = ['pdpa' => true, 'version' => idev_medreg_settings()['consent_version'], 'at' => gmdate('c'), 'counter' => true];
    $u = wp_get_current_user();
    $person['_log'] = [[gmdate('c'), $u->user_login, 'ลงทะเบียน walk-in ที่ห้องบัตร']];
    $now = current_time('mysql', true);
    $ref = 'REG-' . wp_date('ymd') . '-' . strtoupper(wp_generate_password(5, false));
    $wpdb->insert(idev_medreg_table(), ['ref' => $ref, 'status' => 'pending', 'doc_type' => $person['doc_type'], 'method' => 'walkin', 'search_key' => $search, 'data' => idev_medreg_encrypt(wp_json_encode($person, JSON_UNESCAPED_UNICODE)), 'photo' => '', 'created_at' => $now, 'updated_at' => $now]);
    $id = (int) $wpdb->insert_id;
    do_action('idev_medreg_submitted', $id, $ref, $person);
    return [$id, $ref];
}
/** Counts for the records desk: [pending online, pending walk-in, waiting for HOSxP, new today]. */
function idev_medreg_counts() {
    global $wpdb;
    $t = idev_medreg_table();
    $start = get_gmt_from_date(idev_today() . ' 00:00:00');
    return [
        'online' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE status='pending' AND method<>'walkin'"),
        'walkin' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE status='pending' AND method='walkin'"),
        'approved' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE status IN ('approved','error')"),
        'today' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE created_at >= %s", $start)),
    ];
}

/* ---------- ID photos: re-encoded (no EXIF / location), encrypted, outside the web folder when possible ---------- */

function idev_medreg_private_dir() {
    static $found = null;
    if ($found !== null) return $found;
    $secret = get_option('idev_medreg_dir_secret');
    if (!$secret) { $secret = strtolower(wp_generate_password(20, false)); update_option('idev_medreg_dir_secret', $secret, false); }
    $candidates = [dirname(untrailingslashit(ABSPATH)) . '/idev-private/medreg-photos', wp_get_upload_dir()['basedir'] . '/idev-private-' . $secret];
    // Photos copied from Andaman Hub.
    foreach ($candidates as $dir) {
        if (!is_dir($dir)) @wp_mkdir_p($dir);
        if (is_dir($dir) && is_writable($dir)) {
            if (!file_exists("$dir/index.php")) @file_put_contents("$dir/index.php", "<?php // Silence\n");
            if (!file_exists("$dir/.htaccess")) @file_put_contents("$dir/.htaccess", "Require all denied\nDeny from all\n");
            return $found = $dir;
        }
    }
    return $found = '';
}
function idev_medreg_store_photo($tmp) {
    $info = @getimagesize($tmp);
    if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)) return '';
    $src = $info[2] === IMAGETYPE_PNG ? @imagecreatefrompng($tmp) : ($info[2] === IMAGETYPE_WEBP ? @imagecreatefromwebp($tmp) : @imagecreatefromjpeg($tmp));
    if (!$src) return '';
    $w = imagesx($src); $h = imagesy($src);
    $scale = min(1, 1800 / max($w, $h));
    $dst = imagecreatetruecolor(max(1, (int) ($w * $scale)), max(1, (int) ($h * $scale)));
    imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
    imagecopyresampled($dst, $src, 0, 0, 0, 0, imagesx($dst), imagesy($dst), $w, $h);
    ob_start(); imagejpeg($dst, null, 85); $jpeg = ob_get_clean();
    imagedestroy($src); imagedestroy($dst);
    $name = bin2hex(random_bytes(16)) . '.bin';
    return idev_medreg_photo_write($name, $jpeg) ? $name : '';
}
function idev_medreg_photo_path($name) {
    if (!preg_match('/^[0-9a-f]{32}\.bin$/', (string) $name)) return '';
    $dir = idev_medreg_private_dir();
    return $dir ? "$dir/$name" : '';
}
function idev_medreg_photo_write($name, $bytes) { $path = idev_medreg_photo_path($name); return $path && file_put_contents($path, idev_medreg_encrypt($bytes)) !== false; }
function idev_medreg_photo_bytes($name) { $path = idev_medreg_photo_path($name); return $path && is_file($path) ? idev_medreg_decrypt(file_get_contents($path)) : null; }
function idev_medreg_photo_key($name) { $path = idev_medreg_photo_path($name); return $path && is_file($path) ? idev_medreg_cipher_key(file_get_contents($path, false, null, 0, 16)) : ''; }
function idev_medreg_delete_photo($row) {
    $path = idev_medreg_photo_path($row['photo'] ?? '');
    if ($path && is_file($path)) @unlink($path);
    global $wpdb;
    $wpdb->update(idev_medreg_table(), ['photo' => ''], ['id' => (int) $row['id']]);
}

/* ---------- E-mails ---------- */

function idev_medreg_site($en) {
    $s = idev_medreg_settings();
    return ['name' => idev_pick($s['org_name'] ?: get_bloginfo('name'), $s['org_name_en'], $en ? 'en' : 'th'), 'address' => idev_pick($s['org_address'], $s['org_address_en'], $en ? 'en' : 'th'), 'phone' => $s['org_phone']];
}
function idev_medreg_mail_wrap($title, $body_html, $en) {
    $s = idev_medreg_settings();
    $site = idev_medreg_site($en);
    $c = sanitize_hex_color($s['email_color']) ?: '#0e3540';
    return '<div style="font-family:Tahoma,Arial,sans-serif;background:#f3f6f8;padding:24px"><div style="max-width:580px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden;border:1px solid #e3e9ee">'
        . '<div style="background:' . $c . ';color:#fff;padding:18px 22px"><strong style="font-size:17px">' . esc_html($site['name']) . '</strong></div>'
        . '<div style="padding:22px;color:#172737;font-size:15px;line-height:1.7"><h2 style="margin:0 0 12px;font-size:19px">' . esc_html($title) . '</h2>' . $body_html . '</div>'
        . '<div style="padding:14px 22px;background:#f7f9fa;color:#70808d;font-size:12px">' . esc_html(trim($site['address'] . ' · ' . $site['phone'], ' ·')) . '</div></div></div>';
}
function idev_medreg_send($to, $subject, $html, $mailer_cb = null, $attachments = []) {
    $headers = ['Content-Type: text/html; charset=UTF-8'];
    $from = idev_medreg_settings()['email_from'];
    if ($from && is_email($from)) $headers[] = 'Reply-To: ' . $from;
    if ($mailer_cb) add_action('phpmailer_init', $mailer_cb);
    $ok = wp_mail($to, $subject, $html, $headers, $attachments);
    if ($mailer_cb) remove_action('phpmailer_init', $mailer_cb);
    return $ok;
}
function idev_medreg_tpl($text, $vars) { return strtr((string) $text, $vars); }

function idev_medreg_mail_received($p, $ref) {
    $s = idev_medreg_settings();
    $en = ($p['lang'] ?? 'th') === 'en';
    if ($p['email'] !== '' && $s['email_received'] === '1') {
        $body = $en
            ? '<p>' . esc_html(idev_medreg_salutation($p, true)) . '</p><p>We have received your registration. Reference: <strong>' . esc_html($ref) . '</strong></p><p>Our staff will check your details. When your hospital number (HN) is ready, we will e-mail your patient card to this address.</p>'
            : '<p>' . esc_html(idev_medreg_salutation($p, false)) . '</p><p>ได้รับข้อมูลลงทะเบียนของท่านแล้ว เลขอ้างอิง <strong>' . esc_html($ref) . '</strong></p><p>เจ้าหน้าที่จะตรวจสอบข้อมูล เมื่อได้เลขประจำตัวผู้ป่วย (HN) แล้ว ระบบจะส่งบัตรคนไข้มาที่อีเมลนี้</p>';
        /** Filter: designed e-mail [subject, html] (add-ons), null = built-in. */
        $custom = apply_filters('idev_medreg_mail_custom', null, 'received', ['p' => $p, 'ref' => $ref, 'en' => $en]);
        if (is_array($custom)) idev_medreg_send($p['email'], $custom[0], $custom[1]);
        else idev_medreg_send($p['email'], ($en ? 'Registration received ' : 'ได้รับข้อมูลลงทะเบียนแล้ว ') . $ref, idev_medreg_mail_wrap($en ? 'Registration received' : 'ได้รับข้อมูลลงทะเบียนแล้ว', $body, $en));
    }
    foreach (array_filter(array_map('trim', explode(',', (string) $s['staff_email'])), 'is_email') as $staff) {
        idev_medreg_send($staff, 'มีผู้ลงทะเบียนผู้ป่วยใหม่ ' . $ref, idev_medreg_mail_wrap('มีผู้ลงทะเบียนผู้ป่วยใหม่', '<p>เลขอ้างอิง <strong>' . esc_html($ref) . '</strong></p><p><a href="' . esc_url(admin_url('admin.php?page=idev-medreg')) . '">เปิดหลังบ้านเพื่อตรวจสอบ</a></p><p style="color:#70808d;font-size:13px">อีเมลนี้ไม่มีข้อมูลส่วนบุคคลของผู้ป่วย</p>', false));
    }
}

/** Patient card e-mail: the designed card as an image (inline + attachment) and a text version. */
function idev_medreg_mail_card($id) {
    global $wpdb;
    $row = idev_medreg_get($id);
    if (!$row || $row['hn'] === '' || !is_email($row['person']['email'] ?? '')) return false;
    $p = $row['person'];
    $en = ($p['lang'] ?? 'th') === 'en';
    $png = idev_medreg_card_png($row, $en);
    $cid = 'patient-card-' . $row['id'];
    $s = idev_medreg_settings();
    $card_html = $png ? '<p style="margin:16px 0"><img src="cid:' . $cid . '" alt="' . esc_attr(($en ? 'Patient card' : 'บัตรคนไข้') . ' HN ' . $row['hn']) . '" style="width:100%;max-width:540px;border-radius:16px;display:block"></p>' : '';
    $intro = $en
        ? '<p>' . esc_html(idev_medreg_salutation($p, true)) . '</p><p>Your registration is complete. Your hospital number (HN) is <strong style="font-size:18px">' . esc_html($row['hn']) . '</strong>. Please keep this patient card and show it on your phone at the registration desk, together with your passport or ID card.</p>'
        : '<p>' . esc_html(idev_medreg_salutation($p, false)) . '</p><p>การลงทะเบียนผู้ป่วยใหม่เสร็จสมบูรณ์ เลขประจำตัวผู้ป่วย (HN) ของท่านคือ <strong style="font-size:18px">' . esc_html($row['hn']) . '</strong> กรุณาเก็บบัตรนี้ไว้ และแสดงบนมือถือพร้อมบัตรประชาชนที่จุดลงทะเบียนเมื่อมารับบริการ</p>';
    $note = idev_pick($s['card_email_note'], $s['card_email_note_en'], $en ? 'en' : 'th');
    $body = $intro . $card_html . ($note !== '' ? '<p style="color:#70808d;font-size:13px">' . nl2br(esc_html($note)) . '</p>' : '') . ($png ? '<p style="color:#70808d;font-size:13px">' . ($en ? 'The card is also attached as an image you can save to your phone.' : 'แนบรูปบัตรไว้ด้วย บันทึกลงมือถือได้') . '</p>' : '');
    $cb = $png ? function ($mailer) use ($png, $cid, $row) {
        $mailer->addStringEmbeddedImage($png, $cid, 'patient-card.png', 'base64', 'image/png');
        $mailer->addStringAttachment($png, 'patient-card-HN' . preg_replace('/[^0-9A-Za-z-]/', '', $row['hn']) . '.png', 'base64', 'image/png');
    } : null;
    $custom = apply_filters('idev_medreg_mail_custom', null, 'card', ['p' => $p, 'row' => $row, 'en' => $en, 'image' => $png ? 'cid:' . $cid : '']);
    $ok = is_array($custom)
        ? idev_medreg_send($p['email'], $custom[0], $custom[1], $cb)
        : idev_medreg_send($p['email'], ($en ? 'Your patient card – HN ' : 'บัตรคนไข้ของท่าน HN ') . $row['hn'], idev_medreg_mail_wrap($en ? 'Your patient card' : 'บัตรคนไข้ของท่าน', $body, $en), $cb);
    if ($ok) $wpdb->update(idev_medreg_table(), ['emailed_at' => current_time('mysql', true)], ['id' => (int) $id]);
    return $ok;
}

/* ---------- Clean-up ---------- */

add_action('idev_medreg_cleanup', function () {
    global $wpdb;
    $s = idev_medreg_settings();
    $t = idev_medreg_table();
    $cut = gmdate('Y-m-d H:i:s', time() - max(0, (int) $s['photo_days']) * DAY_IN_SECONDS);
    foreach ($wpdb->get_results($wpdb->prepare("SELECT id, photo FROM {$t} WHERE photo<>'' AND ((status='synced' AND synced_at < %s) OR (status='rejected' AND updated_at < %s))", $cut, $cut), ARRAY_A) as $row) idev_medreg_delete_photo($row);
    $cut = gmdate('Y-m-d H:i:s', time() - max(1, (int) $s['rejected_days']) * DAY_IN_SECONDS);
    $wpdb->query($wpdb->prepare("DELETE FROM {$t} WHERE status='rejected' AND updated_at < %s", $cut));
    if ((int) $s['synced_days'] > 0) {
        $cut = gmdate('Y-m-d H:i:s', time() - (int) $s['synced_days'] * DAY_IN_SECONDS);
        foreach ($wpdb->get_results($wpdb->prepare("SELECT id, photo FROM {$t} WHERE status='synced' AND synced_at < %s", $cut), ARRAY_A) as $row) { idev_medreg_delete_photo($row); $wpdb->delete($t, ['id' => (int) $row['id']]); }
    }
});
