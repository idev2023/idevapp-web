=== iDev Patient Registration Pro ===
Contributors: idevapp2023
Tags: hospital, patient registration, hosxp, ocr
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.2.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add-on for iDev Patient Registration: HOSxP connector and automatic reading of Thai ID cards and passports.

== Description ==

Needs the free plugin **iDev Patient Registration** 1.2 or newer.

* **HOSxP connector:** a small PHP program inside the hospital takes approved registrations, finds the patient or creates a new HN in HOSxP, and sends the HN back; the patient card is e-mailed automatically. The website never connects to HOSxP. Permission to connect to the HOSxP database is given by BMS; please arrange it with BMS yourself.
* **Automatic reading:** the Thai ID card (number, names, date of birth) and passport MRZ are read on the patient's phone with tesseract.js (loaded from jsDelivr, or your own copy). The photo is not sent to any reading service.

Licence: 2,900 THB, lifetime, one website (also included in I-Clinic / I-Drug, and keys issued for iDev Patient Registration before version 1.2 keep working).

== Changelog ==

= 1.2.5 =
* Thai ID card: first / last name split by the spaces Tesseract reads, or by the widest gaps when it adds spaces inside a word (letter boxes are not trusted); a misread title (นาข, ใจย) is recognised; the English name is read even when its title is misread. Add ?ocrdebug=1 to the page address to see what was read.

= 1.2.4 =
* Thai ID card: reads a card photographed sideways or a few degrees off, reads the name again on its own (without the label) so vowels and tone marks are kept, and only accepts an ID number printed on one line.

= 1.2.3 =
* Thai ID card: first and last name are split at the wide gap on the card (not at stray spaces), the name line is cut from the full-size photo, and the camera takes a full-resolution still when the phone allows it. A new photo replaces details read from the previous one.

= 1.2.2 =
* Thai ID card: the Thai name line is read a second time on its own, enlarged, so vowels and tone marks are not dropped.

= 1.2.1 =
* Dates show the Buddhist year (พ.ศ.) and Thai month names on Thai pages, and the Gregorian year on English pages, everywhere WordPress formats a date.

= 1.2.0 =
* Includes iDev Patient Registration 1.3.0 (walk-in).

= 1.0.0 =
* The HOSxP connector and automatic reading moved here from iDev Patient Registration 1.1.
