<?php
defined('ABSPATH') || exit;
get_header();
idevapp_page_top(esc_html(ihub_t('page.notFound')), ihub_t('wp.notFoundText'));
echo '<section class="section not-found"><div class="container"><a class="button button-teal" href="' . esc_url(home_url('/')) . '">' . esc_html(ihub_t('wp.backHome')) . '</a></div></section>';
get_footer();
