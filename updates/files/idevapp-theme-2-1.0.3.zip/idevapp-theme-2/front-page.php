<?php
defined('ABSPATH') || exit;
get_header();
while (have_posts()) { the_post(); idevapp_render_page(get_post()); }
get_footer();
