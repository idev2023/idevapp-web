<?php defined('ABSPATH') || exit; $ihub_local = ihub_site_local(); $ihub_phone = ihub_setting('phone'); ?>
</main>
<footer class="footer"><div class="container footer-inner">
  <?php echo idevapp_brand('brand footer-brand'); ?>
  <div><strong><?php echo esc_html(ihub_t('footer.contact')); ?></strong><p><?php echo esc_html($ihub_local['address']); ?></p><p><?php echo esc_html(ihub_t('footer.tel')); ?> <a href="tel:<?php echo esc_attr($ihub_phone); ?>"><?php echo esc_html($ihub_phone); ?></a> · <?php echo esc_html(ihub_t('footer.emergency')); ?></p></div>
  <span class="copyright">© <?php $ihub_y = (int) wp_date('Y'); echo esc_html((function_exists('ihub_lang') && ihub_lang() === 'th') ? $ihub_y + 543 : $ihub_y); ?> iDevApp Hub</span>
</div></footer>
<?php wp_footer(); ?>
</body>
</html>
