/* Mobile menu toggle. */
(function () {
  const tools = document.querySelector('.nav-tools');
  const toggle = tools && tools.querySelector('.menu-toggle');
  if (!toggle) return;
  toggle.addEventListener('click', () => {
    const open = !tools.classList.contains('menu-open');
    tools.classList.toggle('menu-open', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && tools.classList.contains('menu-open')) { tools.classList.remove('menu-open'); toggle.setAttribute('aria-expanded', 'false'); } });
})();

/* Search panel under the header. */
(function () {
  const toggle = document.querySelector('.search-toggle');
  const panel = document.getElementById('site-search');
  if (!toggle || !panel) return;
  toggle.addEventListener('click', () => {
    const open = panel.hidden;
    panel.hidden = !open;
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open) panel.querySelector('input').focus();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !panel.hidden) { panel.hidden = true; toggle.setAttribute('aria-expanded', 'false'); toggle.focus(); } });
})();
