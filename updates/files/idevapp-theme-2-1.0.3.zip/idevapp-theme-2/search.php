<?php
/* Search: doctors/clinics, pages and news. */
defined('ABSPATH') || exit;
get_header();
$query = get_search_query();
idevapp_page_top(esc_html(ihub_t('ui.searchTitle')), $query !== '' ? str_replace('{q}', $query, ihub_t('ui.searchFor')) : '', 'SEARCH');
echo '<section class="section"><div class="container ihub-search">';
echo '<form class="search-again" role="search" action="' . esc_url(home_url('/')) . '" method="get"><input type="search" name="s" value="' . esc_attr($query) . '" placeholder="' . esc_attr(ihub_t('ui.searchPlaceholder')) . '" aria-label="' . esc_attr(ihub_t('ui.search')) . '"><button class="button button-teal">' . ihub_ui_icon('search') . ' ' . esc_html(ihub_t('ui.search')) . '</button></form>';
$providers = ihub_search_providers($query);
$ihub_pages = []; $ihub_news = [];
while (have_posts()) { the_post(); if (get_post_type() === 'page') $ihub_pages[] = get_post(); elseif (get_post_type() === 'post') $ihub_news[] = get_post(); }
if (!$providers && !$ihub_pages && !$ihub_news) echo ihub_empty_news(ihub_t('ui.noResults'), '');
if ($providers) {
    $schedule = ihub_schedule_page_url();
    echo '<h2 class="search-group">' . esc_html(ihub_t('ui.resultsDoctors')) . '</h2><div class="search-list">';
    foreach ($providers as $p) {
        $specialty = ihub_pick($p['specialty'], $p['specialty_en']);
        echo '<a class="search-item" href="' . esc_url(add_query_arg('provider', $p['id'], $schedule)) . '"><span class="search-thumb">' . ($p['photo_url'] ? '<img src="' . esc_url($p['photo_url']) . '" alt="">' : ihub_icon($p['kind'] === 'clinic' ? 'plus' : 'emergency')) . '</span><span><strong>' . esc_html(ihub_pick($p['name'], $p['name_en'])) . '</strong>' . ($specialty !== '' ? '<small>' . esc_html($specialty) . '</small>' : '') . '<em>' . esc_html(ihub_t('ui.viewSchedule')) . ' →</em></span></a>';
    }
    echo '</div>';
}
if ($ihub_pages) {
    echo '<h2 class="search-group">' . esc_html(ihub_t('ui.resultsPages')) . '</h2><div class="search-list">';
    foreach ($ihub_pages as $ihub_page) {
        $summary = ihub_pick($ihub_page->post_excerpt, ihub_en_meta($ihub_page->ID, 'excerpt'));
        echo '<a class="search-item" href="' . esc_url(get_permalink($ihub_page)) . '"><span class="search-thumb">' . ihub_icon('plus') . '</span><span><strong>' . get_the_title($ihub_page) . '</strong>' . ($summary !== '' ? '<small>' . esc_html($summary) . '</small>' : '') . '</span></a>';
    }
    echo '</div>';
}
if ($ihub_news) {
    echo '<h2 class="search-group">' . esc_html(ihub_t('ui.resultsNews')) . '</h2><div class="news-grid">';
    foreach ($ihub_news as $ihub_item) echo ihub_news_card($ihub_item);
    echo '</div>' . ihub_render_pagination();
}
echo '</div></section>';
get_footer();
