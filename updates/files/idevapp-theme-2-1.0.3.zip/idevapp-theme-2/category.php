<?php
/* News index (the "ข่าวสารและประกาศ" page) and category archives. */
defined('ABSPATH') || exit;
get_header();
$term = is_category() ? get_queried_object() : null;
$page_id = (int) get_option('page_for_posts');
$summary = $page_id ? ihub_pick(get_post_field('post_excerpt', $page_id), ihub_en_meta($page_id, 'excerpt')) : '';
idevapp_page_top($term ? esc_html(ihub_term_name($term)) : esc_html(ihub_t('news.title')), $term ? ihub_t('news.subtitle') : ($summary ?: ihub_t('news.subtitle')), 'NEWS & UPDATES');
echo '<section class="section"><div class="container">' . ihub_render_news_tabs($term ? $term->term_id : 0);
if (have_posts()) {
    echo '<div class="news-grid">';
    while (have_posts()) { the_post(); echo ihub_news_card(get_post()); }
    echo '</div>' . ihub_render_pagination();
} else {
    echo ihub_empty_news($term ? ihub_t('news.noneInCategory') : ihub_t('news.emptyTitle'));
}
echo '</div></section>';
get_footer();
