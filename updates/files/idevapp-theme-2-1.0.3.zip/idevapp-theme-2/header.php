<?php defined('ABSPATH') || exit; $ihub_local = ihub_site_local(); $ihub_phone = ihub_setting('phone'); $ihub_lang = ihub_lang(); ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(ihub_setting('mourning_mode') === 'true' ? 'mourning-mode' : ''); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#main"><?php echo esc_html($ihub_lang === 'en' ? 'Skip to content' : 'ข้ามไปยังเนื้อหา'); ?></a>
<div class="topline"><div class="container topline-inner"><span><span class="topline-icon" aria-hidden="true">⌖</span> <?php echo esc_html($ihub_local['address']); ?></span><span class="topline-right"><?php echo ihub_render_font_tools(); ?><span><span class="topline-icon" aria-hidden="true">☎</span> <a href="tel:<?php echo esc_attr($ihub_phone); ?>"><?php echo esc_html(ihub_t('header.emergency') . ': ' . $ihub_phone); ?></a></span></span></div></div>
<?php echo ihub_render_announcements(); ?>
<header class="site-header"><div class="container nav-row">
  <?php echo idevapp_brand(); ?>
  <div class="nav-tools">
    <button type="button" class="menu-toggle" aria-expanded="false" aria-controls="main-nav" aria-label="<?php echo esc_attr(ihub_t('header.mainMenu')); ?>"><span></span><span></span><span></span></button>
    <nav id="main-nav" class="main-nav" aria-label="<?php echo esc_attr(ihub_t('header.mainMenu')); ?>"><?php echo idevapp_menu(); ?></nav>
    <button type="button" class="search-toggle" aria-expanded="false" aria-controls="site-search" aria-label="<?php echo esc_attr(ihub_t('ui.search')); ?>"><?php echo ihub_ui_icon('search'); ?></button>
    <div class="language-switch" role="group" aria-label="<?php echo esc_attr(ihub_t('header.chooseLanguage')); ?>">
      <a href="<?php echo esc_url(ihub_lang_url('th')); ?>" class="<?php echo $ihub_lang === 'th' ? 'active' : ''; ?>" aria-pressed="<?php echo $ihub_lang === 'th' ? 'true' : 'false'; ?>" rel="nofollow">TH</a>
      <a href="<?php echo esc_url(ihub_lang_url('en')); ?>" class="<?php echo $ihub_lang === 'en' ? 'active' : ''; ?>" aria-pressed="<?php echo $ihub_lang === 'en' ? 'true' : 'false'; ?>" rel="nofollow">EN</a>
    </div>
    <?php if (ihub_setting('appointment_url')) : ?><a class="button button-coral nav-cta" href="<?php echo esc_url(ihub_setting('appointment_url')); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html(ihub_t('header.appointment')); ?></a><?php endif; ?>
  </div>
</div>
<div id="site-search" class="site-search" hidden><form class="container" role="search" action="<?php echo esc_url(home_url('/')); ?>" method="get"><label class="screen-reader-text" for="site-search-input"><?php echo esc_html(ihub_t('ui.search')); ?></label><input id="site-search-input" type="search" name="s" value="<?php echo esc_attr(get_search_query()); ?>" placeholder="<?php echo esc_attr(ihub_t('ui.searchPlaceholder')); ?>" autocomplete="off"><button class="button button-teal" type="submit"><?php echo ihub_ui_icon('search'); ?> <?php echo esc_html(ihub_t('ui.search')); ?></button></form></div>
</header>
<main id="main">
