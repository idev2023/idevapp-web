<?php
defined('ABSPATH') || exit;
get_header();
while (have_posts()) {
    the_post();
    $post = get_post();
    $term = ihub_post_category($post);
    $style = get_post_meta($post->ID, 'ihub_display_style', true) ?: 'card';
    $back = '<a href="' . esc_url(ihub_news_url()) . '">' . esc_html(ihub_t('news.back')) . '</a>';
    idevapp_page_top(get_the_title(), ihub_pick($post->post_excerpt, ihub_en_meta($post->ID, 'excerpt')), ihub_term_name($term), $back);
    echo '<article class="article-wrap article-' . esc_attr($style) . '"><time>' . esc_html(ihub_format_post_date($post)) . '</time>';
    if (has_post_thumbnail()) echo '<img class="article-image" src="' . esc_url(get_the_post_thumbnail_url($post, 'full')) . '" alt="">';
    echo '<div class="article-content">' . apply_filters('the_content', get_the_content()) . '</div>';
    echo ihub_render_attachments($post->ID) . '</article>';
}
get_footer();
