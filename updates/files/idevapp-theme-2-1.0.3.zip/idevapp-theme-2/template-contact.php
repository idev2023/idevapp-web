<?php
/* Template Name: ติดต่อเรา (ที่อยู่ เบอร์โทร แผนที่) */
defined('ABSPATH') || exit;
get_header();
while (have_posts()) {
    the_post();
    $post = get_post();
    $local = ihub_site_local();
    $phone = ihub_setting('phone');
    $summary = ihub_pick($post->post_excerpt, ihub_en_meta($post->ID, 'excerpt')) ?: ihub_t('contact.subtitle');
    idevapp_page_top(get_the_title(), $summary, 'CONTACT');
    echo '<section class="section"><div class="container contact-grid"><article class="contact-card"><span class="service-icon mint">' . ihub_icon('pin') . '</span><h2>' . esc_html(ihub_t('contact.location')) . '</h2><p>' . esc_html($local['address']) . '</p></article>';
    echo '<article class="contact-card"><span class="service-icon rose">' . ihub_icon('phone') . '</span><h2>' . esc_html(ihub_t('contact.phone')) . '</h2><p><a href="tel:' . esc_attr($phone) . '">' . esc_html($phone) . '</a></p><small>' . esc_html(ihub_t('contact.emergencyNote')) . '</small></article></div>';
    $content = trim((string) get_the_content());
    if ($content !== '') echo '<div class="container page-body"><div class="article-content">' . apply_filters('the_content', $content) . '</div></div>';
    if (ihub_setting('map_on_contact') === 'true') echo '<div class="container">' . ihub_render_map() . '</div>';
    echo '</section>';
}
get_footer();
