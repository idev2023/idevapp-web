<?php
/**
 * Plugin Name: บริการทางการแพทย์ (การ์ดบริการ)
 * Description: การ์ด “บริการทางการแพทย์” แก้ไขได้ในหน้าเดียว — ไอคอน สี ข้อความไทย / อังกฤษ และลิงก์ แสดงด้วยบล็อก “บริการทางการแพทย์” หรือ [idw_services] ใช้ได้กับทุกธีม
 * Version: 1.0.0
 * Author: iDevApp
 * Author URI: https://idevapp.me/
 * Text Domain: idw-services
 *
 * ไม่ขึ้นกับธีมหรือโมดูลอื่น: ข้อมูลอยู่ใน option idw_services · CSS ของตัวเอง (คลาส .idw-svc) · ไอคอนของตัวเอง
 */
defined( 'ABSPATH' ) || exit;
if ( defined( 'IDW_SVC_VER' ) ) {
	return;
}
define( 'IDW_SVC_VER', defined( 'IDW_VERSION' ) ? IDW_VERSION : '1.0.0' );
define( 'IDW_SVC_URL', plugin_dir_url( __FILE__ ) );

require_once __DIR__ . '/includes/icons.php';

/* ---------- data ---------- */

function idw_svc_tones() {
	return array(
		'mint'     => array( 'เขียวมิ้นต์', '#13a383', '#e3f8f1' ),
		'teal'     => array( 'เขียวน้ำทะเล', '#0f8f86', '#e0f5f3' ),
		'green'    => array( 'เขียว', '#2e9e4f', '#e6f6ea' ),
		'sky'      => array( 'ฟ้า', '#1e93c4', '#e2f4fb' ),
		'blue'     => array( 'น้ำเงิน', '#2463d4', '#e5edfc' ),
		'indigo'   => array( 'คราม', '#4f46e5', '#ecebfd' ),
		'lavender' => array( 'ม่วง', '#8a5cd6', '#f2ecfd' ),
		'pink'     => array( 'ชมพู', '#d9468f', '#fde9f3' ),
		'rose'     => array( 'กุหลาบ', '#e63b5c', '#feebef' ),
		'red'      => array( 'แดง', '#d63031', '#fde8e8' ),
		'orange'   => array( 'ส้ม', '#ea6a12', '#fff0e4' ),
		'amber'    => array( 'เหลืองทอง', '#c98a00', '#fff5d6' ),
	);
}

/** บริการทั่วไปของโรงพยาบาล (ค่าเริ่มต้น) */
function idw_svc_default_items() {
	$t     = function ( $th, $en ) {
		return array( 'th' => $th, 'en' => $en );
	};
	$c     = function ( $q ) {
		return '/doctor-schedule/?clinic=' . rawurlencode( $q );
	};
	$link  = $t( 'ดูตารางออกตรวจ', 'Clinic schedule' );
	$rows  = array(
		array( 'emergency', 'rose', 'อุบัติเหตุและฉุกเฉิน 24 ชม.', 'Emergency 24/7', 'ห้องฉุกเฉินพร้อมทีมแพทย์ พยาบาล และรถพยาบาลตลอด 24 ชั่วโมง โทร 1669', 'Emergency room, doctors, nurses and ambulance around the clock. Call 1669.', 'tel:1669', $t( 'โทร 1669', 'Call 1669' ) ),
		array( 'stethoscope', 'mint', 'ผู้ป่วยนอก / ตรวจโรคทั่วไป', 'Outpatient & general clinic', 'ตรวจรักษาโรคทั่วไป คัดกรอง และส่งต่อแพทย์เฉพาะทาง ในเวลาราชการ', 'General check-ups, screening and specialist referral during office hours.', $c( 'ทั่วไป' ), $link ),
		array( 'thermometer', 'sky', 'อายุรกรรม', 'Internal medicine', 'เบาหวาน ความดัน โรคหัวใจ โรคไต และโรคเรื้อรังอื่น ๆ', 'Diabetes, hypertension, heart, kidney and other chronic diseases.', $c( 'อายุรกรรม' ), $link ),
		array( 'bone', 'orange', 'ศัลยกรรม / ศัลยกรรมกระดูก', 'Surgery & orthopaedics', 'ผ่าตัดทั่วไป กระดูกและข้อ อุบัติเหตุ พร้อมห้องผ่าตัดและวิสัญญี', 'General surgery, bones and joints, trauma, with operating theatres and anaesthesia.', $c( 'ศัลยกรรม' ), $link ),
		array( 'pregnant', 'pink', 'สูติ-นรีเวชกรรม', 'Obstetrics & gynaecology', 'ฝากครรภ์ ห้องคลอด ตรวจภายใน และดูแลสุขภาพสตรี', 'Antenatal care, delivery room and women’s health.', $c( 'สูติ' ), $link ),
		array( 'baby', 'amber', 'กุมารเวชกรรม', 'Paediatrics', 'ดูแลเด็กป่วย วัคซีน ตรวจพัฒนาการ และทารกแรกเกิด', 'Sick children, vaccines, development checks and newborn care.', $c( 'กุมาร' ), $link ),
		array( 'eye', 'indigo', 'จักษุ / หู คอ จมูก', 'Eye & ENT', 'ตรวจรักษาโรคตา ต้อกระจก และโรคหู คอ จมูก', 'Eye diseases, cataract, and ear, nose and throat care.', $c( 'ตา' ), $link ),
		array( 'tooth', 'teal', 'ทันตกรรม', 'Dental care', 'ตรวจฟัน ขูดหินปูน อุดฟัน ถอนฟัน และทันตกรรมเฉพาะทาง', 'Check-ups, scaling, fillings, extractions and specialist dentistry.', $c( 'ทันต' ), $link ),
		array( 'leaf', 'green', 'แพทย์แผนไทย', 'Thai traditional medicine', 'นวด ประคบ อบสมุนไพร และยาสมุนไพร', 'Massage, herbal compress, herbal sauna and herbal medicine.', $c( 'แผนไทย' ), $link ),
		array( 'xray', 'blue', 'รังสีวิทยาและห้องปฏิบัติการ', 'Radiology & laboratory', 'เอกซเรย์ อัลตราซาวด์ และตรวจทางห้องปฏิบัติการ', 'X-ray, ultrasound and laboratory tests.', '', $t( '', '' ) ),
		array( 'wheelchair', 'lavender', 'เวชกรรมฟื้นฟู / กายภาพบำบัด', 'Rehabilitation', 'กายภาพบำบัด ฟื้นฟูผู้ป่วยหลังผ่าตัด และผู้ป่วยโรคหลอดเลือดสมอง', 'Physiotherapy and rehabilitation after surgery or stroke.', $c( 'กายภาพ' ), $link ),
		array( 'star', 'amber', 'คลินิกพิเศษนอกเวลาราชการ', 'After-hours special clinic', 'พบแพทย์เฉพาะทางนอกเวลาราชการ — แก้วันและเวลาให้ตรงกับของโรงพยาบาล', 'See a specialist after office hours — edit the days and times.', $c( 'นอกเวลา' ), $link ),
	);
	$items = array();
	foreach ( $rows as $r ) {
		$items[] = array( 'icon' => $r[0], 'tone' => $r[1], 'title' => $t( $r[2], $r[3] ), 'text' => $t( $r[4], $r[5] ), 'url' => $r[6], 'link' => $r[7], 'on' => true );
	}
	return $items;
}

function idw_svc_defaults() {
	return array(
		'kicker'  => array( 'th' => 'OUR SERVICES', 'en' => 'OUR SERVICES' ),
		'title'   => array( 'th' => 'บริการทางการแพทย์', 'en' => 'Our services' ),
		'lead'    => array( 'th' => '', 'en' => '' ),
		'columns' => 4,
		'style'   => 'soft',
		'bg'      => 'light',
		'items'   => idw_svc_default_items(),
	);
}

/** ข้อมูลที่บันทึกไว้ (หรือค่าเริ่มต้น) */
function idw_svc_data() {
	$d = get_option( 'idw_services' );
	return is_array( $d ) ? idw_svc_clean( $d ) : idw_svc_defaults();
}

/** ตรวจและทำความสะอาดข้อมูลทุกช่อง */
function idw_svc_clean( $d ) {
	$icons = idw_svc_icon_set();
	$tones = idw_svc_tones();
	$tx    = function ( $v, $multi = false ) {
		$v = is_array( $v ) ? $v : array( 'th' => (string) $v, 'en' => '' );
		$f = $multi ? 'sanitize_textarea_field' : 'sanitize_text_field';
		return array( 'th' => $f( (string) ( $v['th'] ?? '' ) ), 'en' => $f( (string) ( $v['en'] ?? '' ) ) );
	};
	$url   = function ( $u ) {
		$u = trim( (string) $u );
		if ( '' === $u ) {
			return '';
		}
		if ( '/' === $u[0] || '#' === $u[0] ) {
			return esc_url_raw( $u ) ? $u : '';
		}
		return esc_url_raw( $u, array( 'http', 'https', 'tel', 'mailto', 'line' ) );
	};
	$out   = array(
		'kicker'  => $tx( $d['kicker'] ?? '' ),
		'title'   => $tx( $d['title'] ?? '' ),
		'lead'    => $tx( $d['lead'] ?? '', true ),
		'columns' => max( 2, min( 6, (int) ( $d['columns'] ?? 4 ) ) ),
		'style'   => in_array( $d['style'] ?? '', array( 'soft', 'solid', 'outline' ), true ) ? $d['style'] : 'soft',
		'bg'      => in_array( $d['bg'] ?? '', array( 'light', 'white', 'none' ), true ) ? $d['bg'] : 'light',
		'items'   => array(),
	);
	foreach ( array_slice( (array) ( $d['items'] ?? array() ), 0, 60 ) as $it ) {
		if ( ! is_array( $it ) ) {
			continue;
		}
		$out['items'][] = array(
			'icon'  => isset( $icons[ $it['icon'] ?? '' ] ) ? $it['icon'] : 'plus',
			'tone'  => isset( $tones[ $it['tone'] ?? '' ] ) ? $it['tone'] : 'mint',
			'title' => $tx( $it['title'] ?? '' ),
			'text'  => $tx( $it['text'] ?? '', true ),
			'url'   => $url( $it['url'] ?? '' ),
			'link'  => $tx( $it['link'] ?? ( $it['linkText'] ?? '' ) ),
			'on'    => ! isset( $it['on'] ) || ! empty( $it['on'] ),
		);
	}
	return $out;
}

/* ---------- front end ---------- */

function idw_svc_lang() {
	if ( function_exists( 'idev_lang' ) ) {
		return idev_lang();
	}
	return 0 === strpos( determine_locale(), 'th' ) ? 'th' : 'en';
}
/** ข้อความตามภาษา (ภาษาอังกฤษว่างใช้ภาษาไทย) */
function idw_svc_t( $v, $lang = null ) {
	$lang = $lang ? $lang : idw_svc_lang();
	$v    = (array) $v;
	return 'en' === $lang && '' !== trim( (string) ( $v['en'] ?? '' ) ) ? $v['en'] : (string) ( $v['th'] ?? '' );
}
function idw_svc_icon( $name ) {
	$set = idw_svc_icon_set();
	return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . ( $set[ $name ][1] ?? $set['plus'][1] ) . '</svg>';
}
function idw_svc_href( $u ) {
	return ( '' !== $u && '/' === $u[0] && 0 !== strpos( $u, '//' ) ) ? home_url( $u ) : $u;
}

add_action( 'init', function () {
	wp_register_style( 'idw-services', IDW_SVC_URL . 'assets/services.css', array(), IDW_SVC_VER );
	wp_register_script( 'idw-services-block', IDW_SVC_URL . 'assets/block.js', array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render' ), IDW_SVC_VER, true );
	wp_add_inline_script( 'idw-services-block', 'window.IDW_SVC_ADMIN=' . wp_json_encode( admin_url( 'admin.php?page=idw-services' ) ) . ';', 'before' );
	register_block_type( 'idw/services', array(
		'api_version'     => 2,
		'title'           => 'บริการทางการแพทย์',
		'category'        => 'widgets',
		'icon'            => 'heart',
		'editor_script'   => 'idw-services-block',
		'style'           => 'idw-services',
		'attributes'      => array(
			'columns'   => array( 'type' => 'number', 'default' => 0 ),
			'limit'     => array( 'type' => 'number', 'default' => 0 ),
			'head'      => array( 'type' => 'boolean', 'default' => true ),
			'bg'        => array( 'type' => 'string', 'default' => '' ),
			'align'     => array( 'type' => 'string', 'default' => 'wide' ),
			'className' => array( 'type' => 'string', 'default' => '' ),
		),
		'supports'        => array( 'align' => array( 'wide', 'full' ), 'html' => false ),
		'render_callback' => 'idw_svc_render',
	) );
	add_shortcode( 'idw_services', function ( $a ) {
		$a = shortcode_atts( array( 'columns' => 0, 'limit' => 0, 'head' => '1', 'bg' => '', 'title' => '', 'align' => 'wide' ), $a, 'idw_services' );
		$a['head'] = ! in_array( strtolower( (string) $a['head'] ), array( '0', 'no', 'false' ), true );
		return idw_svc_render( $a );
	} );
} );

/**
 * การ์ดบริการ · $a: columns (0 = ตามที่ตั้งไว้), limit, head, bg, title (แทนหัวข้อ), align, className
 */
function idw_svc_render( $a = array(), $data = null ) {
	$a    = wp_parse_args( (array) $a, array( 'columns' => 0, 'limit' => 0, 'head' => true, 'bg' => '', 'title' => '', 'align' => 'wide', 'className' => '' ) );
	$d    = $data ? idw_svc_clean( $data ) : idw_svc_data();
	$lang = idw_svc_lang();
	$cols = (int) $a['columns'] ? max( 1, min( 6, (int) $a['columns'] ) ) : $d['columns'];
	$bg   = in_array( $a['bg'], array( 'light', 'white', 'none' ), true ) ? $a['bg'] : $d['bg'];
	$all  = array_values( array_filter( $d['items'], function ( $i ) {
		return $i['on'] && '' !== trim( $i['title']['th'] . $i['title']['en'] );
	} ) );
	if ( (int) $a['limit'] > 0 ) {
		$all = array_slice( $all, 0, (int) $a['limit'] );
	}
	if ( ! $all ) {
		return current_user_can( 'edit_posts' ) ? '<p class="idw-svc-empty">ยังไม่มีการ์ดบริการ — เพิ่มได้ที่เมนู “บริการทางการแพทย์”</p>' : '';
	}
	wp_enqueue_style( 'idw-services' );
	$tones = idw_svc_tones();
	$cls   = 'idw-svc idw-svc--' . $d['style'] . ' idw-svc--bg-' . $bg;
	if ( in_array( $a['align'], array( 'wide', 'full' ), true ) ) {
		$cls .= ' align' . $a['align'];
	}
	if ( $a['className'] ) {
		$cls .= ' ' . implode( ' ', array_map( 'sanitize_html_class', preg_split( '/\s+/', (string) $a['className'] ) ) );
	}
	$h = '<section class="' . esc_attr( $cls ) . '" id="services" style="--idw-svc-cols:' . (int) $cols . '"><div class="idw-svc__in">';
	if ( $a['head'] ) {
		$title = '' !== (string) $a['title'] ? (string) $a['title'] : idw_svc_t( $d['title'], $lang );
		$kick  = idw_svc_t( $d['kicker'], $lang );
		$lead  = idw_svc_t( $d['lead'], $lang );
		if ( $title || $kick ) {
			$h .= '<header class="idw-svc__head">' . ( $kick ? '<span class="idw-svc__kicker">' . esc_html( $kick ) . '</span>' : '' ) . ( $title ? '<h2 class="idw-svc__title">' . esc_html( $title ) . '</h2>' : '' ) . ( $lead ? '<p class="idw-svc__lead">' . esc_html( $lead ) . '</p>' : '' ) . '</header>';
		}
	}
	$h .= '<div class="idw-svc__grid">';
	foreach ( $all as $i ) {
		$tone  = $tones[ $i['tone'] ] ?? $tones['mint'];
		$title = idw_svc_t( $i['title'], $lang );
		$link  = idw_svc_t( $i['link'], $lang );
		$url   = idw_svc_href( $i['url'] );
		$h    .= '<article class="idw-svc__card' . ( $url ? ' has-link' : '' ) . '" style="--tone:' . esc_attr( $tone[1] ) . ';--tone-bg:' . esc_attr( $tone[2] ) . '">';
		$h    .= '<span class="idw-svc__ico">' . idw_svc_icon( $i['icon'] ) . '</span>';
		$h    .= '<h3 class="idw-svc__name">' . esc_html( $title ) . '</h3>';
		$text  = idw_svc_t( $i['text'], $lang );
		if ( $text ) {
			$h .= '<p class="idw-svc__text">' . esc_html( $text ) . '</p>';
		}
		if ( $url ) {
			$label = $link ? $link : ( 'en' === $lang ? 'Learn more' : 'ดูรายละเอียด' );
			$h    .= '<a class="idw-svc__more" href="' . esc_url( $url ) . '"' . ( $link ? '' : ' aria-label="' . esc_attr( $title ) . '"' ) . '>' . esc_html( $label ) . ' <span aria-hidden="true">→</span></a>';
		}
		$h .= '</article>';
	}
	return $h . '</div></div></section>';
}

/* ---------- home page: put the block on the front page ---------- */

/** ใส่บล็อก “บริการทางการแพทย์” ลงหน้าแรก · คืน added | exists | nopage */
function idw_svc_add_to_home() {
	$pid = (int) get_option( 'page_on_front' );
	if ( 'page' !== get_option( 'show_on_front' ) || ! $pid || ! get_post( $pid ) ) {
		return 'nopage';
	}
	$content = (string) get_post_field( 'post_content', $pid );
	if ( has_block( 'idw/services', $content ) ) {
		return 'exists';
	}
	$blocks = parse_blocks( $content );
	$new    = parse_blocks( '<!-- wp:idw/services {"align":"wide"} /-->' );
	$at     = -1;
	foreach ( $blocks as $i => $b ) {
		$cls = (string) ( $b['attrs']['className'] ?? '' );
		/* a services section made before this module: the Hub cards block or the plain theme-1 section */
		if ( ( 'idevapp/cards' === $b['blockName'] && 'services' === ( $b['attrs']['settings']['anchor'] ?? '' ) ) || false !== strpos( $cls, 'hos-services' ) ) {
			if ( 'idevapp/cards' === $b['blockName'] && ! is_array( get_option( 'idw_services' ) ) ) {
				idw_svc_import_hub( $b['attrs']['data'] ?? array() );
			}
			array_splice( $blocks, $i, 1, $new );
			$at = -2;
			break;
		}
		if ( false !== strpos( $cls, 'hos-quick-g' ) || 'idevapp/hero' === $b['blockName'] || 'idevapp/quicklinks' === $b['blockName'] ) {
			$at = $i + 1;
		}
	}
	if ( -2 !== $at ) {
		if ( $at < 0 ) {
			$at = min( 1, count( $blocks ) );
		}
		array_splice( $blocks, $at, 0, $new );
	}
	kses_remove_filters();
	wp_update_post( array( 'ID' => $pid, 'post_content' => wp_slash( serialize_blocks( $blocks ) ) ) );
	kses_init_filters();
	do_action( 'litespeed_purge_all' );
	return 'added';
}

/** รับการ์ดจากบล็อกการ์ดบริการของ Hub ที่เคยแก้ไว้ (รูปแบบข้อมูลใกล้กัน) */
function idw_svc_import_hub( $data ) {
	if ( empty( $data['items'] ) || ! is_array( $data['items'] ) ) {
		return;
	}
	$d          = idw_svc_defaults();
	$d['items'] = $data['items'];
	foreach ( array( 'kicker', 'title' ) as $k ) {
		if ( ! empty( $data[ $k ] ) ) {
			$d[ $k ] = $data[ $k ];
		}
	}
	if ( ! empty( $data['columns'] ) ) {
		$d['columns'] = (int) $data['columns'];
	}
	update_option( 'idw_services', idw_svc_clean( $d ), false );
}

/* theme แบบที่ 1: the home page gets the services block once (sites made before this module) */
add_action( 'admin_init', function () {
	if ( get_option( 'idw_svc_home_v1' ) || ! current_user_can( 'edit_pages' ) || 'idevapp-theme-1' !== get_stylesheet() ) {
		return;
	}
	update_option( 'idw_svc_home_v1', idw_svc_add_to_home(), false );
} );

/* ---------- admin editor ---------- */

add_action( 'admin_menu', function () {
	add_menu_page( 'บริการทางการแพทย์', 'บริการทางการแพทย์', 'edit_pages', 'idw-services', 'idw_svc_page', 'dashicons-heart', 22 );
} );
add_action( 'load-toplevel_page_idw-services', function () {
	global $title;
	$title = 'บริการทางการแพทย์'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- the program-mode menu may hide this item
} );

add_action( 'admin_enqueue_scripts', function () {
	if ( 'idw-services' !== ( $_GET['page'] ?? '' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	$deps = wp_style_is( 'idw-admin', 'registered' ) ? array( 'idw-admin', 'idw-services' ) : array( 'idw-services' );
	wp_enqueue_style( 'idw-services-admin', IDW_SVC_URL . 'assets/admin.css', $deps, IDW_SVC_VER );
	wp_enqueue_script( 'idw-services-admin', IDW_SVC_URL . 'assets/admin.js', array( 'jquery', 'jquery-ui-sortable' ), IDW_SVC_VER, true );
	$icons = array();
	foreach ( idw_svc_icon_set() as $k => $v ) {
		$icons[ $k ] = array( $v[0], $v[1] );
	}
	wp_localize_script( 'idw-services-admin', 'IDW_SVC', array(
		'data'     => idw_svc_data(),
		'defaults' => idw_svc_defaults(),
		'icons'    => $icons,
		'tones'    => idw_svc_tones(),
	) );
} );

add_action( 'admin_post_idw_svc_save', function () {
	if ( ! current_user_can( 'edit_pages' ) || ! check_admin_referer( 'idw_svc_save' ) ) {
		wp_die( 'ไม่มีสิทธิ์', 403 );
	}
	$d = json_decode( wp_unslash( $_POST['data'] ?? '' ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- idw_svc_clean() sanitises every field
	if ( is_array( $d ) ) {
		update_option( 'idw_services', idw_svc_clean( $d ), false );
	}
	$r = '';
	if ( ! empty( $_POST['add_home'] ) && current_user_can( 'edit_pages' ) ) {
		$r = idw_svc_add_to_home();
	}
	do_action( 'litespeed_purge_all' );
	wp_safe_redirect( admin_url( 'admin.php?page=idw-services&saved=1' . ( $r ? '&home=' . $r : '' ) ) );
	exit;
} );

function idw_svc_page() {
	$own = function_exists( 'idw_open' );
	if ( $own ) {
		idw_open( 'บริการทางการแพทย์', 'การ์ดบริการที่แสดงบนหน้าเว็บ — เลือกไอคอน สี ข้อความไทย / อังกฤษ และลิงก์ ลากเพื่อเรียงลำดับ ใช้ได้กับทุกธีม' );
	} else {
		echo '<div class="wrap idw"><div class="idw-body"><h1>บริการทางการแพทย์</h1>';
	}
	if ( isset( $_GET['saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$home = sanitize_key( $_GET['home'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$msg  = array( 'added' => ' และใส่ลงหน้าแรกแล้ว', 'exists' => ' (หน้าแรกมีส่วนนี้อยู่แล้ว)', 'nopage' => ' — แต่ยังไม่ได้ตั้งหน้าแรกเป็นหน้าเว็บ (การตั้งค่า → การอ่าน)' );
		echo '<div class="idw-note">บันทึกแล้ว' . esc_html( $msg[ $home ] ?? '' ) . ' <a href="' . esc_url( home_url( '/' ) ) . '" target="_blank" rel="noopener">ดูหน้าเว็บ ↗</a></div>';
	}
	$pid     = (int) get_option( 'page_on_front' );
	$on_home = 'page' === get_option( 'show_on_front' ) && $pid && has_block( 'idw/services', (string) get_post_field( 'post_content', $pid ) );
	$pages   = get_pages( array( 'sort_column' => 'menu_order,post_title', 'number' => 200 ) );

	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" id="svc-form">';
	wp_nonce_field( 'idw_svc_save' );
	echo '<input type="hidden" name="action" value="idw_svc_save"><input type="hidden" name="data" id="svc-data">';

	echo '<div class="svc-top"><div class="idw-card svc-head"><h2>หัวข้อส่วน</h2><div class="svc-lang-row">';
	foreach ( array( 'th' => 'ภาษาไทย', 'en' => 'English' ) as $l => $ln ) {
		echo '<div class="svc-lang"><span class="svc-lang-tag">' . esc_html( $ln ) . '</span>';
		echo '<label class="idw-field">ข้อความเล็กด้านบน<input class="idw-in" data-h="kicker" data-l="' . esc_attr( $l ) . '"></label>';
		echo '<label class="idw-field">หัวข้อ<input class="idw-in" data-h="title" data-l="' . esc_attr( $l ) . '"></label>';
		echo '<label class="idw-field">คำอธิบาย (ไม่บังคับ)<textarea class="idw-in" rows="2" data-h="lead" data-l="' . esc_attr( $l ) . '"></textarea></label></div>';
	}
	echo '</div></div>';
	echo '<div class="idw-card svc-side"><h2>รูปแบบ</h2>';
	echo '<label class="idw-field">จำนวนคอลัมน์ (จอคอมพิวเตอร์)<select class="idw-in" data-o="columns"><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option></select><small>มือถือแสดง 1–2 คอลัมน์อัตโนมัติ</small></label>';
	echo '<div class="idw-field">ไอคอน<div class="svc-seg" data-o="style"><button type="button" data-v="soft">พื้นอ่อน</button><button type="button" data-v="solid">พื้นเข้ม</button><button type="button" data-v="outline">เส้นขอบ</button></div></div>';
	echo '<div class="idw-field">พื้นหลังส่วน<div class="svc-seg" data-o="bg"><button type="button" data-v="light">เทาอ่อน</button><button type="button" data-v="white">ขาว</button><button type="button" data-v="none">โปร่งใส</button></div></div>';
	echo '<div class="svc-use"><b>วิธีแสดงบนหน้าเว็บ</b><span>ในตัวแก้ไขหน้า กด + แล้วค้นหา “บริการทางการแพทย์” หรือวางรหัสย่อ <code>[idw_services]</code> (ใส่ <code>columns="3"</code> <code>limit="6"</code> ได้)</span>';
	if ( $on_home ) {
		echo '<span class="svc-ok"><span class="dashicons dashicons-yes-alt"></span>หน้าแรกแสดงส่วนนี้อยู่แล้ว</span>';
	} else {
		echo '<label class="svc-check"><input type="checkbox" name="add_home" value="1"> ใส่ลงหน้าแรกเมื่อบันทึก</label>';
	}
	echo '</div></div></div>';

	echo '<div class="svc-bar"><h2>การ์ดบริการ <small id="svc-count"></small></h2><span class="svc-hint"><span class="dashicons dashicons-move"></span>ลากเพื่อเรียงลำดับ</span><button type="button" class="idw-btn" id="svc-reset">คืนค่าเริ่มต้น</button><button type="button" class="idw-btn acc" id="svc-add"><span class="dashicons dashicons-plus-alt2"></span>เพิ่มการ์ด</button></div>';
	echo '<div class="svc-main"><div class="svc-list" id="svc-list"></div>';
	echo '<div class="svc-pv-wrap"><div class="svc-pv-head"><b>ตัวอย่าง</b><div class="svc-seg sm" id="svc-pv-lang"><button type="button" data-v="th" class="on">ไทย</button><button type="button" data-v="en">EN</button></div></div><div class="svc-pv" id="svc-pv"></div></div></div>';
	echo '<datalist id="svc-pages"><option value="/">หน้าแรก</option><option value="tel:1669">โทร 1669</option>';
	foreach ( $pages as $p ) {
		$path = wp_make_link_relative( get_permalink( $p ) );
		echo '<option value="' . esc_attr( $path ) . '">' . esc_html( $p->post_title ) . '</option>';
	}
	echo '</datalist>';
	echo '<div class="svc-pop" id="svc-pop" hidden><input type="search" class="idw-in" placeholder="ค้นหาไอคอน…" id="svc-pop-q"><div class="svc-pop-grid" id="svc-pop-grid"></div></div>';
	echo '<div class="idw-savebar"><span class="msg" id="svc-msg">ยังไม่มีการแก้ไข</span><a class="idw-btn link" href="' . esc_url( home_url( '/' ) ) . '" target="_blank" rel="noopener">ดูหน้าเว็บ ↗</a><button class="idw-btn pri" id="svc-save"><span class="dashicons dashicons-yes"></span>บันทึก</button></div></form>';
	if ( $own ) {
		idw_close();
	} else {
		echo '</div></div>';
	}
}
