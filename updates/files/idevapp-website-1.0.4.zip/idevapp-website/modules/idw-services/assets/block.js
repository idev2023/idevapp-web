/* บล็อก “บริการทางการแพทย์” — การ์ดแก้ที่หน้า บริการทางการแพทย์ ในหลังบ้าน แถบขวาปรับการแสดงผลของบล็อกนี้ */
( function ( wp ) {
	var el = wp.element.createElement, be = wp.blockEditor, c = wp.components, SSR = wp.serverSideRender;
	var admin = window.IDW_SVC_ADMIN || 'admin.php?page=idw-services';
	wp.blocks.registerBlockType( 'idw/services', {
		apiVersion: 2,
		title: 'บริการทางการแพทย์',
		description: 'การ์ดบริการ (ไอคอน ชื่อบริการ คำอธิบาย ลิงก์) — แก้การ์ดได้ที่เมนู บริการทางการแพทย์',
		category: 'widgets',
		icon: 'heart',
		keywords: [ 'services', 'บริการ', 'การ์ด', 'คลินิก' ],
		supports: { align: [ 'wide', 'full' ], html: false },
		attributes: {
			columns: { type: 'number', default: 0 },
			limit: { type: 'number', default: 0 },
			head: { type: 'boolean', default: true },
			bg: { type: 'string', default: '' },
			align: { type: 'string', default: 'wide' }
		},
		edit: function ( p ) {
			var a = p.attributes, set = p.setAttributes;
			return el( 'div', be.useBlockProps(),
				el( be.InspectorControls, null,
					el( c.PanelBody, { title: 'การ์ดบริการ', initialOpen: true },
						el( 'p', null, 'ไอคอน ข้อความ และลิงก์ของการ์ดแก้ได้ในหน้าเดียว ใช้ร่วมกันทุกหน้าที่วางบล็อกนี้' ),
						el( c.Button, { variant: 'primary', href: admin, target: '_blank' }, 'แก้ไขการ์ดบริการ ↗' )
					),
					el( c.PanelBody, { title: 'การแสดงผลในหน้านี้', initialOpen: true },
						el( c.ToggleControl, { label: 'แสดงหัวข้อ', checked: a.head, onChange: function ( v ) { set( { head: v } ); } } ),
						el( c.RangeControl, { label: 'จำนวนคอลัมน์ (0 = ตามที่ตั้งไว้)', min: 0, max: 6, value: a.columns, onChange: function ( v ) { set( { columns: v || 0 } ); } } ),
						el( c.RangeControl, { label: 'แสดงไม่เกิน (0 = ทั้งหมด)', min: 0, max: 24, value: a.limit, onChange: function ( v ) { set( { limit: v || 0 } ); } } ),
						el( c.SelectControl, { label: 'พื้นหลัง', value: a.bg, options: [ { label: 'ตามที่ตั้งไว้', value: '' }, { label: 'เทาอ่อน', value: 'light' }, { label: 'ขาว', value: 'white' }, { label: 'โปร่งใส', value: 'none' } ], onChange: function ( v ) { set( { bg: v } ); } } )
					)
				),
				el( c.Disabled, null, el( SSR, { block: 'idw/services', attributes: a } ) )
			);
		},
		save: function () { return null; }
	} );
} )( window.wp );
