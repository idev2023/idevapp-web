/* หน้าแก้ไข “บริการทางการแพทย์”: การ์ด · ไอคอน · สี · ไทย / อังกฤษ · ลากเรียง · ตัวอย่างสด */
( function ( $ ) {
	var S = window.IDW_SVC; if ( ! S ) return;
	var data = JSON.parse( JSON.stringify( S.data ) ), dirty = false, pvLang = 'th', open = {}, popFor = null;
	var $list = $( '#svc-list' ), $pv = $( '#svc-pv' ), $pop = $( '#svc-pop' ).appendTo( document.body );

	function esc( s ) { return String( s == null ? '' : s ).replace( /[&<>"']/g, function ( c ) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ]; } ); }
	function icon( k ) { var i = S.icons[ k ] || S.icons.plus; return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + i[ 1 ] + '</svg>'; }
	function tone( k ) { return S.tones[ k ] || S.tones.mint; }
	function t( v, l ) { v = v || {}; return l === 'en' && ( v.en || '' ).trim() ? v.en : ( v.th || '' ); }
	function blank() { return { icon: 'plus', tone: 'mint', title: { th: '', en: '' }, text: { th: '', en: '' }, url: '', link: { th: '', en: '' }, on: true }; }
	function touch() { dirty = true; $( '#svc-msg' ).text( 'มีการแก้ไขที่ยังไม่บันทึก' ).addClass( 'warn' ); preview(); }

	/* ---------- header & options ---------- */
	function head() {
		$( '[data-h]' ).each( function () { var h = this.dataset.h, l = this.dataset.l; this.value = ( data[ h ] || {} )[ l ] || ''; } );
		$( '[data-o="columns"]' ).val( String( data.columns ) );
		$( '.svc-seg[data-o]' ).each( function () { var o = this.dataset.o; $( this ).find( 'button' ).each( function () { $( this ).toggleClass( 'on', this.dataset.v === data[ o ] ); } ); } );
	}
	$( document ).on( 'input', '[data-h]', function () { var h = this.dataset.h; data[ h ] = data[ h ] || { th: '', en: '' }; data[ h ][ this.dataset.l ] = this.value; touch(); } );
	$( '[data-o="columns"]' ).on( 'change', function () { data.columns = +this.value; touch(); } );
	$( document ).on( 'click', '.svc-seg[data-o] button', function () { var o = $( this ).closest( '.svc-seg' ).data( 'o' ); data[ o ] = this.dataset.v; head(); touch(); } );
	$( '#svc-pv-lang button' ).on( 'click', function () { pvLang = this.dataset.v; $( this ).addClass( 'on' ).siblings().removeClass( 'on' ); preview(); } );

	/* ---------- card list ---------- */
	function swatches( i, cur ) {
		var h = '';
		$.each( S.tones, function ( k, v ) { h += '<button type="button" class="svc-sw' + ( k === cur ? ' on' : '' ) + '" data-tone="' + k + '" title="' + esc( v[ 0 ] ) + '" style="--tone:' + v[ 1 ] + ';--tone-bg:' + v[ 2 ] + '"></button>'; } );
		return h;
	}
	function field( i, key, l, label, multi, extra ) {
		var v = key === 'url' ? data.items[ i ].url : ( data.items[ i ][ key ] || {} )[ l ] || '';
		var a = ' class="idw-in" data-k="' + key + '"' + ( l ? ' data-l="' + l + '"' : '' ) + ( extra || '' );
		return '<label class="idw-field">' + label + ( multi ? '<textarea rows="2"' + a + '>' + esc( v ) + '</textarea>' : '<input' + a + ' value="' + esc( v ) + '">' ) + '</label>';
	}
	function row( it, i ) {
		var tn = tone( it.tone ), isOpen = !! open[ i ];
		var h = '<div class="svc-item' + ( it.on ? '' : ' off' ) + ( isOpen ? ' open' : '' ) + '" data-i="' + i + '">';
		h += '<div class="svc-item-h"><span class="svc-drag dashicons dashicons-menu" title="ลากเพื่อเรียง"></span>';
		h += '<button type="button" class="svc-ico-btn" data-act="icon" title="เปลี่ยนไอคอน" style="--tone:' + tn[ 1 ] + ';--tone-bg:' + tn[ 2 ] + '">' + icon( it.icon ) + '</button>';
		h += '<button type="button" class="svc-item-name" data-act="toggle"><b>' + ( esc( it.title.th ) || '<i>การ์ดใหม่ — ใส่ชื่อบริการ</i>' ) + '</b><small>' + esc( it.title.en || '' ) + '</small></button>';
		h += '<label class="svc-switch" title="แสดง / ซ่อนการ์ดนี้"><input type="checkbox" data-act="on"' + ( it.on ? ' checked' : '' ) + '><span></span></label>';
		h += '<button type="button" class="svc-mini" data-act="dup" title="ทำสำเนา"><span class="dashicons dashicons-admin-page"></span></button>';
		h += '<button type="button" class="svc-mini del" data-act="del" title="ลบการ์ด"><span class="dashicons dashicons-trash"></span></button>';
		h += '<button type="button" class="svc-mini" data-act="toggle" title="แก้ไข"><span class="dashicons dashicons-arrow-down-alt2"></span></button></div>';
		h += '<div class="svc-item-b"><div class="svc-tones"><span>สีไอคอน</span>' + swatches( i, it.tone ) + '</div>';
		h += '<div class="svc-2col"><div>' + field( i, 'title', 'th', 'ชื่อบริการ (ไทย)' ) + field( i, 'text', 'th', 'คำอธิบายสั้น (ไทย)', true ) + '</div>';
		h += '<div>' + field( i, 'title', 'en', 'Name (English)' ) + field( i, 'text', 'en', 'Short text (English)', true ) + '</div></div>';
		h += '<div class="svc-3col">' + field( i, 'url', '', 'ลิงก์ (เว้นว่าง = ไม่มีลิงก์)', false, ' list="svc-pages" placeholder="/doctor-schedule/ หรือ tel:1669"' ) + field( i, 'link', 'th', 'ข้อความลิงก์ (ไทย)', false, ' placeholder="ดูรายละเอียด"' ) + field( i, 'link', 'en', 'Link text (English)', false, ' placeholder="Learn more"' ) + '</div></div></div>';
		return h;
	}
	function list() {
		$list.html( data.items.map( row ).join( '' ) || '<div class="svc-none">ยังไม่มีการ์ด — กด “เพิ่มการ์ด”</div>' );
		var on = data.items.filter( function ( x ) { return x.on; } ).length;
		$( '#svc-count' ).text( data.items.length + ' การ์ด · แสดง ' + on );
	}
	$list.sortable( { handle: '.svc-drag', items: '.svc-item', placeholder: 'svc-ph', forcePlaceholderSize: true, update: function () {
		var order = $list.children( '.svc-item' ).map( function () { return +this.dataset.i; } ).get(), o2 = {};
		data.items = order.map( function ( k, n ) { if ( open[ k ] ) o2[ n ] = 1; return data.items[ k ]; } );
		open = o2; list(); touch();
	} } );
	$list.on( 'input', '[data-k]', function () {
		var i = +$( this ).closest( '.svc-item' ).data( 'i' ), k = this.dataset.k, it = data.items[ i ];
		if ( k === 'url' ) it.url = this.value; else { it[ k ] = it[ k ] || { th: '', en: '' }; it[ k ][ this.dataset.l ] = this.value; }
		if ( k === 'title' ) { var $h = $( this ).closest( '.svc-item' ).find( '.svc-item-name' ); $h.find( 'b' ).html( esc( it.title.th ) || '<i>การ์ดใหม่ — ใส่ชื่อบริการ</i>' ); $h.find( 'small' ).text( it.title.en || '' ); }
		touch();
	} );
	$list.on( 'click change', '[data-act]', function ( e ) {
		var act = this.dataset.act, $it = $( this ).closest( '.svc-item' ), i = +$it.data( 'i' );
		if ( ( act === 'on' ) !== ( e.type === 'change' ) ) return;
		if ( act === 'toggle' ) { open[ i ] = ! open[ i ]; $it.toggleClass( 'open', !! open[ i ] ); return; }
		if ( act === 'icon' ) { e.stopPropagation(); return showPop( i, this ); }
		if ( act === 'on' ) { data.items[ i ].on = this.checked; $it.toggleClass( 'off', ! this.checked ); list(); }
		if ( act === 'dup' ) { data.items.splice( i + 1, 0, JSON.parse( JSON.stringify( data.items[ i ] ) ) ); shiftOpen( i + 1, 1 ); open[ i + 1 ] = 1; list(); }
		if ( act === 'del' ) { if ( ! window.confirm( 'ลบการ์ด “' + ( data.items[ i ].title.th || 'ไม่มีชื่อ' ) + '” ?' ) ) return; data.items.splice( i, 1 ); shiftOpen( i, -1 ); list(); }
		touch();
	} );
	$list.on( 'click', '.svc-sw', function () {
		var i = +$( this ).closest( '.svc-item' ).data( 'i' ), tn = tone( this.dataset.tone );
		data.items[ i ].tone = this.dataset.tone;
		$( this ).addClass( 'on' ).siblings( '.svc-sw' ).removeClass( 'on' );
		$( this ).closest( '.svc-item' ).find( '.svc-ico-btn' ).css( { '--tone': tn[ 1 ], '--tone-bg': tn[ 2 ] } );
		touch();
	} );
	function shiftOpen( from, d ) { var o2 = {}; $.each( open, function ( k, v ) { k = +k; if ( k < from ) o2[ k ] = v; else if ( k + d >= from ) o2[ k + d ] = v; } ); open = o2; }

	$( '#svc-add' ).on( 'click', function () {
		data.items.push( blank() ); open[ data.items.length - 1 ] = 1; list(); touch();
		var $n = $list.children( '.svc-item' ).last(); $n[ 0 ].scrollIntoView( { behavior: 'smooth', block: 'center' } ); $n.find( '[data-k="title"]' ).first().trigger( 'focus' );
	} );
	$( '#svc-reset' ).on( 'click', function () {
		if ( ! window.confirm( 'คืนค่าเริ่มต้น? การ์ดและหัวข้อที่แก้ไว้จะถูกแทนด้วยบริการมาตรฐาน 12 รายการ (ยังไม่บันทึกจนกว่าจะกดบันทึก)' ) ) return;
		data = JSON.parse( JSON.stringify( S.defaults ) ); open = {}; head(); list(); touch();
	} );

	/* ---------- icon picker ---------- */
	function popGrid( q ) {
		q = ( q || '' ).trim().toLowerCase(); var h = '', cur = popFor != null ? data.items[ popFor ].icon : '';
		$.each( S.icons, function ( k, v ) { if ( q && k.indexOf( q ) < 0 && v[ 0 ].toLowerCase().indexOf( q ) < 0 ) return; h += '<button type="button" data-icon="' + k + '" class="' + ( k === cur ? 'on' : '' ) + '" title="' + esc( v[ 0 ] ) + '">' + icon( k ) + '<span>' + esc( v[ 0 ] ) + '</span></button>'; } );
		$( '#svc-pop-grid' ).html( h || '<p>ไม่พบไอคอน</p>' );
	}
	function showPop( i, btn ) {
		popFor = i; $( '#svc-pop-q' ).val( '' ); popGrid( '' );
		var r = btn.getBoundingClientRect(); $pop.prop( 'hidden', false ).css( { top: r.bottom + window.scrollY + 6, left: Math.max( 8, Math.min( r.left + window.scrollX, window.innerWidth - $pop.outerWidth() - 16 ) ) } );
		$( '#svc-pop-q' ).trigger( 'focus' );
	}
	$( '#svc-pop-q' ).on( 'input', function () { popGrid( this.value ); } );
	$pop.on( 'click', '[data-icon]', function () {
		data.items[ popFor ].icon = this.dataset.icon;
		$list.find( '.svc-item[data-i="' + popFor + '"] .svc-ico-btn' ).html( icon( this.dataset.icon ) );
		$pop.prop( 'hidden', true ); touch();
	} );
	$( document ).on( 'click', function ( e ) { if ( ! $pop.prop( 'hidden' ) && ! $( e.target ).closest( '#svc-pop' ).length ) $pop.prop( 'hidden', true ); } );
	$( document ).on( 'keydown', function ( e ) { if ( e.key === 'Escape' ) $pop.prop( 'hidden', true ); } );

	/* ---------- live preview (same markup as the site) ---------- */
	function preview() {
		var l = pvLang, items = data.items.filter( function ( x ) { return x.on && ( x.title.th + x.title.en ).trim(); } );
		var h = '<section class="idw-svc idw-svc--' + data.style + ' idw-svc--bg-' + data.bg + '" style="--idw-svc-cols:' + data.columns + '"><div class="idw-svc__in">';
		var kick = t( data.kicker, l ), title = t( data.title, l ), lead = t( data.lead, l );
		if ( kick || title ) h += '<header class="idw-svc__head">' + ( kick ? '<span class="idw-svc__kicker">' + esc( kick ) + '</span>' : '' ) + ( title ? '<h2 class="idw-svc__title">' + esc( title ) + '</h2>' : '' ) + ( lead ? '<p class="idw-svc__lead">' + esc( lead ) + '</p>' : '' ) + '</header>';
		h += '<div class="idw-svc__grid">';
		items.forEach( function ( it ) {
			var tn = tone( it.tone ), txt = t( it.text, l ), lk = t( it.link, l ) || ( l === 'en' ? 'Learn more' : 'ดูรายละเอียด' );
			h += '<article class="idw-svc__card' + ( it.url ? ' has-link' : '' ) + '" style="--tone:' + tn[ 1 ] + ';--tone-bg:' + tn[ 2 ] + '"><span class="idw-svc__ico">' + icon( it.icon ) + '</span><h3 class="idw-svc__name">' + esc( t( it.title, l ) ) + '</h3>' + ( txt ? '<p class="idw-svc__text">' + esc( txt ) + '</p>' : '' ) + ( it.url ? '<span class="idw-svc__more">' + esc( lk ) + ' →</span>' : '' ) + '</article>';
		} );
		h += '</div></div></section>';
		$pv.html( items.length ? '<div class="svc-pv-scale">' + h + '</div>' : '<div class="svc-none">ไม่มีการ์ดที่แสดง</div>' );
		fit();
	}
	/* the preview is drawn at desktop width (1200px) and scaled down, so the columns look like the real site */
	function fit() {
		var $s = $pv.children( '.svc-pv-scale' ); if ( ! $s.length ) { $pv.css( 'height', '' ); return; }
		var w = $pv.width(), base = w < 700 ? w : 1200, k = Math.min( 1, w / base ); /* small screens: show the phone layout as it is */
		$s.css( { width: base, transform: 'scale(' + k + ')' } ); $pv.css( 'height', Math.ceil( $s[ 0 ].offsetHeight * k ) );
	}
	$( window ).on( 'resize', fit );

	/* ---------- save ---------- */
	$( '#svc-form' ).on( 'submit', function () { $( '#svc-data' ).val( JSON.stringify( data ) ); dirty = false; $( '#svc-save' ).prop( 'disabled', true ).addClass( 'busy' ); } );
	$( '[name="add_home"]' ).on( 'change', function () { if ( this.checked ) touch(); } );
	window.addEventListener( 'beforeunload', function ( e ) { if ( dirty ) { e.preventDefault(); e.returnValue = ''; } } );

	head(); list(); preview();
} )( jQuery );
