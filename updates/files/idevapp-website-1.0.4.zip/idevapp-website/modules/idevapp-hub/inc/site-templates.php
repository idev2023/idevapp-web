<?php
/**
 * Website templates for government agencies and hospitals, in one click:
 * - "ราชการ เน้นข่าวสาร": news, announcements, procurement, public information (ITA/OIT)
 * - "ราชการ เน้นบริการ": services, booking, registration, steps, fees, FAQ
 * Both include the pages a Thai government website needs (about, structure, public information, complaints,
 * contact, policies, site map). Pages are made from the iDevApp blocks, so everything stays editable.
 */
defined('ABSPATH') || exit;

function ihub_tpl_b($type, $data = [], $settings = []) {
    $def = ihub_block_types()[$type]['data'] ?? [];
    return ihub_block_markup($type, array_merge($def, $data), $settings);
}
function ihub_tpl_rich($th, $en = '') { return ihub_tpl_b('richtext', ['html' => ihub_bt($th, $en)]); }

/** Typical services of a hospital / clinic for the "บริการของเรา" cards (edit them in the block). */
function ihub_tpl_service_items() {
    $sched = home_url('/schedule/');
    $rows = [
        ['emergency', 'rose', 'อุบัติเหตุและฉุกเฉิน', 'Emergency', 'ดูแลผู้ป่วยฉุกเฉิน โทร 1669', 'Emergency care. Call 1669.', 'tel:1669', ['โทร 1669', 'Call 1669']],
        ['stethoscope', 'mint', 'ตรวจโรคทั่วไป', 'General clinic', 'ตรวจรักษาโรคทั่วไป คัดกรอง และส่งต่อแพทย์เฉพาะทาง', 'General check-ups, screening and referral.', $sched, ['ตารางออกตรวจ', 'Schedule']],
        ['thermometer', 'sky', 'อายุรกรรม / โรคเรื้อรัง', 'Internal medicine', 'เบาหวาน ความดัน หัวใจ และโรคเรื้อรัง', 'Diabetes, blood pressure, heart and chronic diseases.', $sched, ['ตารางออกตรวจ', 'Schedule']],
        ['baby', 'amber', 'แม่และเด็ก', 'Mother & child', 'ฝากครรภ์ วัคซีน และตรวจพัฒนาการเด็ก', 'Antenatal care, vaccines and child development.', $sched, ['ตารางออกตรวจ', 'Schedule']],
        ['tooth', 'teal', 'ทันตกรรม', 'Dental care', 'ตรวจฟัน ขูดหินปูน อุดฟัน และถอนฟัน', 'Check-ups, scaling, fillings and extractions.', $sched, ['ตารางออกตรวจ', 'Schedule']],
        ['leaf', 'green', 'แพทย์แผนไทย', 'Thai traditional medicine', 'นวด ประคบ และยาสมุนไพร', 'Massage, herbal compress and herbal medicine.', $sched, ['ตารางออกตรวจ', 'Schedule']],
    ];
    $items = [];
    foreach ($rows as $r) $items[] = ['icon' => $r[0], 'tone' => $r[1], 'title' => ihub_bt($r[2], $r[3]), 'text' => ihub_bt($r[4], $r[5]), 'url' => $r[6], 'linkText' => ihub_bt($r[7][0], $r[7][1]), 'image' => '', 'imageMode' => 'cover'];
    return $items;
}

/** Pages every government website should have: [slug => [title, title_en, blocks]]. */
function ihub_tpl_common_pages() {
    $s = ihub_settings();
    $org_chart = shortcode_exists('idev_orgchart') ? "\n\n<!-- wp:shortcode -->[idev_orgchart id=\"0\"]<!-- /wp:shortcode -->" : '';
    $ita_groups = [
        ['idcard', 'ข้อมูลพื้นฐาน', 'Basic information', 'โครงสร้าง ผู้บริหาร อำนาจหน้าที่ แผนยุทธศาสตร์ ข้อมูลการติดต่อ กฎหมายที่เกี่ยวข้อง', 'Structure, executives, duties, strategy, contacts and laws'],
        ['news', 'การประชาสัมพันธ์และปฏิสัมพันธ์', 'News and contact', 'ข่าวประชาสัมพันธ์ Q&A ช่องทางสื่อสังคมออนไลน์', 'News, Q&A and social media channels'],
        ['calendar', 'แผนดำเนินงานและการใช้งบประมาณ', 'Plans and budget', 'แผนดำเนินงานประจำปี รายงานความก้าวหน้า รายงานผลการดำเนินงาน', 'Annual plan, progress and results reports'],
        ['card', 'การจัดซื้อจัดจ้าง', 'Procurement', 'แผนการจัดซื้อจัดจ้าง ประกาศ ผลการจัดซื้อจัดจ้าง รายงานผลประจำปี', 'Procurement plan, announcements, results and annual report'],
        ['users', 'การบริหารทรัพยากรบุคคล', 'Human resources', 'นโยบายการบริหารทรัพยากรบุคคล หลักเกณฑ์ รายงานผลประจำปี', 'HR policy, criteria and annual report'],
        ['shield', 'การจัดการเรื่องร้องเรียนทุจริต', 'Corruption complaints', 'แนวปฏิบัติ ช่องทางแจ้งเรื่องร้องเรียน ข้อมูลเชิงสถิติ', 'Guidelines, reporting channels and statistics'],
        ['star', 'มาตรการส่งเสริมคุณธรรมและความโปร่งใส', 'Integrity and transparency', 'เจตจำนงสุจริตของผู้บริหาร การประเมินความเสี่ยง มาตรการภายใน', 'Integrity pledge, risk assessment and internal measures'],
        ['chat', 'การเปิดโอกาสให้มีส่วนร่วม', 'Public participation', 'ช่องทางรับฟังความคิดเห็น การมีส่วนร่วมของประชาชน', 'Channels for feedback and public participation'],
    ];
    $ita_items = array_map(function ($g) { return ['icon' => $g[0], 'tone' => 'blue', 'title' => ihub_bt($g[1], $g[2]), 'text' => ihub_bt($g[3], $g[4]), 'linkText' => ihub_bt('ดูเอกสาร', 'Documents'), 'url' => '']; }, $ita_groups);
    return [
        'about' => ['เกี่ยวกับหน่วยงาน', 'About us', implode("\n\n", [
            ihub_tpl_b('heading', ['kicker' => ihub_bt('ABOUT US', 'ABOUT US'), 'title' => ihub_bt('ประวัติความเป็นมา', 'Our history')]),
            ihub_tpl_rich('<p>[แก้ไข] ประวัติความเป็นมาของหน่วยงาน ปีที่ก่อตั้ง และพื้นที่ที่ให้บริการ</p>', '<p>[Edit] The history of the organisation.</p>'),
            ihub_tpl_b('cards', ['kicker' => ihub_bt('VISION & MISSION', 'VISION & MISSION'), 'title' => ihub_bt('วิสัยทัศน์ พันธกิจ ค่านิยม', 'Vision, mission and values'), 'columns' => 3, 'items' => [
                ['icon' => 'star', 'tone' => 'amber', 'title' => ihub_bt('วิสัยทัศน์', 'Vision'), 'text' => ihub_bt('[แก้ไข] วิสัยทัศน์ของหน่วยงาน', '[Edit]'), 'linkText' => ihub_bt(), 'url' => ''],
                ['icon' => 'heart', 'tone' => 'rose', 'title' => ihub_bt('พันธกิจ', 'Mission'), 'text' => ihub_bt('[แก้ไข] พันธกิจ 3–5 ข้อ', '[Edit]'), 'linkText' => ihub_bt(), 'url' => ''],
                ['icon' => 'shield', 'tone' => 'blue', 'title' => ihub_bt('ค่านิยม', 'Values'), 'text' => ihub_bt('[แก้ไข] ค่านิยมองค์กร', '[Edit]'), 'linkText' => ihub_bt(), 'url' => '']]], ['background' => 'light']),
            ihub_tpl_b('heading', ['kicker' => ihub_bt('AUTHORITY', 'AUTHORITY'), 'title' => ihub_bt('อำนาจหน้าที่', 'Responsibilities')]),
            ihub_tpl_rich('<ul><li>[แก้ไข] อำนาจหน้าที่ตามกฎหมาย / ระเบียบที่เกี่ยวข้อง</li></ul>'),
        ])],
        'structure' => ['โครงสร้างและผู้บริหาร', 'Structure and executives', implode("\n\n", [
            ihub_tpl_b('heading', ['kicker' => ihub_bt('ORGANISATION', 'ORGANISATION'), 'title' => ihub_bt('โครงสร้างหน่วยงานและผู้บริหาร', 'Structure and executives')]),
            ihub_tpl_rich('<p>[แก้ไข] ใส่แผนผังผู้บริหาร: เมนู เครื่องมือเว็บไซต์ → แผนผังองค์กร แล้วแก้เลข id ในบล็อกด้านล่าง</p>'),
        ]) . $org_chart],
        'public-information' => ['การเปิดเผยข้อมูลสาธารณะ (ITA)', 'Public information (ITA)', implode("\n\n", [
            ihub_tpl_b('heading', ['kicker' => ihub_bt('OPEN DATA INTEGRITY AND TRANSPARENCY ASSESSMENT', 'OPEN DATA INTEGRITY AND TRANSPARENCY ASSESSMENT'), 'title' => ihub_bt('การเปิดเผยข้อมูลสาธารณะ', 'Public information'), 'text' => ihub_bt('ข้อมูลตามเกณฑ์การประเมินคุณธรรมและความโปร่งใสในการดำเนินงานของหน่วยงานภาครัฐ (ITA) ประจำปี — ตรวจรายการตัวชี้วัดของปีปัจจุบันจากประกาศ ป.ป.ช. แล้วแนบเอกสารในแต่ละหมวด', 'Information under the annual Integrity and Transparency Assessment (ITA).')]),
            ihub_tpl_b('cards', ['title' => ihub_bt(), 'columns' => 4, 'iconStyle' => 'soft', 'items' => $ita_items]),
        ])],
        'procurement' => ['จัดซื้อจัดจ้าง', 'Procurement', implode("\n\n", [
            ihub_tpl_b('heading', ['kicker' => ihub_bt('PROCUREMENT', 'PROCUREMENT'), 'title' => ihub_bt('ประกาศจัดซื้อจัดจ้าง', 'Procurement notices'), 'text' => ihub_bt('แผน ประกาศ และผลการจัดซื้อจัดจ้าง (เผยแพร่ผ่าน “ประกาศข่าว” หมวดจัดซื้อจัดจ้าง)', '')]),
            ihub_tpl_b('news', ['kicker' => ihub_bt(), 'title' => ihub_bt('ประกาศล่าสุด', 'Latest notices'), 'category' => 'procurement', 'showTabs' => false]),
        ])],
        'complaints' => ['ร้องเรียน / ร้องทุกข์', 'Complaints', implode("\n\n", [
            ihub_tpl_b('heading', ['kicker' => ihub_bt('COMPLAINTS', 'COMPLAINTS'), 'title' => ihub_bt('ช่องทางร้องเรียน ร้องทุกข์ และแจ้งเบาะแสการทุจริต', 'Complaints and reporting corruption')]),
            ihub_tpl_b('steps', ['kicker' => ihub_bt(), 'title' => ihub_bt('ขั้นตอนการจัดการเรื่องร้องเรียน', 'How we handle complaints'), 'items' => [
                ['icon' => 'chat', 'title' => ihub_bt('รับเรื่อง', 'We receive it'), 'text' => ihub_bt('ทางโทรศัพท์ อีเมล LINE หรือมาด้วยตนเอง', 'By phone, email, LINE or in person')],
                ['icon' => 'idcard', 'title' => ihub_bt('ลงทะเบียน / ตอบรับ', 'We register it'), 'text' => ihub_bt('แจ้งเลขรับเรื่องภายใน [แก้ไข] วันทำการ', 'You get a reference number within [Edit] working days')],
                ['icon' => 'users', 'title' => ihub_bt('ตรวจสอบข้อเท็จจริง', 'We look into it'), 'text' => ihub_bt('ส่งหน่วยงานที่เกี่ยวข้อง', 'Passed to the team responsible')],
                ['icon' => 'megaphone', 'title' => ihub_bt('แจ้งผล', 'We reply'), 'text' => ihub_bt('แจ้งผลให้ผู้ร้องทราบภายใน [แก้ไข] วัน', 'We tell you the outcome within [Edit] days')]]], ['background' => 'light']),
            ihub_tpl_rich('<p><strong>ช่องทาง:</strong> โทร ' . esc_html($s['phone']) . ' · อีเมล [แก้ไข] · ที่อยู่ ' . esc_html($s['address']) . '</p><p>ข้อมูลผู้ร้องเรียนจะถูกเก็บเป็นความลับ</p>'),
        ])],
        'contact' => ['ติดต่อเรา', 'Contact us', implode("\n\n", [
            ihub_tpl_b('heading', ['kicker' => ihub_bt('CONTACT', 'CONTACT'), 'title' => ihub_bt('ติดต่อเรา', 'Contact us')]),
            ihub_tpl_rich('<p><strong>' . esc_html($s['site_name']) . '</strong><br>' . esc_html($s['address']) . '<br>โทร ' . esc_html($s['phone']) . '</p>'),
            ihub_tpl_b('map'),
        ])],
        'website-policy' => ['นโยบายเว็บไซต์และความเป็นส่วนตัว', 'Website and privacy policy', implode("\n\n", [
            ihub_tpl_b('heading', ['title' => ihub_bt('นโยบายเว็บไซต์ นโยบายความเป็นส่วนตัว และนโยบายคุกกี้', 'Website, privacy and cookie policy')]),
            ihub_tpl_rich('<h3>นโยบายเว็บไซต์</h3><p>[แก้ไข] วัตถุประสงค์ของเว็บไซต์ การใช้งาน และข้อจำกัดความรับผิดชอบ</p><h3>นโยบายคุ้มครองข้อมูลส่วนบุคคล (PDPA)</h3><p>[แก้ไข] ข้อมูลที่เก็บ วัตถุประสงค์ ระยะเวลาเก็บ สิทธิของเจ้าของข้อมูล และช่องทางติดต่อเจ้าหน้าที่คุ้มครองข้อมูลส่วนบุคคล (DPO)</p><h3>นโยบายคุกกี้</h3><p>[แก้ไข] ประเภทคุกกี้ที่ใช้ และวิธีเปลี่ยนการตั้งค่า</p><h3>นโยบายการรักษาความมั่นคงปลอดภัยเว็บไซต์</h3><p>[แก้ไข]</p>'),
        ])],
        'sitemap' => ['แผนผังเว็บไซต์', 'Site map', "<!-- wp:shortcode -->[ihub_sitemap]<!-- /wp:shortcode -->"],
    ];
}

function ihub_site_templates() {
    $s = ihub_settings();
    $name = ihub_bt($s['site_name'], $s['site_name_en']);
    $news_home = implode("\n\n", [
        ihub_tpl_b('hero', ['eyebrow' => ihub_bt('ยินดีต้อนรับ', 'WELCOME'), 'title' => $name, 'highlight' => ihub_bt('ข่าวสาร ประกาศ และข้อมูลสาธารณะ', 'News, notices and public information'), 'text' => ihub_bt($s['hero_text'], $s['hero_text_en']), 'showEmergency' => false, 'showRegister' => false, 'showAppointment' => false, 'showStatus' => false]),
        ihub_tpl_b('news', ['kicker' => ihub_bt('NEWS & ANNOUNCEMENTS', 'NEWS & ANNOUNCEMENTS'), 'title' => ihub_bt('ข่าวประชาสัมพันธ์และประกาศ', 'News and announcements'), 'count' => 9, 'showTabs' => true]),
        ihub_tpl_b('cards', ['kicker' => ihub_bt('QUICK LINKS', 'QUICK LINKS'), 'title' => ihub_bt('บริการข้อมูล', 'Information'), 'columns' => 4, 'items' => [
            ['icon' => 'card', 'tone' => 'blue', 'title' => ihub_bt('จัดซื้อจัดจ้าง', 'Procurement'), 'text' => ihub_bt('แผน ประกาศ และผลการจัดซื้อจัดจ้าง', 'Plans, announcements and results'), 'linkText' => ihub_bt('ดูประกาศ', 'View'), 'url' => '/procurement/'],
            ['icon' => 'shield', 'tone' => 'indigo', 'title' => ihub_bt('ข้อมูลสาธารณะ (ITA)', 'Public information (ITA)'), 'text' => ihub_bt('การเปิดเผยข้อมูลตามเกณฑ์ ITA', 'Information published under the ITA criteria'), 'linkText' => ihub_bt('ดูข้อมูล', 'View'), 'url' => '/public-information/'],
            ['icon' => 'users', 'tone' => 'teal', 'title' => ihub_bt('รับสมัครงาน', 'Jobs'), 'text' => ihub_bt('ประกาศรับสมัครบุคลากร', 'Job vacancies'), 'linkText' => ihub_bt('ดูประกาศ', 'View'), 'url' => '/category/jobs/'],
            ['icon' => 'chat', 'tone' => 'rose', 'title' => ihub_bt('ร้องเรียน / ร้องทุกข์', 'Complaints'), 'text' => ihub_bt('แจ้งเรื่องร้องเรียนและเบาะแสการทุจริต', 'Report a complaint or suspected corruption'), 'linkText' => ihub_bt('แจ้งเรื่อง', 'Report'), 'url' => '/complaints/']]], ['background' => 'light']),
        ihub_tpl_b('stats', ['kicker' => ihub_bt(), 'title' => ihub_bt('ผลการดำเนินงาน', 'Our work in numbers'), 'items' => [
            ['number' => '0', 'suffix' => ihub_bt('', ''), 'label' => ihub_bt('[แก้ไข] ตัวชี้วัด 1', '[Edit] Indicator 1')], ['number' => '0', 'suffix' => ihub_bt('', ''), 'label' => ihub_bt('[แก้ไข] ตัวชี้วัด 2', '[Edit] Indicator 2')], ['number' => '0', 'suffix' => ihub_bt('%', '%'), 'label' => ihub_bt('[แก้ไข] ความพึงพอใจ', '')]]]),
        ihub_tpl_b('cta', ['kicker' => ihub_bt('CONTACT', 'CONTACT'), 'title' => ihub_bt('ติดต่อหน่วยงาน', 'Contact us'), 'buttonText' => ihub_bt('ติดต่อเรา', 'Contact'), 'url' => '/contact/', 'phoneButton' => true], ['background' => 'dark']),
    ]);
    $service_home = implode("\n\n", [
        ihub_tpl_b('hero', ['eyebrow' => ihub_bt('บริการประชาชน', 'PUBLIC SERVICES'), 'title' => $name, 'highlight' => ihub_bt('บริการรวดเร็ว นัดหมายออนไลน์ได้', 'Fast service — book online'), 'text' => ihub_bt($s['hero_text'], $s['hero_text_en']), 'showEmergency' => true, 'showRegister' => true, 'showAppointment' => true, 'showStatus' => true]),
        ihub_tpl_b('cards', ['kicker' => ihub_bt('OUR SERVICES', 'OUR SERVICES'), 'title' => ihub_bt('บริการของเรา', 'Our services'), 'columns' => 3, 'items' => [
            ['icon' => 'stethoscope', 'tone' => 'mint', 'title' => ihub_bt('บริการตรวจรักษา', 'Medical services'), 'text' => ihub_bt('ตรวจโรคทั่วไป คลินิกเฉพาะทาง ทันตกรรม และแพทย์แผนไทย', 'General and specialist clinics, dental care and Thai traditional medicine'), 'linkText' => ihub_bt('ดูบริการทั้งหมด', 'All services'), 'url' => '/services/'],
            ['icon' => 'calendar', 'tone' => 'sky', 'title' => ihub_bt('นัดหมายออนไลน์', 'Book online'), 'text' => ihub_bt('เลือกบริการ วัน และเวลาได้เอง', 'Choose the service, day and time yourself'), 'linkText' => ihub_bt('นัดหมาย', 'Book'), 'url' => '/appointment/'],
            ['icon' => 'idcard', 'tone' => 'lavender', 'title' => ihub_bt('ลงทะเบียนผู้รับบริการใหม่', 'Register'), 'text' => ihub_bt('ลงทะเบียนล่วงหน้า ไม่ต้องรอคิว', 'Register ahead and skip the queue'), 'linkText' => ihub_bt('ลงทะเบียน', 'Register'), 'url' => '/register/']]]),
        ihub_tpl_b('steps', ['kicker' => ihub_bt('HOW IT WORKS', 'HOW IT WORKS'), 'title' => ihub_bt('ขั้นตอนการรับบริการ', 'How to get the service')], ['background' => 'light']),
        ihub_tpl_b('doctors'),
        ihub_tpl_b('faq', [], ['background' => 'light']),
        ihub_tpl_b('news', ['kicker' => ihub_bt('NEWS', 'NEWS'), 'title' => ihub_bt('ข่าวและประกาศ', 'News'), 'count' => 3, 'showTabs' => false]),
        ihub_tpl_b('cta', ['title' => ihub_bt('สอบถามบริการ', 'Questions?'), 'buttonText' => ihub_bt('ติดต่อเรา', 'Contact'), 'url' => '/contact/', 'phoneButton' => true], ['background' => 'dark']),
    ]);
    $common = ihub_tpl_common_pages();
    return [
        'gov_news' => ['label' => 'ราชการ — เน้นข่าวสาร', 'desc' => 'หน่วยงานที่สื่อสารข่าว ประกาศ จัดซื้อจัดจ้าง และข้อมูลสาธารณะ (ITA) เป็นหลัก', 'icon' => 'megaphone',
            'pages' => ['home' => ['หน้าแรก', 'Home', $news_home], 'news' => ['ข่าวประชาสัมพันธ์', 'News', ihub_tpl_b('news', ['count' => 12, 'showTabs' => true])]] + $common,
            'menu' => ['home', 'about', 'structure', 'news', 'procurement', 'public-information', 'complaints', 'contact']],
        'gov_service' => ['label' => 'ราชการ — เน้นบริการ', 'desc' => 'โรงพยาบาล ศูนย์บริการ หน่วยบริการประชาชน: บริการ นัดหมาย ลงทะเบียน ขั้นตอน ค่าบริการ และคำถามพบบ่อย', 'icon' => 'heart',
            'pages' => ['home' => ['หน้าแรก', 'Home', $service_home],
                'services' => ['บริการของเรา', 'Our services', (function_exists('idw_svc_render') ? '<!-- wp:idw/services {"align":"wide"} /-->' : ihub_tpl_b('cards', ['title' => ihub_bt('บริการของเรา', 'Our services'), 'columns' => 3, 'items' => ihub_tpl_service_items()])) . "\n\n" . ihub_tpl_b('steps', [], ['background' => 'light'])],
                'appointment' => ['นัดหมายออนไลน์', 'Book online', shortcode_exists('idev_booking') ? '<!-- wp:shortcode -->[idev_booking]<!-- /wp:shortcode -->' : ihub_tpl_rich('<p>[แก้ไข] เปิดปลั๊กอิน iDev Appointments เพื่อใช้ระบบนัดหมาย</p>')],
                'schedule' => ['ตารางออกตรวจ / ให้บริการ', 'Schedule', ihub_tpl_b('doctors')],
                'fees' => ['อัตราค่าบริการ', 'Fees', ihub_tpl_b('rates')],
                'faq' => ['คำถามพบบ่อย', 'FAQ', ihub_tpl_b('faq')],
                'news' => ['ข่าวและประกาศ', 'News', ihub_tpl_b('news', ['count' => 12])]] + $common,
            'menu' => ['home', 'services', 'appointment', 'schedule', 'fees', 'news', 'about', 'public-information', 'contact']],
    ];
}

/** News categories with their article template (ประกาศข่าว). */
function ihub_tpl_news_categories() {
    return [
        'news' => ['ข่าวประชาสัมพันธ์', '<h3>รายละเอียด</h3><p>…</p><h3>วัน เวลา และสถานที่</h3><p>…</p><h3>ติดต่อสอบถาม</h3><p>…</p>'],
        'announcement' => ['ประกาศ', '<h3>เรื่อง</h3><p>…</p><h3>สาระสำคัญ</h3><p>…</p><p>ประกาศ ณ วันที่ …</p>'],
        'procurement' => ['จัดซื้อจัดจ้าง', '<h3>ประเภท</h3><p>แผน / ประกาศเชิญชวน / ผลการพิจารณา / สัญญา</p><h3>รายละเอียดโครงการ</h3><p>วงเงินงบประมาณ … บาท · วิธีจัดซื้อจัดจ้าง …</p><h3>เอกสารแนบ</h3><p>แนบเอกสารประกาศในช่อง “ไฟล์แนบ”</p>'],
        'jobs' => ['รับสมัครงาน', '<h3>ตำแหน่งที่รับสมัคร</h3><p>…</p><h3>คุณสมบัติ</h3><ul><li>…</li></ul><h3>วันรับสมัคร</h3><p>…</p><h3>วิธีสมัคร</h3><p>…</p>'],
        'activity' => ['กิจกรรม', '<h3>กิจกรรม</h3><p>…</p><h3>ภาพกิจกรรม</h3><p>…</p>'],
    ];
}

add_action('admin_menu', function () {
    add_submenu_page('idevapp-hub', 'แม่แบบเว็บไซต์', 'แม่แบบเว็บไซต์', 'manage_options', 'ihub-templates', 'ihub_tpl_page');
}, 20);

/** Create the pages of a template. Pages that already exist (same slug) are kept. Returns how many pages are new. */
function ihub_tpl_apply($key, $status = 'draft', $front = false, $menu = true) {
    $tpls = ihub_site_templates();
    if (!isset($tpls[$key])) return new WP_Error('ihub_tpl', 'ไม่พบแม่แบบ');
    $tpl = $tpls[$key];
    $status = $status === 'publish' ? 'publish' : 'draft';
    $ids = [];
    $made = 0;
    foreach ($tpl['pages'] as $slug => [$title, $title_en, $content]) {
        $page_slug = $slug === 'home' ? 'home-' . str_replace('_', '-', $key) : $slug;
        $ex = get_page_by_path($page_slug);
        if ($ex) { $ids[$slug] = $ex->ID; continue; }
        $id = wp_insert_post(wp_slash(['post_type' => 'page', 'post_status' => $status, 'post_title' => $title, 'post_name' => $page_slug, 'post_content' => $content]));
        if (is_wp_error($id)) continue;
        update_post_meta($id, 'ihub_title_en', $title_en);
        update_post_meta($id, '_idev_title_en', $title_en); // iDev Bilingual reads this one
        update_post_meta($id, 'ihub_layout', 'full');
        if ($slug === 'home') { update_post_meta($id, 'ihub_show_title', '0'); update_post_meta($id, 'ihub_show_contact', '0'); }
        $ids[$slug] = $id;
        $made++;
    }
    // news categories with their templates
    foreach (ihub_tpl_news_categories() as $cslug => [$cname, $ctpl]) {
        $t = term_exists($cslug, 'category') ?: wp_insert_term($cname, 'category', ['slug' => $cslug]);
        if (!is_wp_error($t) && $t) { $tid = (int) (is_array($t) ? $t['term_id'] : $t); if (!get_term_meta($tid, 'ihub_news_template', true)) update_term_meta($tid, 'ihub_news_template', $ctpl); }
    }
    if ($front && isset($ids['home']) && $status === 'publish') {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $ids['home']);
    }
    if ($menu) {
        $menu_name = 'เมนูหลัก — ' . $tpl['label'];
        $obj = wp_get_nav_menu_object($menu_name);
        $menu_id = $obj ? $obj->term_id : wp_create_nav_menu($menu_name);
        if (!is_wp_error($menu_id) && !$obj) {
            foreach ($tpl['menu'] as $slug) if (isset($ids[$slug])) wp_update_nav_menu_item($menu_id, 0, ['menu-item-object-id' => $ids[$slug], 'menu-item-object' => 'page', 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish']);
        }
        if (!is_wp_error($menu_id) && $status === 'publish') {
            $locations = get_theme_mod('nav_menu_locations', []);
            $loc = isset(get_registered_nav_menus()['primary']) ? 'primary' : (array_keys(get_registered_nav_menus())[0] ?? '');
            if ($loc && empty($locations[$loc])) { $locations[$loc] = $menu_id; set_theme_mod('nav_menu_locations', $locations); }
        }
    }
    return $made;
}

add_action('admin_post_ihub_tpl_apply', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('ihub_tpl_apply')) wp_die('ไม่มีสิทธิ์', 403);
    $key = sanitize_key($_POST['tpl'] ?? '');
    $made = ihub_tpl_apply($key, ($_POST['status'] ?? '') === 'publish' ? 'publish' : 'draft', !empty($_POST['front']), !empty($_POST['menu']));
    if (is_wp_error($made)) wp_die(esc_html($made->get_error_message()));
    wp_safe_redirect(admin_url('admin.php?page=ihub-templates&done=' . (int) $made . '&tpl=' . $key));
    exit;
});

function ihub_tpl_page() {
    if (!current_user_can('manage_options')) wp_die('ไม่มีสิทธิ์');
    $done = isset($_GET['done']) ? (int) $_GET['done'] : -1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    echo '<div class="wrap ihub-tpl"><h1>แม่แบบเว็บไซต์</h1><p class="description">สร้างหน้าเว็บทั้งชุดในคลิกเดียว จากบล็อกของ iDevApp — แก้ข้อความ รูป และลิงก์ได้ทุกส่วน · ข้อความที่มี [แก้ไข] คือส่วนที่ต้องใส่ข้อมูลของหน่วยงาน · หน้าที่มีอยู่แล้ว (ชื่อลิงก์ซ้ำ) จะไม่ถูกเขียนทับ</p>';
    if ($done >= 0) echo '<div class="notice notice-success"><p>สร้างหน้าใหม่ ' . (int) $done . ' หน้า พร้อมหมวดข่าวและแม่แบบข่าวแล้ว — ดูได้ที่ หน้าเว็บ (Pages)</p></div>';
    echo '<div class="ihub-tpl-grid">';
    foreach (ihub_site_templates() as $key => $t) {
        echo '<div class="ihub-tpl-card"><div class="hd"><span class="dashicons dashicons-' . esc_attr($t['icon'] === 'megaphone' ? 'megaphone' : 'heart') . '"></span><h2>' . esc_html($t['label']) . '</h2></div><p>' . esc_html($t['desc']) . '</p><ul>';
        foreach ($t['pages'] as $slug => $p) echo '<li>' . esc_html($p[0]) . (in_array($slug, $t['menu'], true) ? ' <small>· เมนู</small>' : '') . '</li>';
        echo '</ul><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">' . wp_nonce_field('ihub_tpl_apply', '_wpnonce', true, false) . '<input type="hidden" name="action" value="ihub_tpl_apply"><input type="hidden" name="tpl" value="' . esc_attr($key) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '<label><input type="radio" name="status" value="draft" checked> สร้างเป็นฉบับร่าง (ตรวจก่อนเผยแพร่)</label><label><input type="radio" name="status" value="publish"> เผยแพร่ทันที</label>';
        echo '<label><input type="checkbox" name="front" value="1"> ตั้ง “หน้าแรก” ของแม่แบบนี้เป็นหน้าแรกของเว็บ (เมื่อเผยแพร่ทันที)</label><label><input type="checkbox" name="menu" value="1" checked> สร้างเมนูหลักให้ (ใช้เป็นเมนูของเว็บเมื่อเผยแพร่ทันที — ฉบับร่างจะสร้างเมนูไว้ให้ตั้งเองที่ หน้าตา → เมนู)</label>';
        echo '<p><button class="button button-primary button-large" onclick="return confirm(\'สร้างหน้าตามแม่แบบนี้?\')">ใช้แม่แบบนี้</button></p></form></div>';
    }
    echo '</div><style>.ihub-tpl-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:18px;max-width:1100px;margin-top:14px}.ihub-tpl-card{background:#fff;border:1px solid #dcdfe4;border-radius:16px;padding:18px 20px}.ihub-tpl-card .hd{display:flex;gap:10px;align-items:center}.ihub-tpl-card .hd .dashicons{font-size:28px;width:28px;height:28px;color:#16857c}.ihub-tpl-card h2{margin:0}.ihub-tpl-card ul{columns:2;margin:10px 0 14px}.ihub-tpl-card li small{color:#16857c}.ihub-tpl-card label{display:block;margin:4px 0}</style></div>';
}

/* [ihub_sitemap]: site map page (all published pages and news categories). */
add_shortcode('ihub_sitemap', function () {
    $html = '<div class="ihub-sitemap"><h2>' . esc_html(ihub_pick('หน้าเว็บ', 'Pages')) . '</h2><ul>' . wp_list_pages(['title_li' => '', 'echo' => false, 'sort_column' => 'menu_order,post_title']) . '</ul>';
    $html .= '<h2>' . esc_html(ihub_pick('หมวดข่าว', 'News categories')) . '</h2><ul>' . wp_list_categories(['title_li' => '', 'echo' => false, 'hide_empty' => false]) . '</ul></div>';
    return $html;
});
