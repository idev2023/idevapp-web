<?php
/** Appointments are medical records: the table wp_idev_appointments and the settings are kept when the plugin is deleted. */
defined('WP_UNINSTALL_PLUGIN') || exit;
wp_clear_scheduled_hook('idev_appt_cron');
