<?php
/**
 * Plugin Name:       I-Drug
 * Plugin URI:        https://idevapp.me/#systems
 * Description:       Pharmacy system by iDevApp: point of sale with barcode, stock by lot and expiry, drug labels, ขย. 9–13 books, customer registration, appointments and receipts with PromptPay.
 * Version:           1.2.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-package
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// One iDevApp package at a time: activating this one switches the other packages off.
register_activation_hook(__FILE__, function () {
    if (!function_exists('deactivate_plugins')) require_once ABSPATH . 'wp-admin/includes/plugin.php';
    foreach (['i-clinic', 'i-clinic-pro', 'i-drug'] as $p) if ($p !== 'i-drug' && is_plugin_active($p . '/' . $p . '.php')) deactivate_plugins($p . '/' . $p . '.php', true);
});
if (defined('IDEV_PACKAGE')) return;

define('IDEV_PACKAGE', 'pharmacy');
define('IDEV_PACKAGE_SLUG', 'i-drug');
define('IDEV_PACKAGE_NAME', 'I-Drug');
define('IDEV_PACKAGE_VERSION', '1.2.0');
define('IDEV_PACKAGE_FILE', __FILE__);

require_once __DIR__ . '/common/idev-common.php';
// A module that is still active as a separate plugin loads itself (it is switched off on the next admin page);
// loading both copies would be a fatal error. Plugins whose names sort after "i-…" load later, so check the list.
$idev_pkg_active = (array) get_option('active_plugins', []);
if (is_multisite()) $idev_pkg_active = array_merge($idev_pkg_active, array_keys((array) get_site_option('active_sitewide_plugins', [])));
foreach (['idev-thai-holidays', 'idev-clinic-schedule', 'idev-patient-registration', 'idev-patient-registration-pro', 'idev-appointments', 'idev-appointments-pro', 'idev-store'] as $idev_pkg_module) {
    if (in_array($idev_pkg_module . '/' . $idev_pkg_module . '.php', $idev_pkg_active, true)) continue;
    require_once __DIR__ . '/modules/' . $idev_pkg_module . '/' . $idev_pkg_module . '.php';
}
unset($idev_pkg_active);
unset($idev_pkg_module);
require_once __DIR__ . '/includes/package.php';

add_action('init', function () { load_plugin_textdomain('idev-package', false, dirname(plugin_basename(__FILE__)) . '/languages'); }, 1);
register_activation_hook(__FILE__, function () { idev_pkg_install(); idev_pkg_takeover(); }); // runs when this package is the one loaded
