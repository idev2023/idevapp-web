<?php
/** REST API idev-store/v1: staff (sales screen, job form) and public (pick-up booking with the job link). */
defined('ABSPATH') || exit;

function idev_store_public_item($i) {
    return ['id' => $i['id'], 'name' => $i['name'], 'sku' => $i['sku'], 'barcode' => $i['barcode'], 'category' => $i['category'], 'unit' => $i['unit'], 'kind' => $i['kind'],
        'price' => $i['price'], 'qty' => $i['qty'], 'track' => $i['track'], 'low' => $i['track'] && $i['qty'] <= $i['min_qty'], 'drug' => idev_store_labels_on() ? idev_store_item_drug($i) : null];
}
function idev_store_public_customer($c) {
    return ['id' => $c['id'], 'code' => $c['code'], 'name' => $c['name'], 'phone' => $c['phone'], 'email' => $c['email'], 'hn' => $c['hn'], 'label' => idev_store_customer_label($c)];
}

add_action('rest_api_init', function () {
    $ns = 'idev-store/v1';
    $staff = function () { return idev_store_can(); };
    register_rest_route($ns, '/items', ['methods' => 'GET', 'permission_callback' => $staff, 'callback' => function (WP_REST_Request $r) {
        $code = (string) $r->get_param('code');
        if ($code !== '') { $i = idev_store_item_by_code($code); return $i ? [idev_store_public_item($i)] : []; }
        return array_map('idev_store_public_item', idev_store_items(['q' => (string) $r->get_param('q'), 'kind' => (string) $r->get_param('kind'), 'limit' => 30]));
    }]);
    register_rest_route($ns, '/customers', ['methods' => 'GET', 'permission_callback' => $staff, 'callback' => function (WP_REST_Request $r) {
        return array_map('idev_store_public_customer', idev_store_customers((string) $r->get_param('q'), 15));
    }]);
    register_rest_route($ns, '/customers', ['methods' => 'POST', 'permission_callback' => $staff, 'callback' => function (WP_REST_Request $r) {
        $id = idev_store_customer_save($r->get_json_params() ?: $r->get_body_params());
        if (is_wp_error($id)) return new WP_REST_Response(['ok' => false, 'error' => $id->get_error_message()], 400);
        return ['ok' => true, 'customer' => idev_store_public_customer(idev_store_customer($id))];
    }]);
    register_rest_route($ns, '/bills', ['methods' => 'POST', 'permission_callback' => $staff, 'callback' => function (WP_REST_Request $r) {
        $in = $r->get_json_params() ?: [];
        $id = idev_store_bill_create(['customer_id' => (int) ($in['customer_id'] ?? 0), 'lines' => $in['lines'] ?? [], 'discount' => $in['discount'] ?? 0, 'note' => $in['note'] ?? '', 'payments' => $in['payments'] ?? [], 'info' => $in['info'] ?? []]);
        if (is_wp_error($id)) return new WP_REST_Response(['ok' => false, 'error' => $id->get_error_message()], 400);
        $b = idev_store_bill($id);
        return ['ok' => true, 'id' => $id, 'no' => $b['no'], 'total' => $b['total'], 'paid' => $b['paid'], 'change' => array_sum(array_column($b['payments'], 'change_amount')), 'print' => idev_store_print_url('bill', $id), 'labels' => idev_store_labels_on() && idev_store_label_lines($b) ? idev_store_print_url('label', $id) : ''];
    }]);
    register_rest_route($ns, '/promptpay', ['methods' => 'GET', 'permission_callback' => $staff, 'callback' => function (WP_REST_Request $r) {
        return ['svg' => idev_store_promptpay_svg((float) $r->get_param('amount'), 220), 'id' => idev_store_settings()['promptpay']];
    }]);
    // public: pick-up times for the job link
    register_rest_route($ns, '/pickup', ['methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => function (WP_REST_Request $r) {
        $job = idev_store_job_by_token((string) $r->get_param('token'));
        if (!$job || $job['status'] !== 'ready') return new WP_Error('job', 'Not found', ['status' => 404]);
        $out = [];
        $s = idev_store_settings();
        for ($i = 0; $i <= (int) $s['pickup_ahead']; $i++) {
            $d = idev_add_days(idev_today(), $i);
            $slots = idev_store_pickup_slots($d);
            if (!$slots || !array_filter($slots)) continue;
            $out[] = ['date' => $d, 'label' => idev_format_day($d, null, true), 'times' => array_map(function ($t, $n) { return ['time' => $t, 'free' => $n]; }, array_keys($slots), $slots)];
        }
        return $out;
    }]);
    register_rest_route($ns, '/pickup', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => function (WP_REST_Request $r) {
        $job = idev_store_job_by_token((string) $r->get_param('token'));
        if (!$job || $job['status'] !== 'ready') return new WP_REST_Response(['ok' => false, 'error' => __('This order can no longer be changed.', 'idev-store')], 404);
        $ok = idev_store_job_book_pickup($job['id'], (string) $r->get_param('date'), (string) $r->get_param('time'));
        if (is_wp_error($ok)) return new WP_REST_Response(['ok' => false, 'error' => $ok->get_error_message()], 409);
        return ['ok' => true];
    }]);
});
