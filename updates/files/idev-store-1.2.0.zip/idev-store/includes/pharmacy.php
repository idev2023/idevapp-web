<?php
/**
 * Pharmacy / dispensing: drug classes on items, buyer and prescriber details on sales,
 * drug labels (MOPH announcement on dispensed-drug labels, 2565) and the ขย. books
 * (ขย.9 purchases, ขย.10 special controlled drugs, ขย.11 listed dangerous drugs,
 * ขย.12 sales on prescription, ขย.13 four-monthly report).
 *
 * Drug labels: profiles "pharmacy" and "clinic", every system.
 * ขย. books: profile "pharmacy", in the trial and in I-Drug (licence product store_pharmacy).
 */
defined('ABSPATH') || exit;

/* ---------- Switches ---------- */

function idev_store_is_pharmacy() { return idev_store_settings()['profile'] === 'pharmacy'; }
function idev_store_labels_on() { return in_array(idev_store_settings()['profile'], ['pharmacy', 'clinic'], true); }
/** ขย. books: in the trial, and in I-Drug. */
function idev_store_khy_enabled() { return (bool) apply_filters('idev_store_feature', !idev_store_licensed() || idev_is_licensed('store_pharmacy'), 'khy'); }

/* ---------- Drug classes and item fields ---------- */

function idev_store_drug_classes() {
    return [
        '' => __('— Not a drug —', 'idev-store'),
        'household' => __('Household remedy', 'idev-store'),
        'dangerous' => __('Dangerous drug', 'idev-store'),
        'k11' => __('Dangerous drug on the ขย.11 list', 'idev-store'),
        'special' => __('Specially controlled drug (ขย.10)', 'idev-store'),
        'other' => __('Other / not classified', 'idev-store'),
    ];
}
/** Classes whose sale must record the buyer (ขย.10, ขย.11). */
function idev_store_drug_needs_buyer($class) { return in_array($class, ['special', 'k11'], true); }

/** Extra item fields for the pharmacy profile: [key => [label, type, help]]. */
function idev_store_drug_fields() {
    return [
        'generic' => [__('Generic name', 'idev-store'), 'text', __('Printed on the drug label (e.g. Paracetamol / พาราเซตามอล).', 'idev-store')],
        'strength' => [__('Strength', 'idev-store'), 'text', __('e.g. 500 mg, 120 mg/5 ml', 'idev-store')],
        'form' => [__('Dosage form', 'idev-store'), 'text', __('e.g. tablet, capsule, syrup, cream', 'idev-store')],
        'drug_class' => [__('Drug class (Thai FDA)', 'idev-store'), 'class', __('Decides which ขย. book the sale goes into.', 'idev-store')],
        'k13' => [__('Report in ขย.13', 'idev-store'), 'check', __('Drugs on the Thai FDA list that must be reported every four months.', 'idev-store')],
        'reg_no' => [__('Registration no.', 'idev-store'), 'text', ''],
        'maker' => [__('Manufacturer / importer', 'idev-store'), 'text', ''],
        'pack' => [__('Pack size', 'idev-store'), 'text', __('e.g. box of 10 × 10 tablets, bottle 60 ml', 'idev-store')],
        'use' => [__('Default directions', 'idev-store'), 'textarea', __('Pre-filled on the label when you sell; you can change it for each sale.', 'idev-store')],
        'ind' => [__('Indication', 'idev-store'), 'text', __('e.g. relieves pain and fever', 'idev-store')],
        'warn' => [__('Warning on the label', 'idev-store'), 'text', __('e.g. may cause drowsiness; do not take more than 8 tablets a day', 'idev-store')],
    ];
}
/** Clinics get the label fields only. */
function idev_store_label_fields() {
    $f = idev_store_drug_fields();
    return array_intersect_key($f, array_flip(['generic', 'strength', 'form', 'use', 'ind', 'warn']));
}
function idev_store_drug_input($k, $def, $value, $readonly) {
    [, $type, $help] = $def;
    $ro = $readonly ? ' disabled' : '';
    $name = 'item[attrs][' . esc_attr($k) . ']';
    if ($type === 'class') {
        $o = '<select name="' . $name . '"' . $ro . '>';
        foreach (idev_store_drug_classes() as $c => $l) $o .= '<option value="' . esc_attr($c) . '"' . selected($value, $c, false) . '>' . esc_html($l) . '</option>';
        $o .= '</select>';
    } elseif ($type === 'check') $o = '<label><input type="checkbox" name="' . $name . '" value="1"' . checked($value, '1', false) . $ro . '> ' . esc_html__('Yes', 'idev-store') . '</label>';
    elseif ($type === 'textarea') $o = '<textarea name="' . $name . '" rows="2" class="large-text"' . $ro . '>' . esc_textarea($value) . '</textarea>';
    else $o = '<input type="text" name="' . $name . '" value="' . esc_attr($value) . '" class="regular-text"' . ($readonly ? ' readonly' : '') . '>';
    return $o . ($help ? '<p class="description">' . esc_html($help) . '</p>' : '');
}

/** Drug data for the sales screen. */
function idev_store_item_drug($i) {
    $a = $i['attrs'] ?? [];
    $d = array_intersect_key($a, array_flip(['generic', 'strength', 'form', 'drug_class', 'use', 'ind', 'warn']));
    return $d ?: null;
}

/* ---------- Sale details (buyer / prescriber), kept encrypted on the bill ---------- */

/** $in: buyer, age, address, rx (1), prescriber, prescriber_place. */
function idev_store_sale_info_clean($in) {
    $in = (array) $in;
    $o = [];
    foreach (['buyer', 'age', 'prescriber', 'prescriber_place'] as $k) if (isset($in[$k]) && trim((string) $in[$k]) !== '') $o[$k] = mb_substr(sanitize_text_field($in[$k]), 0, 190);
    if (!empty($in['address'])) $o['address'] = mb_substr(sanitize_textarea_field($in['address']), 0, 400);
    if (!empty($in['rx'])) $o['rx'] = 1;
    return $o;
}
/** Checks the details the ขย. books need. Returns true or WP_Error. */
function idev_store_sale_info_check($lines, $info, $customer_id) {
    if (!idev_store_is_pharmacy()) return true;
    $need = false;
    foreach ($lines as $l) if (!empty($l['item']) && idev_store_drug_needs_buyer($l['item']['attrs']['drug_class'] ?? '')) $need = true;
    $cust = $customer_id ? idev_store_customer($customer_id) : null;
    if ($need && empty($info['buyer']) && empty($cust['name'])) return new WP_Error('buyer', __('This sale has a specially controlled drug or a drug on the ขย.11 list: please enter the buyer\'s name.', 'idev-store'));
    if (!empty($info['rx']) && empty($info['prescriber'])) return new WP_Error('rx', __('Please enter the prescriber (doctor / dentist) for a sale on prescription.', 'idev-store'));
    return true;
}
/** Buyer name for the books: the name typed at the sale, else the customer. */
function idev_store_bill_buyer($bill) {
    return $bill['info']['buyer'] ?? ($bill['customer']['name'] ?? '');
}

/** Label text from the sale, falling back to the item's defaults. */
function idev_store_label_clean($in) {
    $in = (array) $in;
    $o = [];
    if (isset($in['use'])) $o['use'] = mb_substr(sanitize_textarea_field($in['use']), 0, 400);
    foreach (['ind', 'warn'] as $k) if (isset($in[$k])) $o[$k] = mb_substr(sanitize_text_field($in[$k]), 0, 250);
    if (!empty($in['skip'])) $o['skip'] = 1;
    return array_filter($o, 'strlen');
}

/* ---------- Drug labels ---------- */

function idev_store_label_formats() {
    $s = idev_store_settings();
    return ['label' => sprintf(__('Label sticker %1$s × %2$s mm', 'idev-store'), $s['label_w'], $s['label_h']), '80mm' => __('Receipt printer 80 mm', 'idev-store')];
}

/** Lines of a bill that get a label: drugs, or lines with directions. Optional $line_id = one line. */
function idev_store_label_lines($bill, $line_id = 0) {
    $out = [];
    foreach ($bill['lines'] as $l) {
        if ($line_id && (int) $l['id'] !== $line_id) continue;
        $item = (int) $l['item_id'] ? idev_store_item((int) $l['item_id']) : null;
        $a = $item['attrs'] ?? [];
        $lbl = $l['label'];
        if (!empty($lbl['skip']) && !$line_id) continue;
        $use = $lbl['use'] ?? ($a['use'] ?? '');
        $is_drug = ($a['drug_class'] ?? '') !== '' || !empty($a['generic']);
        if (!$line_id && !$is_drug && $use === '') continue;
        $exp = '';
        foreach ($l['used'] as $u) { $lot = idev_store_lot((int) $u[0]); if ($lot && $lot['expiry'] && ($exp === '' || $lot['expiry'] < $exp)) $exp = $lot['expiry']; }
        $out[] = ['line' => $l, 'item' => $item, 'generic' => $a['generic'] ?? '', 'strength' => $a['strength'] ?? '', 'form' => $a['form'] ?? '',
            'use' => $use, 'ind' => $lbl['ind'] ?? ($a['ind'] ?? ''), 'warn' => $lbl['warn'] ?? ($a['warn'] ?? ''), 'exp' => $exp, 'unit' => $item['unit'] ?? ''];
    }
    return $out;
}

function idev_store_doc_label($bill, $x) {
    $s = idev_store_settings();
    $l = $x['line'];
    $patient = idev_store_bill_buyer($bill);
    $hn = $bill['customer']['hn'] ?? '';
    $name = $x['generic'] !== '' ? $x['generic'] : $l['name'];
    $trade = $x['generic'] !== '' && mb_strtolower($x['generic']) !== mb_strtolower($l['name']) ? $l['name'] : '';
    $o = '<div class="lb-shop"><b>' . esc_html($s['shop_name']) . '</b>' . ($s['phone'] ? ' · ' . esc_html__('Tel.', 'idev-store') . ' ' . esc_html($s['phone']) : '') . '</div>';
    $o .= '<div class="lb-row"><span>' . esc_html($patient !== '' ? $patient : '……………………………') . ($hn ? ' · HN ' . esc_html($hn) : '') . '</span><span>' . esc_html(idev_format_day(substr($bill['created_at'], 0, 10))) . '</span></div>';
    $o .= '<div class="lb-drug">' . esc_html(trim($name . ' ' . $x['strength'])) . '</div>';
    $o .= '<div class="lb-row lb-sub"><span>' . esc_html(trim(($trade ? $trade . ' · ' : '') . $x['form'])) . '</span><span>' . esc_html(sprintf(__('Qty %s', 'idev-store'), trim(idev_store_qty($l['qty']) . ' ' . $x['unit']))) . '</span></div>';
    $o .= '<div class="lb-use">' . nl2br(esc_html($x['use'] !== '' ? $x['use'] : __('Directions: ……………………………………', 'idev-store'))) . '</div>';
    if ($x['ind'] !== '') $o .= '<div class="lb-ind">' . esc_html(sprintf(__('For: %s', 'idev-store'), $x['ind'])) . '</div>';
    if ($x['warn'] !== '') $o .= '<div class="lb-warn">⚠ ' . esc_html($x['warn']) . '</div>';
    $foot = array_filter([$x['exp'] ? sprintf(__('EXP %s', 'idev-store'), idev_format_day($x['exp'])) : '', $s['pharmacist'] ? sprintf(__('Pharmacist: %s', 'idev-store'), $s['pharmacist']) : '', $bill['no']]);
    $o .= '<div class="lb-foot">' . esc_html(implode(' · ', $foot)) . '</div>';
    return $o;
}

function idev_store_label_css($format) {
    $s = idev_store_settings();
    $w = (float) $s['label_w']; $h = (float) $s['label_h'];
    $css = '.lb-shop{font-size:1em;border-bottom:1px solid #000;padding-bottom:1mm;margin-bottom:1mm;line-height:1.25}
.lb-row{display:flex;justify-content:space-between;gap:2mm}
.lb-sub{font-size:.88em}
.lb-drug{font-weight:bold;font-size:1.18em;margin:1mm 0 0;line-height:1.2}
.lb-use{font-weight:bold;font-size:1.12em;border:1.5px solid #000;border-radius:1.5mm;padding:1mm 1.5mm;margin:1mm 0;line-height:1.3}
.lb-ind{line-height:1.25}.lb-warn{font-weight:bold;line-height:1.25}
.lb-foot{font-size:.78em;margin-top:1mm;color:#333}';
    if ($format === 'label') $css .= '.f-label .sheet{width:' . $w . 'mm;height:' . $h . 'mm;overflow:hidden;padding:2mm 2.5mm;font-size:' . ($w < 60 ? '9' : '10.5') . 'px;margin:12px auto}
.f-label .sheet .trial{padding:0;margin:0 0 1mm;font-size:.8em;border-width:1px}
@media print{.f-label .sheet{padding:2mm 2.5mm!important;width:' . $w . 'mm!important;height:' . ($h - 1) . 'mm!important;margin:0!important}.f-label .sheet:not(:last-child){page-break-after:always;break-after:page}}';
    else $css .= '.f-80mm .sheet + .sheet{margin-top:0}@media print{.f-80mm .sheet{border-bottom:1px dashed #000;padding-bottom:3mm!important;margin-bottom:3mm!important}}';
    return $css;
}

/* ---------- ขย. books ---------- */

function idev_store_khy_books() {
    return [
        'k9' => [__('ขย.9 Purchases of drugs', 'idev-store'), __('Every purchase of drugs (receive stock). Keep for at least 3 years.', 'idev-store')],
        'k10' => [__('ขย.10 Sales of specially controlled drugs', 'idev-store'), __('One sheet per drug and lot. Items with the class "Specially controlled drug".', 'idev-store')],
        'k11' => [__('ขย.11 Sales of listed dangerous drugs', 'idev-store'), __('One sheet per drug and lot. Items with the class "Dangerous drug on the ขย.11 list" (e.g. tramadol, dextromethorphan, antihistamine syrups).', 'idev-store')],
        'k12' => [__('ขย.12 Sales on prescription', 'idev-store'), __('Sales where "Sold on prescription" was ticked. Keep the prescriptions for 1 year and the book for 3 years.', 'idev-store')],
        'k13' => [__('ขย.13 Four-monthly report', 'idev-store'), __('Items marked "Report in ขย.13". Periods: Jan–Apr, May–Aug, Sep–Dec; send to the Thai FDA / provincial health office within 30 days after the period.', 'idev-store')],
    ];
}

/** Four-month period: [from, to] for year + term 1..3. */
function idev_store_khy_term($year, $term) {
    $term = max(1, min(3, (int) $term));
    $m1 = ($term - 1) * 4 + 1;
    $from = sprintf('%04d-%02d-01', $year, $m1);
    $to = wp_date('Y-m-t', strtotime(sprintf('%04d-%02d-01', $year, $m1 + 3)));
    return [$from, $to];
}

/** Items in a drug class (attrs is JSON, filtered here). */
function idev_store_drug_items($classes = null, $k13 = false) {
    global $wpdb;
    $rows = $wpdb->get_results('SELECT * FROM ' . idev_store_t('items') . " WHERE attrs LIKE '%drug_class%' OR attrs LIKE '%k13%' ORDER BY name", ARRAY_A);
    $out = [];
    foreach (array_map('idev_store_item_row', $rows) as $i) {
        $c = $i['attrs']['drug_class'] ?? '';
        if ($k13 ? empty($i['attrs']['k13']) : ($classes === null ? $c === '' : !in_array($c, (array) $classes, true))) continue;
        $out[$i['id']] = $i;
    }
    return $out;
}
function idev_store_drug_label($i) {
    $a = $i['attrs'];
    $gen = $a['generic'] ?? '';
    $g = trim($gen . ' ' . ($a['strength'] ?? ''));
    return $g !== '' && ($gen === '' || mb_stripos($i['name'], $gen) === false) ? $i['name'] . ' (' . $g . ')' : $i['name'];
}

/** Returns ['cols' => [...], 'rows' => [[...]], 'sheets' => [[head, rows]] (k10/k11)] */
function idev_store_khy_data($book, $from, $to) {
    global $wpdb;
    $M = idev_store_t('moves'); $B = idev_store_t('bills'); $LT = idev_store_t('lots');
    $range = [$from . ' 00:00:00', $to . ' 23:59:59'];
    $s = idev_store_settings();
    $sign = $s['pharmacist'];
    if ($book === 'k9') {
        $items = idev_store_drug_items(array_keys(array_diff_key(idev_store_drug_classes(), ['' => 1])));
        $cols = [__('No.', 'idev-store'), __('Date bought', 'idev-store'), __('Seller', 'idev-store'), __('Drug name', 'idev-store'), __('Lot no.', 'idev-store'), __('Quantity', 'idev-store'), __('Pharmacist signature', 'idev-store'), __('Note', 'idev-store')];
        $rows = [];
        if ($items) {
            $moves = $wpdb->get_results($wpdb->prepare("SELECT m.*, l.lot_no, l.expiry FROM $M m LEFT JOIN $LT l ON l.id = m.lot_id WHERE m.type = 'receive' AND m.created_at BETWEEN %s AND %s ORDER BY m.created_at, m.id", $range), ARRAY_A);
            foreach ($moves as $m) {
                if (!isset($items[$m['item_id']])) continue;
                $i = $items[$m['item_id']];
                $rows[] = [count($rows) + 1, idev_format_day(substr($m['created_at'], 0, 10)), $m['note'], idev_store_drug_label($i), trim($m['lot_no'] . ($m['expiry'] ? ' EXP ' . $m['expiry'] : '')), idev_store_qty($m['qty']) . ' ' . $i['unit'], $sign, $m['ref']];
            }
        }
        return ['cols' => $cols, 'rows' => $rows];
    }
    if ($book === 'k10' || $book === 'k11') {
        $items = idev_store_drug_items($book === 'k10' ? ['special'] : ['k11']);
        $cols = $book === 'k10'
            ? [__('No.', 'idev-store'), __('Date sold', 'idev-store'), __('Quantity sold', 'idev-store'), __('Buyer name', 'idev-store'), __('Signature of the person on duty', 'idev-store'), __('Note', 'idev-store')]
            : [__('No.', 'idev-store'), __('Date', 'idev-store'), __('Quantity sold', 'idev-store'), __('Buyer name', 'idev-store'), __('Signature of the person on duty', 'idev-store'), __('Note', 'idev-store')];
        $sheets = []; $flat = [];
        foreach ($items as $i) {
            $moves = $wpdb->get_results($wpdb->prepare("SELECT m.*, b.id AS bill_id FROM $M m JOIN $B b ON b.no = m.ref WHERE m.item_id = %d AND m.type IN ('sale','job') AND b.status <> 'void' AND m.created_at BETWEEN %s AND %s ORDER BY m.lot_id, m.created_at, m.id", $i['id'], $range[0], $range[1]), ARRAY_A);
            $by = [];
            foreach ($moves as $m) $by[(int) $m['lot_id']][] = $m;
            foreach ($by as $lot_id => $ms) {
                $lot = $lot_id ? idev_store_lot($lot_id) : null;
                $in = $lot_id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM $M WHERE lot_id = %d AND qty > 0 AND type IN ('receive','count') ORDER BY id LIMIT 1", $lot_id), ARRAY_A) : null;
                $head = [
                    __('Drug name', 'idev-store') => idev_store_drug_label($i),
                    __('Manufacturer / importer', 'idev-store') => $i['attrs']['maker'] ?? '',
                    __('Lot no.', 'idev-store') => $lot ? trim($lot['lot_no'] . ($lot['expiry'] ? ' (EXP ' . $lot['expiry'] . ')' : '')) : '—',
                    __('Pack size', 'idev-store') => $i['attrs']['pack'] ?? '',
                    __('Obtained from', 'idev-store') => $in['note'] ?? '',
                    __('Quantity received', 'idev-store') => $in ? idev_store_qty($in['qty']) . ' ' . $i['unit'] : '',
                    __('Date received', 'idev-store') => $in ? idev_format_day(substr($in['created_at'], 0, 10)) : '',
                ];
                $rows = [];
                foreach ($ms as $m) {
                    $bill = idev_store_bill((int) $m['bill_id']);
                    $r = [count($rows) + 1, idev_format_day(substr($m['created_at'], 0, 10)), idev_store_qty(-$m['qty']) . ' ' . $i['unit'], idev_store_bill_buyer($bill), $sign, $m['ref']];
                    $rows[] = $r;
                    $flat[] = array_merge([$head[__('Drug name', 'idev-store')], $head[__('Lot no.', 'idev-store')]], array_slice($r, 1));
                }
                $sheets[] = [$head, $rows];
            }
        }
        return ['cols' => $cols, 'sheets' => $sheets, 'flat' => $flat, 'flat_cols' => array_merge([__('Drug name', 'idev-store'), __('Lot no.', 'idev-store')], array_slice($cols, 1))];
    }
    if ($book === 'k12') {
        $cols = [__('No.', 'idev-store'), __('Date sold', 'idev-store'), __('Prescriber (name)', 'idev-store'), __('Prescriber address / workplace', 'idev-store'), __('Patient (name)', 'idev-store'), __('Age', 'idev-store'), __('Patient address', 'idev-store'), __('Drugs and quantity', 'idev-store'), __('Signature of the person on duty', 'idev-store'), __('Note', 'idev-store')];
        $rows = [];
        $ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM $B WHERE status <> 'void' AND info <> '' AND created_at BETWEEN %s AND %s ORDER BY created_at, id", $range));
        foreach ($ids as $id) {
            $b = idev_store_bill((int) $id);
            if (empty($b['info']['rx'])) continue;
            $drugs = implode('; ', array_map(function ($l) { $it = (int) $l['item_id'] ? idev_store_item((int) $l['item_id']) : null; return $l['name'] . ' ' . idev_store_qty($l['qty']) . ' ' . ($it['unit'] ?? ''); }, $b['lines']));
            $rows[] = [count($rows) + 1, idev_format_day(substr($b['created_at'], 0, 10)), $b['info']['prescriber'] ?? '', $b['info']['prescriber_place'] ?? '', idev_store_bill_buyer($b), $b['info']['age'] ?? '', $b['info']['address'] ?? '', trim($drugs), $sign, $b['no']];
        }
        return ['cols' => $cols, 'rows' => $rows];
    }
    // k13: balance brought forward, received, sold, other changes, balance
    $items = idev_store_drug_items(null, true);
    $cols = [__('No.', 'idev-store'), __('Drug name', 'idev-store'), __('Registration no.', 'idev-store'), __('Pack size', 'idev-store'), __('Brought forward', 'idev-store'), __('Bought / received', 'idev-store'), __('Sold', 'idev-store'), __('Other changes', 'idev-store'), __('Closing balance', 'idev-store'), __('Unit', 'idev-store')];
    $rows = [];
    foreach ($items as $i) {
        $open = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(qty),0) FROM $M WHERE item_id = %d AND created_at < %s", $i['id'], $range[0]));
        $q = $wpdb->get_row($wpdb->prepare("SELECT COALESCE(SUM(CASE WHEN type = 'receive' THEN qty ELSE 0 END),0) r, COALESCE(SUM(CASE WHEN type IN ('sale','job','void') THEN qty ELSE 0 END),0) s, COALESCE(SUM(CASE WHEN type NOT IN ('receive','sale','job','void') THEN qty ELSE 0 END),0) o FROM $M WHERE item_id = %d AND created_at BETWEEN %s AND %s", $i['id'], $range[0], $range[1]), ARRAY_A);
        $rows[] = [count($rows) + 1, idev_store_drug_label($i), $i['attrs']['reg_no'] ?? '', $i['attrs']['pack'] ?? '', idev_store_qty($open), idev_store_qty($q['r']), idev_store_qty(-$q['s']), idev_store_qty($q['o']), idev_store_qty($open + $q['r'] + $q['s'] + $q['o']), $i['unit']];
    }
    return ['cols' => $cols, 'rows' => $rows];
}

function idev_store_khy_url($book, $from, $to, $what = 'print') {
    return add_query_arg(['action' => 'idev_store_khy', 'book' => $book, 'from' => $from, 'to' => $to, 'what' => $what, '_wpnonce' => wp_create_nonce('idev_store_khy')], admin_url('admin-post.php'));
}

add_action('admin_post_idev_store_khy', function () {
    if (!idev_store_can(true) || !wp_verify_nonce($_GET['_wpnonce'] ?? '', 'idev_store_khy')) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-store'), 403);
    if (!idev_store_khy_enabled()) wp_die(esc_html__('The ขย. books are in I-Drug.', 'idev-store'), 402);
    $books = idev_store_khy_books();
    $book = isset($books[$_GET['book'] ?? '']) ? $_GET['book'] : 'k9';
    $from = idev_is_valid_date($_GET['from'] ?? '') ? $_GET['from'] : idev_today();
    $to = idev_is_valid_date($_GET['to'] ?? '') ? $_GET['to'] : idev_today();
    $d = idev_store_khy_data($book, $from, $to);
    nocache_headers();
    if (($_GET['what'] ?? '') === 'csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $book . '-' . $from . '-' . $to . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, $d['flat_cols'] ?? $d['cols']);
        foreach ($d['flat'] ?? $d['rows'] as $r) fputcsv($out, $r);
        exit;
    }
    echo idev_store_khy_page($book, $from, $to, $d);
    exit;
});

function idev_store_khy_page($book, $from, $to, $d) {
    $s = idev_store_settings();
    $title = idev_store_khy_books()[$book][0];
    $period = idev_format_day($from) . ' – ' . idev_format_day($to);
    $head = '<div class="kh-top"><div><b>' . esc_html($title) . '</b></div><div>' . esc_html(sprintf(__('Pharmacy: %s', 'idev-store'), $s['shop_name'])) . ($s['khy_license'] ? ' · ' . esc_html(sprintf(__('Licence no. %s', 'idev-store'), $s['khy_license'])) : '') . '</div><div>' . esc_html($period) . ($s['pharmacist'] ? ' · ' . esc_html(sprintf(__('Pharmacist: %1$s %2$s', 'idev-store'), $s['pharmacist'], $s['pharmacist_no'])) : '') . '</div></div>';
    $table = function ($cols, $rows) {
        $o = '<table class="kh"><thead><tr>';
        foreach ($cols as $c) $o .= '<th>' . esc_html($c) . '</th>';
        $o .= '</tr></thead><tbody>';
        foreach ($rows as $r) { $o .= '<tr>'; foreach ($r as $k => $v) $o .= '<td' . ($k === 0 ? ' class="c"' : '') . '>' . nl2br(esc_html((string) $v)) . '</td>'; $o .= '</tr>'; }
        for ($i = count($rows); $i < 8; $i++) $o .= '<tr>' . str_repeat('<td>&nbsp;</td>', count($cols)) . '</tr>';
        return $o . '</tbody></table>';
    };
    $body = '';
    if (isset($d['sheets'])) {
        foreach ($d['sheets'] as [$h, $rows]) {
            $body .= '<section class="page">' . $head . '<div class="kh-head">';
            foreach ($h as $k => $v) $body .= '<span><i>' . esc_html($k) . ':</i> ' . esc_html($v !== '' ? $v : '……………') . '</span>';
            $body .= '</div>' . $table($d['cols'], $rows) . '</section>';
        }
        if (!$d['sheets']) $body = '<section class="page">' . $head . '<p>' . esc_html__('No sales in this period.', 'idev-store') . '</p></section>';
    } else $body = '<section class="page">' . $head . $table($d['cols'], $d['rows']) . '</section>';
    $trial = idev_store_licensed() ? '' : '<div class="trial">' . esc_html__('TRIAL — not activated', 'idev-store') . '</div>';
    return '<!doctype html><html lang="' . esc_attr(idev_lang()) . '"><head><meta charset="utf-8"><title>' . esc_html($title) . '</title><style>
@page{size:A4 landscape;margin:10mm}
*{box-sizing:border-box}body{margin:0;font:12px Tahoma,"Leelawadee UI","Sarabun","Noto Sans Thai",Arial,sans-serif;color:#000;background:#eef0f3}
.bar{position:sticky;top:0;display:flex;gap:8px;justify-content:center;padding:10px;background:#1d2327}
.bar a,.bar button{font:13px Tahoma,sans-serif;color:#fff;background:#3c434a;border:0;border-radius:6px;padding:7px 12px;text-decoration:none;cursor:pointer}.bar button{background:#00a32a;font-weight:bold}
.page{background:#fff;width:297mm;min-height:200mm;margin:16px auto;padding:10mm;box-shadow:0 2px 12px rgba(0,0,0,.15);position:relative}
.kh-top{text-align:center;line-height:1.6;margin-bottom:6px}.kh-top b{font-size:16px}
.kh-head{display:grid;grid-template-columns:repeat(3,1fr);gap:2px 14px;margin:6px 0 8px;border:1px solid #000;padding:6px}
.kh-head i{font-style:normal;color:#333}
table.kh{width:100%;border-collapse:collapse}.kh th,.kh td{border:1px solid #000;padding:4px 5px;vertical-align:top}.kh th{background:#f0f0f0}.kh td.c{text-align:center;width:36px}
.trial{border:2px solid #000;text-align:center;font-weight:bold;padding:3px;margin:8px auto;width:297mm;background:#fff}
@media print{body{background:#fff}.bar,.trial{display:none}.page{margin:0;box-shadow:none;width:auto;min-height:0;padding:0;page-break-after:always}' . ($trial ? '.page::after{content:"TRIAL";position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:bold 120px sans-serif;color:rgba(0,0,0,.08);transform:rotate(-20deg)}' : '') . '}
</style></head><body><div class="bar"><a href="' . esc_url(idev_store_khy_url($book, $from, $to, 'csv')) . '">CSV</a><button onclick="window.print()">' . esc_html__('Print', 'idev-store') . '</button></div>' . $trial . $body . '</body></html>';
}

/** Reports tab. */
function idev_store_khy_tab($from, $to) {
    if (!idev_store_khy_enabled()) { echo idev_license_upsell('store_pharmacy', esc_html__('The ขย. books (ขย.9–13) are in I-Drug. Contact iDevApp to upgrade.', 'idev-store')); return; }
    $books = idev_store_khy_books();
    $book = isset($books[$_GET['book'] ?? '']) ? $_GET['book'] : 'k9';
    $year = (int) ($_GET['year'] ?? wp_date('Y'));
    $term = (int) ($_GET['term'] ?? ceil((int) wp_date('n') / 4));
    if ($book === 'k13') [$from, $to] = idev_store_khy_term($year, $term);
    echo '<form class="ids-filter"><input type="hidden" name="page" value="idev-store-reports"><input type="hidden" name="tab" value="khy"><select name="book" onchange="this.form.submit()">';
    foreach ($books as $k => $b) echo '<option value="' . esc_attr($k) . '"' . selected($book, $k, false) . '>' . esc_html($b[0]) . '</option>';
    echo '</select> ';
    if ($book === 'k13') {
        echo '<select name="term">';
        foreach ([1 => __('Jan – Apr', 'idev-store'), 2 => __('May – Aug', 'idev-store'), 3 => __('Sep – Dec', 'idev-store')] as $k => $l) echo '<option value="' . $k . '"' . selected($term, $k, false) . '>' . esc_html($l) . '</option>';
        echo '</select> <input type="number" name="year" value="' . (int) $year . '" style="width:90px">';
    } else echo '<input type="date" name="from" value="' . esc_attr($from) . '"> – <input type="date" name="to" value="' . esc_attr($to) . '">';
    echo ' <button class="button">' . esc_html__('Show', 'idev-store') . '</button></form>';
    $d = idev_store_khy_data($book, $from, $to);
    echo '<div class="idev-card"><p class="description">' . esc_html($books[$book][1]) . '</p><p><a class="button button-primary" target="_blank" href="' . esc_url(idev_store_khy_url($book, $from, $to)) . '">🖨 ' . esc_html__('Print (A4 landscape)', 'idev-store') . '</a> <a class="button" href="' . esc_url(idev_store_khy_url($book, $from, $to, 'csv')) . '">' . esc_html__('Download CSV', 'idev-store') . '</a></p>';
    $cols = $d['flat_cols'] ?? $d['cols'];
    $rows = $d['flat'] ?? $d['rows'];
    echo '<table class="widefat striped ids-table"><thead><tr>';
    foreach ($cols as $c) echo '<th>' . esc_html($c) . '</th>';
    echo '</tr></thead><tbody>';
    foreach ($rows as $r) { echo '<tr>'; foreach ($r as $v) echo '<td>' . esc_html((string) $v) . '</td>'; echo '</tr>'; }
    if (!$rows) echo '<tr><td colspan="' . count($cols) . '">' . esc_html__('Nothing in this period.', 'idev-store') . '</td></tr>';
    echo '</tbody></table>';
    if ($book !== 'k12' && !idev_store_drug_items($book === 'k13' ? null : array_keys(array_diff_key(idev_store_drug_classes(), ['' => 1])), $book === 'k13')) echo '<p class="description">' . esc_html__('Tip: set the drug class (and "Report in ขย.13") on each item in Stock so it appears in the books.', 'idev-store') . '</p>';
    echo '<p class="description">' . esc_html__('The printout follows the columns of the official forms. The pharmacist still signs each entry by hand; check the current Thai FDA requirements for your province.', 'idev-store') . '</p></div>';
}
