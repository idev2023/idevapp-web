<?php
/**
 * Job orders (e.g. glasses): customer, prescription, items, deposit, status, pick-up appointment.
 * A job owns one bill; the deposit and the balance are payments on that bill.
 */
defined('ABSPATH') || exit;

/** Prescription fields per profile. Eye: sph cyl axis add prism base va (right / left) + PD. */
function idev_store_rx_fields() {
    return ['sph' => 'SPH', 'cyl' => 'CYL', 'axis' => 'AXIS', 'add' => 'ADD', 'prism' => 'PRISM', 'base' => 'BASE', 'va' => 'VA'];
}
function idev_store_rx_clean($in) {
    $c = function ($v) { return mb_substr(preg_replace('/[^0-9A-Za-z+\-.\/ ]/u', '', (string) $v), 0, 12); };
    $rx = [];
    foreach (['r', 'l'] as $eye) foreach (array_keys(idev_store_rx_fields()) as $f) { $v = $c($in[$eye][$f] ?? ''); if ($v !== '') $rx[$eye][$f] = $v; }
    foreach (['pd', 'pd_r', 'pd_l', 'seg'] as $f) { $v = $c($in[$f] ?? ''); if ($v !== '') $rx[$f] = $v; }
    foreach (['lens', 'examiner'] as $f) if (!empty($in[$f])) $rx[$f] = sanitize_text_field($in[$f]);
    if (!empty($in['note'])) $rx['note'] = sanitize_textarea_field($in['note']);
    return $rx;
}
function idev_store_rx_has($rx) { return !empty($rx['r']) || !empty($rx['l']) || !empty($rx['pd']) || !empty($rx['note']); }

function idev_store_job_row($r) {
    if (!$r) return null;
    $r['id'] = (int) $r['id'];
    $r['rx'] = idev_store_json_dec($r['rx']);
    $r['log'] = json_decode($r['log'] ?: '[]', true) ?: [];
    return $r;
}
function idev_store_job($id) { global $wpdb; return idev_store_job_row($wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_store_t('jobs') . ' WHERE id = %d', $id), ARRAY_A)); }
function idev_store_job_by_token($token) {
    global $wpdb;
    if (!preg_match('/^[a-f0-9]{32}$/', (string) $token)) return null;
    return idev_store_job_row($wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_store_t('jobs') . ' WHERE token = %s', $token), ARRAY_A));
}
/** Look-up by job number + last 4 digits of the phone (status page form). */
function idev_store_job_lookup($no, $phone4) {
    global $wpdb;
    $r = $wpdb->get_row($wpdb->prepare('SELECT j.* , c.phone FROM ' . idev_store_t('jobs') . ' j LEFT JOIN ' . idev_store_t('customers') . ' c ON c.id = j.customer_id WHERE j.no = %s', strtoupper(trim($no))), ARRAY_A);
    if (!$r) return null;
    $digits = idev_store_phone($r['phone'] ?? '');
    $p4 = preg_replace('/\D/', '', (string) $phone4);
    if (strlen($p4) < 4 || $digits === '' || substr($digits, -4) !== substr($p4, -4)) return null;
    unset($r['phone']);
    return idev_store_job_row($r);
}

function idev_store_job_log(&$job_log, $text) { $job_log[] = [idev_store_now(), wp_get_current_user()->display_name ?: 'web', $text]; }

/**
 * Creates a job order with its bill. $in: customer_id, kind, rx, due_date, note, lines, discount, deposit [method, amount, received].
 * Returns job id or WP_Error.
 */
function idev_store_job_create($in) {
    global $wpdb;
    $kinds = idev_store_job_kinds();
    $kind = isset($kinds[$in['kind'] ?? '']) ? $in['kind'] : array_key_first($kinds);
    $bill_id = idev_store_bill_create(['customer_id' => (int) ($in['customer_id'] ?? 0), 'lines' => $in['lines'] ?? [], 'discount' => $in['discount'] ?? 0, 'stock_type' => 'job', 'note' => $in['bill_note'] ?? '',
        'payments' => !empty($in['deposit']['amount']) ? [$in['deposit']] : []]);
    if (is_wp_error($bill_id)) return $bill_id;
    $log = [];
    idev_store_job_log($log, __('Job received', 'idev-store'));
    $now = idev_store_now();
    $no = idev_store_next_no(idev_store_settings()['prefix_job']);
    $wpdb->insert(idev_store_t('jobs'), ['no' => $no, 'customer_id' => (int) ($in['customer_id'] ?? 0), 'bill_id' => $bill_id, 'kind' => $kind, 'status' => 'new',
        'due_date' => idev_is_valid_date($in['due_date'] ?? '') ? $in['due_date'] : null, 'rx' => idev_store_json_enc(idev_store_rx_clean($in['rx'] ?? [])),
        'note' => sanitize_textarea_field($in['note'] ?? ''), 'token' => bin2hex(random_bytes(16)), 'log' => wp_json_encode($log, JSON_UNESCAPED_UNICODE), 'user_id' => get_current_user_id(), 'created_at' => $now, 'updated_at' => $now]);
    $id = (int) $wpdb->insert_id;
    $wpdb->update(idev_store_t('bills'), ['job_id' => $id], ['id' => $bill_id]);
    do_action('idev_store_job_created', $id);
    return $id;
}

/** Updates prescription / due date / note of a job. */
function idev_store_job_update($id, $in) {
    global $wpdb;
    $job = idev_store_job($id);
    if (!$job) return new WP_Error('job', __('Job not found.', 'idev-store'));
    $row = ['updated_at' => idev_store_now()];
    if (isset($in['rx'])) $row['rx'] = idev_store_json_enc(idev_store_rx_clean($in['rx']));
    if (array_key_exists('due_date', $in)) $row['due_date'] = idev_is_valid_date($in['due_date']) ? $in['due_date'] : null;
    if (isset($in['note'])) $row['note'] = sanitize_textarea_field($in['note']);
    $wpdb->update(idev_store_t('jobs'), $row, ['id' => $id]);
    return true;
}

function idev_store_job_set_status($id, $status, $note = '') {
    global $wpdb;
    $job = idev_store_job($id);
    $all = idev_store_job_statuses();
    if (!$job || !isset($all[$status])) return new WP_Error('job', __('Job not found.', 'idev-store'));
    if ($status === $job['status']) return true;
    $log = $job['log'];
    idev_store_job_log($log, $all[$status] . ($note !== '' ? ' — ' . $note : ''));
    $row = ['status' => $status, 'log' => wp_json_encode($log, JSON_UNESCAPED_UNICODE), 'updated_at' => idev_store_now()];
    $wpdb->update(idev_store_t('jobs'), $row, ['id' => $id]);
    if ($status === 'ready') idev_store_job_notify($id);
    if ($status === 'cancelled' && $job['bill_id']) { $b = idev_store_bill((int) $job['bill_id']); if ($b && $b['status'] !== 'void' && $b['paid'] <= 0) idev_store_bill_void((int) $job['bill_id'], sprintf(__('Job %s cancelled', 'idev-store'), $job['no'])); }
    do_action('idev_store_job_status', $id, $status, $job['status']);
    return true;
}

function idev_store_jobs($args = []) {
    global $wpdb;
    $j = idev_store_t('jobs'); $c = idev_store_t('customers');
    $w = ['1=1']; $p = [];
    if (!empty($args['status'])) {
        if ($args['status'] === 'open') $w[] = "j.status NOT IN ('done','cancelled')";
        else { $w[] = 'j.status = %s'; $p[] = $args['status']; }
    }
    if (!empty($args['pickup_date'])) { $w[] = 'j.pickup_date = %s'; $p[] = $args['pickup_date']; }
    if (!empty($args['customer_id'])) { $w[] = 'j.customer_id = %d'; $p[] = (int) $args['customer_id']; }
    if (!empty($args['q'])) { $like = '%' . $wpdb->esc_like(trim($args['q'])) . '%'; $w[] = '(j.no LIKE %s OR c.name LIKE %s OR c.phone LIKE %s)'; array_push($p, $like, $like, $like); }
    $order = !empty($args['pickup_date']) ? 'j.pickup_time, j.id' : 'j.id DESC';
    $sql = "SELECT j.*, c.name AS customer_name, c.phone AS customer_phone FROM $j j LEFT JOIN $c c ON c.id = j.customer_id WHERE " . implode(' AND ', $w) . " ORDER BY $order LIMIT " . max(1, min(500, (int) ($args['limit'] ?? 100)));
    return $wpdb->get_results($p ? $wpdb->prepare($sql, $p) : $sql, ARRAY_A);
}
function idev_store_job_counts() {
    global $wpdb;
    $out = [];
    foreach ($wpdb->get_results('SELECT status, COUNT(*) n FROM ' . idev_store_t('jobs') . ' GROUP BY status', ARRAY_A) as $r) $out[$r['status']] = (int) $r['n'];
    return $out;
}

/* ---------- Status page link, notifications ---------- */

function idev_store_job_url($job) {
    $page = (int) idev_store_settings()['status_page'];
    $base = $page && get_post_status($page) === 'publish' ? get_permalink($page) : home_url('/');
    return add_query_arg('idev_job', $job['token'], $base);
}
/** Text for LINE / SMS / e-mail when a job is ready. */
function idev_store_job_message($job) {
    $s = idev_store_settings();
    $c = idev_store_customer((int) $job['customer_id']);
    return sprintf(__('Hello %1$s, your order %2$s at %3$s is ready to pick up. Choose a pick-up time and see the details here: %4$s', 'idev-store'), $c['name'] ?? '', $job['no'], $s['shop_name'], idev_store_job_url($job));
}
function idev_store_job_notify($id) {
    global $wpdb;
    $job = idev_store_job($id);
    $c = $job ? idev_store_customer((int) $job['customer_id']) : null;
    if (!$job || !$c || idev_store_settings()['notify_email'] !== '1' || !is_email($c['email'])) return false;
    $s = idev_store_settings();
    $msg = idev_store_job_message($job);
    $html = '<div style="font-family:sans-serif;font-size:15px;line-height:1.6;color:#222"><p>' . esc_html($msg) . '</p><p><a href="' . esc_url(idev_store_job_url($job)) . '" style="display:inline-block;background:' . esc_attr($s['accent']) . ';color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">' . esc_html__('Choose a pick-up time', 'idev-store') . '</a></p><p style="color:#666">' . esc_html($s['shop_name'] . ($s['phone'] ? ' · ' . $s['phone'] : '')) . '</p></div>';
    $ok = wp_mail($c['email'], sprintf(__('Your order %s is ready', 'idev-store'), $job['no']), $html, ['Content-Type: text/html; charset=UTF-8']);
    if ($ok) $wpdb->update(idev_store_t('jobs'), ['notified_at' => idev_store_now()], ['id' => $id]);
    return $ok;
}

/* ---------- Pick-up appointments ---------- */

/** Free pick-up times on a date: ['10:00' => free places, …]. */
function idev_store_pickup_slots($date) {
    global $wpdb;
    $s = idev_store_settings();
    if (!idev_is_valid_date($date) || $date < idev_today() || $date > idev_add_days(idev_today(), (int) $s['pickup_ahead'])) return [];
    $days = array_map('intval', explode(',', $s['pickup_days']));
    if (!in_array(idev_iso_weekday($date), $days, true)) return [];
    if (function_exists('idev_holidays_get')) foreach (idev_holidays_get($date, $date) as $h) if (!empty($h['closes_clinics'])) return [];
    $step = max(10, (int) $s['pickup_minutes']);
    [$fh, $fm] = array_map('intval', explode(':', $s['pickup_from'] . ':0'));
    [$th, $tm] = array_map('intval', explode(':', $s['pickup_to'] . ':0'));
    $taken = [];
    foreach ($wpdb->get_results($wpdb->prepare('SELECT pickup_time, COUNT(*) n FROM ' . idev_store_t('jobs') . " WHERE pickup_date = %s AND status <> 'cancelled' GROUP BY pickup_time", $date), ARRAY_A) as $r) $taken[$r['pickup_time']] = (int) $r['n'];
    $now = $date === idev_today() ? (int) wp_date('H') * 60 + (int) wp_date('i') + 30 : 0;
    $out = [];
    for ($m = $fh * 60 + $fm; $m + $step <= $th * 60 + $tm; $m += $step) {
        if ($m < $now) continue;
        $t = sprintf('%02d:%02d', intdiv($m, 60), $m % 60);
        $out[$t] = max(0, (int) $s['pickup_capacity'] - ($taken[$t] ?? 0));
    }
    return $out;
}
function idev_store_job_book_pickup($id, $date, $time) {
    global $wpdb;
    $job = idev_store_job($id);
    if (!$job || in_array($job['status'], ['done', 'cancelled'], true)) return new WP_Error('job', __('This order can no longer be changed.', 'idev-store'));
    $slots = idev_store_pickup_slots($date);
    $mine = $job['pickup_date'] === $date && $job['pickup_time'] === $time;
    if (!isset($slots[$time]) || ($slots[$time] < 1 && !$mine)) return new WP_Error('slot', __('This time is no longer available. Please choose another.', 'idev-store'));
    $log = $job['log'];
    idev_store_job_log($log, sprintf(__('Pick-up booked: %1$s %2$s', 'idev-store'), idev_format_day($date, null, true), $time));
    $wpdb->update(idev_store_t('jobs'), ['pickup_date' => $date, 'pickup_time' => $time, 'log' => wp_json_encode($log, JSON_UNESCAPED_UNICODE), 'updated_at' => idev_store_now()], ['id' => $id]);
    $s = idev_store_settings();
    if (is_email($s['staff_email'])) wp_mail($s['staff_email'], sprintf(__('Pick-up booked: %1$s %2$s %3$s', 'idev-store'), $job['no'], $date, $time), sprintf(__('Order %1$s will be picked up on %2$s at %3$s.', 'idev-store'), $job['no'], idev_format_day($date, null, true), $time));
    return true;
}
