<?php
/**
 * Licensing. Without a licence iDev Store is a full trial: every document prints "TRIAL".
 * Sold in the iDevApp systems I-Clinic / I-Drug (stock, sales, customers) and
 * I-Clinic Pro (adds job orders, deposits and pick-up appointments).
 */
defined('ABSPATH') || exit;

add_action('init', function () {
    idev_register_license('store', [
        'name' => 'iDev Store', 'plugin' => 'idev-store',
        'free' => __('Trial: everything works, documents print "TRIAL".', 'idev-store'),
        'pro' => __('Included in I-Clinic, I-Clinic Pro and I-Drug (with installation and one year of support).', 'idev-store'),
        'price' => __('Package', 'idev-store'), 'usage' => 'idev_store_license_usage',
    ]);
}, 5);

function idev_store_licensed() { return function_exists('idev_is_licensed') && idev_is_licensed('store'); }
/** Job orders: in the trial, and in I-Clinic Pro. */
function idev_store_jobs_enabled() {
    /** Filter: switch a feature (jobs, khy) on or off — the iDevApp packages decide by edition. */
    return (bool) apply_filters('idev_store_feature', !idev_store_licensed() || idev_is_licensed('store_jobs'), 'jobs');
}
function idev_store_license_usage() {
    if (!idev_store_licensed()) return esc_html__('Trial', 'idev-store');
    if (idev_is_licensed('store_pharmacy')) return esc_html__('Stock, sales, customers, drug labels and ขย. books', 'idev-store');
    return esc_html(idev_store_jobs_enabled() ? __('Stock, sales, customers and job orders', 'idev-store') : __('Stock, sales and customers (job orders are in I-Clinic Pro)', 'idev-store'));
}
function idev_store_trial_banner() {
    if (idev_store_licensed() || !current_user_can('idev_store_manage')) return '';
    return idev_license_upsell('store', esc_html__('Trial: everything works and receipts / job tickets print "TRIAL". Enter your I-Clinic / I-Drug licence to use it for real.', 'idev-store'));
}
function idev_store_jobs_locked_page() {
    idev_store_head(__('Job orders', 'idev-store'));
    echo idev_license_upsell('store_jobs', esc_html__('Job orders, deposits and pick-up appointments are in I-Clinic Pro. Contact iDevApp to upgrade.', 'idev-store')) . '</div>';
}
