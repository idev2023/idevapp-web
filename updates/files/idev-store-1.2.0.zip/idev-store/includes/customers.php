<?php
/** Customers / patients of the shop. Name and phone stay searchable; address and notes are encrypted. */
defined('ABSPATH') || exit;

function idev_store_customer_row($r) {
    if (!$r) return null;
    $r['id'] = (int) $r['id'];
    $r['data'] = idev_store_json_dec($r['data']);
    return $r;
}
function idev_store_customer($id) {
    global $wpdb;
    return $id ? idev_store_customer_row($wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_store_t('customers') . ' WHERE id = %d', $id), ARRAY_A)) : null;
}
function idev_store_phone($p) { return preg_replace('/[^0-9+]/', '', (string) $p); }
function idev_store_customers($q = '', $limit = 50, $offset = 0) {
    global $wpdb;
    $t = idev_store_t('customers');
    if (trim($q) === '') return array_map('idev_store_customer_row', $wpdb->get_results($wpdb->prepare("SELECT * FROM $t ORDER BY id DESC LIMIT %d OFFSET %d", $limit, $offset), ARRAY_A));
    $like = '%' . $wpdb->esc_like(trim($q)) . '%';
    $digits = idev_store_phone($q);
    $plike = $digits !== '' ? '%' . $wpdb->esc_like($digits) . '%' : $like;
    return array_map('idev_store_customer_row', $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE name LIKE %s OR phone LIKE %s OR code LIKE %s OR hn LIKE %s ORDER BY name LIMIT %d", $like, $plike, $like, $like, $limit), ARRAY_A));
}
/** Creates or updates a customer. Returns id or WP_Error. */
function idev_store_customer_save($in, $id = 0) {
    global $wpdb;
    $name = sanitize_text_field($in['name'] ?? '');
    if ($name === '') return new WP_Error('name', __('Please enter the customer name.', 'idev-store'));
    $old = $id ? idev_store_customer($id) : null;
    $data = array_merge($old['data'] ?? [], array_filter([
        'address' => isset($in['address']) ? sanitize_textarea_field($in['address']) : null,
        'note' => isset($in['note']) ? sanitize_textarea_field($in['note']) : null,
    ], function ($v) { return $v !== null; }));
    $row = ['name' => $name, 'phone' => idev_store_phone($in['phone'] ?? ''), 'email' => sanitize_email($in['email'] ?? ''), 'line_id' => sanitize_text_field($in['line_id'] ?? ''),
        'hn' => sanitize_text_field($in['hn'] ?? ''), 'birthdate' => idev_is_valid_date($in['birthdate'] ?? '') ? $in['birthdate'] : null, 'data' => idev_store_json_enc($data), 'updated_at' => idev_store_now()];
    if ($id) { $wpdb->update(idev_store_t('customers'), $row, ['id' => $id]); return $id; }
    $row += ['code' => idev_store_next_no('C'), 'created_at' => $row['updated_at']];
    $wpdb->insert(idev_store_t('customers'), $row);
    return (int) $wpdb->insert_id;
}
function idev_store_customer_label($c) { return $c ? $c['name'] . ($c['phone'] ? ' · ' . $c['phone'] : '') : __('Walk-in customer', 'idev-store'); }
