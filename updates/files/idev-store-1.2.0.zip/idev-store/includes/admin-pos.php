<?php
/** Sell / dispense screen (barcode scanner friendly). The app itself is assets/pos.js. */
defined('ABSPATH') || exit;

function idev_store_admin_cfg($extra = []) {
    $s = idev_store_settings();
    return array_merge([
        'api' => esc_url_raw(rest_url('idev-store/v1/')), 'nonce' => wp_create_nonce('wp_rest'),
        'vat' => $s['vat'], 'vatRate' => (float) $s['vat_rate'], 'promptpay' => $s['promptpay'] !== '', 'methods' => idev_store_pay_methods(),
        't' => [
            'search' => __('Scan a barcode or type a name…', 'idev-store'), 'noItems' => __('No items found.', 'idev-store'), 'stock' => __('in stock', 'idev-store'), 'service' => __('service', 'idev-store'),
            'cartEmpty' => __('Scan or choose items to start.', 'idev-store'), 'customer' => __('Customer', 'idev-store'), 'walkin' => __('Walk-in customer', 'idev-store'), 'findCustomer' => __('Search name, phone, HN…', 'idev-store'),
            'newCustomer' => __('New customer', 'idev-store'), 'name' => __('Name', 'idev-store'), 'phone' => __('Phone', 'idev-store'), 'email' => __('E-mail', 'idev-store'), 'save' => __('Save', 'idev-store'), 'cancel' => __('Cancel', 'idev-store'),
            'subtotal' => __('Subtotal', 'idev-store'), 'discount' => __('Discount', 'idev-store'), 'vat' => __('VAT', 'idev-store'), 'vatIncl' => __('incl. VAT', 'idev-store'), 'total' => __('Total', 'idev-store'),
            'received' => __('Cash received', 'idev-store'), 'change' => __('Change', 'idev-store'), 'pay' => __('Save & print', 'idev-store'), 'payLater' => __('Save, pay later', 'idev-store'), 'paying' => __('Saving…', 'idev-store'),
            'scanQr' => __('Customer scans to pay', 'idev-store'), 'done' => __('Saved bill %s', 'idev-store'), 'reprint' => __('Print again', 'idev-store'), 'next' => __('Next customer', 'idev-store'),
            'error' => __('Something went wrong. Please try again.', 'idev-store'), 'remove' => __('Remove', 'idev-store'), 'price' => __('Price', 'idev-store'), 'qty' => __('Qty', 'idev-store'), 'notEnough' => __('Received is less than the total.', 'idev-store'),
            'low' => __('low', 'idev-store'), 'add' => __('Add', 'idev-store'), 'note' => __('Note', 'idev-store'),
        ],
    ], $extra);
}

function idev_store_page_pos() {
    wp_enqueue_script('idev-store-ids', IDEV_STORE_URL . 'assets/ids.js', [], IDEV_STORE_VERSION, true);
    wp_enqueue_script('idev-store-pos', IDEV_STORE_URL . 'assets/pos.js', ['idev-store-ids'], IDEV_STORE_VERSION, true);
    idev_store_head(__('Sell / dispense', 'idev-store'), __('Scan barcodes or search; Enter adds the first match. F9 = save & print.', 'idev-store'));
    echo idev_store_trial_banner();
    if (!idev_store_items(['limit' => 1])) idev_store_notice(sprintf(__('No items yet. <a href="%s">Add items to stock</a> first, or type a price for a one-off line.', 'idev-store'), esc_url(idev_store_url('idev-store-stock', ['edit' => 0]))), 'info');
    echo '<div id="ids-pos" data-cfg="' . esc_attr(wp_json_encode(idev_store_admin_cfg(idev_store_pos_drug_cfg()), JSON_UNESCAPED_UNICODE)) . '"></div></div>';
}

/** Pharmacy / clinic part of the sales screen: label builder words and the buyer form. */
function idev_store_pos_drug_cfg() {
    if (!idev_store_labels_on()) return [];
    $base = idev_store_admin_cfg()['t'];
    return [
        'labels' => true, 'pharmacy' => idev_store_is_pharmacy(),
        'classes' => array_filter(idev_store_drug_classes(), function ($k) { return $k !== '' && $k !== 'other'; }, ARRAY_FILTER_USE_KEY),
        'needBuyer' => ['special', 'k11'],
        'builder' => [
            'doseFmt' => __('{verb} {amount} {unit}', 'idev-store'),
            'verbs' => ['take' => __('Take', 'idev-store'), 'apply' => __('Apply', 'idev-store'), 'eye' => __('Put in the eyes', 'idev-store'), 'ear' => __('Put in the ears', 'idev-store'), 'nose' => __('Spray in the nose', 'idev-store'), 'inhale' => __('Inhale', 'idev-store'), 'use' => __('Use', 'idev-store')],
            'units' => ['tab' => __('tablet(s)', 'idev-store'), 'cap' => __('capsule(s)', 'idev-store'), 'tsp' => __('teaspoon(s)', 'idev-store'), 'tbsp' => __('tablespoon(s)', 'idev-store'), 'ml' => __('ml', 'idev-store'), 'drop' => __('drop(s)', 'idev-store'), 'sachet' => __('sachet(s)', 'idev-store'), 'puff' => __('puff(s)', 'idev-store'), 'thin' => __('a thin layer', 'idev-store')],
            'freqs' => ['1' => __('once a day', 'idev-store'), '2' => __('2 times a day', 'idev-store'), '3' => __('3 times a day', 'idev-store'), '4' => __('4 times a day', 'idev-store'), 'q46' => __('every 4–6 hours', 'idev-store'), 'q8' => __('every 8 hours', 'idev-store'), 'q12' => __('every 12 hours', 'idev-store'), 'prn' => __('when needed', 'idev-store')],
            'timings' => ['after' => __('after meals', 'idev-store'), 'before' => __('before meals (30 min)', 'idev-store'), 'with' => __('right after meals', 'idev-store'), 'bed' => __('at bedtime', 'idev-store'), '' => '—'],
            'periods' => ['m' => __('morning', 'idev-store'), 'n' => __('noon', 'idev-store'), 'e' => __('evening', 'idev-store'), 'b' => __('bedtime', 'idev-store')],
        ],
        't' => array_merge($base, [
            'setUse' => __('Set directions for the label', 'idev-store'), 'use' => __('Directions (printed on the label)', 'idev-store'), 'compose' => __('Fill in', 'idev-store'),
            'ind' => __('Indication', 'idev-store'), 'warn' => __('Warning', 'idev-store'), 'labels' => __('Print drug labels', 'idev-store'),
            'buyerTitle' => __('Buyer / prescription (ขย.)', 'idev-store'), 'required' => __('required', 'idev-store'), 'buyer' => __('Buyer / patient name', 'idev-store'),
            'age' => __('Age', 'idev-store'), 'address' => __('Address', 'idev-store'), 'rx' => __('Sold on prescription (ขย.12)', 'idev-store'),
            'prescriber' => __('Prescriber (doctor / dentist)', 'idev-store'), 'prescriberPlace' => __('Prescriber address / workplace', 'idev-store'),
            'needBuyer' => __('Please enter the buyer\'s name (specially controlled drug / ขย.11 list).', 'idev-store'),
        ]),
    ];
}
