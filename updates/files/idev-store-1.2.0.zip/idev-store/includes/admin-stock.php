<?php
/** Stock screen: items, item page (lots, count, write-off, movements), receive stock, CSV import. */
defined('ABSPATH') || exit;

function idev_store_item_attr_fields() {
    return idev_store_settings()['profile'] === 'optical'
        ? ['brand' => __('Brand', 'idev-store'), 'model' => __('Model', 'idev-store'), 'color' => __('Colour', 'idev-store'), 'size' => __('Size', 'idev-store'), 'spec' => __('Lens index / coating / power range', 'idev-store')]
        : (idev_store_settings()['profile'] === 'pharmacy'
            ? []
            : ['brand' => __('Brand', 'idev-store'), 'spec' => __('Details', 'idev-store')]);
}

add_action('idev_store_post_idev-store-stock', function () {
    if (idev_store_post_action('item')) {
        if (!idev_store_can(true)) wp_die(esc_html__('Only a shop manager can change items.', 'idev-store'), 403);
        $id = (int) ($_POST['id'] ?? 0);
        $in = wp_unslash($_POST['item'] ?? []);
        $new = !$id;
        $r = idev_store_item_save($in, $id);
        if (is_wp_error($r)) idev_store_redirect(idev_store_url('idev-store-stock', ['edit' => $id]), $r->get_error_message(), 'error');
        if ($new && idev_store_num($in['opening'] ?? 0) > 0) idev_store_stock_in($r, $in['opening'], ['lot_no' => $in['lot_no'] ?? '', 'expiry' => $in['expiry'] ?? '', 'type' => 'count', 'note' => __('Opening stock', 'idev-store')]);
        idev_store_redirect(idev_store_url('idev-store-stock', ['edit' => $r]), __('Item saved.', 'idev-store'));
    }
    if (idev_store_post_action('count')) {
        if (!idev_store_can(true)) wp_die(esc_html__('Only a shop manager can change stock.', 'idev-store'), 403);
        $id = (int) $_POST['item_id'];
        foreach ((array) ($_POST['counted'] ?? []) as $lot => $q) if ($q !== '') idev_store_stock_count($id, (int) $lot, $q, sanitize_text_field(wp_unslash($_POST['note'] ?? '')));
        idev_store_redirect(idev_store_url('idev-store-stock', ['edit' => $id]), __('Stock count saved.', 'idev-store'));
    }
    if (idev_store_post_action('loss')) {
        if (!idev_store_can(true)) wp_die(esc_html__('Only a shop manager can change stock.', 'idev-store'), 403);
        $id = (int) $_POST['item_id'];
        $type = ($_POST['type'] ?? '') === 'return' ? 'return' : 'loss';
        $r = idev_store_stock_out($id, $_POST['qty'] ?? 0, $type, '', sanitize_text_field(wp_unslash($_POST['note'] ?? '')));
        idev_store_redirect(idev_store_url('idev-store-stock', ['edit' => $id]), is_wp_error($r) ? $r->get_error_message() : __('Saved.', 'idev-store'), is_wp_error($r) ? 'error' : 'success');
    }
    if (idev_store_post_action('receive')) {
        $rows = json_decode(wp_unslash($_POST['payload'] ?? '[]'), true) ?: [];
        $ref = idev_store_next_no('GR');
        $note = sanitize_text_field(wp_unslash($_POST['supplier'] ?? ''));
        $n = 0;
        foreach ($rows as $r) {
            $res = idev_store_stock_in((int) ($r['item_id'] ?? 0), $r['qty'] ?? 0, ['lot_no' => sanitize_text_field($r['lot_no'] ?? ''), 'expiry' => $r['expiry'] ?? '', 'cost' => $r['cost'] ?? '', 'type' => 'receive', 'ref' => $ref, 'note' => $note]);
            if (!is_wp_error($res)) $n++;
        }
        idev_store_redirect(idev_store_url('idev-store-stock'), sprintf(__('Received %1$d items (%2$s).', 'idev-store'), $n, $ref));
    }
    if (idev_store_post_action('import')) {
        if (!idev_store_can(true)) wp_die(esc_html__('Only a shop manager can change items.', 'idev-store'), 403);
        $file = $_FILES['csv']['tmp_name'] ?? '';
        if (!$file || !is_uploaded_file($file)) idev_store_redirect(idev_store_url('idev-store-stock', ['import' => 1]), __('Please choose a CSV file.', 'idev-store'), 'error');
        [$added, $updated, $skipped] = idev_store_import_csv($file);
        idev_store_redirect(idev_store_url('idev-store-stock'), sprintf(__('Import done: %1$d added, %2$d updated, %3$d skipped.', 'idev-store'), $added, $updated, $skipped));
    }
});

/** CSV columns: name, sku, barcode, category, unit, price, cost, qty, min_qty, kind, lot_no, expiry. Matches existing items by SKU / barcode. */
function idev_store_import_csv($file) {
    $fh = fopen($file, 'r');
    $head = fgetcsv($fh);
    if (!$head) return [0, 0, 0];
    $head[0] = preg_replace('/^\xEF\xBB\xBF/', '', $head[0]);
    $head = array_map(function ($h) { return strtolower(trim($h)); }, $head);
    $added = $updated = $skipped = 0;
    while (($row = fgetcsv($fh)) !== false) {
        if (count(array_filter($row, 'strlen')) === 0) continue;
        $r = array_combine($head, array_pad(array_slice($row, 0, count($head)), count($head), ''));
        if (trim($r['name'] ?? '') === '') { $skipped++; continue; }
        $existing = idev_store_item_by_code($r['sku'] ?? '') ?: idev_store_item_by_code($r['barcode'] ?? '');
        $in = ['name' => $r['name'], 'sku' => $r['sku'] ?? '', 'barcode' => $r['barcode'] ?? '', 'category' => $r['category'] ?? '', 'unit' => $r['unit'] ?? '', 'price' => $r['price'] ?? 0, 'cost' => $r['cost'] ?? 0,
            'min_qty' => $r['min_qty'] ?? 0, 'kind' => ($r['kind'] ?? '') === 'service' ? 'service' : 'product', 'track' => ($r['kind'] ?? '') === 'service' ? 0 : 1, 'lots' => !empty($r['expiry']) || !empty($r['lot_no']) ? 1 : ($existing['lots'] ?? 0)];
        $id = idev_store_item_save($in, $existing['id'] ?? 0);
        if (is_wp_error($id)) { $skipped++; continue; }
        $existing ? $updated++ : $added++;
        if (idev_store_num($r['qty'] ?? 0) > 0) idev_store_stock_in($id, $r['qty'], ['lot_no' => $r['lot_no'] ?? '', 'expiry' => $r['expiry'] ?? '', 'cost' => $r['cost'] ?? '', 'type' => 'count', 'note' => 'CSV']);
    }
    fclose($fh);
    return [$added, $updated, $skipped];
}

function idev_store_page_stock() {
    if (isset($_GET['edit'])) { idev_store_item_page((int) $_GET['edit']); return; }
    if (!empty($_GET['receive'])) { idev_store_receive_page(); return; }
    if (!empty($_GET['import'])) { idev_store_import_page(); return; }
    $q = sanitize_text_field(wp_unslash($_GET['q'] ?? ''));
    $cat = sanitize_text_field(wp_unslash($_GET['category'] ?? ''));
    $low = !empty($_GET['low']);
    $items = idev_store_items(['q' => $q, 'category' => $cat, 'low' => $low, 'limit' => 500, 'active' => isset($_GET['inactive']) ? '0' : '1']);
    idev_store_head(__('Stock', 'idev-store'));
    idev_store_flash();
    echo '<p><a class="button button-primary" href="' . esc_url(idev_store_url('idev-store-stock', ['receive' => 1])) . '">＋ ' . esc_html__('Receive stock', 'idev-store') . '</a> ';
    if (idev_store_can(true)) echo '<a class="button" href="' . esc_url(idev_store_url('idev-store-stock', ['edit' => 0])) . '">＋ ' . esc_html__('New item', 'idev-store') . '</a> <a class="button" href="' . esc_url(idev_store_url('idev-store-stock', ['import' => 1])) . '">' . esc_html__('Import CSV', 'idev-store') . '</a>';
    echo '</p><form class="ids-filter"><input type="hidden" name="page" value="idev-store-stock"><input type="search" name="q" value="' . esc_attr($q) . '" placeholder="' . esc_attr__('Name, code, barcode', 'idev-store') . '"> <select name="category"><option value="">' . esc_html__('All categories', 'idev-store') . '</option>';
    foreach (idev_store_categories() as $c) echo '<option' . selected($cat, $c, false) . '>' . esc_html($c) . '</option>';
    echo '</select> <label><input type="checkbox" name="low" value="1"' . checked($low, true, false) . '> ' . esc_html__('Low stock only', 'idev-store') . '</label> <button class="button">' . esc_html__('Filter', 'idev-store') . '</button></form>';
    echo '<table class="widefat striped ids-table"><thead><tr><th>' . esc_html__('Item', 'idev-store') . '</th><th>' . esc_html__('Code', 'idev-store') . '</th><th>' . esc_html__('Category', 'idev-store') . '</th><th class="r">' . esc_html__('In stock', 'idev-store') . '</th><th class="r">' . esc_html__('Price', 'idev-store') . '</th><th class="r">' . esc_html__('Value at cost', 'idev-store') . '</th></tr></thead><tbody>';
    $value = 0;
    foreach ($items as $i) {
        $islow = $i['track'] && $i['min_qty'] > 0 && $i['qty'] <= $i['min_qty'];
        $value += $i['track'] ? max(0, $i['qty']) * $i['cost'] : 0;
        echo '<tr><td><a href="' . esc_url(idev_store_url('idev-store-stock', ['edit' => $i['id']])) . '"><b>' . esc_html($i['name']) . '</b></a>' . ($i['kind'] === 'service' ? ' <span class="ids-tag">' . esc_html__('service', 'idev-store') . '</span>' : '') . '</td><td>' . esc_html(trim($i['sku'] . ' ' . $i['barcode'])) . '</td><td>' . esc_html($i['category']) . '</td><td class="r' . ($islow ? ' ids-late' : '') . '">' . ($i['track'] ? esc_html(idev_store_qty($i['qty']) . ' ' . $i['unit']) : '—') . '</td><td class="r">' . esc_html(idev_store_money($i['price'], false)) . '</td><td class="r">' . ($i['track'] ? esc_html(idev_store_money(max(0, $i['qty']) * $i['cost'], false)) : '—') . '</td></tr>';
    }
    if (!$items) echo '<tr><td colspan="6">' . esc_html__('No items.', 'idev-store') . '</td></tr>';
    echo '</tbody><tfoot><tr><th colspan="5">' . esc_html(sprintf(__('%d items', 'idev-store'), count($items))) . '</th><th class="r">' . esc_html(idev_store_money($value)) . '</th></tr></tfoot></table></div>';
}

function idev_store_item_page($id) {
    $i = $id ? idev_store_item($id) : null;
    if ($id && !$i) { echo '<div class="wrap"><p>' . esc_html__('Item not found.', 'idev-store') . '</p></div>'; return; }
    $manage = idev_store_can(true);
    $v = $i ?: ['name' => '', 'name_en' => '', 'sku' => '', 'barcode' => '', 'category' => '', 'unit' => '', 'kind' => 'product', 'track' => 1, 'lots' => in_array(idev_store_settings()['profile'], ['pharmacy', 'clinic'], true) ? 1 : 0, 'price' => '', 'cost' => '', 'min_qty' => '', 'attrs' => [], 'active' => 1];
    idev_store_head($i ? $i['name'] : __('New item', 'idev-store'), $i ? sprintf(__('In stock: %s', 'idev-store'), idev_store_qty($i['qty']) . ' ' . $i['unit']) : '');
    idev_store_flash();
    echo '<p><a href="' . esc_url(idev_store_url('idev-store-stock')) . '">← ' . esc_html__('Stock', 'idev-store') . '</a></p><div class="ids-grid2"><div class="idev-card">';
    echo idev_store_form_open('item') . '<input type="hidden" name="id" value="' . (int) $id . '"><table class="form-table ids-form">';
    $row = function ($label, $html) { echo '<tr><th>' . esc_html($label) . '</th><td>' . $html . '</td></tr>'; };
    $in = function ($k, $type = 'text', $extra = '') use ($v, $manage) { return '<input type="' . $type . '" name="item[' . $k . ']" value="' . esc_attr($v[$k]) . '" ' . $extra . ($manage ? '' : ' readonly') . '>'; };
    $row(__('Name', 'idev-store'), $in('name', 'text', 'class="regular-text" required'));
    $row(__('Name (English)', 'idev-store'), $in('name_en', 'text', 'class="regular-text"'));
    $row(__('Code (SKU)', 'idev-store'), $in('sku'));
    $row(__('Barcode', 'idev-store'), $in('barcode', 'text', 'placeholder="' . esc_attr__('Scan here', 'idev-store') . '"'));
    $row(__('Category', 'idev-store'), $in('category', 'text', 'list="ids-cats"') . '<datalist id="ids-cats">' . implode('', array_map(function ($c) { return '<option value="' . esc_attr($c) . '">'; }, idev_store_categories())) . '</datalist>');
    $row(__('Unit', 'idev-store'), $in('unit', 'text', 'placeholder="' . esc_attr__('piece, box, pair…', 'idev-store') . '" size="10"'));
    $row(__('Type', 'idev-store'), '<select name="item[kind]"><option value="product"' . selected($v['kind'], 'product', false) . '>' . esc_html__('Product (has stock)', 'idev-store') . '</option><option value="service"' . selected($v['kind'], 'service', false) . '>' . esc_html__('Service / ordered in (no stock)', 'idev-store') . '</option></select>');
    $row(__('Stock', 'idev-store'), '<label><input type="checkbox" name="item[track]" value="1"' . checked($v['track'], 1, false) . '> ' . esc_html__('Track stock', 'idev-store') . '</label><br><label><input type="checkbox" name="item[lots]" value="1"' . checked($v['lots'], 1, false) . '> ' . esc_html__('Track lot number and expiry date', 'idev-store') . '</label>');
    $row(__('Selling price', 'idev-store'), $in('price', 'number', 'step="0.01" min="0"'));
    $row(__('Cost', 'idev-store'), $in('cost', 'number', 'step="0.01" min="0"'));
    $row(__('Warn when stock is at or below', 'idev-store'), $in('min_qty', 'number', 'step="any" min="0"'));
    foreach (idev_store_item_attr_fields() as $k => $l) $row($l, '<input type="text" name="item[attrs][' . esc_attr($k) . ']" value="' . esc_attr($v['attrs'][$k] ?? '') . '" class="regular-text"' . ($manage ? '' : ' readonly') . '>');
    $drug = idev_store_is_pharmacy() ? idev_store_drug_fields() : (idev_store_labels_on() ? idev_store_label_fields() : []);
    if ($drug) echo '<tr><th colspan="2"><h3 style="margin:8px 0 0">' . esc_html(idev_store_is_pharmacy() ? __('Drug details and label', 'idev-store') : __('Drug label', 'idev-store')) . '</h3></th></tr>';
    foreach ($drug as $k => $def) $row($def[0], idev_store_drug_input($k, $def, $v['attrs'][$k] ?? '', !$manage));
    if (!$i) $row(__('Opening stock', 'idev-store'), '<input type="number" step="any" min="0" name="item[opening]"> ' . esc_html__('Lot', 'idev-store') . ' <input name="item[lot_no]" size="10"> ' . esc_html__('Expiry', 'idev-store') . ' <input type="date" name="item[expiry]">');
    else $row(__('Active', 'idev-store'), '<label><input type="hidden" name="item[active]" value="0"><input type="checkbox" name="item[active]" value="1"' . checked($v['active'], 1, false) . '> ' . esc_html__('Show in sales and search', 'idev-store') . '</label>');
    echo '</table>' . ($manage ? '<p><button class="button button-primary">' . esc_html__('Save item', 'idev-store') . '</button></p>' : '') . '</form></div>';
    if (!$i) { echo '</div></div>'; return; }
    echo '<div>';
    if ($i['track']) {
        $lots = idev_store_lots($id);
        echo '<div class="idev-card"><h3>' . esc_html__('Stock by lot', 'idev-store') . '</h3>' . idev_store_form_open('count') . '<input type="hidden" name="item_id" value="' . $id . '"><table class="widefat striped"><thead><tr><th>' . esc_html__('Lot', 'idev-store') . '</th><th>' . esc_html__('Expiry', 'idev-store') . '</th><th class="r">' . esc_html__('In stock', 'idev-store') . '</th>' . ($manage ? '<th>' . esc_html__('Counted', 'idev-store') . '</th>' : '') . '</tr></thead><tbody>';
        $soon = idev_add_days(idev_today(), (int) idev_store_settings()['expiry_days']);
        foreach ($lots as $l) if ($l['qty'] != 0 || count($lots) === 1) echo '<tr><td>' . esc_html($l['lot_no'] ?: '—') . '</td><td' . ($l['expiry'] && $l['expiry'] <= $soon ? ' class="ids-late"' : '') . '>' . esc_html($l['expiry'] ? idev_format_day($l['expiry']) : '—') . '</td><td class="r">' . esc_html(idev_store_qty($l['qty'])) . '</td>' . ($manage ? '<td><input type="number" step="any" name="counted[' . $l['id'] . ']" style="width:90px"></td>' : '') . '</tr>';
        if (!$lots) echo '<tr><td colspan="4">' . esc_html__('No stock yet.', 'idev-store') . ($manage ? ' <input type="number" step="any" name="counted[0]" style="width:90px" placeholder="' . esc_attr__('Counted', 'idev-store') . '">' : '') . '</td></tr>';
        echo '</tbody></table>';
        if ($manage) echo '<p><input name="note" placeholder="' . esc_attr__('Note (e.g. monthly count)', 'idev-store') . '" class="regular-text"> <button class="button">' . esc_html__('Save count', 'idev-store') . '</button></p>';
        echo '</form>';
        if ($manage) echo '<details><summary>' . esc_html__('Write off / return to supplier', 'idev-store') . '</summary>' . idev_store_form_open('loss') . '<input type="hidden" name="item_id" value="' . $id . '"><p><select name="type"><option value="loss">' . esc_html__('Damaged / expired', 'idev-store') . '</option><option value="return">' . esc_html__('Returned to supplier', 'idev-store') . '</option></select> <input type="number" step="any" min="0" name="qty" placeholder="' . esc_attr__('Qty', 'idev-store') . '" style="width:80px"> <input name="note" placeholder="' . esc_attr__('Note', 'idev-store') . '"> <button class="button">' . esc_html__('Save', 'idev-store') . '</button></p></form></details>';
        echo '</div>';
    }
    $types = idev_store_move_types();
    echo '<div class="idev-card"><h3>' . esc_html__('Movements', 'idev-store') . '</h3><table class="widefat striped"><thead><tr><th>' . esc_html__('Date', 'idev-store') . '</th><th>' . esc_html__('Type', 'idev-store') . '</th><th class="r">' . esc_html__('Qty', 'idev-store') . '</th><th class="r">' . esc_html__('Balance', 'idev-store') . '</th><th>' . esc_html__('Ref.', 'idev-store') . '</th></tr></thead><tbody>';
    foreach (idev_store_moves($id) as $m) echo '<tr><td>' . esc_html(idev_store_doc_date($m['created_at'])) . '</td><td>' . esc_html($types[$m['type']] ?? $m['type']) . ($m['lot_no'] ? ' <small>Lot ' . esc_html($m['lot_no']) . '</small>' : '') . '</td><td class="r">' . esc_html(((float) $m['qty'] > 0 ? '+' : '') . idev_store_qty($m['qty'])) . '</td><td class="r">' . esc_html(idev_store_qty($m['balance'])) . '</td><td>' . esc_html(trim($m['ref'] . ' ' . $m['note'])) . '</td></tr>';
    echo '</tbody></table></div></div></div></div>';
}

function idev_store_receive_page() {
    wp_enqueue_script('idev-store-ids', IDEV_STORE_URL . 'assets/ids.js', [], IDEV_STORE_VERSION, true);
    $cfg = idev_store_admin_cfg(['tr' => ['lot' => __('Lot', 'idev-store'), 'expiry' => __('Expiry', 'idev-store'), 'cost' => __('Cost per unit', 'idev-store'), 'save' => __('Receive into stock', 'idev-store'), 'empty' => __('Scan or search items to receive.', 'idev-store')]]);
    idev_store_head(__('Receive stock', 'idev-store'));
    echo '<p><a href="' . esc_url(idev_store_url('idev-store-stock')) . '">← ' . esc_html__('Stock', 'idev-store') . '</a></p><div class="idev-card">' . idev_store_form_open('receive', 'id="ids-recvform"') . '<input type="hidden" name="payload" id="ids-recv-payload"><p><input name="supplier" class="regular-text" placeholder="' . esc_attr__('Supplier / delivery note no.', 'idev-store') . '"></p><div id="ids-recv" data-cfg="' . esc_attr(wp_json_encode($cfg, JSON_UNESCAPED_UNICODE)) . '"></div></form></div></div>';
    ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
  var root = document.getElementById('ids-recv'), I = window.IDS, el = I.el, cfg = JSON.parse(root.dataset.cfg), tr = cfg.tr, rows = [];
  var table = el('table', { class: 'widefat ids-cart' }), btn = el('button', { class: 'button button-primary button-hero', text: tr.save });
  function render() {
    table.innerHTML = '';
    table.appendChild(el('thead', {}, [el('tr', {}, [el('th', { text: '' }), el('th', { text: cfg.t.qty }), el('th', { text: tr.lot }), el('th', { text: tr.expiry }), el('th', { text: tr.cost }), el('th')])]));
    var tb = el('tbody');
    if (!rows.length) tb.appendChild(el('tr', {}, [el('td', { colspan: 6, class: 'ids-empty', text: tr.empty })]));
    rows.forEach(function (r, i) {
      function inp(k, type, w) { return el('input', { type: type, value: r[k], style: 'width:' + w, oninput: function (e) { r[k] = e.target.value; } }); }
      tb.appendChild(el('tr', {}, [el('td', { text: r.name }), el('td', {}, [inp('qty', 'number', '80px')]), el('td', {}, [inp('lot_no', 'text', '110px')]), el('td', {}, [inp('expiry', 'date', '150px')]), el('td', {}, [inp('cost', 'number', '100px')]),
        el('td', {}, [el('button', { type: 'button', class: 'button-link ids-x', text: '✕', onclick: function () { rows.splice(i, 1); render(); } })])]));
    });
    table.appendChild(tb); btn.disabled = !rows.length;
  }
  root.appendChild(I.itemSearch(cfg, function (it) { if (it.track) { rows.push({ item_id: it.id, name: it.name, qty: 1, lot_no: '', expiry: '', cost: '' }); render(); } }, 'product'));
  root.appendChild(table); root.appendChild(el('p', {}, [btn]));
  document.getElementById('ids-recvform').addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target.tagName === 'INPUT') e.preventDefault(); });
  document.getElementById('ids-recvform').addEventListener('submit', function () { document.getElementById('ids-recv-payload').value = JSON.stringify(rows); });
  render();
});
</script>
    <?php
}

function idev_store_import_page() {
    idev_store_head(__('Import items (CSV)', 'idev-store'));
    idev_store_flash();
    echo '<p><a href="' . esc_url(idev_store_url('idev-store-stock')) . '">← ' . esc_html__('Stock', 'idev-store') . '</a></p><div class="idev-card"><p>' . esc_html__('Save from Excel as "CSV UTF-8". The first row is the column names. Items with the same SKU or barcode are updated; quantities are added to stock.', 'idev-store') . '</p>';
    echo '<pre class="ids-pre">name,sku,barcode,category,unit,price,cost,qty,min_qty,kind,lot_no,expiry
Ray-Ban RB5154 Black,RB5154-BK,8053672000000,Frames,piece,4500,2600,3,1,product,,
Lens 1.56 AR,L156AR,,Lenses,pair,900,350,0,0,service,,
Paracetamol 500 mg,PARA500,8850000000001,Medicines,tablet,1,0.3,1000,200,product,A2401,2027-06-30</pre>';
    echo idev_store_form_open('import', 'enctype="multipart/form-data"') . '<p><input type="file" name="csv" accept=".csv,text/csv" required> <button class="button button-primary">' . esc_html__('Import', 'idev-store') . '</button></p></form></div></div>';
}
