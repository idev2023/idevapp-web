<?php
/** Job orders: list, new job (assets/job.js), job page with status, payments, pick-up and messages. */
defined('ABSPATH') || exit;

add_action('idev_store_post_idev-store-jobs', function () {
    if (!idev_store_jobs_enabled()) return;
    if (idev_store_post_action('create')) {
        $in = json_decode(wp_unslash($_POST['payload'] ?? '{}'), true) ?: [];
        if (empty($in['customer_id'])) idev_store_redirect(idev_store_url('idev-store-jobs', ['new' => 1]), __('Please choose the customer.', 'idev-store'), 'error');
        $id = idev_store_job_create([
            'customer_id' => (int) $in['customer_id'], 'kind' => sanitize_key($in['kind'] ?? ''), 'rx' => $in['rx'] ?? [], 'due_date' => $in['due_date'] ?? '', 'note' => $in['note'] ?? '',
            'lines' => $in['lines'] ?? [], 'discount' => $in['discount'] ?? 0, 'deposit' => ['method' => $in['method'] ?? 'cash', 'amount' => $in['deposit'] ?? 0, 'received' => $in['received'] ?? null],
        ]);
        if (is_wp_error($id)) idev_store_redirect(idev_store_url('idev-store-jobs', ['new' => 1]), $id->get_error_message(), 'error');
        idev_store_redirect(idev_store_url('idev-store-jobs', ['id' => $id, 'print' => 1]), __('Job order saved.', 'idev-store'));
    }
    $id = (int) ($_POST['job'] ?? 0);
    $back = idev_store_url('idev-store-jobs', ['id' => $id]);
    if (idev_store_post_action('status')) {
        $r = idev_store_job_set_status($id, sanitize_key($_POST['status'] ?? ''), sanitize_text_field(wp_unslash($_POST['note'] ?? '')));
        $job = idev_store_job($id);
        $msg = is_wp_error($r) ? $r->get_error_message() : __('Status updated.', 'idev-store') . ($job && $job['status'] === 'ready' && $job['notified_at'] ? ' ' . __('The customer was e-mailed.', 'idev-store') : '');
        idev_store_redirect($back, $msg, is_wp_error($r) ? 'error' : 'success');
    }
    if (idev_store_post_action('update')) {
        $r = idev_store_job_update($id, ['rx' => $_POST['rx'] ?? [], 'due_date' => sanitize_text_field($_POST['due_date'] ?? ''), 'note' => wp_unslash($_POST['note'] ?? '')]);
        idev_store_redirect($back, __('Saved.', 'idev-store'));
    }
    if (idev_store_post_action('pickup')) {
        $r = idev_store_job_book_pickup($id, sanitize_text_field($_POST['date'] ?? ''), sanitize_text_field($_POST['time'] ?? ''));
        idev_store_redirect($back, is_wp_error($r) ? $r->get_error_message() : __('Pick-up time saved.', 'idev-store'), is_wp_error($r) ? 'error' : 'success');
    }
    if (idev_store_post_action('notify')) {
        $ok = idev_store_job_notify($id);
        idev_store_redirect($back, $ok ? __('E-mail sent.', 'idev-store') : __('Could not send the e-mail (no e-mail address, or the server cannot send mail).', 'idev-store'), $ok ? 'success' : 'error');
    }
    if (idev_store_post_action('handover')) {
        $job = idev_store_job($id);
        if ($job && $job['bill_id'] && idev_store_num($_POST['amount'] ?? 0) > 0) {
            $p = idev_store_bill_pay((int) $job['bill_id'], sanitize_key($_POST['method'] ?? 'cash'), $_POST['amount'], $_POST['received'] ?? null);
            if (is_wp_error($p)) idev_store_redirect($back, $p->get_error_message(), 'error');
        }
        idev_store_job_set_status($id, 'done');
        idev_store_redirect(idev_store_url('idev-store-jobs', ['id' => $id, 'print_bill' => 1]), __('Picked up and paid. Thank you!', 'idev-store'));
    }
});

function idev_store_page_jobs() {
    if (!idev_store_jobs_enabled()) { idev_store_jobs_locked_page(); return; }
    if (!empty($_GET['new'])) { idev_store_job_new(); return; }
    if (!empty($_GET['id'])) { idev_store_job_view((int) $_GET['id']); return; }
    $status = sanitize_key($_GET['status'] ?? 'open');
    $q = sanitize_text_field(wp_unslash($_GET['q'] ?? ''));
    $jobs = idev_store_jobs(['status' => $status === 'all' ? '' : $status, 'q' => $q, 'limit' => 300]);
    $counts = idev_store_job_counts();
    $st = idev_store_job_statuses();
    $kinds = idev_store_job_kinds();
    idev_store_head(__('Job orders', 'idev-store'));
    idev_store_flash();
    echo '<p><a class="button button-primary" href="' . esc_url(idev_store_url('idev-store-jobs', ['new' => 1])) . '">＋ ' . esc_html__('New job order', 'idev-store') . '</a></p><ul class="subsubsub">';
    $tabs = ['open' => __('In progress', 'idev-store')] + $st + ['all' => __('All', 'idev-store')];
    $open_n = array_sum(array_intersect_key($counts, array_flip(['new', 'ordered', 'making', 'ready'])));
    $links = [];
    foreach ($tabs as $k => $l) { $n = $k === 'open' ? $open_n : ($k === 'all' ? array_sum($counts) : ($counts[$k] ?? 0)); $links[] = '<li><a href="' . esc_url(idev_store_url('idev-store-jobs', ['status' => $k])) . '"' . ($status === $k ? ' class="current"' : '') . '>' . esc_html($l) . ' <span class="count">(' . $n . ')</span></a>'; }
    echo implode(' |</li>', $links) . '</li></ul>';
    echo '<form class="ids-filter" style="float:right"><input type="hidden" name="page" value="idev-store-jobs"><input type="hidden" name="status" value="' . esc_attr($status) . '"><input type="search" name="q" value="' . esc_attr($q) . '" placeholder="' . esc_attr__('Job no., name, phone', 'idev-store') . '"> <button class="button">' . esc_html__('Search', 'idev-store') . '</button></form><br class="clear">';
    echo '<table class="widefat striped ids-table"><thead><tr><th>' . esc_html__('Order', 'idev-store') . '</th><th>' . esc_html__('Customer', 'idev-store') . '</th><th>' . esc_html__('Type', 'idev-store') . '</th><th>' . esc_html__('Ready by', 'idev-store') . '</th><th>' . esc_html__('Status', 'idev-store') . '</th><th>' . esc_html__('Pick-up', 'idev-store') . '</th><th class="r">' . esc_html__('Balance', 'idev-store') . '</th></tr></thead><tbody>';
    $today = idev_today();
    foreach ($jobs as $j) {
        $b = (int) $j['bill_id'] ? idev_store_bill((int) $j['bill_id']) : null;
        $late = $j['due_date'] && $j['due_date'] < $today && in_array($j['status'], ['new', 'ordered', 'making'], true);
        echo '<tr><td><a href="' . esc_url(idev_store_url('idev-store-jobs', ['id' => $j['id']])) . '"><b>' . esc_html($j['no']) . '</b></a><br><small>' . esc_html(idev_store_doc_date($j['created_at'])) . '</small></td><td>' . esc_html($j['customer_name']) . '<br><small>' . esc_html($j['customer_phone']) . '</small></td><td>' . esc_html($kinds[$j['kind']] ?? $j['kind']) . '</td><td' . ($late ? ' class="ids-late"' : '') . '>' . esc_html($j['due_date'] ? idev_format_day($j['due_date']) : '—') . '</td><td>' . idev_store_status_badge($j['status']) . '</td><td>' . esc_html($j['pickup_date'] ? idev_format_day($j['pickup_date']) . ' ' . $j['pickup_time'] : '—') . '</td><td class="r">' . ($b && $b['balance'] > 0.004 && $b['status'] !== 'void' ? esc_html(idev_store_money($b['balance'], false)) : '—') . '</td></tr>';
    }
    if (!$jobs) echo '<tr><td colspan="7">' . esc_html__('No job orders.', 'idev-store') . '</td></tr>';
    echo '</tbody></table></div>';
}

function idev_store_job_new() {
    wp_enqueue_script('idev-store-ids', IDEV_STORE_URL . 'assets/ids.js', [], IDEV_STORE_VERSION, true);
    wp_enqueue_script('idev-store-job', IDEV_STORE_URL . 'assets/job.js', ['idev-store-ids'], IDEV_STORE_VERSION, true);
    $s = idev_store_settings();
    $pre = !empty($_GET['customer']) ? idev_store_customer((int) $_GET['customer']) : null;
    $cfg = idev_store_admin_cfg(['customer' => $pre ? idev_store_public_customer($pre) : null, 'kinds' => idev_store_job_kinds(), 'optical' => $s['profile'] === 'optical', 'rxFields' => idev_store_rx_fields(), 'due' => idev_add_days(idev_today(), 3), 'tj' => [
        'kind' => __('Type', 'idev-store'), 'rx' => __('Prescription', 'idev-store'), 'right' => __('R (OD)', 'idev-store'), 'left' => __('L (OS)', 'idev-store'), 'lens' => __('Lens type / design', 'idev-store'),
        'examiner' => __('Examined by', 'idev-store'), 'rxNote' => __('Prescription note', 'idev-store'), 'due' => __('Ready by', 'idev-store'), 'items' => __('Items (frame, lenses, services)', 'idev-store'),
        'deposit' => __('Deposit now', 'idev-store'), 'note' => __('Note for the workshop', 'idev-store'), 'save' => __('Save job & print ticket', 'idev-store'), 'needCustomer' => __('Please choose the customer.', 'idev-store'),
        'details' => __('Details', 'idev-store'), 'balance' => __('Balance on pick-up', 'idev-store'), 'copyRx' => __('Copy R → L', 'idev-store'),
    ]]);
    idev_store_head(__('New job order', 'idev-store'));
    idev_store_flash();
    echo '<p><a href="' . esc_url(idev_store_url('idev-store-jobs')) . '">← ' . esc_html__('Job orders', 'idev-store') . '</a></p>';
    echo idev_store_form_open('create', 'id="ids-jobform"') . '<input type="hidden" name="payload" id="ids-payload"><div id="ids-job" data-cfg="' . esc_attr(wp_json_encode($cfg, JSON_UNESCAPED_UNICODE)) . '"></div></form></div>';
}

function idev_store_rx_inputs($rx) {
    $f = idev_store_rx_fields();
    $o = '<table class="ids-rx"><tr><th></th>';
    foreach ($f as $l) $o .= '<th>' . esc_html($l) . '</th>';
    $o .= '</tr>';
    foreach (['r' => __('R (OD)', 'idev-store'), 'l' => __('L (OS)', 'idev-store')] as $eye => $label) {
        $o .= '<tr><th>' . esc_html($label) . '</th>';
        foreach (array_keys($f) as $k) $o .= '<td><input name="rx[' . $eye . '][' . $k . ']" value="' . esc_attr($rx[$eye][$k] ?? '') . '"></td>';
        $o .= '</tr>';
    }
    $o .= '</table><div class="ids-rx-more">';
    foreach (['pd' => 'PD', 'pd_r' => 'PD R', 'pd_l' => 'PD L', 'seg' => 'SEG'] as $k => $l) $o .= '<label>' . esc_html($l) . ' <input name="rx[' . $k . ']" value="' . esc_attr($rx[$k] ?? '') . '" size="5"></label>';
    $o .= '<label>' . esc_html__('Lens type / design', 'idev-store') . ' <input name="rx[lens]" value="' . esc_attr($rx['lens'] ?? '') . '"></label><label>' . esc_html__('Examined by', 'idev-store') . ' <input name="rx[examiner]" value="' . esc_attr($rx['examiner'] ?? '') . '"></label></div>';
    return $o . '<textarea name="rx[note]" rows="2" class="large-text" placeholder="' . esc_attr__('Prescription note', 'idev-store') . '">' . esc_textarea($rx['note'] ?? '') . '</textarea>';
}

function idev_store_job_view($id) {
    $job = idev_store_job($id);
    if (!$job) { echo '<div class="wrap"><p>' . esc_html__('Job not found.', 'idev-store') . '</p></div>'; return; }
    $c = idev_store_customer((int) $job['customer_id']);
    $b = $job['bill_id'] ? idev_store_bill((int) $job['bill_id']) : null;
    $st = idev_store_job_statuses();
    $kinds = idev_store_job_kinds();
    $s = idev_store_settings();
    idev_store_head(sprintf(__('Order %s', 'idev-store'), $job['no']), ($kinds[$job['kind']] ?? '') . ' · ' . idev_store_doc_date($job['created_at']));
    idev_store_flash();
    if (!empty($_GET['print'])) echo '<script>window.open(' . wp_json_encode(idev_store_print_url('job', $id) . '#print') . ',"_blank")</script>';
    if (!empty($_GET['print_bill']) && $b) echo '<script>window.open(' . wp_json_encode(idev_store_print_url('bill', $b['id']) . '#print') . ',"_blank")</script>';
    echo '<p><a href="' . esc_url(idev_store_url('idev-store-jobs')) . '">← ' . esc_html__('Job orders', 'idev-store') . '</a> · <a target="_blank" href="' . esc_url(idev_store_print_url('job', $id)) . '">🖨 ' . esc_html__('Print job ticket', 'idev-store') . '</a>' . ($b ? ' · <a target="_blank" href="' . esc_url(idev_store_print_url('bill', $b['id'])) . '">🖨 ' . esc_html__('Print bill', 'idev-store') . '</a>' : '') . ' · <a target="_blank" href="' . esc_url(idev_store_job_url($job)) . '">' . esc_html__('Customer status page', 'idev-store') . ' ↗</a></p>';

    // status bar
    $flow = ['new', 'ordered', 'making', 'ready', 'done'];
    echo '<div class="idev-card ids-flow"><ol>';
    $at = array_search($job['status'], $flow, true);
    foreach ($flow as $i => $k) echo '<li class="' . ($job['status'] === 'cancelled' ? '' : ($i < $at ? 'done' : ($i === $at ? 'now' : ''))) . '">' . esc_html($st[$k]) . '</li>';
    echo '</ol><div class="ids-flow-act">' . idev_store_status_badge($job['status']);
    if (!in_array($job['status'], ['done', 'cancelled'], true)) {
        foreach (['ordered', 'making', 'ready'] as $k) if ($at === false || array_search($k, $flow, true) > $at) echo idev_store_form_open('status', 'style="display:inline"') . '<input type="hidden" name="job" value="' . $id . '"><input type="hidden" name="status" value="' . $k . '"><button class="button' . ($k === 'ready' ? ' button-primary' : '') . '">→ ' . esc_html($st[$k]) . '</button></form> ';
        echo idev_store_form_open('status', 'style="display:inline"') . '<input type="hidden" name="job" value="' . $id . '"><input type="hidden" name="status" value="cancelled"><button class="button-link ids-danger-link" onclick="return confirm(\'' . esc_js(__('Cancel this job order?', 'idev-store')) . '\')">' . esc_html__('Cancel job', 'idev-store') . '</button></form>';
    }
    echo '</div></div><div class="ids-grid2"><div>';

    // customer + prescription
    echo '<div class="idev-card"><h2>' . esc_html($c['name'] ?? '—') . '</h2><p>' . esc_html(implode(' · ', array_filter([$c['phone'] ?? '', $c['email'] ?? '', !empty($c['hn']) ? 'HN ' . $c['hn'] : '']))) . ($c ? ' · <a href="' . esc_url(idev_store_url('idev-store-customers', ['id' => $c['id']])) . '">' . esc_html__('History', 'idev-store') . '</a>' : '') . '</p>';
    echo idev_store_form_open('update') . '<input type="hidden" name="job" value="' . $id . '">';
    if ($s['profile'] === 'optical') echo '<h3>' . esc_html__('Prescription', 'idev-store') . '</h3>' . idev_store_rx_inputs($job['rx']);
    else echo '<h3>' . esc_html__('Details', 'idev-store') . '</h3><textarea name="rx[note]" rows="3" class="large-text">' . esc_textarea($job['rx']['note'] ?? '') . '</textarea>';
    echo '<p><label>' . esc_html__('Ready by', 'idev-store') . ' <input type="date" name="due_date" value="' . esc_attr($job['due_date']) . '"></label></p><p><textarea name="note" rows="2" class="large-text" placeholder="' . esc_attr__('Note for the workshop', 'idev-store') . '">' . esc_textarea($job['note']) . '</textarea></p><p><button class="button">' . esc_html__('Save', 'idev-store') . '</button></p></form></div>';

    // log
    echo '<div class="idev-card"><h3>' . esc_html__('History', 'idev-store') . '</h3><ul class="ids-log">';
    foreach (array_reverse($job['log']) as $l) echo '<li><small>' . esc_html(idev_store_doc_date($l[0]) . ' · ' . $l[1]) . '</small><br>' . esc_html($l[2]) . '</li>';
    echo '</ul></div></div><div>';

    // money
    if ($b) {
        echo '<div class="idev-card"><h3>' . esc_html__('Items and payment', 'idev-store') . '</h3><table class="widefat ids-table"><tbody>';
        foreach ($b['lines'] as $l) echo '<tr><td>' . esc_html($l['name']) . ($l['lot_text'] ? ' <small class="description">' . esc_html($l['lot_text']) . '</small>' : '') . '</td><td class="r">' . esc_html(idev_store_qty($l['qty'])) . '</td><td class="r">' . esc_html(idev_store_money($l['total'], false)) . '</td></tr>';
        echo '</tbody><tfoot><tr><th colspan="2">' . esc_html__('Total', 'idev-store') . '</th><th class="r">' . esc_html(idev_store_money($b['total'])) . '</th></tr><tr><td colspan="2">' . esc_html__('Paid', 'idev-store') . '</td><td class="r">' . esc_html(idev_store_money($b['paid'])) . '</td></tr><tr><th colspan="2">' . esc_html__('Balance', 'idev-store') . '</th><th class="r">' . esc_html(idev_store_money($b['balance'])) . '</th></tr></tfoot></table>';
        echo '<p><a href="' . esc_url(idev_store_url('idev-store-bills', ['id' => $b['id']])) . '">' . esc_html(sprintf(__('Bill %s', 'idev-store'), $b['no'])) . '</a></p>';
        if ($job['status'] === 'ready') {
            echo '<h3>' . esc_html__('Hand over to the customer', 'idev-store') . '</h3>' . idev_store_form_open('handover', 'class="ids-pay"') . '<input type="hidden" name="job" value="' . $id . '">';
            if ($b['balance'] > 0.004) {
                echo '<select name="method">'; foreach (idev_store_pay_methods() as $k => $l) echo '<option value="' . esc_attr($k) . '">' . esc_html($l) . '</option>'; echo '</select> ';
                echo '<input type="number" step="0.01" name="amount" value="' . esc_attr(number_format($b['balance'], 2, '.', '')) . '"> <input type="number" step="0.01" name="received" placeholder="' . esc_attr__('Cash received', 'idev-store') . '"> ';
            }
            echo '<button class="button button-primary">' . esc_html($b['balance'] > 0.004 ? __('Receive balance & mark picked up', 'idev-store') : __('Mark picked up', 'idev-store')) . '</button></form>';
            if ($b['balance'] > 0.004 && $s['promptpay']) echo '<div class="ids-qr">' . idev_store_promptpay_svg($b['balance'], 150) . '<small>PromptPay ' . esc_html(idev_store_money($b['balance'])) . '</small></div>';
        }
        echo '</div>';
    }

    // pick-up + messages
    if (in_array($job['status'], ['making', 'ordered', 'new', 'ready'], true)) {
        echo '<div class="idev-card"><h3>' . esc_html__('Pick-up', 'idev-store') . '</h3><p>' . ($job['pickup_date'] ? '<b>' . esc_html(idev_format_day($job['pickup_date'], null, true) . ' ' . $job['pickup_time']) . '</b>' : esc_html__('No time booked yet. When the status is "Ready to pick up", the customer can choose a time from the link.', 'idev-store')) . '</p>';
        echo idev_store_form_open('pickup') . '<input type="hidden" name="job" value="' . $id . '"><input type="date" name="date" min="' . esc_attr(idev_today()) . '" value="' . esc_attr($job['pickup_date'] ?: '') . '"> <input type="time" name="time" step="' . (int) $s['pickup_minutes'] * 60 . '" value="' . esc_attr($job['pickup_time']) . '"> <button class="button">' . esc_html__('Set pick-up time', 'idev-store') . '</button></form>';
        if ($job['status'] === 'ready') {
        $msg = idev_store_job_message($job);
        $phone = preg_replace('/[^0-9+]/', '', $c['phone'] ?? '');
        echo '<h3>' . esc_html__('Tell the customer', 'idev-store') . '</h3><textarea readonly rows="3" class="large-text ids-msg">' . esc_textarea($msg) . '</textarea><p class="ids-share">';
        echo '<a class="button" target="_blank" rel="noopener" href="' . esc_url('https://line.me/R/msg/text/?' . rawurlencode($msg)) . '">LINE</a> ';
        if ($phone) echo '<a class="button" href="' . esc_url('sms:' . $phone . '?body=' . rawurlencode($msg), ['sms']) . '">SMS</a> <a class="button" target="_blank" rel="noopener" href="' . esc_url('https://wa.me/' . ltrim(preg_replace('/^0/', '66', $phone), '+') . '?text=' . rawurlencode($msg)) . '">WhatsApp</a> ';
        echo '<button type="button" class="button" onclick="var t=this.closest(\'.idev-card\').querySelector(\'.ids-msg\');t.select();navigator.clipboard&&navigator.clipboard.writeText(t.value);this.textContent=\'✓\'">' . esc_html__('Copy text', 'idev-store') . '</button> ';
        if (!empty($c['email'])) echo idev_store_form_open('notify', 'style="display:inline"') . '<input type="hidden" name="job" value="' . $id . '"><button class="button">' . esc_html__('E-mail', 'idev-store') . '</button></form>';
        echo '</p>' . ($job['notified_at'] ? '<p class="description">' . esc_html(sprintf(__('E-mailed %s', 'idev-store'), idev_store_doc_date($job['notified_at']))) . '</p>' : '');
        }
        echo '</div>';
    }
    echo '</div></div></div>';
}
