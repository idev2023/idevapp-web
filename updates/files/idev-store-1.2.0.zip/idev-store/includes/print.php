<?php
/**
 * Printable documents: receipt (whole bill), payment receipt (deposit / part payment) and job ticket.
 * Formats: 80 mm receipt printer, A5, A4, continuous form (dot-matrix, size in inches from the settings).
 */
defined('ABSPATH') || exit;

function idev_store_print_formats() {
    return ['80mm' => __('Receipt printer 80 mm', 'idev-store'), 'a5' => 'A5', 'a4' => 'A4', 'continuous' => __('Continuous form (dot-matrix)', 'idev-store')];
}
function idev_store_print_url($type, $id, $format = '', $line = 0) {
    return add_query_arg(array_filter(['action' => 'idev_store_print', 'type' => $type, 'id' => $id, 'format' => $format, 'line' => $line, '_wpnonce' => wp_create_nonce('idev_store_print_' . $type . $id)]), admin_url('admin-post.php'));
}

add_action('admin_post_idev_store_print', function () {
    $type = sanitize_key($_GET['type'] ?? '');
    $id = (int) ($_GET['id'] ?? 0);
    if (!idev_store_can() || !wp_verify_nonce($_GET['_wpnonce'] ?? '', 'idev_store_print_' . $type . $id)) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-store'), 403);
    $s = idev_store_settings();
    $format = sanitize_key($_GET['format'] ?? '') ?: ($type === 'job' ? $s['job_format'] : ($type === 'label' ? $s['label_format'] : $s['receipt_format']));
    $formats = $type === 'label' ? idev_store_label_formats() : idev_store_print_formats();
    if (!isset($formats[$format])) $format = $type === 'label' ? 'label' : '80mm';
    if ($type === 'label') {
        $bill = idev_store_bill($id);
        if (!$bill) wp_die('Not found', 404);
        $line = (int) ($_GET['line'] ?? 0);
        $body = array_map(function ($x) use ($bill) { return idev_store_doc_label($bill, $x); }, idev_store_label_lines($bill, $line));
        if (!$body) wp_die(esc_html__('This bill has no drugs to label.', 'idev-store'), 404);
        nocache_headers();
        echo idev_store_print_page($bill['no'], $body, $format, $type, $id, $line);
        exit;
    }
    if ($type === 'job') { $job = idev_store_job($id); if (!$job) wp_die('Not found', 404); $body = idev_store_doc_job($job, $format); $title = $job['no']; }
    elseif ($type === 'payment') {
        global $wpdb;
        $p = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . idev_store_t('payments') . ' WHERE id = %d', $id), ARRAY_A);
        $bill = $p ? idev_store_bill((int) $p['bill_id']) : null;
        if (!$bill) wp_die('Not found', 404);
        $body = idev_store_doc_payment($bill, $p, $format); $title = $p['no'];
    } else { $bill = idev_store_bill($id); if (!$bill) wp_die('Not found', 404); $body = idev_store_doc_bill($bill, $format); $title = $bill['no']; }
    nocache_headers();
    echo idev_store_print_page($title, $body, $format, $type, $id);
    exit;
});

function idev_store_print_page($title, $body, $format, $type, $id, $line = 0) {
    $s = idev_store_settings();
    $page = ['label' => 'size: ' . (float) $s['label_w'] . 'mm ' . (float) $s['label_h'] . 'mm; margin: 0', '80mm' => 'size: 80mm auto; margin: 3mm', 'a5' => 'size: A5; margin: 10mm', 'a4' => 'size: A4; margin: 14mm',
        'continuous' => 'size: ' . (float) $s['cont_width'] . 'in ' . (float) $s['cont_height'] . 'in; margin: 0.2in 0.3in'][$format];
    $switch = '';
    foreach ($type === 'label' ? idev_store_label_formats() : idev_store_print_formats() as $k => $l) $switch .= '<a href="' . esc_url(idev_store_print_url($type, $id, $k, $line)) . '"' . ($k === $format ? ' class="on"' : '') . '>' . esc_html($l) . '</a>';
    ob_start(); ?>
<!doctype html><html lang="<?php echo esc_attr(idev_lang()); ?>"><head><meta charset="utf-8"><title><?php echo esc_html($title); ?></title>
<style>
@page { <?php echo $page; ?>; }
*{box-sizing:border-box}
body{margin:0;font-family:Tahoma,"Leelawadee UI","Sarabun","Noto Sans Thai",Arial,sans-serif;color:#000;background:#eef0f3}
.sheet{background:#fff;margin:16px auto;padding:10mm;box-shadow:0 2px 12px rgba(0,0,0,.15)}
.f-80mm .sheet{width:80mm;padding:3mm;font-size:12px}
.f-a5 .sheet{width:148mm;min-height:210mm;font-size:13px}
.f-a4 .sheet{width:210mm;min-height:297mm;font-size:13.5px;padding:14mm}
.f-continuous .sheet{width:<?php echo (float) $s['cont_width']; ?>in;min-height:<?php echo (float) $s['cont_height']; ?>in;padding:.2in .3in;font-size:13px}
.f-continuous *{color:#000!important;background:none!important;border-color:#000!important}
.bar{position:sticky;top:0;display:flex;gap:6px;flex-wrap:wrap;align-items:center;justify-content:center;padding:10px;background:#1d2327}
.bar a,.bar button{font:13px Tahoma,sans-serif;color:#fff;background:#3c434a;border:0;border-radius:6px;padding:7px 12px;text-decoration:none;cursor:pointer}
.bar a.on{background:#2271b1}.bar button{background:#00a32a;font-weight:bold}
h1{font-size:1.35em;margin:0 0 2px;text-align:center}
.shop{text-align:center;line-height:1.45;margin-bottom:8px}
.shop img{max-height:46px;max-width:60%;margin:0 auto 4px;display:block}
.shop b{font-size:1.15em}
.doc-title{text-align:center;font-weight:bold;font-size:1.12em;border-top:1px dashed #000;border-bottom:1px dashed #000;padding:4px 0;margin:6px 0}
.meta{display:grid;grid-template-columns:auto 1fr;gap:1px 10px;margin:6px 0}
.meta span:nth-child(odd){color:#333}
table{width:100%;border-collapse:collapse}
td,th{padding:3px 2px;vertical-align:top;text-align:left}
th{border-bottom:1px solid #000;font-weight:bold}
.r{text-align:right;white-space:nowrap}
.lot{font-size:.85em;color:#333}
.sum td{padding:2px}
.sum .big td{font-weight:bold;font-size:1.15em;border-top:1px solid #000}
.rx{margin:8px 0;border:1px solid #000}
.rx th,.rx td{border:1px solid #000;text-align:center;padding:3px}
.foot{text-align:center;margin-top:10px;border-top:1px dashed #000;padding-top:6px;line-height:1.5}
.qr{display:flex;gap:10px;align-items:center;margin-top:8px}
.qr svg{width:28mm;height:28mm;flex:none}
.f-80mm .qr{flex-direction:column;text-align:center}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.f-80mm .cols{grid-template-columns:1fr}
.sign{display:grid;grid-template-columns:1fr 1fr;gap:30px;margin-top:28px;text-align:center}
.sign div{border-top:1px dotted #000;padding-top:4px}
.sheet{position:relative}
.trial{border:2px solid #000;text-align:center;font-weight:bold;letter-spacing:.08em;padding:3px;margin-bottom:6px}
.sheet:has(.trial)::after{content:"TRIAL";position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:bold 72px sans-serif;color:rgba(0,0,0,.08);transform:rotate(-25deg);pointer-events:none}
@media print{body{background:#fff}.bar{display:none}.sheet{margin:0;box-shadow:none;width:auto!important;min-height:0!important;padding:0!important}}
<?php if ($type === 'label') echo idev_store_label_css($format); elseif (function_exists('idev_doc_css')) echo idev_doc_css(idev_store_doc_design(), $format === 'continuous'); ?>
</style></head><body class="f-<?php echo esc_attr($format); ?>">
<div class="bar"><?php echo $switch; ?><button onclick="window.print()"><?php esc_html_e('Print', 'idev-store'); ?></button></div>
<?php foreach ((array) $body as $b) { ?><div class="sheet"><?php if (!idev_store_licensed()) echo '<div class="trial">' . esc_html__('TRIAL — not activated', 'idev-store') . '</div>'; echo $b; ?></div><?php } ?>
<script>if(location.hash==='#print')window.addEventListener('load',function(){setTimeout(function(){window.print()},300)});</script>
</body></html>
<?php
    return ob_get_clean();
}

/** Look of printed documents (iDevApp document designer). */
function idev_store_doc_design() { return function_exists('idev_doc_design') ? idev_doc_design('idev_store_doc_design') : []; }
function idev_store_doc_head($title) {
    $s = idev_store_settings();
    if (function_exists('idev_doc_header')) return idev_doc_header(idev_store_doc_design(), ['name' => $s['shop_name'], 'address' => $s['address'], 'phone' => $s['phone'], 'tax_id' => $s['tax_id'], 'logo' => $s['logo']], $title);
    $o = '<div class="shop">' . ($s['logo'] ? '<img src="' . esc_url($s['logo']) . '" alt="">' : '') . '<b>' . esc_html($s['shop_name']) . '</b>';
    if ($s['address']) $o .= '<br>' . nl2br(esc_html($s['address']));
    $line = array_filter([$s['phone'] ? __('Tel.', 'idev-store') . ' ' . $s['phone'] : '', $s['tax_id'] ? __('Tax ID', 'idev-store') . ' ' . $s['tax_id'] : '']);
    if ($line) $o .= '<br>' . esc_html(implode(' · ', $line));
    return $o . '</div><div class="doc-title">' . esc_html($title) . '</div>';
}
function idev_store_doc_meta($rows) {
    $o = '<div class="meta">';
    foreach ($rows as $k => $v) if ($v !== '' && $v !== null) $o .= '<span>' . esc_html($k) . '</span><span>' . esc_html($v) . '</span>';
    return $o . '</div>';
}
function idev_store_doc_date($mysql) { return idev_format_day(substr($mysql, 0, 10)) . ' ' . substr($mysql, 11, 5); }
function idev_store_doc_lines($bill) {
    $o = '<table><thead><tr><th>' . esc_html__('Item', 'idev-store') . '</th><th class="r">' . esc_html__('Qty', 'idev-store') . '</th><th class="r">' . esc_html__('Amount', 'idev-store') . '</th></tr></thead><tbody>';
    foreach ($bill['lines'] as $l) {
        $o .= '<tr><td>' . esc_html($l['name']) . '<div class="lot">' . esc_html(idev_store_qty($l['qty']) . ' × ' . idev_store_money($l['price'], false) . ((float) $l['discount'] > 0 ? ' − ' . idev_store_money($l['discount'], false) : '')) . ($l['lot_text'] ? ' · ' . esc_html($l['lot_text']) : '') . '</div></td><td class="r">' . esc_html(idev_store_qty($l['qty'])) . '</td><td class="r">' . esc_html(idev_store_money($l['total'], false)) . '</td></tr>';
    }
    return $o . '</tbody></table>';
}
function idev_store_doc_sums($bill, $extra = []) {
    $s = idev_store_settings();
    $rows = [[__('Subtotal', 'idev-store'), $bill['subtotal']]];
    if ($bill['discount'] > 0) $rows[] = [__('Discount', 'idev-store'), -$bill['discount']];
    if ($s['vat'] === 'excluded') $rows[] = [sprintf(__('VAT %s%%', 'idev-store'), $s['vat_rate']), $bill['vat']];
    $o = '<table class="sum">';
    foreach ($rows as [$k, $v]) $o .= '<tr><td>' . esc_html($k) . '</td><td class="r">' . esc_html(idev_store_money($v, false)) . '</td></tr>';
    $o .= '<tr class="big"><td>' . esc_html__('Total', 'idev-store') . '</td><td class="r">' . esc_html(idev_store_money($bill['total'])) . '</td></tr>';
    if ($s['vat'] === 'included' && $bill['vat'] > 0) $o .= '<tr><td class="lot">' . esc_html(sprintf(__('Includes VAT %s%%', 'idev-store'), $s['vat_rate'])) . '</td><td class="r lot">' . esc_html(idev_store_money($bill['vat'], false)) . '</td></tr>';
    foreach ($extra as [$k, $v, $bold]) $o .= '<tr' . ($bold ? ' class="big"' : '') . '><td>' . esc_html($k) . '</td><td class="r">' . esc_html(is_numeric($v) ? idev_store_money($v) : $v) . '</td></tr>';
    return $o . '</table>';
}
function idev_store_doc_receipt_title() {
    $s = idev_store_settings();
    return $s['vat'] !== 'none' && $s['tax_id'] ? __('Receipt / Abbreviated tax invoice', 'idev-store') : __('Receipt', 'idev-store');
}

function idev_store_doc_bill($bill, $format) {
    $methods = idev_store_pay_methods();
    $void = $bill['status'] === 'void';
    $o = idev_store_doc_head(($void ? '[' . __('VOID', 'idev-store') . '] ' : '') . ($bill['balance'] > 0.004 && !$void ? __('Bill', 'idev-store') : idev_store_doc_receipt_title()));
    $o .= idev_store_doc_meta([__('No.', 'idev-store') => $bill['no'], __('Date', 'idev-store') => idev_store_doc_date($bill['created_at']), __('Customer', 'idev-store') => $bill['customer'] ? idev_store_customer_label($bill['customer']) : '']);
    $o .= idev_store_doc_lines($bill);
    $extra = [];
    foreach ($bill['payments'] as $p) if (!(int) $p['void']) {
        $extra[] = [sprintf(__('Paid (%s)', 'idev-store'), $methods[$p['method']] ?? $p['method']) . ' ' . idev_format_day(substr($p['created_at'], 0, 10)), (float) $p['amount'], false];
        if ((float) $p['change_amount'] > 0) $extra[] = [__('Received / change', 'idev-store'), idev_store_money($p['received'], false) . ' / ' . idev_store_money($p['change_amount'], false), false];
    }
    if ($bill['balance'] > 0.004 && !$void) $extra[] = [__('Balance due', 'idev-store'), $bill['balance'], true];
    $o .= idev_store_doc_sums($bill, $extra);
    $o .= idev_store_doc_foot($bill['user_id'], $format);
    if ($bill['balance'] > 0.004 && !$void && idev_store_settings()['promptpay']) $o .= '<div class="qr">' . idev_store_promptpay_svg($bill['balance'], 160) . '<div>' . esc_html(sprintf(__('Scan to pay %s with PromptPay', 'idev-store'), idev_store_money($bill['balance']))) . '</div></div>';
    return $o;
}
function idev_store_doc_payment($bill, $p, $format) {
    $methods = idev_store_pay_methods();
    $o = idev_store_doc_head(__('Payment receipt', 'idev-store'));
    $paid_before = 0.0;
    foreach ($bill['payments'] as $x) { if ((int) $x['id'] === (int) $p['id']) break; if (!(int) $x['void']) $paid_before += (float) $x['amount']; }
    $job = $bill['job_id'] ? idev_store_job((int) $bill['job_id']) : null;
    $o .= idev_store_doc_meta([__('No.', 'idev-store') => $p['no'], __('Date', 'idev-store') => idev_store_doc_date($p['created_at']), __('Customer', 'idev-store') => $bill['customer'] ? idev_store_customer_label($bill['customer']) : '', __('For', 'idev-store') => $job ? sprintf(__('Order %s', 'idev-store'), $job['no']) : sprintf(__('Bill %s', 'idev-store'), $bill['no'])]);
    $o .= idev_store_doc_lines($bill);
    $left = round($bill['total'] - $paid_before - (float) $p['amount'], 2);
    $o .= idev_store_doc_sums($bill, array_filter([
        $paid_before > 0 ? [__('Paid before', 'idev-store'), $paid_before, false] : null,
        [sprintf(__('Received now (%s)', 'idev-store'), $methods[$p['method']] ?? $p['method']), (float) $p['amount'], true],
        $left > 0.004 ? [__('Balance due', 'idev-store'), $left, false] : null,
    ]));
    return $o . idev_store_doc_foot($p['user_id'], $format);
}
function idev_store_doc_foot($user_id, $format = '') {
    $s = idev_store_settings();
    $d = idev_store_doc_design();
    $u = get_userdata((int) $user_id);
    $note = trim((string) ($d['footer_note'] ?? '')) !== '' ? $d['footer_note'] : ($s['footer'] ?: __('Thank you', 'idev-store'));
    $sign = function_exists('idev_doc_signatures') ? idev_doc_signatures($d, $format === '80mm') : '';
    return $sign . '<div class="foot doc-foot">' . ($u ? esc_html(sprintf(__('Staff: %s', 'idev-store'), $u->display_name)) . '<br>' : '') . nl2br(esc_html($note)) . '</div>';
}

function idev_store_rx_table($rx) {
    if (!idev_store_rx_has($rx)) return '';
    $f = idev_store_rx_fields();
    $o = '<table class="rx"><tr><th></th>';
    foreach ($f as $l) $o .= '<th>' . esc_html($l) . '</th>';
    $o .= '</tr>';
    foreach (['r' => __('R (OD)', 'idev-store'), 'l' => __('L (OS)', 'idev-store')] as $eye => $label) {
        $o .= '<tr><th>' . esc_html($label) . '</th>';
        foreach (array_keys($f) as $k) $o .= '<td>' . esc_html($rx[$eye][$k] ?? '') . '</td>';
        $o .= '</tr>';
    }
    $o .= '</table>';
    $more = array_filter(['PD' => trim(($rx['pd'] ?? '') . (isset($rx['pd_r']) || isset($rx['pd_l']) ? ' (R ' . ($rx['pd_r'] ?? '-') . ' / L ' . ($rx['pd_l'] ?? '-') . ')' : '')), 'SEG' => $rx['seg'] ?? '', __('Lens', 'idev-store') => $rx['lens'] ?? '', __('Examined by', 'idev-store') => $rx['examiner'] ?? '']);
    if ($more) $o .= idev_store_doc_meta($more);
    if (!empty($rx['note'])) $o .= '<div class="lot">' . nl2br(esc_html($rx['note'])) . '</div>';
    return $o;
}

function idev_store_doc_job($job, $format) {
    $bill = $job['bill_id'] ? idev_store_bill((int) $job['bill_id']) : null;
    $c = idev_store_customer((int) $job['customer_id']);
    $kinds = idev_store_job_kinds();
    $o = idev_store_doc_head(__('Job ticket', 'idev-store'));
    $o .= '<div class="cols"><div>' . idev_store_doc_meta([__('Order', 'idev-store') => $job['no'], __('Type', 'idev-store') => $kinds[$job['kind']] ?? $job['kind'], __('Received', 'idev-store') => idev_store_doc_date($job['created_at']), __('Ready by', 'idev-store') => $job['due_date'] ? idev_format_day($job['due_date']) : '']) . '</div>';
    $o .= '<div>' . idev_store_doc_meta([__('Customer', 'idev-store') => $c['name'] ?? '', __('Phone', 'idev-store') => $c['phone'] ?? '', 'HN' => $c['hn'] ?? '']) . '</div></div>';
    if (idev_store_settings()['print_rx'] === '1') $o .= idev_store_rx_table($job['rx']);
    if ($bill) {
        $o .= idev_store_doc_lines($bill);
        $o .= idev_store_doc_sums($bill, [[__('Deposit / paid', 'idev-store'), $bill['paid'], false], [__('Balance due on pick-up', 'idev-store'), $bill['balance'], true]]);
    }
    if ($job['note']) $o .= '<p>' . nl2br(esc_html($job['note'])) . '</p>';
    $url = idev_store_job_url($job);
    idev_load_qr();
    $o .= '<div class="qr">' . idev_qr_svg($url, 160, 'M') . '<div>' . esc_html__('Scan to check the status and book a pick-up time. Please bring this ticket when you pick up.', 'idev-store') . '<br><small>' . esc_html($job['no']) . '</small></div></div>';
    if ($format !== '80mm' && empty(idev_store_doc_design()['signatures'])) $o .= '<div class="sign"><div>' . esc_html__('Customer', 'idev-store') . '</div><div>' . esc_html__('Staff', 'idev-store') . '</div></div>';
    return $o . idev_store_doc_foot($job['user_id'], $format);
}

/* ---------- Print design (iDevApp document designer) ---------- */

/** Sample bill for the designer preview. */
function idev_store_doc_sample() {
    $now = current_time('mysql');
    $lines = [['name' => 'พาราเซตามอล 500 มก.', 'qty' => 2, 'price' => 35, 'discount' => 0, 'total' => 70, 'lot_text' => 'Lot A123 · หมดอายุ 03/2028'], ['name' => 'ยาแก้ไอน้ำดำ 60 มล.', 'qty' => 1, 'price' => 45, 'discount' => 5, 'total' => 40, 'lot_text' => ''], ['name' => 'หน้ากากอนามัย (กล่อง 50 ชิ้น)', 'qty' => 1, 'price' => 120, 'discount' => 0, 'total' => 120, 'lot_text' => '']];
    return ['id' => 0, 'no' => 'B' . wp_date('ymd') . '-0007', 'status' => 'paid', 'created_at' => $now, 'user_id' => get_current_user_id(), 'subtotal' => 230, 'discount' => 0, 'vat' => 0, 'total' => 230, 'paid' => 230, 'balance' => 0, 'job_id' => 0,
        'customer' => ['name' => 'คุณสมใจ ตัวอย่าง', 'phone' => '081-000-0000', 'code' => 'C00012', 'hn' => ''], 'lines' => $lines,
        'payments' => [['id' => 1, 'no' => 'R' . wp_date('ymd') . '-0007', 'method' => 'cash', 'amount' => 230, 'received' => 300, 'change_amount' => 70, 'void' => 0, 'created_at' => $now, 'user_id' => get_current_user_id()]], 'info' => []];
}
add_action('init', function () {
    if (!function_exists('idev_register_doc_designer')) return;
    $docs = ['receipt' => __('Receipt', 'idev-store'), 'payment' => __('Payment receipt', 'idev-store')];
    idev_register_doc_designer('store', [
        'option' => 'idev_store_doc_design', 'docs' => $docs, 'papers' => idev_store_print_formats(),
        'preview' => function ($doc, $design, $paper) {
            add_filter('pre_option_idev_store_doc_design', function () use ($design) { return $design; });
            $bill = idev_store_doc_sample();
            $format = isset(idev_store_print_formats()[$paper]) ? $paper : '80mm';
            $body = $doc === 'payment' ? idev_store_doc_payment($bill, $bill['payments'][0], $format) : idev_store_doc_bill($bill, $format);
            $html = idev_store_print_page($bill['no'], $body, $format, $doc === 'payment' ? 'payment' : 'bill', 0);
            return preg_replace('#<div class="bar">.*?</div>#s', '', $html, 1);
        },
    ]);
}, 30);
function idev_store_page_docs() {
    idev_store_head(__('Print design', 'idev-store'), __('Receipts, payment receipts and job tickets', 'idev-store'));
    if (isset($_GET['saved'])) idev_store_notice(__('Saved.', 'idev-store')); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    idev_doc_designer_ui('store', idev_store_url('idev-store-docs'));
    echo '</div>';
}
