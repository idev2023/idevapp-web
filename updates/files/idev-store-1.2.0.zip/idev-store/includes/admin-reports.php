<?php
/** Reports: money received, best sellers, stock value, low stock, expiring lots, CSV export. */
defined('ABSPATH') || exit;

add_action('admin_init', function () {
    if (($_GET['page'] ?? '') !== 'idev-store-reports' || empty($_GET['export']) || !idev_store_can(true)) return;
    check_admin_referer('idev_store_export');
    global $wpdb;
    $from = idev_is_valid_date($_GET['from'] ?? '') ? $_GET['from'] : idev_today();
    $to = idev_is_valid_date($_GET['to'] ?? '') ? $_GET['to'] : idev_today();
    $rows = $wpdb->get_results($wpdb->prepare('SELECT p.no, p.created_at, p.method, p.amount, p.void, b.no AS bill, c.name AS customer FROM ' . idev_store_t('payments') . ' p JOIN ' . idev_store_t('bills') . ' b ON b.id = p.bill_id LEFT JOIN ' . idev_store_t('customers') . ' c ON c.id = b.customer_id WHERE p.created_at BETWEEN %s AND %s ORDER BY p.id', $from . ' 00:00:00', $to . ' 23:59:59'), ARRAY_A);
    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="payments-' . $from . '-' . $to . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['receipt', 'date', 'method', 'amount', 'void', 'bill', 'customer']);
    foreach ($rows as $r) fputcsv($out, [$r['no'], $r['created_at'], $r['method'], $r['amount'], $r['void'], $r['bill'], $r['customer']]);
    exit;
});

function idev_store_page_reports() {
    global $wpdb;
    $tab = sanitize_key($_GET['tab'] ?? 'sales');
    $from = idev_is_valid_date($_GET['from'] ?? '') ? $_GET['from'] : substr(idev_today(), 0, 8) . '01';
    $to = idev_is_valid_date($_GET['to'] ?? '') ? $_GET['to'] : idev_today();
    idev_store_head(__('Reports', 'idev-store'));
    $tabs = ['sales' => __('Money received', 'idev-store'), 'items' => __('Best sellers', 'idev-store'), 'stock' => __('Stock value', 'idev-store'), 'expiry' => __('Expiring lots', 'idev-store')];
    if (idev_store_is_pharmacy()) $tabs['khy'] = __('ขย. books', 'idev-store');
    echo '<nav class="idev-seg" style="margin:0 0 12px">';
    foreach ($tabs as $k => $l) echo '<a style="text-decoration:none;padding:6px 12px;border-radius:7px;font-weight:600;color:#3c434a' . ($k === $tab ? ';background:#fff;box-shadow:0 1px 3px #0002' : '') . '" href="' . esc_url(idev_store_url('idev-store-reports', ['tab' => $k, 'from' => $from, 'to' => $to])) . '">' . esc_html($l) . '</a>';
    echo '</nav>';
    if (in_array($tab, ['sales', 'items'], true)) echo '<form class="ids-filter"><input type="hidden" name="page" value="idev-store-reports"><input type="hidden" name="tab" value="' . esc_attr($tab) . '"><input type="date" name="from" value="' . esc_attr($from) . '"> – <input type="date" name="to" value="' . esc_attr($to) . '"> <button class="button">' . esc_html__('Show', 'idev-store') . '</button></form>';
    if ($tab !== 'khy') echo '<p><a class="button" target="_blank" href="' . esc_url(wp_nonce_url(idev_store_url('idev-store-reports', ['print' => 1, 'tab' => $tab, 'from' => $from, 'to' => $to]), 'idev_store_report_print')) . '">🖨 ' . esc_html__('Print report', 'idev-store') . '</a></p>';
    idev_store_report_tab($tab, $from, $to);
    echo '</div>';
}

/** One report tab (screen and print). */
function idev_store_report_tab($tab, $from, $to) {
    global $wpdb;
    $range = [$from . ' 00:00:00', $to . ' 23:59:59'];
    $P = idev_store_t('payments'); $B = idev_store_t('bills'); $L = idev_store_t('lines');
    if ($tab === 'sales') {
        $methods = idev_store_pay_methods();
        $by = $wpdb->get_results($wpdb->prepare("SELECT method, COUNT(*) n, SUM(amount) s FROM $P WHERE void = 0 AND created_at BETWEEN %s AND %s GROUP BY method", $range), ARRAY_A);
        $days = $wpdb->get_results($wpdb->prepare("SELECT substr(created_at,1,10) d, SUM(amount) s, COUNT(*) n FROM $P WHERE void = 0 AND created_at BETWEEN %s AND %s GROUP BY substr(created_at,1,10) ORDER BY d", $range), ARRAY_A);
        $voids = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $B WHERE status = 'void' AND updated_at BETWEEN %s AND %s", $range));
        $owed = (float) $wpdb->get_var("SELECT COALESCE(SUM(total - paid),0) FROM $B WHERE status = 'open'");
        $total = array_sum(array_column($by, 's'));
        echo '<div class="ids-stats"><div class="ids-stat"><small>' . esc_html__('Total received', 'idev-store') . '</small><b>' . esc_html(idev_store_money($total)) . '</b></div>';
        foreach ($by as $r) echo '<div class="ids-stat"><small>' . esc_html($methods[$r['method']] ?? $r['method']) . ' (' . (int) $r['n'] . ')</small><b>' . esc_html(idev_store_money($r['s'])) . '</b></div>';
        echo '<div class="ids-stat warn"><small>' . esc_html__('Outstanding balances (all)', 'idev-store') . '</small><b>' . esc_html(idev_store_money($owed)) . '</b></div><div class="ids-stat"><small>' . esc_html__('Voided bills', 'idev-store') . '</small><b>' . $voids . '</b></div></div>';
        echo '<div class="idev-card"><table class="widefat striped ids-table"><thead><tr><th>' . esc_html__('Date', 'idev-store') . '</th><th class="r">' . esc_html__('Payments', 'idev-store') . '</th><th class="r">' . esc_html__('Amount', 'idev-store') . '</th></tr></thead><tbody>';
        foreach ($days as $d) echo '<tr><td>' . esc_html(idev_format_day($d['d'], null, true)) . '</td><td class="r">' . (int) $d['n'] . '</td><td class="r">' . esc_html(idev_store_money($d['s'], false)) . '</td></tr>';
        if (!$days) echo '<tr><td colspan="3">—</td></tr>';
        echo '</tbody></table><p><a class="button" href="' . esc_url(wp_nonce_url(idev_store_url('idev-store-reports', ['export' => 1, 'from' => $from, 'to' => $to]), 'idev_store_export')) . '">' . esc_html__('Download CSV', 'idev-store') . '</a></p></div>';
    } elseif ($tab === 'items') {
        $rows = $wpdb->get_results($wpdb->prepare("SELECT l.name, SUM(l.qty) q, SUM(l.total) s FROM $L l JOIN $B b ON b.id = l.bill_id WHERE b.status <> 'void' AND b.created_at BETWEEN %s AND %s GROUP BY l.item_id, l.name ORDER BY s DESC LIMIT 100", $range), ARRAY_A);
        echo '<div class="idev-card"><table class="widefat striped ids-table"><thead><tr><th>' . esc_html__('Item', 'idev-store') . '</th><th class="r">' . esc_html__('Qty', 'idev-store') . '</th><th class="r">' . esc_html__('Amount', 'idev-store') . '</th></tr></thead><tbody>';
        foreach ($rows as $r) echo '<tr><td>' . esc_html($r['name']) . '</td><td class="r">' . esc_html(idev_store_qty($r['q'])) . '</td><td class="r">' . esc_html(idev_store_money($r['s'], false)) . '</td></tr>';
        if (!$rows) echo '<tr><td colspan="3">—</td></tr>';
        echo '</tbody></table></div>';
    } elseif ($tab === 'stock') {
        $rows = $wpdb->get_results('SELECT category, COUNT(*) n, SUM(CASE WHEN qty > 0 THEN qty * cost ELSE 0 END) v, SUM(CASE WHEN qty > 0 THEN qty * price ELSE 0 END) p FROM ' . idev_store_t('items') . ' WHERE active = 1 AND track = 1 GROUP BY category ORDER BY v DESC', ARRAY_A);
        echo '<div class="idev-card"><table class="widefat striped ids-table"><thead><tr><th>' . esc_html__('Category', 'idev-store') . '</th><th class="r">' . esc_html__('Items', 'idev-store') . '</th><th class="r">' . esc_html__('Value at cost', 'idev-store') . '</th><th class="r">' . esc_html__('Value at selling price', 'idev-store') . '</th></tr></thead><tbody>';
        foreach ($rows as $r) echo '<tr><td>' . esc_html($r['category'] ?: '—') . '</td><td class="r">' . (int) $r['n'] . '</td><td class="r">' . esc_html(idev_store_money($r['v'], false)) . '</td><td class="r">' . esc_html(idev_store_money($r['p'], false)) . '</td></tr>';
        echo '</tbody><tfoot><tr><th>' . esc_html__('Total', 'idev-store') . '</th><th class="r">' . (int) array_sum(array_column($rows, 'n')) . '</th><th class="r">' . esc_html(idev_store_money(array_sum(array_column($rows, 'v')))) . '</th><th class="r">' . esc_html(idev_store_money(array_sum(array_column($rows, 'p')))) . '</th></tr></tfoot></table><p><a href="' . esc_url(idev_store_url('idev-store-stock', ['low' => 1])) . '">' . esc_html(sprintf(__('Low stock: %d items', 'idev-store'), idev_store_low_count())) . ' →</a></p></div>';
    } elseif ($tab === 'khy' && idev_store_is_pharmacy()) {
        idev_store_khy_tab($from, $to);
    } else {
        $rows = idev_store_expiring();
        echo '<div class="idev-card"><p>' . esc_html(sprintf(__('Lots that expire within %d days (change in Settings).', 'idev-store'), (int) idev_store_settings()['expiry_days'])) . '</p><table class="widefat striped ids-table"><thead><tr><th>' . esc_html__('Expiry', 'idev-store') . '</th><th>' . esc_html__('Item', 'idev-store') . '</th><th>' . esc_html__('Lot', 'idev-store') . '</th><th class="r">' . esc_html__('In stock', 'idev-store') . '</th></tr></thead><tbody>';
        foreach ($rows as $r) echo '<tr><td' . ($r['expiry'] < idev_today() ? ' class="ids-late"' : '') . '>' . esc_html(idev_format_day($r['expiry'])) . '</td><td><a href="' . esc_url(idev_store_url('idev-store-stock', ['edit' => $r['item_id']])) . '">' . esc_html($r['name']) . '</a></td><td>' . esc_html($r['lot_no']) . '</td><td class="r">' . esc_html(idev_store_qty($r['qty']) . ' ' . $r['unit']) . '</td></tr>';
        if (!$rows) echo '<tr><td colspan="4">' . esc_html__('Nothing expiring soon.', 'idev-store') . '</td></tr>';
        echo '</tbody></table></div>';
    }
}

/* Printed report in the shop's document look. */
add_action('admin_init', function () {
    if (($_GET['page'] ?? '') !== 'idev-store-reports' || empty($_GET['print']) || !idev_store_can(true)) return;
    check_admin_referer('idev_store_report_print');
    $tab = sanitize_key($_GET['tab'] ?? 'sales');
    $from = idev_is_valid_date($_GET['from'] ?? '') ? $_GET['from'] : idev_today();
    $to = idev_is_valid_date($_GET['to'] ?? '') ? $_GET['to'] : idev_today();
    $titles = ['sales' => __('Money received', 'idev-store'), 'items' => __('Best sellers', 'idev-store'), 'stock' => __('Stock value', 'idev-store'), 'expiry' => __('Expiring lots', 'idev-store')];
    ob_start();
    idev_store_report_tab($tab, $from, $to);
    $body = ob_get_clean();
    $body = preg_replace('#<p><a class="button"[^>]*>.*?</a></p>#s', '', $body); // no buttons on paper
    $s = idev_store_settings();
    $design = idev_store_doc_design();
    nocache_headers();
    echo idev_doc_page(['title' => $titles[$tab] ?? $titles['sales'], 'design' => $design, 'paper' => 'a4', 'trial' => !idev_store_licensed(),
        'org' => ['name' => $s['shop_name'], 'address' => $s['address'], 'phone' => $s['phone'], 'tax_id' => $s['tax_id'], 'logo' => $s['logo'], 'meta' => in_array($tab, ['sales', 'items'], true) ? '<p class="muted">' . esc_html(idev_format_day($from) . ' – ' . idev_format_day($to)) . '</p>' : ''],
        'body' => '<style>.ids-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:8px 0}.ids-stat{border:1px solid #c9d0d6;border-radius:8px;padding:6px 10px}.ids-stat small{display:block;color:#444}.ids-stat b{font-size:1.2em;color:var(--dc)}</style>' . $body . idev_doc_signatures($design) . idev_doc_footer($design, sprintf(__('Printed %s', 'idev-store'), wp_date('j M Y H:i')))]); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    exit;
});
