<?php
/** Shop settings. */
defined('ABSPATH') || exit;

function idev_store_settings_fields($tab) {
    $pages = ['' => __('— Use a simple page of the plugin —', 'idev-store')];
    foreach (get_pages(['post_status' => 'publish']) as $p) $pages[(string) $p->ID] = $p->post_title;
    $formats = idev_store_print_formats();
    $days = idev_weekdays(idev_lang());
    switch ($tab) {
        case 'print': return [
            ['receipt_format', __('Receipt / bill format', 'idev-store'), 'select', __('You can switch format on the print screen at any time.', 'idev-store'), $formats],
            ['job_format', __('Job ticket format', 'idev-store'), 'select', '', $formats],
            ['cont_width', __('Continuous form width (inches)', 'idev-store'), 'text', __('e.g. 9 or 9.5 (dot-matrix such as Epson LQ-590). Set the same paper size in the printer driver.', 'idev-store')],
            ['cont_height', __('Continuous form height (inches)', 'idev-store'), 'text', __('e.g. 5.5 (half of 11") or 11.', 'idev-store')],
            ['print_rx', __('Print the prescription on the job ticket', 'idev-store'), 'checkbox'],
            ['label_format', __('Drug label format', 'idev-store'), 'select', __('For pharmacies and clinics. A label printer (e.g. 80 × 50 mm stickers) or the 80 mm receipt printer.', 'idev-store'), ['label' => __('Label sticker', 'idev-store'), '80mm' => __('Receipt printer 80 mm', 'idev-store')]],
            ['label_w', __('Label width (mm)', 'idev-store'), 'number', '', [30, 120]],
            ['label_h', __('Label height (mm)', 'idev-store'), 'number', __('Set the same paper size in the label printer driver.', 'idev-store'), [20, 120]],
            ['footer', __('Text at the bottom of receipts', 'idev-store'), 'textarea', __('e.g. return policy, thank-you note.', 'idev-store')],
            ['prefix_bill', __('Bill number prefix', 'idev-store'), 'text', __('Numbers run per month: RC2610-0001', 'idev-store')],
            ['prefix_job', __('Job number prefix', 'idev-store'), 'text'],
        ];
        case 'pickup': return [
            ['status_page', __('Order status page', 'idev-store'), 'select', __('A page with the "Order status" block or [idev_job_status]. The QR on job tickets opens it.', 'idev-store'), $pages],
            ['pickup_days', __('Pick-up days', 'idev-store'), 'html', '', idev_store_days_html($days)],
            ['pickup_from', __('Pick-up from', 'idev-store'), 'text', 'HH:MM'],
            ['pickup_to', __('Pick-up until', 'idev-store'), 'text', 'HH:MM'],
            ['pickup_minutes', __('Minutes per pick-up slot', 'idev-store'), 'number', '', [10, 240]],
            ['pickup_capacity', __('Customers per slot', 'idev-store'), 'number', '', [1, 100]],
            ['pickup_ahead', __('Customers can book up to (days ahead)', 'idev-store'), 'number', '', [1, 90]],
            ['notify_email', __('E-mail the customer when the order is ready', 'idev-store'), 'checkbox'],
            ['staff_email', __('Staff e-mail for pick-up bookings', 'idev-store'), 'email'],
        ];
        default: return [
            ['profile', __('Type of business', 'idev-store'), 'select', __('Changes the job types, item fields and the prescription form.', 'idev-store'), idev_store_profiles()],
            ['shop_name', __('Shop / clinic name', 'idev-store'), 'text'],
            ['shop_name_en', __('Name (English)', 'idev-store'), 'text'],
            ['address', __('Address', 'idev-store'), 'textarea'],
            ['phone', __('Phone', 'idev-store'), 'text'],
            ['tax_id', __('Tax ID', 'idev-store'), 'text'],
            ['logo', __('Logo for receipts', 'idev-store'), 'image'],
            ['vat', __('VAT', 'idev-store'), 'select', '', ['none' => __('Not VAT registered', 'idev-store'), 'included' => __('Prices include VAT', 'idev-store'), 'excluded' => __('Add VAT to prices', 'idev-store')]],
            ['vat_rate', __('VAT rate (%)', 'idev-store'), 'text'],
            ['promptpay', __('PromptPay ID', 'idev-store'), 'text', __('Mobile number, national ID / tax ID (13 digits) or e-wallet ID. Shows a QR with the amount when taking payment.', 'idev-store')],
            ['pharmacist', __('Pharmacist on duty', 'idev-store'), 'text', __('Pharmacies and clinics: printed on drug labels and the ขย. books.', 'idev-store')],
            ['pharmacist_no', __('Pharmacist licence no.', 'idev-store'), 'text', __('e.g. ภ.12345', 'idev-store')],
            ['khy_license', __('Drugstore licence no.', 'idev-store'), 'text', __('Pharmacies: printed at the top of the ขย. books.', 'idev-store')],
            ['allow_negative', __('Allow selling more than the stock', 'idev-store'), 'checkbox', __('Off = the sale is stopped when there is not enough stock.', 'idev-store')],
            ['expiry_days', __('Warn about expiry (days before)', 'idev-store'), 'number', '', [1, 730]],
            ['accent', __('Colour', 'idev-store'), 'color'],
        ];
    }
}
function idev_store_days_html($names) {
    $on = array_map('intval', explode(',', idev_store_settings()['pickup_days']));
    $o = '';
    foreach ($names as $i => $n) $o .= '<label style="margin-right:10px"><input type="checkbox" name="idev_store_days[]" value="' . ($i + 1) . '"' . checked(in_array($i + 1, $on, true), true, false) . '> ' . esc_html($n) . '</label>';
    return $o;
}

function idev_store_page_settings() {
    if (!current_user_can('manage_options')) return;
    $tab = in_array($_GET['tab'] ?? '', ['print', 'pickup'], true) ? $_GET['tab'] : 'general';
    $s = idev_store_settings();
    if (!empty($_POST['idev_store_settings']) && check_admin_referer('idev_store_settings_' . $tab)) {
        $s = idev_settings_sanitize(idev_store_settings_fields($tab), $_POST['idev_store_settings'], $s);
        if ($tab === 'pickup') $s['pickup_days'] = implode(',', array_map('intval', (array) ($_POST['idev_store_days'] ?? [])));
        foreach (['pickup_from', 'pickup_to'] as $k) if (!preg_match('/^\d{1,2}:\d{2}$/', $s[$k])) $s[$k] = idev_store_defaults()[$k];
        foreach (['vat_rate', 'cont_width', 'cont_height'] as $k) $s[$k] = (string) (float) $s[$k];
        $s['promptpay'] = preg_replace('/\D/', '', $s['promptpay']);
        update_option('idev_store_settings', $s, false);
        idev_store_settings_flush();
        $s = idev_store_settings();
        idev_store_notice(__('Saved.', 'idev-store'));
        if ($s['promptpay'] !== '' && idev_store_promptpay_payload($s['promptpay'], 1) === '') idev_store_notice(__('The PromptPay ID should be a 10-digit mobile number, a 13-digit ID or a 15-digit e-wallet ID.', 'idev-store'), 'warning');
    }
    idev_store_head(__('Shop settings', 'idev-store'));
    $tabs = ['general' => __('Shop', 'idev-store'), 'print' => __('Printing', 'idev-store'), 'pickup' => __('Order status & pick-up', 'idev-store')];
    echo '<nav class="nav-tab-wrapper">';
    foreach ($tabs as $k => $l) echo '<a class="nav-tab' . ($k === $tab ? ' nav-tab-active' : '') . '" href="' . esc_url(idev_store_url('idev-store-settings', ['tab' => $k])) . '">' . esc_html($l) . '</a>';
    echo '</nav><form method="post">';
    wp_nonce_field('idev_store_settings_' . $tab);
    idev_settings_table('idev_store_settings', idev_store_settings_fields($tab), $s);
    submit_button();
    echo '</form>';
    if ($tab === 'general' && $s['promptpay']) echo '<div class="idev-card ids-qr-test"><h3>' . esc_html__('Test PromptPay QR (1.00 THB)', 'idev-store') . '</h3>' . idev_store_promptpay_svg(1, 160) . '<p class="description">' . esc_html__('Scan with a banking app: it should show your account name and 1.00 THB. Do not pay.', 'idev-store') . '</p></div>';
    echo '<div class="idev-card"><h3>' . esc_html__('Staff accounts', 'idev-store') . '</h3><p>' . esc_html__('Users → Add New: role "Shop staff" can sell, take job orders, receive stock and see customers. "Shop manager" can also change items and prices, count stock, void bills and see reports.', 'idev-store') . '</p></div></div>';
}
