<?php
/** Public order status page: status timeline, balance, and pick-up booking when the order is ready. */
defined('ABSPATH') || exit;

add_action('init', function () {
    wp_register_style('idev-store-front', IDEV_STORE_URL . 'assets/front.css', [], IDEV_STORE_VERSION);
    wp_register_script('idev-store-front', IDEV_STORE_URL . 'assets/front.js', [], IDEV_STORE_VERSION, true);
    idev_register_block('idev/job-status', __('Order status', 'idev-store'), 'search', __('Customers check their order and book a pick-up time.', 'idev-store'), [], function () { return idev_store_status_view(); });
});
add_shortcode('idev_job_status', function () { return idev_store_status_view(); });

/** Lookup form → redirect to the job's own link. */
add_action('template_redirect', function () {
    if (!empty($_POST['idev_job_no']) && isset($_POST['idev_job_phone'])) {
        $job = idev_store_job_lookup(sanitize_text_field(wp_unslash($_POST['idev_job_no'])), sanitize_text_field(wp_unslash($_POST['idev_job_phone'])));
        if ($job) { wp_safe_redirect(idev_store_job_url($job)); exit; }
        $GLOBALS['idev_store_lookup_failed'] = true;
        return;
    }
    // A job link but no status page set up: show a simple page of our own.
    if (isset($_GET['idev_job']) && !idev_store_is_status_page()) {
        $page = (int) idev_store_settings()['status_page'];
        if ($page && get_post_status($page) === 'publish') { wp_safe_redirect(add_query_arg('idev_job', sanitize_key($_GET['idev_job']), get_permalink($page))); exit; }
        nocache_headers();
        echo '<!doctype html><html lang="' . esc_attr(idev_lang()) . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>' . esc_html(idev_store_settings()['shop_name']) . '</title>';
        wp_print_styles(['idev-store-front']);
        echo '</head><body class="idev-js-solo">' . idev_store_status_view();
        wp_print_scripts(['idev-store-front']);
        echo '</body></html>';
        exit;
    }
});
function idev_store_is_status_page() { $p = (int) idev_store_settings()['status_page']; return $p && is_page($p); }

function idev_store_status_view() {
    wp_enqueue_style('idev-store-front');
    $s = idev_store_settings();
    $token = sanitize_key($_GET['idev_job'] ?? '');
    $job = $token ? idev_store_job_by_token($token) : null;
    $o = '<div class="idev-js" style="--idev-js:' . esc_attr($s['accent']) . '">';
    if (!$job) {
        if ($token || !empty($GLOBALS['idev_store_lookup_failed'])) $o .= '<p class="idev-js-err">' . esc_html__('Order not found. Please check the order number and phone number.', 'idev-store') . '</p>';
        $o .= '<form method="post" class="idev-js-form"><h2>' . esc_html__('Check your order', 'idev-store') . '</h2><label>' . esc_html__('Order number (on your ticket)', 'idev-store') . '<input name="idev_job_no" required placeholder="JOB2610-0001" autocomplete="off"></label><label>' . esc_html__('Last 4 digits of your phone number', 'idev-store') . '<input name="idev_job_phone" required inputmode="numeric" pattern="[0-9]{4}" maxlength="4"></label><button>' . esc_html__('Check', 'idev-store') . '</button></form></div>';
        return $o;
    }
    $c = idev_store_customer((int) $job['customer_id']);
    $bill = $job['bill_id'] ? idev_store_bill((int) $job['bill_id']) : null;
    $st = idev_store_job_statuses();
    $kinds = idev_store_job_kinds();
    $o .= '<div class="idev-js-card"><div class="idev-js-head"><div><small>' . esc_html($s['shop_name']) . '</small><h2>' . esc_html(sprintf(__('Order %s', 'idev-store'), $job['no'])) . '</h2><p>' . esc_html(($kinds[$job['kind']] ?? '') . ($c ? ' · ' . $c['name'] : '')) . '</p></div><span class="idev-js-badge s-' . esc_attr($job['status']) . '">' . esc_html($st[$job['status']] ?? $job['status']) . '</span></div>';
    if ($job['status'] !== 'cancelled') {
        $steps = ['new', 'ordered', 'making', 'ready', 'done'];
        $at = array_search($job['status'], $steps, true);
        $o .= '<ol class="idev-js-steps">';
        foreach ($steps as $i => $k) $o .= '<li class="' . ($i < $at ? 'done' : ($i === $at ? 'now' : '')) . '"><span></span>' . esc_html($st[$k]) . '</li>';
        $o .= '</ol>';
    }
    $rows = [];
    if ($job['due_date'] && !in_array($job['status'], ['ready', 'done', 'cancelled'], true)) $rows[__('Expected ready', 'idev-store')] = idev_format_day($job['due_date'], null, true);
    if ($bill && $bill['balance'] > 0.004 && $job['status'] !== 'cancelled') $rows[__('Balance due on pick-up', 'idev-store')] = idev_store_money($bill['balance']);
    if ($job['pickup_date']) $rows[__('Pick-up', 'idev-store')] = idev_format_day($job['pickup_date'], null, true) . ' ' . $job['pickup_time'];
    if ($rows) { $o .= '<dl class="idev-js-dl">'; foreach ($rows as $k => $v) $o .= '<dt>' . esc_html($k) . '</dt><dd>' . esc_html($v) . '</dd>'; $o .= '</dl>'; }
    if ($job['status'] === 'ready') {
        wp_enqueue_script('idev-store-front');
        $cfg = ['api' => esc_url_raw(rest_url('idev-store/v1/pickup')), 'token' => $job['token'], 'booked' => $job['pickup_date'] ? [$job['pickup_date'], $job['pickup_time']] : null,
            't' => ['choose' => __('Choose a pick-up time', 'idev-store'), 'change' => __('Change pick-up time', 'idev-store'), 'none' => __('No pick-up times available online. Please call us.', 'idev-store'), 'ok' => __('Booked. See you then!', 'idev-store'), 'err' => __('Something went wrong. Please try again.', 'idev-store'), 'left' => __('%d left', 'idev-store')]];
        $o .= '<div class="idev-js-pick" data-cfg="' . esc_attr(wp_json_encode($cfg, JSON_UNESCAPED_UNICODE)) . '"></div>';
    }
    if ($job['status'] === 'done') $o .= '<p class="idev-js-ok">' . esc_html__('Picked up. Thank you!', 'idev-store') . '</p>';
    $o .= '<p class="idev-js-contact">' . esc_html($s['shop_name']) . ($s['phone'] ? ' · <a href="tel:' . esc_attr(preg_replace('/[^0-9+]/', '', $s['phone'])) . '">' . esc_html($s['phone']) . '</a>' : '') . ($s['address'] ? '<br>' . esc_html($s['address']) : '') . '</p>';
    return $o . '</div></div>';
}
