<?php
/** Admin menu, overview and the bills screen. */
defined('ABSPATH') || exit;

add_action('admin_menu', function () {
    if (!idev_store_can()) return;
    $ready = (int) (idev_store_job_counts()['ready'] ?? 0);
    add_menu_page(idev_store_brand(), defined('IDEV_PACKAGE') ? __('Sales & stock', 'idev-store') : __('Shop', 'idev-store'), 'idev_store', 'idev-store', 'idev_store_page_overview', defined('IDEV_PACKAGE') && IDEV_PACKAGE === 'pharmacy' ? 'dashicons-plus-alt' : 'dashicons-store', 6);
    add_submenu_page('idev-store', __('Today', 'idev-store'), __('Today', 'idev-store'), 'idev_store', 'idev-store', 'idev_store_page_overview');
    add_submenu_page('idev-store', __('Sell / dispense', 'idev-store'), __('Sell / dispense', 'idev-store'), 'idev_store', 'idev-store-pos', 'idev_store_page_pos');
    if (idev_store_jobs_enabled()) add_submenu_page('idev-store', __('Job orders', 'idev-store'), __('Job orders', 'idev-store') . ($ready ? ' <span class="awaiting-mod">' . $ready . '</span>' : ''), 'idev_store', 'idev-store-jobs', 'idev_store_page_jobs');
    add_submenu_page('idev-store', __('Bills', 'idev-store'), __('Bills', 'idev-store'), 'idev_store', 'idev-store-bills', 'idev_store_page_bills');
    add_submenu_page('idev-store', __('Stock', 'idev-store'), __('Stock', 'idev-store'), 'idev_store', 'idev-store-stock', 'idev_store_page_stock');
    add_submenu_page('idev-store', __('Customers', 'idev-store'), __('Customers', 'idev-store'), 'idev_store', 'idev-store-customers', 'idev_store_page_customers');
    add_submenu_page('idev-store', __('Reports', 'idev-store'), __('Reports', 'idev-store'), 'idev_store_manage', 'idev-store-reports', 'idev_store_page_reports');
    add_submenu_page('idev-store', __('Print design', 'idev-store'), __('Print design', 'idev-store'), 'manage_options', 'idev-store-docs', 'idev_store_page_docs');
    add_submenu_page('idev-store', __('Shop settings', 'idev-store'), __('Settings', 'idev-store'), 'manage_options', 'idev-store-settings', 'idev_store_page_settings');
});

add_action('admin_enqueue_scripts', function ($hook) {
    if (strpos((string) $hook, 'idev-store') === false) return;
    wp_enqueue_style('idev-store-admin', IDEV_STORE_URL . 'assets/admin.css', [], IDEV_STORE_VERSION);
});

/** Form posts are handled before any output so they can redirect (post → redirect → get). */
add_action('admin_init', function () {
    $page = sanitize_key($_GET['page'] ?? '');
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && strpos($page, 'idev-store') === 0 && !empty($_POST['idev_store_action'])) do_action('idev_store_post_' . $page);
});

/** Name of the system shown in the back office: the iDevApp package (I-Clinic, I-Drug …) or "Shop". */
function idev_store_brand() { return defined('IDEV_PACKAGE_NAME') ? IDEV_PACKAGE_NAME : __('Shop', 'idev-store'); }
/** Page header with the shop tabs; the caller closes the wrap with </div>. */
function idev_store_head($title, $subtitle = '') {
    $page = sanitize_key($_GET['page'] ?? 'idev-store'); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $tabs = ['idev-store' => __('Today', 'idev-store'), 'idev-store-pos' => __('Sell / dispense', 'idev-store')];
    if (idev_store_jobs_enabled()) $tabs['idev-store-jobs'] = __('Job orders', 'idev-store');
    $tabs += ['idev-store-bills' => __('Bills', 'idev-store'), 'idev-store-stock' => __('Stock', 'idev-store'), 'idev-store-customers' => __('Customers', 'idev-store')];
    if (current_user_can('idev_store_manage')) $tabs['idev-store-reports'] = __('Reports', 'idev-store');
    if (current_user_can('manage_options')) $tabs += ['idev-store-docs' => __('Print design', 'idev-store'), 'idev-store-settings' => __('Settings', 'idev-store')];
    $chip = idev_store_licensed() ? [__('Licensed', 'idev-store'), 'ok'] : [__('Trial', 'idev-store'), 'trial'];
    idev_page_open($title, $subtitle ?: idev_store_brand(), ['tabs' => $tabs, 'current' => $page, 'chip' => $chip, 'url' => function ($k) { return idev_store_url($k); },
        'icons' => ['idev-store' => 'home', 'idev-store-pos' => 'cart', 'idev-store-jobs' => 'wrench', 'idev-store-bills' => 'receipt', 'idev-store-stock' => 'box', 'idev-store-customers' => 'users', 'idev-store-reports' => 'chart', 'idev-store-docs' => 'palette', 'idev-store-settings' => 'gear']]);
}

/** Small helpers for the admin screens. */
function idev_store_notice($text, $type = 'success') { echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p>' . wp_kses_post($text) . '</p></div>'; }
function idev_store_flash() {
    $f = get_transient('idev_store_flash_' . get_current_user_id());
    if ($f) { delete_transient('idev_store_flash_' . get_current_user_id()); idev_store_notice($f[0], $f[1]); }
}
function idev_store_redirect($url, $msg = '', $type = 'success') {
    if ($msg !== '') set_transient('idev_store_flash_' . get_current_user_id(), [$msg, $type], 60);
    wp_safe_redirect($url);
    exit;
}
function idev_store_post_action($action) {
    if (($_POST['idev_store_action'] ?? '') !== $action) return false;
    if (!idev_store_can()) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-store'), 403);
    check_admin_referer('idev_store_' . $action);
    return true;
}
function idev_store_form_open($action, $extra = '') { return '<form method="post" ' . $extra . '>' . wp_nonce_field('idev_store_' . $action, '_wpnonce', true, false) . '<input type="hidden" name="idev_store_action" value="' . esc_attr($action) . '">'; }
function idev_store_status_badge($status, $labels = null) {
    $labels = $labels ?: idev_store_job_statuses();
    return '<span class="ids-badge s-' . esc_attr($status) . '">' . esc_html($labels[$status] ?? $status) . '</span>';
}
function idev_store_bill_statuses() { return ['open' => __('Balance due', 'idev-store'), 'paid' => __('Paid', 'idev-store'), 'void' => __('Void', 'idev-store')]; }

/* ---------- Today ---------- */

function idev_store_page_overview() {
    global $wpdb;
    $today = idev_today();
    $sales = (float) $wpdb->get_var($wpdb->prepare('SELECT COALESCE(SUM(amount),0) FROM ' . idev_store_t('payments') . ' WHERE void = 0 AND created_at BETWEEN %s AND %s', $today . ' 00:00:00', $today . ' 23:59:59'));
    $bills = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . idev_store_t('bills') . " WHERE status <> 'void' AND created_at BETWEEN %s AND %s", $today . ' 00:00:00', $today . ' 23:59:59'));
    $counts = idev_store_job_counts();
    $open = array_sum(array_intersect_key($counts, array_flip(['new', 'ordered', 'making'])));
    $pickups = idev_store_jobs(['pickup_date' => $today]);
    $low = idev_store_low_count();
    $exp = idev_store_expiring();
    idev_store_head(__('Today', 'idev-store'), idev_format_day($today, null, true, true));
    idev_store_flash();
    echo idev_store_trial_banner();
    echo '<div class="ids-quick"><a class="button button-primary button-hero" href="' . esc_url(idev_store_url('idev-store-pos')) . '">＋ ' . esc_html__('Sell / dispense', 'idev-store') . '</a>' . (idev_store_jobs_enabled() ? '<a class="button button-hero" href="' . esc_url(idev_store_url('idev-store-jobs', ['new' => 1])) . '">＋ ' . esc_html__('New job order', 'idev-store') . '</a>' : '') . '<a class="button button-hero" href="' . esc_url(idev_store_url('idev-store-stock', ['receive' => 1])) . '">＋ ' . esc_html__('Receive stock', 'idev-store') . '</a></div>';
    echo '<div class="ids-stats">';
    $stat = function ($label, $value, $url = '', $warn = false) { echo '<a class="ids-stat' . ($warn ? ' warn' : '') . '" href="' . esc_url($url ?: '#') . '"><small>' . esc_html($label) . '</small><b>' . esc_html($value) . '</b></a>'; };
    $stat(__('Received today', 'idev-store'), idev_store_money($sales), idev_store_url('idev-store-bills', ['from' => $today, 'to' => $today]));
    $stat(__('Bills today', 'idev-store'), (string) $bills, idev_store_url('idev-store-bills', ['from' => $today, 'to' => $today]));
    $stat(__('Jobs in progress', 'idev-store'), (string) $open, idev_store_url('idev-store-jobs', ['status' => 'open']));
    $stat(__('Ready, not picked up', 'idev-store'), (string) ($counts['ready'] ?? 0), idev_store_url('idev-store-jobs', ['status' => 'ready']), !empty($counts['ready']));
    $stat(__('Low stock', 'idev-store'), (string) $low, idev_store_url('idev-store-stock', ['low' => 1]), $low > 0);
    $stat(__('Expiring soon', 'idev-store'), (string) count($exp), idev_store_url('idev-store-reports', ['tab' => 'expiry']), count($exp) > 0);
    echo '</div><div class="ids-grid2"><div class="idev-card"><h2>' . esc_html__('Pick-ups today', 'idev-store') . '</h2>';
    if (!$pickups) echo '<p class="description">' . esc_html__('No pick-up appointments today.', 'idev-store') . '</p>';
    else { echo '<table class="widefat striped"><tbody>'; foreach ($pickups as $j) echo '<tr><td><b>' . esc_html($j['pickup_time']) . '</b></td><td><a href="' . esc_url(idev_store_url('idev-store-jobs', ['id' => $j['id']])) . '">' . esc_html($j['no']) . '</a></td><td>' . esc_html($j['customer_name']) . '</td><td>' . idev_store_status_badge($j['status']) . '</td></tr>'; echo '</tbody></table>'; }
    echo '</div><div class="idev-card"><h2>' . esc_html__('Ready to pick up', 'idev-store') . '</h2>';
    $ready = idev_store_jobs(['status' => 'ready', 'limit' => 15]);
    if (!$ready) echo '<p class="description">—</p>';
    else { echo '<table class="widefat striped"><tbody>'; foreach ($ready as $j) echo '<tr><td><a href="' . esc_url(idev_store_url('idev-store-jobs', ['id' => $j['id']])) . '">' . esc_html($j['no']) . '</a></td><td>' . esc_html($j['customer_name']) . '</td><td>' . esc_html($j['pickup_date'] ? idev_format_day($j['pickup_date']) . ' ' . $j['pickup_time'] : __('no time booked', 'idev-store')) . '</td></tr>'; echo '</tbody></table>'; }
    echo '</div></div></div>';
}

/* ---------- Bills ---------- */

add_action('idev_store_post_idev-store-bills', function () {
    if (idev_store_post_action('pay')) {
        $id = (int) $_POST['bill'];
        $r = idev_store_bill_pay($id, sanitize_key($_POST['method'] ?? 'cash'), $_POST['amount'] ?? 0, $_POST['received'] ?? null);
        idev_store_redirect(idev_store_url('idev-store-bills', ['id' => $id]), is_wp_error($r) ? $r->get_error_message() : __('Payment saved.', 'idev-store') . ' <a target="_blank" href="' . esc_url(idev_store_print_url('payment', $r) . '#print') . '">' . esc_html__('Print receipt', 'idev-store') . '</a>', is_wp_error($r) ? 'error' : 'success');
    }
    if (idev_store_post_action('void')) {
        if (!idev_store_can(true)) wp_die(esc_html__('Only a shop manager can void a bill.', 'idev-store'), 403);
        $id = (int) $_POST['bill'];
        $r = idev_store_bill_void($id, sanitize_text_field(wp_unslash($_POST['reason'] ?? '')));
        idev_store_redirect(idev_store_url('idev-store-bills', ['id' => $id]), is_wp_error($r) ? $r->get_error_message() : __('Bill voided. The items are back in stock.', 'idev-store'), is_wp_error($r) ? 'error' : 'success');
    }
});

function idev_store_page_bills() {
    if (!empty($_GET['id'])) { idev_store_bill_view((int) $_GET['id']); return; }
    $from = idev_is_valid_date($_GET['from'] ?? '') ? $_GET['from'] : idev_add_days(idev_today(), -6);
    $to = idev_is_valid_date($_GET['to'] ?? '') ? $_GET['to'] : idev_today();
    $status = sanitize_key($_GET['status'] ?? '');
    $q = sanitize_text_field(wp_unslash($_GET['q'] ?? ''));
    $bills = idev_store_bills(['from' => $from, 'to' => $to, 'status' => $status, 'q' => $q, 'limit' => 300]);
    idev_store_head(__('Bills', 'idev-store'));
    idev_store_flash();
    echo '<form class="ids-filter"><input type="hidden" name="page" value="idev-store-bills"><input type="date" name="from" value="' . esc_attr($from) . '"> – <input type="date" name="to" value="' . esc_attr($to) . '"> <select name="status"><option value="">' . esc_html__('All', 'idev-store') . '</option>';
    foreach (idev_store_bill_statuses() as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($status, $k, false) . '>' . esc_html($l) . '</option>';
    echo '</select> <input type="search" name="q" value="' . esc_attr($q) . '" placeholder="' . esc_attr__('Bill number', 'idev-store') . '"> <button class="button">' . esc_html__('Filter', 'idev-store') . '</button></form>';
    echo '<table class="widefat striped ids-table"><thead><tr><th>' . esc_html__('No.', 'idev-store') . '</th><th>' . esc_html__('Date', 'idev-store') . '</th><th>' . esc_html__('Customer', 'idev-store') . '</th><th class="r">' . esc_html__('Total', 'idev-store') . '</th><th class="r">' . esc_html__('Paid', 'idev-store') . '</th><th>' . esc_html__('Status', 'idev-store') . '</th></tr></thead><tbody>';
    $sum = 0;
    foreach ($bills as $b) {
        $c = idev_store_customer((int) $b['customer_id']);
        if ($b['status'] !== 'void') $sum += (float) $b['total'];
        echo '<tr><td><a href="' . esc_url(idev_store_url('idev-store-bills', ['id' => $b['id']])) . '"><b>' . esc_html($b['no']) . '</b></a>' . ((int) $b['job_id'] ? ' <span class="ids-tag">' . esc_html__('job', 'idev-store') . '</span>' : '') . '</td><td>' . esc_html(idev_store_doc_date($b['created_at'])) . '</td><td>' . esc_html($c['name'] ?? '—') . '</td><td class="r">' . esc_html(idev_store_money($b['total'], false)) . '</td><td class="r">' . esc_html(idev_store_money($b['paid'], false)) . '</td><td>' . idev_store_status_badge($b['status'], idev_store_bill_statuses()) . '</td></tr>';
    }
    if (!$bills) echo '<tr><td colspan="6">' . esc_html__('No bills.', 'idev-store') . '</td></tr>';
    echo '</tbody><tfoot><tr><th colspan="3">' . esc_html(sprintf(__('%d bills', 'idev-store'), count($bills))) . '</th><th class="r">' . esc_html(idev_store_money($sum)) . '</th><th colspan="2"></th></tr></tfoot></table></div>';
}

function idev_store_bill_view($id) {
    $b = idev_store_bill($id);
    if (!$b) { echo '<div class="wrap"><p>' . esc_html__('Bill not found.', 'idev-store') . '</p></div>'; return; }
    $methods = idev_store_pay_methods();
    idev_store_head(sprintf(__('Bill %s', 'idev-store'), $b['no']), idev_store_doc_date($b['created_at']));
    idev_store_flash();
    echo '<p><a href="' . esc_url(idev_store_url('idev-store-bills')) . '">← ' . esc_html__('All bills', 'idev-store') . '</a></p><div class="ids-grid2"><div class="idev-card">';
    echo '<h2>' . idev_store_status_badge($b['status'], idev_store_bill_statuses()) . ' ' . esc_html($b['customer'] ? idev_store_customer_label($b['customer']) : __('Walk-in customer', 'idev-store')) . '</h2>';
    if ((int) $b['job_id']) { $j = idev_store_job((int) $b['job_id']); if ($j) echo '<p>' . esc_html__('Job order', 'idev-store') . ': <a href="' . esc_url(idev_store_url('idev-store-jobs', ['id' => $j['id']])) . '">' . esc_html($j['no']) . '</a></p>'; }
    echo '<table class="widefat ids-table"><thead><tr><th>' . esc_html__('Item', 'idev-store') . '</th><th class="r">' . esc_html__('Qty', 'idev-store') . '</th><th class="r">' . esc_html__('Price', 'idev-store') . '</th><th class="r">' . esc_html__('Amount', 'idev-store') . '</th></tr></thead><tbody>';
    foreach ($b['lines'] as $l) echo '<tr><td>' . esc_html($l['name']) . ($l['lot_text'] ? '<br><small class="description">' . esc_html($l['lot_text']) . '</small>' : '') . '</td><td class="r">' . esc_html(idev_store_qty($l['qty'])) . '</td><td class="r">' . esc_html(idev_store_money($l['price'], false)) . ((float) $l['discount'] ? '<br><small>−' . esc_html(idev_store_money($l['discount'], false)) . '</small>' : '') . '</td><td class="r">' . esc_html(idev_store_money($l['total'], false)) . '</td></tr>';
    echo '</tbody><tfoot>';
    if ($b['discount'] > 0) echo '<tr><td colspan="3">' . esc_html__('Discount', 'idev-store') . '</td><td class="r">−' . esc_html(idev_store_money($b['discount'], false)) . '</td></tr>';
    if ($b['vat'] > 0) echo '<tr><td colspan="3">' . esc_html__('VAT', 'idev-store') . '</td><td class="r">' . esc_html(idev_store_money($b['vat'], false)) . '</td></tr>';
    echo '<tr><th colspan="3">' . esc_html__('Total', 'idev-store') . '</th><th class="r">' . esc_html(idev_store_money($b['total'])) . '</th></tr></tfoot></table>';
    echo '<p><a class="button" target="_blank" href="' . esc_url(idev_store_print_url('bill', $id)) . '">🖨 ' . esc_html__('Print bill / receipt', 'idev-store') . '</a>' . (idev_store_labels_on() && $b['status'] !== 'void' && idev_store_label_lines($b) ? ' <a class="button" target="_blank" href="' . esc_url(idev_store_print_url('label', $id)) . '">💊 ' . esc_html__('Print drug labels', 'idev-store') . '</a>' : '') . '</p>';
    if ($b['info']) {
        $f = ['buyer' => __('Buyer / patient', 'idev-store'), 'age' => __('Age', 'idev-store'), 'address' => __('Address', 'idev-store'), 'prescriber' => __('Prescriber', 'idev-store'), 'prescriber_place' => __('Prescriber address / workplace', 'idev-store')];
        echo '<h3>' . esc_html(!empty($b['info']['rx']) ? __('Sold on prescription (ขย.12)', 'idev-store') : __('Buyer details', 'idev-store')) . '</h3><table class="widefat"><tbody>';
        foreach ($f as $k => $l) if (!empty($b['info'][$k])) echo '<tr><th>' . esc_html($l) . '</th><td>' . nl2br(esc_html($b['info'][$k])) . '</td></tr>';
        echo '</tbody></table>';
    }
    if (idev_store_labels_on() && $b['status'] !== 'void') idev_store_bill_labels_box($b);
    echo '</div><div class="idev-card"><h2>' . esc_html__('Payments', 'idev-store') . '</h2>';
    if ($b['payments']) {
        echo '<table class="widefat striped"><tbody>';
        foreach ($b['payments'] as $p) echo '<tr' . ((int) $p['void'] ? ' class="ids-void"' : '') . '><td>' . esc_html($p['no']) . '</td><td>' . esc_html(idev_store_doc_date($p['created_at'])) . '</td><td>' . esc_html($methods[$p['method']] ?? $p['method']) . '</td><td class="r">' . esc_html(idev_store_money($p['amount'], false)) . '</td><td><a target="_blank" href="' . esc_url(idev_store_print_url('payment', (int) $p['id'])) . '">🖨</a></td></tr>';
        echo '</tbody></table>';
    } else echo '<p class="description">' . esc_html__('No payments yet.', 'idev-store') . '</p>';
    if ($b['status'] === 'open') {
        echo '<h3>' . esc_html(sprintf(__('Balance due: %s', 'idev-store'), idev_store_money($b['balance']))) . '</h3>' . idev_store_form_open('pay', 'class="ids-pay"') . '<input type="hidden" name="bill" value="' . (int) $id . '">';
        echo '<select name="method">'; foreach ($methods as $k => $l) echo '<option value="' . esc_attr($k) . '">' . esc_html($l) . '</option>'; echo '</select> ';
        echo '<input type="number" step="0.01" min="0" name="amount" value="' . esc_attr(number_format($b['balance'], 2, '.', '')) . '"> <input type="number" step="0.01" min="0" name="received" placeholder="' . esc_attr__('Cash received', 'idev-store') . '"> <button class="button button-primary">' . esc_html__('Receive payment', 'idev-store') . '</button></form>';
        if (idev_store_settings()['promptpay']) echo '<div class="ids-qr">' . idev_store_promptpay_svg($b['balance'], 170) . '<small>PromptPay ' . esc_html(idev_store_money($b['balance'])) . '</small></div>';
    }
    if ($b['status'] !== 'void' && idev_store_can(true)) {
        echo '<details class="ids-danger"><summary>' . esc_html__('Void this bill', 'idev-store') . '</summary>' . idev_store_form_open('void') . '<input type="hidden" name="bill" value="' . (int) $id . '"><p>' . esc_html__('Items go back into stock and the payments are cancelled. The bill number stays in the records.', 'idev-store') . '</p><input type="text" name="reason" required placeholder="' . esc_attr__('Reason', 'idev-store') . '" class="regular-text"> <button class="button" onclick="return confirm(\'' . esc_js(__('Void this bill?', 'idev-store')) . '\')">' . esc_html__('Void bill', 'idev-store') . '</button></form></details>';
    }
    echo '</div></div></div>';
}

/** Directions per line, editable after the sale, with a print button per label. */
function idev_store_bill_labels_box($b) {
    $lines = idev_store_label_lines($b);
    $ids = array_map(function ($x) { return (int) $x['line']['id']; }, $lines);
    echo '<details class="ids-labels"' . (isset($_GET['labels']) ? ' open' : '') . '><summary>' . esc_html__('Directions on the labels', 'idev-store') . '</summary>';
    foreach ($b['lines'] as $l) {
        $x = in_array((int) $l['id'], $ids, true) ? $lines[array_search((int) $l['id'], $ids, true)] : (idev_store_label_lines($b, (int) $l['id'])[0] ?? null);
        if (!$x) continue;
        echo idev_store_form_open('label', 'class="ids-lblform"') . '<input type="hidden" name="bill" value="' . (int) $b['id'] . '"><input type="hidden" name="line" value="' . (int) $l['id'] . '"><b>' . esc_html($l['name']) . '</b> × ' . esc_html(idev_store_qty($l['qty'])) . '<br>';
        echo '<textarea name="label[use]" rows="2" class="large-text" placeholder="' . esc_attr__('Directions', 'idev-store') . '">' . esc_textarea($x['use']) . '</textarea>';
        echo '<input name="label[ind]" value="' . esc_attr($x['ind']) . '" placeholder="' . esc_attr__('Indication', 'idev-store') . '" class="regular-text"> <input name="label[warn]" value="' . esc_attr($x['warn']) . '" placeholder="' . esc_attr__('Warning', 'idev-store') . '" class="regular-text">';
        echo '<p><button class="button">' . esc_html__('Save', 'idev-store') . '</button> <a class="button-link" target="_blank" href="' . esc_url(idev_store_print_url('label', (int) $b['id'], '', (int) $l['id'])) . '">💊 ' . esc_html__('Print this label', 'idev-store') . '</a></p></form>';
    }
    echo '</details>';
}
add_action('idev_store_post_idev-store-bills', function () {
    if (!idev_store_post_action('label')) return;
    $bill = (int) ($_POST['bill'] ?? 0);
    $b = idev_store_bill($bill);
    $line = (int) ($_POST['line'] ?? 0);
    if (!$b || !in_array($line, array_map('intval', array_column($b['lines'], 'id')), true)) wp_die('Not found', 404);
    idev_store_line_label_save($line, wp_unslash($_POST['label'] ?? []));
    idev_store_redirect(idev_store_url('idev-store-bills', ['id' => $bill, 'labels' => 1]), __('Label saved.', 'idev-store'));
});
