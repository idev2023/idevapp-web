<?php
/** Tables, roles, settings and small helpers. */
defined('ABSPATH') || exit;

function idev_store_t($name) { global $wpdb; return $wpdb->prefix . 'idev_store_' . $name; }

function idev_store_install() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $c = $wpdb->get_charset_collate();
    $money = 'decimal(12,2) NOT NULL DEFAULT 0';
    dbDelta('CREATE TABLE ' . idev_store_t('items') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  sku varchar(64) NOT NULL DEFAULT '',
  barcode varchar(64) NOT NULL DEFAULT '',
  name varchar(190) NOT NULL,
  name_en varchar(190) NOT NULL DEFAULT '',
  category varchar(64) NOT NULL DEFAULT '',
  unit varchar(24) NOT NULL DEFAULT '',
  kind varchar(16) NOT NULL DEFAULT 'product',
  track tinyint(1) NOT NULL DEFAULT 1,
  lots tinyint(1) NOT NULL DEFAULT 0,
  price $money,
  cost $money,
  min_qty decimal(12,2) NOT NULL DEFAULT 0,
  qty decimal(12,2) NOT NULL DEFAULT 0,
  attrs longtext NOT NULL,
  active tinyint(1) NOT NULL DEFAULT 1,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY sku (sku),
  KEY barcode (barcode),
  KEY category (category)
) $c;");
    dbDelta('CREATE TABLE ' . idev_store_t('lots') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  item_id bigint(20) unsigned NOT NULL,
  lot_no varchar(64) NOT NULL DEFAULT '',
  expiry date DEFAULT NULL,
  qty decimal(12,2) NOT NULL DEFAULT 0,
  cost $money,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY item_id (item_id)
) $c;");
    dbDelta('CREATE TABLE ' . idev_store_t('moves') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  item_id bigint(20) unsigned NOT NULL,
  lot_id bigint(20) unsigned NOT NULL DEFAULT 0,
  qty decimal(12,2) NOT NULL,
  balance decimal(12,2) NOT NULL DEFAULT 0,
  type varchar(16) NOT NULL,
  ref varchar(40) NOT NULL DEFAULT '',
  note varchar(255) NOT NULL DEFAULT '',
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY item_id (item_id),
  KEY ref (ref)
) $c;");
    dbDelta('CREATE TABLE ' . idev_store_t('customers') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  code varchar(24) NOT NULL DEFAULT '',
  name varchar(190) NOT NULL,
  phone varchar(32) NOT NULL DEFAULT '',
  email varchar(190) NOT NULL DEFAULT '',
  line_id varchar(64) NOT NULL DEFAULT '',
  hn varchar(32) NOT NULL DEFAULT '',
  birthdate date DEFAULT NULL,
  data longtext NOT NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY phone (phone),
  KEY name (name)
) $c;");
    dbDelta('CREATE TABLE ' . idev_store_t('bills') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  no varchar(32) NOT NULL,
  customer_id bigint(20) unsigned NOT NULL DEFAULT 0,
  job_id bigint(20) unsigned NOT NULL DEFAULT 0,
  status varchar(12) NOT NULL DEFAULT 'open',
  subtotal $money,
  discount $money,
  vat $money,
  total $money,
  paid $money,
  note varchar(255) NOT NULL DEFAULT '',
  info longtext,
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY no (no),
  KEY customer_id (customer_id),
  KEY created_at (created_at)
) $c;");
    dbDelta('CREATE TABLE ' . idev_store_t('lines') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  bill_id bigint(20) unsigned NOT NULL,
  item_id bigint(20) unsigned NOT NULL DEFAULT 0,
  name varchar(190) NOT NULL,
  qty decimal(12,2) NOT NULL DEFAULT 1,
  price $money,
  discount $money,
  total $money,
  info text NOT NULL,
  PRIMARY KEY  (id),
  KEY bill_id (bill_id),
  KEY item_id (item_id)
) $c;");
    dbDelta('CREATE TABLE ' . idev_store_t('payments') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  bill_id bigint(20) unsigned NOT NULL,
  no varchar(32) NOT NULL,
  method varchar(16) NOT NULL DEFAULT 'cash',
  amount $money,
  received $money,
  change_amount $money,
  void tinyint(1) NOT NULL DEFAULT 0,
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY bill_id (bill_id),
  KEY created_at (created_at)
) $c;");
    dbDelta('CREATE TABLE ' . idev_store_t('jobs') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  no varchar(32) NOT NULL,
  customer_id bigint(20) unsigned NOT NULL DEFAULT 0,
  bill_id bigint(20) unsigned NOT NULL DEFAULT 0,
  kind varchar(24) NOT NULL DEFAULT 'glasses',
  status varchar(16) NOT NULL DEFAULT 'new',
  due_date date DEFAULT NULL,
  pickup_date date DEFAULT NULL,
  pickup_time char(5) NOT NULL DEFAULT '',
  rx longtext NOT NULL,
  note text NOT NULL,
  token char(32) NOT NULL DEFAULT '',
  notified_at datetime DEFAULT NULL,
  log longtext NOT NULL,
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY no (no),
  KEY customer_id (customer_id),
  KEY status (status),
  KEY pickup_date (pickup_date)
) $c;");
    dbDelta('CREATE TABLE ' . idev_store_t('counters') . " (
  k varchar(40) NOT NULL,
  n bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (k)
) $c;");
    // 1.1.0: sale details (buyer / prescriber) on bills, for the ขย. books
    $bt = idev_store_t('bills');
    if (!in_array('info', (array) $wpdb->get_col("DESCRIBE $bt", 0), true)) $wpdb->query("ALTER TABLE $bt ADD COLUMN info longtext");
    if (!get_role('idev_store_staff')) add_role('idev_store_staff', __('Shop staff', 'idev-store'), ['read' => true, 'idev_store' => true]);
    if (!get_role('idev_store_manager')) add_role('idev_store_manager', __('Shop manager', 'idev-store'), ['read' => true, 'idev_store' => true, 'idev_store_manage' => true]);
    foreach (['administrator'] as $r) { $role = get_role($r); if ($role) { $role->add_cap('idev_store'); $role->add_cap('idev_store_manage'); } }
    update_option('idev_store_db', IDEV_STORE_VERSION, false);
}
add_action('plugins_loaded', function () { if (get_option('idev_store_db') !== IDEV_STORE_VERSION) idev_store_install(); });

add_action('init', function () {
    load_plugin_textdomain('idev-store', false, dirname(plugin_basename(IDEV_STORE_FILE)) . '/languages');
    idev_register_plugin('idev-store', ['name' => 'iDev Store', 'version' => IDEV_STORE_VERSION, 'description' => __('Stock, sales and dispensing, job orders and pick-up appointments for clinics, optical shops and pharmacies.', 'idev-store'), 'settings' => admin_url('admin.php?page=idev-store-settings'), 'docs' => 'https://idevapp.me/plugins/idev-store']);
});
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_STORE_FILE, admin_url('admin.php?page=idev-store-settings'), 'https://idevapp.me/plugins/idev-store'); });

/* ---------- Settings ---------- */

function idev_store_defaults() {
    return [
        'shop_name' => get_bloginfo('name'), 'shop_name_en' => '', 'address' => '', 'phone' => '', 'tax_id' => '', 'logo' => '', 'footer' => '',
        'profile' => 'optical', 'vat' => 'none', 'vat_rate' => '7', 'promptpay' => '',
        'receipt_format' => '80mm', 'job_format' => 'a5', 'cont_width' => '9', 'cont_height' => '5.5', 'print_rx' => '1',
        'prefix_bill' => 'RC', 'prefix_job' => 'JOB', 'allow_negative' => '0', 'expiry_days' => '90',
        'status_page' => '', 'pickup_days' => '1,2,3,4,5,6', 'pickup_from' => '10:00', 'pickup_to' => '18:00', 'pickup_minutes' => '30', 'pickup_capacity' => '3', 'pickup_ahead' => '14',
        'label_format' => 'label', 'label_w' => '80', 'label_h' => '50', 'pharmacist' => '', 'pharmacist_no' => '', 'khy_license' => '',
        'notify_email' => '1', 'staff_email' => get_option('admin_email'), 'accent' => '#1d3f8b',
    ];
}
function idev_store_settings() {
    if (empty($GLOBALS['idev_store_settings_cache'])) { $saved = get_option('idev_store_settings', []); $GLOBALS['idev_store_settings_cache'] = array_merge(idev_store_defaults(), is_array($saved) ? $saved : []); }
    return $GLOBALS['idev_store_settings_cache'];
}
function idev_store_settings_flush() { $GLOBALS['idev_store_settings_cache'] = null; }

/** Business type: the words and job kinds that suit it. */
function idev_store_profiles() {
    return [
        'optical' => __('Eye clinic / optical shop', 'idev-store'),
        'clinic' => __('Clinic', 'idev-store'),
        'pharmacy' => __('Pharmacy', 'idev-store'),
        'general' => __('Shop / service', 'idev-store'),
    ];
}
function idev_store_job_kinds() {
    $p = idev_store_settings()['profile'];
    $k = [
        'optical' => ['glasses' => __('Glasses', 'idev-store'), 'contact' => __('Contact lenses', 'idev-store'), 'repair' => __('Repair', 'idev-store'), 'other' => __('Other', 'idev-store')],
        'clinic' => ['order' => __('Order', 'idev-store'), 'device' => __('Medical device', 'idev-store'), 'other' => __('Other', 'idev-store')],
        'pharmacy' => ['order' => __('Medicine order', 'idev-store'), 'other' => __('Other', 'idev-store')],
        'general' => ['order' => __('Order', 'idev-store'), 'repair' => __('Repair', 'idev-store'), 'other' => __('Other', 'idev-store')],
    ];
    return $k[$p] ?? $k['general'];
}
function idev_store_job_statuses() {
    return [
        'new' => __('Received', 'idev-store'),
        'ordered' => __('Ordered from supplier', 'idev-store'),
        'making' => __('In progress', 'idev-store'),
        'ready' => __('Ready to pick up', 'idev-store'),
        'done' => __('Picked up', 'idev-store'),
        'cancelled' => __('Cancelled', 'idev-store'),
    ];
}
function idev_store_pay_methods() {
    return ['cash' => __('Cash', 'idev-store'), 'qr' => __('PromptPay QR / transfer', 'idev-store'), 'card' => __('Card', 'idev-store'), 'other' => __('Other', 'idev-store')];
}

/* ---------- Helpers ---------- */

function idev_store_now() { return current_time('mysql'); }
function idev_store_num($v) { return round((float) str_replace(',', '', (string) $v), 2); }
function idev_store_money($v, $symbol = true) { return ($symbol ? '฿' : '') . number_format((float) $v, 2); }
function idev_store_qty($v) { $v = (float) $v; return floor($v) == $v ? number_format($v) : rtrim(rtrim(number_format($v, 2), '0'), '.'); }

/** Running document number: RC2610-0001 (prefix + yymm + counter that restarts every month). */
function idev_store_next_no($prefix) {
    global $wpdb;
    $key = $prefix . wp_date('ym');
    $t = idev_store_t('counters');
    if (!$wpdb->query($wpdb->prepare("UPDATE $t SET n = n + 1 WHERE k = %s", $key))) {
        if ($wpdb->insert($t, ['k' => $key, 'n' => 1]) === false) $wpdb->query($wpdb->prepare("UPDATE $t SET n = n + 1 WHERE k = %s", $key));
    }
    $n = (int) $wpdb->get_var($wpdb->prepare("SELECT n FROM $t WHERE k = %s", $key));
    return $key . '-' . str_pad((string) $n, 4, '0', STR_PAD_LEFT);
}

/** Prescriptions and notes are health data: encrypted with the same key as the other iDev patient plugins. */
function idev_store_key() { return hash('sha256', 'idev-medreg|' . (defined('AUTH_KEY') ? AUTH_KEY : '') . '|' . (defined('SECURE_AUTH_KEY') ? SECURE_AUTH_KEY : ''), true); }
function idev_store_encrypt($plain) {
    if ($plain === '' || $plain === null) return '';
    if (function_exists('idev_medreg_encrypt')) return idev_medreg_encrypt($plain);
    $k = idev_store_key();
    $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
    return 'k1:' . substr(hash('sha256', 'idev-medreg-id|' . $k), 0, 8) . ':' . base64_encode($nonce . sodium_crypto_secretbox((string) $plain, $nonce, $k));
}
function idev_store_decrypt($cipher) {
    if ($cipher === '' || $cipher === null) return '';
    if (function_exists('idev_medreg_decrypt')) { $p = idev_medreg_decrypt($cipher); if ($p !== null) return $p; }
    if (!preg_match('/^k1:[0-9a-f]{8}:(.+)$/s', (string) $cipher, $m)) return null;
    $raw = base64_decode($m[1], true);
    if ($raw === false || strlen($raw) < 40) return null;
    $p = sodium_crypto_secretbox_open(substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), idev_store_key());
    return $p === false ? null : $p;
}
function idev_store_json_enc($data) { return idev_store_encrypt(wp_json_encode($data, JSON_UNESCAPED_UNICODE)); }
function idev_store_json_dec($cipher) { $p = idev_store_decrypt($cipher); $d = $p ? json_decode($p, true) : null; return is_array($d) ? $d : []; }

function idev_store_can($manage = false) { return current_user_can($manage ? 'idev_store_manage' : 'idev_store'); }
function idev_store_url($page, $args = []) { return add_query_arg($args, admin_url('admin.php?page=' . $page)); }
