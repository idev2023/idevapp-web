<?php
/** Customers: list, profile with job orders (prescription history) and bills. */
defined('ABSPATH') || exit;

add_action('idev_store_post_idev-store-customers', function () {
    if (!idev_store_post_action('save')) return;
    $id = (int) ($_POST['id'] ?? 0);
    $r = idev_store_customer_save(wp_unslash($_POST['c'] ?? []), $id);
    if (is_wp_error($r)) idev_store_redirect(idev_store_url('idev-store-customers', ['id' => $id ?: 'new']), $r->get_error_message(), 'error');
    idev_store_redirect(idev_store_url('idev-store-customers', ['id' => $r]), __('Customer saved.', 'idev-store'));
});

function idev_store_page_customers() {
    if (!empty($_GET['id'])) { idev_store_customer_page($_GET['id'] === 'new' ? 0 : (int) $_GET['id']); return; }
    $q = sanitize_text_field(wp_unslash($_GET['q'] ?? ''));
    $list = idev_store_customers($q, 200);
    idev_store_head(__('Customers', 'idev-store'));
    idev_store_flash();
    echo '<p><a class="button button-primary" href="' . esc_url(idev_store_url('idev-store-customers', ['id' => 'new'])) . '">＋ ' . esc_html__('New customer', 'idev-store') . '</a></p><form class="ids-filter"><input type="hidden" name="page" value="idev-store-customers"><input type="search" name="q" value="' . esc_attr($q) . '" placeholder="' . esc_attr__('Name, phone, HN, code', 'idev-store') . '"> <button class="button">' . esc_html__('Search', 'idev-store') . '</button></form>';
    echo '<table class="widefat striped ids-table"><thead><tr><th>' . esc_html__('Code', 'idev-store') . '</th><th>' . esc_html__('Name', 'idev-store') . '</th><th>' . esc_html__('Phone', 'idev-store') . '</th><th>HN</th><th>' . esc_html__('Since', 'idev-store') . '</th></tr></thead><tbody>';
    foreach ($list as $c) echo '<tr><td>' . esc_html($c['code']) . '</td><td><a href="' . esc_url(idev_store_url('idev-store-customers', ['id' => $c['id']])) . '"><b>' . esc_html($c['name']) . '</b></a></td><td>' . esc_html($c['phone']) . '</td><td>' . esc_html($c['hn']) . '</td><td>' . esc_html(idev_format_day(substr($c['created_at'], 0, 10))) . '</td></tr>';
    if (!$list) echo '<tr><td colspan="5">' . esc_html__('No customers.', 'idev-store') . '</td></tr>';
    echo '</tbody></table></div>';
}

function idev_store_customer_page($id) {
    $c = $id ? idev_store_customer($id) : null;
    if ($id && !$c) { echo '<div class="wrap"><p>' . esc_html__('Customer not found.', 'idev-store') . '</p></div>'; return; }
    $v = $c ?: ['name' => '', 'phone' => '', 'email' => '', 'line_id' => '', 'hn' => '', 'birthdate' => '', 'data' => [], 'code' => ''];
    idev_store_head($c ? $c['name'] : __('New customer', 'idev-store'), $c ? $c['code'] : '');
    idev_store_flash();
    echo '<p><a href="' . esc_url(idev_store_url('idev-store-customers')) . '">← ' . esc_html__('Customers', 'idev-store') . '</a></p><div class="ids-grid2"><div class="idev-card">' . idev_store_form_open('save') . '<input type="hidden" name="id" value="' . (int) $id . '"><table class="form-table ids-form">';
    $f = function ($label, $k, $type = 'text', $val = null) use ($v) { echo '<tr><th>' . esc_html($label) . '</th><td><input type="' . $type . '" name="c[' . $k . ']" value="' . esc_attr($val ?? ($v[$k] ?? '')) . '" class="regular-text"' . ($k === 'name' ? ' required' : '') . '></td></tr>'; };
    $f(__('Name', 'idev-store'), 'name'); $f(__('Phone', 'idev-store'), 'phone', 'tel'); $f(__('E-mail', 'idev-store'), 'email', 'email'); $f('LINE ID', 'line_id'); $f('HN', 'hn'); $f(__('Date of birth', 'idev-store'), 'birthdate', 'date');
    echo '<tr><th>' . esc_html__('Address', 'idev-store') . '</th><td><textarea name="c[address]" rows="2" class="large-text">' . esc_textarea($v['data']['address'] ?? '') . '</textarea></td></tr><tr><th>' . esc_html__('Notes', 'idev-store') . '</th><td><textarea name="c[note]" rows="3" class="large-text">' . esc_textarea($v['data']['note'] ?? '') . '</textarea><p class="description">' . esc_html__('Address and notes are stored encrypted.', 'idev-store') . '</p></td></tr></table><p><button class="button button-primary">' . esc_html__('Save', 'idev-store') . '</button></p></form></div>';
    if (!$c) { echo '</div></div>'; return; }
    echo '<div><div class="idev-card"><h3>' . esc_html__('Job orders', 'idev-store') . '</h3><p><a class="button" href="' . esc_url(idev_store_url('idev-store-jobs', ['new' => 1, 'customer' => $id])) . '">＋ ' . esc_html__('New job order', 'idev-store') . '</a></p>';
    $kinds = idev_store_job_kinds();
    foreach (idev_store_jobs(['customer_id' => $id, 'limit' => 50]) as $j) {
        $job = idev_store_job_row($j);
        echo '<div class="ids-hist"><a href="' . esc_url(idev_store_url('idev-store-jobs', ['id' => $j['id']])) . '"><b>' . esc_html($j['no']) . '</b></a> · ' . esc_html(idev_store_doc_date($j['created_at'])) . ' · ' . esc_html($kinds[$j['kind']] ?? $j['kind']) . ' ' . idev_store_status_badge($j['status']);
        if (idev_store_rx_has($job['rx'])) echo idev_store_rx_table($job['rx']);
        echo '</div>';
    }
    echo '</div><div class="idev-card"><h3>' . esc_html__('Bills', 'idev-store') . '</h3><table class="widefat striped"><tbody>';
    foreach (idev_store_bills(['customer_id' => $id, 'limit' => 50]) as $b) echo '<tr><td><a href="' . esc_url(idev_store_url('idev-store-bills', ['id' => $b['id']])) . '">' . esc_html($b['no']) . '</a></td><td>' . esc_html(idev_store_doc_date($b['created_at'])) . '</td><td class="r">' . esc_html(idev_store_money($b['total'], false)) . '</td><td>' . idev_store_status_badge($b['status'], idev_store_bill_statuses()) . '</td></tr>';
    echo '</tbody></table></div></div></div></div>';
}
