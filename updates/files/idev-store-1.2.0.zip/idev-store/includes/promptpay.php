<?php
/** PromptPay QR (EMVCo / Thai QR Payment): phone number, national ID / tax ID or e-wallet ID, with the amount. */
defined('ABSPATH') || exit;

function idev_store_crc16($data) {
    $crc = 0xFFFF;
    for ($i = 0, $n = strlen($data); $i < $n; $i++) {
        $crc ^= ord($data[$i]) << 8;
        for ($b = 0; $b < 8; $b++) $crc = ($crc & 0x8000) ? (($crc << 1) ^ 0x1021) & 0xFFFF : ($crc << 1) & 0xFFFF;
    }
    return strtoupper(str_pad(dechex($crc), 4, '0', STR_PAD_LEFT));
}
function idev_store_tlv($id, $value) { return $id . str_pad((string) strlen($value), 2, '0', STR_PAD_LEFT) . $value; }

/** Payload text for a PromptPay QR, or '' when the PromptPay ID is not valid. */
function idev_store_promptpay_payload($target, $amount = null) {
    $t = preg_replace('/\D/', '', (string) $target);
    if (strlen($t) === 10 && $t[0] === '0') $acc = idev_store_tlv('01', '0066' . substr($t, 1));      // mobile number
    elseif (strlen($t) === 13) $acc = idev_store_tlv('02', $t);                                       // national ID / tax ID
    elseif (strlen($t) === 15) $acc = idev_store_tlv('03', $t);                                       // e-wallet ID
    else return '';
    $amount = $amount !== null ? round((float) $amount, 2) : 0;
    $p = idev_store_tlv('00', '01') . idev_store_tlv('01', $amount > 0 ? '12' : '11')
        . idev_store_tlv('29', idev_store_tlv('00', 'A000000677010111') . $acc)
        . idev_store_tlv('53', '764') . ($amount > 0 ? idev_store_tlv('54', number_format($amount, 2, '.', '')) : '') . idev_store_tlv('58', 'TH');
    $p .= '6304';
    return $p . idev_store_crc16($p);
}
function idev_store_promptpay_svg($amount, $size = 200) {
    $payload = idev_store_promptpay_payload(idev_store_settings()['promptpay'], $amount);
    if ($payload === '') return '';
    idev_load_qr();
    return idev_qr_svg($payload, $size, 'M');
}
