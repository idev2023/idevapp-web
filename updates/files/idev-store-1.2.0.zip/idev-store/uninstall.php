<?php
// Shop data (stock, bills, customers, job orders) is kept on purpose: it is business and patient records.
defined('WP_UNINSTALL_PLUGIN') || exit;
