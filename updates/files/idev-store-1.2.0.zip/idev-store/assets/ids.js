/* iDev Store shared UI: API, item search (barcode friendly), customer picker, cart with totals. */
(function () {
  'use strict';
  function el(tag, attrs, kids) {
    var e = document.createElement(tag);
    for (var k in attrs || {}) {
      if (k === 'class') e.className = attrs[k];
      else if (k === 'text') e.textContent = attrs[k];
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), attrs[k]);
      else if (attrs[k] !== null && attrs[k] !== undefined && attrs[k] !== false) e.setAttribute(k, attrs[k]);
    }
    (kids || []).forEach(function (c) { if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  function money(n) { return (Math.round((+n || 0) * 100) / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function num(v) { v = parseFloat(String(v).replace(/,/g, '')); return isFinite(v) ? v : 0; }
  function api(cfg, path, opts) {
    opts = opts || {};
    var h = { 'X-WP-Nonce': cfg.nonce };
    if (opts.body && typeof opts.body !== 'string') { h['Content-Type'] = 'application/json'; opts.body = JSON.stringify(opts.body); }
    return fetch(cfg.api + path, { method: opts.method || 'GET', headers: h, body: opts.body, credentials: 'same-origin' }).then(function (r) {
      return r.json().then(function (j) { if (!r.ok) throw new Error((j && (j.error || j.message)) || cfg.t.error); return j; });
    });
  }
  function debounce(fn, ms) { var t; return function () { var a = arguments, s = this; clearTimeout(t); t = setTimeout(function () { fn.apply(s, a); }, ms); }; }

  /** Item search box: Enter adds exact barcode/SKU match (scanner) or the first result. */
  function itemSearch(cfg, onPick, kind) {
    var box = el('div', { class: 'ids-search' });
    var input = el('input', { type: 'search', placeholder: cfg.t.search, autocomplete: 'off', class: 'ids-search-in' });
    var list = el('div', { class: 'ids-results' });
    var results = [];
    function show(items) {
      results = items; list.innerHTML = '';
      if (!items.length) { if (input.value.trim()) list.appendChild(el('div', { class: 'ids-empty', text: cfg.t.noItems })); return; }
      items.forEach(function (it) {
        list.appendChild(el('button', { type: 'button', class: 'ids-result' + (it.track && it.qty <= 0 ? ' out' : ''), onclick: function () { pick(it); } }, [
          el('span', { class: 'n' }, [it.name, it.sku ? el('small', { text: ' ' + it.sku }) : null]),
          el('span', { class: 'q', text: it.track ? (it.qty + ' ' + (it.unit || '') + (it.low ? ' · ' + cfg.t.low : '')) : cfg.t.service }),
          el('span', { class: 'p', text: money(it.price) })
        ]));
      });
    }
    function pick(it) { onPick(it); input.value = ''; show([]); input.focus(); }
    var search = debounce(function () {
      var q = input.value.trim();
      if (!q) { show([]); return; }
      api(cfg, 'items?q=' + encodeURIComponent(q) + (kind ? '&kind=' + kind : '')).then(show).catch(function () {});
    }, 180);
    input.addEventListener('input', search);
    input.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter') return;
      e.preventDefault();
      var q = input.value.trim(); if (!q) return;
      api(cfg, 'items?code=' + encodeURIComponent(q)).then(function (r) {
        if (r.length) pick(r[0]); else if (results.length) pick(results[0]);
        else api(cfg, 'items?q=' + encodeURIComponent(q)).then(function (x) { if (x.length === 1) pick(x[0]); else show(x); });
      });
    });
    box.appendChild(input); box.appendChild(list);
    box.focus = function () { input.focus(); };
    return box;
  }

  /** Customer picker with quick add. state.customer = {id,label}|null */
  function customerPicker(cfg, state, onChange) {
    var wrap = el('div', { class: 'ids-cust' });
    function render() {
      wrap.innerHTML = '';
      wrap.appendChild(el('label', { class: 'ids-lbl', text: cfg.t.customer }));
      if (state.customer) {
        wrap.appendChild(el('div', { class: 'ids-chosen' }, [el('b', { text: state.customer.label }), el('button', { type: 'button', class: 'button-link', text: '✕', onclick: function () { state.customer = null; render(); onChange && onChange(); } })]));
        return;
      }
      var input = el('input', { type: 'search', placeholder: cfg.t.findCustomer, autocomplete: 'off' });
      var list = el('div', { class: 'ids-results small' });
      var find = debounce(function () {
        var q = input.value.trim(); list.innerHTML = '';
        if (q.length < 2) return;
        api(cfg, 'customers?q=' + encodeURIComponent(q)).then(function (cs) {
          list.innerHTML = '';
          cs.forEach(function (c) { list.appendChild(el('button', { type: 'button', class: 'ids-result', onclick: function () { state.customer = c; render(); onChange && onChange(); } }, [el('span', { class: 'n', text: c.label }), el('span', { class: 'q', text: c.hn ? 'HN ' + c.hn : c.code })])); });
          list.appendChild(el('button', { type: 'button', class: 'ids-result add', onclick: function () { addForm(q); } }, ['＋ ' + cfg.t.newCustomer + ': ' + q]));
        });
      }, 200);
      input.addEventListener('input', find);
      wrap.appendChild(input); wrap.appendChild(list);
      wrap.appendChild(el('button', { type: 'button', class: 'button-link ids-add-cust', text: '＋ ' + cfg.t.newCustomer, onclick: function () { addForm(''); } }));
    }
    function addForm(q) {
      wrap.innerHTML = '';
      var isPhone = /^[0-9+ -]{6,}$/.test(q);
      var n = el('input', { placeholder: cfg.t.name, value: isPhone ? '' : q }), p = el('input', { placeholder: cfg.t.phone, inputmode: 'tel', value: isPhone ? q : '' }), m = el('input', { placeholder: cfg.t.email, type: 'email' });
      var err = el('p', { class: 'ids-err' });
      wrap.appendChild(el('div', { class: 'ids-newcust' }, [el('label', { class: 'ids-lbl', text: cfg.t.newCustomer }), n, p, m, err,
        el('div', {}, [el('button', { type: 'button', class: 'button button-primary', text: cfg.t.save, onclick: function () {
          api(cfg, 'customers', { method: 'POST', body: { name: n.value, phone: p.value, email: m.value } }).then(function (r) { state.customer = r.customer; render(); onChange && onChange(); }).catch(function (e) { err.textContent = e.message; });
        } }), ' ', el('button', { type: 'button', class: 'button', text: cfg.t.cancel, onclick: render })])]));
      n.focus();
    }
    render();
    return wrap;
  }

  /** Totals with the shop's VAT mode. */
  function totals(cfg, lines, discount) {
    var sub = lines.reduce(function (s, l) { return s + Math.max(0, num(l.qty) * num(l.price) - num(l.discount)); }, 0);
    var net = Math.max(0, sub - num(discount)), vat = 0, total = net;
    if (cfg.vat === 'excluded') { vat = Math.round(net * cfg.vatRate) / 100; total = net + vat; }
    else if (cfg.vat === 'included') vat = Math.round(net * cfg.vatRate / (100 + cfg.vatRate) * 100) / 100;
    return { sub: sub, vat: vat, total: Math.round(total * 100) / 100 };
  }

  /** Editable cart table. lines: [{item_id,name,qty,price,discount,stock,track}] */
  function cart(cfg, lines, onChange) {
    var t = el('table', { class: 'ids-cart widefat' });
    function render() {
      t.innerHTML = '';
      t.appendChild(el('thead', {}, [el('tr', {}, [el('th', { text: '' }), el('th', { class: 'r', text: cfg.t.qty }), el('th', { class: 'r', text: cfg.t.price }), el('th', { class: 'r', text: cfg.t.discount }), el('th', { class: 'r', text: cfg.t.total }), el('th')])]));
      var tb = el('tbody');
      if (!lines.length) tb.appendChild(el('tr', {}, [el('td', { colspan: 6, class: 'ids-empty', text: cfg.t.cartEmpty })]));
      lines.forEach(function (l, i) {
        function inp(key, w) { return el('input', { type: 'number', step: key === 'qty' ? 'any' : '0.01', min: 0, value: l[key], style: 'width:' + w, oninput: function (e) { l[key] = num(e.target.value); upd(); }, onfocus: function (e) { e.target.select(); } }); }
        var tot = el('td', { class: 'r b' });
        function upd() { tot.textContent = money(num(l.qty) * num(l.price) - num(l.discount)); onChange(); }
        var warn = l.track && num(l.qty) > l.stock ? el('small', { class: 'ids-warn', text: ' (' + l.stock + ' ' + cfg.t.stock + ')' }) : null;
        tb.appendChild(el('tr', {}, [
          el('td', {}, [l.item_id ? document.createTextNode(l.name) : el('input', { value: l.name, placeholder: cfg.t.name, oninput: function (e) { l.name = e.target.value; } }), warn, cfg.lineExtra ? cfg.lineExtra(l, render) : null]),
          el('td', { class: 'r' }, [inp('qty', '64px')]), el('td', { class: 'r' }, [inp('price', '92px')]), el('td', { class: 'r' }, [inp('discount', '80px')]), tot,
          el('td', {}, [el('button', { type: 'button', class: 'button-link ids-x', title: cfg.t.remove, text: '✕', onclick: function () { lines.splice(i, 1); render(); onChange(); } })])
        ]));
        tot.textContent = money(num(l.qty) * num(l.price) - num(l.discount));
      });
      t.appendChild(tb);
    }
    t.add = function (it) {
      var ex = lines.find(function (l) { return l.item_id && l.item_id === it.id; });
      if (ex) ex.qty = num(ex.qty) + 1;
      else lines.push({ item_id: it.id, name: it.name, qty: 1, price: it.price, discount: 0, stock: it.qty, track: it.track, drug: it.drug || null, label: it.drug ? { use: it.drug.use || '', ind: it.drug.ind || '', warn: it.drug.warn || '' } : null });
      render(); onChange();
    };
    t.addFree = function () { lines.push({ item_id: 0, name: '', qty: 1, price: 0, discount: 0 }); render(); onChange(); };
    t.render = render;
    render();
    return t;
  }

  window.IDS = { el: el, money: money, num: num, api: api, itemSearch: itemSearch, customerPicker: customerPicker, cart: cart, totals: totals };
})();
