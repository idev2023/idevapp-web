/* iDev Store — new job order (customer, prescription, items, deposit). */
(function () {
  'use strict';
  var root = document.getElementById('ids-job');
  if (!root || !window.IDS) return;
  var I = window.IDS, el = I.el, cfg = JSON.parse(root.dataset.cfg), t = cfg.t, tj = cfg.tj;
  var state = { customer: cfg.customer || null, kind: Object.keys(cfg.kinds)[0], rx: { r: {}, l: {} }, due_date: cfg.due, lines: [], discount: 0, deposit: '', method: 'cash', received: '', note: '' };
  var sumBox, cartT;

  function field(label, input) { return el('label', { class: 'ids-field' }, [el('span', { text: label }), input]); }
  function rxGrid() {
    var f = cfg.rxFields, tb = el('tbody');
    var head = el('tr', {}, [el('th')].concat(Object.keys(f).map(function (k) { return el('th', { text: f[k] }); })));
    [['r', tj.right], ['l', tj.left]].forEach(function (e) {
      tb.appendChild(el('tr', {}, [el('th', { text: e[1] })].concat(Object.keys(f).map(function (k) {
        return el('td', {}, [el('input', { 'data-eye': e[0], 'data-k': k, value: state.rx[e[0]][k] || '', inputmode: k === 'va' ? 'text' : 'decimal', oninput: function (ev) { state.rx[e[0]][k] = ev.target.value; } })]);
      }))));
    });
    var copy = el('button', { type: 'button', class: 'button-link', text: tj.copyRx, onclick: function () {
      state.rx.l = Object.assign({}, state.rx.r);
      box.querySelectorAll('input[data-eye="l"]').forEach(function (i) { i.value = state.rx.l[i.dataset.k] || ''; });
    } });
    var more = el('div', { class: 'ids-rx-more' }, ['pd', 'pd_r', 'pd_l', 'seg'].map(function (k) { return el('label', {}, [k.toUpperCase().replace('_', ' ') + ' ', el('input', { size: 5, oninput: function (e) { state.rx[k] = e.target.value; } })]); }).concat([
      el('label', {}, [tj.lens + ' ', el('input', { oninput: function (e) { state.rx.lens = e.target.value; } })]),
      el('label', {}, [tj.examiner + ' ', el('input', { oninput: function (e) { state.rx.examiner = e.target.value; } })])
    ]));
    var box = el('div', {}, [el('table', { class: 'ids-rx' }, [el('thead', {}, [head]), tb]), copy, more,
      el('textarea', { rows: 2, class: 'large-text', placeholder: tj.rxNote, oninput: function (e) { state.rx.note = e.target.value; } })]);
    return box;
  }

  function sums() {
    var x = I.totals(cfg, state.lines, state.discount);
    var dep = Math.min(I.num(state.deposit), x.total);
    sumBox.innerHTML = '';
    var rows = [[t.subtotal, I.money(x.sub)]];
    if (cfg.vat !== 'none') rows.push([cfg.vat === 'included' ? t.vatIncl : t.vat, I.money(x.vat)]);
    rows.push([t.total, '฿' + I.money(x.total)], [tj.deposit, I.money(dep)], [tj.balance, '฿' + I.money(x.total - dep)]);
    sumBox.appendChild(el('table', { class: 'ids-sumt' }, rows.map(function (r, i) { return el('tr', { class: i === rows.length - 1 || r[0] === t.total ? 'big' : '' }, [el('td', { text: r[0] }), el('td', { class: 'r', text: r[1] })]); })));
  }

  function build() {
    root.innerHTML = '';
    var kind = el('select', { onchange: function (e) { state.kind = e.target.value; } });
    Object.keys(cfg.kinds).forEach(function (k) { kind.appendChild(el('option', { value: k, text: cfg.kinds[k] })); });
    cartT = I.cart(cfg, state.lines, sums);
    var search = I.itemSearch(cfg, function (it) { cartT.add(it); });
    sumBox = el('div', { class: 'ids-sum' });
    var methods = el('select', { onchange: function (e) { state.method = e.target.value; } });
    Object.keys(cfg.methods).forEach(function (k) { methods.appendChild(el('option', { value: k, text: cfg.methods[k] })); });
    var err = el('p', { class: 'ids-err' });
    var left = el('div', {}, [
      el('div', { class: 'idev-card' }, [I.customerPicker(cfg, state), el('div', { class: 'ids-row' }, [field(tj.kind, kind), field(tj.due, el('input', { type: 'date', value: state.due_date, oninput: function (e) { state.due_date = e.target.value; } }))])]),
      el('div', { class: 'idev-card' }, [el('h3', { text: cfg.optical ? tj.rx : tj.details }), cfg.optical ? rxGrid() : el('textarea', { rows: 4, class: 'large-text', oninput: function (e) { state.rx.note = e.target.value; } })]),
    ]);
    var right = el('div', {}, [
      el('div', { class: 'idev-card' }, [el('h3', { text: tj.items }), search, cartT, el('p', {}, [el('button', { type: 'button', class: 'button-link', text: '＋ ' + t.add + ' (' + t.name + ' / ' + t.price + ')', onclick: function () { cartT.addFree(); } })]),
        field(t.discount, el('input', { type: 'number', min: 0, step: '0.01', oninput: function (e) { state.discount = I.num(e.target.value); sums(); } })), sumBox]),
      el('div', { class: 'idev-card' }, [el('div', { class: 'ids-row' }, [field(tj.deposit, el('input', { type: 'number', min: 0, step: '0.01', oninput: function (e) { state.deposit = e.target.value; sums(); } })), field('', methods), field(t.received, el('input', { type: 'number', min: 0, step: '0.01', oninput: function (e) { state.received = e.target.value; } }))]),
        field(tj.note, el('textarea', { rows: 2, oninput: function (e) { state.note = e.target.value; } })), err,
        el('button', { type: 'submit', class: 'button button-primary button-hero', text: tj.save })])
    ]);
    root.appendChild(el('div', { class: 'ids-grid2' }, [left, right]));
    sums();
    document.getElementById('ids-jobform').addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target.tagName === 'INPUT') e.preventDefault(); });
    document.getElementById('ids-jobform').addEventListener('submit', function (e) {
      if (!state.customer) { e.preventDefault(); err.textContent = tj.needCustomer; window.scrollTo(0, 0); return; }
      document.getElementById('ids-payload').value = JSON.stringify({ customer_id: state.customer.id, kind: state.kind, rx: state.rx, due_date: state.due_date, lines: state.lines, discount: state.discount, deposit: state.deposit, method: state.method, received: state.received, note: state.note });
    });
  }
  build();
})();
