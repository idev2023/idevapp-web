(function () {
  document.querySelectorAll('.idev-js-pick').forEach(function (box) {
    var cfg = JSON.parse(box.dataset.cfg), days = [], day = null;
    function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
    function msg(text, cls) { var p = box.querySelector('.idev-js-msg') || box.appendChild(el('p', 'idev-js-msg')); p.className = 'idev-js-msg ' + cls; p.textContent = text; }
    function render() {
      box.innerHTML = '';
      box.appendChild(el('h3', '', cfg.booked ? cfg.t.change : cfg.t.choose));
      if (!days.length) { box.appendChild(el('p', '', cfg.t.none)); return; }
      var dr = box.appendChild(el('div', 'idev-js-days'));
      days.forEach(function (d) { var b = dr.appendChild(el('button', d === day ? 'on' : '', d.label)); b.type = 'button'; b.onclick = function () { day = d; render(); }; });
      var tr = box.appendChild(el('div', 'idev-js-times'));
      day.times.forEach(function (t) {
        var mine = cfg.booked && cfg.booked[0] === day.date && cfg.booked[1] === t.time;
        var b = tr.appendChild(el('button', mine ? 'on' : '', t.time)); b.type = 'button';
        b.appendChild(el('small', '', cfg.t.left.replace('%d', t.free)));
        b.disabled = t.free < 1 && !mine;
        b.onclick = function () { book(day.date, t.time, b); };
      });
    }
    function book(date, time, btn) {
      btn.disabled = true;
      var fd = new FormData(); fd.append('token', cfg.token); fd.append('date', date); fd.append('time', time);
      fetch(cfg.api, { method: 'POST', body: fd }).then(function (r) { return r.json(); }).then(function (j) {
        if (!j.ok) { msg(j.error || cfg.t.err, 'idev-js-err'); btn.disabled = false; return; }
        cfg.booked = [date, time]; load(function () { msg(cfg.t.ok + ' ' + day.label + ' ' + time, 'idev-js-ok'); });
      }).catch(function () { msg(cfg.t.err, 'idev-js-err'); btn.disabled = false; });
    }
    function load(done) {
      fetch(cfg.api + (cfg.api.indexOf('?') < 0 ? '?' : '&') + 'token=' + encodeURIComponent(cfg.token)).then(function (r) { return r.json(); }).then(function (d) {
        days = Array.isArray(d) ? d : [];
        day = days.find(function (x) { return cfg.booked && x.date === cfg.booked[0]; }) || days[0] || null;
        render(); if (done) done();
      }).catch(function () { msg(cfg.t.err, 'idev-js-err'); });
    }
    load();
  });
})();
