/* iDev Store — sell / dispense screen. */
(function () {
  'use strict';
  var root = document.getElementById('ids-pos');
  if (!root || !window.IDS) return;
  var I = window.IDS, el = I.el, cfg = JSON.parse(root.dataset.cfg), t = cfg.t;
  var state = { lines: [], customer: null, discount: 0, method: 'cash', received: '', note: '', info: {} };
  var search, cartT, sumBox, payBox, custBox, infoBox;

  /* ---- Drug label editor (pharmacy / clinic) ---- */
  if (cfg.labels) cfg.lineExtra = function (l, rerender) {
    if (!l.item_id || !l.drug) return null;
    l.label = l.label || { use: '', ind: '', warn: '' };
    var wrap = el('div', { class: 'ids-lbl-line' });
    var cls = l.drug.drug_class && cfg.classes[l.drug.drug_class];
    var sum = el('button', { type: 'button', class: 'button-link', onclick: function () { panel.hidden = !panel.hidden; } }, ['💊 ' + (l.label.use ? l.label.use.split('\n')[0] : t.setUse)]);
    var panel = el('div', { class: 'ids-lbl-edit', hidden: l.label.use ? true : null });
    var use = el('textarea', { rows: 2, placeholder: t.use, oninput: function (e) { l.label.use = e.target.value; sum.lastChild.textContent = '💊 ' + (l.label.use.split('\n')[0] || t.setUse); } });
    use.value = l.label.use;
    var B = cfg.builder, pick = { verb: 'take', n: '1', unit: Object.keys(B.units)[0], freq: '3', timing: 'after', periods: [] };
    function sel(key, opts) { var s = el('select', { onchange: function (e) { pick[key] = e.target.value; } }); Object.keys(opts).forEach(function (k) { s.appendChild(el('option', { value: k, text: opts[k], selected: pick[key] === k ? 'selected' : null })); }); return s; }
    var periods = el('span', { class: 'ids-periods' });
    Object.keys(B.periods).forEach(function (k) { periods.appendChild(el('label', {}, [el('input', { type: 'checkbox', onchange: function (e) { var i = pick.periods.indexOf(k); if (e.target.checked && i < 0) pick.periods.push(k); else if (!e.target.checked && i >= 0) pick.periods.splice(i, 1); } }), ' ' + B.periods[k]])); });
    function compose() {
      var order = Object.keys(B.periods);
      var txt = B.doseFmt.replace('{verb}', B.verbs[pick.verb]).replace('{amount}', pick.n).replace('{unit}', B.units[pick.unit]);
      txt = [txt, B.freqs[pick.freq], pick.timing ? B.timings[pick.timing] : '', pick.periods.sort(function (a, b) { return order.indexOf(a) - order.indexOf(b); }).map(function (k) { return B.periods[k]; }).join(' ')].filter(Boolean).join(' ');
      l.label.use = txt.replace(/\s+/g, ' ').trim(); use.value = l.label.use; use.dispatchEvent(new Event('input'));
    }
    panel.appendChild(el('div', { class: 'ids-builder' }, [sel('verb', B.verbs), el('input', { type: 'text', value: pick.n, size: 3, oninput: function (e) { pick.n = e.target.value; } }), sel('unit', B.units), sel('freq', B.freqs), sel('timing', B.timings), periods,
      el('button', { type: 'button', class: 'button button-small', text: '↓ ' + t.compose, onclick: compose })]));
    panel.appendChild(use);
    var ind = el('input', { value: l.label.ind, placeholder: t.ind, oninput: function (e) { l.label.ind = e.target.value; } });
    var warn = el('input', { value: l.label.warn, placeholder: t.warn, oninput: function (e) { l.label.warn = e.target.value; } });
    panel.appendChild(el('div', { class: 'ids-lbl-2' }, [ind, warn]));
    wrap.appendChild(el('div', {}, [cls ? el('span', { class: 'ids-tag' + (cfg.needBuyer.indexOf(l.drug.drug_class) >= 0 ? ' warn' : ''), text: cls }) : null, ' ', sum]));
    wrap.appendChild(panel);
    return wrap;
  };

  /* ---- Buyer / prescription (ขย.10, 11, 12) ---- */
  function needBuyer() { return cfg.pharmacy && state.lines.some(function (l) { return l.drug && cfg.needBuyer.indexOf(l.drug.drug_class) >= 0; }); }
  function renderInfo() {
    if (!infoBox) return;
    var old = infoBox.querySelector('details'), was = old && old.open;
    infoBox.innerHTML = '';
    if (!cfg.pharmacy) return;
    var need = needBuyer(), i = state.info;
    var det = el('details', { class: 'ids-info', open: was || need || i.rx || i.buyer ? 'open' : null });
    det.appendChild(el('summary', {}, [t.buyerTitle, need ? el('span', { class: 'ids-tag warn', text: t.required }) : null]));
    function f(key, ph, type) { var x = el(type === 'ta' ? 'textarea' : 'input', { placeholder: ph, rows: type === 'ta' ? 2 : null, oninput: function (e) { i[key] = e.target.value; } }); x.value = i[key] || ''; return x; }
    det.appendChild(f('buyer', t.buyer + (state.customer ? ' (' + state.customer.label + ')' : '')));
    det.appendChild(el('div', { class: 'ids-lbl-2' }, [f('age', t.age), f('address', t.address)]));
    var rxBox = el('div', { class: 'ids-rx', hidden: i.rx ? null : true }, [f('prescriber', t.prescriber), f('prescriber_place', t.prescriberPlace)]);
    det.appendChild(el('label', { class: 'ids-rxchk' }, [el('input', { type: 'checkbox', checked: i.rx ? 'checked' : null, onchange: function (e) { i.rx = e.target.checked ? 1 : 0; rxBox.hidden = !e.target.checked; } }), ' ' + t.rx]));
    det.appendChild(rxBox);
    infoBox.appendChild(det);
  }

  function layout() {
    root.innerHTML = '';
    search = I.itemSearch(cfg, function (it) { cartT.add(it); });
    cartT = I.cart(cfg, state.lines, refresh);
    custBox = I.customerPicker(cfg, state, function () { refreshPay(); renderInfo(); });
    infoBox = el('div');
    sumBox = el('div', { class: 'ids-sum' });
    payBox = el('div', { class: 'ids-paybox' });
    root.appendChild(el('div', { class: 'ids-pos' }, [
      el('div', { class: 'ids-pos-main idev-card' }, [search, cartT, el('p', {}, [el('button', { type: 'button', class: 'button-link', text: '＋ ' + t.add + ' (' + t.name + ' / ' + t.price + ')', onclick: function () { cartT.addFree(); } })])]),
      el('div', { class: 'ids-pos-side idev-card' }, [custBox, infoBox, sumBox, payBox])
    ]));
    refresh();
    search.focus();
  }

  function refresh() {
    var tt = I.totals(cfg, state.lines, state.discount);
    sumBox.innerHTML = '';
    var disc = el('input', { type: 'number', min: 0, step: '0.01', value: state.discount || '', placeholder: '0.00', oninput: function (e) { state.discount = I.num(e.target.value); refreshPay(); updSum(); } });
    var rows = el('table', { class: 'ids-sumt' });
    function updSum() {
      var x = I.totals(cfg, state.lines, state.discount);
      rows.innerHTML = '';
      rows.appendChild(el('tr', {}, [el('td', { text: t.subtotal }), el('td', { class: 'r', text: I.money(x.sub) })]));
      rows.appendChild(el('tr', {}, [el('td', { text: t.discount }), el('td', { class: 'r' }, [disc])]));
      if (cfg.vat !== 'none') rows.appendChild(el('tr', {}, [el('td', { text: cfg.vat === 'included' ? t.vatIncl : t.vat + ' ' + cfg.vatRate + '%' }), el('td', { class: 'r', text: I.money(x.vat) })]));
      rows.appendChild(el('tr', { class: 'big' }, [el('td', { text: t.total }), el('td', { class: 'r', text: '฿' + I.money(x.total) })]));
    }
    updSum();
    sumBox.appendChild(rows);
    refreshPay();
    renderInfo();
  }

  function refreshPay() {
    var tt = I.totals(cfg, state.lines, state.discount);
    payBox.innerHTML = '';
    var tabs = el('div', { class: 'ids-methods' });
    Object.keys(cfg.methods).forEach(function (k) { tabs.appendChild(el('button', { type: 'button', class: 'button' + (state.method === k ? ' button-primary' : ''), text: cfg.methods[k], onclick: function () { state.method = k; refreshPay(); } })); });
    payBox.appendChild(tabs);
    var change = el('div', { class: 'ids-change' });
    if (state.method === 'cash') {
      var rec = el('input', { type: 'number', min: 0, step: '0.01', class: 'ids-received', value: state.received, placeholder: I.money(tt.total), oninput: function (e) { state.received = e.target.value; showChange(); } });
      var quick = el('div', { class: 'ids-quickcash' });
      [tt.total, 100, 500, 1000].filter(function (v, i, a) { return v > 0 && (i === 0 || v > tt.total) && a.indexOf(v) === i; }).forEach(function (v) { quick.appendChild(el('button', { type: 'button', class: 'button', text: I.money(v), onclick: function () { state.received = v; rec.value = v; showChange(); } })); });
      payBox.appendChild(el('label', { class: 'ids-lbl', text: t.received })); payBox.appendChild(rec); payBox.appendChild(quick);
      payBox.appendChild(change);
      function showChange() { var r = I.num(state.received); change.textContent = r ? (r >= tt.total ? t.change + ' ฿' + I.money(r - tt.total) : t.notEnough) : ''; change.className = 'ids-change' + (r && r < tt.total ? ' bad' : ''); }
      showChange();
    } else if (state.method === 'qr' && cfg.promptpay && tt.total > 0) {
      var q = el('div', { class: 'ids-qr' }, [el('small', { text: t.scanQr })]);
      payBox.appendChild(q);
      I.api(cfg, 'promptpay?amount=' + tt.total).then(function (r) { var d = el('div'); d.innerHTML = r.svg; q.insertBefore(d.firstChild || d, q.firstChild); });
    }
    var go = el('button', { type: 'button', class: 'button button-primary button-hero ids-go', text: t.pay + ' (F9)', onclick: function () { save(true); } });
    go.disabled = !state.lines.length;
    payBox.appendChild(go);
    payBox.appendChild(el('button', { type: 'button', class: 'button-link ids-later', text: t.payLater, onclick: function () { save(false); }, disabled: !state.lines.length || !state.customer }));
  }

  var busy = false;
  function save(pay) {
    if (busy || !state.lines.length) return;
    var tt = I.totals(cfg, state.lines, state.discount);
    if (pay && state.method === 'cash' && state.received !== '' && I.num(state.received) < tt.total) { alertBox(t.notEnough); return; }
    if (needBuyer() && !(state.info.buyer || '').trim() && !state.customer) { alertBox(t.needBuyer); renderInfo(); return; }
    busy = true;
    var payments = pay ? [{ method: state.method, amount: tt.total, received: state.method === 'cash' ? (state.received === '' ? tt.total : state.received) : null }] : [];
    I.api(cfg, 'bills', { method: 'POST', body: { customer_id: state.customer ? state.customer.id : 0, lines: state.lines, discount: state.discount, payments: payments, info: state.info } }).then(function (r) {
      busy = false;
      var w = window.open(r.print + '#print', '_blank');
      root.innerHTML = '';
      root.appendChild(el('div', { class: 'idev-card ids-done' }, [
        el('h2', { text: t.done.replace('%s', r.no) }),
        r.change > 0 ? el('p', { class: 'ids-change big', text: t.change + ' ฿' + I.money(r.change) }) : null,
        el('p', {}, [el('a', { class: 'button', href: r.print, target: '_blank', text: '🖨 ' + t.reprint }), ' ', r.labels ? el('a', { class: 'button button-primary', href: r.labels + '#print', target: '_blank', text: '💊 ' + t.labels }) : null, r.labels ? ' ' : null, el('button', { type: 'button', class: 'button button-primary button-hero', text: t.next + ' (Enter)', onclick: reset })])
      ]));
      setTimeout(function () { root.querySelector('.button-hero').focus(); }, 50);
    }).catch(function (e) { busy = false; alertBox(e.message); });
  }
  function alertBox(msg) { var p = payBox.querySelector('.ids-err') || payBox.appendChild(el('p', { class: 'ids-err' })); p.textContent = msg; }
  function reset() { state = { lines: [], customer: null, discount: 0, method: 'cash', received: '', note: '', info: {} }; layout(); }
  document.addEventListener('keydown', function (e) { if (e.key === 'F9') { e.preventDefault(); save(true); } });
  layout();
})();
