<?php
defined('ABSPATH') || exit;

function idev_pn_settings() {
    $s = get_option('idev_popup_notice', []);
    return array_merge(['hide_hours' => '8', 'where' => 'all', 'color' => '#169c91', 'button_color' => '#169c91', 'delay' => '0'], is_array($s) ? $s : []);
}
function idev_pn_meta($id, $k) { return (string) get_post_meta($id, "_idev_{$k}", true); }

add_action('init', function () {
    load_plugin_textdomain('idev-popup-notice', false, dirname(plugin_basename(IDEV_PN_FILE)) . '/languages');
    register_post_type('idev_popup', [
        'labels' => ['name' => __('Popups', 'idev-popup-notice'), 'singular_name' => __('Popup', 'idev-popup-notice'), 'add_new' => __('Add popup', 'idev-popup-notice'), 'add_new_item' => __('Add popup', 'idev-popup-notice'), 'edit_item' => __('Edit popup', 'idev-popup-notice'), 'all_items' => __('Popups', 'idev-popup-notice'), 'not_found' => __('No popups yet', 'idev-popup-notice')],
        'public' => false, 'show_ui' => true, 'show_in_menu' => 'idevapp', 'supports' => ['title', 'thumbnail', 'page-attributes'], 'map_meta_cap' => true,
    ]);
    idev_register_plugin('idev-popup-notice', ['name' => 'iDev Popup Notice', 'version' => IDEV_PN_VERSION, 'description' => __('Important-notice popups with start and end times.', 'idev-popup-notice'), 'settings' => admin_url('edit.php?post_type=idev_popup'), 'docs' => 'https://idevapp.me/plugins/idev-popup-notice']);
});
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_PN_FILE, admin_url('edit.php?post_type=idev_popup&page=idev-pn-settings'), 'https://idevapp.me/plugins/idev-popup-notice'); });

/* ---------- Edit screen ---------- */

add_filter('enter_title_here', function ($t, $post) { return $post->post_type === 'idev_popup' ? __('Popup title (Thai)', 'idev-popup-notice') : $t; }, 10, 2);
add_action('add_meta_boxes_idev_popup', function () { add_meta_box('idev_pn_box', __('Popup content', 'idev-popup-notice'), 'idev_pn_box', 'idev_popup', 'normal', 'high'); });

/** Look of each popup (Word-like designer): [key => [label, [value => label], default]]. */
function idev_pn_layouts() {
    return [
        'size' => [__('Size', 'idev-popup-notice'), ['s' => __('Small', 'idev-popup-notice'), 'm' => __('Medium', 'idev-popup-notice'), 'l' => __('Large', 'idev-popup-notice'), 'xl' => __('Extra large', 'idev-popup-notice'), 'full' => __('Almost full screen', 'idev-popup-notice')], 'm'],
        'image' => [__('Picture (featured image)', 'idev-popup-notice'), ['top' => __('Above the text', 'idev-popup-notice'), 'left' => __('Left of the text', 'idev-popup-notice'), 'right' => __('Right of the text', 'idev-popup-notice'), 'bg' => __('Behind the text', 'idev-popup-notice'), 'poster' => __('Picture only (poster)', 'idev-popup-notice')], 'top'],
        'fit' => [__('Picture fit', 'idev-popup-notice'), ['contain' => __('Whole picture', 'idev-popup-notice'), 'cover' => __('Fill the space', 'idev-popup-notice')], 'contain'],
        'align' => [__('Text alignment', 'idev-popup-notice'), ['left' => __('Left', 'idev-popup-notice'), 'center' => __('Centre', 'idev-popup-notice')], 'left'],
        'theme' => [__('Colours', 'idev-popup-notice'), ['light' => __('White', 'idev-popup-notice'), 'tint' => __('Light brand colour', 'idev-popup-notice'), 'brand' => __('Brand colour', 'idev-popup-notice'), 'dark' => __('Dark', 'idev-popup-notice'), 'alert' => __('Urgent (red)', 'idev-popup-notice')], 'light'],
        'place' => [__('Position', 'idev-popup-notice'), ['center' => __('Centre of the screen', 'idev-popup-notice'), 'corner' => __('Bottom corner (small)', 'idev-popup-notice'), 'top' => __('Top of the screen', 'idev-popup-notice')], 'center'],
        'kicker' => [__('Small heading', 'idev-popup-notice'), ['show' => __('"Important notice"', 'idev-popup-notice'), 'hide' => __('None', 'idev-popup-notice')], 'show'],
    ];
}
function idev_pn_layout($id) {
    $out = [];
    foreach (idev_pn_layouts() as $k => $def) { $v = idev_pn_meta($id, 'l_' . $k); $out[$k] = isset($def[1][$v]) ? $v : $def[2]; }
    return $out;
}
function idev_pn_editor_settings($name) {
    return ['textarea_name' => $name, 'textarea_rows' => 10, 'media_buttons' => true, 'editor_height' => 220,
        'tinymce' => ['toolbar1' => 'formatselect,fontsizeselect,bold,italic,underline,forecolor,backcolor,removeformat', 'toolbar2' => 'alignleft,aligncenter,alignright,alignjustify,bullist,numlist,outdent,indent,link,unlink,hr,charmap,undo,redo', 'fontsize_formats' => '12px 14px 16px 18px 20px 24px 28px 32px 40px', 'block_formats' => 'Paragraph=p;Heading 2=h2;Heading 3=h3;Heading 4=h4', 'object_resizing' => 'img', 'wordpress_adv_hidden' => false],
        'quicktags' => true];
}

function idev_pn_box($post) {
    wp_nonce_field('idev_pn', 'idev_pn_nonce');
    $v = function ($k) use ($post) { return esc_attr(idev_pn_meta($post->ID, $k)); };
    $local = function ($k) use ($post) { $x = idev_pn_meta($post->ID, $k); return $x ? esc_attr(str_replace(' ', 'T', $x)) : ''; };
    $l = idev_pn_layout($post->ID);
    $s = idev_pn_settings();
    echo '<div class="idev-pn-designer"><div class="idev-pn-edit"><div class="idev-form"><label>' . esc_html__('Title (English)', 'idev-popup-notice') . '<input name="idev_pn[title_en]" value="' . $v('title_en') . '"></label></div>';
    echo '<p class="description">' . esc_html__('Write the message like in Word: headings, font size, colours, lists, pictures (Add Media). Click a picture to resize it by its corners or align it.', 'idev-popup-notice') . '</p>';
    echo '<h3 class="idev-pn-h">' . esc_html__('Message (Thai)', 'idev-popup-notice') . '</h3>';
    wp_editor(idev_pn_meta($post->ID, 'body'), 'idev_pn_body', idev_pn_editor_settings('idev_pn[body]'));
    echo '<details class="idev-pn-en"><summary>' . esc_html__('Message (English)', 'idev-popup-notice') . '</summary>';
    wp_editor(idev_pn_meta($post->ID, 'body_en'), 'idev_pn_body_en', idev_pn_editor_settings('idev_pn[body_en]'));
    echo '</details><div class="idev-form"><div class="idev-grid2"><label>' . esc_html__('Button text (Thai)', 'idev-popup-notice') . '<input name="idev_pn[link_text]" value="' . $v('link_text') . '"></label><label>' . esc_html__('Button text (English)', 'idev-popup-notice') . '<input name="idev_pn[link_text_en]" value="' . $v('link_text_en') . '"></label></div>';
    echo '<label>' . esc_html__('Button link', 'idev-popup-notice') . '<input name="idev_pn[link_url]" value="' . $v('link_url') . '" placeholder="https://… or /page"></label>';
    echo '<div class="idev-grid2"><label>' . esc_html__('Show from (empty = now)', 'idev-popup-notice') . '<input type="datetime-local" name="idev_pn[starts_at]" value="' . $local('starts_at') . '"></label><label>' . esc_html__('Show until (empty = no end)', 'idev-popup-notice') . '<input type="datetime-local" name="idev_pn[ends_at]" value="' . $local('ends_at') . '"></label></div>';
    echo '<p class="description">' . esc_html__('Image: "Featured image" box. Order: "Page attributes → Order" (smaller first). To pause, switch the popup to Draft. Times use the site time zone.', 'idev-popup-notice') . '</p></div></div>';
    echo '<aside class="idev-pn-side"><h3 class="idev-pn-h">' . esc_html__('Layout', 'idev-popup-notice') . '</h3><div class="idev-pn-opts">';
    foreach (idev_pn_layouts() as $k => $def) {
        echo '<label>' . esc_html($def[0]) . '<select name="idev_pn[l_' . esc_attr($k) . ']" data-l="' . esc_attr($k) . '">';
        foreach ($def[1] as $val => $lab) echo '<option value="' . esc_attr($val) . '"' . selected($l[$k], $val, false) . '>' . esc_html($lab) . '</option>';
        echo '</select></label>';
    }
    echo '</div><h3 class="idev-pn-h">' . esc_html__('Preview', 'idev-popup-notice') . '</h3><div class="idev-pn-stage" style="--idev-pn-color:' . esc_attr($s['color']) . ';--idev-pn-button:' . esc_attr($s['button_color']) . '"><div id="idev-pn-preview"></div></div>';
    echo '<p class="description">' . esc_html__('The preview follows your changes. The real size depends on the visitor\'s screen.', 'idev-popup-notice') . '</p></aside></div>';
}

add_action('admin_enqueue_scripts', function ($hook) {
    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== 'idev_popup' || !in_array($hook, ['post.php', 'post-new.php'], true)) return;
    wp_enqueue_style('idev-popup-notice', IDEV_PN_URL . 'assets/popup.css', [], IDEV_PN_VERSION);
    wp_enqueue_style('idev-pn-admin', IDEV_PN_URL . 'assets/admin.css', ['idev-popup-notice'], IDEV_PN_VERSION);
    wp_enqueue_script('idev-popup-notice', IDEV_PN_URL . 'assets/popup.js', [], IDEV_PN_VERSION, true);
    wp_enqueue_script('idev-pn-admin', IDEV_PN_URL . 'assets/admin.js', ['jquery', 'idev-popup-notice'], IDEV_PN_VERSION, true);
    wp_localize_script('idev-pn-admin', 'idevPnAdmin', ['kicker' => __('Important notice', 'idev-popup-notice'), 'close' => __('Close', 'idev-popup-notice')]);
});

add_action('save_post_idev_popup', function ($id) {
    if (!isset($_POST['idev_pn_nonce']) || !wp_verify_nonce(sanitize_key($_POST['idev_pn_nonce']), 'idev_pn')) return;
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $id)) return;
    $in = wp_unslash($_POST['idev_pn'] ?? []);
    foreach (['title_en', 'link_text', 'link_text_en'] as $k) update_post_meta($id, "_idev_{$k}", sanitize_text_field($in[$k] ?? ''));
    foreach (['body', 'body_en'] as $k) update_post_meta($id, "_idev_{$k}", wp_kses_post($in[$k] ?? ''));
    update_post_meta($id, '_idev_link_url', idev_safe_url($in['link_url'] ?? ''));
    foreach (['starts_at', 'ends_at'] as $k) { $x = str_replace('T', ' ', sanitize_text_field($in[$k] ?? '')); update_post_meta($id, "_idev_{$k}", preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $x) ? $x : ''); }
    foreach (idev_pn_layouts() as $k => $def) { $v = sanitize_key($in['l_' . $k] ?? ''); update_post_meta($id, '_idev_l_' . $k, isset($def[1][$v]) ? $v : $def[2]); }
});

/** Popups whose time window contains now. */
function idev_pn_active() {
    $now = (new DateTimeImmutable('now', wp_timezone()))->format('Y-m-d H:i');
    $out = [];
    foreach (get_posts(['post_type' => 'idev_popup', 'post_status' => 'publish', 'numberposts' => 30, 'orderby' => ['menu_order' => 'ASC', 'date' => 'DESC']]) as $p) {
        $a = idev_pn_meta($p->ID, 'starts_at'); $b = idev_pn_meta($p->ID, 'ends_at');
        if (($a !== '' && $a > $now) || ($b !== '' && $b <= $now)) continue;
        $out[] = $p;
    }
    return $out;
}

add_filter('manage_idev_popup_posts_columns', function ($c) { return ['cb' => $c['cb'], 'title' => __('Title', 'idev-popup-notice'), 'idev_when' => __('Shown', 'idev-popup-notice'), 'idev_live' => __('Now', 'idev-popup-notice'), 'idev_order' => __('Order', 'idev-popup-notice'), 'date' => $c['date']]; });
add_action('manage_idev_popup_posts_custom_column', function ($col, $id) {
    if ($col === 'idev_when') echo esc_html((idev_pn_meta($id, 'starts_at') ?: __('now', 'idev-popup-notice')) . ' → ' . (idev_pn_meta($id, 'ends_at') ?: __('no end', 'idev-popup-notice')));
    if ($col === 'idev_live') echo in_array($id, wp_list_pluck(idev_pn_active(), 'ID'), true) ? '<span style="color:#0a7d55;font-weight:600">● ' . esc_html__('Showing', 'idev-popup-notice') . '</span>' : '<span style="color:#8a8f98">' . esc_html__('Not showing', 'idev-popup-notice') . '</span>';
    if ($col === 'idev_order') echo (int) get_post_field('menu_order', $id);
}, 10, 2);

/* ---------- Settings ---------- */

add_action('admin_menu', function () {
    add_submenu_page('edit.php?post_type=idev_popup', __('Popup settings', 'idev-popup-notice'), __('Settings', 'idev-popup-notice'), 'manage_options', 'idev-pn-settings', 'idev_pn_settings_page');
    add_submenu_page('idevapp', __('Popup settings', 'idev-popup-notice'), __('Popup settings', 'idev-popup-notice'), 'manage_options', 'idev-pn-settings', 'idev_pn_settings_page');
}, 20);
function idev_pn_settings_page() {
    $fields = [
        ['where', __('Show on', 'idev-popup-notice'), 'select', '', ['all' => __('Every page', 'idev-popup-notice'), 'front' => __('Home page only', 'idev-popup-notice')]],
        ['hide_hours', __('After closing, hide for (hours)', 'idev-popup-notice'), 'number', __('A popup shows again once its text is changed.', 'idev-popup-notice'), [0, 720]],
        ['delay', __('Delay before showing (seconds)', 'idev-popup-notice'), 'number', '', [0, 60]],
        ['color', __('Heading colour', 'idev-popup-notice'), 'color'],
        ['button_color', __('Button colour', 'idev-popup-notice'), 'color'],
    ];
    $s = idev_pn_settings();
    if (isset($_POST['idev_popup_notice']) && check_admin_referer('idev_pn_settings')) { $s = idev_settings_sanitize($fields, $_POST['idev_popup_notice'], $s); update_option('idev_popup_notice', $s); echo '<div class="notice notice-success"><p>' . esc_html__('Saved.', 'idev-popup-notice') . '</p></div>'; }
    idev_admin_header(__('Popup settings', 'idev-popup-notice'));
    echo '<form method="post">';
    wp_nonce_field('idev_pn_settings');
    idev_settings_table('idev_popup_notice', $fields, $s);
    submit_button();
    echo '</form><p><a class="button button-primary" href="' . esc_url(admin_url('edit.php?post_type=idev_popup')) . '">' . esc_html__('Manage popups', 'idev-popup-notice') . '</a></p></div>';
}

/* ---------- Front end ---------- */

add_action('wp_footer', function () {
    if (is_admin()) return;
    $s = idev_pn_settings();
    if ($s['where'] === 'front' && !is_front_page()) return;
    if (!apply_filters('idev_popup_show', !idev_pn_form_page())) return;
    $items = [];
    foreach (idev_pn_active() as $p) {
        $title = idev_pick($p->post_title, idev_pn_meta($p->ID, 'title_en'));
        $body = idev_pick(idev_pn_meta($p->ID, 'body'), idev_pn_meta($p->ID, 'body_en'));
        if ($title === '' && trim($body) === '') continue;
        $items[] = ['id' => (string) $p->ID, 'title' => $title, 'body' => wpautop(wp_kses_post($body)), 'image' => (string) get_the_post_thumbnail_url($p, 'full'), 'linkText' => idev_pick(idev_pn_meta($p->ID, 'link_text'), idev_pn_meta($p->ID, 'link_text_en')), 'linkUrl' => idev_href(idev_pn_meta($p->ID, 'link_url')), 'layout' => idev_pn_layout($p->ID)];
    }
    if (!$items) return;
    wp_enqueue_style('idev-popup-notice', IDEV_PN_URL . 'assets/popup.css', [], IDEV_PN_VERSION);
    wp_enqueue_script('idev-popup-notice', IDEV_PN_URL . 'assets/popup.js', [], IDEV_PN_VERSION, true);
    echo '<style>:root{--idev-pn-color:' . esc_attr($s['color']) . ';--idev-pn-button:' . esc_attr($s['button_color']) . '}</style>';
    echo '<script type="application/json" id="idev-popups">' . wp_json_encode(['items' => $items, 'hide' => (int) $s['hide_hours'], 'delay' => (int) $s['delay'], 'kicker' => __('Important notice', 'idev-popup-notice'), 'close' => __('Close', 'idev-popup-notice'), 'next' => __('Next notice', 'idev-popup-notice')], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) . '</script>';
}, 5);

/* ---------- Import from Andaman Hub (once) ---------- */

function idev_pn_migrate() {
    global $wpdb;
    if (get_option('idev_pn_migrated')) return;
    $ids = $wpdb->get_col("SELECT ID FROM {$wpdb->posts} WHERE post_type='ah_popup'");
    if ($ids) {
        $list = implode(',', array_map('intval', $ids));
        $wpdb->query("UPDATE {$wpdb->posts} SET post_type='idev_popup' WHERE ID IN ({$list})");
        foreach (['title_en', 'body', 'body_en', 'link_text', 'link_text_en', 'link_url', 'starts_at', 'ends_at'] as $k) $wpdb->query($wpdb->prepare("INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) SELECT post_id, %s, meta_value FROM {$wpdb->postmeta} WHERE meta_key=%s AND post_id IN ({$list})", "_idev_{$k}", "ah_{$k}"));
    }
    update_option('idev_pn_migrated', 1, false);
}

/** Pages where people fill in a form (booking, registration, doctor portal): no popup in the way. */
function idev_pn_form_page() {
    if (!is_singular()) return false;
    $post = get_post();
    if (!$post) return false;
    foreach (['idev/booking', 'idev/patient-registration', 'idev/doctor-portal'] as $b) if (has_block($b, $post)) return true;
    foreach (['idev_booking', 'idev_patient_registration', 'idev_doctor_portal', 'andaman_registration'] as $sc) if (has_shortcode($post->post_content, $sc)) return true;
    return false;
}
