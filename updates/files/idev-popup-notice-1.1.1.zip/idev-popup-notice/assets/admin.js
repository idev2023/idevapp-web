/* Popup designer: live preview of the popup while editing (message, picture, layout). */
jQuery(function ($) {
  const box = document.getElementById('idev-pn-preview');
  if (!box || !window.idevPnHTML) return;
  const C = window.idevPnAdmin || {};
  const body = () => { const e = window.tinymce && tinymce.get('idev_pn_body'); return e && !e.isHidden() ? e.getContent() : $('#idev_pn_body').val() || ''; };
  const image = () => { const i = $('#postimagediv img').attr('src'); return i || ''; };
  function draw() {
    const layout = {};
    $('[data-l]').each(function () { layout[this.dataset.l] = this.value; });
    const p = { title: $('#title').val() || '', body: body(), image: image(), linkText: $('[name="idev_pn[link_text]"]').val(), linkUrl: $('[name="idev_pn[link_url]"]').val() ? '#' : '', layout };
    box.innerHTML = window.idevPnHTML(p, { kicker: C.kicker || 'Important notice', close: C.close || 'Close', next: '', count: 1 });
    box.parentNode.className = 'idev-pn-stage ' + layout.place;
  }
  let t; const later = () => { clearTimeout(t); t = setTimeout(draw, 150); };
  $(document).on('input change', '#title, [data-l], [name^="idev_pn["], #idev_pn_body', later);
  $(document).on('tinymce-editor-init', (e, ed) => { if (ed.id === 'idev_pn_body') ed.on('input change keyup NodeChange SetContent', later); });
  new MutationObserver(later).observe(document.getElementById('postimagediv') || document.body, { childList: true, subtree: true });
  setTimeout(draw, 300);
});
