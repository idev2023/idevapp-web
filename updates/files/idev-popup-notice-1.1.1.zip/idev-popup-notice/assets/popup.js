/* Shows active popups one at a time; a closed popup stays hidden for the configured hours (until its text changes).
   If a cookie banner is waiting for an answer (iDev Cookie Consent), popups wait until it is answered. */
/* One popup as HTML (also used by the designer preview in the admin). */
window.idevPnHTML = function (p, o) {
  const esc = (s) => String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const L = Object.assign({ size: 'm', image: 'top', fit: 'contain', align: 'left', theme: 'light', place: 'center', kicker: 'show' }, p.layout || {});
  const img = p.image ? `<div class="idev-pn-img"><img src="${esc(p.image)}" alt=""></div>` : '';
  const poster = L.image === 'poster' && p.image;
  const btn = p.linkUrl && p.linkText ? `<a href="${esc(p.linkUrl)}">${esc(p.linkText)}</a>` : '';
  const next = o.count > 1 ? `<button type="button" class="idev-pn-next">${esc(o.next)} (${o.count - 1}) →</button>` : '';
  const kick = L.kicker !== 'hide' ? `<span class="idev-pn-kicker">${esc(o.kicker)}${o.count > 1 ? ` · 1/${o.count}` : ''}</span>` : '';
  const cls = ['idev-pn', 'size-' + L.size, 'img-' + (p.image ? L.image : 'none'), 'fit-' + L.fit, 'align-' + L.align, 'theme-' + L.theme].join(' ');
  const body = poster
    ? `<h2 class="idev-pn-sr" id="idev-pn-title">${esc(p.title)}</h2>${p.linkUrl ? `<a class="idev-pn-posterlink" href="${esc(p.linkUrl)}">${img}</a>` : img}${next ? `<div class="idev-pn-actions idev-pn-posteract">${next}</div>` : ''}`
    : `${L.image !== 'bg' ? img : ''}<div class="idev-pn-body">${kick}${p.title ? `<h2 id="idev-pn-title">${esc(p.title)}</h2>` : ''}<div class="idev-pn-text">${p.body || ''}</div>${btn || next ? `<div class="idev-pn-actions">${btn}${next}</div>` : ''}</div>`;
  const bg = L.image === 'bg' && p.image && !poster ? ` style="--idev-pn-bg:url('${esc(p.image)}')"` : '';
  return `<section class="${cls}"${bg} role="dialog" aria-modal="true" aria-labelledby="idev-pn-title"><button type="button" class="idev-pn-close" aria-label="${esc(o.close)}">×</button>${body}</section>`;
};
(function () {
  const src = document.getElementById('idev-popups');
  if (!src) return;
  let cfg; try { cfg = JSON.parse(src.textContent); } catch (e) { return; }
  const KEY = 'idev-popups-dismissed', HIDE = Math.max(0, cfg.hide) * 3600 * 1000;
  const sig = (p) => `${p.id}|${p.title}|${p.body}|${p.image}`.slice(0, 400);
  const read = () => { try { const v = JSON.parse(localStorage.getItem(KEY) || '{}'); return v && typeof v === 'object' ? v : {}; } catch (e) { return {}; } };
  const esc = (s) => String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const store = read();
  let queue = cfg.items.filter((p) => Date.now() - Number(store[sig(p)] || 0) > HIDE);
  let box = null, lastFocus = null;
  function close() {
    const cur = queue[0]; if (!cur) return;
    const s = read(); s[sig(cur)] = Date.now();
    Object.keys(s).forEach((k) => { if (Date.now() - Number(s[k]) > Math.max(HIDE, 864e5)) delete s[k]; });
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* private mode */ }
    queue = queue.slice(1); render();
  }
  function onKey(e) { if (e.key === 'Escape') close(); }
  function render() {
    if (box) box.remove(); box = null;
    const p = queue[0];
    if (!p) { document.removeEventListener('keydown', onKey); if (lastFocus) lastFocus.focus(); return; }
    box = document.createElement('div');
    const L = p.layout || {};
    box.className = 'idev-pn-backdrop place-' + (L.place || 'center');
    box.innerHTML = window.idevPnHTML(p, { kicker: cfg.kicker, close: cfg.close, next: cfg.next, count: queue.length });
    box.addEventListener('mousedown', (e) => { if (e.target === box && (L.place || 'center') === 'center') close(); });
    box.querySelector('.idev-pn-close').addEventListener('click', close);
    const n = box.querySelector('.idev-pn-next'); if (n) n.addEventListener('click', close);
    document.body.appendChild(box);
    box.querySelector('.idev-pn-close').focus();
  }
  function start() { if (!queue.length) return; lastFocus = document.activeElement; document.addEventListener('keydown', onKey); setTimeout(render, Math.max(0, cfg.delay) * 1000); }
  if (window.idevConsentPending) document.addEventListener('idev:consent', start, { once: true }); else start();
})();
