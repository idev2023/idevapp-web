<?php
defined('ABSPATH') || exit;
get_header();
?>
<header class="app-bar">
  <a class="back" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php esc_attr_e('Home', 'idev-app'); ?>">‹</a>
  <h1><?php echo esc_html(is_singular() ? get_the_title() : (is_search() ? sprintf(__('Search: %s', 'idev-app'), get_search_query()) : wp_strip_all_tags(get_the_archive_title() ?: get_bloginfo('name')))); ?></h1>
</header>
<main class="app-page">
<?php if (is_singular()) : while (have_posts()) : the_post(); ?>
  <article <?php post_class('card page-card'); ?>><?php the_content(); wp_link_pages(); ?></article>
<?php endwhile; elseif (have_posts()) : ?>
  <div class="list">
  <?php while (have_posts()) : the_post(); ?>
    <a class="card row" href="<?php the_permalink(); ?>"><?php if (has_post_thumbnail()) the_post_thumbnail('thumbnail'); ?><span><b><?php the_title(); ?></b><small><?php echo esc_html(get_the_date()); ?></small></span><span class="go">›</span></a>
  <?php endwhile; ?>
  </div>
  <?php the_posts_pagination(); ?>
<?php else : ?>
  <section class="card empty"><p><?php esc_html_e('Nothing here yet.', 'idev-app'); ?></p><a class="btn" href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Back to home', 'idev-app'); ?></a></section>
<?php endif; ?>
</main>
<?php get_footer(); ?>
