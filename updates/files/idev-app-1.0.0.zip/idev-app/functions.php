<?php
/** iDev App theme: an app-like front end for the iDevApp clinic systems. */
defined('ABSPATH') || exit;

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('custom-logo', ['height' => 96, 'width' => 96, 'flex-width' => true, 'flex-height' => true]);
    add_theme_support('html5', ['search-form', 'gallery', 'caption', 'style', 'script']);
    add_theme_support('responsive-embeds');
    load_theme_textdomain('idev-app', get_template_directory() . '/languages');
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('idev-app-font', 'https://fonts.googleapis.com/css2?family=Anuphan:wght@400;500;600;700&display=swap', [], null);
    wp_enqueue_style('idev-app', get_template_directory_uri() . '/assets/app.css', [], wp_get_theme()->get('Version'));
    $accent = sanitize_hex_color(get_theme_mod('idev_app_accent', '#0f766e')) ?: '#0f766e';
    wp_add_inline_style('idev-app', ':root{--acc:' . $accent . '}');
});

/* Customizer: colour and the welcome line. */
add_action('customize_register', function ($c) {
    $c->add_section('idev_app', ['title' => __('iDev App', 'idev-app'), 'priority' => 30]);
    $c->add_setting('idev_app_accent', ['default' => '#0f766e', 'sanitize_callback' => 'sanitize_hex_color']);
    $c->add_control(new WP_Customize_Color_Control($c, 'idev_app_accent', ['label' => __('Main colour', 'idev-app'), 'section' => 'idev_app']));
    $c->add_setting('idev_app_welcome', ['default' => '', 'sanitize_callback' => 'sanitize_text_field']);
    $c->add_control('idev_app_welcome', ['label' => __('Welcome line on the home screen', 'idev-app'), 'section' => 'idev_app', 'type' => 'text']);
    $c->add_setting('idev_app_staff', ['default' => '1', 'sanitize_callback' => function ($v) { return $v ? '1' : ''; }]);
    $c->add_control('idev_app_staff', ['label' => __('Show the staff sign-in button', 'idev-app'), 'section' => 'idev_app', 'type' => 'checkbox']);
});

/** Clinic details from the clinic system's settings (or the site). */
function idev_app_info() {
    $s = function_exists('idev_store_settings') ? idev_store_settings() : [];
    $name = trim((string) ($s['shop_name'] ?? '')) ?: get_bloginfo('name');
    $logo = has_custom_logo() ? wp_get_attachment_image_url(get_theme_mod('custom_logo'), 'medium') : (string) ($s['logo'] ?? '');
    return ['name' => $name, 'logo' => $logo, 'phone' => (string) ($s['phone'] ?? ''), 'address' => (string) ($s['address'] ?? ''), 'tagline' => get_bloginfo('description')];
}

/** Find a published page that contains a shortcode / block. */
function idev_app_page_with($needles) {
    global $wpdb;
    foreach ((array) $needles as $n) {
        $id = (int) $wpdb->get_var($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status = 'publish' AND post_content LIKE %s ORDER BY menu_order, ID LIMIT 1", '%' . $wpdb->esc_like($n) . '%'));
        if ($id) return get_permalink($id);
    }
    return '';
}

/** The big buttons of the home screen: [key, title, subtitle, url, icon, tone]. */
function idev_app_tiles() {
    $i = idev_app_info();
    $book = function_exists('idev_appt_booking_url') ? idev_appt_booking_url() : '';
    if (!$book) $book = idev_app_page_with(['[idev_booking', 'wp:idev/booking']);
    $reg = function_exists('idev_appt_register_url') ? idev_appt_register_url() : '';
    if (!$reg) $reg = idev_app_page_with(['[idev_patient_registration', 'wp:idev/patient-registration']);
    $sched = function_exists('idev_cs_schedule_url') ? idev_cs_schedule_url() : '';
    if (!$sched || $sched === home_url('/')) $sched = idev_app_page_with(['[idev_schedule', '[idev_doctors', 'wp:idev/schedule', 'wp:idev/doctors']);
    $map = $i['address'] !== '' ? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($i['name'] . ' ' . $i['address']) : '';
    $tiles = [];
    if ($book) $tiles[] = ['book', __('Book an appointment', 'idev-app'), __('Choose a doctor, a day and a time', 'idev-app'), $book, 'calendar', 'a'];
    if ($reg) $tiles[] = ['reg', __('New patient registration', 'idev-app'), __('Register before your visit, get your HN', 'idev-app'), $reg, 'idcard', 'b'];
    if ($sched) $tiles[] = ['sched', __('Doctors\' schedule', 'idev-app'), __('Who works when', 'idev-app'), $sched, 'stethoscope', 'c'];
    if ($i['phone'] !== '') $tiles[] = ['call', __('Call the clinic', 'idev-app'), $i['phone'], 'tel:' . preg_replace('/[^0-9+]/', '', $i['phone']), 'phone', 'd'];
    if ($map) $tiles[] = ['map', __('Directions', 'idev-app'), __('Open in Google Maps', 'idev-app'), $map, 'pin', 'e'];
    return apply_filters('idev_app_tiles', $tiles);
}

function idev_app_icon($name) {
    if (function_exists('idev_icon')) return idev_icon($name);
    $p = ['calendar' => '<rect x="3" y="4.5" width="18" height="16.5" rx="2.5"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/>', 'home' => '<path d="M3 11 12 4l9 7"/><path d="M5 10v10h14V10"/>', 'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>', 'phone' => '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/>', 'pin' => '<path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>', 'idcard' => '<rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="9" cy="11" r="2.5"/><path d="M15 9.5h3.5M15 13h3.5"/>', 'stethoscope' => '<path d="M5 3v6a4 4 0 0 0 8 0V3M9 13v2a5 5 0 0 0 10 0v-2"/><circle cx="19" cy="11" r="2"/>'];
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($p[$name] ?? $p['home']) . '</svg>';
}

/** Tab bar (phones) / side rail (desktop). */
function idev_app_nav() {
    $tiles = idev_app_tiles();
    $items = [['home', __('Home', 'idev-app'), home_url('/'), 'home']];
    foreach ($tiles as $t) if (in_array($t[0], ['book', 'reg', 'sched'], true)) $items[] = [$t[0], [ 'book' => __('Book', 'idev-app'), 'reg' => __('Register', 'idev-app'), 'sched' => __('Doctors', 'idev-app')][$t[0]], $t[3], $t[4]];
    if (get_theme_mod('idev_app_staff', '1')) $items[] = ['staff', __('Staff', 'idev-app'), is_user_logged_in() ? admin_url() : wp_login_url(), 'user'];
    $here = trailingslashit((is_ssl() ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? '') . strtok($_SERVER['REQUEST_URI'] ?? '/', '?')); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
    echo '<nav class="app-nav" aria-label="' . esc_attr__('Menu', 'idev-app') . '">';
    foreach ($items as [$k, $l, $u, $ic]) echo '<a class="' . (trailingslashit(strtok($u, '?')) === $here ? 'on' : '') . '" href="' . esc_url($u) . '">' . idev_app_icon($ic) . '<span>' . esc_html($l) . '</span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo '</nav>';
}
function idev_app_brand() {
    $i = idev_app_info();
    echo '<a class="app-brand" href="' . esc_url(home_url('/')) . '">' . ($i['logo'] ? '<img src="' . esc_url($i['logo']) . '" alt="">' : '<span class="mk">' . esc_html(mb_substr($i['name'], 0, 1)) . '</span>') . '<span><b>' . esc_html($i['name']) . '</b>' . ($i['tagline'] ? '<small>' . esc_html($i['tagline']) . '</small>' : '') . '</span></a>';
}
