<?php defined('ABSPATH') || exit; ?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#0f3a46">
<meta name="mobile-web-app-capable" content="yes">
<?php wp_head(); ?>
</head>
<body <?php body_class('app'); ?>>
<?php wp_body_open(); ?>
<div class="app-shell">
  <aside class="app-rail"><?php idev_app_brand(); idev_app_nav(); ?><div class="app-rail-foot">iDevApp</div></aside>
  <div class="app-main">
