<?php defined('ABSPATH') || exit; ?>
  </div>
</div>
<div class="app-tabbar"><?php idev_app_nav(); ?></div>
<?php wp_footer(); ?>
</body>
</html>
