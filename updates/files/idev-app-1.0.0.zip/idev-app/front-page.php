<?php
defined('ABSPATH') || exit;
get_header();
$i = idev_app_info();
$status = function_exists('idev_cs_open_status') ? idev_cs_open_status() : null;
$welcome = get_theme_mod('idev_app_welcome', '') ?: __('How can we help you today?', 'idev-app');
?>
<header class="home-hero">
  <div class="home-top"><?php idev_app_brand(); ?>
    <?php if ($status) : ?><span class="open st-<?php echo esc_attr($status['state']); ?>"><i></i><?php echo esc_html($status['text']); ?></span><?php endif; ?>
  </div>
  <p class="date"><?php echo esc_html(function_exists('idev_format_day') ? idev_format_day(wp_date('Y-m-d'), null, true, true) : wp_date(get_option('date_format'))); ?></p>
  <h1><?php echo esc_html($welcome); ?></h1>
</header>
<main class="home-body">
  <div class="tiles">
  <?php foreach (idev_app_tiles() as $n => [$k, $t, $sub, $u, $ic, $tone]) : ?>
    <a class="tile t-<?php echo esc_attr($tone); ?><?php echo $n === 0 ? ' big' : ''; ?>" href="<?php echo esc_url($u); ?>"<?php echo strpos($u, 'http') === 0 && strpos($u, home_url()) !== 0 ? ' target="_blank" rel="noopener"' : ''; ?>>
      <span class="ic"><?php echo idev_app_icon($ic); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
      <span class="tx"><b><?php echo esc_html($t); ?></b><small><?php echo esc_html($sub); ?></small></span>
      <span class="go">›</span>
    </a>
  <?php endforeach; ?>
  </div>
  <?php
  while (have_posts()) { the_post(); $c = trim((string) get_the_content()); if ($c !== '' && is_page()) { echo '<section class="card home-content">'; the_content(); echo '</section>'; } }
  ?>
  <?php if (get_theme_mod('idev_app_staff', '1')) : ?>
  <a class="staff" href="<?php echo esc_url(is_user_logged_in() ? admin_url() : wp_login_url()); ?>"><?php echo idev_app_icon('user'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><b><?php echo esc_html(is_user_logged_in() ? __('Open the clinic system', 'idev-app') : __('Staff sign-in', 'idev-app')); ?></b><small><?php esc_html_e('Doctors, nurses and the front desk', 'idev-app'); ?></small></span><span class="go">›</span></a>
  <?php endif; ?>
  <?php if ($i['address']) : ?><p class="addr"><?php echo esc_html(preg_replace('/\s*\n\s*/', ' ', $i['address'])); ?></p><?php endif; ?>
</main>
<?php get_footer(); ?>
