<?php
/**
 * Plugin Name:       iDev Appointments
 * Plugin URI:        https://idevapp.me/plugins/idev-appointments
 * Description:       Online appointments with doctors and clinics: a link per doctor or clinic, time slots with a limit per slot, patients identified by HN (new patients register first), PDPA/GDPR consent, automatic or staff confirmation, e-mail confirmation and reminders, cancel or reschedule by patient or staff, and a portal where doctors see and confirm their own appointments.
 * Version:           1.5.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-appointments
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// The Pro version contains this plugin; when both are installed the Pro one is used.
if (defined('IDEV_APPT_VERSION')) return;

define('IDEV_APPT_VERSION', '1.5.0');
define('IDEV_APPT_FILE', __FILE__);
define('IDEV_APPT_URL', plugin_dir_url(__FILE__));

require_once __DIR__ . '/common/idev-common.php';
require_once __DIR__ . '/includes/core.php';
require_once __DIR__ . '/includes/emails.php';
require_once __DIR__ . '/includes/rest.php';
require_once __DIR__ . '/includes/front.php';
require_once __DIR__ . '/includes/portal.php';
require_once __DIR__ . '/includes/settings.php';

register_activation_hook(__FILE__, function () { idev_appt_install(); update_option('idev_appt_flush', 1, false); });
register_deactivation_hook(__FILE__, function () { wp_clear_scheduled_hook('idev_appt_cron'); flush_rewrite_rules(); });
