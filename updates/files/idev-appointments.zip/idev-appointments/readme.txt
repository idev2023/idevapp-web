=== iDev Appointments ===
Contributors: idevapp2023
Donate link: https://idevapp.me/
Tags: appointments, booking, doctor, clinic, hospital
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.5.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Online appointments with doctors and clinics: a link per doctor or clinic, time slots with a limit per slot, patients identified by HN (new patients

== Description ==

Online appointments with doctors and clinics: a link per doctor or clinic, time slots with a limit per slot, patients identified by HN (new patients register first), PDPA/GDPR consent, automatic or staff confirmation, e-mail confirmation and reminders, cancel or reschedule by patient or staff, and a doctor portal.

= Features =

* Own booking address for each doctor and clinic
* Slots from the clinic schedule, capacity per slot, days off and holidays
* HN + date of birth, or online registration reference
* Automatic or staff confirmation (per doctor)
* E-mails: received, confirmed, reminder before the day, on the day, cancelled, moved — editable
* Patients cancel or move by the link in the e-mail; add to calendar (.ics)
* Doctor portal: day/week, confirm, move, cancel, came / did not come
* Requires iDev Clinic Schedule

Thai and English interface. Works with any theme. Part of the iDevApp plugin suite for hospitals and clinics — all iDev plugins appear under the **iDevApp** menu.

= Pro add-on (optional) =

All of the above is free with no limits on doctors, clinics or appointments. **iDev Appointments Pro** (separate plugin) adds LINE and SMS reminders, a waiting list, branches, reports with no-show rates and CSV export, and an optional HOSxP connector.

== Installation ==

1. Plugins → Add New → Upload Plugin, choose the zip, Install, Activate.
2. Open **iDevApp** in the admin menu for settings.

== Changelog ==

= 1.5.1 =
* Dates show the Buddhist year (พ.ศ.) and Thai month names on Thai pages, and the Gregorian year on English pages, everywhere WordPress formats a date.

= 1.5.0 =
* Second booking order (choose in Settings): service → day → time → sub-service / doctor → patient → agreement.
* Doctors see their own appointments or the whole clinic's (setting, or per doctor).
* Records desk: edit an HN that was already checked; recheck the data of patients who registered online and booked. Patients can book whatever their registration status.

= 1.4.0 =
* Booking in steps: clinic / service → doctor / staff / sub-service → day → time → patient → agreement. Thai ID / passport number. Places per slot for each doctor or shared by the clinic / service. Break between slots.

= 1.3.0 =
* HN check for the medical records desk (list of appointments whose HN is not checked, confirm or correct the HN).

= 1.2.4 =
* Month calendar lists each patient with the status (waiting, confirmed, moved, cancelled, came, did not come); status filter; tap a patient to open the appointment.

= 1.2.3 =
* Month calendar in the doctor portal: clinic hours and the appointments of each day.

= 1.2.2 =
* New sign-in card on the doctor portal page.

= 1.2.0 =
* Every doctor and clinic is free — no licence needed.
* Hooks for iDev Appointments Pro (branches, messages, waiting list). Licence keys issued for 1.1 now turn on iDev Appointments Pro.

= 1.1.0 =
* Free plan: online booking for 1 doctor or clinic, unlimited appointments. Licence (2,000 THB, lifetime, one website): every doctor and clinic.
* Licences are entered under iDevApp → Licences.

= 1.0.0 =
* First release.
