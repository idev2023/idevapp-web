<?php
/** Printouts: visit summary (OPD card) and medical certificate, with the shared document designer (3 templates). */
defined('ABSPATH') || exit;

function idev_emr_print_url($type, $id, $paper = '') {
    return add_query_arg(array_filter(['action' => 'idev_emr_print', 'type' => $type, 'id' => $id, 'paper' => $paper, '_wpnonce' => wp_create_nonce('idev_emr_print_' . $type . $id)]), admin_url('admin-post.php'));
}
function idev_emr_papers() { return ['a4' => 'A4', 'a5' => 'A5']; }
function idev_emr_doc_design() { return function_exists('idev_doc_design') ? idev_doc_design('idev_emr_doc_design') : []; }
function idev_emr_org() {
    $s = function_exists('idev_store_settings') ? idev_store_settings() : [];
    $e = idev_emr_settings();
    $line = $e['clinic_license'] !== '' ? __('Licence no.', 'idev-clinic-emr') . ' ' . $e['clinic_license'] : '';
    return ['name' => $s['shop_name'] ?? get_bloginfo('name'), 'address' => $s['address'] ?? '', 'phone' => $s['phone'] ?? '', 'tax_id' => '', 'logo' => $s['logo'] ?? '', 'line' => $line];
}
function idev_emr_trial() { return function_exists('idev_store_licensed') && !idev_store_licensed(); }

add_action('admin_post_idev_emr_print', function () {
    $type = sanitize_key($_GET['type'] ?? '');
    $id = (int) ($_GET['id'] ?? 0);
    if (!idev_emr_can() || !wp_verify_nonce($_GET['_wpnonce'] ?? '', 'idev_emr_print_' . $type . $id)) wp_die(esc_html__('Sorry, you are not allowed to do that.', 'idev-clinic-emr'), 403);
    $v = idev_emr_visit($id);
    $c = $v ? idev_emr_patient($v['customer_id']) : null;
    if (!$c) wp_die('Not found', 404);
    $s = idev_emr_settings();
    $paper = sanitize_key($_GET['paper'] ?? '') ?: ($type === 'cert' ? $s['cert_paper'] : $s['opd_paper']);
    if (!isset(idev_emr_papers()[$paper])) $paper = 'a4';
    $papers = [];
    foreach (idev_emr_papers() as $k => $l) $papers[$l] = idev_emr_print_url($type, $id, $k);
    nocache_headers();
    echo idev_emr_doc($type, $v, $c, idev_emr_doc_design(), $paper, $papers); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- full HTML page, escaped inside
    exit;
});

function idev_emr_doc($type, $v, $c, $design, $paper, $papers = [], $preview = false) {
    $body = $type === 'cert' ? idev_emr_doc_cert($v, $c) : idev_emr_doc_opd($v, $c);
    $title = $type === 'cert' ? __('Medical certificate', 'idev-clinic-emr') : __('Visit summary', 'idev-clinic-emr');
    $css = '<style>.emrd-grid{display:grid;grid-template-columns:repeat(4,auto);gap:2px 14px;margin:6px 0 10px}.emrd-grid b{font-weight:normal;color:#555}.emrd-sec{margin:8px 0}.emrd-sec h3{margin:0 0 2px;font-size:1em;color:var(--dc,#000)}'
        . '.emrd-al{border:1.5px solid #b91c1c;color:#b91c1c;padding:4px 8px;font-weight:bold;margin:6px 0}.emrd-p{text-indent:2.5em;line-height:2;margin:6px 0}.emrd-line{border-bottom:1px dotted #000;padding:0 6px;font-weight:bold;white-space:nowrap}'
        . '.emrd-sign{margin:40px 0 0 auto;width:60%;text-align:center;line-height:1.9}.emrd-sign span{display:block;border-top:1px dotted #000;margin-top:34px}.emrd-no{text-align:right;font-size:.9em}.f-a5 .emrd-grid{grid-template-columns:repeat(2,auto)}</style>';
    return idev_doc_page(['title' => $title, 'body' => $css . $body, 'design' => $design, 'paper' => $paper, 'org' => idev_emr_org(), 'trial' => idev_emr_trial(), 'papers' => $papers, 'preview' => $preview]);
}

function idev_emr_doc_patient_grid($v, $c) {
    $p = $c['profile'];
    $rows = [
        __('Name', 'idev-clinic-emr') => $c['name'], 'HN' => $c['hn'],
        __('Age', 'idev-clinic-emr') => trim(($p['sex'] !== '' ? idev_emr_sexes()[$p['sex']] : '') . ' ' . idev_emr_age($c['birthdate'], $v['visit_date'])), __('Date', 'idev-clinic-emr') => idev_format_day($v['visit_date'], null, true),
        'VN' => $v['vn'], __('Phone', 'idev-clinic-emr') => $c['phone'],
    ];
    $o = '<div class="emrd-grid">';
    foreach ($rows as $k => $val) $o .= '<b>' . esc_html($k) . '</b><span>' . esc_html($val ?: '—') . '</span>';
    return $o . '</div>';
}

function idev_emr_doc_opd($v, $c) {
    $d = $v['d'];
    $p = $c['profile'];
    $o = idev_emr_doc_patient_grid($v, $c);
    $o .= $p['allergies'] ? '<div class="emrd-al">⚠ ' . esc_html__('Drug allergy:', 'idev-clinic-emr') . ' ' . esc_html(implode(', ', array_map(function ($a) { return $a['drug'] . ($a['reaction'] ? ' (' . $a['reaction'] . ')' : ''); }, $p['allergies']))) . '</div>' : '';
    $sec = function ($t, $text) { return $text !== '' ? '<div class="emrd-sec"><h3>' . esc_html($t) . '</h3>' . nl2br(esc_html($text)) . '</div>' : ''; };
    $o .= $sec(__('Vital signs', 'idev-clinic-emr'), idev_emr_vitals_text($d['vitals']));
    $o .= $sec(__('Chief complaint (CC)', 'idev-clinic-emr'), $d['cc']) . $sec(__('Present illness (PI)', 'idev-clinic-emr'), $d['pi']) . $sec(__('Past history / current medicines', 'idev-clinic-emr'), $d['pmh']) . $sec(__('Physical examination (PE)', 'idev-clinic-emr'), $d['pe']);
    $o .= $sec(__('Diagnosis', 'idev-clinic-emr'), implode("\n", array_map(function ($x) { return trim($x['code'] . ' ' . $x['name']); }, $d['dx'])));
    $o .= $sec(__('Treatment / procedures', 'idev-clinic-emr'), $d['procedures']);
    if ($v['o']) {
        $price = idev_emr_settings()['show_price_on_opd'] === '1';
        $o .= '<div class="emrd-sec"><h3>' . esc_html__('Medicines and services', 'idev-clinic-emr') . '</h3><table><thead><tr><th>' . esc_html__('Item', 'idev-clinic-emr') . '</th><th>' . esc_html__('Directions', 'idev-clinic-emr') . '</th><th class="r">' . esc_html__('Qty', 'idev-clinic-emr') . '</th>' . ($price ? '<th class="r">' . esc_html__('Amount', 'idev-clinic-emr') . '</th>' : '') . '</tr></thead><tbody>';
        foreach ($v['o'] as $x) $o .= '<tr><td>' . esc_html($x['name']) . '</td><td>' . esc_html($x['use']) . '</td><td class="r">' . esc_html(idev_store_qty($x['qty']) . ($x['unit'] ? ' ' . $x['unit'] : '')) . '</td>' . ($price ? '<td class="r">' . esc_html(number_format($x['qty'] * $x['price'], 2)) . '</td>' : '') . '</tr>';
        $o .= '</tbody></table></div>';
    }
    $o .= $sec(__('Advice', 'idev-clinic-emr'), $d['advice']);
    if (!empty($d['followup']['date'])) $o .= $sec(__('Next appointment', 'idev-clinic-emr'), idev_format_day($d['followup']['date'], null, true) . (!empty($d['followup']['time']) ? ' ' . $d['followup']['time'] : '') . (!empty($d['followup']['note']) ? ' — ' . $d['followup']['note'] : ''));
    $doc = idev_emr_doctor($v['doctor_id']);
    $o .= '<div class="emrd-sign"><span></span>(' . esc_html($doc['name'] ?: '..............................') . ')<br>' . esc_html__('Doctor', 'idev-clinic-emr') . ($doc['license'] ? ' · ' . esc_html__('Licence no.', 'idev-clinic-emr') . ' ' . esc_html($doc['license']) : '') . '</div>';
    return $o;
}

function idev_emr_doc_cert($v, $c) {
    $d = $v['d'];
    $cert = array_merge(['days' => 0, 'from' => $v['visit_date'], 'opinion' => '', 'purpose' => '', 'fit' => 0], $d['cert'] ?: []);
    $s = idev_emr_settings();
    $doc = idev_emr_doctor($v['doctor_id']);
    $p = $c['profile'];
    $L = function ($t) { return '<span class="emrd-line">' . ($t !== '' ? esc_html($t) : str_repeat('&nbsp;', 24)) . '</span>'; };
    $o = '<div class="emrd-no">' . esc_html__('No.', 'idev-clinic-emr') . ' ' . esc_html($v['vn']) . '</div>';
    $o .= '<p class="emrd-p">' . sprintf(esc_html__('I, %1$s, licensed medical practitioner no. %2$s, have examined %3$s, ID card / passport no. %4$s, age %5$s, HN %6$s, on %7$s.', 'idev-clinic-emr'),
        $L($doc['name']), $L($doc['license']), $L($c['name']), $L($p['id_no'] ? substr($p['id_no'], 0, -4) . 'XXXX' : ''), $L(idev_emr_age($c['birthdate'], $v['visit_date'])), $L($c['hn']), $L(idev_format_day($v['visit_date'], null, true))) . '</p>';
    if ($cert['fit']) {
        $vt = idev_emr_vitals_text(array_intersect_key($d['vitals'], array_flip(['weight', 'height', 'sbp', 'dbp', 'pulse'])));
        $o .= '<p class="emrd-p">' . esc_html__('Result: the person above is in good health, with no signs of serious illness, communicable disease or condition that would prevent work.', 'idev-clinic-emr') . ($vt ? ' (' . esc_html($vt) . ')' : '') . '</p>';
    } else {
        $dx = implode(', ', array_map(function ($x) { return $x['name'] ?: $x['code']; }, $d['dx']));
        $o .= '<p class="emrd-p">' . esc_html($s['cert_text']) . ($dx !== '' ? ' ' . esc_html__('Diagnosis:', 'idev-clinic-emr') . ' ' . $L($dx) : '') . '</p>';
    }
    $opinion = $cert['opinion'];
    if ($cert['days'] > 0) {
        $from = $cert['from'] ?: $v['visit_date'];
        $rest = strtr($s['cert_rest_text'], ['{days}' => (string) $cert['days'], '{from}' => idev_format_day($from, null, true), '{to}' => idev_format_day(idev_add_days($from, $cert['days'] - 1), null, true)]);
        $opinion = trim($opinion . "\n" . $rest);
    }
    if ($opinion !== '') $o .= '<p class="emrd-p"><b>' . esc_html__('Doctor\'s opinion:', 'idev-clinic-emr') . '</b> ' . nl2br(esc_html($opinion)) . '</p>';
    if ($cert['purpose'] !== '') $o .= '<p class="emrd-p">' . esc_html__('This certificate is issued for:', 'idev-clinic-emr') . ' ' . $L($cert['purpose']) . '</p>';
    $o .= '<div class="emrd-sign"><span></span>(' . esc_html($doc['name'] ?: '..............................') . ')<br>' . esc_html__('Examining doctor', 'idev-clinic-emr') . '<br>' . ($doc['license'] ? esc_html__('Licence no.', 'idev-clinic-emr') . ' ' . esc_html($doc['license']) : '') . '</div>';
    return $o;
}

/* Designer: Print design → Examination room (same three templates as receipts). */
add_action('init', function () {
    if (!function_exists('idev_register_doc_designer')) return;
    idev_register_doc_designer('emr', [
        'option' => 'idev_emr_doc_design', 'docs' => ['cert' => __('Medical certificate', 'idev-clinic-emr'), 'opd' => __('Visit summary', 'idev-clinic-emr')], 'papers' => idev_emr_papers(),
        'preview' => function ($doc, $design, $paper) { [$v, $c] = idev_emr_doc_sample(); return idev_emr_doc($doc === 'opd' ? 'opd' : 'cert', $v, $c, $design, isset(idev_emr_papers()[$paper]) ? $paper : 'a4', [], true); },
    ]);
}, 30);
/** Sample visit for the designer (fictional data). */
function idev_emr_doc_sample() {
    $today = idev_today();
    $v = ['id' => 0, 'vn' => 'VN' . wp_date('ym') . '-0012', 'customer_id' => 0, 'visit_date' => $today, 'queue_no' => 3, 'status' => 'done', 'doctor_id' => get_current_user_id(), 'bill_id' => 0, 'log' => [],
        'd' => ['vitals' => ['weight' => 62, 'height' => 165, 'temp' => 38.2, 'sbp' => 122, 'dbp' => 78, 'pulse' => 96, 'rr' => 20, 'spo2' => 98], 'cc' => 'ไข้ เจ็บคอ 2 วัน', 'pi' => 'ไข้ต่ำ ๆ เจ็บคอเวลากลืน ไม่ไอ ไม่มีน้ำมูก', 'pmh' => '', 'pe' => 'Pharynx injected, tonsils 1+ no exudate, lungs clear', 'dx' => [['code' => 'J02.9', 'name' => 'คออักเสบเฉียบพลัน', 'type' => 'principal']],
            'plan' => '', 'advice' => 'ดื่มน้ำมาก ๆ พักผ่อน หากไข้ไม่ลดใน 3 วันให้กลับมาพบแพทย์', 'note' => '', 'nurse_note' => '', 'procedures' => '', 'followup' => ['date' => idev_add_days($today, 7), 'time' => '10:00', 'note' => 'ติดตามอาการ'], 'cert' => ['days' => 2, 'from' => $today, 'opinion' => '', 'purpose' => 'ลาป่วย', 'fit' => 0]],
        'o' => [['item_id' => 0, 'name' => 'Paracetamol 500 mg', 'qty' => 20, 'unit' => 'เม็ด', 'price' => 1, 'use' => 'รับประทานครั้งละ 1 เม็ด ทุก 4–6 ชั่วโมง เวลามีไข้', 'ind' => '', 'warn' => '', 'kind' => 'product'], ['item_id' => 0, 'name' => 'Chlorpheniramine 4 mg', 'qty' => 10, 'unit' => 'เม็ด', 'price' => 1, 'use' => 'รับประทานครั้งละ 1 เม็ด วันละ 3 ครั้ง หลังอาหาร', 'ind' => '', 'warn' => '', 'kind' => 'product']]];
    $c = ['id' => 0, 'name' => 'นางสาวสมใจ ใจดี', 'hn' => '69-00012', 'phone' => '0812345678', 'birthdate' => (string) ((int) wp_date('Y') - 29) . '-04-12', 'email' => '', 'data' => [],
        'profile' => ['sex' => 'f', 'id_no' => '1234567890123', 'blood' => 'O', 'chronic' => '', 'allergies' => [['drug' => 'Penicillin', 'reaction' => 'ผื่นลมพิษ', 'severity' => 'moderate', 'certainty' => 'certain']], 'no_allergy' => '', 'alert' => '', 'emergency' => '', 'rights' => '', 'note' => '']];
    return [$v, $c];
}
