/* iDev Clinic Records — queue search, allergy editor, visit screen (vital signs, diagnosis, orders, re-med, follow-up). */
(function () {
  'use strict';
  var C = window.IDEV_EMR || {}, T = C.t || {};
  function el(tag, attrs, kids) {
    var e = document.createElement(tag);
    for (var k in attrs || {}) {
      var v = attrs[k];
      if (v === null || v === undefined || v === false) continue;
      if (k === 'class') e.className = v; else if (k === 'text') e.textContent = v; else if (k === 'html') e.innerHTML = v;
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v); else e.setAttribute(k, v);
    }
    (kids || []).forEach(function (c) { if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  function api(base, path) {
    return fetch(base + path, { headers: { 'X-WP-Nonce': C.nonce }, credentials: 'same-origin' }).then(function (r) { return r.json(); });
  }
  function debounce(fn, ms) { var t; return function () { var a = arguments; clearTimeout(t); t = setTimeout(function () { fn.apply(null, a); }, ms); }; }
  function num(v) { v = parseFloat(String(v).replace(/,/g, '')); return isFinite(v) ? v : 0; }
  function money(n) { return (Math.round(n * 100) / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function fmt(s) { var a = [].slice.call(arguments, 1); return String(s).replace(/%(\d+\$)?[sd]/g, function () { return a.shift(); }); }

  /* ---------- Queue: find a patient ---------- */
  document.querySelectorAll('.emr-find[data-mode="queue"]').forEach(function (box) {
    var input = box.querySelector('input'), out = box.querySelector('.emr-find-out'), form = document.getElementById('emr-queue-form');
    var run = debounce(function () {
      var q = input.value.trim();
      if (q.length < 2) { out.innerHTML = ''; return; }
      api(C.api, 'patients?q=' + encodeURIComponent(q)).then(function (list) {
        out.innerHTML = '';
        if (!list.length) out.appendChild(el('div', { class: 'emr-none' }, [T.none + ' ', el('a', { href: 'admin.php?page=idev-emr-patients&id=new&queue=1', text: '＋ ' + T.newPatient })]));
        list.forEach(function (p) {
          out.appendChild(el('div', { class: 'emr-res' }, [
            el('div', {}, [el('b', { text: p.name }), p.allergy ? el('span', { class: 'emr-tag red', text: '⚠ ' + p.allergy }) : null, el('small', { text: ['HN ' + (p.hn || '—'), p.age, p.phone].filter(Boolean).join(' · ') })]),
            el('button', { type: 'button', class: 'button button-primary', text: T.add, onclick: function () { form.customer_id.value = p.id; form.submit(); } }),
            el('a', { class: 'button', href: p.url, text: T.open })
          ]));
        });
      });
    }, 220);
    input.addEventListener('input', run);
    input.addEventListener('keydown', function (e) { if (e.key === 'Escape') { input.value = ''; out.innerHTML = ''; } });
    document.addEventListener('click', function (e) { if (!box.contains(e.target)) out.innerHTML = ''; });
  });

  /* ---------- Patient form: allergy rows ---------- */
  var alTable = document.querySelector('.emr-altable tbody');
  if (alTable) {
    var tpl = alTable.lastElementChild.cloneNode(true);
    var nextIndex = alTable.children.length;
    document.querySelector('.emr-aladd').addEventListener('click', function () {
      var row = tpl.cloneNode(true);
      row.querySelectorAll('[name]').forEach(function (i) { i.name = i.name.replace(/\[\d+\]/, '[' + nextIndex + ']'); if (i.tagName === 'INPUT') i.value = ''; });
      nextIndex++;
      alTable.appendChild(row); row.querySelector('input').focus();
    });
    alTable.addEventListener('click', function (e) { if (e.target.classList.contains('emr-alx')) { var tr = e.target.closest('tr'); if (alTable.children.length > 1) tr.remove(); else tr.querySelectorAll('input').forEach(function (i) { i.value = ''; }); } });
  }

  /* ---------- Visit screen ---------- */
  var form = document.getElementById('emr-visit');
  if (!form) return;
  var V = JSON.parse(document.getElementById('emr-visit-data').textContent);
  var dirty = false, dirtyMark = form.querySelector('.emr-dirty');
  function setDirty() { dirty = true; if (dirtyMark) dirtyMark.hidden = false; }
  form.addEventListener('input', setDirty);
  window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = T.unsaved; } });

  // Vital signs: BMI and warning colours
  var ranges = { temp: [35.5, 37.5], sbp: [90, 139], dbp: [60, 89], pulse: [50, 110], rr: [10, 24], spo2: [95, 100], pain: [0, 6], dtx: [70, 180] };
  function vitals() {
    var w = num((form['vitals[weight]'] || {}).value), h = num((form['vitals[height]'] || {}).value) / 100, b = document.getElementById('emr-bmi'), bt = document.getElementById('emr-bmi-t');
    if (b) { var bmi = w > 0 && h > 0 ? Math.round(w / (h * h) * 10) / 10 : 0; b.textContent = bmi || '—'; bt.textContent = !bmi ? '' : bmi < 18.5 ? '↓' : bmi < 23 ? '✓' : bmi < 25 ? '↑' : '↑↑'; b.parentNode.className = 'emr-vf bmi' + (bmi && (bmi < 18.5 || bmi >= 25) ? ' hi' : ''); }
    form.querySelectorAll('.emr-vf[data-k]').forEach(function (l) { var k = l.dataset.k, i = l.querySelector('input'), r = ranges[k]; l.classList.toggle('hi', !!(r && i.value !== '' && (num(i.value) < r[0] || num(i.value) > r[1]))); });
  }
  form.addEventListener('input', function (e) { if (e.target.name && e.target.name.indexOf('vitals[') === 0) vitals(); });
  vitals();

  /* Diagnosis */
  var dxBox = document.getElementById('emr-dx'), dx = (V.dx || []).map(function (x) { return { code: x.code, name: x.name }; });
  function renderDx() {
    dxBox.innerHTML = '';
    var list = el('div', { class: 'emr-dxlist' });
    dx.forEach(function (x, i) {
      list.appendChild(el('span', { class: 'emr-dxchip' + (i === 0 ? ' main' : '') }, [
        i === 0 ? el('em', { text: T.principal }) : (V.doctor ? el('button', { type: 'button', class: 'up', title: T.principal, text: '↑', onclick: function () { dx.unshift(dx.splice(i, 1)[0]); renderDx(); setDirty(); } }) : null),
        x.code ? el('code', { text: x.code }) : null, ' ' + x.name,
        el('input', { type: 'hidden', name: 'dx[' + i + '][code]', value: x.code }), el('input', { type: 'hidden', name: 'dx[' + i + '][name]', value: x.name }),
        V.doctor ? el('button', { type: 'button', class: 'x', text: '✕', onclick: function () { dx.splice(i, 1); renderDx(); setDirty(); } }) : null
      ]));
    });
    dxBox.appendChild(list);
    if (!V.doctor) return;
    var wrap = el('div', { class: 'emr-dxfind' }), input = el('input', { type: 'search', placeholder: T.dxSearch, autocomplete: 'off' }), out = el('div', { class: 'emr-drop' });
    function add(x) { dx.push(x); renderDx(); setDirty(); dxBox.querySelector('input[type=search]').focus(); }
    var run = debounce(function () {
      var q = input.value.trim(); out.innerHTML = '';
      if (!q) return;
      api(C.api, 'icd?q=' + encodeURIComponent(q)).then(function (r) {
        out.innerHTML = '';
        r.forEach(function (x) { out.appendChild(el('button', { type: 'button', onclick: function () { add({ code: x.code, name: x.th }); } }, [el('code', { text: x.code }), ' ' + x.th, el('small', { text: x.en })])); });
        out.appendChild(el('button', { type: 'button', class: 'free', onclick: function () { add({ code: '', name: q }); } }, ['＋ ' + T.dxFree + ': “' + q + '”']));
      });
    }, 160);
    input.addEventListener('input', run);
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); var f = out.querySelector('button'); if (f) f.click(); } });
    wrap.appendChild(input); wrap.appendChild(out); dxBox.appendChild(wrap);
  }
  renderDx();

  /* Allergy check (same rules as the server) */
  function allergyHits(names) {
    var hay = names.filter(Boolean).join(' | ').toLowerCase(), hits = [];
    (V.allergies || []).forEach(function (a) {
      var d = (a.drug || '').toLowerCase().trim();
      if (d.length < 3) return;
      var words = [d];
      Object.keys(V.families).forEach(function (f) { var m = V.families[f]; if (m.indexOf(d) >= 0 || d.indexOf(f) >= 0) words = words.concat(m); });
      if (words.some(function (w) { return w.length >= 4 && hay.indexOf(w) >= 0; })) hits.push(a.drug);
    });
    return hits;
  }

  /* Orders */
  var orders = (V.orders || []).map(function (o) { return Object.assign({}, o); });
  var box = document.getElementById('emr-orders'), jsonIn = document.getElementById('emr-orders-json');
  function sync() { jsonIn.value = JSON.stringify(orders); }
  function builder(o, ta) {
    var B = C.builder;
    if (!B) return null;
    var pick = { verb: 'take', n: '1', unit: Object.keys(B.units)[0], freq: '3', timing: 'after', periods: [] };
    function sel(key, opts) { var s = el('select', { onchange: function (e) { pick[key] = e.target.value; } }); Object.keys(opts).forEach(function (k) { s.appendChild(el('option', { value: k, text: opts[k], selected: pick[key] === k ? 'selected' : null })); }); return s; }
    var per = el('span', { class: 'emr-periods' });
    Object.keys(B.periods).forEach(function (k) { per.appendChild(el('label', {}, [el('input', { type: 'checkbox', onchange: function (e) { var i = pick.periods.indexOf(k); if (e.target.checked && i < 0) pick.periods.push(k); else if (!e.target.checked && i >= 0) pick.periods.splice(i, 1); } }), ' ' + B.periods[k]])); });
    return el('div', { class: 'emr-builder' }, [sel('verb', B.verbs), el('input', { type: 'text', value: pick.n, size: 2, oninput: function (e) { pick.n = e.target.value; } }), sel('unit', B.units), sel('freq', B.freqs), sel('timing', B.timings), per,
      el('button', { type: 'button', class: 'button button-small', text: '↓ ' + T.fill, onclick: function () {
        var order = Object.keys(B.periods);
        var txt = B.doseFmt.replace('{verb}', B.verbs[pick.verb]).replace('{amount}', pick.n).replace('{unit}', B.units[pick.unit]);
        txt = [txt, B.freqs[pick.freq], pick.timing ? B.timings[pick.timing] : '', pick.periods.sort(function (a, b) { return order.indexOf(a) - order.indexOf(b); }).map(function (k) { return B.periods[k]; }).join(' ')].filter(Boolean).join(' ');
        o.use = txt.replace(/\s+/g, ' ').trim(); ta.value = o.use; sync(); setDirty();
      } })]);
  }
  function renderOrders() {
    box.innerHTML = '';
    if (!V.locked) {
      var tools = el('div', { class: 'emr-otools' });
      tools.appendChild(itemSearch());
      if (V.remed && V.remed.length) {
        var rs = el('select', { class: 'emr-remedsel', onchange: function (e) { if (e.target.value) remed(+e.target.value); e.target.value = ''; } }, [el('option', { value: '', text: '↻ ' + T.remedSel })]);
        V.remed.forEach(function (h) { rs.appendChild(el('option', { value: h.id, text: h.date + ' · ' + (h.dx || h.vn) + ' (' + h.orders.length + ')' })); });
        tools.appendChild(rs);
      }
      box.appendChild(tools);
    }
    var t = el('table', { class: 'emr-otable' }), tb = el('tbody'), total = 0;
    t.appendChild(el('thead', {}, [el('tr', {}, [el('th', { text: '' }), el('th', { text: T.use }), el('th', { class: 'r', text: T.qty }), el('th', { class: 'r', text: T.price }), el('th', { class: 'r', text: T.total }), el('th')])]));
    if (!orders.length) tb.appendChild(el('tr', {}, [el('td', { colspan: 6, class: 'emr-empty', text: T.noOrders })]));
    orders.forEach(function (o, i) {
      var hits = o.kind === 'service' ? [] : allergyHits([o.name, o.generic]);
      var line = num(o.qty) * num(o.price); total += line;
      var tot = el('td', { class: 'r b', text: money(line) });
      var ta = el('textarea', { rows: 2, placeholder: T.use, readonly: V.locked ? 'readonly' : null, oninput: function (e) { o.use = e.target.value; sync(); } }); ta.value = o.use || '';
      var useCell = el('td', { class: 'use' }, [ta]);
      if (!V.locked && o.kind !== 'service') {
        var b = builder(o, ta);
        if (b) { var tog = el('button', { type: 'button', class: 'button-link', text: '⚙ ' + T.fill, onclick: function () { b.hidden = !b.hidden; } }); b.hidden = true; useCell.appendChild(tog); useCell.appendChild(b); }
      }
      function qin(key, w) { return el('input', { type: 'number', min: 0, step: key === 'qty' ? 'any' : '0.01', value: o[key], style: 'width:' + w, readonly: V.locked ? 'readonly' : null, oninput: function (e) { o[key] = num(e.target.value); tot.textContent = money(num(o.qty) * num(o.price)); sync(); }, onfocus: function (e) { e.target.select(); } }); }
      var nameCell = el('td', { class: 'name' }, [el('b', { text: o.name }), o.generic ? el('small', { text: o.generic }) : null, o.stock !== undefined && o.track && num(o.qty) > o.stock ? el('small', { class: 'warn', text: o.stock + ' ' + T.stock }) : null]);
      if (hits.length) {
        nameCell.appendChild(el('div', { class: 'emr-ohit' }, ['⚠ ' + fmt(T.allergyHit, hits.join(', ')), V.locked ? null : el('label', {}, [el('input', { type: 'checkbox', checked: o.ack ? 'checked' : null, onchange: function (e) { o.ack = e.target.checked ? 1 : 0; sync(); } }), ' ' + T.ack])]));
      }
      tb.appendChild(el('tr', { class: hits.length ? 'hit' : '' }, [nameCell, useCell, el('td', { class: 'r' }, [qin('qty', '64px'), el('small', { text: o.unit || '' })]), el('td', { class: 'r' }, [qin('price', '84px')]), tot,
        el('td', {}, [V.locked ? null : el('button', { type: 'button', class: 'button-link emr-x', title: T.remove, text: '✕', onclick: function () { orders.splice(i, 1); renderOrders(); setDirty(); } })])]));
    });
    t.appendChild(tb);
    if (orders.length) t.appendChild(el('tfoot', {}, [el('tr', {}, [el('td', { colspan: 4, class: 'r', text: T.total }), el('td', { class: 'r b', text: money(total) }), el('td')])]));
    box.appendChild(t);
    sync();
  }
  function addItem(it) {
    var ex = orders.find(function (o) { return o.item_id && o.item_id === it.id; });
    if (ex) ex.qty = num(ex.qty) + 1;
    else orders.push({ item_id: it.id, name: it.name, qty: 1, unit: it.unit || '', price: it.price, kind: it.kind === 'service' ? 'service' : 'product', generic: it.drug ? [it.drug.generic, it.drug.strength].filter(Boolean).join(' ') : '',
      use: it.drug ? it.drug.use || '' : '', ind: it.drug ? it.drug.ind || '' : '', warn: it.drug ? it.drug.warn || '' : '', stock: it.qty, track: it.track, ack: 0 });
    renderOrders(); setDirty();
  }
  function itemSearch() {
    var wrap = el('div', { class: 'emr-isearch' }), input = el('input', { type: 'search', placeholder: T.itemSearch, autocomplete: 'off' }), out = el('div', { class: 'emr-drop' }), results = [];
    var run = debounce(function () {
      var q = input.value.trim(); out.innerHTML = '';
      if (!q) return;
      api(C.store, 'items?q=' + encodeURIComponent(q)).then(function (r) {
        results = r; out.innerHTML = '';
        if (!r.length) out.appendChild(el('div', { class: 'emr-none', text: T.none }));
        r.forEach(function (it) {
          var hit = it.kind !== 'service' && allergyHits([it.name, it.drug && it.drug.generic]).length;
          out.appendChild(el('button', { type: 'button', class: hit ? 'hit' : (it.track && it.qty <= 0 ? 'out' : ''), onclick: function () { addItem(it); input.value = ''; out.innerHTML = ''; input.focus(); } }, [
            el('span', {}, [hit ? '⚠ ' : '', it.name, it.drug && it.drug.generic ? el('small', { text: ' ' + it.drug.generic }) : null]),
            el('small', { text: it.track ? it.qty + ' ' + (it.unit || '') + (it.qty <= 0 ? ' · ' + T.out : it.low ? ' · ' + T.low : '') : T.service }), el('b', { text: money(it.price) })]));
        });
      });
    }, 180);
    input.addEventListener('input', run);
    input.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter') return; e.preventDefault();
      var q = input.value.trim(); if (!q) return;
      api(C.store, 'items?code=' + encodeURIComponent(q)).then(function (r) { if (r.length) { addItem(r[0]); input.value = ''; out.innerHTML = ''; } else if (results.length) { addItem(results[0]); input.value = ''; out.innerHTML = ''; } });
    });
    wrap.appendChild(input); wrap.appendChild(out);
    return wrap;
  }
  function remed(id) {
    var h = (V.remed || []).find(function (x) { return x.id === id; });
    if (!h) return;
    h.orders.forEach(function (o) {
      var ex = o.item_id && orders.find(function (x) { return x.item_id === o.item_id; });
      if (ex) { ex.qty = o.qty; ex.use = o.use || ex.use; } else orders.push(Object.assign({}, o, { ack: 0 }));
    });
    renderOrders(); setDirty();
    var n = el('div', { class: 'notice notice-success inline' }, [el('p', { text: fmt(T.remedDone, h.orders.length, h.date) })]);
    box.insertBefore(n, box.firstChild); setTimeout(function () { n.remove(); }, 5000);
  }
  document.querySelectorAll('.emr-remed').forEach(function (b) { b.addEventListener('click', function () { remed(+b.dataset.id); document.getElementById('orders').scrollIntoView({ behavior: 'smooth' }); }); });
  renderOrders();

  /* Follow-up: quick dates and free times */
  var fp = document.getElementById('emr-fu-p'), fd = document.getElementById('emr-fu-d'), ft = document.getElementById('emr-fu-t');
  function slots() {
    if (!ft) return;
    var keep = ft.dataset.value || ft.value;
    ft.innerHTML = ''; ft.appendChild(el('option', { value: '', text: T.chooseTime }));
    if (!fp.value || !fd.value) return;
    api(C.api, 'slots?provider=' + fp.value + '&date=' + fd.value).then(function (r) {
      if (!r.length) { ft.appendChild(el('option', { value: '', text: T.noSlots, disabled: 'disabled' })); return; }
      r.forEach(function (s) { ft.appendChild(el('option', { value: s.time, text: s.time + ' (' + s.left + ' ' + T.left + ')', selected: s.time === keep ? 'selected' : null, disabled: s.left <= 0 && s.time !== keep ? 'disabled' : null })); });
      ft.dataset.value = '';
    });
  }
  if (fp && fd) {
    fp.addEventListener('change', slots); fd.addEventListener('change', slots);
    document.querySelectorAll('.emr-quickd button').forEach(function (b) {
      b.addEventListener('click', function () { var d = new Date(); d.setDate(d.getDate() + (+b.dataset.days)); fd.value = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); slots(); setDirty(); });
    });
    slots();
  }

  /* Submit: orders JSON, allergy confirmation, keep the section in view */
  var lastBtn = null;
  form.addEventListener('click', function (e) { var b = e.target.closest('button[name="go"]'); if (b) lastBtn = b; });
  form.addEventListener('submit', function (e) {
    sync();
    if (!V.locked && orders.some(function (o) { return o.kind !== 'service' && allergyHits([o.name, o.generic]).length && !o.ack; })) { e.preventDefault(); alert(T.mustAck); document.getElementById('orders').scrollIntoView({ behavior: 'smooth' }); return; }
    var sec = lastBtn && lastBtn.closest('section');
    form.anchor.value = sec ? sec.id : '';
    dirty = false;
  });
  if (location.hash) { var target = document.querySelector(location.hash); if (target) setTimeout(function () { target.scrollIntoView(); var f = target.querySelector('input:not([type=hidden]),textarea'); if (f && location.hash !== '#orders') f.focus({ preventScroll: true }); }, 50); }
})();
