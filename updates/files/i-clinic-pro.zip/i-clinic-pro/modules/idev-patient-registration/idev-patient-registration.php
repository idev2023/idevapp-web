<?php
/**
 * Plugin Name:       iDev Patient Registration
 * Plugin URI:        https://idevapp.me/plugins/idev-patient-registration
 * Description:       Online new-patient registration for hospitals and clinics: PDPA/GDPR consent, photo of the Thai ID card or passport (or typed in), LINE and WhatsApp, staff review, HN and a designable patient card with QR code sent by e-mail. Personal data is encrypted.
 * Version:           1.3.1
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-patient-registration
 * Domain Path:       /languages
 */
defined('ABSPATH') || exit;

// The Pro version contains this plugin; when both are installed the Pro one is used.
if (defined('IDEV_MEDREG_VERSION')) return;

define('IDEV_MEDREG_VERSION', '1.3.1');
define('IDEV_MEDREG_FILE', __FILE__);
define('IDEV_MEDREG_DIR', plugin_dir_path(__FILE__));
define('IDEV_MEDREG_URL', plugin_dir_url(__FILE__));

require_once dirname(__DIR__, 2) . '/common/idev-common.php';
require_once __DIR__ . '/includes/keys.php';
require_once __DIR__ . '/includes/core.php';
require_once __DIR__ . '/includes/card.php';
require_once __DIR__ . '/includes/form.php';
require_once __DIR__ . '/includes/admin.php';
require_once __DIR__ . '/includes/settings.php';
require_once __DIR__ . '/includes/migrate.php';

register_activation_hook(__FILE__, function () { idev_medreg_install(); idev_medreg_migrate_andaman(); });
register_deactivation_hook(__FILE__, function () { wp_clear_scheduled_hook('idev_medreg_cleanup'); });
