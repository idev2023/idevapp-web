=== I-Clinic Pro ===
Contributors: idevapp
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later

Clinic and shop system by iDevApp with job orders (glasses, lenses, hearing aids, dental work): everything in I-Clinic plus job tickets with prescriptions, deposits and pick-up appointments.

One plugin: install the zip from Plugins → Add New → Upload Plugin. A licence key from iDevApp removes "TRIAL" from printed documents.
