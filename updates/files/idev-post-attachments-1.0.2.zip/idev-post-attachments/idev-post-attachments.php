<?php
/**
 * Plugin Name:       iDev Post Attachments
 * Plugin URI:        https://idevapp.me/plugins/idev-post-attachments
 * Description:       Attach PDF, Word, Excel, PowerPoint and other files to any post or page. Drag to order, give each file a friendly name, show a tidy download list with file type and size, and count downloads.
 * Version:           1.0.2
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-post-attachments
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// Loaded once: the same plugin may also be inside an iDevApp package (I-Clinic / I-Drug) or a Pro version.
if (defined('IDEV_PA_VERSION')) return;

define('IDEV_PA_VERSION', '1.0.2');
define('IDEV_PA_FILE', __FILE__);
require_once __DIR__ . '/common/idev-common.php';
require_once __DIR__ . '/includes/attachments.php';
register_activation_hook(__FILE__, 'idev_pa_migrate');
