<?php
/**
 * ข้อมูลชุดการ์ด: option idw_services = [ 'v' => 2, 'sets' => [ ชุด, ... ] ]
 * ชุด = id, name, kicker/title/lead {th,en}, columns, style, size, layout, card, bg, more {url,label}, items[]
 * การ์ด = icon, tone, image, imageId, imageMode (cover|icon), title/text/link {th,en}, url, on
 */
defined( 'ABSPATH' ) || exit;

function idw_svc_tones() {
	return array(
		'mint'     => array( 'เขียวมิ้นต์', '#13a383', '#e3f8f1' ),
		'teal'     => array( 'เขียวน้ำทะเล', '#0f8f86', '#e0f5f3' ),
		'green'    => array( 'เขียว', '#2e9e4f', '#e6f6ea' ),
		'sky'      => array( 'ฟ้า', '#1e93c4', '#e2f4fb' ),
		'blue'     => array( 'น้ำเงิน', '#2463d4', '#e5edfc' ),
		'indigo'   => array( 'คราม', '#4f46e5', '#ecebfd' ),
		'lavender' => array( 'ม่วง', '#8a5cd6', '#f2ecfd' ),
		'pink'     => array( 'ชมพู', '#d9468f', '#fde9f3' ),
		'rose'     => array( 'กุหลาบ', '#e63b5c', '#feebef' ),
		'red'      => array( 'แดง', '#d63031', '#fde8e8' ),
		'orange'   => array( 'ส้ม', '#ea6a12', '#fff0e4' ),
		'amber'    => array( 'เหลืองทอง', '#c98a00', '#fff5d6' ),
		'slate'    => array( 'เทา', '#4b5f66', '#eef2f3' ),
	);
}

/** ตัวเลือกรูปแบบ: key => [ค่าที่ใช้ได้ => ชื่อ] (ค่าแรกเป็นค่าเริ่มต้น) */
function idw_svc_options() {
	return array(
		'layout' => array( 'stack' => 'ไอคอนด้านบน', 'center' => 'กึ่งกลาง', 'row' => 'ไอคอนด้านข้าง' ),
		'card'   => array( 'border' => 'เส้นขอบ', 'shadow' => 'เงา', 'tint' => 'พื้นสีอ่อน', 'plain' => 'ไม่มีกรอบ' ),
		'style'  => array( 'soft' => 'พื้นอ่อน', 'solid' => 'พื้นเข้ม', 'outline' => 'เส้นขอบ', 'plain' => 'ไอคอนอย่างเดียว' ),
		'size'   => array( 'm' => 'กลาง', 's' => 'เล็ก', 'l' => 'ใหญ่' ),
		'bg'     => array( 'light' => 'เทาอ่อน', 'white' => 'ขาว', 'none' => 'โปร่งใส', 'brand' => 'สีหลักของเว็บ' ),
		'ratio'  => array( '16/10' => '16:10', '4/3' => '4:3', '1/1' => '1:1', '16/9' => '16:9', '3/4' => '3:4 แนวตั้ง', 'auto' => 'ตามรูปจริง' ),
		'fit'    => array( 'cover' => 'เต็มกรอบ (ตัดขอบ)', 'contain' => 'เห็นทั้งรูป' ),
		'tsize'  => array( 'm' => 'ปกติ', 's' => 'เล็ก', 'l' => 'ใหญ่' ),
		'radius' => array( '16' => 'โค้ง', '8' => 'โค้งน้อย', '24' => 'โค้งมาก', '0' => 'เหลี่ยม' ),
	);
}

function idw_svc_t2( $th, $en = '' ) {
	return array( 'th' => $th, 'en' => $en );
}

/** การ์ดจากตาราง [icon, tone, ชื่อไทย, ชื่ออังกฤษ, คำอธิบายไทย, คำอธิบายอังกฤษ, url, ข้อความลิงก์ {th,en}] */
function idw_svc_rows( $rows ) {
	$items = array();
	foreach ( $rows as $r ) {
		$items[] = array( 'icon' => $r[0], 'tone' => $r[1], 'title' => idw_svc_t2( $r[2], $r[3] ), 'text' => idw_svc_t2( $r[4], $r[5] ), 'url' => $r[6], 'link' => $r[7] ?? idw_svc_t2( '' ), 'on' => true );
	}
	return $items;
}

/** บริการทั่วไปของโรงพยาบาล (ชุดเริ่มต้น) */
function idw_svc_default_items() {
	$c    = function ( $q ) {
		return '/doctor-schedule/?clinic=' . rawurlencode( $q );
	};
	$link = idw_svc_t2( 'ดูตารางออกตรวจ', 'Clinic schedule' );
	return idw_svc_rows( array(
		array( 'emergency', 'rose', 'อุบัติเหตุและฉุกเฉิน 24 ชม.', 'Emergency 24/7', 'ห้องฉุกเฉินพร้อมทีมแพทย์ พยาบาล และรถพยาบาลตลอด 24 ชั่วโมง โทร 1669', 'Emergency room, doctors, nurses and ambulance around the clock. Call 1669.', 'tel:1669', idw_svc_t2( 'โทร 1669', 'Call 1669' ) ),
		array( 'stethoscope', 'mint', 'ผู้ป่วยนอก / ตรวจโรคทั่วไป', 'Outpatient & general clinic', 'ตรวจรักษาโรคทั่วไป คัดกรอง และส่งต่อแพทย์เฉพาะทาง ในเวลาราชการ', 'General check-ups, screening and specialist referral during office hours.', $c( 'ทั่วไป' ), $link ),
		array( 'thermometer', 'sky', 'อายุรกรรม', 'Internal medicine', 'เบาหวาน ความดัน โรคหัวใจ โรคไต และโรคเรื้อรังอื่น ๆ', 'Diabetes, hypertension, heart, kidney and other chronic diseases.', $c( 'อายุรกรรม' ), $link ),
		array( 'bone', 'orange', 'ศัลยกรรม / ศัลยกรรมกระดูก', 'Surgery & orthopaedics', 'ผ่าตัดทั่วไป กระดูกและข้อ อุบัติเหตุ พร้อมห้องผ่าตัดและวิสัญญี', 'General surgery, bones and joints, trauma, with operating theatres and anaesthesia.', $c( 'ศัลยกรรม' ), $link ),
		array( 'pregnant', 'pink', 'สูติ-นรีเวชกรรม', 'Obstetrics & gynaecology', 'ฝากครรภ์ ห้องคลอด ตรวจภายใน และดูแลสุขภาพสตรี', 'Antenatal care, delivery room and women’s health.', $c( 'สูติ' ), $link ),
		array( 'baby', 'amber', 'กุมารเวชกรรม', 'Paediatrics', 'ดูแลเด็กป่วย วัคซีน ตรวจพัฒนาการ และทารกแรกเกิด', 'Sick children, vaccines, development checks and newborn care.', $c( 'กุมาร' ), $link ),
		array( 'eye', 'indigo', 'จักษุ / หู คอ จมูก', 'Eye & ENT', 'ตรวจรักษาโรคตา ต้อกระจก และโรคหู คอ จมูก', 'Eye diseases, cataract, and ear, nose and throat care.', $c( 'ตา' ), $link ),
		array( 'tooth', 'teal', 'ทันตกรรม', 'Dental care', 'ตรวจฟัน ขูดหินปูน อุดฟัน ถอนฟัน และทันตกรรมเฉพาะทาง', 'Check-ups, scaling, fillings, extractions and specialist dentistry.', $c( 'ทันต' ), $link ),
		array( 'leaf', 'green', 'แพทย์แผนไทย', 'Thai traditional medicine', 'นวด ประคบ อบสมุนไพร และยาสมุนไพร', 'Massage, herbal compress, herbal sauna and herbal medicine.', $c( 'แผนไทย' ), $link ),
		array( 'xray', 'blue', 'รังสีวิทยาและห้องปฏิบัติการ', 'Radiology & laboratory', 'เอกซเรย์ อัลตราซาวด์ และตรวจทางห้องปฏิบัติการ', 'X-ray, ultrasound and laboratory tests.', '', idw_svc_t2( '' ) ),
		array( 'wheelchair', 'lavender', 'เวชกรรมฟื้นฟู / กายภาพบำบัด', 'Rehabilitation', 'กายภาพบำบัด ฟื้นฟูผู้ป่วยหลังผ่าตัด และผู้ป่วยโรคหลอดเลือดสมอง', 'Physiotherapy and rehabilitation after surgery or stroke.', $c( 'กายภาพ' ), $link ),
		array( 'star', 'amber', 'คลินิกพิเศษนอกเวลาราชการ', 'After-hours special clinic', 'พบแพทย์เฉพาะทางนอกเวลาราชการ — แก้วันและเวลาให้ตรงกับของโรงพยาบาล', 'See a specialist after office hours — edit the days and times.', $c( 'นอกเวลา' ), $link ),
	) );
}

/** สีที่ปรับได้: key => ชื่อ ('' = ตามธีม / ค่าเริ่มต้น) */
function idw_svc_color_keys() {
	return array(
		'kicker'  => 'ข้อความเล็กด้านบน',
		'title'   => 'หัวข้อ',
		'lead'    => 'คำอธิบายหัวข้อ',
		'name'    => 'ชื่อการ์ด',
		'text'    => 'ข้อความในการ์ด',
		'link'    => 'ลิงก์ในการ์ด',
		'card'    => 'พื้นการ์ด',
		'line'    => 'เส้นขอบการ์ด',
		'section' => 'พื้นหลังส่วน',
		'button'  => 'ปุ่ม “ดูทั้งหมด”',
	);
}

/** แม่แบบสำหรับสร้างชุดใหม่: key => [ชื่อ, คำอธิบาย, ข้อมูลชุด] */
function idw_svc_templates() {
	return array(
		'services' => array( 'บริการทางการแพทย์', 'คลินิกและบริการ 12 รายการ พร้อมคำอธิบายและลิงก์ตารางแพทย์', array(
			'name' => 'บริการทางการแพทย์', 'kicker' => idw_svc_t2( 'OUR SERVICES', 'OUR SERVICES' ), 'title' => idw_svc_t2( 'บริการทางการแพทย์', 'Our services' ),
			'columns' => 4, 'layout' => 'stack', 'card' => 'border', 'style' => 'soft', 'size' => 'm', 'bg' => 'light', 'items' => idw_svc_default_items(),
		) ),
		'quick' => array( 'ลิงก์ด่วน', 'ปุ่มไอคอนใหญ่กึ่งกลาง เช่น นัดหมาย ตารางแพทย์ ลงทะเบียน', array(
			'name' => 'ลิงก์ด่วน', 'kicker' => idw_svc_t2( '' ), 'title' => idw_svc_t2( 'บริการออนไลน์', 'Online services' ),
			'columns' => 6, 'layout' => 'center', 'card' => 'shadow', 'style' => 'solid', 'size' => 'l', 'bg' => 'white',
			'items' => idw_svc_rows( array(
				array( 'calendar', 'mint', 'นัดหมายออนไลน์', 'Book an appointment', '', '', '/appointment/' ),
				array( 'clock', 'sky', 'ตารางแพทย์ออกตรวจ', 'Doctor schedule', '', '', '/doctor-schedule/' ),
				array( 'idcard', 'indigo', 'ลงทะเบียนผู้ป่วยใหม่', 'New patient', '', '', '/registration/' ),
				array( 'news', 'orange', 'ข่าวประชาสัมพันธ์', 'News', '', '', '/news/' ),
				array( 'chat', 'pink', 'ร้องเรียน / เสนอแนะ', 'Feedback', '', '', '/contact/' ),
				array( 'phone', 'teal', 'ติดต่อเรา', 'Contact us', '', '', '/contact/' ),
			) ),
		) ),
		'contact' => array( 'ช่องทางติดต่อ', 'การ์ดแนวนอน ไอคอนด้านข้าง เช่น โทรศัพท์ LINE อีเมล แผนที่', array(
			'name' => 'ช่องทางติดต่อ', 'kicker' => idw_svc_t2( 'CONTACT', 'CONTACT' ), 'title' => idw_svc_t2( 'ช่องทางติดต่อ', 'Contact us' ),
			'columns' => 4, 'layout' => 'row', 'card' => 'tint', 'style' => 'solid', 'size' => 'm', 'bg' => 'none',
			'items' => idw_svc_rows( array(
				array( 'phone', 'teal', 'โทรศัพท์', 'Phone', '0 0000 0000 (ตลอด 24 ชั่วโมง)', '+66 0 0000 0000 (24 hours)', 'tel:000000000' ),
				array( 'chat', 'green', 'LINE Official', 'LINE Official', '@ชื่อบัญชี', '@account', '' ),
				array( 'megaphone', 'blue', 'Facebook', 'Facebook', 'เพจของหน่วยงาน', 'Our page', '' ),
				array( 'pin', 'rose', 'แผนที่ / การเดินทาง', 'Map & directions', 'ดูเส้นทางมาที่หน่วยงาน', 'Get directions', '/contact/' ),
			) ),
		) ),
		'blank' => array( 'ชุดว่าง', 'เริ่มจากการ์ดเปล่า 3 ใบ', array(
			'name' => 'ชุดการ์ดใหม่', 'title' => idw_svc_t2( 'หัวข้อ', 'Heading' ), 'columns' => 3,
			'items' => idw_svc_rows( array( array( 'plus', 'mint', 'การ์ดที่ 1', '', '', '', '' ), array( 'star', 'sky', 'การ์ดที่ 2', '', '', '', '' ), array( 'heart', 'pink', 'การ์ดที่ 3', '', '', '', '' ) ) ),
		) ),
	);
}

/** ชุดตามแม่แบบ */
function idw_svc_from_template( $key, $id = '' ) {
	$t = idw_svc_templates();
	$s = ( $t[ $key ] ?? $t['blank'] )[2];
	return idw_svc_clean( $s, $id ? $id : ( 'services' === $key ? 'services' : $key ) );
}

/** ตรวจและทำความสะอาดข้อมูลชุดการ์ดทุกช่อง */
function idw_svc_clean( $d, $id = '' ) {
	$icons = idw_svc_icon_set();
	$tones = idw_svc_tones();
	$opts  = idw_svc_options();
	$tx    = function ( $v, $multi = false ) {
		$v = is_array( $v ) ? $v : array( 'th' => (string) $v, 'en' => '' );
		$f = $multi ? 'sanitize_textarea_field' : 'sanitize_text_field';
		return array( 'th' => $f( (string) ( $v['th'] ?? '' ) ), 'en' => $f( (string) ( $v['en'] ?? '' ) ) );
	};
	$url   = function ( $u ) {
		$u = trim( (string) $u );
		if ( '' === $u ) {
			return '';
		}
		if ( ( '/' === $u[0] && 0 !== strpos( $u, '//' ) ) || '#' === $u[0] || '{' === $u[0] ) {
			return preg_match( '/^[^\s<>"\']+$/', $u ) ? $u : '';
		}
		return esc_url_raw( $u, array( 'http', 'https', 'tel', 'mailto', 'line' ) );
	};
	$opt   = function ( $k, $v ) use ( $opts ) {
		return (string) ( isset( $opts[ $k ][ $v ] ) ? $v : array_key_first( $opts[ $k ] ) );
	};
	$style = (string) ( $d['style'] ?? ( $d['iconStyle'] ?? '' ) );
	$style = 'gradient' === $style ? 'solid' : $style;
	$id    = sanitize_key( $id ? $id : ( $d['id'] ?? '' ) );
	$out   = array(
		'id'      => $id ? $id : 'set' . wp_rand( 100, 999 ),
		'name'    => sanitize_text_field( (string) ( $d['name'] ?? '' ) ),
		'kicker'  => $tx( $d['kicker'] ?? '' ),
		'title'   => $tx( $d['title'] ?? '' ),
		'lead'    => $tx( $d['lead'] ?? '', true ),
		'columns' => max( 1, min( 6, (int) ( $d['columns'] ?? 4 ) ) ),
		'layout'  => $opt( 'layout', (string) ( $d['layout'] ?? ( 'center' === ( $d['align'] ?? '' ) ? 'center' : '' ) ) ),
		'card'    => $opt( 'card', (string) ( $d['card'] ?? '' ) ),
		'style'   => $opt( 'style', $style ),
		'size'    => $opt( 'size', (string) ( $d['size'] ?? array( 'large' => 'l', 'xl' => 'l' )[ $d['iconSize'] ?? '' ] ?? '' ) ),
		'bg'      => $opt( 'bg', (string) ( $d['bg'] ?? '' ) ),
		'ratio'   => $opt( 'ratio', (string) ( $d['ratio'] ?? '' ) ),
		'fit'     => $opt( 'fit', (string) ( $d['fit'] ?? '' ) ),
		'tsize'   => $opt( 'tsize', (string) ( $d['tsize'] ?? '' ) ),
		'radius'  => $opt( 'radius', (string) ( $d['radius'] ?? '' ) ),
		'colors'  => array(),
		'more'    => array( 'url' => $url( $d['more']['url'] ?? '' ), 'label' => $tx( $d['more']['label'] ?? '' ) ),
		'items'   => array(),
	);
	foreach ( array_keys( idw_svc_color_keys() ) as $k ) {
		$out['colors'][ $k ] = (string) sanitize_hex_color( (string) ( $d['colors'][ $k ] ?? '' ) );
	}
	if ( '' === $out['name'] ) {
		$out['name'] = $out['title']['th'] ? $out['title']['th'] : 'ชุดการ์ด';
	}
	foreach ( array_slice( (array) ( $d['items'] ?? array() ), 0, 60 ) as $it ) {
		if ( ! is_array( $it ) ) {
			continue;
		}
		$img_id = (int) ( $it['imageId'] ?? 0 );
		$img    = (string) ( $it['image'] ?? '' );
		if ( ctype_digit( $img ) ) {
			$img_id = (int) $img;
			$img    = '';
		}
		if ( $img_id && 'attachment' === get_post_type( $img_id ) ) {
			$img = (string) wp_get_attachment_image_url( $img_id, 'medium_large' );
		} else {
			$img_id = 0;
		}
		$icon           = (string) ( $it['icon'] ?? 'plus' );
		$out['items'][] = array(
			'icon'      => '' === $icon || 'none' === $icon ? '' : ( isset( $icons[ $icon ] ) ? $icon : 'plus' ),
			'tone'      => isset( $tones[ $it['tone'] ?? '' ] ) ? $it['tone'] : 'mint',
			'image'     => esc_url_raw( $img ),
			'imageId'   => $img_id,
			'imageMode' => 'icon' === ( $it['imageMode'] ?? '' ) ? 'icon' : 'cover',
			'pos'       => in_array( $it['pos'] ?? '', array( 'top', 'bottom', 'left', 'right' ), true ) ? $it['pos'] : 'center',
			'color'     => (string) sanitize_hex_color( (string) ( $it['color'] ?? '' ) ),
			'title'     => $tx( $it['title'] ?? '' ),
			'text'      => $tx( $it['text'] ?? '', true ),
			'url'       => $url( $it['url'] ?? '' ),
			'link'      => $tx( $it['link'] ?? ( $it['linkText'] ?? '' ) ),
			'on'        => ! isset( $it['on'] ) || ! empty( $it['on'] ),
		);
	}
	return $out;
}

/** ทุกชุด (เรียงตามที่ตั้งไว้) · ข้อมูลรุ่น 1.0.4 (ชุดเดียว) ถูกแปลงเป็นชุด “services” */
function idw_svc_sets() {
	$o = get_option( 'idw_services' );
	if ( ! is_array( $o ) ) {
		return array( idw_svc_from_template( 'services' ) );
	}
	if ( isset( $o['items'] ) && ! isset( $o['sets'] ) ) {
		$o['name'] = 'บริการทางการแพทย์';
		return array( idw_svc_clean( $o, 'services' ) );
	}
	$sets = array();
	foreach ( (array) ( $o['sets'] ?? array() ) as $s ) {
		if ( is_array( $s ) && ! empty( $s['id'] ) ) {
			$sets[] = $s; // cleaned when saved
		}
	}
	return $sets ? $sets : array( idw_svc_from_template( 'services' ) );
}

/** ชุดตาม id ('' = ชุด services หรือชุดแรก) */
function idw_svc_get( $id = '' ) {
	$sets = idw_svc_sets();
	foreach ( $sets as $s ) {
		if ( $s['id'] === $id ) {
			return $s;
		}
	}
	if ( '' !== $id ) {
		return null;
	}
	foreach ( $sets as $s ) {
		if ( 'services' === $s['id'] ) {
			return $s;
		}
	}
	return $sets[0];
}
/** เดิม: ข้อมูลชุดบริการ */
function idw_svc_data() {
	return idw_svc_get( '' );
}

function idw_svc_store( $sets ) {
	update_option( 'idw_services', array( 'v' => 2, 'sets' => array_values( $sets ) ), false );
	do_action( 'litespeed_purge_all' );
}

/** บันทึก / เพิ่มชุด (แทนชุดที่ id ตรงกัน) */
function idw_svc_put( $set ) {
	$sets = idw_svc_sets();
	$set  = idw_svc_clean( $set );
	$done = false;
	foreach ( $sets as $i => $s ) {
		if ( $s['id'] === $set['id'] ) {
			$sets[ $i ] = $set;
			$done       = true;
		}
	}
	if ( ! $done ) {
		$sets[] = $set;
	}
	idw_svc_store( $sets );
	return $set;
}

/** id ใหม่ที่ไม่ซ้ำ */
function idw_svc_new_id( $base ) {
	$base = sanitize_key( remove_accents( (string) $base ) );
	$base = $base ? substr( $base, 0, 20 ) : 'cards';
	$ids  = wp_list_pluck( idw_svc_sets(), 'id' );
	$id   = $base;
	for ( $n = 2; in_array( $id, $ids, true ); $n++ ) {
		$id = $base . '-' . $n;
	}
	return $id;
}

/** รายชื่อชุดสำหรับตัวเลือก: [ [id, name, จำนวนการ์ด] ] */
function idw_svc_set_list() {
	$out = array();
	foreach ( idw_svc_sets() as $s ) {
		$out[] = array( 'id' => $s['id'], 'name' => $s['name'], 'n' => count( $s['items'] ) );
	}
	return $out;
}
