/* หน้าแก้ไข “การ์ดบริการ”: ชุดการ์ด · การ์ด (ไอคอน / รูป / สี / ไทย-อังกฤษ / ลิงก์) · รูปแบบ · สี · ตัวอย่างสดจากตัวแสดงผลจริง */
( function ( $ ) {
	var S = window.IDW_SVC; if ( ! S ) return;
	var data = JSON.parse( JSON.stringify( S.data ) ), dirty = false, pvLang = 'th', pvSize = 'desk', open = {}, popFor = null, pvTimer = 0, pvReq = null;
	var $list = $( '#svc-list' ), $pv = $( '#svc-pv' ), $pop = $( '#svc-pop' ).appendTo( document.body );
	data.colors = data.colors || {}; data.more = data.more || { url: '', label: { th: '', en: '' } };

	function esc( s ) { return String( s == null ? '' : s ).replace( /[&<>"']/g, function ( c ) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ]; } ); }
	function icon( k ) { if ( ! k ) return '<span class="svc-noico">–</span>'; var i = S.icons[ k ] || S.icons.plus; return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + i[ 1 ] + '</svg>'; }
	function toneVars( it ) { if ( it.color ) return { '--tone': it.color, '--tone-bg': it.color + '22' }; var t = S.tones[ it.tone ] || S.tones.mint; return { '--tone': t[ 1 ], '--tone-bg': t[ 2 ] }; }
	function styleStr( o ) { return $.map( o, function ( v, k ) { return k + ':' + v; } ).join( ';' ); }
	function blank() { return { icon: 'plus', tone: 'mint', color: '', image: '', imageId: 0, imageMode: 'cover', pos: 'center', title: { th: '', en: '' }, text: { th: '', en: '' }, url: '', link: { th: '', en: '' }, on: true }; }
	function touch( now ) { dirty = true; $( '#svc-msg' ).text( 'มีการแก้ไขที่ยังไม่บันทึก' ).addClass( 'warn' ); preview( now ); }

	/* ---------- set header, style options, colours ---------- */
	function head() {
		$( '[data-h]' ).each( function () { this.value = ( data[ this.dataset.h ] || {} )[ this.dataset.l ] || ''; } );
		$( '[data-o="name"]' ).val( data.name );
		$( '[data-o="columns"]' ).val( String( data.columns ) );
		$( '[data-m="url"]' ).val( data.more.url || '' );
		$( '[data-m="label"]' ).each( function () { this.value = ( data.more.label || {} )[ this.dataset.l ] || ''; } );
		$( '.svc-seg[data-o]' ).each( function () { var o = this.dataset.o; $( this ).find( 'button' ).each( function () { $( this ).toggleClass( 'on', this.dataset.v === String( data[ o ] ) ); } ); } );
		$( '[data-c]' ).each( function () { var v = data.colors[ this.dataset.c ] || ''; this.value = v || '#ffffff'; $( this ).closest( '.svc-color' ).toggleClass( 'is-set', !! v ); } );
	}
	$( document ).on( 'input', '[data-h]', function () { var h = this.dataset.h; data[ h ] = data[ h ] || { th: '', en: '' }; data[ h ][ this.dataset.l ] = this.value; touch(); } );
	$( '[data-o="name"]' ).on( 'input', function () { data.name = this.value; $( '.svc-set.on b' ).text( this.value || '…' ); touch(); } );
	$( '[data-o="columns"]' ).on( 'change', function () { data.columns = +this.value; touch( 1 ); } );
	$( '[data-m]' ).on( 'input', function () { if ( this.dataset.m === 'url' ) data.more.url = this.value; else { data.more.label = data.more.label || {}; data.more.label[ this.dataset.l ] = this.value; } touch(); } );
	$( document ).on( 'click', '.svc-seg[data-o] button', function () { var o = $( this ).closest( '.svc-seg' ).data( 'o' ); data[ o ] = this.dataset.v; head(); touch( 1 ); } );
	$( '[data-c]' ).on( 'input', function () { data.colors[ this.dataset.c ] = this.value; $( this ).closest( '.svc-color' ).addClass( 'is-set' ); touch(); } );
	$( '[data-c-clear]' ).on( 'click', function () { data.colors[ this.dataset.cClear ] = ''; head(); touch( 1 ); } );
	$( '#svc-pv-lang button' ).on( 'click', function () { pvLang = this.dataset.v; $( this ).addClass( 'on' ).siblings().removeClass( 'on' ); preview( 1 ); } );
	$( '#svc-pv-size button' ).on( 'click', function () { pvSize = this.dataset.v; $( this ).addClass( 'on' ).siblings().removeClass( 'on' ); fit(); } );
	$( '#svc-copy' ).on( 'click', function () { var t = $( '#svc-code' ).text(); if ( navigator.clipboard ) navigator.clipboard.writeText( t ); $( this ).addClass( 'done' ); } );

	/* ---------- card list ---------- */
	function swatches( it ) {
		var h = '';
		$.each( S.tones, function ( k, v ) { h += '<button type="button" class="svc-sw' + ( k === it.tone && ! it.color ? ' on' : '' ) + '" data-tone="' + k + '" title="' + esc( v[ 0 ] ) + '" style="--tone:' + v[ 1 ] + ';--tone-bg:' + v[ 2 ] + '"></button>'; } );
		return h + '<label class="svc-sw-custom' + ( it.color ? ' on' : '' ) + '" title="เลือกสีเอง"><input type="color" data-k="color" value="' + esc( it.color || '#13a383' ) + '"><span class="dashicons dashicons-art"></span></label>';
	}
	function field( i, key, l, label, multi, extra ) {
		var it = data.items[ i ], v = ( key === 'url' ) ? it.url : ( it[ key ] || {} )[ l ] || '';
		var a = ' class="idw-in" data-k="' + key + '"' + ( l ? ' data-l="' + l + '"' : '' ) + ( extra || '' );
		return '<label class="idw-field">' + label + ( multi ? '<textarea rows="2"' + a + '>' + esc( v ) + '</textarea>' : '<input' + a + ' value="' + esc( v ) + '">' ) + '</label>';
	}
	function select( key, val, opts, label ) {
		return '<label class="idw-field">' + label + '<select class="idw-in" data-k="' + key + '">' + opts.map( function ( o ) { return '<option value="' + o[ 0 ] + '"' + ( o[ 0 ] === val ? ' selected' : '' ) + '>' + o[ 1 ] + '</option>'; } ).join( '' ) + '</select></label>';
	}
	function head_ico( it ) {
		if ( it.image ) return '<span class="svc-ico-btn is-img" data-act="image" title="เปลี่ยนรูป"><img src="' + esc( it.image ) + '" alt=""></span>';
		return '<button type="button" class="svc-ico-btn" data-act="icon" title="เปลี่ยนไอคอน" style="' + styleStr( toneVars( it ) ) + '">' + icon( it.icon ) + '</button>';
	}
	function row( it, i ) {
		var h = '<div class="svc-item' + ( it.on ? '' : ' off' ) + ( open[ i ] ? ' open' : '' ) + '" data-i="' + i + '">';
		h += '<div class="svc-item-h"><span class="svc-drag dashicons dashicons-menu" title="ลากเพื่อเรียง"></span>' + head_ico( it );
		h += '<button type="button" class="svc-item-name" data-act="toggle"><b>' + ( esc( it.title.th ) || '<i>การ์ดใหม่ — ใส่ชื่อ</i>' ) + '</b><small>' + esc( it.title.en || '' ) + '</small></button>';
		h += '<label class="svc-switch" title="แสดง / ซ่อนการ์ดนี้"><input type="checkbox" data-act="on"' + ( it.on ? ' checked' : '' ) + '><span></span></label>';
		h += '<button type="button" class="svc-mini" data-act="dup" title="ทำสำเนา"><span class="dashicons dashicons-admin-page"></span></button>';
		h += '<button type="button" class="svc-mini del" data-act="del" title="ลบการ์ด"><span class="dashicons dashicons-trash"></span></button>';
		h += '<button type="button" class="svc-mini" data-act="toggle" title="แก้ไข"><span class="dashicons dashicons-arrow-down-alt2"></span></button></div>';
		h += '<div class="svc-item-b">';
		/* picture: icon or image */
		h += '<div class="svc-pic"><div class="svc-pic-icon"><span class="svc-lbl">ไอคอน</span><button type="button" class="svc-ico-btn big" data-act="icon" style="' + styleStr( toneVars( it ) ) + '">' + icon( it.icon ) + '</button><button type="button" class="svc-link" data-act="noicon">' + ( it.icon ? 'ไม่ใช้ไอคอน' : '' ) + '</button></div>';
		h += '<div class="svc-pic-img"><span class="svc-lbl">รูป (ไม่ใส่ก็ได้)</span>' + ( it.image ? '<span class="svc-thumb" style="object-position:' + it.pos + '"><img src="' + esc( it.image ) + '" alt="" style="object-position:' + it.pos + '"></span>' : '' );
		h += '<span class="svc-pic-btns"><button type="button" class="idw-btn sm" data-act="image">' + ( it.image ? 'เปลี่ยนรูป' : 'เลือกรูป' ) + '</button>' + ( it.image ? '<button type="button" class="idw-btn sm link" data-act="noimage">เอารูปออก</button>' : '' ) + '</span>';
		if ( it.image ) h += '<div class="svc-2col tight">' + select( 'imageMode', it.imageMode, [ [ 'cover', 'รูปเต็มด้านบนการ์ด' ], [ 'icon', 'รูปเล็กแทนไอคอน' ] ], 'แสดงรูปแบบ' ) + select( 'pos', it.pos, [ [ 'center', 'กลาง' ], [ 'top', 'บน' ], [ 'bottom', 'ล่าง' ], [ 'left', 'ซ้าย' ], [ 'right', 'ขวา' ] ], 'จุดโฟกัสของรูป' ) + '</div>';
		h += '</div></div>';
		h += '<div class="svc-tones"><span>สี</span>' + swatches( it ) + '</div>';
		h += '<div class="svc-2col"><div>' + field( i, 'title', 'th', 'ชื่อ (ไทย)' ) + field( i, 'text', 'th', 'คำอธิบาย (ไทย)', true ) + '</div>';
		h += '<div>' + field( i, 'title', 'en', 'Name (English)' ) + field( i, 'text', 'en', 'Text (English)', true ) + '</div></div>';
		h += '<div class="svc-3col">' + field( i, 'url', '', 'ลิงก์ (เว้นว่าง = ไม่มีลิงก์)', false, ' list="svc-pages" placeholder="/doctor-schedule/ · tel:1669 · https://…"' ) + field( i, 'link', 'th', 'ข้อความลิงก์ (ไทย)', false, ' placeholder="ว่าง = ทั้งการ์ดกดได้"' ) + field( i, 'link', 'en', 'Link text (English)', false, ' placeholder="Learn more"' ) + '</div></div></div>';
		return h;
	}
	function list() {
		$list.html( data.items.map( row ).join( '' ) || '<div class="svc-none">ยังไม่มีการ์ด — กด “เพิ่มการ์ด”</div>' );
		var on = data.items.filter( function ( x ) { return x.on; } ).length;
		$( '#svc-count' ).text( data.items.length + ' การ์ด · แสดง ' + on );
	}
	function redraw( i ) { $list.children( '.svc-item[data-i="' + i + '"]' ).replaceWith( row( data.items[ i ], i ) ); }
	$list.sortable( { handle: '.svc-drag', items: '.svc-item', placeholder: 'svc-ph', forcePlaceholderSize: true, update: function () {
		var order = $list.children( '.svc-item' ).map( function () { return +this.dataset.i; } ).get(), o2 = {};
		data.items = order.map( function ( k, n ) { if ( open[ k ] ) o2[ n ] = 1; return data.items[ k ]; } );
		open = o2; list(); touch( 1 );
	} } );
	$list.on( 'input change', '[data-k]', function ( e ) {
		var i = +$( this ).closest( '.svc-item' ).data( 'i' ), k = this.dataset.k, it = data.items[ i ];
		if ( this.tagName === 'SELECT' || k === 'color' ) { if ( e.type !== ( k === 'color' ? 'input' : 'change' ) ) return; }
		else if ( e.type !== 'input' ) return;
		if ( k === 'url' || k === 'imageMode' || k === 'pos' ) it[ k ] = this.value;
		else if ( k === 'color' ) { it.color = this.value; $( this ).closest( '.svc-tones' ).find( '.svc-sw' ).removeClass( 'on' ); $( this ).parent().addClass( 'on' ); $( this ).closest( '.svc-item' ).find( '.svc-ico-btn' ).css( toneVars( it ) ); }
		else { it[ k ] = it[ k ] || { th: '', en: '' }; it[ k ][ this.dataset.l ] = this.value; }
		if ( k === 'title' ) { var $h = $( this ).closest( '.svc-item' ).find( '.svc-item-name' ); $h.find( 'b' ).html( esc( it.title.th ) || '<i>การ์ดใหม่ — ใส่ชื่อ</i>' ); $h.find( 'small' ).text( it.title.en || '' ); }
		if ( k === 'pos' ) $( this ).closest( '.svc-item' ).find( '.svc-thumb img' ).css( 'object-position', this.value );
		touch( this.tagName === 'SELECT' );
	} );
	$list.on( 'click change', '[data-act]', function ( e ) {
		var act = this.dataset.act, $it = $( this ).closest( '.svc-item' ), i = +$it.data( 'i' ), it = data.items[ i ];
		if ( ( act === 'on' ) !== ( e.type === 'change' ) ) return;
		if ( act === 'toggle' ) { open[ i ] = ! open[ i ]; $it.toggleClass( 'open', !! open[ i ] ); return; }
		if ( act === 'icon' ) { e.stopPropagation(); return showPop( i, this ); }
		if ( act === 'image' ) return pickImage( i );
		if ( act === 'noimage' ) { it.image = ''; it.imageId = 0; redraw( i ); }
		if ( act === 'noicon' ) { it.icon = ''; redraw( i ); }
		if ( act === 'on' ) { it.on = this.checked; $it.toggleClass( 'off', ! this.checked ); list(); }
		if ( act === 'dup' ) { data.items.splice( i + 1, 0, JSON.parse( JSON.stringify( it ) ) ); shiftOpen( i + 1, 1 ); open[ i + 1 ] = 1; list(); }
		if ( act === 'del' ) { if ( ! window.confirm( 'ลบการ์ด “' + ( it.title.th || 'ไม่มีชื่อ' ) + '” ?' ) ) return; data.items.splice( i, 1 ); shiftOpen( i, -1 ); list(); }
		touch( 1 );
	} );
	$list.on( 'click', '.svc-sw', function () {
		var i = +$( this ).closest( '.svc-item' ).data( 'i' ), it = data.items[ i ];
		it.tone = this.dataset.tone; it.color = '';
		$( this ).addClass( 'on' ).siblings().removeClass( 'on' );
		$( this ).closest( '.svc-item' ).find( '.svc-ico-btn' ).css( toneVars( it ) );
		touch();
	} );
	function shiftOpen( from, d ) { var o2 = {}; $.each( open, function ( k, v ) { k = +k; if ( k < from ) o2[ k ] = v; else if ( k + d >= from ) o2[ k + d ] = v; } ); open = o2; }

	function pickImage( i ) {
		if ( ! window.wp || ! wp.media ) return;
		var f = wp.media( { title: 'เลือกรูปสำหรับการ์ด', button: { text: 'ใช้รูปนี้' }, library: { type: 'image' }, multiple: false } );
		f.on( 'select', function () {
			var a = f.state().get( 'selection' ).first().toJSON(), s = a.sizes || {};
			var it = data.items[ i ]; it.imageId = a.id; it.image = ( s.medium_large || s.large || s.full || a ).url; it.imageMode = it.imageMode || 'cover';
			open[ i ] = 1; redraw( i ); touch( 1 );
		} );
		f.open();
	}

	$( '#svc-add' ).on( 'click', function () {
		data.items.push( blank() ); open[ data.items.length - 1 ] = 1; list(); touch( 1 );
		var $n = $list.children( '.svc-item' ).last(); $n[ 0 ].scrollIntoView( { behavior: 'smooth', block: 'center' } ); $n.find( '[data-k="title"]' ).first().trigger( 'focus' );
	} );
	$( '#svc-expand' ).on( 'click', function () { var all = Object.keys( open ).length < data.items.length; open = {}; if ( all ) data.items.forEach( function ( x, i ) { open[ i ] = 1; } ); list(); } );
	$( '#svc-reset' ).on( 'click', function () {
		if ( ! S.defaults || ! window.confirm( 'คืนค่าเริ่มต้นของชุดนี้? การ์ด หัวข้อ รูปแบบ และสีที่แก้ไว้จะถูกแทนทั้งหมด (ยังไม่บันทึกจนกว่าจะกดบันทึก)' ) ) return;
		var name = data.name; data = JSON.parse( JSON.stringify( S.defaults ) ); data.name = name; data.colors = data.colors || {}; open = {}; head(); list(); touch( 1 );
	} );

	/* ---------- icon picker ---------- */
	function popGrid( q ) {
		q = ( q || '' ).trim().toLowerCase(); var h = '', cur = popFor != null ? data.items[ popFor ].icon : '';
		$.each( S.icons, function ( k, v ) { if ( q && k.indexOf( q ) < 0 && v[ 0 ].toLowerCase().indexOf( q ) < 0 ) return; h += '<button type="button" data-icon="' + k + '" class="' + ( k === cur ? 'on' : '' ) + '" title="' + esc( v[ 0 ] ) + '">' + icon( k ) + '<span>' + esc( v[ 0 ] ) + '</span></button>'; } );
		$( '#svc-pop-grid' ).html( h || '<p>ไม่พบไอคอน</p>' );
	}
	function showPop( i, btn ) {
		popFor = i; $( '#svc-pop-q' ).val( '' ); popGrid( '' ); $pop.prop( 'hidden', false );
		var r = btn.getBoundingClientRect(); $pop.css( { top: r.bottom + window.scrollY + 6, left: Math.max( 8, Math.min( r.left + window.scrollX, document.documentElement.clientWidth - $pop.outerWidth() - 8 ) ) } );
		$( '#svc-pop-q' ).trigger( 'focus' );
	}
	$( '#svc-pop-q' ).on( 'input', function () { popGrid( this.value ); } );
	$pop.on( 'click', '[data-icon]', function () { var it = data.items[ popFor ]; it.icon = this.dataset.icon; if ( it.image && it.imageMode === 'icon' ) { it.image = ''; it.imageId = 0; } redraw( popFor ); $pop.prop( 'hidden', true ); touch( 1 ); } );
	$( document ).on( 'click', function ( e ) { if ( ! $pop.prop( 'hidden' ) && ! $( e.target ).closest( '#svc-pop' ).length ) $pop.prop( 'hidden', true ); } );
	$( document ).on( 'keydown', function ( e ) { if ( e.key === 'Escape' ) $pop.prop( 'hidden', true ); } );

	/* ---------- live preview: drawn by the site's own renderer ---------- */
	function preview( now ) {
		clearTimeout( pvTimer );
		pvTimer = setTimeout( function () {
			if ( pvReq ) pvReq.abort();
			$pv.addClass( 'loading' );
			pvReq = $.post( S.ajax, { action: 'idw_svc_preview', nonce: S.nonce, lang: pvLang, data: JSON.stringify( data ) } ).done( function ( r ) {
				if ( ! r || ! r.success ) return;
				$pv.html( '<div class="svc-pv-scale">' + r.data.html + '</div>' ).removeClass( 'loading' ); fit(); links( r.data.links || {}, r.data.more );
				$pv.find( 'img' ).on( 'load', fit );
			} );
		}, now ? 0 : 350 );
	}
	/* link check: a card whose link has no page on this site gets a note (visitors never get a 404 from a card) */
	function links( L, more ) {
		var msg = { fixed: 'ไม่มีหน้านี้ — ใช้หน้า', dropped: 'ไม่พบหน้านี้ในเว็บ — การ์ดจะไม่แสดงลิงก์จนกว่าจะสร้างหน้าหรือแก้ลิงก์', missing: 'ไม่พบหน้านี้ในเว็บ — ผู้ชมจะเจอหน้า 404 แก้ลิงก์หรือเลือกจากรายการหน้า' };
		$list.children( '.svc-item' ).each( function () {
			var i = +this.dataset.i, r = L[ i ], $f = $( this ).find( '[data-k="url"]' ).closest( '.idw-field' ), st = r ? r[ 1 ] : 'ok';
			$( this ).toggleClass( 'link-bad', st === 'missing' || st === 'dropped' );
			$f.find( '.svc-linknote' ).remove();
			if ( st !== 'ok' ) $f.append( '<small class="svc-linknote ' + st + '">' + msg[ st ] + ( st === 'fixed' ? ' <code>' + esc( decodeURIComponent( r[ 0 ].replace( S.home, '/' ) ) ) + '</code>' : '' ) + '</small>' );
		} );
		var $m = $( '[data-m="url"]' ).closest( '.idw-field' ); $m.find( '.svc-linknote' ).remove();
		if ( more && more[ 1 ] !== 'ok' ) $m.append( '<small class="svc-linknote ' + more[ 1 ] + '">' + msg[ more[ 1 ] ] + '</small>' );
		var bad = $list.children( '.link-bad' ).length; $( '#svc-count' ).text( data.items.length + ' การ์ด · แสดง ' + data.items.filter( function ( x ) { return x.on; } ).length + ( bad ? ' · ลิงก์ที่ต้องแก้ ' + bad : '' ) );
	}
	/* drawn at the chosen device width, scaled down to fit */
	function fit() {
		var $s = $pv.children( '.svc-pv-scale' ); if ( ! $s.length ) return;
		var w = $pv.width(), base = { desk: 1200, tab: 820, phone: 390 }[ pvSize ], k = Math.min( 1, w / base );
		$s.css( { width: base, transform: 'scale(' + k + ')', marginLeft: base * k < w ? ( w - base * k ) / 2 : 0 } ); $pv.css( 'height', Math.ceil( $s[ 0 ].offsetHeight * k ) );
	}
	$( window ).on( 'resize', fit );

	/* ---------- sets: new panel, delete, save ---------- */
	$( '#svc-new-btn' ).on( 'click', function () { $( '#svc-new' ).prop( 'hidden', false )[ 0 ].scrollIntoView( { behavior: 'smooth', block: 'nearest' } ); } );
	$( '#svc-new-cancel' ).on( 'click', function () { $( '#svc-new' ).prop( 'hidden', true ); } );
	$( '#svc-del-form' ).on( 'submit', function () { var n = +$( this ).data( 'used' ); return window.confirm( 'ลบชุด “' + data.name + '”?' + ( n ? '\nชุดนี้ใช้อยู่ใน ' + n + ' หน้า — ส่วนนั้นจะไม่แสดงการ์ดจนกว่าจะเลือกชุดอื่น' : '' ) ); } );
	$( '#svc-form' ).on( 'submit', function () { $( '#svc-data' ).val( JSON.stringify( data ) ); dirty = false; $( '#svc-save' ).prop( 'disabled', true ).addClass( 'busy' ); } );
	$( '[name="add_home"]' ).on( 'change', function () { if ( this.checked ) { dirty = true; $( '#svc-msg' ).text( 'จะใส่ลงหน้าแรกเมื่อบันทึก' ).addClass( 'warn' ); } } );
	$( '.svc-hub-row' ).on( 'submit', function () { return ! dirty || window.confirm( 'ชุดนี้ยังไม่ได้บันทึก — แปลงต่อโดยไม่บันทึก?' ); } );
	window.addEventListener( 'beforeunload', function ( e ) { if ( dirty ) { e.preventDefault(); e.returnValue = ''; } } );

	head(); list(); preview( 1 );
} )( jQuery );
