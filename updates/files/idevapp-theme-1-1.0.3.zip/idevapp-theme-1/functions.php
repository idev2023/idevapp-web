<?php
/**
 * iDevApp แบบที่ 1 — พัฒนาโดย iDevApp.me
 */
defined( 'ABSPATH' ) || exit;

define( 'HOS_THEME_VER', '1.0.3' );
/** เลขเวอร์ชันไฟล์ = เวลาแก้ไขไฟล์ (กันแคช Cloudflare/LiteSpeed เสิร์ฟไฟล์เก่า) */
function hos_asset_ver( $file ) {
	$f = get_template_directory() . '/assets/' . $file;
	return file_exists( $f ) ? HOS_THEME_VER . '.' . filemtime( $f ) : HOS_THEME_VER;
}

require get_template_directory() . '/inc/content.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/menu.php';
require get_template_directory() . '/inc/idev.php';
require get_template_directory() . '/inc/blocks.php';
require get_template_directory() . '/inc/patterns.php';
require get_template_directory() . '/inc/translate.php';
require get_template_directory() . '/inc/inner.php';
require get_template_directory() . '/inc/design.php';

add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'idevapp-theme-1' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array( 'height' => 120, 'width' => 120, 'flex-width' => true, 'flex-height' => true ) );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	register_nav_menus( array(
		'primary' => 'เมนูหลัก',
		'footer'  => 'เมนูท้ายเว็บ (ลิงก์ด่วน)',
	) );
	add_image_size( 'hos-card', 720, 405, true );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'hos-fonts', hosd_fonts_url(), array(), null );
	wp_enqueue_style( 'hos-theme', get_template_directory_uri() . '/assets/theme.css', array(), hos_asset_ver( 'theme.css' ) );
	wp_enqueue_script( 'hos-theme', get_template_directory_uri() . '/assets/theme.js', array(), hos_asset_ver( 'theme.js' ), true );
	// ไม่โหลด CSS ของ block library ซ้ำซ้อนกับ Elementor เดิม
} );

add_filter( 'body_class', function ( $classes ) {
	$classes[] = 'style-' . hos_style();
	return $classes;
} );

add_action( 'wp_head', function () {
	if ( ! has_site_icon() ) {
		echo '<link rel="icon" type="image/png" href="' . esc_url( get_template_directory_uri() . '/assets/logo.png' ) . '">' . "\n";
	}
}, 2 );

add_filter( 'excerpt_length', function () { return 28; } );
add_filter( 'excerpt_more', function () { return '…'; } );

/** จำนวนรายการต่อหน้าในหน้ารวมเอกสาร */
add_action( 'pre_get_posts', function ( $q ) {
	if ( ! is_admin() && $q->is_main_query() && ( $q->is_archive() || $q->is_search() ) ) {
		$q->set( 'posts_per_page', 20 );
	}
} );

/** ถ้ายังไม่ได้เปิด plugin iDevApp Website ให้ฟังก์ชันที่ theme ใช้ยังทำงานได้ */
if ( ! function_exists( 'hos_get_document_url' ) ) {
	function hos_get_document_url( $post_id = null ) {
		$content = (string) get_post_field( 'post_content', $post_id ? $post_id : get_the_ID() );
		$u = preg_match( '#href=["\']([^"\']+\.(?:pdf|docx?|xlsx?))["\']#i', $content, $m ) ? html_entity_decode( $m[1] ) : '';
		return apply_filters( 'hos_document_url_fallback', $u, $post_id ? $post_id : get_the_ID() );
	}
}
if ( ! function_exists( 'hos_file_ext' ) ) {
	function hos_file_ext( $url ) {
		$path = wp_parse_url( $url, PHP_URL_PATH );
		return $path ? strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) : '';
	}
}
require get_template_directory() . '/inc/slides.php'; // สไลด์หน้าแรก (ใช้ได้โดยไม่ต้องมีปลั๊กอินเสริม)


