<?php
/**
 * เนื้อหาหน้าเว็บแบบแก้ไขได้ตรงหน้า (WYSIWYG) จากบล็อกมาตรฐานของ WordPress
 * + ลงทะเบียนเป็น "ชุดบล็อกสำเร็จรูป" ให้กดแทรกในหน้าใดก็ได้
 */
defined( 'ABSPATH' ) || exit;

// ---------- ตัวช่วยสร้าง markup บล็อก (ตรงกับที่ตัวแก้ไขบันทึก) ----------
function hosb_attrs( $a ) {
	return $a ? ' ' . wp_json_encode( $a, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) : '';
}
function hosb_cls( $base, $a ) {
	$c = array( $base );
	if ( ! empty( $a['align'] ) ) {
		$c[] = 'align' . $a['align'];
	}
	if ( ! empty( $a['className'] ) ) {
		$c[] = $a['className'];
	}
	return trim( implode( ' ', array_filter( $c ) ) );
}
function hosb_p( $html, $class = '' ) {
	$a = $class ? array( 'className' => $class ) : array();
	return '<!-- wp:paragraph' . hosb_attrs( $a ) . ' --><p' . ( $class ? ' class="' . esc_attr( $class ) . '"' : '' ) . '>' . $html . '</p><!-- /wp:paragraph -->';
}
function hosb_h( $text, $level = 2, $class = '' ) {
	$a = array();
	if ( 2 !== $level ) {
		$a['level'] = $level;
	}
	if ( $class ) {
		$a['className'] = $class;
	}
	return '<!-- wp:heading' . hosb_attrs( $a ) . ' --><h' . $level . ' class="' . esc_attr( hosb_cls( 'wp-block-heading', $a ) ) . '">' . $text . '</h' . $level . '><!-- /wp:heading -->';
}
function hosb_group( $inner, $class = '', $align = '', $constrained = false ) {
	$a = array();
	if ( $align ) {
		$a['align'] = $align;
	}
	if ( $class ) {
		$a['className'] = $class;
	}
	if ( $constrained ) {
		$a['layout'] = array( 'type' => 'constrained' );
	}
	return '<!-- wp:group' . hosb_attrs( $a ) . ' --><div class="' . esc_attr( hosb_cls( 'wp-block-group', $a ) ) . '">' . implode( '', (array) $inner ) . '</div><!-- /wp:group -->';
}
function hosb_cols( $cols, $class = '', $align = 'wide' ) {
	$a = array();
	if ( $align ) {
		$a['align'] = $align;
	}
	if ( $class ) {
		$a['className'] = $class;
	}
	$h = '';
	foreach ( $cols as $c ) {
		list( $inner, $width ) = array_pad( (array) $c, 2, '' );
		$ca = $width ? array( 'width' => $width ) : array();
		$h .= '<!-- wp:column' . hosb_attrs( $ca ) . ' --><div class="wp-block-column"' . ( $width ? ' style="flex-basis:' . esc_attr( $width ) . '"' : '' ) . '>' . implode( '', (array) $inner ) . '</div><!-- /wp:column -->';
	}
	return '<!-- wp:columns' . hosb_attrs( $a ) . ' --><div class="' . esc_attr( hosb_cls( 'wp-block-columns', $a ) ) . '">' . $h . '</div><!-- /wp:columns -->';
}
function hosb_btns( $items ) {
	$h = '';
	foreach ( $items as $it ) {
		list( $text, $url, $class ) = array_pad( $it, 3, '' );
		$a  = $class ? array( 'className' => $class ) : array();
		$h .= '<!-- wp:button' . hosb_attrs( $a ) . ' --><div class="' . esc_attr( hosb_cls( 'wp-block-button', $a ) ) . '"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $url ) . '">' . $text . '</a></div><!-- /wp:button -->';
	}
	return '<!-- wp:buttons --><div class="wp-block-buttons">' . $h . '</div><!-- /wp:buttons -->';
}
function hosb_list( $items, $ordered = false ) {
	$h = '';
	foreach ( $items as $i ) {
		$h .= '<!-- wp:list-item --><li>' . $i . '</li><!-- /wp:list-item -->';
	}
	$tag = $ordered ? 'ol' : 'ul';
	return '<!-- wp:list' . ( $ordered ? ' {"ordered":true}' : '' ) . ' --><' . $tag . ' class="wp-block-list">' . $h . '</' . $tag . '><!-- /wp:list -->';
}
function hosb_table( $head, $rows ) {
	$h = '<thead><tr>';
	foreach ( $head as $c ) {
		$h .= '<th>' . $c . '</th>';
	}
	$h .= '</tr></thead><tbody>';
	foreach ( $rows as $r ) {
		$h .= '<tr>';
		foreach ( $r as $c ) {
			$h .= '<td>' . $c . '</td>';
		}
		$h .= '</tr>';
	}
	return '<!-- wp:table --><figure class="wp-block-table"><table class="has-fixed-layout">' . $h . '</tbody></table></figure><!-- /wp:table -->';
}
function hosb_img( $url, $alt, $class = '', $align = '' ) {
	$a = array( 'sizeSlug' => 'full', 'linkDestination' => 'none' );
	if ( $align ) {
		$a['align'] = $align;
	}
	if ( $class ) {
		$a['className'] = $class;
	}
	return '<!-- wp:image' . hosb_attrs( $a ) . ' --><figure class="' . esc_attr( hosb_cls( 'wp-block-image size-full', $a ) ) . '"><img src="' . esc_url( $url ) . '" alt="' . esc_attr( $alt ) . '"/></figure><!-- /wp:image -->';
}
function hosb_block( $name, $attrs = array() ) {
	return '<!-- wp:' . $name . hosb_attrs( $attrs ) . ' /-->';
}
function hosb_link( $slug ) {
	$p = get_page_by_path( $slug );
	return $p ? get_permalink( $p ) : home_url( '/' . $slug . '/' );
}
function hosb_e( $s ) {
	return esc_html( $s );
}

/** ตัวเลขสถิติเป็นย่อหน้า <strong>ตัวเลข</strong>คำอธิบาย */
function hosp_stats( $n ) {
	$out = array();
	foreach ( array_slice( hos_stat_items(), 0, $n ) as $it ) {
		$out[] = hosb_p( '<strong>' . hosb_e( $it[0] ) . '</strong>' . hosb_e( $it[1] ) );
	}
	return $out;
}

// ---------- ส่วน (section) ----------
function hosp_hero() {
	$phone = hos_mod( 'hos_phone' );
	return hosb_group(
		hosb_cols( array(
			array( array(
				hosb_p( hosb_e( hos_mod( 'hos_hero_eyebrow' ) ), 'hos-eyebrow-p' ),
				hosb_h( hosb_e( hos_site_name() ), 1, 'hos-hero-title' ),
				hosb_p( hosb_e( hos_mod( 'hos_vision' ) ), 'hos-hero-lead' ),
				hosb_btns( array( array( '🩺 ตารางแพทย์ออกตรวจ', hos_quick_url( hos_mod( 'hos_schedule_url' ) ), 'hos-btn-light' ), array( '☎ ' . hosb_e( $phone ), 'tel:' . preg_replace( '/[^0-9+]/', '', $phone ), 'hos-btn-ghost' ) ) ),
				hosb_group( hosp_stats( 3 ), 'hos-facts' ),
			), '46%' ),
			array( array( hosb_block( 'hos/slider', array( 'max' => 12 ) ) ), '54%' ),
		), 'hos-hero-cols' ),
		'hos-hero-g', 'full', true
	);
}
function hosp_quick() {
	$items = array(
		array( '🩺', 'ตารางแพทย์ออกตรวจ', hos_quick_url( hos_mod( 'hos_schedule_url' ) ) ),
		array( '📢', 'ข่าวประชาสัมพันธ์', hosb_link( 'ข่าวประชาสัมพันธ์' ) ),
		array( '🧾', 'จัดซื้อจัดจ้าง', hosb_link( 'ข่าวสารจัดซื้อ-จัดจ้าง' ) ),
		array( '💼', 'รับสมัครงาน', hosb_link( 'ข่าวรับสมัครงาน' ) ),
		array( '🛡️', 'ITA คุณธรรมและความโปร่งใส', hosb_link( 'ita' ) ),
		array( '📄', 'ดาวน์โหลดเอกสาร', hos_source_url( 'downloads' ) ),
	);
	$h = array();
	foreach ( $items as $i ) {
		$h[] = hosb_group( array( hosb_p( $i[0], 'hos-q-ico' ), hosb_p( '<a href="' . esc_url( $i[2] ) . '">' . hosb_e( $i[1] ) . '</a>', 'hos-q-t' ) ), 'hos-q' );
	}
	return hosb_group( $h, 'hos-quick-g', 'wide' );
}
function hosp_head( $kicker, $title, $lead = '' ) {
	return hosb_p( $kicker, 'hos-kicker-p' ) . hosb_h( $title, 2, 'hos-sec-title' ) . ( $lead ? hosb_p( $lead, 'hos-sec-lead' ) : '' );
}
function hosp_news() {
	return hosb_group( array( hosp_head( 'NEWS &amp; UPDATES', 'ข่าวสารและประกาศ' ), hosb_block( 'hos/news', array( 'source' => 'all', 'count' => 6 ) ) ), 'hos-sec', 'wide' );
}
function hosp_vision() {
	return hosb_group(
		hosb_cols( array(
			array( array( hosp_head( 'VISION', 'วิสัยทัศน์' ), hosb_p( '“' . hosb_e( hos_mod( 'hos_vision' ) ) . '”', 'hos-vision-quote' ), hosb_btns( array( array( 'พันธกิจและค่านิยม', hosb_link( 'vision' ), '' ) ) ) ), '50%' ),
			array( array( hosb_group( hosp_stats( 4 ), 'hos-stats-g' ) ), '50%' ),
		), 'hos-vision-cols' ),
		'hos-band-g', 'full', true
	);
}
function hosp_ita() {
	$chips = array();
	foreach ( array( 'ita-2569' => '2569', 'ita-2568' => '2568', 'ita-2567' => '2567', 'ita-2566' => '2566', 'ita65' => '2565', 'ita64' => '2564' ) as $s => $y ) {
		$chips[] = '<a href="' . esc_url( hosb_link( $s ) ) . '">ITA ' . $y . '</a>';
	}
	return hosb_group( array(
		hosp_head( 'INTEGRITY &amp; TRANSPARENCY', 'คุณธรรมและความโปร่งใส', 'เปิดเผยข้อมูลสาธารณะตามเกณฑ์การประเมินคุณธรรมและความโปร่งใส (ITA)' ),
		hosb_p( implode( ' ', $chips ), 'hos-chips-p' ),
	), 'hos-dark-g', 'full', true );
}
function hosp_visit() {
	$q = hos_mod( 'hos_map_query' );
	return hosb_group( hosb_cols( array(
		array( array(
			hosp_head( 'VISIT US', 'การเดินทางมาโรงพยาบาล' ),
			hosb_p( '📍 ' . hosb_e( hos_mod( 'hos_address' ) ) ),
			hosb_p( '☎ ' . hosb_e( hos_mod( 'hos_phone' ) ) . ' · แฟกซ์ ' . hosb_e( hos_mod( 'hos_fax' ) ) ),
			hosb_p( '🕘 ' . hosb_e( hos_mod( 'hos_hours' ) ) ),
			hosb_btns( array( array( '🧭 นำทาง', 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( $q ), '' ), array( 'ติดต่อเรา', hosb_link( 'ติดต่อเรา' ), 'is-style-outline' ) ) ),
		), '42%' ),
		array( array( hosb_block( 'hos/map', array( 'height' => 360 ) ) ), '58%' ),
	), 'hos-visit-cols' ), 'hos-sec', 'wide' );
}

/** หน้าแรกทั้งหน้า */
/** บริการของเรา: การ์ดบริการ (แก้ข้อความ ไอคอน และลิงก์ได้ในหน้าแรก) */
function hos_services_items() {
	return array(
		array( '🚑', 'อุบัติเหตุและฉุกเฉิน 24 ชม.', 'ห้องฉุกเฉินพร้อมทีมแพทย์ พยาบาล และรถพยาบาลตลอด 24 ชั่วโมง', 'tel:1669', 'โทร 1669' ),
		array( '🩺', 'ผู้ป่วยนอก / ตรวจโรคทั่วไป', 'ตรวจรักษาโรคทั่วไป คัดกรอง และส่งต่อแพทย์เฉพาะทาง', 'ทั่วไป', '' ),
		array( '❤️', 'อายุรกรรม', 'เบาหวาน ความดัน โรคหัวใจ โรคไต และโรคเรื้อรังอื่น ๆ', 'อายุรกรรม', '' ),
		array( '🦴', 'ศัลยกรรม / กระดูกและข้อ', 'ผ่าตัดทั่วไป กระดูกและข้อ และอุบัติเหตุ', 'ศัลยกรรม', '' ),
		array( '🤰', 'สูติ-นรีเวชกรรม', 'ฝากครรภ์ ห้องคลอด และดูแลสุขภาพสตรี', 'สูติ', '' ),
		array( '👶', 'กุมารเวชกรรม', 'ดูแลเด็กป่วย วัคซีน และตรวจพัฒนาการ', 'กุมาร', '' ),
		array( '🦷', 'ทันตกรรม', 'ตรวจฟัน ขูดหินปูน อุดฟัน และถอนฟัน', 'ทันต', '' ),
		array( '🌿', 'แพทย์แผนไทย', 'นวด ประคบ อบสมุนไพร และยาสมุนไพร', 'แผนไทย', '' ),
	);
}
function hosp_services() {
	$sched = hos_quick_url( hos_mod( 'hos_schedule_url' ) );
	$h     = array();
	foreach ( hos_services_items() as $i ) {
		$url  = 0 === strpos( $i[3], 'tel:' ) ? $i[3] : add_query_arg( 'clinic', rawurlencode( $i[3] ), $sched );
		$link = $i[4] ? $i[4] : 'ดูตารางออกตรวจ';
		$h[]  = hosb_group( array( hosb_p( $i[0], 'hos-svc-ico' ), hosb_h( hosb_e( $i[1] ), 3, 'hos-svc-t' ), hosb_p( hosb_e( $i[2] ), 'hos-svc-d' ), hosb_p( '<a href="' . esc_url( $url ) . '">' . hosb_e( $link ) . ' →</a>', 'hos-svc-a' ) ), 'hos-svc' );
	}
	return hosb_group( array( hosp_head( 'OUR SERVICES', 'บริการของเรา', 'คลินิกและบริการทางการแพทย์ — คลิกเพื่อดูตารางแพทย์ออกตรวจ' ), hosb_group( $h, 'hos-svc-g' ) ), 'hos-sec hos-services', 'wide' );
}
function hos_page_content_home( $banner_url = '' ) {
	$out = array( hosp_hero(), hosp_quick() );
	if ( $banner_url ) {
		$out[] = hosb_img( $banner_url, 'ประชาสัมพันธ์', 'hos-promo', 'wide' );
	}
	$out[] = function_exists( 'hos_service_cards_block' ) && hos_service_cards_block() ? hos_service_cards_block() : hosp_services();
	$out[] = hosp_news();
	$out[] = hosp_vision();
	$out[] = hosp_ita();
	$out[] = hosp_visit();
	return implode( "\n\n", $out );
}

/** หน้าอื่น ๆ: slug => [ชื่อ, เนื้อหา] */
function hos_page_contents() {
	$pages = array();
	$pages['ข่าวประชาสัมพันธ์']      = array( 'ข่าวประชาสัมพันธ์', hosb_p( 'ข่าวและกิจกรรมของ' . hosb_e( hos_site_name() ), 'hos-sec-lead' ) . hosb_block( 'hos/news', array( 'source' => 'news', 'count' => 12 ) ) );
	$pages['ข่าวสารจัดซื้อ-จัดจ้าง'] = array( 'ข่าวสารจัดซื้อ/จัดจ้าง', hosb_p( 'ประกวดราคา ประกาศราคากลาง และสรุปผลการดำเนินการจัดซื้อจัดจ้าง', 'hos-sec-lead' ) . hosb_block( 'hos/news', array( 'source' => 'procurement', 'count' => 9 ) ) . hosb_h( 'ประกาศย้อนหลัง', 2 ) . hosb_block( 'hos/doclist', array( 'source' => 'procurement', 'count' => 20 ) ) );
	$pages['ข่าวรับสมัครงาน']         = array( 'ข่าวรับสมัครงาน', hosb_p( 'ประกาศรับสมัคร รายชื่อผู้มีสิทธิสอบ และผลการคัดเลือก', 'hos-sec-lead' ) . hosb_block( 'hos/news', array( 'source' => 'jobs', 'count' => 12 ) ) );

	$hist = '';
	foreach ( hos_data_history() as $p ) {
		$hist .= hosb_p( hosb_e( $p ) );
	}
	$rows = array();
	foreach ( array_reverse( hos_data_directors() ) as $d ) {
		$rows[] = array( hosb_e( $d[0] ), hosb_e( $d[1] ) );
	}
	$pages['history'] = array( 'ประวัติโรงพยาบาล', $hist . hosb_group( hosp_stats( 4 ), 'hos-stats-g is-light' ) . hosb_h( 'ทำเนียบผู้อำนวยการ', 2 ) . hosb_table( array( 'ผู้อำนวยการ', 'ระยะเวลาดำรงตำแหน่ง' ), $rows ) );

	$cards = array();
	foreach ( hos_data_vision_sections() as $t => $list ) {
		$cards[] = hosb_group( array( hosb_h( hosb_e( $t ), 3 ), hosb_list( array_map( 'hosb_e', $list ), true ) ), 'hos-card-g' );
	}
	$acr = function ( $rows ) {
		return hosb_list( array_map( function ( $r ) { return '<strong>' . hosb_e( $r[0] ) . '</strong> ' . hosb_e( $r[1] ) . ' — ' . hosb_e( $r[2] ); }, $rows ) );
	};
	$pages['vision'] = array( 'วิสัยทัศน์ / พันธกิจ / ค่านิยม',
		hosb_group( array( hosb_p( 'วิสัยทัศน์', 'hos-kicker-p' ), hosb_p( '“' . hosb_e( hos_mod( 'hos_vision' ) ) . '”', 'hos-vision-quote' ) ), 'hos-vision-box' )
		. hosb_cols( array( array( array( $cards[0], $cards[2] ) ), array( array( $cards[1], $cards[3] ) ) ), '', '' )
		. hosb_cols( array(
			array( array( hosb_group( array( hosb_h( 'เข็มมุ่ง', 3 ), $acr( hos_data_focus() ) ), 'hos-card-g' ) ) ),
			array( array( hosb_group( array( hosb_h( 'ค่านิยมองค์กร (TMOPH)', 3 ), $acr( hos_data_values() ) ), 'hos-card-g' ) ) ),
		), '', '' ) );

	$dc = array();
	foreach ( hos_data_departments() as $t => $list ) {
		$dc[] = hosb_group( array( hosb_h( hosb_e( $t ), 3 ), hosb_list( array_map( 'hosb_e', $list ) ) ), 'hos-card-g' );
	}
	$pages['department'] = array( 'หน่วยงานภายใน', hosb_p( 'โครงสร้างภารกิจและกลุ่มงานของ' . hosb_e( hos_site_name() ) . '', 'hos-sec-lead' ) . hosb_cols( array( array( array( $dc[0], $dc[1], $dc[4] ) ), array( array( $dc[2], $dc[3] ) ) ), '', '' ) );

	$pages['doctor-schedule'] = array( 'ตารางแพทย์ออกตรวจ', hosb_p( 'เลือกวันเพื่อดูคลินิกที่เปิด หรือพิมพ์ชื่อคลินิกเพื่อค้นหา · ห้องฉุกเฉินเปิดตลอด 24 ชั่วโมง', 'hos-sec-lead' ) . hosb_block( 'hos/clinics' ) );

	$contact = array(
		array( '📍 ที่อยู่', hosb_e( hos_mod( 'hos_address' ) ) ),
		array( '☎ โทรศัพท์', hosb_e( hos_mod( 'hos_phone' ) ) . '<br>แฟกซ์ ' . hosb_e( hos_mod( 'hos_fax' ) ) ),
		array( '✉ อีเมล', hosb_e( hos_mod( 'hos_email' ) ) ),
		array( '🕘 เวลาทำการ', hosb_e( hos_mod( 'hos_hours' ) ) ),
	);
	$cc = array();
	foreach ( $contact as $c ) {
		$cc[] = array( array( hosb_group( array( hosb_h( $c[0], 3 ), hosb_p( $c[1] ) ), 'hos-card-g' ) ) );
	}
	$q = hos_mod( 'hos_map_query' );
	$pages['map'] = array( 'แผนที่โรงพยาบาล',
		hosb_p( '📍 ' . hosb_e( hos_mod( 'hos_address' ) ), 'hos-sec-lead' )
		. hosb_btns( array(
			array( '🧭 นำทางมาโรงพยาบาล', 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( $q ), '' ),
			array( 'เปิดใน Google Maps', 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $q ), 'is-style-outline' ),
		) )
		. hosb_block( 'hos/map', array( 'height' => 560 ) )
		. hosb_h( 'จุดบริการสำคัญ', 2 )
		. hosb_cols( array(
			array( array( hosb_group( array( hosb_h( '🚑 ห้องอุบัติเหตุและฉุกเฉิน', 3 ), hosb_p( 'เปิดตลอด 24 ชั่วโมง · สายด่วน 1669' ) ), 'hos-card-g' ) ) ),
			array( array( hosb_group( array( hosb_h( '🏥 อาคารผู้ป่วยนอก', 3 ), hosb_p( 'ห้องบัตร คัดกรอง ตรวจโรคทั่วไป คลินิกเฉพาะทาง (ชั้น 1)' ) ), 'hos-card-g' ) ) ),
			array( array( hosb_group( array( hosb_h( '💊 ห้องจ่ายยา', 3 ), hosb_p( 'รับยาผู้ป่วยนอก (ชั้น 1)' ) ), 'hos-card-g' ) ) ),
			array( array( hosb_group( array( hosb_h( '🤱 อาคารสูตินรีเวชฯ', 3 ), hosb_p( 'ฝากครรภ์ สูติ-นรีเวชกรรม (ชั้น 1)' ) ), 'hos-card-g' ) ) ),
		), '', '' )
		. hosb_p( 'แก้ไขข้อมูลจุดบริการ หรือแทรกรูปแผนผังอาคารได้ในหน้านี้', 'hos-note-p' ) );
	$pages['ติดต่อเรา'] = array( 'ติดต่อเรา', hosb_cols( $cc, '', '' ) . hosb_block( 'hos/map', array( 'height' => 420 ) ) );
	return $pages;
}

// ---------- ชุดบล็อกสำเร็จรูป ----------
add_action( 'init', function () {
	if ( ! function_exists( 'register_block_pattern' ) ) {
		return;
	}
	register_block_pattern_category( 'hos', array( 'label' => 'โรงพยาบาล' ) );
	$list = array(
		'hero'   => array( 'แบนเนอร์หน้าแรก + สไลด์', 'hosp_hero' ),
		'quick'  => array( 'ปุ่มลัด 6 ปุ่ม', 'hosp_quick' ),
		'news'   => array( 'ข่าวสารและประกาศ (แท็บ)', 'hosp_news' ),
		'vision' => array( 'วิสัยทัศน์ + ตัวเลขสถิติ', 'hosp_vision' ),
		'ita'    => array( 'คุณธรรมและความโปร่งใส (ITA)', 'hosp_ita' ),
		'visit'  => array( 'การเดินทาง + แผนที่', 'hosp_visit' ),
	);
	foreach ( $list as $k => $p ) {
		register_block_pattern( 'hos/' . $k, array( 'title' => $p[0], 'categories' => array( 'hos' ), 'content' => call_user_func( $p[1] ) ) );
	}
}, 20 );
