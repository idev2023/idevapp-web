=== iDev Store ===
Contributors: idevapp2023
Donate link: https://idevapp.me/
Tags: pos, inventory, optical, pharmacy, clinic
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.3.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Back office for clinics, eye clinics / optical shops and pharmacies: stock, selling and dispensing, job orders with pick-up appointments, receipts and PromptPay QR.

== Description ==

= Features =

* Stock with lot numbers and expiry dates, first-expiry-first-out, low-stock and expiry warnings, stock count, write-off, CSV import
* Sell / dispense screen for barcode scanners, cash change, PromptPay QR with the amount, pay later
* Job orders (e.g. glasses): eye prescription (SPH CYL AXIS ADD PRISM BASE VA, PD), frame and lenses, deposit and balance
* Status: received → ordered → in progress → ready → picked up, with e-mail, LINE, SMS and WhatsApp message
* Customers check the order with the QR on the ticket and book a pick-up time
* Receipts, payment receipts and job tickets for 80 mm receipt printers, A5, A4 and continuous-form dot-matrix printers
* Drug labels (pharmacies and clinics): shop, patient, date, generic name, strength, quantity, directions with a quick builder, indication, warning, expiry, pharmacist — label stickers or 80 mm
* Pharmacies: drug classes, buyer and prescriber on the sale, ขย.9 / ขย.10 / ขย.11 / ขย.12 books and the ขย.13 four-monthly report (A4 landscape print and CSV)
* Customers with history; prescriptions and notes are encrypted
* Reports: money received by method, best sellers, stock value, expiring lots, CSV export
* Roles: shop staff and shop manager

Thai and English interface. Works with any theme. Part of the iDevApp plugin suite — appears under the **Shop** menu.

== Installation ==

1. Plugins → Add New → Upload Plugin, choose the zip, Install, Activate.
2. Shop → Settings: shop details, type of business, PromptPay, printer format.
3. Create a page with the "Order status" block (or [idev_job_status]) and choose it under Settings → Order status & pick-up.

== Changelog ==

= 1.3.1 =
* Dates show the Buddhist year (พ.ศ.) and Thai month names on Thai pages, and the Gregorian year on English pages, everywhere WordPress formats a date.

= 1.1.0 =
* Drug labels for pharmacies and clinics (directions builder, label sticker or 80 mm, re-print per line).
* Pharmacy: drug class, ขย.13 flag, manufacturer and pack size on items; buyer / prescription details on sales (encrypted).
* ขย.9–13 books in Reports (Pharmacy package).

= 1.0.1 =
* Licences: trial mode prints "TRIAL"; sold in the iDevApp packages (job orders in the "Clinic with job orders" package).

= 1.0.0 =
* First release.
