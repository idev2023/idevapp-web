=== iDev Maps & Directions ===
Contributors: idevapp2023
Donate link: https://idevapp.me/
Tags: google maps, directions, map
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Google Maps without an API key, several locations, and a Directions button that opens the Google Maps app on phones using the coordinates from the

== Description ==

Google Maps without an API key, several locations, and a Directions button that opens the Google Maps app on phones using the coordinates from the embed code.

= Features =

* Paste the Embed code, a maps link, coordinates or an address
* Directions / Open in Maps / Call buttons
* Waits for cookie consent
* Block and shortcodes [idev_map] [idev_directions]

Thai and English interface. Works with any theme. Part of the iDevApp plugin suite for hospitals and clinics — all iDev plugins appear under the **iDevApp** menu.

== Installation ==

1. Plugins → Add New → Upload Plugin, choose the zip, Install, Activate.
2. Open **iDevApp** in the admin menu for settings.

== Changelog ==

= 1.0.0 =
* First release.
