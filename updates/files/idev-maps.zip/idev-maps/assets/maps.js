/* iDev Maps: load maps after cookie consent (iDev Cookie Consent or any plugin that sets window.idevConsent). */
(function () {
  function load(box) {
    const f = box.querySelector('iframe[data-src]');
    if (!f) return;
    f.src = f.dataset.src; f.removeAttribute('data-src'); f.hidden = false;
    const gate = box.querySelector('.idev-map-gate'); if (gate) gate.remove();
  }
  const all = () => document.querySelectorAll('[data-idev-consent]').forEach(load);
  const ok = () => window.idevConsent && typeof window.idevConsent.allowed === 'function' && window.idevConsent.allowed('external');
  document.addEventListener('click', (e) => { const b = e.target.closest('[data-idev-load]'); if (b) load(b.closest('[data-idev-consent]')); });
  document.addEventListener('idev:consent', () => { if (ok()) all(); });
  if (ok()) all();
})();
