<?php
/**
 * Plugin Name:       iDev Maps & Directions
 * Plugin URI:        https://idevapp.me/plugins/idev-maps
 * Description:       Google Maps without an API key: paste the "Embed a map" code, a maps link or an address. Several locations, a "Directions" button that opens the Google Maps app on phones, call button, and maps that wait for cookie consent.
 * Version:           1.0.2
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-maps
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// Loaded once: the same plugin may also be inside an iDevApp package (I-Clinic / I-Drug) or a Pro version.
if (defined('IDEV_MAPS_VERSION')) return;

define('IDEV_MAPS_VERSION', '1.0.2');
define('IDEV_MAPS_FILE', __FILE__);
require_once __DIR__ . '/common/idev-common.php';
require_once __DIR__ . '/includes/maps.php';
require_once __DIR__ . '/includes/admin.php';
register_activation_hook(__FILE__, 'idev_maps_migrate');
