<?php
defined('ABSPATH') || exit;

function idev_maps_settings() {
    $s = get_option('idev_maps', []);
    $s = array_merge(['locations' => [], 'height' => '420', 'radius' => '16', 'color' => '#0f766e', 'consent' => 'auto', 'show_address' => '1', 'show_call' => '1'], is_array($s) ? $s : []);
    $s['locations'] = array_values(array_filter((array) $s['locations'], 'is_array'));
    return $s;
}
function idev_maps_location($i = 0) {
    $list = idev_maps_settings()['locations'];
    $loc = $list[(int) $i] ?? null;
    return $loc ? array_merge(['name' => '', 'name_en' => '', 'map' => '', 'destination' => '', 'address' => '', 'address_en' => '', 'phone' => ''], $loc) : null;
}

/* ---------- Parsing what people paste ---------- */

function idev_maps_extract_src($value) {
    if (preg_match('/<iframe[^>]*\ssrc\s*=\s*["\']([^"\']+)["\']/i', $value, $m)) return html_entity_decode($m[1]);
    return $value;
}
function idev_maps_is_google($host) { return (bool) preg_match('/(^|\.)google\.[a-z.]+$/', $host); }

/** Safe iframe src, or null when the input cannot be embedded (e.g. a maps.app.goo.gl short link). */
function idev_maps_embed_src($input) {
    $raw = idev_maps_extract_src(trim((string) $input));
    if ($raw === '') return null;
    $url = wp_parse_url($raw);
    if (!empty($url['scheme']) && !empty($url['host'])) {
        if ($url['scheme'] !== 'https' || !idev_maps_is_google($url['host'])) return null;
        $path = $url['path'] ?? '';
        if (strpos($path, '/maps/embed') === 0) return 'https://www.google.com' . $path . (isset($url['query']) ? '?' . $url['query'] : '');
        $q = idev_maps_query_from_url($raw);
        return $q ? 'https://www.google.com/maps?q=' . rawurlencode($q) . '&output=embed' : null;
    }
    if (preg_match('/[<>"]/', $raw) || strlen($raw) > 300) return null;
    return 'https://www.google.com/maps?q=' . rawurlencode($raw) . '&output=embed';
}

/** "lat,lng" or a place query found in a Google Maps URL (normal or embed). */
function idev_maps_query_from_url($raw) {
    $url = wp_parse_url($raw);
    $path = $url['path'] ?? '';
    parse_str($url['query'] ?? '', $params);
    if (!empty($params['pb'])) {
        // Embed links: !2d = longitude, !3d = latitude of the map centre (the marked place).
        if (preg_match('/!2d(-?\d+\.\d+)!3d(-?\d+\.\d+)/', $params['pb'], $m)) return "{$m[2]},{$m[1]}";
        if (preg_match('/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/', $params['pb'], $m)) return "{$m[1]},{$m[2]}";
    }
    if (preg_match('/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/', $raw, $m)) return "{$m[1]},{$m[2]}";
    if (preg_match('/@(-?\d+\.\d+),(-?\d+\.\d+)/', $path, $m)) return "{$m[1]},{$m[2]}";
    foreach (['q', 'query', 'destination', 'daddr', 'll'] as $k) if (!empty($params[$k])) return (string) $params[$k];
    if (preg_match('#/maps/place/([^/]+)#', $path, $m)) return str_replace('+', ' ', urldecode($m[1]));
    return '';
}

/** Where "Directions" should go: explicit destination → map coordinates/place → address. */
function idev_maps_destination($loc) {
    if (!$loc) return '';
    $d = trim((string) $loc['destination']);
    if ($d !== '') {
        if (preg_match('#^https?://#i', $d)) { $q = idev_maps_query_from_url($d); if ($q) return $q; }
        else return $d;
    }
    $raw = idev_maps_extract_src(trim((string) $loc['map']));
    if ($raw !== '') {
        if (preg_match('#^https?://#i', $raw)) { $q = idev_maps_query_from_url($raw); if ($q) return $q; }
        elseif (!preg_match('/[<>"]/', $raw)) return $raw;
    }
    return trim(idev_pick($loc['address'], $loc['address_en'], 'th'));
}

/** Universal Google Maps directions link: on phones it opens the Maps app with the route ready. */
function idev_maps_directions_url($i = 0) {
    $dest = idev_maps_destination(idev_maps_location($i));
    if ($dest === '') return '';
    return 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode($dest);
}
function idev_maps_open_url($i = 0) {
    $loc = idev_maps_location($i);
    if (!$loc) return '';
    $raw = idev_maps_extract_src(trim((string) $loc['map']));
    $u = wp_parse_url($raw);
    // Share links (maps.app.goo.gl, google.com/maps/place/…) open fine as they are; embed links do not.
    if (($u['scheme'] ?? '') === 'https' && !empty($u['host']) && (idev_maps_is_google($u['host']) || preg_match('/(^|\.)goo\.gl$/', $u['host'])) && strpos($u['path'] ?? '', '/maps/embed') !== 0) return $raw;
    $dest = idev_maps_destination($loc);
    return $dest === '' ? '' : 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($dest);
}

/* ---------- Output ---------- */

function idev_maps_consent_needed() {
    $mode = idev_maps_settings()['consent'];
    if ($mode === 'off') return false;
    if ($mode === 'always') return true;
    return function_exists('idev_cookie_consent_active') && idev_cookie_consent_active();
}

function idev_maps_iframe($src, $title) {
    wp_enqueue_script('idev-maps');
    $attrs = 'title="' . esc_attr($title) . '" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen';
    if (!idev_maps_consent_needed()) return '<iframe src="' . esc_url($src) . '" ' . $attrs . '></iframe>';
    return '<div class="idev-map-consent" data-idev-consent="map"><iframe data-src="' . esc_url($src) . '" ' . $attrs . ' hidden></iframe><div class="idev-map-gate">' . idev_icon('pin') . '<button type="button" data-idev-load>' . esc_html__('Show map', 'idev-maps') . '</button><small>' . esc_html__('The map is provided by Google, which may set cookies.', 'idev-maps') . '</small></div></div>';
}

/**
 * Map card. $args: location (index), title, height, buttons (bool), address (bool), map (bool).
 */
function idev_map_render($args = []) {
    $s = idev_maps_settings();
    $a = array_merge(['location' => 0, 'title' => null, 'height' => '', 'buttons' => true, 'address' => (bool) $s['show_address'], 'map' => true], $args);
    $loc = idev_maps_location($a['location']);
    if (!$loc) return current_user_can('manage_options') ? '<p class="idev-map-empty">' . esc_html__('No map yet — add a location under iDevApp → Maps.', 'idev-maps') . '</p>' : '';
    wp_enqueue_style('idev-maps');
    $name = idev_pick($loc['name'], $loc['name_en']);
    $title = $a['title'] === null ? $name : $a['title'];
    $src = $a['map'] ? idev_maps_embed_src($loc['map']) : null;
    $height = (int) ($a['height'] ?: $s['height']);
    $html = '<section class="idev-map" style="--idev-map:' . esc_attr($s['color']) . ';--idev-map-h:' . max(200, min(900, $height)) . 'px;--idev-map-r:' . (int) $s['radius'] . 'px">';
    $address = $a['address'] ? idev_pick($loc['address'], $loc['address_en']) : '';
    $buttons = '';
    if ($a['buttons']) {
        $dir = idev_maps_directions_url($a['location']);
        $open = idev_maps_open_url($a['location']);
        if ($dir) $buttons .= '<a class="idev-map-btn is-primary" href="' . esc_url($dir) . '" target="_blank" rel="noopener">' . idev_icon('navigate') . '<span>' . esc_html__('Directions', 'idev-maps') . '</span></a>';
        if ($open) $buttons .= '<a class="idev-map-btn" href="' . esc_url($open) . '" target="_blank" rel="noopener">' . idev_icon('pin') . '<span>' . esc_html__('Open in Google Maps', 'idev-maps') . '</span></a>';
        if ($s['show_call'] && $loc['phone']) $buttons .= '<a class="idev-map-btn" href="tel:' . esc_attr(preg_replace('/[^0-9+]/', '', $loc['phone'])) . '">' . idev_icon('phone') . '<span>' . esc_html($loc['phone']) . '</span></a>';
    }
    if ($title !== '' || $address !== '' || $buttons !== '') {
        $html .= '<div class="idev-map-head"><div>' . ($title !== '' ? '<h2>' . esc_html($title) . '</h2>' : '') . ($address !== '' ? '<p>' . esc_html($address) . '</p>' : '') . '</div>' . ($buttons ? '<div class="idev-map-btns">' . $buttons . '</div>' : '') . '</div>';
    }
    if ($src) $html .= '<div class="idev-map-frame">' . idev_maps_iframe($src, $title ?: __('Map', 'idev-maps')) . '</div>';
    return $html . '</section>';
}

/** Just the Directions button (for headers, footers, contact pages). */
function idev_directions_button($i = 0, $label = '') {
    $url = idev_maps_directions_url($i);
    if (!$url) return '';
    wp_enqueue_style('idev-maps');
    return '<a class="idev-map-btn is-primary" style="--idev-map:' . esc_attr(idev_maps_settings()['color']) . '" href="' . esc_url($url) . '" target="_blank" rel="noopener">' . idev_icon('navigate') . '<span>' . esc_html($label ?: __('Directions', 'idev-maps')) . '</span></a>';
}

add_shortcode('idev_map', function ($a) {
    $a = shortcode_atts(['location' => 0, 'title' => null, 'height' => '', 'buttons' => 'yes', 'address' => '', 'map' => 'yes'], $a);
    $args = ['location' => (int) $a['location'], 'title' => $a['title'], 'height' => $a['height'], 'buttons' => $a['buttons'] !== 'no', 'map' => $a['map'] !== 'no'];
    if ($a['address'] !== '') $args['address'] = $a['address'] !== 'no';
    return idev_map_render($args);
});
add_shortcode('idev_directions', function ($a) { $a = shortcode_atts(['location' => 0, 'label' => ''], $a); return idev_directions_button((int) $a['location'], $a['label']); });

add_action('init', function () {
    load_plugin_textdomain('idev-maps', false, dirname(plugin_basename(IDEV_MAPS_FILE)) . '/languages');
    wp_register_style('idev-maps', plugins_url('assets/maps.css', IDEV_MAPS_FILE), [], IDEV_MAPS_VERSION);
    wp_register_script('idev-maps', plugins_url('assets/maps.js', IDEV_MAPS_FILE), [], IDEV_MAPS_VERSION, true);
    idev_register_plugin('idev-maps', ['name' => 'iDev Maps & Directions', 'version' => IDEV_MAPS_VERSION, 'description' => __('Google Maps without an API key, with a Directions button.', 'idev-maps'), 'settings' => admin_url('admin.php?page=idev-maps'), 'docs' => 'https://idevapp.me/plugins/idev-maps']);
    $locs = ['0' => __('Location 1', 'idev-maps')];
    foreach (idev_maps_settings()['locations'] as $i => $l) $locs[(string) $i] = ($l['name'] ?? '') ?: sprintf(__('Location %d', 'idev-maps'), $i + 1);
    idev_register_block('idev/map', __('Map & directions', 'idev-maps'), 'location-alt', __('Google map with Directions, Open in Maps and Call buttons.', 'idev-maps'), [
        'location' => ['select', __('Location', 'idev-maps'), '0', $locs],
        'title' => ['text', __('Heading (empty = location name)', 'idev-maps'), ''],
        'height' => ['number', __('Map height (px)', 'idev-maps'), 0, [0, 900]],
        'buttons' => ['toggle', __('Buttons', 'idev-maps'), true],
        'map' => ['toggle', __('Map', 'idev-maps'), true],
    ], function ($a) { return idev_map_render(['location' => (int) $a['location'], 'title' => ($a['title'] ?? '') === '' ? null : $a['title'], 'height' => (int) ($a['height'] ?? 0), 'buttons' => !empty($a['buttons']), 'map' => !empty($a['map'])]); });
});
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_MAPS_FILE, admin_url('admin.php?page=idev-maps'), 'https://idevapp.me/plugins/idev-maps'); });

/* Copies the Andaman Hub map and address once. */
function idev_maps_migrate() {
    $s = get_option('idev_maps', []);
    if (!empty($s['locations'])) return;
    $ah = get_option('ah_settings', []);
    if (empty($ah['map_query']) && empty($ah['address'])) return;
    $s['locations'] = [['name' => $ah['site_name'] ?? '', 'name_en' => $ah['site_name_en'] ?? '', 'map' => $ah['map_query'] ?? '', 'destination' => '', 'address' => $ah['address'] ?? '', 'address_en' => $ah['address_en'] ?? '', 'phone' => $ah['phone'] ?? '']];
    update_option('idev_maps', $s);
}
