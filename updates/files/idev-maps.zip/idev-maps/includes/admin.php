<?php
defined('ABSPATH') || exit;

add_action('admin_menu', function () { add_submenu_page('idevapp', __('Maps & directions', 'idev-maps'), __('Maps & directions', 'idev-maps'), 'manage_options', 'idev-maps', 'idev_maps_page'); }, 20);

function idev_maps_location_fields() {
    return [
        'name' => [__('Name (Thai)', 'idev-maps'), 'text', ''],
        'name_en' => [__('Name (English)', 'idev-maps'), 'text', ''],
        'map' => [__('Google Map', 'idev-maps'), 'textarea', __('Google Maps → Share → Embed a map → copy HTML and paste here. A google.com/maps link, coordinates (8.65,98.25) or an address also work.', 'idev-maps')],
        'destination' => [__('Directions to (optional)', 'idev-maps'), 'text', __('Coordinates such as 8.6512,98.2534 or a place name. Empty = taken from the map.', 'idev-maps')],
        'address' => [__('Address (Thai)', 'idev-maps'), 'textarea', ''],
        'address_en' => [__('Address (English)', 'idev-maps'), 'textarea', ''],
        'phone' => [__('Phone', 'idev-maps'), 'text', ''],
    ];
}

function idev_maps_page() {
    $s = idev_maps_settings();
    $fields = [
        ['height', __('Map height (px)', 'idev-maps'), 'number', '', [200, 900]],
        ['radius', __('Corner radius (px)', 'idev-maps'), 'number', '', [0, 40]],
        ['color', __('Button colour', 'idev-maps'), 'color'],
        ['show_address', __('Show address above the map', 'idev-maps'), 'checkbox'],
        ['show_call', __('Show Call button', 'idev-maps'), 'checkbox'],
        ['consent', __('Wait for cookie consent', 'idev-maps'), 'select', __('Google may set cookies when the map loads. "Automatic" waits only when iDev Cookie Consent is active.', 'idev-maps'), ['auto' => __('Automatic', 'idev-maps'), 'always' => __('Always ask before loading', 'idev-maps'), 'off' => __('Never (load right away)', 'idev-maps')]],
    ];
    $bad = [];
    if (isset($_POST['idev_maps']) && check_admin_referer('idev_maps')) {
        $in = wp_unslash($_POST['idev_maps']);
        $s = idev_settings_sanitize($fields, $in, $s);
        $locs = [];
        foreach ((array) ($in['locations'] ?? []) as $row) {
            if (!is_array($row)) continue;
            $loc = [];
            foreach (idev_maps_location_fields() as $k => $f) $loc[$k] = $f[1] === 'textarea' ? ($k === 'map' ? substr(trim((string) ($row[$k] ?? '')), 0, 3000) : sanitize_textarea_field($row[$k] ?? '')) : sanitize_text_field($row[$k] ?? '');
            if (implode('', $loc) === '') continue;
            if ($loc['map'] !== '' && !idev_maps_embed_src($loc['map'])) $bad[] = $loc['name'] ?: '#' . (count($locs) + 1);
            $locs[] = $loc;
        }
        $s['locations'] = $locs;
        update_option('idev_maps', $s);
        echo '<div class="notice notice-success"><p>' . esc_html__('Saved.', 'idev-maps') . '</p></div>';
        if ($bad) echo '<div class="notice notice-warning"><p>' . esc_html(sprintf(__('This map link cannot be shown on the page: %s. Use "Embed a map" from Google Maps instead (short maps.app.goo.gl links cannot be embedded). The Directions button still works.', 'idev-maps'), implode(', ', $bad))) . '</p></div>';
    }
    idev_admin_header(__('Maps & directions', 'idev-maps'));
    echo '<form method="post" id="idev-maps-form">';
    wp_nonce_field('idev_maps');
    echo '<h2 class="idev-section">' . esc_html__('Locations', 'idev-maps') . '</h2><div id="idev-maps-locs">';
    $locs = $s['locations'] ?: [[]];
    foreach ($locs as $i => $loc) idev_maps_location_box($i, $loc);
    echo '</div><template id="idev-maps-tpl">';
    idev_maps_location_box('__i__', []);
    echo '</template><p><button type="button" class="button" id="idev-maps-add">＋ ' . esc_html__('Add location', 'idev-maps') . '</button></p>';
    echo '<h2 class="idev-section">' . esc_html__('Display', 'idev-maps') . '</h2>';
    idev_settings_table('idev_maps', $fields, $s);
    submit_button();
    echo '</form><div class="idev-card"><h2>' . esc_html__('How to use', 'idev-maps') . '</h2><p>' . esc_html__('Block: "Map & directions" (iDevApp category).', 'idev-maps') . '</p><p><code>[idev_map]</code> <code>[idev_map location="1" height="320" buttons="no"]</code> <code>[idev_directions]</code></p><p>PHP: <code>idev_map_render()</code>, <code>idev_maps_directions_url()</code>, <code>idev_directions_button()</code></p></div></div>';
    ?>
<script>
(function(){var box=document.getElementById('idev-maps-locs'),tpl=document.getElementById('idev-maps-tpl');
document.getElementById('idev-maps-add').addEventListener('click',function(){var n=box.children.length;box.insertAdjacentHTML('beforeend',tpl.innerHTML.replace(/__i__/g,n).replace(/__n__/g,n+1));});
box.addEventListener('click',function(e){var b=e.target.closest('[data-remove]');if(b&&confirm(b.dataset.remove)){b.closest('.idev-maps-loc').remove();}});})();
</script>
<style>.idev-maps-loc{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:6px 18px 12px;margin:0 0 14px;max-width:960px}.idev-maps-loc h3{display:flex;justify-content:space-between;align-items:center}.idev-maps-loc .form-table th{width:190px}.idev-maps-loc textarea{width:100%}.idev-maps-test{margin-top:4px}</style>
    <?php
}

function idev_maps_location_box($i, $loc) {
    $n = is_numeric($i) ? $i + 1 : '__n__';
    echo '<div class="idev-maps-loc"><h3><span>' . esc_html__('Location', 'idev-maps') . ' ' . esc_html($n) . ($i === 0 ? ' <small style="font-weight:400;color:#646970">(' . esc_html__('main — used by the Directions button', 'idev-maps') . ')</small>' : '') . '</span><button type="button" class="button-link-delete" data-remove="' . esc_attr__('Remove this location?', 'idev-maps') . '">' . esc_html__('Remove', 'idev-maps') . '</button></h3><table class="form-table" role="presentation">';
    foreach (idev_maps_location_fields() as $k => $f) {
        $name = 'idev_maps[locations][' . esc_attr($i) . '][' . $k . ']';
        $v = (string) ($loc[$k] ?? '');
        echo '<tr><th>' . esc_html($f[0]) . '</th><td>' . ($f[1] === 'textarea' ? '<textarea name="' . $name . '" rows="' . ($k === 'map' ? 4 : 2) . '">' . esc_textarea($v) . '</textarea>' : '<input class="regular-text" name="' . $name . '" value="' . esc_attr($v) . '">');
        if ($f[2]) echo '<p class="description">' . esc_html($f[2]) . '</p>';
        if ($k === 'destination' && is_numeric($i) && ($url = idev_maps_directions_url($i))) echo '<p class="idev-maps-test"><a href="' . esc_url($url) . '" target="_blank" rel="noopener">' . esc_html__('Test the Directions link', 'idev-maps') . ' ↗</a> <code>' . esc_html(idev_maps_destination(idev_maps_location($i))) . '</code></p>';
        echo '</td></tr>';
    }
    echo '</table></div>';
}
