=== iDev Clinic Schedule ===
Contributors: idevapp2023
Donate link: https://idevapp.me/
Tags: doctor schedule, clinic, hospital, opening hours
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Doctor and clinic schedules by month, week or day; doctor team with specialty tabs; opening hours and an "open now" status.

== Description ==

Doctor and clinic schedules by month, week or day; doctor team with specialty tabs; opening hours and an "open now" status.

= Features =

* Weekly, monthly, yearly or one-off clinic times
* Month / week / day views
* Doctor team with photos and specialty tabs
* Opening hours and live open/closed status
* Blocks and shortcodes [idev_schedule] [idev_doctors] [idev_open_status]

Thai and English interface. Works with any theme. Part of the iDevApp plugin suite for hospitals and clinics — all iDev plugins appear under the **iDevApp** menu.

== Installation ==

1. Plugins → Add New → Upload Plugin, choose the zip, Install, Activate.
2. Open **iDevApp** in the admin menu for settings.

== Changelog ==

= 1.0.2 =
* Dates show the Buddhist year (พ.ศ.) and Thai month names on Thai pages, and the Gregorian year on English pages, everywhere WordPress formats a date.

= 1.0.0 =
* First release.
