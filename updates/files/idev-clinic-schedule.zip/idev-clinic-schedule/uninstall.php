<?php
defined('WP_UNINSTALL_PLUGIN') || exit;
$s = get_option('idev_clinic_schedule', []);
if (is_array($s) && ($s['keep_data'] ?? '1') === '0') {
    foreach (get_posts(['post_type' => 'idev_provider', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids']) as $id) wp_delete_post($id, true);
    delete_option('idev_cs_templates');
    delete_option('idev_clinic_schedule');
}
