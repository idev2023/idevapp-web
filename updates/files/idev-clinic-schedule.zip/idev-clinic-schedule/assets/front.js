/* Doctor team: specialty tabs. */
document.querySelectorAll('.idev-team').forEach((team) => {
  const tabs = team.querySelector('.idev-team-tabs');
  if (!tabs) return;
  tabs.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-tab]');
    if (!b) return;
    tabs.querySelectorAll('button').forEach((x) => { x.classList.toggle('is-active', x === b); x.setAttribute('aria-selected', x === b ? 'true' : 'false'); });
    team.querySelectorAll('.idev-team-card').forEach((card) => { card.hidden = b.dataset.tab !== '' && !card.dataset.groups.split(' ').includes(b.dataset.tab); });
  });
});
