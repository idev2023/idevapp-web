/* Clinic times editor. State lives here and is written to the hidden input as JSON. */
(function () {
  const root = document.getElementById('idev-cs-slots');
  const input = document.getElementById('idev-cs-slots-input');
  if (!root || !input || !window.IDEV_CS) return;
  const C = window.IDEV_CS, L = C.L;
  const parse = (v) => { try { const x = JSON.parse(v || '[]'); return Array.isArray(x) ? x : []; } catch (e) { return []; } };
  let slots = parse(root.dataset.slots), templates = parse(root.dataset.templates);
  const sources = parse(root.dataset.sources);
  let message = '';
  const open = new Set();
  const REC = [['weekly', L.weekly], ['monthly_week', L.monthly_week], ['monthly_day', L.monthly_day], ['yearly', L.yearly], ['date', L.date]];
  const fmt = (s, ...a) => { let i = 0; return s.replace(/%(\d\$)?s|%d/g, (m, n) => (n ? a[parseInt(n, 10) - 1] : a[i++])); };
  const today = () => new Date().toISOString().slice(0, 10);
  const empty = (p) => Object.assign({ recurrence: 'weekly', weekday: 1, week_of_month: null, day_of_month: null, month_of_year: null, on_date: null, valid_from: null, valid_until: null, start_time: '09:00', end_time: '16:00', note: '', note_en: '' }, p || {});
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const day = (v) => { if (!v) return ''; const [y, m, d] = v.split('-').map(Number); return `${d} ${C.months[m - 1]} ${C.buddhist ? y + 543 : y}`; };
  function valid(s) {
    const t = /^([01]\d|2[0-3]):[0-5]\d$/;
    if (!t.test(s.start_time || '') || !t.test(s.end_time || '') || s.end_time <= s.start_time) return false;
    if ((s.recurrence === 'weekly' || s.recurrence === 'monthly_week') && !s.weekday) return false;
    if (s.recurrence === 'monthly_week' && !s.week_of_month) return false;
    if ((s.recurrence === 'monthly_day' || s.recurrence === 'yearly') && !s.day_of_month) return false;
    if (s.recurrence === 'yearly' && !s.month_of_year) return false;
    if (s.recurrence === 'date' && !s.on_date) return false;
    return !(s.valid_from && s.valid_until && s.valid_until < s.valid_from);
  }
  function describe(s) {
    const d = s.weekday ? C.days[s.weekday - 1] : '';
    const r = { weekly: fmt(L.everyDay, d), monthly_week: fmt(L.nthDay, d, L.weeks[(s.week_of_month || 1) - 1]), monthly_day: fmt(L.dayOfMonth, s.day_of_month), yearly: fmt(L.yearlyOn, `${s.day_of_month} ${C.months[(s.month_of_year || 1) - 1]}`), date: day(s.on_date) }[s.recurrence] || '';
    const range = s.valid_from || s.valid_until ? ` (${s.valid_from ? day(s.valid_from) : '…'} – ${s.valid_until ? day(s.valid_until) : '…'})` : '';
    return `${r} ${s.start_time}–${s.end_time}${range}`;
  }
  const opts = (list, cur) => list.map(([v, l]) => `<option value="${v}"${String(v) === String(cur) ? ' selected' : ''}>${esc(l)}</option>`).join('');
  function render() {
    input.value = JSON.stringify(slots);
    const rows = slots.map((s, i) => {
      const bad = !valid(s), more = open.has(i) || s.valid_from || s.valid_until || s.note || s.note_en;
      let f = `<label>${esc(L.repeat)}<select data-i="${i}" data-k="recurrence">${opts(REC, s.recurrence)}</select></label>`;
      if (s.recurrence === 'weekly' || s.recurrence === 'monthly_week') f += `<label>${esc(L.day)}<select data-i="${i}" data-k="weekday" data-num>${opts(C.days.map((d, n) => [n + 1, d]), s.weekday || 1)}</select></label>`;
      if (s.recurrence === 'monthly_week') f += `<label>${esc(L.week)}<select data-i="${i}" data-k="week_of_month" data-num>${opts(L.weeks.map((w, n) => [n + 1, w]), s.week_of_month || 1)}</select></label>`;
      if (s.recurrence === 'monthly_day' || s.recurrence === 'yearly') f += `<label>${esc(L.date_label)}<select data-i="${i}" data-k="day_of_month" data-num>${opts(Array.from({ length: 31 }, (_, n) => [n + 1, n + 1]), s.day_of_month || 1)}</select></label>`;
      if (s.recurrence === 'yearly') f += `<label>${esc(L.month)}<select data-i="${i}" data-k="month_of_year" data-num>${opts(C.months.map((m, n) => [n + 1, m]), s.month_of_year || 1)}</select></label>`;
      if (s.recurrence === 'date') f += `<label>${esc(L.date_label)}<input type="date" data-i="${i}" data-k="on_date" value="${esc(s.on_date || '')}"></label>`;
      f += `<label>${esc(L.from)}<input type="time" data-i="${i}" data-k="start_time" value="${esc(s.start_time)}"></label><label>${esc(L.to)}<input type="time" data-i="${i}" data-k="end_time" value="${esc(s.end_time)}"></label>`;
      return `<div class="idev-slot${bad ? ' is-invalid' : ''}"><div class="idev-slot-head"><strong>${i + 1}. ${bad ? esc(L.check) : esc(describe(s))}</strong><span><button type="button" class="button-link" data-act="copy" data-i="${i}">⧉ ${esc(L.copy)}</button> <button type="button" class="button-link-delete" data-act="remove" data-i="${i}">${esc(L.remove)}</button></span></div>
        <div class="idev-slot-grid">${f}</div>
        <details data-i="${i}"${more ? ' open' : ''}><summary>${esc(L.more)}</summary><div class="idev-slot-grid">
          <label>${esc(L.validFrom)}<input type="date" data-i="${i}" data-k="valid_from" value="${esc(s.valid_from || '')}"></label><label>${esc(L.validUntil)}<input type="date" data-i="${i}" data-k="valid_until" value="${esc(s.valid_until || '')}"></label>
          <label class="wide">${esc(L.note)}<input data-i="${i}" data-k="note" maxlength="120" value="${esc(s.note)}"></label><label class="wide">${esc(L.noteEn)}<input data-i="${i}" data-k="note_en" maxlength="120" value="${esc(s.note_en)}"></label>
        </div><small class="description">${esc(L.rangeHint)}</small></details></div>`;
    }).join('');
    const withSlots = sources.filter((s) => s.slots && s.slots.length);
    root.innerHTML = `${slots.length ? '' : `<p class="idev-slot-empty">${esc(L.empty)}</p>`}${rows}
      <div class="idev-slot-bar"><button type="button" class="button" data-add="one">${esc(L.addOne)}</button><button type="button" class="button" data-add="weekdays">${esc(L.addWeekdays)}</button><button type="button" class="button" data-add="weekend">${esc(L.addWeekend)}</button><button type="button" class="button" data-add="monthly">${esc(L.addMonthly)}</button><button type="button" class="button" data-add="date">${esc(L.addDate)}</button></div>
      <div class="idev-slot-bar"><label>${esc(L.useTemplate)}<select data-pick="template"><option value="">${esc(L.chooseTemplate)}</option>${templates.map((t) => `<option value="${esc(t.id)}">${esc(t.name)} (${esc(fmt(L.count, t.slots.length))})</option>`).join('')}</select></label>
        <label>${esc(L.copyFrom)}<select data-pick="source"><option value="">${esc(L.chooseSource)}</option>${withSlots.map((s) => `<option value="${esc(s.id)}">${esc(s.name)} (${esc(fmt(L.count, s.slots.length))})</option>`).join('')}</select></label>
        <button type="button" class="button" data-act="save-template"${slots.length ? '' : ' disabled'}>💾 ${esc(L.saveTemplate)}</button></div>
      ${templates.length ? `<details><summary>${esc(L.manageTemplates)} (${templates.length})</summary><ul class="idev-templates">${templates.map((t) => `<li><span>${esc(t.name)}<small>${esc(t.slots.map(describe).join(' · '))}</small></span><button type="button" class="button-link-delete" data-act="delete-template" data-id="${esc(t.id)}">${esc(L.remove)}</button></li>`).join('')}</ul></details>` : ''}
      ${slots.some((s) => !valid(s)) ? `<p class="idev-slot-error">${esc(L.invalid)}</p>` : ''}${message ? `<p class="idev-slot-msg">${esc(message)}</p>` : ''}`;
  }
  function apply(list, label) {
    if (!list || !list.length) return;
    const replace = slots.length > 0 && window.confirm(fmt(L.confirmUse, label));
    slots = (replace ? [] : slots).concat(list.map((s) => empty(s)));
    message = fmt(L.used, label);
    render();
  }
  function changeRec(i, r) {
    const s = slots[i]; s.recurrence = r;
    if (r === 'monthly_week') { s.weekday = s.weekday || 1; s.week_of_month = s.week_of_month || 1; }
    if (r === 'monthly_day' || r === 'yearly') { s.day_of_month = s.day_of_month || 1; s.month_of_year = r === 'yearly' ? s.month_of_year || 1 : null; }
    if (r === 'date') s.on_date = s.on_date || today();
    if (r === 'weekly') s.weekday = s.weekday || 1;
  }
  const ajax = async (data) => (await fetch(C.ajax, { method: 'POST', credentials: 'same-origin', body: new URLSearchParams(Object.assign({ action: 'idev_cs_template', nonce: C.nonce }, data)) })).json();
  root.addEventListener('change', (e) => {
    const el = e.target;
    if (el.dataset.pick) { const f = (el.dataset.pick === 'template' ? templates : sources).find((x) => String(x.id) === el.value); if (f) apply(f.slots, f.name); return; }
    if (el.dataset.i === undefined || !el.dataset.k) return;
    const i = Number(el.dataset.i);
    if (el.dataset.k === 'recurrence') changeRec(i, el.value);
    else slots[i][el.dataset.k] = el.hasAttribute('data-num') ? Number(el.value) : (el.value || (['note', 'note_en', 'start_time', 'end_time'].includes(el.dataset.k) ? '' : null));
    render();
  });
  root.addEventListener('input', (e) => { const el = e.target; if (el.dataset.i !== undefined && ['note', 'note_en'].includes(el.dataset.k)) { slots[Number(el.dataset.i)][el.dataset.k] = el.value; input.value = JSON.stringify(slots); } });
  root.addEventListener('toggle', (e) => { const el = e.target; if (el.tagName === 'DETAILS' && el.dataset.i !== undefined) { if (el.open) open.add(Number(el.dataset.i)); else open.delete(Number(el.dataset.i)); } }, true);
  root.addEventListener('click', async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    e.preventDefault();
    const a = b.dataset.add, i = Number(b.dataset.i);
    if (a === 'one') slots.push(empty());
    if (a === 'weekdays') [1, 2, 3, 4, 5].forEach((w) => slots.push(empty({ weekday: w })));
    if (a === 'weekend') [6, 7].forEach((w) => slots.push(empty({ weekday: w, start_time: '09:00', end_time: '12:00' })));
    if (a === 'monthly') slots.push(empty({ recurrence: 'monthly_week', weekday: 3, week_of_month: 1 }));
    if (a === 'date') slots.push(empty({ recurrence: 'date', on_date: today() }));
    if (b.dataset.act === 'copy') slots.splice(i + 1, 0, Object.assign({}, slots[i]));
    if (b.dataset.act === 'remove') slots.splice(i, 1);
    if (b.dataset.act === 'save-template') {
      const name = window.prompt(L.namePrompt); if (!name) return;
      const r = await ajax({ do: 'save', name, slots: JSON.stringify(slots) });
      if (r.success) { templates = r.data; message = fmt(L.savedTemplate, name); } else message = r.data || L.failed;
    }
    if (b.dataset.act === 'delete-template') { if (!window.confirm(L.confirmDelete)) return; const r = await ajax({ do: 'delete', id: b.dataset.id }); if (r.success) templates = r.data; }
    render();
  });
  render();
})();
