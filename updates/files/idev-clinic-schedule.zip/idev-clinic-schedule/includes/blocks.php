<?php
defined('ABSPATH') || exit;

add_action('init', function () {
    $views = ['week' => __('Week', 'idev-clinic-schedule'), 'month' => __('Month', 'idev-clinic-schedule'), 'day' => __('Day', 'idev-clinic-schedule')];
    $kinds = ['' => __('All', 'idev-clinic-schedule'), 'doctor' => __('Doctors', 'idev-clinic-schedule'), 'clinic' => __('Clinics', 'idev-clinic-schedule')];
    idev_register_block('idev/schedule', __('Clinic schedule', 'idev-clinic-schedule'), 'calendar-alt', __('Doctor and clinic times by month, week or day.', 'idev-clinic-schedule'), [
        'view' => ['select', __('Start with', 'idev-clinic-schedule'), 'week', $views],
        'navigation' => ['toggle', __('Buttons for view, filter and dates', 'idev-clinic-schedule'), true],
        'kind' => ['select', __('Show', 'idev-clinic-schedule'), '', $kinds],
    ], function ($a) { return idev_cs_schedule_from_request(['view' => $a['view'], 'navigation' => !empty($a['navigation']), 'kind' => $a['kind']]); });
    idev_register_block('idev/doctors', __('Doctor team', 'idev-clinic-schedule'), 'groups', __('Doctors with photo, specialty and profile, in specialty tabs.', 'idev-clinic-schedule'), [
        'kind' => ['select', __('Show', 'idev-clinic-schedule'), 'doctor', ['doctor' => __('Doctors', 'idev-clinic-schedule'), 'clinic' => __('Clinics', 'idev-clinic-schedule'), 'all' => __('All', 'idev-clinic-schedule')]],
        'columns' => ['number', __('Columns', 'idev-clinic-schedule'), 3, [2, 4]],
        'tabs' => ['toggle', __('Specialty tabs', 'idev-clinic-schedule'), true],
        'bio' => ['toggle', __('Show profile', 'idev-clinic-schedule'), true],
        'schedule_link' => ['toggle', __('"View clinic times" link', 'idev-clinic-schedule'), true],
    ], function ($a) { return idev_cs_render_team(['kind' => $a['kind'], 'columns' => (int) $a['columns'], 'tabs' => !empty($a['tabs']), 'bio' => !empty($a['bio']), 'schedule_link' => !empty($a['schedule_link'])]); });
    idev_register_block('idev/open-status', __('Open now status', 'idev-clinic-schedule'), 'clock', __('"Open now · closes 20:00" from the opening hours.', 'idev-clinic-schedule'), [], function () { return idev_cs_render_open_status(); });
}, 9);
