<?php
/** Live "Open now / Closed" status from the opening hours and holidays. */
defined('ABSPATH') || exit;

/** ['state' => open|closed|holiday, 'text' => …] */
function idev_cs_open_status($lang = null) {
    $lang = $lang ?: idev_lang();
    $now = new DateTimeImmutable('now', wp_timezone());
    $today = $now->format('Y-m-d');
    $time = $now->format('H:i');
    $hours = idev_cs_hours();
    $days = idev_weekdays($lang);
    $holidays = [];
    foreach (idev_cs_holidays($today, idev_add_days($today, 14)) as $d => $list) foreach ($list as $h) if ($h['closes_clinics']) $holidays[$d] = $h;
    $er = idev_cs_setting('emergency_24h') === '1' ? ' · ' . __('Emergency open 24 h', 'idev-clinic-schedule') : '';
    $open_day = function ($d) use ($hours, $holidays) { $r = $hours[idev_iso_weekday($d)]; return !$r['closed'] && !isset($holidays[$d]) && $r['close'] > $r['open']; };
    if (isset($holidays[$today])) return ['state' => 'holiday', 'text' => __('Holiday', 'idev-clinic-schedule') . ' · ' . idev_pick($holidays[$today]['name'], $holidays[$today]['name_en'], $lang) . $er];
    $r = $hours[idev_iso_weekday($today)];
    if ($open_day($today) && $time >= $r['open'] && $time < $r['close']) return ['state' => 'open', 'text' => sprintf(__('Open now · closes %s', 'idev-clinic-schedule'), $r['close'])];
    if ($open_day($today) && $time < $r['open']) return ['state' => 'closed', 'text' => sprintf(__('Closed · opens today %s', 'idev-clinic-schedule'), $r['open']) . $er];
    for ($i = 1; $i <= 14; $i++) {
        $d = idev_add_days($today, $i);
        if (!$open_day($d)) continue;
        $o = $hours[idev_iso_weekday($d)]['open'];
        return ['state' => 'closed', 'text' => ($i === 1 ? sprintf(__('Closed · opens tomorrow %s', 'idev-clinic-schedule'), $o) : sprintf(__('Closed · opens %1$s %2$s', 'idev-clinic-schedule'), $days[idev_iso_weekday($d) - 1], $o)) . $er];
    }
    return ['state' => 'closed', 'text' => __('Closed', 'idev-clinic-schedule') . $er];
}

function idev_cs_render_open_status() {
    idev_cs_assets();
    $s = idev_cs_open_status();
    return '<div class="idev-open-status-wrap"><span class="idev-open-status is-' . esc_attr($s['state']) . '">' . esc_html($s['text']) . '</span></div>';
}
add_shortcode('idev_open_status', 'idev_cs_render_open_status');
