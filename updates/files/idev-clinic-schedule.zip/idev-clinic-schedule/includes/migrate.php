<?php
/** One-time import of doctors, times, templates and settings from the Andaman Hub plugin. */
defined('ABSPATH') || exit;

function idev_cs_migrate() {
    global $wpdb;
    if (get_option('idev_cs_migrated')) return;
    $ids = $wpdb->get_col("SELECT ID FROM {$wpdb->posts} WHERE post_type='ah_provider'");
    if ($ids) {
        $list = implode(',', array_map('intval', $ids));
        $wpdb->query("UPDATE {$wpdb->posts} SET post_type='idev_provider' WHERE ID IN ({$list})");
        foreach (['kind', 'name_en', 'specialty', 'specialty_en', 'note', 'note_en', 'bio', 'bio_en', 'booking_url', 'slots'] as $k) {
            $wpdb->query($wpdb->prepare("INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) SELECT post_id, %s, meta_value FROM {$wpdb->postmeta} WHERE meta_key=%s AND post_id IN ({$list})", "_idev_{$k}", "ah_{$k}"));
        }
        // Specialty text → specialty terms (for the team tabs).
        idev_cs_register_types();
        foreach ($ids as $id) {
            $th = trim((string) get_post_meta($id, '_idev_specialty', true));
            if ($th === '') continue;
            $term = term_exists($th, 'idev_specialty') ?: wp_insert_term($th, 'idev_specialty');
            if (is_wp_error($term)) continue;
            $tid = (int) (is_array($term) ? $term['term_id'] : $term);
            $en = (string) get_post_meta($id, '_idev_specialty_en', true);
            if ($en !== '' && !get_term_meta($tid, 'idev_name_en', true)) update_term_meta($tid, 'idev_name_en', $en);
            wp_set_object_terms($id, [$tid], 'idev_specialty', true);
        }
        clean_post_cache(0);
    }
    $templates = get_option('ah_schedule_templates');
    if (is_array($templates) && !get_option('idev_cs_templates')) update_option('idev_cs_templates', $templates, false);
    $old = get_option('ah_settings');
    if (is_array($old) && !get_option('idev_clinic_schedule')) {
        $s = idev_cs_defaults();
        foreach (['appointment_url', 'phone', 'hours'] as $k) if (!empty($old[$k])) $s[$k] = $old[$k];
        $s['emergency_24h'] = ($old['emergency_24h'] ?? '') === 'true' ? '1' : '0';
        $doctors = get_page_by_path('doctors');
        if ($doctors) $s['schedule_page'] = (string) $doctors->ID;
        add_option('idev_clinic_schedule', $s);
    }
    update_option('idev_cs_migrated', 1, false);
}
