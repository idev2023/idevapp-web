<?php
/** Doctor team: photo, specialty, profile and a link to each doctor's schedule, with specialty tabs. */
defined('ABSPATH') || exit;

/** $args: kind (doctor|clinic|all), columns (2-4), tabs (bool), bio (bool), schedule_link (bool), specialty (slug) */
function idev_cs_render_team($args = []) {
    idev_cs_assets();
    $a = array_merge(['kind' => 'doctor', 'columns' => 3, 'tabs' => true, 'bio' => true, 'schedule_link' => true, 'specialty' => ''], $args);
    $people = array_values(array_filter(idev_cs_providers(), function ($p) use ($a) {
        if ($a['kind'] !== 'all' && $p['kind'] !== $a['kind']) return false;
        return !$a['specialty'] || in_array($a['specialty'], array_column($p['specialties'], 'slug'), true);
    }));
    if (!$people) return '';
    $lang = idev_lang();
    // Tabs: specialty terms; people without one go to "Other". Falls back to the specialty text when no terms are used.
    $groups = [];
    $use_terms = (bool) array_filter(array_column($people, 'specialties'));
    foreach ($people as $p) {
        if ($use_terms) {
            $list = $p['specialties'] ?: [['slug' => 'other', 'name' => 'อื่น ๆ', 'name_en' => 'Other', 'order' => 9999]];
            foreach ($list as $t) { $groups[$t['slug']] = $groups[$t['slug']] ?? ['label' => idev_pick($t['name'], $t['name_en'] ?: ($t['slug'] === 'other' ? 'Other' : ''), $lang), 'order' => $t['order'] ?? 0]; }
        } else {
            $label = idev_pick($p['specialty'], $p['specialty_en'], $lang);
            if ($label !== '') $groups[sanitize_title($p['specialty'] ?: $label)] = $groups[sanitize_title($p['specialty'] ?: $label)] ?? ['label' => $label, 'order' => 0];
        }
    }
    uasort($groups, function ($x, $y) { return [$x['order'], $x['label']] <=> [$y['order'], $y['label']]; });
    $show_tabs = $a['tabs'] && count($groups) > 1;
    $schedule = idev_cs_schedule_url();
    $id = 'idev-team-' . wp_rand(1000, 9999);
    $html = '<div class="idev-team" id="' . $id . '">';
    if ($show_tabs) {
        $html .= '<div class="idev-team-tabs" role="tablist"><button type="button" role="tab" class="is-active" aria-selected="true" data-tab="">' . esc_html__('All', 'idev-clinic-schedule') . ' <span>' . count($people) . '</span></button>';
        foreach ($groups as $slug => $g) {
            $n = count(array_filter($people, function ($p) use ($slug, $use_terms) { return in_array($slug, idev_cs_team_slugs($p, $use_terms), true); }));
            $html .= '<button type="button" role="tab" aria-selected="false" data-tab="' . esc_attr($slug) . '">' . esc_html($g['label']) . ' <span>' . $n . '</span></button>';
        }
        $html .= '</div>';
    }
    $html .= '<div class="idev-team-grid cols-' . max(2, min(4, (int) $a['columns'])) . '">';
    foreach ($people as $p) {
        $photo = $p['photo_large'] ? '<img src="' . esc_url($p['photo_large']) . '" alt="" loading="lazy">' : '<span class="idev-team-ph' . ($p['kind'] === 'clinic' ? ' is-clinic' : '') . '">' . idev_icon($p['kind'] === 'clinic' ? 'plus' : 'stethoscope') . '</span>';
        $spec = idev_pick($p['specialty'], $p['specialty_en'], $lang);
        $bio = idev_pick($p['bio'], $p['bio_en'], $lang);
        $html .= '<article class="idev-team-card" data-groups="' . esc_attr(implode(' ', idev_cs_team_slugs($p, $use_terms))) . '"><div class="idev-team-photo' . ($p['photo_large'] ? '' : ' is-empty') . '">' . $photo . '</div><div class="idev-team-body"><h3>' . esc_html(idev_pick($p['name'], $p['name_en'], $lang)) . '</h3>';
        if ($spec !== '') $html .= '<span class="idev-team-spec">' . esc_html($spec) . '</span>';
        if ($a['bio'] && $bio !== '') $html .= '<p>' . nl2br(esc_html($bio)) . '</p>';
        if ($a['schedule_link'] && $p['slots']) $html .= '<a class="idev-team-link" href="' . esc_url(add_query_arg('provider', $p['id'], $schedule)) . '">' . esc_html__('View clinic times', 'idev-clinic-schedule') . ' →</a>';
        $html .= '</div></article>';
    }
    return $html . '</div></div>';
}
function idev_cs_team_slugs($p, $use_terms) {
    if ($use_terms) return $p['specialties'] ? array_column($p['specialties'], 'slug') : ['other'];
    $label = $p['specialty'] ?: $p['specialty_en'];
    return $label !== '' ? [sanitize_title($label)] : [];
}

add_shortcode('idev_doctors', function ($atts) {
    $a = shortcode_atts(['kind' => 'doctor', 'columns' => '3', 'tabs' => '1', 'bio' => '1', 'schedule_link' => '1', 'specialty' => ''], $atts);
    return idev_cs_render_team(['kind' => in_array($a['kind'], ['doctor', 'clinic', 'all'], true) ? $a['kind'] : 'doctor', 'columns' => (int) $a['columns'], 'tabs' => $a['tabs'] !== '0', 'bio' => $a['bio'] !== '0', 'schedule_link' => $a['schedule_link'] !== '0', 'specialty' => sanitize_title($a['specialty'])]);
});
