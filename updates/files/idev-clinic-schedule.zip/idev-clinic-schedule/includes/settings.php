<?php
defined('ABSPATH') || exit;

function idev_cs_defaults() {
    return ['appointment_url' => '', 'phone' => '', 'schedule_page' => '0', 'default_view' => 'week', 'booking_hint' => '1', 'hours' => '', 'emergency_24h' => '0', 'primary' => '#169c91', 'accent' => '#ed345d', 'keep_data' => '1'];
}
function idev_cs_settings() {
    static $cache = null;
    if ($cache === null) { $s = get_option('idev_clinic_schedule', []); $cache = array_merge(idev_cs_defaults(), is_array($s) ? $s : []); }
    return $cache;
}
function idev_cs_setting($key) { return (string) (idev_cs_settings()[$key] ?? ''); }

/** Opening hours: 7 rows (1 = Monday) with open/close times. */
function idev_cs_hours() {
    $saved = json_decode(idev_cs_setting('hours'), true);
    $hours = [];
    for ($day = 1; $day <= 7; $day++) {
        $row = is_array($saved) && isset($saved[$day - 1]) && is_array($saved[$day - 1]) ? $saved[$day - 1] : [];
        $hours[$day] = ['closed' => !empty($row['closed']), 'open' => preg_match('/^\d{2}:\d{2}$/', $row['open'] ?? '') ? $row['open'] : '08:00', 'close' => preg_match('/^\d{2}:\d{2}$/', $row['close'] ?? '') ? $row['close'] : '20:00'];
    }
    return $hours;
}

/** Address of the clinic schedule page (Settings), used by "view schedule" links. */
function idev_cs_schedule_url() {
    $page = (int) idev_cs_setting('schedule_page');
    if ($page && get_post_status($page) === 'publish') return get_permalink($page);
    $found = get_page_by_path('doctors');
    return $found ? get_permalink($found) : home_url('/');
}

add_action('init', function () {
    load_plugin_textdomain('idev-clinic-schedule', false, dirname(plugin_basename(IDEV_CS_FILE)) . '/languages');
    idev_register_plugin('idev-clinic-schedule', ['name' => 'iDev Clinic Schedule', 'version' => IDEV_CS_VERSION, 'description' => __('Doctor and clinic schedules, opening hours and the doctor team.', 'idev-clinic-schedule'), 'settings' => admin_url('edit.php?post_type=idev_provider&page=idev-cs-settings'), 'docs' => 'https://idevapp.me/plugins/idev-clinic-schedule']);
});
add_action('plugins_loaded', function () { idev_plugin_links(IDEV_CS_FILE, admin_url('edit.php?post_type=idev_provider&page=idev-cs-settings'), 'https://idevapp.me/plugins/idev-clinic-schedule'); });

add_action('admin_menu', function () {
    add_submenu_page('edit.php?post_type=idev_provider', __('Settings', 'idev-clinic-schedule'), __('Settings', 'idev-clinic-schedule'), 'manage_options', 'idev-cs-settings', 'idev_cs_settings_page');
});

function idev_cs_settings_page() {
    if (!current_user_can('manage_options')) return;
    $pages = ['0' => __('— automatic (page "doctors") —', 'idev-clinic-schedule')];
    foreach (get_pages() as $p) $pages[(string) $p->ID] = $p->post_title;
    $fields = [
        ['appointment_url', __('Booking system link', 'idev-clinic-schedule'), 'url', __('Clinic times link here unless a doctor/clinic has its own booking link.', 'idev-clinic-schedule')],
        ['phone', __('Phone number', 'idev-clinic-schedule'), 'text', __('Shown when there is no schedule yet.', 'idev-clinic-schedule')],
        ['schedule_page', __('Schedule page', 'idev-clinic-schedule'), 'select', __('Where "view schedule" links go (the page with [idev_schedule]).', 'idev-clinic-schedule'), $pages],
        ['default_view', __('Default view', 'idev-clinic-schedule'), 'select', '', ['week' => __('Week', 'idev-clinic-schedule'), 'month' => __('Month', 'idev-clinic-schedule'), 'day' => __('Day', 'idev-clinic-schedule')]],
        ['booking_hint', __('Show "tap a time to book"', 'idev-clinic-schedule'), 'checkbox'],
        ['heading_hours', __('Opening hours', 'idev-clinic-schedule'), 'heading', __('Used for the live status "Open now · closes 20:00" ([idev_open_status]). Holidays that close clinics are taken into account.', 'idev-clinic-schedule')],
        ['emergency_24h', __('Emergency unit open 24 hours (mentioned when the clinic is closed)', 'idev-clinic-schedule'), 'checkbox'],
        ['heading_look', __('Colours', 'idev-clinic-schedule'), 'heading'],
        ['primary', __('Main colour', 'idev-clinic-schedule'), 'color'],
        ['accent', __('Accent colour', 'idev-clinic-schedule'), 'color'],
        ['keep_data', __('Keep doctors and times when the plugin is deleted', 'idev-clinic-schedule'), 'checkbox'],
    ];
    $s = idev_cs_settings();
    if (isset($_POST['idev_clinic_schedule']) && check_admin_referer('idev_cs_settings')) {
        $s = idev_settings_sanitize($fields, $_POST['idev_clinic_schedule'], $s);
        $rows = [];
        for ($d = 1; $d <= 7; $d++) {
            $r = isset($_POST['idev_hours'][$d]) ? wp_unslash($_POST['idev_hours'][$d]) : [];
            $t = function ($v, $def) { return preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', (string) $v) ? $v : $def; };
            $rows[] = ['closed' => !empty($r['closed']), 'open' => $t($r['open'] ?? '', '08:00'), 'close' => $t($r['close'] ?? '', '20:00')];
        }
        $s['hours'] = wp_json_encode($rows);
        update_option('idev_clinic_schedule', $s);
        echo '<div class="notice notice-success"><p>' . esc_html__('Saved.', 'idev-clinic-schedule') . '</p></div>';
    }
    idev_admin_header(__('Clinic schedule settings', 'idev-clinic-schedule'));
    echo '<form method="post">';
    wp_nonce_field('idev_cs_settings');
    $before = array_slice($fields, 0, 6); $after = array_slice($fields, 6);
    idev_settings_table('idev_clinic_schedule', $before, $s);
    echo '<table class="form-table"><tr><th>' . esc_html__('Clinic hours', 'idev-clinic-schedule') . '</th><td><table>';
    $days = idev_weekdays(strpos(get_user_locale(), 'th') === 0 ? 'th' : 'en');
    $hours = idev_cs_hours();
    foreach ($hours as $d => $r) echo '<tr><th style="padding:4px 14px 4px 0;text-align:left">' . esc_html($days[$d - 1]) . '</th><td><input type="time" name="idev_hours[' . $d . '][open]" value="' . esc_attr($r['open']) . '"> – <input type="time" name="idev_hours[' . $d . '][close]" value="' . esc_attr($r['close']) . '"> <label><input type="checkbox" name="idev_hours[' . $d . '][closed]" value="1"' . checked($r['closed'], true, false) . '> ' . esc_html__('Closed all day', 'idev-clinic-schedule') . '</label></td></tr>';
    echo '</table></td></tr></table>';
    idev_settings_table('idev_clinic_schedule', $after, $s);
    submit_button();
    echo '</form><div class="idev-box"><h2>' . esc_html__('Shortcodes', 'idev-clinic-schedule') . '</h2><ul style="list-style:disc;padding-left:20px">';
    foreach ([
        '[idev_schedule]' => __('Schedule with month / week / day buttons, filters and date navigation.', 'idev-clinic-schedule'),
        '[idev_schedule view="day" navigation="0"]' => __('Today only, without buttons (e.g. on the home page).', 'idev-clinic-schedule'),
        '[idev_doctors]' => __('Doctor team with specialty tabs. Options: kind="doctor|clinic|all" columns="3" tabs="1" bio="1".', 'idev-clinic-schedule'),
        '[idev_open_status]' => __('"Open now · closes 20:00" from the opening hours above.', 'idev-clinic-schedule'),
    ] as $code => $text) echo '<li><code>' . esc_html($code) . '</code> — ' . esc_html($text) . '</li>';
    echo '</ul><p>' . esc_html__('The same are available as blocks in the "iDevApp" block category.', 'idev-clinic-schedule') . '</p></div></div>';
}
