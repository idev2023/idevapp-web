<?php
defined('ABSPATH') || exit;

function idev_cs_register_types() {
    register_post_type('idev_provider', [
        'labels' => ['name' => __('Doctors & clinics', 'idev-clinic-schedule'), 'singular_name' => __('Doctor / clinic', 'idev-clinic-schedule'), 'add_new' => __('Add doctor / clinic', 'idev-clinic-schedule'), 'add_new_item' => __('Add doctor or clinic', 'idev-clinic-schedule'), 'edit_item' => __('Edit doctor / clinic', 'idev-clinic-schedule'), 'all_items' => __('Doctors & clinics', 'idev-clinic-schedule'), 'menu_name' => __('Clinic schedule', 'idev-clinic-schedule'), 'search_items' => __('Search', 'idev-clinic-schedule'), 'not_found' => __('Nothing yet', 'idev-clinic-schedule')],
        'public' => false, 'show_ui' => true, 'show_in_menu' => true, 'menu_icon' => 'dashicons-calendar-alt', 'menu_position' => 25,
        'supports' => ['title', 'thumbnail', 'page-attributes'], 'map_meta_cap' => true, 'capability_type' => 'post',
    ]);
    register_taxonomy('idev_specialty', 'idev_provider', [
        'labels' => ['name' => __('Specialties', 'idev-clinic-schedule'), 'singular_name' => __('Specialty', 'idev-clinic-schedule'), 'add_new_item' => __('Add specialty', 'idev-clinic-schedule'), 'edit_item' => __('Edit specialty', 'idev-clinic-schedule'), 'menu_name' => __('Specialties', 'idev-clinic-schedule')],
        'public' => false, 'show_ui' => true, 'show_admin_column' => true, 'hierarchical' => true, 'show_in_rest' => false,
    ]);
}
add_action('init', 'idev_cs_register_types');

function idev_cs_meta($post_id, $key) { return (string) get_post_meta($post_id, "_idev_{$key}", true); }

/** One doctor/clinic as an array. */
function idev_cs_provider($post) {
    $slots = json_decode(idev_cs_meta($post->ID, 'slots') ?: '[]', true);
    $terms = get_the_terms($post->ID, 'idev_specialty');
    $specialties = [];
    foreach (is_array($terms) ? $terms : [] as $t) $specialties[] = ['id' => $t->term_id, 'slug' => $t->slug, 'name' => $t->name, 'name_en' => (string) get_term_meta($t->term_id, 'idev_name_en', true), 'order' => (int) get_term_meta($t->term_id, 'idev_order', true)];
    return [
        'id' => $post->ID, 'kind' => idev_cs_meta($post->ID, 'kind') === 'clinic' ? 'clinic' : 'doctor', 'name' => $post->post_title, 'name_en' => idev_cs_meta($post->ID, 'name_en'),
        'specialty' => idev_cs_meta($post->ID, 'specialty'), 'specialty_en' => idev_cs_meta($post->ID, 'specialty_en'), 'note' => idev_cs_meta($post->ID, 'note'), 'note_en' => idev_cs_meta($post->ID, 'note_en'),
        'bio' => idev_cs_meta($post->ID, 'bio'), 'bio_en' => idev_cs_meta($post->ID, 'bio_en'), 'booking_url' => idev_cs_meta($post->ID, 'booking_url'),
        'photo' => (string) get_the_post_thumbnail_url($post, 'thumbnail'), 'photo_large' => (string) get_the_post_thumbnail_url($post, 'medium_large'),
        'specialties' => $specialties, 'slots' => is_array($slots) ? $slots : [],
    ];
}

/** Published doctors/clinics in display order. */
function idev_cs_providers($include_hidden = false) {
    $posts = get_posts(['post_type' => 'idev_provider', 'post_status' => $include_hidden ? ['publish', 'draft', 'pending', 'private'] : 'publish', 'numberposts' => -1, 'orderby' => ['menu_order' => 'ASC', 'title' => 'ASC']]);
    return array_map('idev_cs_provider', $posts);
}

function idev_cs_templates() { $t = get_option('idev_cs_templates', []); return is_array($t) ? array_values($t) : []; }

/* ---------- Edit screen ---------- */

add_filter('enter_title_here', function ($text, $post) { return $post->post_type === 'idev_provider' ? __('Name (e.g. Dr. Somchai Jaidee or Antenatal clinic)', 'idev-clinic-schedule') : $text; }, 10, 2);

add_action('add_meta_boxes_idev_provider', function () {
    add_meta_box('idev_cs_box', __('Details and clinic times', 'idev-clinic-schedule'), 'idev_cs_box', 'idev_provider', 'normal', 'high');
});

function idev_cs_box($post) {
    $p = idev_cs_provider($post);
    wp_nonce_field('idev_cs_save', 'idev_cs_nonce');
    $f = function ($key, $label, $placeholder = '', $type = 'text') use ($p) { return '<label>' . esc_html($label) . '<input type="' . $type . '" name="idev_cs[' . $key . ']" value="' . esc_attr($p[$key]) . '" placeholder="' . esc_attr($placeholder) . '"></label>'; };
    $ta = function ($key, $label) use ($p) { return '<label>' . esc_html($label) . '<textarea name="idev_cs[' . $key . ']" rows="3">' . esc_textarea($p[$key]) . '</textarea></label>'; };
    echo '<div class="idev-form idev-cs-box"><fieldset class="idev-cs-kind"><legend>' . esc_html__('Type', 'idev-clinic-schedule') . '</legend>';
    echo '<label><input type="radio" name="idev_cs[kind]" value="doctor"' . checked($p['kind'], 'doctor', false) . '> <span><strong>👩‍⚕️ ' . esc_html__('Doctor', 'idev-clinic-schedule') . '</strong></span></label>';
    echo '<label><input type="radio" name="idev_cs[kind]" value="clinic"' . checked($p['kind'], 'clinic', false) . '> <span><strong>🏥 ' . esc_html__('Clinic / department', 'idev-clinic-schedule') . '</strong></span></label></fieldset>';
    echo '<div class="idev-grid2">' . $f('name_en', __('Name (English)', 'idev-clinic-schedule')) . '<span></span>';
    echo $f('specialty', __('Specialty / details', 'idev-clinic-schedule'), __('e.g. Internal medicine, 2nd floor', 'idev-clinic-schedule')) . $f('specialty_en', __('Specialty (English)', 'idev-clinic-schedule'));
    echo $f('note', __('Note', 'idev-clinic-schedule'), __('e.g. appointments only', 'idev-clinic-schedule')) . $f('note_en', __('Note (English)', 'idev-clinic-schedule'));
    echo $ta('bio', __('Profile (shown in the doctor team)', 'idev-clinic-schedule')) . $ta('bio_en', __('Profile (English)', 'idev-clinic-schedule')) . '</div>';
    echo '<label>' . esc_html__('Booking link (empty = the link in Settings)', 'idev-clinic-schedule') . '<input type="url" name="idev_cs[booking_url]" value="' . esc_attr($p['booking_url']) . '" placeholder="https://..."></label>';
    echo '<h3>' . esc_html__('Clinic times', 'idev-clinic-schedule') . '</h3><p class="description">' . esc_html__('Weekly, monthly (e.g. 1st and 3rd Wednesday, or every 15th), yearly or on a date, optionally only within a date range. Hide from the schedule: set to Draft. Order: Attributes → Order. Specialty tabs: "Specialties" box on the right.', 'idev-clinic-schedule') . '</p>';
    $sources = [];
    foreach (idev_cs_providers(true) as $o) if ($o['id'] !== $post->ID && $o['slots']) $sources[] = ['id' => $o['id'], 'name' => $o['name'], 'slots' => $o['slots']];
    echo '<div id="idev-cs-slots" data-slots="' . esc_attr(wp_json_encode($p['slots'])) . '" data-templates="' . esc_attr(wp_json_encode(idev_cs_templates())) . '" data-sources="' . esc_attr(wp_json_encode($sources)) . '"></div>';
    echo '<input type="hidden" name="idev_cs[slots]" id="idev-cs-slots-input" value="' . esc_attr(wp_json_encode($p['slots'])) . '"></div>';
}

add_action('save_post_idev_provider', function ($post_id) {
    if (!isset($_POST['idev_cs_nonce']) || !wp_verify_nonce(sanitize_key($_POST['idev_cs_nonce']), 'idev_cs_save')) return;
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $post_id)) return;
    $in = isset($_POST['idev_cs']) && is_array($_POST['idev_cs']) ? wp_unslash($_POST['idev_cs']) : [];
    update_post_meta($post_id, '_idev_kind', ($in['kind'] ?? '') === 'clinic' ? 'clinic' : 'doctor');
    foreach (['name_en', 'specialty', 'specialty_en', 'note', 'note_en'] as $k) update_post_meta($post_id, "_idev_{$k}", sanitize_text_field($in[$k] ?? ''));
    foreach (['bio', 'bio_en'] as $k) update_post_meta($post_id, "_idev_{$k}", sanitize_textarea_field($in[$k] ?? ''));
    update_post_meta($post_id, '_idev_booking_url', esc_url_raw(trim($in['booking_url'] ?? ''), ['http', 'https']));
    update_post_meta($post_id, '_idev_slots', wp_slash(wp_json_encode(idev_cs_clean_slots(json_decode((string) ($in['slots'] ?? '[]'), true)), JSON_UNESCAPED_UNICODE)));
});

add_action('wp_ajax_idev_cs_template', function () {
    check_ajax_referer('idev_cs_slots', 'nonce');
    if (!current_user_can('edit_posts')) wp_send_json_error(__('Not allowed.', 'idev-clinic-schedule'), 403);
    $templates = idev_cs_templates();
    if (($_POST['do'] ?? '') === 'delete') {
        $id = sanitize_key($_POST['id'] ?? '');
        $templates = array_values(array_filter($templates, function ($t) use ($id) { return $t['id'] !== $id; }));
    } else {
        $name = mb_substr(sanitize_text_field(wp_unslash($_POST['name'] ?? '')), 0, 100);
        $slots = idev_cs_clean_slots(json_decode(wp_unslash($_POST['slots'] ?? '[]'), true));
        if ($name === '' || !$slots) wp_send_json_error(__('Give the template a name and at least one valid time.', 'idev-clinic-schedule'));
        $templates[] = ['id' => substr(md5(uniqid('', true)), 0, 10), 'name' => $name, 'slots' => $slots];
    }
    update_option('idev_cs_templates', $templates, false);
    wp_send_json_success($templates);
});

/* ---------- List screen ---------- */

add_filter('manage_idev_provider_posts_columns', function ($c) {
    return ['cb' => $c['cb'], 'title' => __('Name', 'idev-clinic-schedule'), 'idev_kind' => __('Type', 'idev-clinic-schedule'), 'taxonomy-idev_specialty' => __('Specialties', 'idev-clinic-schedule'), 'idev_slots' => __('Clinic times', 'idev-clinic-schedule'), 'idev_order' => __('Order', 'idev-clinic-schedule'), 'date' => $c['date']];
});
add_action('manage_idev_provider_posts_custom_column', function ($col, $id) {
    if ($col === 'idev_kind') echo idev_cs_meta($id, 'kind') === 'clinic' ? '🏥 ' . esc_html__('Clinic', 'idev-clinic-schedule') : '👩‍⚕️ ' . esc_html__('Doctor', 'idev-clinic-schedule');
    if ($col === 'idev_slots') { $n = count(json_decode(idev_cs_meta($id, 'slots') ?: '[]', true) ?: []); echo $n ? esc_html(sprintf(_n('%d time', '%d times', $n, 'idev-clinic-schedule'), $n)) : '<span style="color:#b32d2e">' . esc_html__('No times yet', 'idev-clinic-schedule') . '</span>'; }
    if ($col === 'idev_order') echo (int) get_post_field('menu_order', $id);
}, 10, 2);
add_filter('post_row_actions', function ($a, $post) {
    if ($post->post_type === 'idev_provider' && current_user_can('edit_post', $post->ID)) $a['idev_dup'] = '<a href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=idev_cs_duplicate&id=' . $post->ID), 'idev_cs_dup_' . $post->ID)) . '">' . esc_html__('Duplicate with times', 'idev-clinic-schedule') . '</a>';
    return $a;
}, 10, 2);
add_action('admin_post_idev_cs_duplicate', function () {
    $id = (int) ($_GET['id'] ?? 0);
    if (!current_user_can('edit_post', $id) || !check_admin_referer('idev_cs_dup_' . $id)) wp_die(esc_html__('Not allowed.', 'idev-clinic-schedule'));
    $src = get_post($id);
    $copy = wp_insert_post(['post_type' => 'idev_provider', 'post_status' => 'draft', 'post_title' => $src->post_title . ' ' . __('(copy)', 'idev-clinic-schedule'), 'menu_order' => $src->menu_order]);
    foreach (get_post_meta($id) as $k => $v) if (strpos($k, '_idev_') === 0 || $k === '_thumbnail_id') update_post_meta($copy, $k, wp_slash(maybe_unserialize($v[0])));
    wp_set_object_terms($copy, wp_get_object_terms($id, 'idev_specialty', ['fields' => 'ids']), 'idev_specialty');
    wp_safe_redirect(admin_url("post.php?post={$copy}&action=edit"));
    exit;
});

/* ---------- Specialty: English name and tab order ---------- */

add_action('idev_specialty_edit_form_fields', function ($term) {
    echo '<tr class="form-field"><th><label>' . esc_html__('Name in English', 'idev-clinic-schedule') . '</label></th><td><input name="idev_name_en" value="' . esc_attr(get_term_meta($term->term_id, 'idev_name_en', true)) . '"></td></tr>';
    echo '<tr class="form-field"><th><label>' . esc_html__('Tab order', 'idev-clinic-schedule') . '</label></th><td><input type="number" name="idev_order" value="' . esc_attr(get_term_meta($term->term_id, 'idev_order', true)) . '"><p class="description">' . esc_html__('Smaller numbers come first.', 'idev-clinic-schedule') . '</p></td></tr>';
});
add_action('idev_specialty_add_form_fields', function () {
    echo '<div class="form-field"><label>' . esc_html__('Name in English', 'idev-clinic-schedule') . '</label><input name="idev_name_en"></div><div class="form-field"><label>' . esc_html__('Tab order', 'idev-clinic-schedule') . '</label><input type="number" name="idev_order" value="10"></div>';
});
foreach (['edited_idev_specialty', 'created_idev_specialty'] as $idev_hook) add_action($idev_hook, function ($term_id) {
    if (isset($_POST['idev_name_en'])) update_term_meta($term_id, 'idev_name_en', sanitize_text_field(wp_unslash($_POST['idev_name_en'])));
    if (isset($_POST['idev_order'])) update_term_meta($term_id, 'idev_order', (int) $_POST['idev_order']);
});

add_action('admin_enqueue_scripts', function ($hook) {
    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== 'idev_provider' || !in_array($hook, ['post.php', 'post-new.php'], true)) return;
    wp_enqueue_style('idev-cs-admin', IDEV_CS_URL . 'assets/admin.css', [], IDEV_CS_VERSION);
    wp_enqueue_script('idev-cs-slots', IDEV_CS_URL . 'assets/slots.js', [], IDEV_CS_VERSION, true);
    $lang = strpos(get_user_locale(), 'th') === 0 ? 'th' : 'en';
    wp_localize_script('idev-cs-slots', 'IDEV_CS', ['ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('idev_cs_slots'), 'days' => idev_weekdays($lang), 'months' => idev_months($lang), 'buddhist' => $lang === 'th', 'L' => [
        'weekly' => __('Every week', 'idev-clinic-schedule'), 'monthly_week' => __('Every month (week number)', 'idev-clinic-schedule'), 'monthly_day' => __('Every month (date)', 'idev-clinic-schedule'), 'yearly' => __('Every year', 'idev-clinic-schedule'), 'date' => __('On a date', 'idev-clinic-schedule'),
        'repeat' => __('Repeats', 'idev-clinic-schedule'), 'day' => __('Day', 'idev-clinic-schedule'), 'week' => __('Week', 'idev-clinic-schedule'), 'date_label' => __('Date', 'idev-clinic-schedule'), 'month' => __('Month', 'idev-clinic-schedule'), 'from' => __('From', 'idev-clinic-schedule'), 'to' => __('To', 'idev-clinic-schedule'),
        'weeks' => [__('1st week', 'idev-clinic-schedule'), __('2nd week', 'idev-clinic-schedule'), __('3rd week', 'idev-clinic-schedule'), __('4th week', 'idev-clinic-schedule'), __('Last week', 'idev-clinic-schedule')],
        'everyDay' => __('Every %s', 'idev-clinic-schedule'), 'nthDay' => __('%1$s, %2$s of the month', 'idev-clinic-schedule'), 'dayOfMonth' => __('Day %s of every month', 'idev-clinic-schedule'), 'yearlyOn' => __('Every year on %s', 'idev-clinic-schedule'),
        'check' => __('Please complete this row', 'idev-clinic-schedule'), 'copy' => __('Duplicate', 'idev-clinic-schedule'), 'remove' => __('Remove', 'idev-clinic-schedule'), 'more' => __('Date range / note', 'idev-clinic-schedule'),
        'validFrom' => __('Valid from', 'idev-clinic-schedule'), 'validUntil' => __('Valid until', 'idev-clinic-schedule'), 'note' => __('Note', 'idev-clinic-schedule'), 'noteEn' => __('Note (English)', 'idev-clinic-schedule'), 'rangeHint' => __('Empty = always valid.', 'idev-clinic-schedule'),
        'empty' => __('No clinic times yet. Add them with the buttons below or use a template.', 'idev-clinic-schedule'),
        'addOne' => __('+ Add time', 'idev-clinic-schedule'), 'addWeekdays' => __('+ Mon–Fri', 'idev-clinic-schedule'), 'addWeekend' => __('+ Sat–Sun', 'idev-clinic-schedule'), 'addMonthly' => __('+ Monthly', 'idev-clinic-schedule'), 'addDate' => __('+ One day', 'idev-clinic-schedule'),
        'useTemplate' => __('Use template', 'idev-clinic-schedule'), 'chooseTemplate' => __('— choose a template —', 'idev-clinic-schedule'), 'copyFrom' => __('Copy times from', 'idev-clinic-schedule'), 'chooseSource' => __('— choose doctor / clinic —', 'idev-clinic-schedule'),
        'saveTemplate' => __('Save as template', 'idev-clinic-schedule'), 'manageTemplates' => __('Manage templates', 'idev-clinic-schedule'), 'count' => __('%d times', 'idev-clinic-schedule'),
        'invalid' => __('Some rows are incomplete (end must be after start, choose a day/date). Incomplete rows are not saved.', 'idev-clinic-schedule'),
        'confirmUse' => __('Use the times from "%s"? OK = replace all current times · Cancel = add them to the end', 'idev-clinic-schedule'), 'used' => __('Times from "%s" added. Remember to update.', 'idev-clinic-schedule'),
        'namePrompt' => __('Template name, e.g. "Medicine Mon–Fri mornings"', 'idev-clinic-schedule'), 'savedTemplate' => __('Template "%s" saved.', 'idev-clinic-schedule'), 'failed' => __('Could not save.', 'idev-clinic-schedule'), 'confirmDelete' => __('Delete this template?', 'idev-clinic-schedule'),
    ]]);
});
