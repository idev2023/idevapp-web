<?php
/** Recurrence rules and the public month / week / day schedule. */
defined('ABSPATH') || exit;

function idev_cs_recurrences() { return ['weekly', 'monthly_week', 'monthly_day', 'yearly', 'date']; }

/** Does this slot take place on the given date? */
function idev_cs_occurs_on($slot, $date) {
    if (!empty($slot['valid_from']) && $date < $slot['valid_from']) return false;
    if (!empty($slot['valid_until']) && $date > $slot['valid_until']) return false;
    [, $month, $day] = array_map('intval', explode('-', $date));
    $weekday = idev_iso_weekday($date);
    switch ($slot['recurrence'] ?? 'weekly') {
        case 'weekly': return $weekday === (int) $slot['weekday'];
        case 'monthly_week':
            if ($weekday !== (int) $slot['weekday']) return false;
            if ((int) $slot['week_of_month'] === 5) return (int) idev_parse_date(idev_add_days($date, 7))->format('n') !== $month;
            return (int) ceil($day / 7) === (int) $slot['week_of_month'];
        case 'monthly_day': return $day === (int) $slot['day_of_month'];
        case 'yearly': return $day === (int) $slot['day_of_month'] && $month === (int) $slot['month_of_year'];
        case 'date': return ($slot['on_date'] ?? '') === $date;
    }
    return false;
}

/** Validates one slot; returns null when it cannot be used. */
function idev_cs_clean_slot($raw) {
    $v = is_array($raw) ? $raw : [];
    $time = '/^([01]\d|2[0-3]):[0-5]\d$/';
    $start = substr((string) ($v['start_time'] ?? ''), 0, 5);
    $end = substr((string) ($v['end_time'] ?? ''), 0, 5);
    if (!preg_match($time, $start) || !preg_match($time, $end) || $end <= $start) return null;
    $rec = in_array($v['recurrence'] ?? '', idev_cs_recurrences(), true) ? $v['recurrence'] : 'weekly';
    $int = function ($x, $min, $max) { return (is_numeric($x) && (int) $x == $x && $x >= $min && $x <= $max) ? (int) $x : null; };
    $date = function ($x) { return idev_is_valid_date($x) ? $x : null; };
    $s = ['recurrence' => $rec, 'weekday' => $int($v['weekday'] ?? null, 1, 7), 'week_of_month' => $int($v['week_of_month'] ?? null, 1, 5), 'day_of_month' => $int($v['day_of_month'] ?? null, 1, 31), 'month_of_year' => $int($v['month_of_year'] ?? null, 1, 12),
        'on_date' => $date($v['on_date'] ?? null), 'valid_from' => $date($v['valid_from'] ?? null), 'valid_until' => $date($v['valid_until'] ?? null), 'start_time' => $start, 'end_time' => $end,
        'note' => mb_substr(sanitize_text_field((string) ($v['note'] ?? '')), 0, 120), 'note_en' => mb_substr(sanitize_text_field((string) ($v['note_en'] ?? '')), 0, 120)];
    if (in_array($rec, ['weekly', 'monthly_week'], true) && !$s['weekday']) return null;
    if ($rec === 'monthly_week' && !$s['week_of_month']) return null;
    if (in_array($rec, ['monthly_day', 'yearly'], true) && !$s['day_of_month']) return null;
    if ($rec === 'yearly' && !$s['month_of_year']) return null;
    if ($rec === 'date' && !$s['on_date']) return null;
    if ($s['valid_from'] && $s['valid_until'] && $s['valid_until'] < $s['valid_from']) return null;
    return $s;
}
function idev_cs_clean_slots($list) {
    if (!is_array($list)) return [];
    $slots = array_values(array_filter(array_map('idev_cs_clean_slot', array_slice($list, 0, 100))));
    usort($slots, function ($a, $b) { return strcmp($a['start_time'], $b['start_time']); });
    return $slots;
}

function idev_cs_month_start($d) { return substr($d, 0, 7) . '-01'; }
function idev_cs_shift_month($d, $step) { return idev_parse_date(idev_cs_month_start($d))->modify(($step >= 0 ? '+' : '') . (int) $step . ' month')->format('Y-m-d'); }

/** Holidays from iDev Thai Holidays, keyed by date. */
function idev_cs_holidays($from, $to) {
    if (!function_exists('idev_holidays_get')) return [];
    idev_holidays_ensure_years(range((int) substr($from, 0, 4), (int) substr($to, 0, 4)));
    $out = [];
    foreach (idev_holidays_get($from, $to) as $h) $out[$h['holiday_date']][] = $h;
    return $out;
}

/**
 * Schedule as a month calendar, week table or one day.
 * $args: view, default_view, date, kind (doctor|clinic), provider (id), specialty (slug), base_url, navigation (bool)
 */
function idev_cs_render_schedule($args = []) {
    idev_cs_assets();
    $lang = idev_lang();
    $today = idev_today();
    $views = ['month', 'week', 'day'];
    $default = in_array($args['default_view'] ?? '', $views, true) ? $args['default_view'] : idev_cs_setting('default_view');
    $view = in_array($args['view'] ?? '', $views, true) ? $args['view'] : $default;
    $anchor = idev_is_valid_date($args['date'] ?? '') ? $args['date'] : $today;
    $kind = in_array($args['kind'] ?? '', ['doctor', 'clinic'], true) ? $args['kind'] : '';
    $only = (int) ($args['provider'] ?? 0);
    $specialty = sanitize_title($args['specialty'] ?? '');
    $nav = !isset($args['navigation']) || $args['navigation'];
    $base = $args['base_url'] ?? (get_permalink() ?: home_url('/'));
    $days = idev_weekdays($lang);

    if ($view === 'day') $dates = [$anchor];
    elseif ($view === 'week') { $mon = idev_monday_of($anchor); $dates = []; for ($i = 0; $i < 7; $i++) $dates[] = idev_add_days($mon, $i); }
    else { $dates = []; for ($d = idev_monday_of(idev_cs_month_start($anchor)), $end = idev_add_days(idev_monday_of(idev_add_days(idev_cs_shift_month($anchor, 1), -1)), 6); $d <= $end; $d = idev_add_days($d, 1)) $dates[] = $d; }

    $all = idev_cs_providers();
    $providers = array_values(array_filter($all, function ($p) use ($kind, $specialty) {
        if ($kind && $p['kind'] !== $kind) return false;
        if ($specialty && !in_array($specialty, array_column($p['specialties'], 'slug'), true)) return false;
        return true;
    }));
    $single = null;
    foreach ($all as $p) if ($only && (int) $p['id'] === $only) $single = $p;
    if ($single) $providers = [$single];
    $holidays = idev_cs_holidays($dates[0], end($dates));
    $closed = function ($d) use ($holidays) { foreach ($holidays[$d] ?? [] as $h) if ($h['closes_clinics']) return $h; return null; };
    $entries_on = function ($d, $list = null) use ($providers, $closed) {
        if ($closed($d)) return [];
        $out = [];
        foreach ($list ?? $providers as $p) foreach ($p['slots'] as $s) if (idev_cs_occurs_on($s, $d)) $out[] = ['p' => $p, 's' => $s, 'd' => $d];
        usort($out, function ($a, $b) { return strcmp($a['s']['start_time'], $b['s']['start_time']); });
        return $out;
    };
    $book = idev_cs_setting('appointment_url');
    $name = function ($p) { return idev_pick($p['name'], $p['name_en']); };
    $href = function ($ch) use ($view, $anchor, $kind, $today, $base, $default, $only) {
        $q = [];
        $v = $ch['view'] ?? $view; $dt = $ch['date'] ?? $anchor; $k = array_key_exists('kind', $ch) ? $ch['kind'] : $kind;
        if ($v !== $default) $q['view'] = $v;
        if ($dt !== $today) $q['date'] = $dt;
        if ($k) $q['kind'] = $k;
        if ($only && !array_key_exists('kind', $ch)) $q['provider'] = $only;
        $url = remove_query_arg(['view', 'date', 'kind', 'provider', 'week'], $base);
        return esc_url($q ? add_query_arg($q, $url) : $url);
    };
    $step = function ($dir) use ($view, $anchor) { return $view === 'day' ? idev_add_days($anchor, $dir) : ($view === 'week' ? idev_add_days($anchor, $dir * 7) : idev_cs_shift_month($anchor, $dir)); };
    $chip = function ($e) use ($book, $name) {
        /** Filter: link of the "Book" button for one clinic time (iDev Appointments points it at its booking page). */
        $url = apply_filters('idev_cs_booking_url', $e['p']['booking_url'] ?: $book, $e['p'], $e['d'] ?? '', $e['s']);
        $external = $url && wp_parse_url($url, PHP_URL_HOST) && wp_parse_url($url, PHP_URL_HOST) !== wp_parse_url(home_url(), PHP_URL_HOST);
        $note = idev_pick($e['s']['note'], $e['s']['note_en']);
        $body = esc_html($e['s']['start_time'] . '–' . $e['s']['end_time']) . ($note !== '' ? '<small>' . esc_html($note) . '</small>' : '');
        if ($url) return '<a class="idev-sch-chip is-link" href="' . esc_url($url) . '"' . ($external ? ' target="_blank" rel="noopener noreferrer"' : '') . ' title="' . esc_attr(__('Book', 'idev-clinic-schedule') . ': ' . $name($e['p'])) . '">' . $body . '<span class="idev-sch-chip-book">' . esc_html__('Book', 'idev-clinic-schedule') . ($external ? ' ↗' : ' →') . '</span></a>';
        return '<span class="idev-sch-chip">' . $body . '</span>';
    };
    $tag = function ($d) use ($holidays) {
        $h = '';
        foreach ($holidays[$d] ?? [] as $x) $h .= '<span class="idev-sch-holiday' . ($x['closes_clinics'] ? ' is-closed' : '') . '">' . ($x['closes_clinics'] ? esc_html__('Closed', 'idev-clinic-schedule') . ' · ' : '') . esc_html(idev_pick($x['name'], $x['name_en'])) . '</span>';
        return $h;
    };
    $avatar = function ($p) { return $p['photo'] ? '<img src="' . esc_url($p['photo']) . '" alt="">' : '<span class="idev-sch-avatar' . ($p['kind'] === 'clinic' ? ' is-clinic' : '') . '">' . idev_icon($p['kind'] === 'clinic' ? 'plus' : 'stethoscope') . '</span>'; };
    $sub = function ($p) { $t = idev_pick($p['specialty'], $p['specialty_en']); return $t !== '' ? '<small>' . esc_html($t) . '</small>' : ''; };
    $day_card = function ($d, $large = false) use ($entries_on, $closed, $today, $days, $tag, $chip, $avatar, $name, $sub, $lang) {
        $e = $entries_on($d);
        $h = '<section class="idev-sch-day' . ($d === $today ? ' is-today' : '') . ($large ? ' is-large' : '') . ($closed($d) ? ' is-holiday' : '') . '"><h3>' . esc_html($days[idev_iso_weekday($d) - 1]) . ' <small>' . esc_html(idev_format_short($d, $lang)) . '</small>' . ($d === $today ? '<span class="idev-sch-badge">' . esc_html__('Today', 'idev-clinic-schedule') . '</span>' : '') . '</h3>' . $tag($d);
        if (!$closed($d)) {
            if ($e) { $h .= '<ul>'; foreach ($e as $x) $h .= '<li>' . $chip($x) . '<span class="idev-sch-day-person">' . ($large ? $avatar($x['p']) : '') . '<span><strong>' . esc_html($name($x['p'])) . '</strong>' . $sub($x['p']) . '</span></span></li>'; $h .= '</ul>'; }
            else $h .= '<p class="idev-sch-empty">' . esc_html($large ? __('No doctor or clinic is scheduled on this day.', 'idev-clinic-schedule') : __('No doctor scheduled', 'idev-clinic-schedule')) . '</p>';
        }
        return $h . '</section>';
    };

    if (!$all) {
        $phone = idev_cs_setting('phone');
        return '<div class="idev-sch-nodata">' . idev_icon('clock') . '<div><strong>' . esc_html__('No schedule has been published yet.', 'idev-clinic-schedule') . '</strong>' . ($phone ? '<p><a href="tel:' . esc_attr($phone) . '">' . esc_html(__('Call us', 'idev-clinic-schedule') . ' ' . $phone) . '</a></p>' : '') . '</div></div>';
    }
    $title = $view === 'day' ? idev_format_day($anchor, $lang, true) : ($view === 'week' ? idev_format_day($dates[0], $lang) . ' – ' . idev_format_day($dates[6], $lang) : idev_format_month($anchor, $lang));
    $current = $view === 'day' ? $anchor === $today : ($view === 'week' ? idev_monday_of($anchor) === idev_monday_of($today) : idev_cs_month_start($anchor) === idev_cs_month_start($today));
    $kinds = array_unique(array_column($all, 'kind'));

    $html = '<div class="idev-sch view-' . $view . '">';
    if ($single) $html .= '<div class="idev-sch-single">' . $avatar($single) . '<strong>' . esc_html(sprintf(__('Schedule of %s', 'idev-clinic-schedule'), $name($single))) . '</strong><a href="' . $href(['kind' => '']) . '">' . esc_html__('Show everyone', 'idev-clinic-schedule') . ' →</a></div>';
    if ($nav) {
        $html .= '<div class="idev-sch-toolbar"><div class="idev-sch-views" role="group" aria-label="' . esc_attr__('View', 'idev-clinic-schedule') . '">';
        foreach (['month' => __('Month', 'idev-clinic-schedule'), 'week' => __('Week', 'idev-clinic-schedule'), 'day' => __('Day', 'idev-clinic-schedule')] as $v => $l) $html .= '<a href="' . $href(['view' => $v]) . '"' . ($view === $v ? ' class="is-active" aria-current="page"' : '') . '>' . esc_html($l) . '</a>';
        $html .= '</div>';
        if (count($kinds) > 1 && !$single) {
            $html .= '<nav class="idev-sch-kinds">';
            foreach (['' => __('All', 'idev-clinic-schedule'), 'doctor' => __('Doctors', 'idev-clinic-schedule'), 'clinic' => __('Clinics', 'idev-clinic-schedule')] as $v => $l) $html .= '<a href="' . $href(['kind' => $v]) . '"' . ($kind === $v ? ' class="is-active"' : '') . '>' . esc_html($l) . '</a>';
            $html .= '</nav>';
        }
        $html .= '<div class="idev-sch-nav"><a href="' . $href(['date' => $step(-1)]) . '">← ' . esc_html__('Previous', 'idev-clinic-schedule') . '</a><strong>' . esc_html($title) . '</strong>' . ($current ? '' : '<a href="' . $href(['date' => $today]) . '">' . esc_html__('Today', 'idev-clinic-schedule') . '</a>') . '<a href="' . $href(['date' => $step(1)]) . '">' . esc_html__('Next', 'idev-clinic-schedule') . ' →</a></div></div>';
    }
    if (idev_cs_setting('booking_hint') === '1' && ($book || array_filter(array_column($providers, 'booking_url')) || has_filter('idev_cs_booking_url'))) $html .= '<p class="idev-sch-hint">' . esc_html__('Tap a time to book an appointment.', 'idev-clinic-schedule') . '</p>';

    if ($view === 'month') {
        $html .= '<div class="idev-sch-month"><div class="idev-sch-mhead">';
        foreach (idev_weekdays($lang, true) as $d) $html .= '<span>' . esc_html($d) . '</span>';
        $html .= '</div><div class="idev-sch-mgrid">';
        foreach ($dates as $d) {
            $e = $entries_on($d);
            $html .= '<div class="idev-sch-mcell' . (substr($d, 0, 7) === substr($anchor, 0, 7) ? '' : ' is-outside') . ($d === $today ? ' is-today' : '') . ($closed($d) ? ' is-holiday' : '') . '"><a class="idev-sch-mday" href="' . $href(['view' => 'day', 'date' => $d]) . '"><strong>' . (int) substr($d, 8, 2) . '</strong>' . ($e ? '<span class="idev-sch-mcount">' . count($e) . '</span>' : '') . '</a>' . $tag($d) . '<ul>';
            foreach (array_slice($e, 0, 3) as $x) $html .= '<li><span>' . esc_html($x['s']['start_time']) . '</span> ' . esc_html($name($x['p'])) . '</li>';
            $html .= '</ul>' . (count($e) > 3 ? '<a class="idev-sch-mmore" href="' . $href(['view' => 'day', 'date' => $d]) . '">+' . (count($e) - 3) . '</a>' : '') . '</div>';
        }
        $html .= '</div></div>';
    } elseif ($view === 'week') {
        $html .= '<div class="idev-sch-table-wrap"><table class="idev-sch-table"><thead><tr><th>' . esc_html__('Doctor / clinic', 'idev-clinic-schedule') . '</th>';
        foreach ($dates as $d) $html .= '<th class="' . ($d === $today ? 'is-today' : '') . ($closed($d) ? ' is-holiday' : '') . '"><a href="' . $href(['view' => 'day', 'date' => $d]) . '">' . esc_html($days[idev_iso_weekday($d) - 1]) . '<small>' . esc_html(idev_format_short($d, $lang)) . '</small></a>' . $tag($d) . '</th>';
        $html .= '</tr></thead><tbody>';
        foreach ($providers as $p) {
            $note = idev_pick($p['note'], $p['note_en']);
            $html .= '<tr><th scope="row"><div class="idev-sch-person">' . $avatar($p) . '<span><strong>' . esc_html($name($p)) . '</strong>' . $sub($p) . ($note !== '' ? '<em>' . esc_html($note) . '</em>' : '') . '</span></div></th>';
            foreach ($dates as $d) {
                $html .= '<td class="' . ($d === $today ? 'is-today' : '') . ($closed($d) ? ' is-holiday' : '') . '">';
                if ($closed($d)) $html .= '<span class="idev-sch-empty">' . esc_html__('Closed', 'idev-clinic-schedule') . '</span>';
                else { $e = $entries_on($d, [$p]); $html .= $e ? implode('', array_map($chip, $e)) : '<span class="idev-sch-empty">—</span>'; }
                $html .= '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</tbody></table></div><div class="idev-sch-days">';
        $i = array_search($today, $dates, true);
        foreach ($i === false ? $dates : array_merge(array_slice($dates, $i), array_slice($dates, 0, $i)) as $d) $html .= $day_card($d);
        $html .= '</div>';
    } else $html .= $day_card($anchor, true);
    return $html . '</div>';
}

/** Reads ?view= &date= &kind= &provider= from the address when navigation is on. */
function idev_cs_schedule_from_request($atts) {
    $nav = !empty($atts['navigation']);
    $get = function ($k) { return isset($_GET[$k]) ? sanitize_text_field(wp_unslash($_GET[$k])) : ''; };
    return idev_cs_render_schedule([
        'view' => $nav && $get('view') ? $get('view') : ($atts['view'] ?: ''), 'default_view' => $atts['view'] ?: '',
        'date' => $nav ? ($get('date') ?: $get('week')) : '', 'kind' => $nav && $get('kind') ? $get('kind') : ($atts['kind'] ?? ''),
        'provider' => $nav ? (int) $get('provider') : 0, 'specialty' => $atts['specialty'] ?? '', 'navigation' => $nav,
    ]);
}
add_shortcode('idev_schedule', function ($atts) {
    $a = shortcode_atts(['view' => '', 'navigation' => '1', 'kind' => '', 'specialty' => ''], $atts);
    $a['navigation'] = $a['navigation'] !== '0';
    return idev_cs_schedule_from_request($a);
});
