<?php
/**
 * Plugin Name:       iDev Clinic Schedule
 * Plugin URI:        https://idevapp.me/plugins/idev-clinic-schedule
 * Description:       Doctor and clinic schedules (weekly, monthly, yearly or one-off times) shown as month, week or day, with booking links, holidays, opening hours with a live "open now" status, and a doctor team grid with specialty tabs.
 * Version:           1.0.2
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-clinic-schedule
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// Loaded once: the same plugin may also be inside an iDevApp package (I-Clinic / I-Drug) or a Pro version.
if (defined('IDEV_CS_VERSION')) return;

define('IDEV_CS_VERSION', '1.0.2');
define('IDEV_CS_FILE', __FILE__);
define('IDEV_CS_URL', plugin_dir_url(__FILE__));
require_once __DIR__ . '/common/idev-common.php';
foreach (['settings', 'cpt', 'schedule', 'hours', 'team', 'blocks', 'migrate'] as $idev_cs_file) require_once __DIR__ . "/includes/{$idev_cs_file}.php";

register_activation_hook(__FILE__, function () {
    idev_cs_register_types();
    idev_cs_migrate();
    flush_rewrite_rules();
});

add_action('wp_enqueue_scripts', function () {
    wp_register_style('idev-clinic-schedule', IDEV_CS_URL . 'assets/front.css', [], IDEV_CS_VERSION);
    wp_register_script('idev-clinic-schedule', IDEV_CS_URL . 'assets/front.js', [], IDEV_CS_VERSION, ['in_footer' => true, 'strategy' => 'defer']);
    $s = idev_cs_settings();
    wp_add_inline_style('idev-clinic-schedule', ':root{--idev-cs-primary:' . esc_attr($s['primary']) . ';--idev-cs-accent:' . esc_attr($s['accent']) . '}');
});
/** Styles/scripts are only loaded on pages that show a schedule, team or status. */
if (!function_exists('idev_cs_assets')) { function idev_cs_assets() { wp_enqueue_style('idev-clinic-schedule'); wp_enqueue_script('idev-clinic-schedule'); } }
