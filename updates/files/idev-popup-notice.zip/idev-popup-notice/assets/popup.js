/* Shows active popups one at a time; a closed popup stays hidden for the configured hours (until its text changes).
   If a cookie banner is waiting for an answer (iDev Cookie Consent), popups wait until it is answered. */
(function () {
  const src = document.getElementById('idev-popups');
  if (!src) return;
  let cfg; try { cfg = JSON.parse(src.textContent); } catch (e) { return; }
  const KEY = 'idev-popups-dismissed', HIDE = Math.max(0, cfg.hide) * 3600 * 1000;
  const sig = (p) => `${p.id}|${p.title}|${p.body}|${p.image}`.slice(0, 400);
  const read = () => { try { const v = JSON.parse(localStorage.getItem(KEY) || '{}'); return v && typeof v === 'object' ? v : {}; } catch (e) { return {}; } };
  const esc = (s) => String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const store = read();
  let queue = cfg.items.filter((p) => Date.now() - Number(store[sig(p)] || 0) > HIDE);
  let box = null, lastFocus = null;
  function close() {
    const cur = queue[0]; if (!cur) return;
    const s = read(); s[sig(cur)] = Date.now();
    Object.keys(s).forEach((k) => { if (Date.now() - Number(s[k]) > Math.max(HIDE, 864e5)) delete s[k]; });
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* private mode */ }
    queue = queue.slice(1); render();
  }
  function onKey(e) { if (e.key === 'Escape') close(); }
  function render() {
    if (box) box.remove(); box = null;
    const p = queue[0];
    if (!p) { document.removeEventListener('keydown', onKey); if (lastFocus) lastFocus.focus(); return; }
    box = document.createElement('div');
    box.className = 'idev-pn-backdrop';
    box.innerHTML = `<section class="idev-pn" role="dialog" aria-modal="true" aria-labelledby="idev-pn-title"><button type="button" class="idev-pn-close" aria-label="${esc(cfg.close)}">×</button>${p.image ? `<img src="${esc(p.image)}" alt="">` : ''}<div class="idev-pn-body"><span class="idev-pn-kicker">${esc(cfg.kicker)}${queue.length > 1 ? ` · 1/${queue.length}` : ''}</span>${p.title ? `<h2 id="idev-pn-title">${esc(p.title)}</h2>` : ''}<div class="idev-pn-text">${p.body}</div><div class="idev-pn-actions">${p.linkUrl && p.linkText ? `<a href="${esc(p.linkUrl)}">${esc(p.linkText)}</a>` : ''}${queue.length > 1 ? `<button type="button" class="idev-pn-next">${esc(cfg.next)} (${queue.length - 1}) →</button>` : ''}</div></div></section>`;
    box.addEventListener('mousedown', (e) => { if (e.target === box) close(); });
    box.querySelector('.idev-pn-close').addEventListener('click', close);
    const n = box.querySelector('.idev-pn-next'); if (n) n.addEventListener('click', close);
    document.body.appendChild(box);
    box.querySelector('.idev-pn-close').focus();
  }
  function start() { if (!queue.length) return; lastFocus = document.activeElement; document.addEventListener('keydown', onKey); setTimeout(render, Math.max(0, cfg.delay) * 1000); }
  if (window.idevConsentPending) document.addEventListener('idev:consent', start, { once: true }); else start();
})();
