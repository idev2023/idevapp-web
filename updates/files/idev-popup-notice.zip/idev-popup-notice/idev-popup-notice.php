<?php
/**
 * Plugin Name:       iDev Popup Notice
 * Plugin URI:        https://idevapp.me/plugins/idev-popup-notice
 * Description:       Important-notice popups: as many as you need, each with start/end time, image, button and order. Shown one at a time; visitors who close one don't see it again for a few hours. Thai / English.
 * Version:           1.0.1
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            iDevApp
 * Author URI:        https://idevapp.me/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       idev-popup-notice
 * Domain Path:       /languages
 * Update URI:        https://idevapp.me/updates/
 */
defined('ABSPATH') || exit;

// Loaded once: the same plugin may also be inside an iDevApp package (I-Clinic / I-Drug) or a Pro version.
if (defined('IDEV_PN_VERSION')) return;

define('IDEV_PN_VERSION', '1.0.1');
define('IDEV_PN_FILE', __FILE__);
define('IDEV_PN_URL', plugin_dir_url(__FILE__));
require_once __DIR__ . '/common/idev-common.php';
require_once __DIR__ . '/includes/popup.php';
register_activation_hook(__FILE__, 'idev_pn_migrate');
