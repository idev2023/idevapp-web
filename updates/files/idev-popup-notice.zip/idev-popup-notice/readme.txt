=== iDev Popup Notice ===
Contributors: idevapp2023
Donate link: https://idevapp.me/
Tags: popup, announcement, notice
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Important-notice popups with start and end times, one at a time, remembered after closing. Waits for the cookie banner and stays away from form pages.

== Description ==

Important-notice popups with start and end times, one at a time, remembered after closing. Waits for the cookie banner and stays away from form pages.

= Features =

* Start / end date and time
* Thai and English text, picture and button
* Hidden again for N hours after closing
* Not shown on booking, registration and portal pages

Thai and English interface. Works with any theme. Part of the iDevApp plugin suite for hospitals and clinics — all iDev plugins appear under the **iDevApp** menu.

== Installation ==

1. Plugins → Add New → Upload Plugin, choose the zip, Install, Activate.
2. Open **iDevApp** in the admin menu for settings.

== Changelog ==

= 1.1.0 =
* Word-like popup designer: headings, font sizes, colours, resizable pictures; layouts (size, picture position, poster, colours, corner / top position) with a live preview.

= 1.0.0 =
* First release.
