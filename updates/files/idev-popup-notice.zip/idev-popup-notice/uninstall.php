<?php
defined('WP_UNINSTALL_PLUGIN') || exit;
delete_option('idev_popup_notice');
