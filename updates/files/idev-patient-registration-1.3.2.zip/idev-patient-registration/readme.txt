=== iDev Patient Registration ===
Contributors: idevapp2023
Donate link: https://idevapp.me/
Tags: hospital, clinic, patient registration, pdpa, medical
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.3.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Online new-patient registration for hospitals and clinics: PDPA/GDPR consent, ID card or passport photo, staff review, HN and a patient card.

== Description ==

iDev Patient Registration lets new patients register before their first visit. They agree to the privacy notice, take a photo of their Thai ID card or passport (or type the details in), and add contact details such as LINE and WhatsApp. Staff check each registration, give it a hospital number (HN) and the patient receives a patient card with a QR code by e-mail. The interface is in Thai and English.

= Features =

* Three ways to register: photo of a Thai ID card, photo of a passport, or typed in.
* Live camera with continuous autofocus, a sharpness check and automatic capture.
* PDPA / GDPR consent with versions; the version and time are saved with each registration.
* Fields you can turn on or off: name in English, address with a "use my location" button, drug allergies, emergency contact, LINE, WhatsApp, preferred contact.
* Staff screen: search, edit, approve with an HN, not approve, history of every change.
* **Patient card designer**: logo, colours, fonts (Sarabun included), QR code or barcode; sent as an image by e-mail and downloadable.
* Personal data is **encrypted** in the database; document photos are re-encoded without EXIF/location, encrypted, and deleted automatically after a number of days you choose.
* Encryption key management: key file, wp-config key, rotation and recovery.
* Rate limit and honeypot against spam.
* Block **Patient registration** and shortcode `[idev_patient_registration]`.

= Automatic reading of the document =

The Thai ID card (number, names, date of birth) and the passport machine-readable lines (with check digits) can be read on the patient's own phone with tesseract.js. Reading needs a copy of tesseract.js 5 on your server (set its location in Settings → Form). The photo is never sent to a reading service. The optional add-on iDev Patient Registration Pro loads the reader for you and adds a connector for the HOSxP hospital system.

= External services =

This plugin does not connect to any external service and sends no data to iDevApp. If you set "Reading engine location" to an address on another server, the patient's browser loads tesseract.js and its language files from that address (no patient data is sent).

== Installation ==

1. In WordPress go to **Plugins → Add New**, search for "iDev Patient Registration", then Install and Activate.
2. Open **iDevApp → Registrations → Settings**: hospital name, ways to register, consent text and e-mails.
3. Design the patient card in **Settings → Patient card**.
4. Add the **Patient registration** block to a page.

== Frequently Asked Questions ==

= Is there a limit on registrations? =

No. Registrations are unlimited.

= Where is the data kept? =

In your own WordPress database, encrypted. Document photos are kept outside the web folder when possible and deleted automatically.

= Can it create the HN in our hospital system automatically? =

For HOSxP, the add-on iDev Patient Registration Pro includes a connector that runs inside the hospital. Without it, staff save the patient in the hospital system and type the HN; the patient card is then sent automatically.

== Screenshots ==

1. Registration form on a phone.
2. Taking a photo of the ID card.
3. Staff screen.
4. Patient card designer.

== Changelog ==

= 1.3.2 =
* Thai ID card: the Thai name line is read a second time on its own, enlarged, so vowels and tone marks are not dropped.

= 1.3.1 =
* Dates show the Buddhist year (พ.ศ.) and Thai month names on Thai pages, and the Gregorian year on English pages, everywhere WordPress formats a date.

= 1.3.0 =
* Walk-in registration by staff at the counter.

= 1.2.0 =
* Unlimited registrations for everyone.
* The HOSxP connector and the automatic reader loader moved to the add-on iDev Patient Registration Pro. Sites that had a licence keep the connector after installing Pro (the same key works).

= 1.1.0 =
* Licences.

= 1.0.0 =
* First release.
