<?php
/**
 * Thai Public Agency functions and definitions.
 *
 * Everything is edited in Appearance → Editor: colours and fonts (Styles), header and footer
 * (Patterns → Template parts) and the front page (Templates → Front page).
 *
 * @package thai-public-agency
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'thai_public_agency_setup' ) ) :
	/**
	 * Theme supports and the editor stylesheet.
	 */
	function thai_public_agency_setup() {
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'editor-styles' );
		add_editor_style( 'assets/theme.css' );
		load_theme_textdomain( 'thai-public-agency', get_template_directory() . '/languages' );
	}
endif;
add_action( 'after_setup_theme', 'thai_public_agency_setup' );

if ( ! function_exists( 'thai_public_agency_enqueue' ) ) :
	/**
	 * Front-end stylesheet and the text-size / contrast buttons.
	 */
	function thai_public_agency_enqueue() {
		$version = wp_get_theme()->get( 'Version' );
		wp_enqueue_style( 'thai-public-agency-style', get_theme_file_uri( 'assets/theme.css' ), array(), $version );
		wp_enqueue_script( 'thai-public-agency-a11y', get_theme_file_uri( 'assets/a11y.js' ), array(), $version, array( 'strategy' => 'defer' ) );
	}
endif;
add_action( 'wp_enqueue_scripts', 'thai_public_agency_enqueue' );

if ( ! function_exists( 'thai_public_agency_block_styles' ) ) :
	/**
	 * Block style and pattern category.
	 */
	function thai_public_agency_block_styles() {
		register_block_style(
			'core/group',
			array(
				'name'  => 'thpa-card',
				'label' => __( 'Card', 'thai-public-agency' ),
			)
		);
		register_block_pattern_category(
			'thai-public-agency',
			array( 'label' => __( 'Thai Public Agency', 'thai-public-agency' ) )
		);
	}
endif;
add_action( 'init', 'thai_public_agency_block_styles' );
