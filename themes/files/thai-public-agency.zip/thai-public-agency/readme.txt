=== Thai Public Agency ===
Contributors: idevapp2023
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A block theme for government offices, public hospitals and local administrations.

== Description ==

A block theme for government offices, public hospitals and local administrations: text-size and high-contrast buttons, online services, press releases, announcements, an open-information (ITA / OIT) section and contact details. Thai fonts included; everything can be changed in the Site Editor.

The theme has English source text and a Thai translation; WordPress shows the language set in Settings → General.

== Installation ==

1. In your admin area go to Appearance → Themes → Add New Theme and search for "Thai Public Agency".
2. Click Install, then Activate.
3. Go to Appearance → Editor to change the colours, fonts, header, footer and front page.

== Frequently Asked Questions ==

= How do I change the text on the front page? =

Go to Appearance → Editor → Templates → Front page, click any text and type.

= Does the theme collect any data? =

No. The theme does not collect data or contact any outside service.

== Changelog ==

= 1.0.0 =
* First release on WordPress.org.

== Copyright ==

Thai Public Agency WordPress Theme, Copyright 2026 iDevApp
Thai Public Agency is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Resources ==

Sarabun font
License: SIL Open Font License, Version 1.1, https://openfontlicense.org/
Copyright: Copyright 2020 The Sarabun Project Authors
Source: https://github.com/cadsondemak/Sarabun
Files: assets/fonts/Sarabun-*.woff

Illustration assets/images/hero-gov.svg and screenshot.png
License: GPLv2 or later
Copyright: iDevApp, made for this theme

Line icons in the patterns
License: MIT License (Feather) / ISC License (Lucide), both GPL-compatible
Source: https://feathericons.com/ and https://lucide.dev/
