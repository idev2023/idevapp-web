<?php
/**
 * Title: Hero (public agency)
 * Slug: thai-public-agency/hero
 * Categories: thai-public-agency
 * Description: Hero (public agency): edit the text, images and colours in the editor.
 *
 * @package thai-public-agency
 */

?>
<!-- wp:group {"tagName":"section","align":"full","className":"thpa-hero thpa-hero-gov","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}}},"textColor":"base","gradient":"hero","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull thpa-hero thpa-hero-gov has-base-color has-hero-gradient-background has-text-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"verticalAlignment":"center","align":"wide"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"58%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:58%"><!-- wp:paragraph {"className":"thpa-kicker thpa-kicker-light"} -->
<p class="thpa-kicker thpa-kicker-light"><?php echo esc_html__( 'Welcome', 'thai-public-agency' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"textColor":"base","fontSize":"xx-large"} -->
<h1 class="wp-block-heading has-base-color has-text-color has-xx-large-font-size"><?php echo esc_html__( 'Public services that are open, fast and accessible to everyone', 'thai-public-agency' ); ?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"base","fontSize":"large"} -->
<p class="has-base-color has-text-color has-large-font-size"><?php echo esc_html__( 'News, announcements, online services and ways to contact us, all in one place.', 'thai-public-agency' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"accent","textColor":"ink"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-accent-background-color has-text-color has-background wp-element-button" href="<?php echo esc_url( home_url( '/e-service/' ) ); ?>"><?php echo esc_html__( 'Online services (e-Service)', 'thai-public-agency' ); ?></a></div>
<!-- /wp:button -->

<!-- wp:button {"textColor":"base","className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-base-color has-text-color wp-element-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php echo esc_html__( 'Contact us', 'thai-public-agency' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"42%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:42%"><!-- wp:image {"sizeSlug":"full","className":"thpa-hero-art"} -->
<figure class="wp-block-image size-full thpa-hero-art"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/hero-gov.svg" alt="<?php echo esc_attr__( 'Illustration of a public office building', 'thai-public-agency' ); ?>"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
