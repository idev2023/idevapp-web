<?php
/**
 * Title: Announcements and procurement
 * Slug: thai-public-agency/announce
 * Categories: thai-public-agency
 * Description: Announcements and procurement: edit the text, images and colours in the editor.
 *
 * @package thai-public-agency
 */

?>
<!-- wp:group {"tagName":"section","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"surface","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull has-surface-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"60%"} -->
<div class="wp-block-column" style="flex-basis:60%"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"thpa-kicker"} -->
<p class="thpa-kicker"><?php echo esc_html__( 'Announcements', 'thai-public-agency' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'Latest announcements', 'thai-public-agency' ); ?></h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:latest-posts {"postsToShow":6,"displayPostDate":true,"className":"thpa-announce"} /--></div>
<!-- /wp:column -->

<!-- wp:column {"width":"40%"} -->
<div class="wp-block-column" style="flex-basis:40%"><!-- wp:group {"className":"is-style-thpa-card","style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group is-style-thpa-card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php echo esc_html__( 'Executives', 'thai-public-agency' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:html -->
<div class="thpa-exec"><div class="thpa-exec-photo" aria-hidden="true"></div></div>
<!-- /wp:html -->

<!-- wp:paragraph {"style":{"typography":{"textAlign":"center"}}} -->
<p class="has-text-align-center"><strong><?php echo esc_html__( 'Executive’s full name', 'thai-public-agency' ); ?></strong><br><?php echo esc_html__( 'Position', 'thai-public-agency' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"textAlign":"center"}},"fontSize":"small"} -->
<p class="has-text-align-center has-small-font-size"><a href="<?php echo esc_url( home_url( '/executives/' ) ); ?>"><?php echo esc_html__( 'All executives →', 'thai-public-agency' ); ?></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
