<?php
/**
 * Title: Footer
 * Slug: thai-public-agency/part-footer
 * Inserter: no
 * Block Types: core/template-part/footer
 *
 * @package thai-public-agency
 */

?>
<!-- wp:group {"align":"full","className":"thpa-footer","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}},"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"backgroundColor":"primary-dark","textColor":"base","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull thpa-footer has-base-color has-primary-dark-background-color has-text-color has-background has-link-color" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"40%"} -->
<div class="wp-block-column" style="flex-basis:40%"><!-- wp:site-title {"level":0,"fontSize":"large"} /-->

<!-- wp:paragraph {"textColor":"line"} -->
<p class="has-line-color has-text-color"><?php echo esc_html__( 'Office address, number, street, subdistrict, district, province, postcode', 'thai-public-agency' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"line"} -->
<p class="has-line-color has-text-color"><?php echo esc_html__( 'Tel. 0-0000-0000 · Fax 0-0000-0000', 'thai-public-agency' ); ?><br><?php echo esc_html__( 'Email: info@example.com', 'thai-public-agency' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"textColor":"accent","fontSize":"medium"} -->
<h3 class="wp-block-heading has-accent-color has-text-color has-medium-font-size"><?php echo esc_html__( 'Services', 'thai-public-agency' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:list {"className":"thpa-links"} -->
<ul class="wp-block-list thpa-links"><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/e-service/' ) ); ?>"><?php echo esc_html__( 'Online services (e-Service)', 'thai-public-agency' ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/complaint/' ) ); ?>"><?php echo esc_html__( 'Complaints', 'thai-public-agency' ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/procurement/' ) ); ?>"><?php echo esc_html__( 'Procurement', 'thai-public-agency' ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/jobs/' ) ); ?>"><?php echo esc_html__( 'Jobs', 'thai-public-agency' ); ?></a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"textColor":"accent","fontSize":"medium"} -->
<h3 class="wp-block-heading has-accent-color has-text-color has-medium-font-size"><?php echo esc_html__( 'Transparency', 'thai-public-agency' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:list {"className":"thpa-links"} -->
<ul class="wp-block-list thpa-links"><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/ita/' ) ); ?>">ITA / OIT</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>"><?php echo esc_html__( 'Privacy policy', 'thai-public-agency' ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/cookie-policy/' ) ); ?>"><?php echo esc_html__( 'Cookie policy', 'thai-public-agency' ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/sitemap/' ) ); ?>"><?php echo esc_html__( 'Site map', 'thai-public-agency' ); ?></a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"textColor":"accent","fontSize":"medium"} -->
<h3 class="wp-block-heading has-accent-color has-text-color has-medium-font-size"><?php echo esc_html__( 'Follow us', 'thai-public-agency' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:social-links {"iconColor":"base","iconColorValue":"#ffffff","className":"is-style-logos-only"} -->
<ul class="wp-block-social-links has-icon-color is-style-logos-only"><!-- wp:social-link {"url":"#","service":"facebook"} /-->

<!-- wp:social-link {"url":"#","service":"line"} /-->

<!-- wp:social-link {"url":"#","service":"youtube"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:separator {"className":"is-style-wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|30"}}},"backgroundColor":"primary"} -->
<hr class="wp-block-separator has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-wide" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--30)"/>
<!-- /wp:separator -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"textColor":"line","fontSize":"small"} -->
<p class="has-line-color has-text-color has-small-font-size"><?php echo esc_html__( 'All rights reserved · Official website', 'thai-public-agency' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"line","fontSize":"small"} -->
<p class="has-line-color has-text-color has-small-font-size"><?php printf( /* translators: %s: theme author. */ esc_html__( 'Theme by %s', 'thai-public-agency' ), '<a href="https://idevapp.me/">iDevApp</a>' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
