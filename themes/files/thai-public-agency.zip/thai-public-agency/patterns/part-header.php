<?php
/**
 * Title: Header
 * Slug: thai-public-agency/part-header
 * Inserter: no
 * Block Types: core/template-part/header
 *
 * @package thai-public-agency
 */

?>
<!-- wp:group {"align":"full","className":"thpa-topbar","style":{"spacing":{"padding":{"top":"6px","bottom":"6px","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}},"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"backgroundColor":"primary-dark","textColor":"base","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull thpa-topbar has-base-color has-primary-dark-background-color has-text-color has-background has-link-color" style="padding-top:6px;padding-right:var(--wp--preset--spacing--40);padding-bottom:6px;padding-left:var(--wp--preset--spacing--40)"><!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide"><!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><?php echo esc_html__( 'Official website', 'thai-public-agency' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"right"}} -->
<div class="wp-block-group"><!-- wp:html -->
<div class="thpa-a11y" role="group" aria-label="<?php echo esc_attr__( 'Text size', 'thai-public-agency' ); ?>"><button type="button" data-fs="-1" aria-label="<?php echo esc_attr__( 'Smaller text', 'thai-public-agency' ); ?>"><?php echo esc_html__( 'A-', 'thai-public-agency' ); ?></button><button type="button" data-fs="0" aria-label="<?php echo esc_attr__( 'Normal text size', 'thai-public-agency' ); ?>"><?php echo esc_html__( 'A', 'thai-public-agency' ); ?></button><button type="button" data-fs="1" aria-label="<?php echo esc_attr__( 'Larger text', 'thai-public-agency' ); ?>"><?php echo esc_html__( 'A+', 'thai-public-agency' ); ?></button><button type="button" data-contrast aria-label="<?php echo esc_attr__( 'High contrast', 'thai-public-agency' ); ?>">◐</button></div>
<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"base","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-base-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--30);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--40)"><!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:site-logo {"width":64} /-->

<!-- wp:group {"style":{"spacing":{"blockGap":"2px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:site-title {"level":0,"fontSize":"large"} /-->

<!-- wp:site-tagline {"textColor":"muted","fontSize":"small"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"right"}} -->
<div class="wp-block-group"><!-- wp:search {"label":"<?php echo esc_attr__( 'Search', 'thai-public-agency' ); ?>","showLabel":false,"placeholder":"<?php echo esc_attr__( 'Search this website', 'thai-public-agency' ); ?>","width":240,"widthUnit":"px","buttonText":"<?php echo esc_attr__( 'Search', 'thai-public-agency' ); ?>","buttonPosition":"button-inside","buttonUseIcon":true} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"thpa-navbar","style":{"spacing":{"padding":{"top":"12px","bottom":"12px","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}},"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"backgroundColor":"primary","textColor":"base","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull thpa-navbar has-base-color has-primary-background-color has-text-color has-background has-link-color" style="padding-top:12px;padding-right:var(--wp--preset--spacing--40);padding-bottom:12px;padding-left:var(--wp--preset--spacing--40)"><!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"left"}} -->
<div class="wp-block-group alignwide"><!-- wp:navigation {"style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"fontSize":"medium","layout":{"type":"flex","justifyContent":"left"}} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
