<?php
/**
 * Thai Pharmacy functions and definitions.
 *
 * Everything is edited in Appearance → Editor: colours and fonts (Styles), header and footer
 * (Patterns → Template parts) and the front page (Templates → Front page).
 *
 * @package thai-pharmacy
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'thai_pharmacy_setup' ) ) :
	/**
	 * Theme supports and the editor stylesheet.
	 */
	function thai_pharmacy_setup() {
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'editor-styles' );
		add_editor_style( 'assets/theme.css' );
		load_theme_textdomain( 'thai-pharmacy', get_template_directory() . '/languages' );
	}
endif;
add_action( 'after_setup_theme', 'thai_pharmacy_setup' );

if ( ! function_exists( 'thai_pharmacy_enqueue' ) ) :
	/**
	 * Front-end stylesheet.
	 */
	function thai_pharmacy_enqueue() {
		$version = wp_get_theme()->get( 'Version' );
		wp_enqueue_style( 'thai-pharmacy-style', get_theme_file_uri( 'assets/theme.css' ), array(), $version );
	}
endif;
add_action( 'wp_enqueue_scripts', 'thai_pharmacy_enqueue' );

if ( ! function_exists( 'thai_pharmacy_block_styles' ) ) :
	/**
	 * Block style and pattern category.
	 */
	function thai_pharmacy_block_styles() {
		register_block_style(
			'core/group',
			array(
				'name'  => 'thph-card',
				'label' => __( 'Card', 'thai-pharmacy' ),
			)
		);
		register_block_pattern_category(
			'thai-pharmacy',
			array( 'label' => __( 'Thai Pharmacy', 'thai-pharmacy' ) )
		);
	}
endif;
add_action( 'init', 'thai_pharmacy_block_styles' );
