<?php
/**
 * Title: Footer
 * Slug: thai-pharmacy/part-footer
 * Inserter: no
 * Block Types: core/template-part/footer
 *
 * @package thai-pharmacy
 */

?>
<!-- wp:group {"align":"full","className":"thph-footer","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}},"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"backgroundColor":"primary-dark","textColor":"base","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull thph-footer has-base-color has-primary-dark-background-color has-text-color has-background has-link-color" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"36%"} -->
<div class="wp-block-column" style="flex-basis:36%"><!-- wp:site-title {"level":0,"fontSize":"large"} /-->

<!-- wp:paragraph {"textColor":"line"} -->
<p class="has-line-color has-text-color"><?php echo esc_html__( 'Your local pharmacy, with a pharmacist on duty every day.', 'thai-pharmacy' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"line","fontSize":"small"} -->
<p class="has-line-color has-text-color has-small-font-size"><?php echo esc_html__( 'Pharmacy licence no. ……………', 'thai-pharmacy' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size"><?php echo esc_html__( 'Product categories', 'thai-pharmacy' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:list {"className":"thph-links"} -->
<ul class="wp-block-list thph-links"><!-- wp:list-item -->
<li><a href="#"><?php echo esc_html__( 'Household medicines', 'thai-pharmacy' ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php echo esc_html__( 'Vitamins and supplements', 'thai-pharmacy' ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php echo esc_html__( 'Skin care', 'thai-pharmacy' ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php echo esc_html__( 'Medical supplies', 'thai-pharmacy' ); ?></a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size"><?php echo esc_html__( 'Opening hours', 'thai-pharmacy' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"line"} -->
<p class="has-line-color has-text-color"><?php echo esc_html__( 'Every day 08:00–21:00', 'thai-pharmacy' ); ?></p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size"><?php echo esc_html__( 'Contact', 'thai-pharmacy' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"line"} -->
<p class="has-line-color has-text-color"><?php echo esc_html__( 'Tel. 000-000-0000', 'thai-pharmacy' ); ?><br>LINE @yourpharmacy<br><?php echo esc_html__( 'Shop address, street, subdistrict, district, province', 'thai-pharmacy' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:separator {"className":"is-style-wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|30"}}}} -->
<hr class="wp-block-separator has-alpha-channel-opacity is-style-wide" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--30)"/>
<!-- /wp:separator -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"textColor":"line","fontSize":"small"} -->
<p class="has-line-color has-text-color has-small-font-size"><?php echo esc_html__( 'All rights reserved', 'thai-pharmacy' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>"><?php echo esc_html__( 'Privacy policy', 'thai-pharmacy' ); ?></a> · <a href="<?php echo esc_url( home_url( '/cookie-policy/' ) ); ?>"><?php echo esc_html__( 'Cookie policy', 'thai-pharmacy' ); ?></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
