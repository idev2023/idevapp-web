<?php
/**
 * Title: Hero (pharmacy)
 * Slug: thai-pharmacy/hero
 * Categories: thai-pharmacy
 * Description: Hero (pharmacy): edit the text, images and colours in the editor.
 *
 * @package thai-pharmacy
 */

?>
<!-- wp:group {"tagName":"section","align":"full","className":"thph-hero thph-hero-pharmacy","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"primary","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull thph-hero thph-hero-pharmacy has-primary-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"verticalAlignment":"center","align":"wide"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"55%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%"><!-- wp:paragraph {"className":"thph-kicker thph-kicker-light"} -->
<p class="thph-kicker thph-kicker-light"><?php echo esc_html__( 'Your local pharmacy', 'thai-pharmacy' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"textColor":"base","fontSize":"xx-large"} -->
<h1 class="wp-block-heading has-base-color has-text-color has-xx-large-font-size"><?php echo esc_html__( 'Pharmacist advice every day. Genuine, quality medicines at friendly prices.', 'thai-pharmacy' ); ?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"base","fontSize":"large"} -->
<p class="has-base-color has-text-color has-large-font-size"><?php echo esc_html__( 'Our pharmacist explains how to use each medicine safely, with a clear label on every item.', 'thai-pharmacy' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"accent","textColor":"ink"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-accent-background-color has-text-color has-background wp-element-button" href="#"><?php echo esc_html__( 'Chat on LINE', 'thai-pharmacy' ); ?></a></div>
<!-- /wp:button -->

<!-- wp:button {"textColor":"base","className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-base-color has-text-color wp-element-button" href="tel:0000000000"><?php echo esc_html__( 'Call us', 'thai-pharmacy' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

</div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%"><!-- wp:image {"sizeSlug":"full","className":"thph-hero-art"} -->
<figure class="wp-block-image size-full thph-hero-art"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/hero-pharmacy.svg" alt="<?php echo esc_attr__( 'Illustration of a pharmacy', 'thai-pharmacy' ); ?>"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
