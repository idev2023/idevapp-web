<?php
/**
 * Thai Clinic functions and definitions.
 *
 * Everything is edited in Appearance → Editor: colours and fonts (Styles), header and footer
 * (Patterns → Template parts) and the front page (Templates → Front page).
 *
 * @package thai-clinic
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'thai_clinic_setup' ) ) :
	/**
	 * Theme supports and the editor stylesheet.
	 */
	function thai_clinic_setup() {
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'editor-styles' );
		add_editor_style( 'assets/theme.css' );
		load_theme_textdomain( 'thai-clinic', get_template_directory() . '/languages' );
	}
endif;
add_action( 'after_setup_theme', 'thai_clinic_setup' );

if ( ! function_exists( 'thai_clinic_enqueue' ) ) :
	/**
	 * Front-end stylesheet.
	 */
	function thai_clinic_enqueue() {
		$version = wp_get_theme()->get( 'Version' );
		wp_enqueue_style( 'thai-clinic-style', get_theme_file_uri( 'assets/theme.css' ), array(), $version );
	}
endif;
add_action( 'wp_enqueue_scripts', 'thai_clinic_enqueue' );

if ( ! function_exists( 'thai_clinic_block_styles' ) ) :
	/**
	 * Block style and pattern category.
	 */
	function thai_clinic_block_styles() {
		register_block_style(
			'core/group',
			array(
				'name'  => 'thcl-card',
				'label' => __( 'Card', 'thai-clinic' ),
			)
		);
		register_block_pattern_category(
			'thai-clinic',
			array( 'label' => __( 'Thai Clinic', 'thai-clinic' ) )
		);
	}
endif;
add_action( 'init', 'thai_clinic_block_styles' );
