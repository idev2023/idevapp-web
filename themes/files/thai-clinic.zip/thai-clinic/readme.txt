=== Thai Clinic ===
Contributors: idevapp2023
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A block theme for clinics and private hospitals.

== Description ==

A block theme for clinics and private hospitals: a hero with a booking button, services, doctors and their schedule, booking steps, health articles and a contact section with map. Thai fonts included; colours, fonts and every section can be changed in the Site Editor.

The theme has English source text and a Thai translation; WordPress shows the language set in Settings → General.

== Installation ==

1. In your admin area go to Appearance → Themes → Add New Theme and search for "Thai Clinic".
2. Click Install, then Activate.
3. Go to Appearance → Editor to change the colours, fonts, header, footer and front page.

== Frequently Asked Questions ==

= How do I change the text on the front page? =

Go to Appearance → Editor → Templates → Front page, click any text and type.

= Does the theme collect any data? =

No. The theme does not collect data or contact any outside service.

== Changelog ==

= 1.0.0 =
* First release on WordPress.org.

== Copyright ==

Thai Clinic WordPress Theme, Copyright 2026 iDevApp
Thai Clinic is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Resources ==

IBM Plex Sans Thai font
License: SIL Open Font License, Version 1.1, https://openfontlicense.org/
Copyright: Copyright 2021 IBM Corp.
Source: https://github.com/IBM/plex
Files: assets/fonts/IBMPlexSansThai-*.woff

Illustration assets/images/hero-clinic.svg and screenshot.png
License: GPLv2 or later
Copyright: iDevApp, made for this theme

Line icons in the patterns
License: MIT License (Feather) / ISC License (Lucide), both GPL-compatible
Source: https://feathericons.com/ and https://lucide.dev/
