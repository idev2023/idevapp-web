<?php
/**
 * Title: Footer
 * Slug: thai-clinic/part-footer
 * Inserter: no
 * Block Types: core/template-part/footer
 *
 * @package thai-clinic
 */

?>
<!-- wp:group {"align":"full","className":"thcl-footer","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}},"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"backgroundColor":"ink","textColor":"base","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull thcl-footer has-base-color has-ink-background-color has-text-color has-background has-link-color" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"36%"} -->
<div class="wp-block-column" style="flex-basis:36%"><!-- wp:site-title {"level":0,"fontSize":"large"} /-->

<!-- wp:paragraph {"textColor":"line"} -->
<p class="has-line-color has-text-color"><?php echo esc_html__( 'Your neighbourhood clinic, caring doctors and specialists.', 'thai-clinic' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"base","iconColorValue":"#ffffff","className":"is-style-logos-only"} -->
<ul class="wp-block-social-links has-icon-color is-style-logos-only"><!-- wp:social-link {"url":"#","service":"facebook"} /-->

<!-- wp:social-link {"url":"#","service":"line"} /-->

<!-- wp:social-link {"url":"#","service":"instagram"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size"><?php echo esc_html__( 'Services', 'thai-clinic' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:list {"className":"thcl-links"} -->
<ul class="wp-block-list thcl-links"><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/booking/' ) ); ?>"><?php echo esc_html__( 'Book online', 'thai-clinic' ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/register/' ) ); ?>"><?php echo esc_html__( 'New patient registration', 'thai-clinic' ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/doctors/' ) ); ?>"><?php echo esc_html__( 'Doctor schedule', 'thai-clinic' ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/news/' ) ); ?>"><?php echo esc_html__( 'News and articles', 'thai-clinic' ); ?></a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size"><?php echo esc_html__( 'Opening hours', 'thai-clinic' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"line"} -->
<p class="has-line-color has-text-color"><?php echo esc_html__( 'Mon–Fri 09:00–20:00', 'thai-clinic' ); ?><br><?php echo esc_html__( 'Sat–Sun 09:00–17:00', 'thai-clinic' ); ?></p>
<!-- /wp:paragraph -->

</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size"><?php echo esc_html__( 'Contact', 'thai-clinic' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"line"} -->
<p class="has-line-color has-text-color"><?php echo esc_html__( 'Tel. 000-000-0000', 'thai-clinic' ); ?><br>LINE @yourclinic<br><?php echo esc_html__( 'Clinic address, street, district, province', 'thai-clinic' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:separator {"className":"is-style-wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|30"}}}} -->
<hr class="wp-block-separator has-alpha-channel-opacity is-style-wide" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--30)"/>
<!-- /wp:separator -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"textColor":"line","fontSize":"small"} -->
<p class="has-line-color has-text-color has-small-font-size"><?php echo esc_html__( 'All rights reserved', 'thai-clinic' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>"><?php echo esc_html__( 'Privacy policy', 'thai-clinic' ); ?></a> · <a href="<?php echo esc_url( home_url( '/cookie-policy/' ) ); ?>"><?php echo esc_html__( 'Cookie policy', 'thai-clinic' ); ?></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
