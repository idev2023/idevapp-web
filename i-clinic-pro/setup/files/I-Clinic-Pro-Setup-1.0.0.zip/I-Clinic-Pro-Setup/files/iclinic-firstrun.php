<?php
/**
 * I-Clinic Pro first run (run by the setup with: wp eval-file iclinic-firstrun.php <name> <address> <phone> <promptpay>, each base64 of UTF-8).
 * Sets the clinic details, creates the pages patients use, and links them in the settings. Safe to run again.
 */
if (!defined('ABSPATH')) exit(1);

// The setup passes each value as base64 of UTF-8 text (Windows would mangle Thai on the command line).
$arg = function ($i) use ($args) { $v = (string) ($args[$i] ?? ''); if ($v === '-') return ''; $d = base64_decode($v, true); return trim($d !== false ? $d : $v); };
$name = $arg(0);
$address = $arg(1);
$phone = $arg(2);
$promptpay = preg_replace('/\D/', '', $arg(3));

// Package set-up (tables, roles, settings) — normally done on the first visit to the admin.
if (function_exists('idev_pkg_install')) { idev_pkg_install(); update_option('idev_pkg_edition', IDEV_PACKAGE, false); }

// Site basics
if ($name !== '') { update_option('blogname', $name); update_option('blogdescription', 'I-Clinic Pro'); }
update_option('timezone_string', 'Asia/Bangkok');
update_option('date_format', 'j F Y');
update_option('time_format', 'H:i');
update_option('start_of_week', 1);
update_option('blog_public', 0);          // a clinic system: keep it out of search engines
update_option('default_comment_status', 'closed');
update_option('users_can_register', 0);

// Clinic / shop details used on receipts, job tickets and drug labels
$st = get_option('idev_store_settings', []);
if (!is_array($st)) $st = [];
if ($name !== '') $st['shop_name'] = $name;
if ($address !== '') $st['address'] = $address;
if ($phone !== '') $st['phone'] = $phone;
if ($promptpay !== '') $st['promptpay'] = $promptpay;
update_option('idev_store_settings', $st);

// Pages patients and staff open
$page = function ($slug, $title, $content) {
    $p = get_page_by_path($slug);
    if ($p) return (int) $p->ID;
    return (int) wp_insert_post(['post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug,
        'post_content' => "<!-- wp:shortcode -->\n" . $content . "\n<!-- /wp:shortcode -->", 'comment_status' => 'closed']);
};
$ids = [
    'booking'  => $page('booking', 'นัดหมายออนไลน์', '[idev_booking]'),
    'register' => $page('register', 'ลงทะเบียนผู้ป่วยใหม่', '[idev_patient_registration]'),
    'schedule' => $page('schedule', 'ตารางออกตรวจ', '[idev_schedule]'),
    'doctors'  => $page('doctor', 'สำหรับแพทย์', '[idev_doctor_portal]'),
    'status'   => $page('job-status', 'ติดตามงานสั่งทำ', '[idev_job_status]'),
];

$ap = get_option('idev_appt_settings', []);
if (!is_array($ap)) $ap = [];
$ap['page'] = (string) $ids['booking'];
$ap['portal_page'] = (string) $ids['doctors'];
$ap['register_page'] = (string) $ids['register'];
update_option('idev_appt_settings', $ap, false);

$st = get_option('idev_store_settings', []);
$st['status_page'] = (string) $ids['status'];
update_option('idev_store_settings', $st);

// The WordPress sample content is not needed
foreach (['hello-world' => 'post', 'sample-page' => 'page'] as $slug => $type) {
    $p = get_page_by_path($slug, OBJECT, $type);
    if ($p) wp_delete_post($p->ID, true);
}
wp_delete_comment(1, true);

flush_rewrite_rules();
echo "OK " . wp_json_encode($ids) . "\n";
