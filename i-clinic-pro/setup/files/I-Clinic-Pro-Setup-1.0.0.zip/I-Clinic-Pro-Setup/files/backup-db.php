<?php
// I-Clinic Pro: a consistent copy of the SQLite database while the system is running.
// php backup-db.php <database file> <copy to>
[$self, $src, $dst] = $argv + [null, '', ''];
if (!is_file($src) || $dst === '') { fwrite(STDERR, "usage: php backup-db.php <db> <copy>\n"); exit(2); }
@unlink($dst);
$db = new PDO('sqlite:' . $src, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$db->exec('PRAGMA busy_timeout = 30000');
$db->exec('VACUUM INTO ' . $db->quote($dst));
$check = new PDO('sqlite:' . $dst);
$ok = $check->query('PRAGMA integrity_check')->fetchColumn();
if ($ok !== 'ok') { fwrite(STDERR, "integrity check failed: $ok\n"); exit(1); }
echo "ok\n";
