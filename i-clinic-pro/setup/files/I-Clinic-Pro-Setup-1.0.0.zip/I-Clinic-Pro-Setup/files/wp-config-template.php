<?php
/**
 * I-Clinic Pro — WordPress settings (written by the I-Clinic Pro setup).
 * The database is one SQLite file in the data folder, outside the web folder.
 */
define('DB_DIR', '{{DATA_DIR}}');
define('DB_FILE', 'iclinic.sqlite');
define('DB_NAME', 'iclinic');
define('DB_USER', '');
define('DB_PASSWORD', '');
define('DB_HOST', '');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

{{SALTS}}

$table_prefix = 'wp_';

/*
 * The system is opened by several names inside the clinic: this computer's name, its LAN IP address
 * (tablets and phones), localhost, and optionally a public name through Cloudflare Tunnel.
 * Requests for any other name are answered with the main name.
 */
$iclinic_main  = '{{MAIN_HOST}}';
$iclinic_extra = [{{EXTRA_HOSTS}}];
$iclinic_host  = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
$iclinic_name  = preg_replace('/:\d+$/', '', $iclinic_host);
$iclinic_ok    = $iclinic_name !== '' && (
    in_array($iclinic_name, array_merge(['localhost', '127.0.0.1', strtolower('{{COMPUTER}}')], $iclinic_extra), true)
    || (filter_var($iclinic_name, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && !filter_var($iclinic_name, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE))
);
if (!$iclinic_ok) $iclinic_host = $iclinic_main;
// Behind Cloudflare Tunnel the visitor uses HTTPS
if (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https' && in_array($iclinic_name, $iclinic_extra, true)) $_SERVER['HTTPS'] = 'on';
$iclinic_scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
define('WP_HOME', $iclinic_scheme . '://' . $iclinic_host);
define('WP_SITEURL', $iclinic_scheme . '://' . $iclinic_host);
define('IDEV_LICENSE_DOMAIN', strtolower('{{COMPUTER}}'));   // the licence names this computer

define('FS_METHOD', 'direct');          // updates are written straight to disk
define('DISABLE_WP_CRON', true);        // a Windows scheduled task runs WordPress jobs every 5 minutes
define('WP_POST_REVISIONS', 10);
define('WP_MEMORY_LIMIT', '256M');
define('WP_DEBUG', false);
define('WP_DEBUG_LOG', '{{LOG_DIR}}wordpress.log');
define('WP_DEBUG_DISPLAY', false);
define('DISALLOW_FILE_EDIT', true);     // no code editor in the admin

if (!defined('ABSPATH')) define('ABSPATH', __DIR__ . '/');
require_once ABSPATH . 'wp-settings.php';
