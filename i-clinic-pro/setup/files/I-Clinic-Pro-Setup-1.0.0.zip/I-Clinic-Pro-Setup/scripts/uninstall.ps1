﻿<#
  I-Clinic Pro — ถอนการติดตั้ง  (ข้อมูลคนไข้และไฟล์สำรองไม่ถูกลบ เว้นแต่ยืนยันเอง)
#>
$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not (Test-Path (Join-Path $root 'iclinic.json'))) { $root = Split-Path -Parent $root }
$cfg = Get-Content (Join-Path $root 'iclinic.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$ans = Read-Host 'ถอนการติดตั้ง I-Clinic Pro ใช่ไหม (พิมพ์ YES)'
if ($ans -ne 'YES') { exit 0 }
Stop-Service $cfg.Service -ErrorAction SilentlyContinue
& sc.exe delete $cfg.Service | Out-Null
Get-ScheduledTask -TaskName 'I-Clinic Pro*' -ErrorAction SilentlyContinue | Unregister-ScheduledTask -Confirm:$false
Get-NetFirewallRule -DisplayName 'I-Clinic Pro*' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
$php = Join-Path $root 'php'
$mp = [Environment]::GetEnvironmentVariable('Path', 'Machine')
[Environment]::SetEnvironmentVariable('Path', (($mp -split ';') | Where-Object { $_ -and $_ -ne $php }) -join ';', 'Machine')
Remove-Item (Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'I-Clinic Pro.url') -ErrorAction SilentlyContinue
foreach ($d in @('apache', 'php', 'www', 'bin')) { Remove-Item (Join-Path $root $d) -Recurse -Force -ErrorAction SilentlyContinue }
Write-Host 'ถอนโปรแกรมแล้ว' -ForegroundColor Green
$del = Read-Host ('ลบข้อมูลคนไข้ (โฟลเดอร์ data) และไฟล์สำรองด้วยหรือไม่ ลบแล้วกู้คืนไม่ได้ (พิมพ์ DELETE เพื่อลบ, Enter = เก็บไว้)')
if ($del -eq 'DELETE') { Remove-Item (Join-Path $root 'data') -Recurse -Force; Remove-Item $cfg.BackupDir -Recurse -Force; Write-Host 'ลบข้อมูลแล้ว' }
else { Write-Host ('ข้อมูลยังอยู่ที่ ' + (Join-Path $root 'data') + ' และ ' + $cfg.BackupDir) -ForegroundColor Yellow }
