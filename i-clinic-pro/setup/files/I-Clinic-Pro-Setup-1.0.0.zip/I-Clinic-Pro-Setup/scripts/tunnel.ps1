﻿<#
  I-Clinic Pro — เปิดให้คนไข้จองนัด / ลงทะเบียนจากนอกคลินิกผ่าน Cloudflare Tunnel (ทางเลือก)
  ก่อนเริ่ม: ใน Cloudflare Zero Trust → Networks → Tunnels สร้าง tunnel แบบ cloudflared,
  ตั้ง Public hostname เช่น clinic.example.com → Service: HTTP  localhost:<พอร์ตของ I-Clinic>
  แล้วคัดลอก token ของ tunnel (พิมพ์ในหน้าต่างนี้เท่านั้น อย่าส่งให้ใครทางแชต)
#>
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$hostName = (Read-Host 'ชื่อเว็บที่ตั้งใน Cloudflare (เช่น clinic.example.com)').Trim().ToLower()
if ($hostName -notmatch '^[a-z0-9.-]+\.[a-z]{2,}$') { throw 'ชื่อเว็บไม่ถูกต้อง' }
$sec = Read-Host 'Tunnel token' -AsSecureString
$token = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
if ($token.Length -lt 50) { throw 'token สั้นเกินไป' }
$msi = Join-Path $root 'data\tmp\cloudflared.msi'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest -Uri 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.msi' -OutFile $msi -UseBasicParsing
Start-Process msiexec.exe -ArgumentList '/i', ('"' + $msi + '"'), '/quiet', '/norestart' -Wait
$cf = Join-Path ${env:ProgramFiles(x86)} 'cloudflared\cloudflared.exe'
if (-not (Test-Path $cf)) { $cf = Join-Path $env:ProgramFiles 'cloudflared\cloudflared.exe' }
& $cf service install $token
$token = $null
# let WordPress answer for the public name, over HTTPS
$cfgFile = Join-Path $root 'www\wp-config.php'
$c = [IO.File]::ReadAllText($cfgFile)
$c = [regex]::Replace($c, '\$iclinic_extra = \[(.*?)\];', { param($m) $list = @($m.Groups[1].Value -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ }); $q = "'" + $hostName + "'"; if ($list -notcontains $q) { $list += $q }; '$iclinic_extra = [' + ($list -join ', ') + '];' })
[IO.File]::WriteAllText($cfgFile, $c, (New-Object Text.UTF8Encoding($false)))
Write-Host ('เปิดแล้ว: https://' + $hostName + '/  (หน้าจองนัด https://' + $hostName + '/booking/)') -ForegroundColor Green
Write-Host 'แนะนำ: ใน Cloudflare Zero Trust → Access ตั้งให้ /wp-admin/ และ /wp-login.php เข้าได้เฉพาะพนักงาน' -ForegroundColor Yellow
