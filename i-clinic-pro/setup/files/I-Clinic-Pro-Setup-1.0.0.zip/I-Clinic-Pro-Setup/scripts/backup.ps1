﻿<#
  I-Clinic Pro — สำรองข้อมูล (Task Scheduler เรียกทุกคืน หรือดับเบิลคลิก "สำรองข้อมูลตอนนี้.cmd")
  ได้ไฟล์ zip หนึ่งไฟล์: ฐานข้อมูล (สำเนาที่ตรวจความถูกต้องแล้ว) + ไฟล์ที่อัปโหลด + การตั้งค่า + กุญแจเข้ารหัส
  ตั้งที่เก็บ / จำนวนวันที่เก็บได้ในไฟล์ iclinic.json (BackupDir, KeepDays) เช่น ไปไดรฟ์ USB หรือ NAS
#>
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$cfg = Get-Content (Join-Path $root 'iclinic.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$dest = $cfg.BackupDir; if (-not $dest) { $dest = Join-Path $root 'backup' }
$keep = [int]$cfg.KeepDays; if ($keep -lt 1) { $keep = 30 }
$log = Join-Path $root 'logs\backup.log'
function L($t) { Add-Content -Path $log -Value ((Get-Date -Format 's') + '  ' + $t) -Encoding UTF8 }
$env:PATH = (Join-Path $root 'php') + ';' + $env:PATH
Add-Type -AssemblyName System.IO.Compression.FileSystem

try {
    if (-not (Test-Path $dest)) { New-Item -ItemType Directory -Path $dest | Out-Null }
    $stamp = Get-Date -Format 'yyyy-MM-dd_HHmm'
    $work = Join-Path $root ('data\tmp\backup-' + $stamp)
    New-Item -ItemType Directory -Path $work -Force | Out-Null
    $php = Join-Path $root 'php\php.exe'
    $old = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $r = & $php (Join-Path $root 'bin\backup-db.php') (Join-Path $root 'data\iclinic.sqlite') (Join-Path $work 'iclinic.sqlite') 2>&1 | Out-String
    $code = $LASTEXITCODE; $ErrorActionPreference = $old
    if ($code -ne 0) { throw ('database copy failed: ' + $r) }
    # other files in the data folder (encryption keys etc.), not the live database or temporary files
    Get-ChildItem (Join-Path $root 'data') -File | Where-Object { $_.Name -notlike 'iclinic.sqlite*' } | Copy-Item -Destination $work
    Copy-Item (Join-Path $root 'www\wp-config.php') $work
    $up = Join-Path $root 'www\wp-content\uploads'
    if (Test-Path $up) { Copy-Item $up (Join-Path $work 'uploads') -Recurse }
    $zip = Join-Path $dest ('iclinic-' + $stamp + '.zip')
    [IO.Compression.ZipFile]::CreateFromDirectory($work, $zip)
    Remove-Item $work -Recurse -Force
    Get-ChildItem $dest -Filter 'iclinic-*.zip' | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-$keep) } | Remove-Item -Force
    L ('ok ' + $zip + ' ' + [math]::Round((Get-Item $zip).Length / 1MB, 1) + ' MB')
    Write-Host ('สำรองข้อมูลแล้ว: ' + $zip)
} catch {
    L ('FAILED ' + $_.Exception.Message)
    Write-Host ('สำรองข้อมูลไม่สำเร็จ: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
