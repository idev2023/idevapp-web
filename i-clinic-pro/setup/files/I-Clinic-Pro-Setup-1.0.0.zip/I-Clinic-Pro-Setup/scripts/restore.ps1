﻿<#
  I-Clinic Pro — กู้ข้อมูลจากไฟล์สำรอง (ดับเบิลคลิก "กู้ข้อมูล.cmd" แล้วเลือกไฟล์ iclinic-....zip)
  ข้อมูลปัจจุบันถูกเก็บไว้ก่อนในโฟลเดอร์ data\before-restore-... จึงย้อนกลับได้
#>
param([string]$Zip = '')
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$cfg = Get-Content (Join-Path $root 'iclinic.json') -Raw -Encoding UTF8 | ConvertFrom-Json
Add-Type -AssemblyName System.IO.Compression.FileSystem
if ($Zip -eq '') {
    Add-Type -AssemblyName System.Windows.Forms
    $d = New-Object Windows.Forms.OpenFileDialog
    $d.InitialDirectory = $cfg.BackupDir; $d.Filter = 'I-Clinic backup (iclinic-*.zip)|iclinic-*.zip'
    if ($d.ShowDialog() -ne 'OK') { exit 0 }
    $Zip = $d.FileName
}
$ans = Read-Host ('กู้ข้อมูลจาก ' + [IO.Path]::GetFileName($Zip) + ' ข้อมูลหลังวันที่สำรองจะหายไป พิมพ์ YES เพื่อยืนยัน')
if ($ans -ne 'YES') { Write-Host 'ยกเลิก'; exit 0 }
$tmp = Join-Path $root ('data\tmp\restore-' + (Get-Date -Format 'yyyyMMddHHmmss'))
[IO.Compression.ZipFile]::ExtractToDirectory($Zip, $tmp)
if (-not (Test-Path (Join-Path $tmp 'iclinic.sqlite'))) { throw 'ไฟล์นี้ไม่ใช่ไฟล์สำรองของ I-Clinic Pro' }
Stop-Service $cfg.Service
$keep = Join-Path $root ('data\before-restore-' + (Get-Date -Format 'yyyyMMdd-HHmm'))
New-Item -ItemType Directory -Path $keep | Out-Null
Get-ChildItem (Join-Path $root 'data') -File | Copy-Item -Destination $keep
Copy-Item (Join-Path $tmp 'iclinic.sqlite') (Join-Path $root 'data\iclinic.sqlite') -Force
Remove-Item (Join-Path $root 'data\iclinic.sqlite-*') -ErrorAction SilentlyContinue
Get-ChildItem $tmp -File | Where-Object { $_.Name -notin @('iclinic.sqlite', 'wp-config.php') } | Copy-Item -Destination (Join-Path $root 'data') -Force
if (Test-Path (Join-Path $tmp 'uploads')) {
    $up = Join-Path $root 'www\wp-content\uploads'
    if (Test-Path $up) { Rename-Item $up ($up + '-before-restore-' + (Get-Date -Format 'yyyyMMddHHmm')) }
    Copy-Item (Join-Path $tmp 'uploads') $up -Recurse
}
Remove-Item $tmp -Recurse -Force
Start-Service $cfg.Service
Write-Host ('กู้ข้อมูลเรียบร้อย ข้อมูลก่อนกู้อยู่ที่ ' + $keep) -ForegroundColor Green
