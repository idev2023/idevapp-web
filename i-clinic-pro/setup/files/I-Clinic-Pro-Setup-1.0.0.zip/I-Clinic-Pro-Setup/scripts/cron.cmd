@echo off
rem I-Clinic Pro: runs WordPress jobs (e-mails, appointment reminders). Started every 5 minutes by Task Scheduler.
set "ROOT=%~dp0.."
set "PATH=%ROOT%\php;%PATH%"
"%ROOT%\php\php.exe" "%ROOT%\bin\wp-cli.phar" --path="%ROOT%\www" cron event run --due-now --quiet >> "%ROOT%\logs\cron.log" 2>&1
