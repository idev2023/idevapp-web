﻿#Requires -Version 5.1
<#
  I-Clinic Pro — ติดตั้งครบในครั้งเดียวบนคอมพิวเตอร์ Windows 10/11 (64 บิต) ที่ยังไม่มีอะไรเลย
  Apache + PHP + WordPress (ฐานข้อมูล SQLite ไฟล์เดียว) + I-Clinic Pro + ธีม iDev App
  ตั้งเป็น Windows service เปิดเองเมื่อเปิดเครื่อง เปิด firewall ในวงแลน งานอัตโนมัติทุก 5 นาที และสำรองข้อมูลทุกคืน

  เปิดด้วยไฟล์ "Setup.cmd" (ขอสิทธิ์ผู้ดูแลเครื่องให้เอง)
  ติดตั้งแบบไม่ถาม:  Setup.cmd -Unattended -ClinicName "คลินิก..." -AdminEmail you@example.com
#>
[CmdletBinding()]
param(
    [string]$InstallDir = 'C:\iClinic',
    [int]$Port = 0,
    [string]$ClinicName = '',
    [string]$Address = '',
    [string]$Phone = '',
    [string]$PromptPay = '',
    [string]$AdminUser = '',
    [string]$AdminEmail = '',
    [switch]$Unattended
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Here     = Split-Path -Parent $MyInvocation.MyCommand.Path
$Files    = Join-Path $Here 'files'
$Packages = Join-Path $Here 'packages'
$Version  = '1.0.2'
$Utf8     = New-Object Text.UTF8Encoding($false)   # PHP and config files must not start with a BOM
$UA       = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) I-Clinic-Setup/1.0'

# ---------------------------------------------------------------- helpers
$script:LogFile = $null
function Log([string]$t) { if ($script:LogFile) { Add-Content -Path $script:LogFile -Value ((Get-Date -Format 's') + '  ' + $t) -Encoding UTF8 } }
function Say([string]$t, [string]$c = 'Gray') { Write-Host $t -ForegroundColor $c; Log $t }
function Step([string]$t) { Write-Host ''; Say ('>> ' + $t) 'Cyan' }
function Ok([string]$t) { Say ('   OK  ' + $t) 'Green' }
function Warn([string]$t) { Say ('   !!  ' + $t) 'Yellow' }
function Fail([string]$t) {
    Say ('XX ' + $t) 'Red'
    if ($script:LogFile) { Write-Host ('  บันทึกการติดตั้ง: ' + $script:LogFile) }
    throw $t
}
function WriteText([string]$path, [string]$text) { [IO.File]::WriteAllText($path, $text, $Utf8) }
function Ask([string]$q, [string]$def) {
    if ($Unattended) { return $def }
    $p = $q; if ($def -ne '') { $p += ' [' + $def + ']' }
    $a = Read-Host $p
    if ([string]::IsNullOrWhiteSpace($a)) { return $def } else { return $a.Trim() }
}
function RandomText([int]$len, [string]$chars) {
    $rng = New-Object Security.Cryptography.RNGCryptoServiceProvider
    $bytes = New-Object byte[] ($len * 2)
    $rng.GetBytes($bytes)
    $sb = New-Object Text.StringBuilder
    for ($i = 0; $i -lt $len; $i++) { [void]$sb.Append($chars[([BitConverter]::ToUInt16($bytes, $i * 2)) % $chars.Length]) }
    return $sb.ToString()
}
function Download([string]$url, [string]$to) {
    Log ('download ' + $url)
    Invoke-WebRequest -Uri $url -OutFile $to -UseBasicParsing -UserAgent $UA -TimeoutSec 600
    if (-not (Test-Path $to) -or (Get-Item $to).Length -lt 1024) { throw ('ดาวน์โหลดไม่สำเร็จ: ' + $url) }
}
<#
  Finds a package: first in the "packages" folder next to this script (copy files there to install
  without internet), otherwise downloads it and keeps a copy in "packages" for the next computer.
#>
function GetPackage([string]$label, [string]$pattern, [scriptblock]$urls, [string]$saveAs = '') {
    if (-not (Test-Path $Packages)) { New-Item -ItemType Directory -Path $Packages | Out-Null }
    $local = Get-ChildItem -Path $Packages -Filter $pattern -File -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
    if ($local) { Ok ($label + ': ใช้ไฟล์ในโฟลเดอร์ packages (' + $local.Name + ')'); return $local.FullName }
    $list = & $urls
    foreach ($u in $list) {
        if (-not $u) { continue }
        $name = [IO.Path]::GetFileName(($u -split '\?')[0]); if ($saveAs -ne '') { $name = $saveAs }
        $to = Join-Path $Packages $name
        try { Download $u $to; Ok ($label + ': ดาวน์โหลดแล้ว (' + $name + ')'); return $to }
        catch { Warn ($label + ': ดาวน์โหลดจาก ' + $u + ' ไม่ได้ (' + $_.Exception.Message + ')'); Remove-Item $to -ErrorAction SilentlyContinue }
    }
    Fail ($label + ' — ดาวน์โหลดไม่ได้ ให้ดาวน์โหลดเองแล้ววางไฟล์ในโฟลเดอร์ packages (ชื่อไฟล์แบบ ' + $pattern + ') แล้วเปิด Setup อีกครั้ง')
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
function Expand([string]$zip, [string]$to) {
    if (Test-Path $to) { Remove-Item $to -Recurse -Force }
    [IO.Compression.ZipFile]::ExtractToDirectory($zip, $to)
}
# Native programs write notes to stderr; in Windows PowerShell 5.1 that must not stop the script.
function Native([string]$exe, [string[]]$a) {
    $old = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    try { $out = & $exe @a 2>&1 | ForEach-Object { "$_" }; $code = $LASTEXITCODE } finally { $ErrorActionPreference = $old }
    return @{ Code = $code; Text = (($out | Out-String).Trim()) }
}
function B64([string]$t) { if ($t -eq '') { return '-' }; return [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($t)) }   # '-' = empty (PowerShell 5.1 drops empty arguments)
function Php([string[]]$a) {
    $r = Native $script:PhpExe $a
    $shown = ($a -join ' ') -replace '--admin_password=\S+', '--admin_password=***'
    Log ('php ' + $shown + ' -> ' + $r.Code + ' ' + $r.Text)
    if ($r.Code -ne 0) { throw ('คำสั่ง PHP ไม่สำเร็จ: ' + $shown + "`n" + $r.Text) }
    return $r.Text
}
function Wp([string[]]$a) { return Php (@('-d', 'memory_limit=512M', $script:WpCli, ('--path=' + $script:Www)) + $a) }

# ---------------------------------------------------------------- start
Clear-Host
Write-Host ''
Write-Host '  ==================================================' -ForegroundColor DarkCyan
Write-Host '     I-Clinic Pro  -  ติดตั้งระบบคลินิก (iDevApp)' -ForegroundColor DarkCyan
Write-Host '  ==================================================' -ForegroundColor DarkCyan
Write-Host ''

$me = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { Write-Host 'กรุณาเปิดด้วย Setup.cmd (ต้องใช้สิทธิ์ผู้ดูแลเครื่อง)' -ForegroundColor Red; exit 1 }
if (-not [Environment]::Is64BitOperatingSystem) { Write-Host 'ต้องใช้ Windows 64 บิต' -ForegroundColor Red; exit 1 }
if ([Environment]::OSVersion.Version.Major -lt 10) { Write-Host 'ต้องใช้ Windows 10 หรือ 11 / Windows Server 2016 ขึ้นไป' -ForegroundColor Red; exit 1 }

$InstallDir = $InstallDir.TrimEnd('\')
$Www   = Join-Path $InstallDir 'www'
$Data  = Join-Path $InstallDir 'data'
$Logs  = Join-Path $InstallDir 'logs'
$Bin   = Join-Path $InstallDir 'bin'
$ApacheDir = Join-Path $InstallDir 'apache'
$PhpDir    = Join-Path $InstallDir 'php'
$script:Www = $Www
$Service = 'iClinicWeb'

if (Test-Path (Join-Path $Www 'wp-config.php')) {
    Write-Host ('พบระบบที่ติดตั้งไว้แล้วที่ ' + $InstallDir) -ForegroundColor Yellow
    Write-Host 'อัปเดตระบบได้จากหลังบ้าน (แดชบอร์ด → อัปเดต) ถ้าต้องการติดตั้งใหม่ ให้เปิด Uninstall.cmd ก่อน' -ForegroundColor Yellow
    exit 1
}
foreach ($d in @($InstallDir, $Data, $Logs, $Bin, (Join-Path $Data 'tmp'), (Join-Path $Data 'sessions'), (Join-Path $InstallDir 'backup'))) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d | Out-Null }
}
$script:LogFile = Join-Path $Logs ('setup-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')
Log ('I-Clinic Pro setup ' + $Version + ' on ' + $env:COMPUTERNAME)

# ---------------------------------------------------------------- questions
Step 'ข้อมูลคลินิก (กด Enter เพื่อใช้ค่าในวงเล็บ แก้ภายหลังได้ในหลังบ้าน)'
if ($ClinicName -eq '') { $ClinicName = Ask 'ชื่อคลินิก / ร้าน' 'คลินิกของฉัน' }
if ($Address -eq '')    { $Address    = Ask 'ที่อยู่ (สำหรับใบเสร็จ)' '' }
if ($Phone -eq '')      { $Phone      = Ask 'เบอร์โทร' '' }
if ($PromptPay -eq '')  { $PromptPay  = Ask 'เลขพร้อมเพย์ (เบอร์มือถือหรือเลข 13 หลัก ว่างได้)' '' }
if ($AdminUser -eq '')  { $AdminUser  = Ask 'ชื่อผู้ใช้ผู้ดูแลระบบ' 'admin' }
if ($AdminEmail -eq '') { $AdminEmail = Ask 'อีเมลผู้ดูแลระบบ' ('admin@' + $env:COMPUTERNAME.ToLower() + '.local') }
if ($AdminUser -notmatch '^[A-Za-z0-9._@-]{3,60}$') { Fail 'ชื่อผู้ใช้ใช้ได้เฉพาะ a-z 0-9 . _ - @ อย่างน้อย 3 ตัว' }
if ($AdminEmail -notmatch '^[^@\s]+@[^@\s]+\.[^@\s]+$') { Fail 'อีเมลไม่ถูกต้อง' }

$Computer = $env:COMPUTERNAME.ToLower()
if ($Port -eq 0) {
    $busy = Get-NetTCPConnection -LocalPort 80 -State Listen -ErrorAction SilentlyContinue
    if ($busy) { $Port = 8080; Warn 'พอร์ต 80 มีโปรแกรมอื่นใช้อยู่ (เช่น IIS) จะใช้พอร์ต 8080 แทน' } else { $Port = 80 }
}
if (Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue) { Fail ('พอร์ต ' + $Port + ' มีโปรแกรมอื่นใช้อยู่ ปิดโปรแกรมนั้น หรือเปิด Setup ด้วย -Port 8081') }
$PortPart = ''; if ($Port -ne 80) { $PortPart = ':' + $Port }
$MainHost = $Computer + $PortPart
$SiteUrl = 'http://' + $MainHost
$Ips = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | Select-Object -ExpandProperty IPAddress)

# ---------------------------------------------------------------- packages
Step 'เตรียมโปรแกรมที่ต้องใช้ (ครั้งแรกต้องต่ออินเทอร์เน็ต)'
$VcZip = GetPackage 'Visual C++ Runtime' 'vc_redist.x64.exe' { @('https://aka.ms/vs/17/release/vc_redist.x64.exe') }
$ApacheZip = GetPackage 'Apache' 'httpd-2.4*-win64-VS1*.zip' {
    $u = @()
    try {
        $page = Invoke-WebRequest -Uri 'https://www.apachelounge.com/download/' -UseBasicParsing -UserAgent $UA -TimeoutSec 60
        $m = [regex]::Match($page.Content, '/download/VS1[78]/binaries/httpd-2\.4\.\d+-\d+-win64-VS1[78]\.zip')
        if ($m.Success) { $u += 'https://www.apachelounge.com' + $m.Value }
    } catch { Warn 'อ่านหน้าดาวน์โหลดของ Apache Lounge ไม่ได้ จะลองลิงก์สำรอง' }
    $u += 'https://www.apachelounge.com/download/VS17/binaries/httpd-2.4.66-251206-win64-VS17.zip'
    return $u
}
$PhpZip = GetPackage 'PHP 8.3' 'php-8.3*-Win32-vs16-x64*.zip' { @('https://windows.php.net/downloads/releases/latest/php-8.3-Win32-vs16-x64-latest.zip') }
$WpZip  = GetPackage 'WordPress (ภาษาไทย)' 'wordpress*.zip' { @('https://th.wordpress.org/latest-th.zip', 'https://wordpress.org/latest.zip') } 'wordpress-latest-th.zip'
$SqliteZip = GetPackage 'SQLite Database Integration' 'sqlite-database-integration*.zip' { @('https://downloads.wordpress.org/plugin/sqlite-database-integration.latest-stable.zip') }
$WpCliFile = GetPackage 'WP-CLI' 'wp-cli*.phar' { @('https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar') }
$CaFile = GetPackage 'ใบรับรอง HTTPS' 'cacert*.pem' { @('https://curl.se/ca/cacert.pem') }
$ClinicZip = GetPackage 'I-Clinic Pro' 'i-clinic-pro*.zip' { @('https://idevapp.me/updates/files/i-clinic-pro.zip') }
$ThemeZip  = GetPackage 'ธีม iDev App' 'idev-app*.zip' { @('https://idevapp.me/updates/files/idev-app.zip') }

# ---------------------------------------------------------------- runtime
Step 'ติดตั้ง Visual C++ Runtime'
$p = Start-Process -FilePath $VcZip -ArgumentList '/install', '/quiet', '/norestart' -Wait -PassThru
if (@(0, 1638, 3010) -contains $p.ExitCode) { Ok 'เรียบร้อย' } else { Warn ('ตัวติดตั้งตอบรหัส ' + $p.ExitCode + ' (ถ้ามีรุ่นใหม่กว่าอยู่แล้วไม่เป็นไร)') }

Step 'ติดตั้ง Apache และ PHP'
$tmp = Join-Path $Data 'tmp\apache'
Expand $ApacheZip $tmp
$inner = Get-ChildItem -Path $tmp -Directory | Where-Object { Test-Path (Join-Path $_.FullName 'bin\httpd.exe') } | Select-Object -First 1
if (-not $inner) { Fail 'ไฟล์ Apache ไม่ถูกต้อง (ไม่พบ bin\httpd.exe)' }
if (Test-Path $ApacheDir) { Remove-Item $ApacheDir -Recurse -Force }
Move-Item $inner.FullName $ApacheDir
Remove-Item $tmp -Recurse -Force
Expand $PhpZip $PhpDir
if (-not (Test-Path (Join-Path $PhpDir 'php8apache2_4.dll'))) { Fail 'PHP ต้องเป็นรุ่น Thread Safe (มีไฟล์ php8apache2_4.dll)' }
Copy-Item $CaFile (Join-Path $PhpDir 'cacert.pem') -Force
Copy-Item $WpCliFile (Join-Path $Bin 'wp-cli.phar') -Force
$script:PhpExe = Join-Path $PhpDir 'php.exe'
$script:WpCli = Join-Path $Bin 'wp-cli.phar'

$fwd = { param($s) $s.Replace('\', '/') }
$repl = @{ '{{PHP}}' = (& $fwd $PhpDir); '{{APACHE}}' = (& $fwd $ApacheDir); '{{WWW}}' = (& $fwd $Www); '{{LOGS}}' = (& $fwd $Logs); '{{DATA}}' = (& $fwd $Data); '{{PORT}}' = [string]$Port; '{{COMPUTER}}' = $Computer }
function Fill([string]$text) { foreach ($k in $repl.Keys) { $text = $text.Replace($k, $repl[$k]) }; return $text }

$ini = [IO.File]::ReadAllText((Join-Path $PhpDir 'php.ini-production')) + (Fill ([IO.File]::ReadAllText((Join-Path $Files 'php-iclinic.ini'))))
WriteText (Join-Path $PhpDir 'php.ini') $ini
# extensions such as intl load DLLs from the PHP folder: PHP must be on the PATH
$env:PATH = $PhpDir + ';' + $env:PATH
$mp = [Environment]::GetEnvironmentVariable('Path', 'Machine')
if (($mp -split ';') -notcontains $PhpDir) { [Environment]::SetEnvironmentVariable('Path', $PhpDir + ';' + $mp, 'Machine') }
$v = Php @('-r', 'echo PHP_VERSION, " ", implode(",", array_intersect(["curl","gd","intl","mbstring","openssl","pdo_sqlite","sodium","zip"], get_loaded_extensions()));')
Ok ('PHP ' + $v)
foreach ($ext in @('pdo_sqlite', 'mbstring', 'openssl', 'gd', 'curl')) { if ($v -notmatch $ext) { Fail ('PHP เปิดส่วนขยาย ' + $ext + ' ไม่ได้ ดูไฟล์ ' + $Logs + '\php-error.log') } }

WriteText (Join-Path $ApacheDir 'conf\httpd.conf') (Fill ([IO.File]::ReadAllText((Join-Path $Files 'httpd.conf'))))
$t = (Native (Join-Path $ApacheDir 'bin\httpd.exe') @('-t')).Text
Log ('httpd -t: ' + $t)
if ($t -notmatch 'Syntax OK') { Fail ('การตั้งค่า Apache ไม่ถูกต้อง: ' + $t) }
Ok 'Apache ตั้งค่าเรียบร้อย'

# ---------------------------------------------------------------- WordPress
Step 'ติดตั้ง WordPress'
$tmp = Join-Path $Data 'tmp\wp'
Expand $WpZip $tmp
$src = Join-Path $tmp 'wordpress'; if (-not (Test-Path $src)) { $src = $tmp }
if (Test-Path $Www) { Remove-Item $Www -Recurse -Force }
Move-Item $src $Www
if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
$plugins = Join-Path $Www 'wp-content\plugins'
Expand-Archive -Path $SqliteZip -DestinationPath $plugins -Force
Copy-Item (Join-Path $plugins 'sqlite-database-integration\db.copy') (Join-Path $Www 'wp-content\db.php') -Force

$saltChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#$%&()*+,-.:;<=>?@[]^_{|}~'
$salts = (@('AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT') | ForEach-Object { "define('" + $_ + "', '" + (RandomText 64 $saltChars) + "');" }) -join "`n"
$cfg = [IO.File]::ReadAllText((Join-Path $Files 'wp-config-template.php'))
$cfg = $cfg.Replace('{{DATA_DIR}}', ((& $fwd $Data) + '/')).Replace('{{LOG_DIR}}', ((& $fwd $Logs) + '/')).Replace('{{SALTS}}', $salts)
$cfg = $cfg.Replace('{{MAIN_HOST}}', $MainHost).Replace('{{COMPUTER}}', $Computer).Replace('{{EXTRA_HOSTS}}', '')
WriteText (Join-Path $Www 'wp-config.php') $cfg
WriteText (Join-Path $Www '.htaccess') ([IO.File]::ReadAllText((Join-Path $Files 'htaccess.txt')))
WriteText (Join-Path $Data 'index.php') "<?php // Silence is golden."

$pwChars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789-_.'
$AdminPass = RandomText 16 $pwChars
Wp @('core', 'install', ('--url=' + $SiteUrl), '--title=I-Clinic Pro', ('--admin_user=' + $AdminUser), ('--admin_password=' + $AdminPass), ('--admin_email=' + $AdminEmail), '--skip-email') | Out-Null
Ok 'สร้างฐานข้อมูลและบัญชีผู้ดูแลแล้ว'
Wp @('plugin', 'activate', 'sqlite-database-integration') | Out-Null
try { Wp @('site', 'switch-language', 'th') | Out-Null; Ok 'ตั้งภาษาไทย' } catch { Warn 'ตั้งภาษาไทยไม่ได้ (เปลี่ยนได้ที่ ตั้งค่า → ทั่วไป → ภาษาของเว็บไซต์)' }

Step 'ติดตั้ง I-Clinic Pro และธีม'
Wp @('plugin', 'install', $ClinicZip, '--activate', '--force') | Out-Null
Ok 'I-Clinic Pro'
Wp @('theme', 'install', $ThemeZip, '--activate', '--force') | Out-Null
Ok 'ธีม iDev App'
Wp @('rewrite', 'structure', '/%postname%/') | Out-Null
# Thai text goes to PHP as base64: Windows hands command-line text to PHP in the old code page
$first = Wp @('eval-file', (Join-Path $Files 'iclinic-firstrun.php'), (B64 $ClinicName), (B64 $Address), (B64 $Phone), (B64 $PromptPay))
Log $first
Ok 'ตั้งค่าคลินิก และสร้างหน้า นัดหมาย / ลงทะเบียน / ตารางออกตรวจ / สำหรับแพทย์ / ติดตามงาน'
foreach ($old in @('akismet', 'hello')) { try { Wp @('plugin', 'delete', $old) | Out-Null } catch {} }
try { Wp @('theme', 'delete', '--all') | Out-Null } catch {}

# ---------------------------------------------------------------- permissions
Step 'สิทธิ์ของโฟลเดอร์'
# The web server runs as LocalSystem; ordinary Windows users only read the program.
& icacls $InstallDir /inheritance:r /grant:r '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX' /T /C /Q | Out-Null
& icacls $Data /inheritance:r /grant:r '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-18:(OI)(CI)F' /T /C /Q | Out-Null
Ok 'ข้อมูลคนไข้ในโฟลเดอร์ data เปิดได้เฉพาะผู้ดูแลเครื่องและระบบ'

# ---------------------------------------------------------------- service
Step 'ตั้งเป็น Windows service (เปิดเองเมื่อเปิดเครื่อง)'
$httpd = Join-Path $ApacheDir 'bin\httpd.exe'
Log ('httpd -k install: ' + (Native $httpd @('-k', 'install', '-n', $Service)).Text)
$svcKey = 'HKLM:\SYSTEM\CurrentControlSet\Services\' + $Service
if (-not (Test-Path $svcKey)) { Fail 'สร้าง service ไม่สำเร็จ' }
New-ItemProperty -Path $svcKey -Name 'Environment' -PropertyType MultiString -Force -Value @(('PATH=' + $PhpDir + ';' + $env:SystemRoot + '\System32;' + $env:SystemRoot), ('TEMP=' + (Join-Path $Data 'tmp')), ('TMP=' + (Join-Path $Data 'tmp'))) | Out-Null
Set-ItemProperty -Path $svcKey -Name 'DisplayName' -Value 'I-Clinic Pro (เว็บเซิร์ฟเวอร์)'
& sc.exe config $Service start= auto | Out-Null
& sc.exe failure $Service reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null
Start-Service $Service
Start-Sleep -Seconds 2
$ok = $false
for ($i = 0; $i -lt 10 -and -not $ok; $i++) {
    try { $r = Invoke-WebRequest -Uri ('http://127.0.0.1' + $PortPart + '/wp-login.php') -UseBasicParsing -TimeoutSec 20; $ok = ($r.StatusCode -eq 200) } catch { Start-Sleep -Seconds 2 }
}
if (-not $ok) { Fail ('เว็บไม่ตอบ ดู ' + $Logs + '\apache-error.log และ php-error.log') }
Ok ('เว็บทำงานที่พอร์ต ' + $Port)

Step 'Firewall (ให้เครื่องอื่นในคลินิกเปิดได้)'
Get-NetFirewallRule -DisplayName 'I-Clinic Pro*' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
New-NetFirewallRule -DisplayName ('I-Clinic Pro (เว็บ พอร์ต ' + $Port + ')') -Direction Inbound -Protocol TCP -LocalPort $Port -Action Allow -Profile Domain, Private | Out-Null
Ok 'เปิดในเครือข่ายแบบ Private / Domain'
$pub = Get-NetConnectionProfile -ErrorAction SilentlyContinue | Where-Object { $_.NetworkCategory -eq 'Public' }
if ($pub) { Warn ('เครือข่าย "' + ($pub[0].Name) + '" ตั้งเป็น Public เครื่องอื่นจะเปิดไม่ได้ ตั้งเป็น Private ที่ Settings → Network → Properties') }

# ---------------------------------------------------------------- scheduled tasks
Step 'งานอัตโนมัติ'
Copy-Item (Join-Path $Here 'scripts\*') $Bin -Force
Copy-Item (Join-Path $Files 'backup-db.php') $Bin -Force
$cfgJson = @{ InstallDir = $InstallDir; BackupDir = (Join-Path $InstallDir 'backup'); KeepDays = 30; Port = $Port; Service = $Service; Version = $Version } | ConvertTo-Json
WriteText (Join-Path $InstallDir 'iclinic.json') $cfgJson
$sys = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 2) -MultipleInstances IgnoreNew
$cronAction = New-ScheduledTaskAction -Execute (Join-Path $Bin 'cron.cmd') -WorkingDirectory $Bin
$cronTrigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5)
Register-ScheduledTask -TaskName 'I-Clinic Pro - งานอัตโนมัติ' -Action $cronAction -Trigger $cronTrigger -Principal $sys -Settings $set -Force | Out-Null
Ok 'ส่งอีเมล / แจ้งเตือนนัด ทุก 5 นาที'
$bkAction = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $Bin 'backup.ps1') + '"')
$bkTrigger = New-ScheduledTaskTrigger -Daily -At '02:30'
Register-ScheduledTask -TaskName 'I-Clinic Pro - สำรองข้อมูล' -Action $bkAction -Trigger $bkTrigger -Principal $sys -Settings $set -Force | Out-Null
Ok ('สำรองข้อมูลทุกคืน 02:30 ไปที่ ' + (Join-Path $InstallDir 'backup') + ' (เก็บ 30 วัน)')

# ---------------------------------------------------------------- shortcuts and summary
Step 'ทางลัดบนหน้าจอ'
$desk = [Environment]::GetFolderPath('CommonDesktopDirectory')
WriteText (Join-Path $desk 'I-Clinic Pro.url') ("[InternetShortcut]`r`nURL=http://localhost" + $PortPart + "/wp-admin/`r`n")
Copy-Item (Join-Path $Here 'launchers\*.cmd') $InstallDir -Force   # Uninstall, Backup-now, Restore, Open-to-internet
Ok 'ไอคอน "I-Clinic Pro" บนเดสก์ท็อป'

$lines = @(
    'I-Clinic Pro — ข้อมูลเข้าระบบ (เก็บไฟล์นี้ไว้ให้ดี ลบได้หลังจดไว้แล้ว)',
    ('ติดตั้งเมื่อ: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm')),
    '',
    ('เครื่องนี้:            http://localhost' + $PortPart + '/'),
    ('เครื่องอื่นในคลินิก:  ' + $SiteUrl + '/')
)
foreach ($ip in $Ips) { $lines += ('                      http://' + $ip + $PortPart + '/') }
$lines += @('', ('หลังบ้าน:  ' + $SiteUrl + '/wp-admin/'), ('ผู้ใช้:     ' + $AdminUser), ('รหัสผ่าน:  ' + $AdminPass), '',
    ('License ของ I-Clinic Pro ออกให้ชื่อเครื่อง: ' + $Computer), 'ใส่ license ที่ หลังบ้าน → iDevApp → License (ยังไม่ใส่ใช้ได้ครบ แต่ใบเสร็จมีคำว่า TRIAL)')
$credFile = Join-Path $InstallDir 'ข้อมูลเข้าระบบ.txt'
[IO.File]::WriteAllLines($credFile, $lines, (New-Object Text.UTF8Encoding($true)))
& icacls $credFile /inheritance:r /grant:r '*S-1-5-32-544:F' '*S-1-5-18:F' /Q | Out-Null

Write-Host ''
Write-Host '  ==================================================' -ForegroundColor Green
Write-Host '     ติดตั้ง I-Clinic Pro เสร็จแล้ว' -ForegroundColor Green
Write-Host '  ==================================================' -ForegroundColor Green
foreach ($l in $lines) { Write-Host ('   ' + $l) }
Write-Host ''
Write-Host ('   ข้อมูลนี้บันทึกไว้ที่ ' + $credFile) -ForegroundColor Yellow
Write-Host '   ขั้นต่อไป: เข้าหลังบ้าน แล้วทำตามรายการ "ตั้งค่า" ในหน้าแรกของ I-Clinic Pro' -ForegroundColor Yellow
Log 'setup finished'
if (-not $Unattended) {
    Start-Process notepad.exe -ArgumentList ('"' + $credFile + '"')     # in case this window can't show Thai letters
    Start-Process ('http://localhost' + $PortPart + '/wp-login.php')
}
